import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';

const rootDir = process.cwd();
console.log('🚀 [Asset Optimizer] Starting automated image & asset optimization...');

const targets = [
  { file: 'public/logo.jpg', resize: '512x512', quality: 82, format: 'jpg' },
  { file: 'public/apple-touch-icon.png', resize: '180x180', quality: 85, format: 'png' },
  { file: 'public/icon-192.png', resize: '192x192', quality: 85, format: 'png' },
  { file: 'public/icon-512.png', resize: '512x512', quality: 85, format: 'png' },
  { file: 'public/favicon.ico', resize: '48x48', quality: 85, format: 'ico' },
  { file: 'src/assets/images/smart_teacher_logo_1791551437596.jpg', resize: '512x512', quality: 82, format: 'jpg' },
];

for (const t of targets) {
  const fullPath = path.join(rootDir, t.file);
  if (fs.existsSync(fullPath)) {
    const statsBefore = fs.statSync(fullPath);
    if (statsBefore.size > 80 * 1024) {
      try {
        console.log(`📦 Compressing ${t.file} (current: ${Math.round(statsBefore.size / 1024)} KB)...`);
        execSync(`convert "${fullPath}" -resize ${t.resize} -quality ${t.quality} "${fullPath}"`, { stdio: 'ignore' });
        const statsAfter = fs.statSync(fullPath);
        console.log(`✅ Optimized ${t.file}: ${Math.round(statsBefore.size / 1024)} KB -> ${Math.round(statsAfter.size / 1024)} KB`);
        
        // Also generate webp counterpart
        const webpPath = fullPath.replace(/\.(png|jpg|jpeg)$/i, '.webp');
        if (t.format !== 'ico' && !fs.existsSync(webpPath)) {
          execSync(`convert "${fullPath}" -quality ${t.quality} "${webpPath}"`, { stdio: 'ignore' });
          console.log(`✨ Generated WebP: ${path.basename(webpPath)}`);
        }
      } catch (err) {
        console.warn(`⚠️ Warning optimizing ${t.file}:`, err.message);
      }
    }
  }
}

// Clean unreferenced artifacts from dist-singlefile if it exists
const singleFileDir = path.join(rootDir, 'dist-singlefile');
if (fs.existsSync(singleFileDir)) {
  const redundantFiles = [
    'al-moallim-smart-study.zip',
    'al-muallem-al-dhaki-complete.html',
    'apple-touch-icon.png',
    'favicon.ico',
    'icon-192.png',
    'icon-512.png',
    'logo.jpg'
  ];
  for (const rf of redundantFiles) {
    const rfp = path.join(singleFileDir, rf);
    if (fs.existsSync(rfp)) {
      try { fs.unlinkSync(rfp); } catch {}
    }
  }
}

console.log('🎉 [Asset Optimizer] Image & asset optimization complete.');
