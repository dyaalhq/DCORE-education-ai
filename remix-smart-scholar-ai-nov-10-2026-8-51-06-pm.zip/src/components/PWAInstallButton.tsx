import React, { useState } from 'react';
import { Download, Smartphone, Share, PlusSquare, X, Check, Laptop } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface PWAInstallButtonProps {
  variant?: 'header' | 'sidebar' | 'card' | 'settings';
  className?: string;
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({
  variant = 'header',
  className = '',
}) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSModal, setShowIOSModal] = useState(false);

  if (isInstalled) {
    if (variant === 'settings') {
      return (
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 text-xs font-bold border border-emerald-200 dark:border-emerald-800">
          <Check className="w-4 h-4" />
          <span>التطبيق مثبت على جهازك كـ PWA</span>
        </div>
      );
    }
    return null;
  }

  const handleInstallClick = async () => {
    if (isInstallable) {
      await install();
    } else if (isIOS) {
      setShowIOSModal(true);
    } else {
      // Browser doesn't have active prompt yet or desktop
      setShowIOSModal(true);
    }
  };

  // Render by variant
  let buttonContent = (
    <button
      type="button"
      onClick={handleInstallClick}
      className={`flex items-center gap-1.5 rounded-xl text-xs font-black transition-all cursor-pointer shadow-sm active:scale-95 ${
        variant === 'header'
          ? 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 px-3 py-1.5 shadow-amber-500/20'
          : variant === 'sidebar'
          ? 'w-full justify-center bg-teal-50 dark:bg-[#1a2723] text-teal-800 dark:text-teal-200 border border-teal-200 dark:border-teal-800/60 hover:bg-teal-100 py-2.5 px-3'
          : variant === 'card'
          ? 'bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 text-white px-4 py-2.5 shadow-md shadow-teal-600/20'
          : 'bg-[#0f766e] hover:bg-[#115e59] text-white px-4 py-2 rounded-xl'
      } ${className}`}
      title="تثبيت التطبيق على الشاشة الرئيسية لجهازك كـ تطبيق أصلي"
    >
      <Download className="w-3.5 h-3.5 stroke-[2.5]" />
      <span>تثبيت التطبيق</span>
      <span className="text-[10px] bg-white/25 px-1.5 py-0.2 rounded-full font-bold">PWA</span>
    </button>
  );

  return (
    <>
      {buttonContent}

      {/* iOS & Manual Installation Instructions Modal */}
      {showIOSModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in duration-200" dir="rtl">
          <div className="bg-white dark:bg-[#15231f] rounded-3xl p-6 max-w-md w-full shadow-2xl border border-teal-100 dark:border-teal-800 text-slate-800 dark:text-slate-100 relative">
            <button
              onClick={() => setShowIOSModal(false)}
              className="absolute top-4 left-4 p-1.5 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-[#1e2d28] transition"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#0f766e] to-[#14b8a6] text-white flex items-center justify-center shadow-md">
                <Smartphone className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-black text-base">إضافة «المعلم الذكي» لشاشتك الرئيسية</h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  استمتع بتجربة تطبيق كامل الشاشة وسرعة فائقة بدون أشرطة المتصفح
                </p>
              </div>
            </div>

            <div className="space-y-3 bg-slate-50 dark:bg-[#1a2723] p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 text-xs leading-relaxed">
              <div className="flex items-start gap-2.5">
                <div className="w-5 h-5 rounded-full bg-teal-600 text-white flex items-center justify-center font-bold text-[11px] shrink-0 mt-0.5">
                  1
                </div>
                <div>
                  في متصفحك (Safari على الآيفون أو Chrome على الأندرويد/الكمبيوتر)، اضغط على زر <strong>المشاركة (Share)</strong> <Share className="inline w-3.5 h-3.5 text-teal-600" /> أو قائمة الخيارات <span className="font-bold">⋮</span>.
                </div>
              </div>

              <div className="flex items-start gap-2.5">
                <div className="w-5 h-5 rounded-full bg-teal-600 text-white flex items-center justify-center font-bold text-[11px] shrink-0 mt-0.5">
                  2
                </div>
                <div>
                  اختر من القائمة: <strong>«إضافة إلى الشاشة الرئيسية» (Add to Home Screen)</strong> <PlusSquare className="inline w-3.5 h-3.5 text-teal-600" /> أو <strong>«تثبيت التطبيق» (Install App)</strong>.
                </div>
              </div>

              <div className="flex items-start gap-2.5">
                <div className="w-5 h-5 rounded-full bg-teal-600 text-white flex items-center justify-center font-bold text-[11px] shrink-0 mt-0.5">
                  3
                </div>
                <div>
                  اضغط على <strong>«إضافة» (Add)</strong>، وستجد أيقونة التطبيق الفخمة مباشرة على شاشتك الرئيسية!
                </div>
              </div>
            </div>

            <div className="mt-5 flex justify-end">
              <button
                type="button"
                onClick={() => setShowIOSModal(false)}
                className="w-full py-2.5 bg-[#0f766e] hover:bg-[#115e59] text-white rounded-xl font-bold text-xs transition shadow-sm cursor-pointer"
              >
                فهمت ذلك، شكراً لك!
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
