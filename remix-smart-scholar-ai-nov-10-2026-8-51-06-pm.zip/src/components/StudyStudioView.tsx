import React, { useState, useRef, useMemo } from 'react';
import { 
  Sparkles, 
  HelpCircle, 
  Layers, 
  GitFork, 
  Calendar, 
  BookOpen, 
  CheckCircle2, 
  XCircle, 
  RotateCw, 
  Download, 
  Plus, 
  Trash2, 
  Loader2, 
  FileText,
  Printer,
  Edit3,
  Copy,
  Check,
  Bold,
  Italic,
  List,
  ListOrdered,
  Heading,
  Quote,
  Code,
  Eye,
  Camera,
  Image,
  FileDown,
  Upload,
  Link2,
  X,
  Palette,
  Terminal,
  ChevronDown,
  LayoutTemplate,
  Sigma,
  Calculator,
  Table,
  FileSpreadsheet,
  TrendingUp,
  BarChart3,
  Mic,
  MicOff,
  AlertTriangle,
  Bell,
  Clock,
  Square,
  Radio,
  Play,
  Pause,
  Volume2,
  RotateCcw,
  AlertCircle
} from 'lucide-react';
import katex from 'katex';
import { Source, SourceChunk, QuizQuestion, Flashcard, StudyPlan, TodoItem, MemoItem, GlossaryItem, MindMapNode, NoteItem, FallbackAISettings } from '../types';
import { InteractiveMindMap } from './InteractiveMindMap';
import { D3VisualMindMap } from './D3VisualMindMap';
import { EducationalContent } from './EducationalContent';
import { formatNextReviewTime } from '../lib/spacedRepetition';
import { AcademicPrintModal } from './AcademicPrintModal';
import { StudyProgressDashboard } from './StudyProgressDashboard';
import { FlashcardMasteryDashboard } from './FlashcardMasteryDashboard';
import { studySpeechEngine } from '../lib/studySpeechEngine';
import { StudySpeechController } from './StudySpeechController';
import {
  extractStructuredSummary,
  generateIntelligentAcademicSummary,
  filterAIFiller,
  preprocessAndEnforceAcademicSchema,
  ACADEMIC_SUMMARY_SCHEMA_PROMPT,
  StructuredSummary,
  mindMapToStructuredSummary,
  exportNoteToPdf,
} from '../lib/academicFormatter';
import { extractTextFromPDF } from '../lib/pdfExtractor';
import {
  generateStudioSummary,
  generateStudioQuiz,
  generateStudioFlashcards,
  generateStudioMindMapData,
  generateStudioPlan,
  generateStudioGlossary,
} from '../lib/studioAiBridge';
import { SmartQuizView } from './InteractiveQuizView';
import { StudyReminderController } from './StudyReminderController';

interface StudyStudioViewProps {
  currentNotebookId: string;
  notebookTitle?: string;
  notebookSubject?: string;
  initialTab?: 'summary' | 'quiz' | 'cards' | 'progress' | 'mindmap' | 'planner' | 'memos';
  sources: Source[];
  chunks: SourceChunk[];
  notes?: NoteItem[];
  onAddNote?: (title: string, text: string, tags?: string[]) => void;
  onDeleteNote?: (id: string) => void;
  onAskAboutNote?: (note: NoteItem) => void;
  flashcards: Flashcard[];
  onAddFlashcards: (cards: Flashcard[]) => void;
  onReviewCard: (cardId: string, rating: boolean | 'again' | 'hard' | 'good' | 'easy') => void;
  todos: TodoItem[];
  onAddTodo: (text: string, due?: string) => void;
  onToggleTodo: (id: string) => void;
  onDeleteTodo: (id: string) => void;
  memos: MemoItem[];
  onAddMemo: (text: string) => void;
  onDeleteMemo: (id: string) => void;
  glossary: GlossaryItem[];
  onAddGlossary: (term: string, def: string, ex?: string) => void;
  onDeleteGlossary: (id: string) => void;
  fallbackConfig?: FallbackAISettings;
}

function safeParseJson<T = any>(rawText: string): T | null {
  if (!rawText) return null;
  const trimmed = rawText.trim();
  try {
    return JSON.parse(trimmed);
  } catch (e) {
    // continue
  }
  const codeBlockMatch = trimmed.match(/```(?:json)?\s*([\s\S]*?)\s*```/i);
  if (codeBlockMatch && codeBlockMatch[1]) {
    try {
      return JSON.parse(codeBlockMatch[1].trim());
    } catch (e) {
      // continue
    }
  }
  const braceMatch = trimmed.match(/(\{[\s\S]*\}|\[[\s\S]*\])/);
  if (braceMatch && braceMatch[1]) {
    try {
      return JSON.parse(braceMatch[1].trim());
    } catch (e) {
      // continue
    }
  }
  return null;
}

export interface NoteTemplateItem {
  id: string;
  name: string;
  badge: string;
  description: string;
  suggestedTitle: string;
  content: string;
}

export const NOTE_TEMPLATES: NoteTemplateItem[] = [
  {
    id: 'book_summary',
    name: 'تلخيص كتاب / فصل دراسي',
    badge: 'شامل',
    description: 'هيكل متكامل للأطروحة، الأركان الأساسية، شواهد الاقتباسات، والمسرد المفاهيمي.',
    suggestedTitle: 'ملخص: [اسم الكتاب أو الفصل الدراسي]',
    content: `# 📖 ملخص دراسي: [اسم الكتاب أو الفصل]

**المؤلف / المرجع الأكاديمي:** [اسم المؤلف أو المصدر]  
**تاريخ التلخيص:** ${new Date().toLocaleDateString('ar-EG')} | **المادة:** [اسم المادة الدراسية]

---

### 🎯 1. الفكرة المركزية والأطروحة (Core Thesis)
> [اكتب هنا الفكرة المحورية الكبرى التي يدور حولها هذا الفصل بأسلوب مكثف وواضح]

---

### 📌 2. الأفكار الرئيسية والأركان الأساسية
1. **المفهوم الأول:** [الشرح والتحليل المركز، مع ذكر النقاط الجوهرية]
2. **المفهوم الثاني:** [الشرح والتحليل المركز]
3. **المفهوم الثالث:** [الشرح والتحليل المركز]

---

### 💬 3. شواهد واقتباسات جوهرية
- «[اقتباس نصي بارز ومؤثر من المصدر]» — *(ص: [رقم الصفحة])*
- «[اقتباس آخر يوثق قانوناً أو تعليلاً مهماً]»

---

### 🧩 4. مسرد المصطلحات الجديدة (Key Vocabulary)
- **[المصطلح الأول]:** [التعريف الدقيق كما ورد في النص]
- **[المصطلح الثاني]:** [التعريف الدقيق كما ورد في النص]

---

### 💡 5. الخلاصة والاستنتاج الشخصي
[ما هي الاستفادة المباشرة وكيف ترتبط هذه المعرفة بالاختبار أو بالتطبيقات العملية؟]`
  },
  {
    id: 'comparison_table',
    name: 'جدول مقارنة أكاديمي',
    badge: 'مقارنات',
    description: 'مصفوفة مقارنة منهجية بين مفهومين أو نظريتين لمنع الخلط وتوضيح الفروق.',
    suggestedTitle: 'مقارنة: [المفهوم أ] مقابل [المفهوم ب]',
    content: `# ⚖️ جدول مقارنة تحليلي: [المفهوم أ] مقابل [المفهوم ب]

**الهدف الدراسي:** توضيح الفروق الدقيقة وأوجه الشبه بين المفهومين لتثبيت الفهم للامتحانات.

---

### 📊 مصفوفة المقارنة المنهجية

| وجه المقارنة | 🔹 [المفهوم / النظرية أ] | 🔸 [المفهوم / النظرية ب] |
| :--- | :--- | :--- |
| **التعريف الأساسي** | [التعريف الموجز المحدد] | [التعريف الموجز المحدد] |
| **الشروط والمتطلبات** | [شروط التحقق أو التطبيق] | [شروط التحقق أو التطبيق] |
| **الصيغة الرياضية / الرمز** | \`$القانون_1$\` | \`$القانون_2$\` |
| **أهم الخصائص** | [خاصية 1، خاصية 2] | [خاصية 1، خاصية 2] |
| **مثال تطبيقي واقعي** | [مثال نموذجي] | [مثال نموذجي] |
| **الفرق الجوهري** | [الفارق الأساسي الحاسم] | [الفارق الأساسي الحاسم] |

---

### 🔍 أوجه التقاطع والشبه:
- [نقطة التشابه الأولى]
- [نقطة التشابه الثانية]

---

### ⚠️ محاذير وأخطاء شائعة:
> **تنبيه اختباري:** لا تخلط بين المفهومين عند دراسة حالة [بيان الحالة الاستثنائية].`
  },
  {
    id: 'weekly_review',
    name: 'مراجعة أسبوعية شاملة',
    badge: 'تنظيم',
    description: 'جرد أسبوعي للمواضيع المنجزة، القوانين الذهبية، والمسائل التي تم حلها.',
    suggestedTitle: 'مراجعة الأسبوع الدراسي [رقم الأسبوع]',
    content: `# 📅 مراجعة المذاكرة الأسبوعية: [الأسبوع / الوحدة الدراسية]

**الفترة:** من [تاريخ البدء] إلى [تاريخ الانتهاء] | **معدل الإنجاز:** 🟢 ممتاز

---

### 🎯 1. المواضيع والدروس المنجزة هذا الأسبوع
- [x] **الدرس الأول:** [ملخص ما تم تحصيله واستيعابه]
- [x] **الدرس الثاني:** [أهم المفاهيم والقوانين المستفادة]
- [ ] **موضوع يحتاج مراجعة إضافية:** [تحديد الموضوع المطلوب]

---

### 📐 2. القوانين والمعادلات الذهبية المستفادة
$$\\Delta E = mc^2$$
- **دلالات الرموز:** [شرح المتغيرات ووحدات القياس وشروط التعويض]

---

### 🧠 3. مسائل وتطبيقات تم حلها بنجاح
1. **المسألة الأولى:** [فكرتها وطريقة الوصول للحل النموذجي]
2. **المسألة الثانية:** [الفخ أو الخدعة التي تم التغلب عليها]

---

### 🚩 4. نقاط الضعف التي تحتاج إلى تثبيت
- [ ] مراجعة الفروق بين [المصطلح 1] و [المصطلح 2].
- [ ] حل 5 تمارين تدريبية إضافية على [القانون الرئيسي].

---

### 🚀 5. خطة الأسبوع القادم والأهداف
1. [الهدف الدراسي الأول]
2. [الهدف الدراسي الثاني]`
  },
  {
    id: 'problem_analysis',
    name: 'تحليل مسألة / تجربة علمية',
    badge: 'مسائل وبرهان',
    description: 'توثيق منظم لمعطيات المسألة، الفرضيات، خطوات الحل، والتحقق الرياضي.',
    suggestedTitle: 'تحليل مسألة: [عنوان المسألة أو القانون]',
    content: `# 🧪 تقرير تحليل مسألة / تجربة: [عنوان المسألة أو التجربة]

**المادة:** [فيزياء / كيمياء / رياضيات] | **المصدر:** [رقم الصفحة / التمرين]

---

### 1. معطيات المسألة والفرضيات (Given Data)
- **المعطى الأول:** $v_0 = ...$
- **المعطى الثاني:** $t = ...$
- **المطلوب حسابه أو إثباته:** $[المتغير المطلوب مع رمزه]$

---

### 2. القوانين والمعادلات المعتمدة
$$v = v_0 + a \\cdot t$$

---

### 3. خطوات الحل والبرهان النموذجي (Step-by-Step)
1. **الخطوة الأولى:** [كتابة القانون والتعويض بالمعطيات]
2. **الخطوة الثانية:** [التبسيط الرياضي ونقل الأطراف]
3. **الخطوة الثالثة:** [الحساب والوصول للناتج النهائي]

---

### 4. النتيجة النهائية والتحقق (Conclusion & Verification)
> **النتيجة النهائية:** $[الرقم النهائي مع وحدة القياس]$  
> **التحقق المنطقي:** [تفسير صحة النتيجة منطقياً وفيزيائياً]`
  },
  {
    id: 'cornell_notes',
    name: 'نظام كورنيل للمذاكرة',
    badge: 'استرجاع نشط',
    description: 'أسلوب التدوين الجامعي: كلمات مفتاحية وأسئلة، شروحات مفصلة، وملخص ختامي.',
    suggestedTitle: 'تدوينة كورنيل: [عنوان الدرس / المحاضرة]',
    content: `# 🏛️ تدوين بنظام كورنيل: [عنوان المحاضرة أو الدرس]

**المحاضر / المصدر:** [الاسم] | **التاريخ:** ${new Date().toLocaleDateString('ar-EG')}

---

### 🔑 الكلمات المفتاحية والأسئلة الاسترجاعية (Cues & Questions)
*استخدم هذه الأسئلة لاختبار نفسك واسترجاع المعلومات لاحقاً:*
- ما هو التعريف الدقيق لـ [المفهوم الرئيسي]؟
- ما هي الشروط الثلاثة لتطبيق [القاعدة]؟
- كيف تستنتج [العلاقة الرياضية] من [القانون الأول]؟

---

### 📝 الملاحظات والشروحات التفصيلية (Lecture Notes)
*تفاصيل الدرس والأفكار المرتبة أثناء القراءة والمذاكرة:*
- **النقطة الأولى:** [شرح المفهوم بالأمثلة العملية]
- **النقطة الثانية:** [القواعد والتفصيلات الهامة]
- **النقطة الثالثة:** [الاستثناءات والملاحظات الخاصة التي ركّز عليها المرجع]

---

### 📌 الملخص الختامي المركز (Summary)
> [لخص محتوى هذه الصفحة بالكامل في سطرين أو ثلاثة فقط للمراجعة الفورية ليلة الامتحان]`
  },
  {
    id: 'glossary_card',
    name: 'بطاقة مصطلحات ومفاهيم',
    badge: 'معجم',
    description: 'بطاقة معجمية لتعريف المصطلحات الأكاديمية مع الخصائص والأمثلة والأخطاء.',
    suggestedTitle: 'بطاقة مفهوم: [اسم المصطلح]',
    content: `# 🏷️ بطاقة مفهوم أكاديمي: [اسم المصطلح]

---

- **المصطلح باللغة العربية:** [المصطلح بالعربية]
- **المصطلح باللغة الإنجليزية / اللاتينية:** *[English Term]*
- **المجال والتخصص:** [التخصص الدقيق]

### 📖 التعريف المعياري الشامل:
> "[اكتب هنا التعريف المعتمد حرفياً كما ورد في المرجع الأكاديمي]"

### 🎯 الخصائص والأركان الأساسية:
1. **الخاصية الأولى:** [الوصف والشرح]
2. **الخاصية الثانية:** [الوصف والشرح]

### 💡 مثال واقعي توضيحي:
- [مثال تطبيقي يجسد المفهوم ويوضحه بشكل ملموس]

### ⚠️ أخطاء شائعة ومحاذير:
- [خطأ يقع فيه الكثير من الطلاب أو خلط بينه وبين مصطلح مشابه]`
  }
];

export const StudyStudioView: React.FC<StudyStudioViewProps> = ({
  currentNotebookId,
  notebookTitle,
  notebookSubject,
  initialTab = 'summary',
  sources,
  chunks,
  notes = [],
  onAddNote,
  onDeleteNote,
  onAskAboutNote,
  flashcards,
  onAddFlashcards,
  onReviewCard,
  todos,
  onAddTodo,
  onToggleTodo,
  onDeleteTodo,
  memos,
  onAddMemo,
  onDeleteMemo,
  glossary,
  onAddGlossary,
  onDeleteGlossary,
  fallbackConfig,
}) => {
  const [activeTab, setActiveTab] = useState<'summary' | 'quiz' | 'cards' | 'progress' | 'mindmap' | 'planner' | 'memos'>(initialTab);

  // Summary State
  const [summaryTabType, setSummaryTabType] = useState<'ai' | 'custom'>('ai');
  const [summaryText, setSummaryText] = useState('');
  const [customSummaryText, setCustomSummaryText] = useState('');
  const [isSummarizing, setIsSummarizing] = useState(false);
  const [copiedSummary, setCopiedSummary] = useState(false);
  const [isAcademicPrintOpen, setIsAcademicPrintOpen] = useState(false);
  const [isAcademicPrintLoading, setIsAcademicPrintLoading] = useState(false);
  const [structuredSummaryData, setStructuredSummaryData] = useState<StructuredSummary | null>(null);

  // Quiz State
  const [quizQuestions, setQuizQuestions] = useState<QuizQuestion[]>([]);
  const [userAnswers, setUserAnswers] = useState<Record<string, string | number>>({});
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [isGeneratingQuiz, setIsGeneratingQuiz] = useState(false);

  // Flashcards Filter & Visualization Mode
  const [cardTab, setCardTab] = useState<'due' | 'all' | 'mistakes'>('due');
  const [flippedCardId, setFlippedCardId] = useState<string | null>(null);
  const [isGeneratingCards, setIsGeneratingCards] = useState(false);
  const [flashcardViewMode, setFlashcardViewMode] = useState<'cards' | 'dashboard'>('cards');

  // Mind Map State
  const [mindMapData, setMindMapData] = useState<any>(null);
  const [isGeneratingMindMap, setIsGeneratingMindMap] = useState(false);
  const [mindMapEngine, setMindMapEngine] = useState<'d3' | 'classic'>('d3');

  // Planner State
  const [planGoal, setPlanGoal] = useState('');
  const [planDays, setPlanDays] = useState(7);
  const [generatedPlan, setGeneratedPlan] = useState<StudyPlan | null>(null);
  const [isGeneratingPlan, setIsGeneratingPlan] = useState(false);

  // New Memo / Glossary state
  const [newMemoText, setNewMemoText] = useState('');
  const [newTerm, setNewTerm] = useState('');
  const [newDef, setNewDef] = useState('');
  const [newEx, setNewEx] = useState('');
  const [newTodoText, setNewTodoText] = useState('');

  // Notes Workspace Subtab & Management State
  const [notesSubTab, setNotesSubTab] = useState<'notes' | 'memos' | 'glossary'>('notes');
  const [notesSearch, setNotesSearch] = useState('');
  const [selectedTagFilter, setSelectedTagFilter] = useState<string>('all');
  const [isAddingNote, setIsAddingNote] = useState(false);
  const [newNoteTitle, setNewNoteTitle] = useState('');
  const [newNoteText, setNewNoteText] = useState('');
  const [newNoteTags, setNewNoteTags] = useState('');
  const [copiedNoteId, setCopiedNoteId] = useState<string | null>(null);
  const [isNotePreview, setIsNotePreview] = useState(false);
  const [isExportingPdf, setIsExportingPdf] = useState(false);
  const [isImageUrlModalOpen, setIsImageUrlModalOpen] = useState(false);
  const [imageUrlInput, setImageUrlInput] = useState('');
  const [imageCaptionInput, setImageCaptionInput] = useState('');
  const [activeExportNote, setActiveExportNote] = useState<{
    title: string;
    text: string;
    tags?: string[];
    createdAt?: string | number;
  } | null>(null);
  const [isColorPaletteOpen, setIsColorPaletteOpen] = useState(false);
  const [selectedFontColor, setSelectedFontColor] = useState('#ef4444');

  // Templates Dropdown State
  const [isTemplatesDropdownOpen, setIsTemplatesDropdownOpen] = useState(false);
  const [pendingTemplate, setPendingTemplate] = useState<NoteTemplateItem | null>(null);
  const [isTemplateConfirmOpen, setIsTemplateConfirmOpen] = useState(false);

  // LaTeX KaTeX Equation Builder State
  const [isMathModalOpen, setIsMathModalOpen] = useState(false);
  const [mathLatexInput, setMathLatexInput] = useState('E = mc^2');
  const [isMathDisplayBlock, setIsMathDisplayBlock] = useState(true);

  // Voice Recording & Reflection State (Speech-to-Text & Audio Capture)
  const [isVoiceModalOpen, setIsVoiceModalOpen] = useState(false);
  const [isRecordingVoice, setIsRecordingVoice] = useState(false);
  const [voiceTranscript, setVoiceTranscript] = useState('');
  const [interimTranscript, setInterimTranscript] = useState('');
  const [voiceDurationSeconds, setVoiceDurationSeconds] = useState(0);
  const [voiceReflectionTitle, setVoiceReflectionTitle] = useState('');
  const [isFormattingTranscript, setIsFormattingTranscript] = useState(false);
  const [isTranscribingWithGemini, setIsTranscribingWithGemini] = useState(false);
  const [recordedAudioUrl, setRecordedAudioUrl] = useState<string | null>(null);
  const [recordedAudioBlob, setRecordedAudioBlob] = useState<Blob | null>(null);
  const [recordedAudioMime, setRecordedAudioMime] = useState<string>('audio/webm');
  const [transcriptionError, setTranscriptionError] = useState<string>('');

  const recognitionRef = useRef<any>(null);
  const voiceTimerRef = useRef<any>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const mediaStreamRef = useRef<MediaStream | null>(null);

  // Clean up recording streams and timers
  const cleanupVoiceRecording = () => {
    if (voiceTimerRef.current) {
      clearInterval(voiceTimerRef.current);
      voiceTimerRef.current = null;
    }
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch {}
      recognitionRef.current = null;
    }
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      mediaStreamRef.current = null;
    }
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      try {
        mediaRecorderRef.current.stop();
      } catch {}
      mediaRecorderRef.current = null;
    }
  };

  const startVoiceRecording = async () => {
    setVoiceTranscript('');
    setInterimTranscript('');
    setVoiceDurationSeconds(0);
    setTranscriptionError('');
    if (recordedAudioUrl) {
      URL.revokeObjectURL(recordedAudioUrl);
      setRecordedAudioUrl(null);
    }
    audioChunksRef.current = [];

    const now = new Date();
    setVoiceReflectionTitle(`تأملات وعصف ذهني: ${now.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}`);

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaStreamRef.current = stream;

      let mimeType = 'audio/webm';
      if (typeof MediaRecorder !== 'undefined') {
        if (MediaRecorder.isTypeSupported('audio/webm;codecs=opus')) {
          mimeType = 'audio/webm;codecs=opus';
        } else if (MediaRecorder.isTypeSupported('audio/webm')) {
          mimeType = 'audio/webm';
        } else if (MediaRecorder.isTypeSupported('audio/mp4')) {
          mimeType = 'audio/mp4';
        } else if (MediaRecorder.isTypeSupported('audio/ogg')) {
          mimeType = 'audio/ogg';
        }
      }

      const recorder = new MediaRecorder(stream, mimeType ? { mimeType } : undefined);
      mediaRecorderRef.current = recorder;

      recorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      recorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: mimeType });
        const url = URL.createObjectURL(audioBlob);
        setRecordedAudioUrl(url);
        setRecordedAudioBlob(audioBlob);
        setRecordedAudioMime(mimeType);

        // Automatically trigger AI transcription with Gemini Audio API
        transcribeAudioBlobWithGemini(audioBlob, mimeType);
      };

      recorder.start(500);
      setIsRecordingVoice(true);

      // Start duration counter
      if (voiceTimerRef.current) clearInterval(voiceTimerRef.current);
      voiceTimerRef.current = setInterval(() => {
        setVoiceDurationSeconds((prev) => prev + 1);
      }, 1000);

      // In parallel: Run SpeechRecognition for live visual text preview if supported
      const SpeechRecognitionClass = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (SpeechRecognitionClass) {
        try {
          const recognition = new SpeechRecognitionClass();
          recognition.continuous = true;
          recognition.interimResults = true;
          recognition.lang = 'ar-SA';

          recognition.onresult = (event: any) => {
            let finalChunks = '';
            let currentInterim = '';
            for (let i = event.resultIndex; i < event.results.length; ++i) {
              if (event.results[i].isFinal) {
                finalChunks += event.results[i][0].transcript + ' ';
              } else {
                currentInterim += event.results[i][0].transcript;
              }
            }
            if (finalChunks) {
              setVoiceTranscript((prev) => (prev ? `${prev.trim()} ${finalChunks.trim()}` : finalChunks.trim()));
            }
            setInterimTranscript(currentInterim);
          };

          recognition.onerror = (e: any) => console.warn('SpeechRecognition warning:', e.error);
          recognition.start();
          recognitionRef.current = recognition;
        } catch (srErr) {
          console.warn('SpeechRecognition init warning:', srErr);
        }
      }
    } catch (err: any) {
      console.error('Microphone access failed:', err);
      setIsRecordingVoice(false);
      setTranscriptionError(err.message || 'تعذر تشغيل الميكروفون. يرجى التأكد من منح الإذن للمتصفح.');
    }
  };

  const stopVoiceRecording = () => {
    setIsRecordingVoice(false);
    if (voiceTimerRef.current) {
      clearInterval(voiceTimerRef.current);
      voiceTimerRef.current = null;
    }
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch {}
      recognitionRef.current = null;
    }
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      mediaStreamRef.current = null;
    }
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      mediaRecorderRef.current.stop();
    }
  };

  // Dedicated Gemini Audio Transcriber
  const transcribeAudioBlobWithGemini = async (blob: Blob, mimeType: string) => {
    if (!blob || blob.size === 0) return;
    setIsTranscribingWithGemini(true);
    setTranscriptionError('');
    try {
      const reader = new FileReader();
      const base64Promise = new Promise<string>((resolve, reject) => {
        reader.onloadend = () => resolve(reader.result as string);
        reader.onerror = reject;
      });
      reader.readAsDataURL(blob);
      const base64Audio = await base64Promise;

      const res = await fetch('/api/transcribe-audio', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          audioBase64: base64Audio,
          mimeType: mimeType.split(';')[0],
          fileName: `تسجيل ملاحظة - ${voiceReflectionTitle}`,
        }),
      });

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        throw new Error(errJson.error || `خطأ تفريغ (${res.status})`);
      }

      const data = await res.json();
      if (data && data.text) {
        setVoiceTranscript(data.text.trim());
      }
    } catch (err: any) {
      console.warn('Gemini audio transcription fallback:', err);
      setTranscriptionError('تعذر التفريغ التلقائي عبر الذكاء الاصطناعي، تم الاحتفاظ بالنص المسجل محلياً.');
    } finally {
      setIsTranscribingWithGemini(false);
    }
  };

  const handleSaveVoiceAsNote = () => {
    const fullText = (voiceTranscript + (interimTranscript ? ` ${interimTranscript}` : '')).trim();
    if (!fullText) {
      alert('لم يتم تسجيل أو تفريغ أي كلمات لتحويلها إلى تدوينة نصية.');
      return;
    }

    const finalTitle = voiceReflectionTitle.trim() || `عصف ذهني وتأملات: ${new Date().toLocaleDateString('ar-EG')}`;
    const structuredNote = `# 🎙️ ${finalTitle}\n\n**تاريخ التسجيل:** ${new Date().toLocaleString('ar-EG')}\n**مدة التسجيل:** ${Math.floor(voiceDurationSeconds / 60)} دقيقة و ${voiceDurationSeconds % 60} ثانية\n\n---\n\n### 💡 نص التسجيل المفرغ بالذكاء الاصطناعي:\n${fullText}`;

    // 1. Save as comprehensive Note
    if (onAddNote) {
      onAddNote(finalTitle, structuredNote, ['عصف_ذهني_صوتي', 'تسجيلات_صوتية', 'تأملات']);
    } else {
      setNewNoteTitle(finalTitle);
      setNewNoteText(structuredNote);
      setNewNoteTags('عصف_ذهني_صوتي, تأملات');
      setIsAddingNote(true);
    }

    // 2. Also save as MemoItem in current notebook
    if (onAddMemo) {
      onAddMemo(`🎙️ ${finalTitle}:\n${fullText.slice(0, 200)}${fullText.length > 200 ? '...' : ''}`);
    }

    setIsVoiceModalOpen(false);
    cleanupVoiceRecording();
  };

  const handleFormatVoiceTranscriptWithAI = async () => {
    const fullText = (voiceTranscript + (interimTranscript ? ` ${interimTranscript}` : '')).trim();
    if (!fullText) return;
    setIsFormattingTranscript(true);
    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: `لديك النص التالي المفرغ من جلسة عصف ذهني وتأملات شفهية لطالب:\n"""\n${fullText}\n"""\nالمطلوب: قم بإعادة صياغة وتنظيم وهيكلة هذه الأفكار في تدوينة دراسية أكاديمية منظمة بأسلوب Markdown، تحتوي على:\n1. عنوان رئيسي ذكي\n2. الأفكار المحورية (نقاط واضحة)\n3. التحليل والتفصيل\n4. التوصيات والخطوات القادمة للمذاكرة\nابدأ مباشرة بالنص المنظم بدون مقدمات.`,
          fallbackConfig,
        }),
      });
      const data = await res.json();
      if (data.text) {
        setVoiceTranscript(data.text.trim());
      }
    } catch (e) {
      console.warn('Failed to format transcript with AI:', e);
    } finally {
      setIsFormattingTranscript(false);
    }
  };

  const noteTextareaRef = useRef<HTMLTextAreaElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const fileImageInputRef = useRef<HTMLInputElement>(null);
  const printableNoteRef = useRef<HTMLDivElement>(null);

  // Compress image to prevent huge base64 strings and keep UI reactive
  const compressImageFile = (file: File, maxWidth = 1200, maxHeight = 1200, quality = 0.85): Promise<string> => {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new window.Image();
        img.onload = () => {
          let { width, height } = img;
          if (width > maxWidth || height > maxHeight) {
            if (width / height > maxWidth / maxHeight) {
              height = Math.round((height * maxWidth) / width);
              width = maxWidth;
            } else {
              width = Math.round((width * maxHeight) / height);
              height = maxHeight;
            }
          }
          const canvas = document.createElement('canvas');
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (!ctx) {
            resolve(e.target?.result as string);
            return;
          }
          ctx.drawImage(img, 0, 0, width, height);
          const dataUrl = canvas.toDataURL('image/jpeg', quality);
          resolve(dataUrl);
        };
        img.onerror = () => resolve(e.target?.result as string);
        img.src = e.target?.result as string;
      };
      reader.onerror = () => resolve('');
      reader.readAsDataURL(file);
    });
  };

  // Insert image markdown into note at cursor position
  const insertImageMarkdown = (url: string, altText?: string) => {
    const textarea = noteTextareaRef.current;
    const currentText = newNoteText;
    const cleanAlt = (altText || '').trim() || 'صورة توضيحية';
    const imageMarkdown = `\n![${cleanAlt}](${url.trim()})\n`;

    if (!textarea) {
      setNewNoteText((prev) => prev ? `${prev}${imageMarkdown}` : imageMarkdown.trimStart());
      return;
    }

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const updated = currentText.substring(0, start) + imageMarkdown + currentText.substring(end);
    setNewNoteText(updated);

    setTimeout(() => {
      textarea.focus();
      const nextPos = start + imageMarkdown.length;
      textarea.setSelectionRange(nextPos, nextPos);
    }, 0);
  };

  const handleImageFileChange = async (e: React.ChangeEvent<HTMLInputElement>, source: 'camera' | 'upload') => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;
    e.target.value = '';

    for (const file of files) {
      try {
        if (file.type.startsWith('image/') || /\.(png|jpe?g|webp|bmp)$/i.test(file.name)) {
          const compressed = await compressImageFile(file, 1200, 1200, 0.82);
          if (compressed) {
            const caption = source === 'camera' ? 'صورة دراسية' : file.name.replace(/\.[^/.]+$/, '');
            insertImageMarkdown(compressed, caption);
          }
        } else if (file.type.startsWith('audio/') || /\.(mp3|wav|m4a|ogg|aac|webm|flac|amr)$/i.test(file.name)) {
          // Audio Ingestion via Speech-to-Text
          const arrayBuffer = await file.arrayBuffer();
          const bytes = new Uint8Array(arrayBuffer);
          let binary = '';
          const len = bytes.byteLength;
          for (let i = 0; i < len; i += 32768) {
            binary += String.fromCharCode.apply(null, Array.from(bytes.subarray(i, Math.min(i + 32768, len))));
          }
          const base64Audio = btoa(binary);

          const transcribeRes = await fetch('/api/transcribe-audio', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              audioBase64: base64Audio,
              mimeType: file.type || 'audio/mp3',
              fileName: file.name,
            }),
          });

          if (transcribeRes.ok) {
            const trData = await transcribeRes.json();
            const textToInsert = `\n\n### 🎙️ تفريغ صوتي: ${file.name}\n${trData.text}\n\n`;
            setNewNoteText((prev) => `${prev}${textToInsert}`.trimStart());
          }
        } else if (file.name.endsWith('.docx')) {
          const arrayBuffer = await file.arrayBuffer();
          const mammothModule = await import('mammoth');
          const mammoth = (mammothModule as any).default || mammothModule;
          const docxResult = await mammoth.extractRawText({ arrayBuffer });
          const textToInsert = `\n\n### 📄 مستند Word: ${file.name}\n${docxResult.value}\n\n`;
          setNewNoteText((prev) => `${prev}${textToInsert}`.trimStart());
        } else if (file.type === 'application/pdf' || file.name.endsWith('.pdf')) {
          const pdfRes = await extractTextFromPDF(file);
          const textToInsert = `\n\n### 📑 مقتطفات من PDF: ${file.name}\n${pdfRes.fullText.slice(0, 5000)}\n\n`;
          setNewNoteText((prev) => `${prev}${textToInsert}`.trimStart());
        } else {
          // Plain text / Markdown
          const text = await file.text();
          const textToInsert = `\n\n### 📝 مستند: ${file.name}\n${text}\n\n`;
          setNewNoteText((prev) => `${prev}${textToInsert}`.trimStart());
        }
      } catch (err) {
        console.error('File processing failed:', err);
      }
    }
  };

  const handleExportNotePdf = async (customNote?: { title: string; text: string; tags?: string[]; createdAt?: string | number }) => {
    const target = customNote || {
      title: newNoteTitle.trim() || 'تدوينة دراسية',
      text: newNoteText,
      tags: newNoteTags.split(',').map((t) => t.trim()).filter(Boolean),
      createdAt: new Date().toISOString(),
    };

    if (!target.text.trim()) {
      alert('يرجى كتابة محتوى للملاحظة أولاً قبل التصدير كملف PDF.');
      return;
    }

    setIsExportingPdf(true);
    setActiveExportNote(target);

    // Wait for React to render printable container
    setTimeout(async () => {
      try {
        if (printableNoteRef.current) {
          const safeFilename = `ملاحظة_${target.title.replace(/[\\/*?:"<>|]/g, '_')}.pdf`;
          await exportNoteToPdf(printableNoteRef.current, safeFilename);
        }
      } catch (err) {
        console.error('Error generating note PDF with jsPDF:', err);
      } finally {
        setIsExportingPdf(false);
        setActiveExportNote(null);
      }
    }, 250);
  };

  // WYSIWYG Markdown Formatting Handler for Study Notes
  const applyNoteFormatting = (formatType: 'bold' | 'italic' | 'heading' | 'bullet' | 'ordered' | 'quote' | 'code' | 'codeblock') => {
    const textarea = noteTextareaRef.current;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const currentText = newNoteText;
    const selected = currentText.substring(start, end);

    let replacement = '';
    let newStart = start;
    let newEnd = end;

    switch (formatType) {
      case 'bold': {
        const target = selected || 'نص غامق';
        replacement = `**${target}**`;
        newStart = start + 2;
        newEnd = newStart + target.length;
        break;
      }
      case 'italic': {
        const target = selected || 'نص مائل';
        replacement = `*${target}*`;
        newStart = start + 1;
        newEnd = newStart + target.length;
        break;
      }
      case 'heading': {
        const target = selected || 'عنوان فرعي';
        const needsNewline = start > 0 && currentText[start - 1] !== '\n' ? '\n' : '';
        replacement = `${needsNewline}### ${target}\n`;
        newStart = start + needsNewline.length + 4;
        newEnd = newStart + target.length;
        break;
      }
      case 'bullet': {
        if (selected) {
          const lines = selected.split('\n');
          replacement = lines
            .map((line) => (line.trim().startsWith('• ') || line.trim().startsWith('- ') ? line : `• ${line}`))
            .join('\n');
          newStart = start;
          newEnd = start + replacement.length;
        } else {
          const needsNewline = start > 0 && currentText[start - 1] !== '\n' ? '\n' : '';
          replacement = `${needsNewline}• عنصر قائمة`;
          newStart = start + needsNewline.length + 2;
          newEnd = newStart + 'عنصر قائمة'.length;
        }
        break;
      }
      case 'ordered': {
        if (selected) {
          const lines = selected.split('\n');
          replacement = lines
            .map((line, idx) => (line.trim().match(/^\d+\.\s/) ? line : `${idx + 1}. ${line}`))
            .join('\n');
          newStart = start;
          newEnd = start + replacement.length;
        } else {
          const needsNewline = start > 0 && currentText[start - 1] !== '\n' ? '\n' : '';
          replacement = `${needsNewline}1. خطوة أولى`;
          newStart = start + needsNewline.length + 3;
          newEnd = newStart + 'خطوة أولى'.length;
        }
        break;
      }
      case 'quote': {
        if (selected) {
          const lines = selected.split('\n');
          replacement = lines
            .map((line) => (line.trim().startsWith('> ') ? line : `> ${line}`))
            .join('\n');
          newStart = start;
          newEnd = start + replacement.length;
        } else {
          const needsNewline = start > 0 && currentText[start - 1] !== '\n' ? '\n' : '';
          replacement = `${needsNewline}> قاعدة أو قانون دراسي`;
          newStart = start + needsNewline.length + 2;
          newEnd = newStart + 'قاعدة أو قانون دراسي'.length;
        }
        break;
      }
      case 'code': {
        const target = selected || 'صيغة أو رمز';
        replacement = `\`${target}\``;
        newStart = start + 1;
        newEnd = newStart + target.length;
        break;
      }
      case 'codeblock': {
        const target = selected || '# مقتطف برمجي دراسي\ndef calculate(x, y):\n    return x + y';
        const needsNewlineBefore = start > 0 && currentText[start - 1] !== '\n' ? '\n' : '';
        const needsNewlineAfter = end < currentText.length && currentText[end] !== '\n' ? '\n' : '';
        replacement = `${needsNewlineBefore}\`\`\`python\n${target}\n\`\`\`${needsNewlineAfter}`;
        newStart = start + needsNewlineBefore.length + 10;
        newEnd = newStart + target.length;
        break;
      }
    }

    const updated = currentText.substring(0, start) + replacement + currentText.substring(end);
    setNewNoteText(updated);

    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(newStart, newEnd);
    }, 0);
  };

  // Font Color tool handler for highlighting educational text with colors
  const applyFontColor = (colorHex: string) => {
    setSelectedFontColor(colorHex);
    const textarea = noteTextareaRef.current;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const currentText = newNoteText;
    const selected = currentText.substring(start, end);

    const target = selected || 'نص ملون';
    const tagOpen = `<span style="color: ${colorHex}; font-weight: 600;">`;
    const tagClose = '</span>';
    const replacement = `${tagOpen}${target}${tagClose}`;

    const newStart = start + tagOpen.length;
    const newEnd = newStart + target.length;

    const updated = currentText.substring(0, start) + replacement + currentText.substring(end);
    setNewNoteText(updated);
    setIsColorPaletteOpen(false);

    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(newStart, newEnd);
    }, 0);
  };

  // Templates Selection Handler
  const handleSelectTemplate = (template: NoteTemplateItem) => {
    setIsTemplatesDropdownOpen(false);
    if (!newNoteText.trim()) {
      if (!newNoteTitle.trim()) {
        setNewNoteTitle(template.suggestedTitle);
      }
      setNewNoteText(template.content);
    } else {
      setPendingTemplate(template);
      setIsTemplateConfirmOpen(true);
    }
  };

  const handleApplyPendingTemplate = (mode: 'replace' | 'append') => {
    if (!pendingTemplate) return;
    if (mode === 'replace') {
      setNewNoteText(pendingTemplate.content);
      if (!newNoteTitle.trim() || newNoteTitle === 'ملاحظة جديدة') {
        setNewNoteTitle(pendingTemplate.suggestedTitle);
      }
    } else {
      setNewNoteText((prev) => `${prev.trim()}\n\n---\n\n${pendingTemplate.content}`);
    }
    setPendingTemplate(null);
    setIsTemplateConfirmOpen(false);
  };

  // KaTeX Equation Helper
  const renderKaTeXHtml = (latex: string, displayMode: boolean): string => {
    try {
      const clean = (latex || '').trim();
      if (!clean) return '<span class="text-gray-400 italic text-xs">اكتب صيغة LaTeX أو اختر من النماذج أدناه...</span>';
      return katex.renderToString(clean, {
        displayMode,
        throwOnError: false,
      });
    } catch (e: any) {
      return `<span class="text-rose-500 font-mono text-xs">صيغة رياضية غير مكتملة: ${e?.message || ''}</span>`;
    }
  };

  const insertLatexToNote = (latex: string, isBlock: boolean) => {
    const clean = latex.trim();
    if (!clean) return;
    const formatted = isBlock ? `\n$$\n${clean}\n$$\n` : ` $${clean}$ `;

    const textarea = noteTextareaRef.current;
    if (!textarea) {
      setNewNoteText((prev) => (prev ? `${prev}${formatted}` : formatted.trimStart()));
      setIsMathModalOpen(false);
      return;
    }

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const currentText = newNoteText;
    const updated = currentText.substring(0, start) + formatted + currentText.substring(end);
    setNewNoteText(updated);
    setIsMathModalOpen(false);

    setTimeout(() => {
      textarea.focus();
      const nextPos = start + formatted.length;
      textarea.setSelectionRange(nextPos, nextPos);
    }, 0);
  };

  const handleNoteTextKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'b') {
      e.preventDefault();
      applyNoteFormatting('bold');
    } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'i') {
      e.preventDefault();
      applyNoteFormatting('italic');
    }
  };

  // Extract all text for context
  const getCombinedSourceText = () => {
    return sources.map((s) => `### ${s.title}\n${s.content.slice(0, 15000)}`).join('\n\n');
  };

  // Comprehensive Notebook Context for accurate concept extraction
  const getComprehensiveNotebookContext = () => {
    const parts: string[] = [];

    // 1. Sources text
    const sourcesText = sources.map((s) => `### المصدر: ${s.title}\n${s.content.slice(0, 12000)}`).join('\n\n');
    if (sourcesText.trim()) {
      parts.push(`## المصادر والوثائق الدراسية المعتمدة بالدفتر:\n${sourcesText}`);
    }

    // 2. Glossary terms (definitions and concepts)
    if (glossary.length > 0) {
      const glossaryText = glossary.map((g) => `- **${g.term}**: ${g.def}${g.ex ? ` (مثال: ${g.ex})` : ''}`).join('\n');
      parts.push(`## معجم المصطلحات والمفاهيم المحورية (Glossary):\n${glossaryText}`);
    }

    // 3. Memos and notes
    if (memos.length > 0) {
      const memosText = memos.map((m) => `- ${m.text}`).join('\n');
      parts.push(`## الملاحظات والتدوينات الدراسية السريعة (Study Memos):\n${memosText}`);
    }

    // 4. Student Notes
    if (notes && notes.length > 0) {
      const notesText = notes.map((n) => `- **${n.title}**: ${n.text}${n.goal ? ` (الهدف: ${n.goal})` : ''}`).join('\n');
      parts.push(`## تدوينات وملاحظات الطالب بالدفتر (Student Notes):\n${notesText}`);
    }

    // 5. Existing summaries
    const activeSummary = summaryText || customSummaryText;
    if (activeSummary.trim()) {
      parts.push(`## الملخص الأكاديمي الحالي للدفتر:\n${activeSummary.slice(0, 4000)}`);
    }

    return parts.join('\n\n');
  };

  // 1. Generate Comprehensive Summary
  const handleGenerateSummary = async (formatType = 'comprehensive') => {
    setIsSummarizing(true);
    try {
      const summary = await generateStudioSummary({
        notebookTitle: notebookTitle || 'ملخص دراسي شامل',
        notebookSubject: notebookSubject || 'المنهج الدراسي',
        sources,
        notes,
        memos,
        glossary,
        fallbackConfig,
      });
      const enforced = preprocessAndEnforceAcademicSchema(summary, {
        notebookName: notebookTitle || 'ملخص دراسي شامل',
        subject: notebookSubject || 'المنهج الدراسي',
      });
      setSummaryText(enforced || summary || 'فشل التوليد.');
    } catch (e: any) {
      setSummaryText('حدث خطأ: ' + (e.message || e));
    } finally {
      setIsSummarizing(false);
    }
  };

  const handleOpenAcademicPrint = async () => {
    const currentText = summaryTabType === 'ai' ? summaryText : customSummaryText;
    if (!currentText.trim()) {
      alert('لا يوجد محتوى للطباعة بعد. يرجى توليد ملخص أو كتابة محتوى أولاً.');
      return;
    }
    setIsAcademicPrintOpen(true);
    setIsAcademicPrintLoading(true);
    setStructuredSummaryData(null);
    try {
      const structured = await generateIntelligentAcademicSummary(
        currentText,
        notebookTitle || 'ملخص دراسي شامل ومنظم',
        notebookSubject || 'دليل مراجعة أكاديمي'
      );
      setStructuredSummaryData(structured);
    } catch (e) {
      console.error('Failed to generate intelligent summary:', e);
      const fallback = extractStructuredSummary(
        currentText,
        notebookTitle || 'ملخص دراسي شامل ومنظم',
        notebookSubject || 'دليل مراجعة أكاديمي'
      );
      setStructuredSummaryData(fallback);
    } finally {
      setIsAcademicPrintLoading(false);
    }
  };

  // 2. Generate Interactive Quiz
  const handleGenerateQuiz = async () => {
    setIsGeneratingQuiz(true);
    setQuizSubmitted(false);
    setUserAnswers({});

    try {
      const questions = await generateStudioQuiz(
        {
          notebookTitle: notebookTitle || 'اختبار دراسي',
          notebookSubject: notebookSubject || 'المنهج الدراسي',
          sources,
          notes,
          memos,
          glossary,
          fallbackConfig,
        },
        6
      );
      setQuizQuestions(questions);
    } catch (e: any) {
      console.error(e);
      alert(`فشل إنشاء الاختبار: ${e.message || 'يرجى المحاولة مجددًا'}`);
    } finally {
      setIsGeneratingQuiz(false);
    }
  };

  // 3. Generate Flashcards
  const handleGenerateFlashcards = async () => {
    setIsGeneratingCards(true);
    try {
      const newCards = await generateStudioFlashcards(
        {
          notebookTitle: notebookTitle || 'بطاقات دراسية',
          notebookSubject: notebookSubject || 'المنهج الدراسي',
          sources,
          notes,
          memos,
          glossary,
          fallbackConfig,
        },
        8
      );
      onAddFlashcards(newCards);
    } catch (e: any) {
      console.error(e);
      alert(`تعذر إنشاء البطاقات: ${e.message || 'يرجى المحاولة مجددًا'}`);
    } finally {
      setIsGeneratingCards(false);
    }
  };

  // 4. Generate Hierarchical Main Concepts Tree from Notebook Context
  const handleGenerateMindMap = async () => {
    setIsGeneratingMindMap(true);
    try {
      const rootNode = await generateStudioMindMapData({
        notebookTitle: notebookTitle || 'الفكرة المركزية للدراسة',
        notebookSubject: notebookSubject || 'شجرة المفاهيم الأساسية',
        sources,
        notes,
        memos,
        glossary,
        fallbackConfig,
      });

      setMindMapData(rootNode);

      // Format structured academic summary immediately
      const summary = mindMapToStructuredSummary(
        rootNode,
        notebookTitle || 'الدفتر الأكاديمي',
        notebookSubject || 'شجرة المفاهيم الأساسية والدليل الدراسي'
      );
      setStructuredSummaryData(summary);
    } catch (e) {
      console.error(e);
      alert('تعذر توليد شجرة المفاهيم التلقائية. يرجى التأكد من مصادر الدفتر وإعادة المحاولة.');
    } finally {
      setIsGeneratingMindMap(false);
    }
  };


  // Export Mind Map tree as academic report PDF
  const handleExportMindMapPdf = () => {
    const currentData = mindMapData || {
      id: 'root',
      title: notebookTitle || 'الفكرة المركزية للدراسة',
      notes: 'دليل دراسي أكاديمي شامل يربط المفاهيم الأساسية والمحاور العلمية المستخلصة من الدفتر.',
      level: 0,
      color: '#0f766e',
      children: [
        {
          id: 'b1',
          title: 'المحور الأول: المفاهيم والتعاريف التأسيسية',
          level: 1,
          badge: 'مفهوم رئيسي',
          color: '#0f766e',
          notes: 'تأصيل المصطلحات والمبادئ الجوهرية في المنهج الدراسي.',
          children: [
            { id: 'b1-1', title: 'التعريف العلمي الدقيق', level: 2, badge: 'تعريف', color: '#0f766e' },
            { id: 'b1-2', title: 'الخصائص والمحددات', level: 2, badge: 'خاصية', color: '#0f766e' },
          ]
        },
        {
          id: 'b2',
          title: 'المحور الثاني: القوانين والمعادلات والتطبيقات',
          level: 1,
          badge: 'قوانين ونماذج',
          color: '#0284c7',
          notes: 'العلاقات الرياضية والنماذج التحليلية للموضوع.',
          children: [
            { id: 'b2-1', title: 'العلاقة التناسبية والصيغة', level: 2, badge: 'قانون', color: '#0284c7' },
            { id: 'b2-2', title: 'التطبيقات والمسائل المحلولة', level: 2, badge: 'تطبيق', color: '#0284c7' },
          ]
        }
      ]
    };
    const summary = mindMapToStructuredSummary(
      currentData,
      notebookTitle || 'الدفتر الأكاديمي',
      notebookSubject || 'دليل دراسي - شجرة المفاهيم'
    );
    setStructuredSummaryData(summary);
    setIsAcademicPrintOpen(true);
  };

  // Filtered flashcards with smart mistake prioritization
  const filteredCards = useMemo(() => {
    const list = flashcards.filter((c) => {
      if (cardTab === 'due') return (c.nextReview || 0) <= Date.now();
      if (cardTab === 'mistakes') return c.mistake;
      return true;
    });

    // Prioritize cards with the 'mistake' flag, then by earliest nextReview timestamp
    return list.sort((a, b) => {
      if (a.mistake && !b.mistake) return -1;
      if (!a.mistake && b.mistake) return 1;
      return (a.nextReview || 0) - (b.nextReview || 0);
    });
  }, [flashcards, cardTab]);

  const dueFlashcards = useMemo(() => {
    return flashcards.filter((c) => (c.nextReview || 0) <= Date.now());
  }, [flashcards]);

  const dueMistakeCount = useMemo(() => {
    return dueFlashcards.filter((c) => c.mistake).length;
  }, [dueFlashcards]);

  return (
    <div className="space-y-5">
      {/* Studio Header & Tab Navigation */}
      <div className="bg-white dark:bg-[#14201c] rounded-2xl border border-[#e2e8e5] dark:border-[#22352f] p-4 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
          <div>
            <h2 className="text-lg font-bold text-[#17201e] dark:text-[#eef7f4] flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-[#0f766e] dark:text-[#2dd4bf]" />
              <span>أدوات الدراسة والتحليل الذكية</span>
            </h2>
            <p className="text-xs text-[#596762] dark:text-[#9ab3ab] mt-0.5">
              حوّل وثائقك ومصادرك إلى ملخصات، اختبارات تفاعلية، بطاقات استرجاع، وخرائط ذهنية تلقائيًا.
            </p>
          </div>
        </div>

        {/* Smooth Horizontal Scrollable Tab Pills Strip */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar border-b border-[#e2e8e5] dark:border-[#22352f] pb-3 -mx-1 px-1 touch-pan-x">
          <button
            onClick={() => setActiveTab('summary')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shrink-0 cursor-pointer ${
              activeTab === 'summary'
                ? 'bg-[#0f766e] text-white shadow-xs'
                : 'bg-[#f6f8f7] dark:bg-[#1a2723] text-[#596762] dark:text-[#9ab3ab] hover:text-[#0f766e]'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>ملخص ودليل دراسة</span>
          </button>

          <button
            onClick={() => setActiveTab('quiz')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shrink-0 cursor-pointer ${
              activeTab === 'quiz'
                ? 'bg-[#0f766e] text-white shadow-xs'
                : 'bg-[#f6f8f7] dark:bg-[#1a2723] text-[#596762] dark:text-[#9ab3ab] hover:text-[#0f766e]'
            }`}
          >
            <HelpCircle className="w-3.5 h-3.5" />
            <span>اختبارات تفاعلية</span>
          </button>

          <button
            onClick={() => setActiveTab('cards')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shrink-0 cursor-pointer ${
              activeTab === 'cards'
                ? 'bg-[#0f766e] text-white shadow-xs'
                : 'bg-[#f6f8f7] dark:bg-[#1a2723] text-[#596762] dark:text-[#9ab3ab] hover:text-[#0f766e]'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>بطاقات استرجاع</span>
          </button>

          <button
            onClick={() => setActiveTab('progress')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shrink-0 cursor-pointer ${
              activeTab === 'progress'
                ? 'bg-[#0f766e] text-white shadow-xs'
                : 'bg-[#f6f8f7] dark:bg-[#1a2723] text-[#596762] dark:text-[#9ab3ab] hover:text-[#0f766e]'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5" />
            <span>لوحة الإتقان</span>
          </button>

          <button
            onClick={() => setActiveTab('mindmap')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shrink-0 cursor-pointer ${
              activeTab === 'mindmap'
                ? 'bg-[#0f766e] text-white shadow-xs'
                : 'bg-[#f6f8f7] dark:bg-[#1a2723] text-[#596762] dark:text-[#9ab3ab] hover:text-[#0f766e]'
            }`}
          >
            <GitFork className="w-3.5 h-3.5" />
            <span>خريطة المفاهيم</span>
          </button>

          <button
            onClick={() => setActiveTab('planner')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 relative shrink-0 cursor-pointer ${
              activeTab === 'planner'
                ? 'bg-[#0f766e] text-white shadow-xs'
                : 'bg-[#f6f8f7] dark:bg-[#1a2723] text-[#596762] dark:text-[#9ab3ab] hover:text-[#0f766e]'
            }`}
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>خطة المذاكرة</span>
            {approachingTasks.length > 0 && (
              <span className="flex items-center justify-center min-w-[18px] h-[18px] px-1 bg-rose-500 text-white rounded-full text-[10px] font-black animate-pulse shadow-xs">
                {approachingTasks.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('memos')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shrink-0 cursor-pointer ${
              activeTab === 'memos'
                ? 'bg-[#0f766e] text-white shadow-xs'
                : 'bg-[#f6f8f7] dark:bg-[#1a2723] text-[#596762] dark:text-[#9ab3ab] hover:text-[#0f766e]'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>دفتر الملاحظات والمعجم ({notes.length + memos.length})</span>
          </button>
        </div>

        {/* In-App Visual Alert Banner for Approaching Task Due Dates */}
        {approachingTasks.length > 0 && (
          <div className="mt-3 p-3.5 bg-gradient-to-r from-amber-500/10 via-rose-500/10 to-amber-500/5 dark:from-amber-950/40 dark:via-rose-950/30 dark:to-transparent border-2 border-amber-300 dark:border-amber-700/60 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs animate-in fade-in slide-in-from-top-2 shadow-xs">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-amber-500 text-white flex items-center justify-center shrink-0 shadow-sm animate-bounce">
                <Bell className="w-4 h-4" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-black text-amber-900 dark:text-amber-200">
                    تنبيه استحقاق المهام الأكاديمية ({approachingTasks.length})
                  </span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800">
                    موعد قريب / متأخرة
                  </span>
                </div>
                <div className="text-[11px] text-amber-800/90 dark:text-amber-300/90 mt-0.5">
                  أقرب مهمة: «<strong>{approachingTasks[0].text}</strong>» {approachingTasks[0].dueTime ? `(الساعة: ${approachingTasks[0].dueTime})` : ''}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 self-end sm:self-auto shrink-0">
              <button
                type="button"
                onClick={() => onToggleTodo(approachingTasks[0].id)}
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold text-xs flex items-center gap-1 transition-colors cursor-pointer shadow-xs"
              >
                <Check className="w-3.5 h-3.5" />
                <span>إنجاز الآن</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('planner')}
                className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl font-bold text-xs transition-colors cursor-pointer"
              >
                عرض كل المهام
              </button>

              <button
                type="button"
                onClick={() => setDismissedAlertIds((prev) => [...prev, ...approachingTasks.map((t: TodoItem) => t.id)])}
                className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors cursor-pointer"
                title="تجاهل التنبيه مؤقتاً"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* 1. Summary Tab */}
      {activeTab === 'summary' && (
        <div className="bg-white dark:bg-[#14201c] rounded-2xl border border-[#e2e8e5] dark:border-[#22352f] p-6 shadow-sm space-y-5">
          {/* Sub-tabs: AI Summary vs Custom Summary */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#e2e8e5] dark:border-[#22352f]">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setSummaryTabType('ai')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  summaryTabType === 'ai'
                    ? 'bg-[#0f766e] text-white shadow-sm'
                    : 'bg-[#f6f8f7] dark:bg-[#1a2723] text-[#596762] dark:text-[#9ab3ab] hover:text-[#0f766e]'
                }`}
              >
                ✨ ملخص المصادر التلقائي (AI)
              </button>
              <button
                type="button"
                onClick={() => setSummaryTabType('custom')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  summaryTabType === 'custom'
                    ? 'bg-[#0f766e] text-white shadow-sm'
                    : 'bg-[#f6f8f7] dark:bg-[#1a2723] text-[#596762] dark:text-[#9ab3ab] hover:text-[#0f766e]'
                }`}
              >
                ✍️ ملخصي ومعلوماتي الخاصة (نص حر للطباعة)
              </button>
            </div>

            {/* Print / Action Buttons */}
            <div className="flex items-center gap-2">
              {((summaryTabType === 'ai' && summaryText) || (summaryTabType === 'custom' && customSummaryText)) && (
                <>
                  <button
                    type="button"
                    onClick={() => {
                      const textToSpeak = summaryTabType === 'ai' ? summaryText : customSummaryText;
                      studySpeechEngine.speak(textToSpeak, notebookTitle ? `ملخص ${notebookTitle}` : 'ملخص المذاكرة الذكي');
                    }}
                    className="px-3 py-1.5 bg-teal-50 dark:bg-teal-950/80 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-800/80 rounded-xl text-xs font-bold hover:bg-teal-100 dark:hover:bg-teal-900 flex items-center gap-1.5 transition cursor-pointer shadow-2xs"
                    title="الاستماع للملخص صوتياً (TTS) مع خيارات التحكم بالسرعة"
                  >
                    <Volume2 className="w-3.5 h-3.5" />
                    <span>قراءة صوتية (TTS)</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const textToCopy = summaryTabType === 'ai' ? summaryText : customSummaryText;
                      navigator.clipboard.writeText(textToCopy);
                      setCopiedSummary(true);
                      setTimeout(() => setCopiedSummary(false), 2000);
                    }}
                    className="px-3 py-1.5 border border-[#e2e8e5] dark:border-[#22352f] rounded-xl text-xs font-bold text-[#596762] dark:text-[#9ab3ab] hover:bg-gray-50 dark:hover:bg-gray-800 flex items-center gap-1.5"
                  >
                    {copiedSummary ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedSummary ? 'تم النسخ!' : 'نسخ'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleOpenAcademicPrint}
                    className="px-3.5 py-1.5 bg-[#0f766e] text-white rounded-xl text-xs font-bold hover:bg-[#115e59] flex items-center gap-1.5 shadow-sm cursor-pointer"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>تصدير PDF أكاديمي احترافي</span>
                  </button>
                </>
              )}

              {summaryTabType === 'ai' && (
                <button
                  onClick={() => handleGenerateSummary()}
                  disabled={isSummarizing}
                  className="px-4 py-1.5 bg-[#0f766e] text-white rounded-xl text-xs font-bold hover:bg-[#115e59] flex items-center gap-2"
                >
                  {isSummarizing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                  <span>توليد ملخص جديد</span>
                </button>
              )}
            </div>
          </div>

          {/* AI Summary View */}
          {summaryTabType === 'ai' && (
            <div>
              {summaryText ? (
                <div className="space-y-3">
                  <div className="p-5 bg-[#f8fbfa] dark:bg-[#121b18] border border-[#e2e8e5] dark:border-[#22352f] rounded-2xl text-xs sm:text-sm leading-relaxed font-sans text-[#17201e] dark:text-[#eef7f4]">
                    <EducationalContent content={summaryText} />
                  </div>
                  <div className="flex items-center justify-between text-xs text-[#596762] dark:text-[#9ab3ab] pt-2">
                    <span>💡 يمكنك نقل هذا الملخص إلى ملخصك الخاص للتعديل عليه وإضافة معلومات إضافية.</span>
                    <button
                      type="button"
                      onClick={() => {
                        setCustomSummaryText(summaryText);
                        setSummaryTabType('custom');
                      }}
                      className="text-[#0f766e] dark:text-[#2dd4bf] font-bold hover:underline flex items-center gap-1"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      <span>تعديل في ملخصي الخاص</span>
                    </button>
                  </div>
                </div>
              ) : (
                <div className="p-10 border border-dashed border-[#e2e8e5] dark:border-[#22352f] rounded-2xl text-center text-xs text-[#596762] dark:text-[#9ab3ab] space-y-2">
                  <p>اضغط على «توليد ملخص جديد» لاستخراج ملخص دراسي مفصل من مصادر الدفتر.</p>
                  <p className="text-[11px] text-gray-400">أو انقر على تبويب «ملخصي ومعلوماتي الخاصة» لكتابة ملخصك بنفسك وطباعته مباشرة.</p>
                </div>
              )}
            </div>
          )}

          {/* Custom Summary & Notes View */}
          {summaryTabType === 'custom' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-xs sm:text-sm text-[#17201e] dark:text-[#eef7f4]">
                    محرر ملخصك ومعلوماتك الخاصة
                  </h4>
                  <p className="text-xs text-[#596762] dark:text-[#9ab3ab]">
                    اكتب أو الصق هنا أي ملخص، معلومات دراسية، قوانين، أو تنبيهات، واطبعها بصيغة PDF أنيقة.
                  </p>
                </div>

                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      if (!customSummaryText.trim()) {
                        alert('يرجى إدخال محتوى في المحرر أولاً.');
                        return;
                      }
                      const formatted = preprocessAndEnforceAcademicSchema(customSummaryText, {
                        notebookName: notebookTitle,
                        subject: notebookSubject,
                      });
                      setCustomSummaryText(formatted);
                    }}
                    className="px-3 py-1.5 border border-teal-200 dark:border-teal-800 bg-teal-50 dark:bg-teal-950/40 rounded-xl text-xs font-bold text-[#0f766e] dark:text-[#2dd4bf] hover:bg-teal-100 flex items-center gap-1.5 shadow-2xs cursor-pointer"
                    title="إعادة هيكلة النص تلقائياً وفق الهيكل الأكاديمي الإلزامي: المفاهيم، الخلاصات، المنهجية"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>تنظيم بالهيكل الثلاثي (Main Concepts, Takeaways, Methodology)</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      if (customSummaryText.trim()) {
                        onAddMemo(customSummaryText.slice(0, 120) + (customSummaryText.length > 120 ? '...' : ''));
                        alert('تم حفظ النص كمذكرة سريعة!');
                      }
                    }}
                    className="px-3 py-1.5 border border-[#e2e8e5] dark:border-[#22352f] rounded-xl text-xs font-bold text-[#0f766e] dark:text-[#2dd4bf] hover:bg-teal-50"
                  >
                    حفظ في المذكرات
                  </button>
                  <button
                    type="button"
                    onClick={() => setCustomSummaryText('')}
                    className="px-2.5 py-1.5 text-xs text-red-500 font-bold hover:bg-red-50 rounded-xl"
                  >
                    مسح
                  </button>
                </div>
              </div>

              <textarea
                rows={10}
                value={customSummaryText}
                onChange={(e) => setCustomSummaryText(e.target.value)}
                placeholder="اكتب هنا ملخصك أو الصق أي نص أو معلومات تريد حفظها وطباعتها كملف PDF..."
                className="w-full p-4 bg-[#f8fbfa] dark:bg-[#121b18] border border-[#e2e8e5] dark:border-[#22352f] rounded-2xl text-xs sm:text-sm font-sans text-[#17201e] dark:text-[#eef7f4] focus:outline-none focus:ring-2 focus:ring-[#0f766e] leading-relaxed"
              />

              {customSummaryText && (
                <div className="p-4 bg-gray-50 dark:bg-[#182622] rounded-xl border border-gray-200 dark:border-gray-800 text-xs text-gray-600 dark:text-gray-300 flex items-center justify-between">
                  <span>
                    عدد الكلمات: <b>{customSummaryText.split(/\s+/).filter(Boolean).length}</b> • الأسطر: <b>{customSummaryText.split('\n').length}</b>
                  </span>
                  <button
                    type="button"
                    onClick={() => window.print()}
                    className="text-[#0f766e] dark:text-[#2dd4bf] font-bold hover:underline flex items-center gap-1"
                  >
                    <Printer className="w-4 h-4" />
                    <span>جاهز للطباعة كـ PDF الآن</span>
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* 2. Source-Based Smart Quiz Tab */}
      {activeTab === 'quiz' && (
        <SmartQuizView
          sources={sources}
          chunks={chunks}
          currentNotebookId={currentNotebookId}
          notebookTitle={notebookTitle}
          notebookSubject={notebookSubject}
          fallbackConfig={fallbackConfig}
          onAskAboutQuestion={(qText) => {
            if (onAskAboutNote) {
              onAskAboutNote({
                id: `quiz_${Date.now()}`,
                notebookId: currentNotebookId,
                subject: notebookSubject || 'عام',
                level: 'أساسي',
                title: 'استفسار عن سؤال في الاختبار الذكي',
                goal: 'فهم وتفسير الإجابة وتعميق الاستيعاب',
                tags: ['اختبار', 'سؤال'],
                text: qText,
                favorite: false,
                mastery: 0,
                created: Date.now(),
                updated: Date.now(),
              });
            }
          }}
        />
      )}

      {/* 3. Flashcards Tab */}
      {activeTab === 'cards' && (
        <div className="space-y-5">
          {/* View Switcher: Interactive Flashcards vs. Mastery & Progress Dashboard */}
          <div className="bg-white dark:bg-[#14201c] rounded-2xl border border-[#e2e8e5] dark:border-[#22352f] p-4 sm:p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-1.5 p-1 bg-slate-100 dark:bg-[#1a2723] rounded-2xl w-fit">
              <button
                type="button"
                onClick={() => setFlashcardViewMode('cards')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                  flashcardViewMode === 'cards'
                    ? 'bg-white dark:bg-[#14201c] text-teal-800 dark:text-teal-200 shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100'
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                <span>🗂️ بطاقات الاستذكار ({flashcards.length})</span>
              </button>
              <button
                type="button"
                onClick={() => setFlashcardViewMode('dashboard')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                  flashcardViewMode === 'dashboard'
                    ? 'bg-white dark:bg-[#14201c] text-teal-800 dark:text-teal-200 shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100'
                }`}
              >
                <BarChart3 className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                <span>📊 لوحة تحليلات الإتقان والتوزيع الزمني</span>
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              </button>
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              <button
                type="button"
                onClick={() => setFlashcardViewMode(flashcardViewMode === 'dashboard' ? 'cards' : 'dashboard')}
                className="px-3 py-1.5 rounded-xl bg-teal-50 dark:bg-teal-950/60 border border-teal-200/80 dark:border-teal-800/60 flex items-center gap-2 cursor-pointer hover:bg-teal-100 dark:hover:bg-teal-900/40 transition text-xs font-bold text-teal-900 dark:text-teal-200"
              >
                <TrendingUp className="w-3.5 h-3.5 text-teal-600" />
                <span>معدل الإتقان:</span>
                <span className="font-mono text-emerald-600 dark:text-emerald-400">
                  {flashcards.length > 0 ? Math.round((flashcards.filter((c) => (c.level || 0) >= 3 && !c.mistake).length / flashcards.length) * 100) : 0}%
                </span>
                <span className="text-[10px] text-teal-600 dark:text-teal-400">
                  {flashcardViewMode === 'dashboard' ? '← العودة للبطاقات' : 'عرض التحليلات ↗'}
                </span>
              </button>

              <button
                onClick={handleGenerateFlashcards}
                disabled={isGeneratingCards}
                className="px-3.5 py-1.5 bg-[#0f766e] text-white rounded-xl text-xs font-bold hover:bg-[#115e59] flex items-center gap-1.5 cursor-pointer"
              >
                {isGeneratingCards ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Plus className="w-3.5 h-3.5" />}
                <span>توليد بطاقات</span>
              </button>
            </div>
          </div>

          {flashcardViewMode === 'dashboard' ? (
            <FlashcardMasteryDashboard
              flashcards={flashcards}
              notebookTitle={notebookTitle}
              notebookSubject={notebookSubject}
              sources={sources}
              onStartReview={(filter) => {
                setCardTab(filter);
                setFlashcardViewMode('cards');
              }}
              onGenerateCards={handleGenerateFlashcards}
              onClose={() => setFlashcardViewMode('cards')}
            />
          ) : (
            <div className="bg-white dark:bg-[#14201c] rounded-2xl border border-[#e2e8e5] dark:border-[#22352f] p-6 shadow-sm space-y-5">
              {/* Quick Mastery & Progress Distribution Bar */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-teal-500/10 via-emerald-500/5 to-slate-50 dark:from-teal-950/40 dark:via-emerald-950/20 dark:to-[#1a2723] border border-teal-500/20 dark:border-teal-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="space-y-1.5 flex-1">
                  <div className="flex items-center justify-between text-xs font-bold">
                    <div className="flex items-center gap-2 text-slate-800 dark:text-slate-100">
                      <Sparkles className="w-4 h-4 text-teal-600 dark:text-teal-400" />
                      <span>توزيع مستويات الإتقان الحالي (Leitner 5-Tiers):</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setFlashcardViewMode('dashboard')}
                      className="text-teal-700 dark:text-teal-300 hover:underline flex items-center gap-1 cursor-pointer text-[11px]"
                    >
                      <span>عرض لوحة التحليلات والتوزيع الزمني بالتفصيل</span>
                      <TrendingUp className="w-3 h-3 text-teal-600" />
                    </button>
                  </div>

                  {/* 4-tier distribution visual bar */}
                  <div className="w-full h-3 bg-slate-200/80 dark:bg-slate-800 rounded-full overflow-hidden flex shadow-inner">
                    {flashcards.length > 0 ? (
                      <>
                        <div
                          className="bg-teal-600 h-full transition-all duration-500"
                          style={{ width: `${(flashcards.filter((c) => (c.level || 0) >= 4 && !c.mistake).length / flashcards.length) * 100}%` }}
                          title="متقنة تماماً (مستوى 4-5)"
                        />
                        <div
                          className="bg-emerald-500 h-full transition-all duration-500"
                          style={{ width: `${(flashcards.filter((c) => (c.level || 0) === 3 && !c.mistake).length / flashcards.length) * 100}%` }}
                          title="متقدمة (مستوى 3)"
                        />
                        <div
                          className="bg-amber-400 h-full transition-all duration-500"
                          style={{ width: `${(flashcards.filter((c) => ((c.level || 0) === 1 || (c.level || 0) === 2) && !c.mistake).length / flashcards.length) * 100}%` }}
                          title="قيد التعلم (مستوى 1-2)"
                        />
                        <div
                          className="bg-rose-500 h-full transition-all duration-500"
                          style={{ width: `${(flashcards.filter((c) => (c.level || 0) === 0 || c.mistake).length / flashcards.length) * 100}%` }}
                          title="أخطاء وجديدة (مستوى 0)"
                        />
                      </>
                    ) : (
                      <div className="w-full bg-slate-300 dark:bg-slate-700 h-full" />
                    )}
                  </div>

                  <div className="flex items-center justify-between text-[10px] font-bold text-slate-500 dark:text-slate-400 pt-0.5 flex-wrap gap-2">
                    <span className="flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-teal-600 inline-block" />
                      <span>متقنة (L4-5): {flashcards.filter((c) => (c.level || 0) >= 4 && !c.mistake).length}</span>
                    </span>
                    <span className="flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block" />
                      <span>متقدمة (L3): {flashcards.filter((c) => (c.level || 0) === 3 && !c.mistake).length}</span>
                    </span>
                    <span className="flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-amber-400 inline-block" />
                      <span>قيد التعلم (L1-2): {flashcards.filter((c) => ((c.level || 0) === 1 || (c.level || 0) === 2) && !c.mistake).length}</span>
                    </span>
                    <span className="flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-rose-500 inline-block" />
                      <span>أخطاء وجديدة (L0): {flashcards.filter((c) => (c.level || 0) === 0 || c.mistake).length}</span>
                    </span>
                  </div>
                </div>
              </div>

              {/* Automated Smart Review Notification Banner */}
              {dueFlashcards.length > 0 && (
                <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-amber-500/15 via-rose-500/10 to-teal-500/15 border border-amber-500/40 dark:border-amber-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3 animate-in fade-in slide-in-from-top-1 duration-200">
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-2xl bg-amber-500 text-white flex items-center justify-center shrink-0 shadow-md shadow-amber-500/30">
                      <Bell className="w-5 h-5 animate-bounce" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-extrabold text-xs sm:text-sm text-amber-900 dark:text-amber-200">
                          🚨 حان موعد المراجعة الذكية المجدولة (Spaced Repetition)
                        </span>
                        {dueMistakeCount > 0 && (
                          <span className="px-2.5 py-0.5 rounded-full bg-rose-500 text-white text-[10px] font-black animate-pulse shadow-2xs">
                            {dueMistakeCount} أخطاء سابقة في الصدارة
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-700 dark:text-slate-300 mt-1 leading-relaxed">
                        لديك <b>{dueFlashcards.length}</b> بطاقة مستحقة للمراجعة الآن وفق خوارزمية التكرار المتباعد.
                        {dueMistakeCount > 0 && ' تم فرز بطاقات الأخطاء السابقة أولاً لترسيخها ومعالجة نقاط الضعف.'}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => setCardTab('due')}
                      className="px-4 py-2 bg-gradient-to-r from-amber-600 via-rose-600 to-teal-700 hover:from-amber-700 hover:to-teal-800 text-white text-xs font-bold rounded-xl shadow-md transition-all flex items-center gap-1.5 cursor-pointer active:scale-95"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>⚡ بدء المراجعة المركزة الفورية</span>
                    </button>
                  </div>
                </div>
              )}

              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex gap-2 text-xs flex-wrap">
                  <button
                    onClick={() => setCardTab('due')}
                    className={`px-3 py-1.5 rounded-lg font-bold flex items-center gap-1.5 ${
                      cardTab === 'due' ? 'bg-[#0f766e] text-white' : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300'
                    }`}
                  >
                    <span>مستحقة للمراجعة</span>
                    <span className={`px-1.5 py-0.2 rounded-md text-[10px] font-mono ${cardTab === 'due' ? 'bg-teal-900 text-white' : 'bg-gray-200 dark:bg-gray-700'}`}>
                      {dueFlashcards.length}
                    </span>
                  </button>

                  <button
                    onClick={() => setCardTab('mistakes')}
                    className={`px-3 py-1.5 rounded-lg font-bold flex items-center gap-1.5 ${
                      cardTab === 'mistakes' ? 'bg-rose-600 text-white' : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300'
                    }`}
                  >
                    <span>⚠️ بطاقات الأخطاء</span>
                    <span className={`px-1.5 py-0.2 rounded-md text-[10px] font-mono ${cardTab === 'mistakes' ? 'bg-rose-900 text-white' : 'bg-gray-200 dark:bg-gray-700'}`}>
                      {flashcards.filter((c) => c.mistake).length}
                    </span>
                  </button>

                  <button
                    onClick={() => setCardTab('all')}
                    className={`px-3 py-1.5 rounded-lg font-bold flex items-center gap-1.5 ${
                      cardTab === 'all' ? 'bg-[#0f766e] text-white' : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300'
                    }`}
                  >
                    <span>جميع البطاقات</span>
                    <span className={`px-1.5 py-0.2 rounded-md text-[10px] font-mono ${cardTab === 'all' ? 'bg-teal-900 text-white' : 'bg-gray-200 dark:bg-gray-700'}`}>
                      {flashcards.length}
                    </span>
                  </button>
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  <button
                    type="button"
                    onClick={() => setFlashcardViewMode('dashboard')}
                    className="px-3.5 py-2 bg-teal-50 dark:bg-teal-950/60 hover:bg-teal-100 text-teal-800 dark:text-teal-300 border border-teal-200/80 dark:border-teal-800/60 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-2xs cursor-pointer"
                    title="عرض لوحة تحليلات تقدم المذاكرة وإحصائيات الإتقان البيانية عبر الزمن"
                  >
                    <BarChart3 className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                    <span>لوحة تحليلات الإتقان والتوزيع الزمني</span>
                  </button>

                  <button
                    onClick={handleGenerateFlashcards}
                    disabled={isGeneratingCards}
                    className="px-4 py-2 bg-[#0f766e] text-white rounded-xl text-xs font-bold hover:bg-[#115e59] flex items-center gap-2 cursor-pointer"
                  >
                    {isGeneratingCards ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
                    <span>توليد بطاقات من المصادر</span>
                  </button>
                </div>
              </div>

          {filteredCards.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {filteredCards.map((card) => {
                const isFlipped = flippedCardId === card.id;
                return (
                  <div
                    key={card.id}
                    onClick={() => setFlippedCardId(isFlipped ? null : card.id)}
                    className="p-5 bg-[#f8fbfa] dark:bg-[#121b18] border border-[#e2e8e5] dark:border-[#22352f] rounded-2xl cursor-pointer hover:shadow-md transition-all flex flex-col justify-between min-h-[160px]"
                  >
                    <div>
                      <div className="flex items-center justify-between text-[10px] text-[#596762] dark:text-[#9ab3ab] mb-2 font-bold">
                        <span className="flex items-center gap-1.5">
                          <span>{isFlipped ? 'الإجابة / الشرح' : 'المفهوم / السؤال'}</span>
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              studySpeechEngine.speak(isFlipped ? card.back : card.front, isFlipped ? 'إجابة البطاقة' : 'سؤال البطاقة');
                            }}
                            className="p-1 rounded hover:bg-teal-100 dark:hover:bg-teal-900/60 text-teal-700 dark:text-teal-300 transition cursor-pointer"
                            title="قراءة صوتية"
                          >
                            <Volume2 className="w-3 h-3" />
                          </button>
                        </span>
                        <div className="flex items-center gap-1.5">
                          <span className="px-1.5 py-0.5 rounded-md bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 font-mono text-[9px]">
                            {formatNextReviewTime(card.nextReview || 0)}
                          </span>
                          <span className="font-bold">مستوى {card.level || 0}</span>
                        </div>
                      </div>
                      <div className="text-xs sm:text-sm font-semibold text-[#17201e] dark:text-[#eef7f4] leading-relaxed min-h-[50px]">
                        <EducationalContent content={isFlipped ? card.back : card.front} />
                      </div>
                    </div>

                    <div className="mt-4 pt-3 border-t border-[#e2e8e5] dark:border-[#22352f] flex flex-wrap gap-1.5 justify-end" onClick={(e) => e.stopPropagation()}>
                      <button
                        type="button"
                        onClick={() => onReviewCard(card.id, 'again')}
                        className="px-2 py-1 rounded-lg bg-rose-100 hover:bg-rose-200 dark:bg-rose-950/80 dark:hover:bg-rose-900 text-rose-800 dark:text-rose-200 text-[10px] font-bold transition-all cursor-pointer"
                        title="إعادة المراجعة خلال ساعة لترسيخ المفهوم"
                      >
                        إعادة (1س)
                      </button>
                      <button
                        type="button"
                        onClick={() => onReviewCard(card.id, 'hard')}
                        className="px-2 py-1 rounded-lg bg-amber-100 hover:bg-amber-200 dark:bg-amber-950/80 dark:hover:bg-amber-900 text-amber-800 dark:text-amber-200 text-[10px] font-bold transition-all cursor-pointer"
                        title="صعب قليلاً"
                      >
                        صعب
                      </button>
                      <button
                        type="button"
                        onClick={() => onReviewCard(card.id, 'good')}
                        className="px-2 py-1 rounded-lg bg-teal-100 hover:bg-teal-200 dark:bg-teal-950/80 dark:hover:bg-teal-900 text-teal-800 dark:text-teal-200 text-[10px] font-bold transition-all cursor-pointer"
                        title="متقن حسب الجدول الزمني"
                      >
                        متقن ✓
                      </button>
                      <button
                        type="button"
                        onClick={() => onReviewCard(card.id, 'easy')}
                        className="px-2 py-1 rounded-lg bg-emerald-100 hover:bg-emerald-200 dark:bg-emerald-950/80 dark:hover:bg-emerald-900 text-emerald-800 dark:text-emerald-200 text-[10px] font-bold transition-all cursor-pointer"
                        title="سهل جداً - مكافأة تباعد زمني"
                      >
                        سهل ⚡
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="p-10 border border-dashed border-[#e2e8e5] dark:border-[#22352f] rounded-2xl text-center text-xs text-[#596762] dark:text-[#9ab3ab]">
              لا توجد بطاقات في هذا القسم. اضغط على «توليد بطاقات من المصادر» للبدء.
            </div>
          )}
            </div>
          )}
        </div>
      )}

      {/* 3.5. Study Progress Analytics Dashboard (Recharts) */}
      {activeTab === 'progress' && (
        <StudyProgressDashboard
          flashcards={flashcards}
          notebookTitle={notebookTitle}
          notebookSubject={notebookSubject}
          sources={sources}
        />
      )}

      {/* 4. Interactive SVG Mind Map Tab - Hierarchical Tree Generator */}
      {activeTab === 'mindmap' && (
        <div className="bg-white dark:bg-[#14201c] rounded-2xl border border-[#e2e8e5] dark:border-[#22352f] p-6 shadow-sm space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded-md bg-teal-100 dark:bg-teal-950 text-teal-800 dark:text-teal-300 text-[10px] font-bold">
                  Notebook Context Tree
                </span>
                <span className="text-xs text-gray-500 font-mono">Hierarchical Visual Tree</span>
              </div>
              <h3 className="font-bold text-base text-[#17201e] dark:text-[#eef7f4] flex items-center gap-2 mt-1">
                <GitFork className="w-4 h-4 text-[#0f766e] dark:text-[#2dd4bf]" />
                <span>شجرة المفاهيم الأساسية (Main Concepts Visual Tree)</span>
              </h3>
              <p className="text-xs text-[#596762] dark:text-[#9ab3ab]">
                استخراج وهيكلة المفاهيم الأساسية من سياق الدفتر كاملاً في مخطط شجري هرمي مع تصدير مباشر لتقرير أكاديمي منظم (Export to PDF).
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {/* Engine Switcher */}
              <div className="flex items-center bg-[#e6f4f1] dark:bg-[#192723] p-0.5 rounded-xl text-xs font-bold">
                <button
                  type="button"
                  onClick={() => setMindMapEngine('d3')}
                  className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 ${
                    mindMapEngine === 'd3'
                      ? 'bg-[#0f766e] text-white shadow-xs'
                      : 'text-teal-900 dark:text-teal-200 hover:bg-teal-200/50'
                  }`}
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>خرائط D3 الذكية (Clustered)</span>
                </button>
                <button
                  type="button"
                  onClick={() => setMindMapEngine('classic')}
                  className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 ${
                    mindMapEngine === 'classic'
                      ? 'bg-[#0f766e] text-white shadow-xs'
                      : 'text-teal-900 dark:text-teal-200 hover:bg-teal-200/50'
                  }`}
                >
                  <GitFork className="w-3.5 h-3.5" />
                  <span>الشجرة الكلاسيكية</span>
                </button>
              </div>

              <button
                id="generate-main-concepts-tree-btn"
                onClick={handleGenerateMindMap}
                disabled={isGeneratingMindMap}
                className="px-4 py-2 bg-[#0f766e] text-white rounded-xl text-xs font-bold hover:bg-[#115e59] flex items-center gap-2 cursor-pointer shadow-xs disabled:opacity-50"
              >
                {isGeneratingMindMap ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                <span>استخراج مفاهيم الدفتر</span>
              </button>

              <button
                type="button"
                id="export-tree-pdf-btn"
                onClick={handleExportMindMapPdf}
                className="px-3.5 py-2 bg-white dark:bg-[#192723] border border-teal-600 dark:border-teal-500 text-teal-800 dark:text-teal-200 rounded-xl text-xs font-bold hover:bg-teal-50 dark:hover:bg-teal-950 flex items-center gap-1.5 shadow-xs cursor-pointer"
                title="تصدير الشجرة كدليل دراسي أكاديمي منظم (academic-report-style)"
              >
                <FileText className="w-4 h-4 text-teal-600 dark:text-teal-400" />
                <span>Export to PDF (دليل دراسي)</span>
              </button>
            </div>
          </div>

          {mindMapEngine === 'd3' ? (
            <D3VisualMindMap
              notebookTitle={notebookTitle || 'الدفتر الأكاديمي'}
              notebookSubject={notebookSubject || 'المنهج الدراسي'}
              glossary={glossary}
              memos={memos}
              sources={sources}
              chunks={chunks}
              notes={notes}
              initialData={mindMapData}
              onSave={(updated) => setMindMapData(updated)}
            />
          ) : (
            <InteractiveMindMap
              initialData={mindMapData}
              initialLayout="tree"
              onSave={(updated) => setMindMapData(updated)}
              onExportPdf={handleExportMindMapPdf}
              notebookTitle={notebookTitle}
              notebookSubject={notebookSubject}
            />
          )}
        </div>
      )}

      {/* 5. Study Planner & To-Dos */}
      {activeTab === 'planner' && (
        <div className="space-y-5">
          {/* Daily Study Reminder & Inactivity Notification Controller */}
          <StudyReminderController />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* To-Do Tracker */}
            <div className="bg-white dark:bg-[#14201c] rounded-2xl border border-[#e2e8e5] dark:border-[#22352f] p-5 shadow-sm space-y-3">
              <h3 className="font-bold text-sm text-[#17201e] dark:text-[#eef7f4]">
                قائمة مهام المذاكرة
              </h3>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (!newTodoText.trim()) return;
                const dueParam = newTodoDueDate ? (newTodoDueTime ? `${newTodoDueDate}T${newTodoDueTime}` : newTodoDueDate) : undefined;
                onAddTodo(newTodoText.trim(), dueParam);
                setNewTodoText('');
                setNewTodoDueDate('');
                setNewTodoDueTime('');
              }}
              className="space-y-2"
            >
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="أضف مهمة دراسية جديدة..."
                  value={newTodoText}
                  onChange={(e) => setNewTodoText(e.target.value)}
                  className="flex-1 px-3 py-2 border border-[#e2e8e5] dark:border-[#22352f] rounded-xl text-xs bg-[#f6f8f7] dark:bg-[#1a2723] text-[#17201e] dark:text-[#eef7f4]"
                />
                <button
                  type="submit"
                  disabled={!newTodoText.trim()}
                  className="px-4 py-2 bg-[#0f766e] hover:bg-[#115e59] text-white rounded-xl text-xs font-bold transition-all disabled:opacity-40 cursor-pointer shrink-0"
                >
                  إضافة
                </button>
              </div>

              {/* Due Date & Time Controls */}
              <div className="flex flex-wrap items-center gap-2 pt-1 text-xs">
                <div className="flex items-center gap-1.5 flex-1 min-w-[140px]">
                  <span className="text-[11px] text-slate-500 font-semibold shrink-0">موعد الاستحقاق:</span>
                  <input
                    type="date"
                    value={newTodoDueDate}
                    onChange={(e) => setNewTodoDueDate(e.target.value)}
                    className="px-2 py-1 border border-[#e2e8e5] dark:border-[#22352f] rounded-lg text-xs bg-[#f6f8f7] dark:bg-[#1a2723] text-[#17201e] dark:text-[#eef7f4]"
                  />
                </div>

                <div className="flex items-center gap-1.5">
                  <span className="text-[11px] text-slate-500 font-semibold shrink-0">الساعة:</span>
                  <input
                    type="time"
                    value={newTodoDueTime}
                    onChange={(e) => setNewTodoDueTime(e.target.value)}
                    className="px-2 py-1 border border-[#e2e8e5] dark:border-[#22352f] rounded-lg text-xs bg-[#f6f8f7] dark:bg-[#1a2723] text-[#17201e] dark:text-[#eef7f4]"
                  />
                </div>

                {/* Quick Date Chips */}
                <div className="flex gap-1">
                  <button
                    type="button"
                    onClick={() => setNewTodoDueDate(todayISO)}
                    className="px-2 py-1 rounded-md text-[10px] font-bold bg-teal-50 dark:bg-teal-950 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-800"
                  >
                    اليوم
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const tm = new Date();
                      tm.setDate(tm.getDate() + 1);
                      setNewTodoDueDate(tm.toISOString().slice(0, 10));
                    }}
                    className="px-2 py-1 rounded-md text-[10px] font-bold bg-slate-100 dark:bg-[#1a2723] text-slate-700 dark:text-slate-300"
                  >
                    غداً
                  </button>
                </div>
              </div>
            </form>

            <div className="space-y-1.5 max-h-80 overflow-y-auto">
              {todos.length === 0 ? (
                <div className="text-xs text-gray-400 p-4 text-center">لا توجد مهام حاليًا.</div>
              ) : (
                todos.map((todo) => {
                  const taskDue = todo.dueDate || todo.due;
                  const isOverdue = taskDue && taskDue.slice(0, 10) < todayISO && !todo.done;
                  const isDueToday = taskDue && taskDue.slice(0, 10) === todayISO && !todo.done;
                  return (
                    <div
                      key={todo.id}
                      className={`flex items-center justify-between p-2.5 rounded-xl border transition-all ${
                        todo.done
                          ? 'bg-[#f8fbfa]/60 dark:bg-[#121b18]/60 border-[#e2e8e5] dark:border-[#22352f] opacity-75'
                          : isOverdue
                          ? 'bg-rose-50/70 dark:bg-rose-950/20 border-rose-300 dark:border-rose-900/60 shadow-2xs'
                          : isDueToday
                          ? 'bg-amber-50/70 dark:bg-amber-950/20 border-amber-300 dark:border-amber-800 shadow-2xs'
                          : 'bg-[#f8fbfa] dark:bg-[#121b18] border-[#e2e8e5] dark:border-[#22352f]'
                      }`}
                    >
                      <label className="flex items-center gap-2 cursor-pointer flex-1 min-w-0">
                        <input
                          type="checkbox"
                          checked={todo.done}
                          onChange={() => onToggleTodo(todo.id)}
                          className="rounded text-[#0f766e] w-4 h-4 cursor-pointer"
                        />
                        <span className={`text-xs truncate ${todo.done ? 'line-through text-gray-400' : 'text-[#17201e] dark:text-[#eef7f4]'}`}>
                          {todo.text}
                        </span>
                      </label>

                      <div className="flex items-center gap-1.5 shrink-0 pr-2">
                        {isOverdue && (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800 animate-pulse">
                            ⚠️ متأخرة
                          </span>
                        )}
                        {isDueToday && (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-amber-800">
                            🔔 مستحقة اليوم
                          </span>
                        )}
                        {taskDue && !isOverdue && !isDueToday && (
                          <span className="text-[10px] font-medium text-slate-500">
                            📅 {taskDue.slice(0, 10)}
                          </span>
                        )}
                        <button
                          onClick={() => onDeleteTodo(todo.id)}
                          className="text-gray-400 hover:text-red-500 p-1 cursor-pointer"
                          title="حذف المهمة"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Quick AI Study Plan Generator */}
          <div className="bg-white dark:bg-[#14201c] rounded-2xl border border-[#e2e8e5] dark:border-[#22352f] p-5 shadow-sm space-y-3">
            <h3 className="font-bold text-sm text-[#17201e] dark:text-[#eef7f4]">
              خطة المذاكرة الموزعة
            </h3>
            <div className="text-xs text-[#596762] dark:text-[#9ab3ab]">
              نظّم دراستك على أيام متفرقة مع توزيع أهداف كل جلسة بناءً على حجم المصادر.
            </div>

            <div className="flex gap-2">
              <input
                type="text"
                placeholder="الهدف (مثال: إنهاء الفصل الأول والتمارين)"
                value={planGoal}
                onChange={(e) => setPlanGoal(e.target.value)}
                className="flex-1 px-3 py-2 border border-[#e2e8e5] dark:border-[#22352f] rounded-xl text-xs bg-[#f6f8f7] dark:bg-[#1a2723] text-[#17201e] dark:text-[#eef7f4]"
              />
              <select
                value={planDays}
                onChange={(e) => setPlanDays(Number(e.target.value))}
                className="px-3 py-2 border border-[#e2e8e5] dark:border-[#22352f] rounded-xl text-xs bg-[#f6f8f7] dark:bg-[#1a2723]"
              >
                <option value={3}>3 أيام</option>
                <option value={7}>أسبوع (7 أيام)</option>
                <option value={14}>أسبوعين (14 يوم)</option>
              </select>
            </div>

            <button
              disabled={isGeneratingPlan}
              onClick={async () => {
                const targetGoal = planGoal.trim() || `إنهاء وإتقان مقرر ${notebookTitle || 'الدفتر الدراسي'}`;
                setIsGeneratingPlan(true);
                try {
                  const plan = await generateStudioPlan(
                    {
                      notebookTitle: notebookTitle || 'مقرر دراسي',
                      notebookSubject: notebookSubject || 'المنهج الدراسي',
                      sources,
                      notes,
                      memos,
                      glossary,
                      fallbackConfig,
                    },
                    targetGoal,
                    planDays
                  );
                  setGeneratedPlan(plan);
                } catch (e: any) {
                  alert(`تعذر إنشاء الخطة: ${e.message || 'يرجى المحاولة مجددًا'}`);
                } finally {
                  setIsGeneratingPlan(false);
                }
              }}
              className="w-full py-2.5 bg-[#0f766e] hover:bg-[#115e59] text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs disabled:opacity-50"
            >
              {isGeneratingPlan ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>جاري تحليل المقرر وتوليد الخطة بالذكاء الاصطناعي...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>توليد جدول الخطة الذكية للمقرر</span>
                </>
              )}
            </button>

            {generatedPlan && (
              <div className="space-y-2 mt-3 pt-3 border-t border-[#e2e8e5] dark:border-[#22352f]">
                <div className="flex items-center justify-between text-xs font-bold text-teal-800 dark:text-teal-200">
                  <span>جدول الخطة الذكية ({generatedPlan.days} أيام):</span>
                  <button
                    type="button"
                    onClick={() => {
                      generatedPlan.items.forEach((it) => {
                        onAddTodo(`[خطة M${it.day}] ${it.task}`, it.date);
                      });
                      alert('تمت إضافة جميع مهام الخطة إلى قائمة المهام الدراسية بنجاح!');
                    }}
                    className="text-[11px] px-2 py-0.5 rounded bg-teal-100 dark:bg-teal-950 text-teal-700 dark:text-teal-300 hover:bg-teal-200 cursor-pointer"
                  >
                    + إضافة للمهام الدراسية
                  </button>
                </div>
                <div className="space-y-1.5 max-h-56 overflow-y-auto">
                  {generatedPlan.items.map((item) => (
                    <div
                      key={item.day}
                      className="p-2.5 bg-[#f8fbfa] dark:bg-[#121b18] border border-[#e2e8e5] dark:border-[#22352f] rounded-xl text-xs flex items-center justify-between gap-2"
                    >
                      <div className="flex items-center gap-2">
                        <span className="font-black px-1.5 py-0.5 rounded bg-teal-100 dark:bg-teal-900/60 text-teal-800 dark:text-teal-300 text-[10px]">
                          اليوم {item.day}
                        </span>
                        <span className="text-slate-800 dark:text-slate-100 font-medium">{item.task}</span>
                      </div>
                      <span className="text-[10px] text-slate-400 font-mono shrink-0">{item.date}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
            </div>
          </div>
        </div>
      )}

      {/* 6. Comprehensive Notes, Memos & Personal Glossary Workspace */}
      {activeTab === 'memos' && (
        <div className="space-y-4">
          {/* Sub-Navigation Tabs */}
          <div className="flex flex-wrap items-center justify-between gap-3 bg-white dark:bg-[#14201c] p-3 rounded-2xl border border-[#e2e8e5] dark:border-[#22352f] shadow-xs">
            <div className="flex flex-wrap gap-1.5 bg-[#f6f8f7] dark:bg-[#1a2723] p-1 rounded-xl">
              <button
                type="button"
                onClick={() => setNotesSubTab('notes')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                  notesSubTab === 'notes'
                    ? 'bg-white dark:bg-[#14201c] text-[#0f766e] dark:text-[#2dd4bf] shadow-xs'
                    : 'text-[#596762] dark:text-[#9ab3ab] hover:text-[#17201e] dark:hover:text-[#eef7f4]'
                }`}
              >
                <FileText className="w-3.5 h-3.5" />
                <span>تدوينات وملاحظات الدفتر ({notes.length})</span>
              </button>

              <button
                type="button"
                onClick={() => setNotesSubTab('memos')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                  notesSubTab === 'memos'
                    ? 'bg-white dark:bg-[#14201c] text-[#0f766e] dark:text-[#2dd4bf] shadow-xs'
                    : 'text-[#596762] dark:text-[#9ab3ab] hover:text-[#17201e] dark:hover:text-[#eef7f4]'
                }`}
              >
                <BookOpen className="w-3.5 h-3.5" />
                <span>ملاحظات سريعة ({memos.length})</span>
              </button>

              <button
                type="button"
                onClick={() => setNotesSubTab('glossary')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                  notesSubTab === 'glossary'
                    ? 'bg-white dark:bg-[#14201c] text-[#0f766e] dark:text-[#2dd4bf] shadow-xs'
                    : 'text-[#596762] dark:text-[#9ab3ab] hover:text-[#17201e] dark:hover:text-[#eef7f4]'
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                <span>معجم المصطلحات ({glossary.length})</span>
              </button>
            </div>

            {notesSubTab === 'notes' && (
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsVoiceModalOpen(true);
                    startVoiceRecording();
                  }}
                  className="px-3.5 py-1.5 bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-700 hover:to-red-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm shadow-rose-600/20 transition-all cursor-pointer active:scale-95"
                  title="تسجيل عصف ذهني صوتي وتحويله آلياً إلى تدوينة نصية"
                >
                  <Mic className="w-3.5 h-3.5 animate-pulse" />
                  <span>تسجيل عصف ذهني صوتي</span>
                </button>

                <button
                  type="button"
                  onClick={() => setIsAddingNote(!isAddingNote)}
                  className="px-3.5 py-1.5 bg-[#0f766e] text-white hover:bg-[#115e59] rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs transition-all cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>{isAddingNote ? 'إلغاء التدوينة' : 'تدوينة دراسية جديدة'}</span>
                </button>
              </div>
            )}
          </div>

          {/* Tab 1: Organized Notebook Notes */}
          {notesSubTab === 'notes' && (
            <div className="space-y-4">
              {/* Add Note Form */}
              {isAddingNote && (
                <div className="bg-white dark:bg-[#14201c] rounded-2xl border-2 border-[#0f766e] p-4 sm:p-5 shadow-md space-y-3 animate-in fade-in duration-200">
                  <div className="flex items-center justify-between pb-2 border-b border-black/10 dark:border-white/10">
                    <h3 className="font-bold text-xs text-[#0f766e] dark:text-[#2dd4bf] flex items-center gap-1.5">
                      <Edit3 className="w-4 h-4" />
                      <span>كتابة تدوينة دراسية جديدة</span>
                    </h3>
                    <button
                      type="button"
                      onClick={() => setIsAddingNote(false)}
                      className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 cursor-pointer"
                    >
                      <XCircle className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="space-y-2.5">
                    <div>
                      <label className="block text-[11px] font-bold text-gray-700 dark:text-gray-300 mb-1">
                        عنوان التدوينة أو المفهوم:
                      </label>
                      <input
                        type="text"
                        placeholder="مثال: القوانين الأساسية في الحركة الدائرية"
                        value={newNoteTitle}
                        onChange={(e) => setNewNoteTitle(e.target.value)}
                        className="w-full px-3 py-2 border border-[#e2e8e5] dark:border-[#22352f] rounded-xl text-xs bg-[#f8fbfa] dark:bg-[#121b18] text-[#17201e] dark:text-[#eef7f4] focus:outline-none focus:border-[#0f766e]"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-gray-700 dark:text-gray-300 mb-1">
                        الوسوم والتصنيفات (مفصولة بفواصل):
                      </label>
                      <input
                        type="text"
                        placeholder="مثال: فيزياء, قوانين, مراجعة_نهائية"
                        value={newNoteTags}
                        onChange={(e) => setNewNoteTags(e.target.value)}
                        className="w-full px-3 py-2 border border-[#e2e8e5] dark:border-[#22352f] rounded-xl text-xs bg-[#f8fbfa] dark:bg-[#121b18] text-[#17201e] dark:text-[#eef7f4] focus:outline-none focus:border-[#0f766e]"
                      />
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-1.5 flex-wrap gap-2">
                        <label className="block text-[11px] font-bold text-gray-700 dark:text-gray-300">
                          نص التدوينة والملاحظات والشروحات:
                        </label>
                        <div className="flex items-center gap-2">
                          {/* Export PDF also available in preview mode */}
                          <button
                            type="button"
                            onClick={() => handleExportNotePdf()}
                            disabled={!newNoteText.trim() || isExportingPdf}
                            className={`text-[11px] font-bold px-2 py-0.5 rounded-lg flex items-center gap-1 transition-all cursor-pointer ${
                              !newNoteText.trim() || isExportingPdf
                                ? 'text-gray-400 dark:text-gray-600 cursor-not-allowed'
                                : 'text-teal-700 dark:text-teal-300 bg-teal-50 dark:bg-teal-950/60 hover:bg-teal-100 dark:hover:bg-teal-900/40'
                            }`}
                            title="تحويل الملاحظة المنسقة الحالية إلى ملف PDF جاهز للطباعة باستخدام مكتبة jsPDF"
                          >
                            {isExportingPdf ? (
                              <Loader2 className="w-3 h-3 animate-spin" />
                            ) : (
                              <FileDown className="w-3 h-3" />
                            )}
                            <span>تصدير PDF</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => setIsNotePreview(!isNotePreview)}
                            className="text-[11px] font-semibold text-[#0f766e] dark:text-[#2dd4bf] hover:underline flex items-center gap-1 cursor-pointer"
                          >
                            {isNotePreview ? (
                              <>
                                <Edit3 className="w-3.5 h-3.5" />
                                <span>العودة للتحرير</span>
                              </>
                            ) : (
                              <>
                                <Eye className="w-3.5 h-3.5" />
                                <span>معاينة التنسيق</span>
                              </>
                            )}
                          </button>
                        </div>
                      </div>

                      {/* Hidden Multi-format Pickers */}
                      <input
                        ref={cameraInputRef}
                        type="file"
                        accept=".pdf,.doc,.docx,.txt,.html,audio/*,image/*"
                        multiple
                        className="hidden"
                        onChange={(e) => handleImageFileChange(e, 'upload')}
                      />
                      <input
                        ref={fileImageInputRef}
                        type="file"
                        accept=".pdf,.doc,.docx,.txt,.html,audio/*,image/*"
                        multiple
                        className="hidden"
                        onChange={(e) => handleImageFileChange(e, 'upload')}
                      />

                      {/* WYSIWYG Toolbar */}
                      {!isNotePreview && (
                        <div
                          role="toolbar"
                          aria-label="شريط أدوات تنسيق الملاحظات"
                          className="flex items-center flex-wrap gap-1 p-1.5 bg-[#f0f7f5] dark:bg-[#182622] border border-[#d2e5dd] dark:border-[#263c35] rounded-t-xl border-b-0"
                        >
                          {/* Voice Dictation */}
                          <button
                            type="button"
                            onClick={() => {
                              setIsVoiceModalOpen(true);
                              startVoiceRecording();
                            }}
                            className="p-1.5 rounded-lg text-rose-700 dark:text-rose-300 bg-rose-50/80 dark:bg-rose-950/40 hover:bg-rose-100 hover:text-rose-800 transition-colors cursor-pointer flex items-center gap-1 text-xs font-bold"
                            title="تسجيل إملاء صوتي أو عصف ذهني وتحويله إلى نص"
                          >
                            <Mic className="w-3.5 h-3.5 text-rose-600 animate-pulse" />
                            <span className="text-[10px]">إملاء صوتي</span>
                          </button>

                          <span className="w-px h-4 bg-gray-300 dark:bg-gray-700 mx-0.5" />

                          {/* Bold */}
                          <button
                            type="button"
                            onClick={() => applyNoteFormatting('bold')}
                            className="p-1.5 rounded-lg text-gray-700 dark:text-gray-200 hover:bg-white dark:hover:bg-[#20332d] hover:text-[#0f766e] dark:hover:text-[#2dd4bf] transition-colors cursor-pointer flex items-center gap-1 text-xs font-bold"
                            title="خط غامق (Ctrl+B)"
                          >
                            <Bold className="w-3.5 h-3.5" />
                            <span className="text-[10px] hidden sm:inline">غامق</span>
                          </button>

                          {/* Italic */}
                          <button
                            type="button"
                            onClick={() => applyNoteFormatting('italic')}
                            className="p-1.5 rounded-lg text-gray-700 dark:text-gray-200 hover:bg-white dark:hover:bg-[#20332d] hover:text-[#0f766e] dark:hover:text-[#2dd4bf] transition-colors cursor-pointer flex items-center gap-1 text-xs"
                            title="خط مائل (Ctrl+I)"
                          >
                            <Italic className="w-3.5 h-3.5" />
                            <span className="text-[10px] hidden sm:inline">مائل</span>
                          </button>

                          <span className="w-px h-4 bg-gray-300 dark:bg-gray-700 mx-0.5" />

                          {/* Heading */}
                          <button
                            type="button"
                            onClick={() => applyNoteFormatting('heading')}
                            className="p-1.5 rounded-lg text-gray-700 dark:text-gray-200 hover:bg-white dark:hover:bg-[#20332d] hover:text-[#0f766e] dark:hover:text-[#2dd4bf] transition-colors cursor-pointer flex items-center gap-1 text-xs"
                            title="عنوان فرعي (###)"
                          >
                            <Heading className="w-3.5 h-3.5" />
                            <span className="text-[10px] hidden sm:inline">عنوان</span>
                          </button>

                          {/* Bullet List */}
                          <button
                            type="button"
                            onClick={() => applyNoteFormatting('bullet')}
                            className="p-1.5 rounded-lg text-gray-700 dark:text-gray-200 hover:bg-white dark:hover:bg-[#20332d] hover:text-[#0f766e] dark:hover:text-[#2dd4bf] transition-colors cursor-pointer flex items-center gap-1 text-xs font-semibold"
                            title="قائمة نقطية لتنظيم العناصر (•)"
                          >
                            <List className="w-3.5 h-3.5" />
                            <span className="text-[10px] hidden sm:inline">نقطي</span>
                          </button>

                          {/* Ordered List */}
                          <button
                            type="button"
                            onClick={() => applyNoteFormatting('ordered')}
                            className="p-1.5 rounded-lg text-gray-700 dark:text-gray-200 hover:bg-white dark:hover:bg-[#20332d] hover:text-[#0f766e] dark:hover:text-[#2dd4bf] transition-colors cursor-pointer flex items-center gap-1 text-xs font-semibold"
                            title="قائمة رقمية للخطوات المتسلسلة (1.)"
                          >
                            <ListOrdered className="w-3.5 h-3.5" />
                            <span className="text-[10px] hidden sm:inline">ترقيم</span>
                          </button>

                          <span className="w-px h-4 bg-gray-300 dark:bg-gray-700 mx-0.5" />

                          {/* Quote / Law */}
                          <button
                            type="button"
                            onClick={() => applyNoteFormatting('quote')}
                            className="p-1.5 rounded-lg text-gray-700 dark:text-gray-200 hover:bg-white dark:hover:bg-[#20332d] hover:text-[#0f766e] dark:hover:text-[#2dd4bf] transition-colors cursor-pointer flex items-center gap-1 text-xs"
                            title="اقتباس أو قاعدة دراسية (>)"
                          >
                            <Quote className="w-3.5 h-3.5" />
                            <span className="text-[10px] hidden sm:inline">قاعدة</span>
                          </button>

                          {/* Code / Formula */}
                          <button
                            type="button"
                            onClick={() => applyNoteFormatting('code')}
                            className="p-1.5 rounded-lg text-gray-700 dark:text-gray-200 hover:bg-white dark:hover:bg-[#20332d] hover:text-[#0f766e] dark:hover:text-[#2dd4bf] transition-colors cursor-pointer flex items-center gap-1 text-xs"
                            title="رمز أو صيغة علمية مضمنة (`)"
                          >
                            <Code className="w-3.5 h-3.5" />
                            <span className="text-[10px] hidden sm:inline">صيغة</span>
                          </button>

                          {/* Code Block */}
                          <button
                            type="button"
                            onClick={() => applyNoteFormatting('codeblock')}
                            className="p-1.5 rounded-lg text-gray-700 dark:text-gray-200 hover:bg-white dark:hover:bg-[#20332d] hover:text-[#0f766e] dark:hover:text-[#2dd4bf] transition-colors cursor-pointer flex items-center gap-1 text-xs"
                            title="كتلة كود برمجي منسق مع رأس اللغة (```)"
                          >
                            <Terminal className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                            <span className="text-[10px] hidden sm:inline">كود برمجي</span>
                          </button>

                          <span className="w-px h-4 bg-gray-300 dark:bg-gray-700 mx-0.5" />

                          {/* Templates Dropdown */}
                          <div className="relative">
                            <button
                              type="button"
                              onClick={() => setIsTemplatesDropdownOpen(!isTemplatesDropdownOpen)}
                              className="p-1.5 rounded-lg text-emerald-800 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/60 hover:bg-emerald-100 dark:hover:bg-emerald-900/50 border border-emerald-200 dark:border-emerald-800/60 transition-colors cursor-pointer flex items-center gap-1 text-xs font-bold shadow-2xs"
                              title="قوالب دراسية جاهزة (تلخيص كتاب، جدول مقارنة، مراجعة أسبوعية، وغيرها)"
                            >
                              <LayoutTemplate className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                              <span className="text-[10px] font-bold">قوالب جاهزة</span>
                              <ChevronDown className="w-3 h-3 text-emerald-500" />
                            </button>

                            {/* Templates Dropdown Menu */}
                            {isTemplatesDropdownOpen && (
                              <div
                                className="absolute top-full mt-1.5 right-0 z-50 bg-white dark:bg-[#162420] border border-gray-200 dark:border-[#223831] rounded-2xl p-2.5 shadow-2xl w-80 max-h-96 overflow-y-auto space-y-1.5 animate-in fade-in duration-150"
                                dir="rtl"
                              >
                                <div className="flex items-center justify-between pb-2 border-b border-gray-100 dark:border-gray-800 px-1">
                                  <span className="text-xs font-bold text-gray-800 dark:text-gray-200 flex items-center gap-1.5">
                                    <LayoutTemplate className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                                    قوالب الملاحظات الأكاديمية
                                  </span>
                                  <button
                                    type="button"
                                    onClick={() => setIsTemplatesDropdownOpen(false)}
                                    className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 p-0.5 cursor-pointer"
                                  >
                                    <X className="w-3.5 h-3.5" />
                                  </button>
                                </div>

                                <div className="space-y-1 pt-1">
                                  {NOTE_TEMPLATES.map((tmpl) => (
                                    <button
                                      key={tmpl.id}
                                      type="button"
                                      onClick={() => handleSelectTemplate(tmpl)}
                                      className="w-full text-right p-2 rounded-xl hover:bg-emerald-50/80 dark:hover:bg-[#1f332c] border border-transparent hover:border-emerald-200 dark:hover:border-emerald-800/40 transition-all cursor-pointer group flex items-start gap-2.5"
                                    >
                                      <div className="w-7 h-7 rounded-lg bg-emerald-100/70 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 flex items-center justify-center shrink-0 mt-0.5 font-bold group-hover:scale-105 transition-transform">
                                        <FileSpreadsheet className="w-3.5 h-3.5" />
                                      </div>
                                      <div className="flex-1 min-w-0">
                                        <div className="flex items-center justify-between gap-1">
                                          <span className="text-xs font-bold text-gray-800 dark:text-gray-200 group-hover:text-emerald-700 dark:group-hover:text-emerald-300 transition-colors">
                                            {tmpl.name}
                                          </span>
                                          <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-md bg-emerald-100 dark:bg-emerald-900/60 text-emerald-800 dark:text-emerald-200 shrink-0">
                                            {tmpl.badge}
                                          </span>
                                        </div>
                                        <p className="text-[10px] text-gray-500 dark:text-gray-400 mt-0.5 line-clamp-2 leading-relaxed">
                                          {tmpl.description}
                                        </p>
                                      </div>
                                    </button>
                                  ))}
                                </div>
                              </div>
                            )}
                          </div>

                          {/* LaTeX / KaTeX Equation Tool */}
                          <button
                            type="button"
                            onClick={() => setIsMathModalOpen(true)}
                            className="p-1.5 rounded-lg text-purple-800 dark:text-purple-300 bg-purple-50 dark:bg-purple-950/60 hover:bg-purple-100 dark:hover:bg-purple-900/50 border border-purple-200 dark:border-purple-800/60 transition-colors cursor-pointer flex items-center gap-1 text-xs font-bold shadow-2xs"
                            title="إدراج معادلة أو صيغة رياضية وفيزيائية مع عرض مباشر (KaTeX)"
                          >
                            <Sigma className="w-3.5 h-3.5 text-purple-600 dark:text-purple-400" />
                            <span className="text-[10px] font-bold">معادلة KaTeX</span>
                          </button>

                          <span className="w-px h-4 bg-gray-300 dark:bg-gray-700 mx-0.5" />

                          {/* Font Color Tool */}
                          <div className="relative">
                            <button
                              type="button"
                              onClick={() => setIsColorPaletteOpen(!isColorPaletteOpen)}
                              className="p-1.5 rounded-lg text-gray-700 dark:text-gray-200 hover:bg-white dark:hover:bg-[#20332d] hover:text-[#0f766e] dark:hover:text-[#2dd4bf] transition-colors cursor-pointer flex items-center gap-1 text-xs"
                              title="لون الخط لتمييز النصوص والمصطلحات والتلخيص"
                            >
                              <Palette className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                              <span className="text-[10px] hidden sm:inline">لون الخط</span>
                              <span
                                className="w-2 h-2 rounded-full border border-black/20 dark:border-white/20 inline-block shadow-2xs"
                                style={{ backgroundColor: selectedFontColor }}
                              />
                              <ChevronDown className="w-3 h-3 text-gray-400" />
                            </button>

                            {/* Color Palette Dropdown Menu */}
                            {isColorPaletteOpen && (
                              <div
                                className="absolute top-full mt-1.5 right-0 z-40 bg-white dark:bg-[#162420] border border-gray-200 dark:border-[#223831] rounded-2xl p-3 shadow-xl w-64 space-y-2.5 animate-in fade-in duration-150"
                                dir="rtl"
                              >
                                <div className="flex items-center justify-between pb-1.5 border-b border-gray-100 dark:border-gray-800">
                                  <span className="text-[11px] font-bold text-gray-800 dark:text-gray-200 flex items-center gap-1.5">
                                    <Palette className="w-3.5 h-3.5 text-amber-500" />
                                    ألوان تمييز وتلخيص النصوص
                                  </span>
                                  <button
                                    type="button"
                                    onClick={() => setIsColorPaletteOpen(false)}
                                    className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 text-xs p-0.5 cursor-pointer"
                                  >
                                    <X className="w-3.5 h-3.5" />
                                  </button>
                                </div>

                                {/* Preset Educational Colors */}
                                <div className="grid grid-cols-4 gap-1.5">
                                  {[
                                    { hex: '#ef4444', name: 'أحمر', label: 'مهم وتنبيه' },
                                    { hex: '#2563eb', name: 'أزرق', label: 'تعريف ومفهوم' },
                                    { hex: '#059669', name: 'أخضر', label: 'قانون ومثال' },
                                    { hex: '#7c3aed', name: 'بنفسجي', label: 'استنتاج وربط' },
                                    { hex: '#ea580c', name: 'برتقالي', label: 'سؤال اختبار' },
                                    { hex: '#e11d48', name: 'وردي', label: 'نقطة دقيقة' },
                                    { hex: '#0f766e', name: 'تيل', label: 'لون المنصة' },
                                    { hex: '#d97706', name: 'ذهبي', label: 'فكرة ذهبية' },
                                  ].map((item) => (
                                    <button
                                      key={item.hex}
                                      type="button"
                                      onClick={() => applyFontColor(item.hex)}
                                      className="group flex flex-col items-center p-1.5 rounded-xl hover:bg-gray-100 dark:hover:bg-[#1f332c] transition-all cursor-pointer"
                                      title={`${item.name} (${item.label})`}
                                    >
                                      <span
                                        className="w-5 h-5 rounded-full shadow-xs border border-white/50 dark:border-black/30 group-hover:scale-115 transition-transform"
                                        style={{ backgroundColor: item.hex }}
                                      />
                                      <span className="text-[9px] text-gray-500 dark:text-gray-400 mt-1 truncate max-w-full font-medium">
                                        {item.name}
                                      </span>
                                    </button>
                                  ))}
                                </div>

                                {/* Custom Color Input */}
                                <div className="pt-2 border-t border-gray-100 dark:border-gray-800 flex items-center justify-between gap-2">
                                  <label className="text-[10px] text-gray-600 dark:text-gray-300 font-medium flex items-center gap-1">
                                    <span>درجة لون مخصصة:</span>
                                  </label>
                                  <div className="flex items-center gap-1.5">
                                    <input
                                      type="color"
                                      value={selectedFontColor}
                                      onChange={(e) => applyFontColor(e.target.value)}
                                      className="w-6 h-6 rounded-lg border border-gray-200 dark:border-gray-700 cursor-pointer p-0 bg-transparent"
                                      title="اختر لوناً مخصصاً"
                                    />
                                    <span className="text-[10px] font-mono text-gray-400 uppercase">{selectedFontColor}</span>
                                  </div>
                                </div>
                              </div>
                            )}
                          </div>

                          <span className="w-px h-4 bg-gray-300 dark:bg-gray-700 mx-0.5" />

                          {/* Camera Photo Insert */}
                          <button
                            type="button"
                            onClick={() => cameraInputRef.current?.click()}
                            className="p-1.5 rounded-lg text-gray-700 dark:text-gray-200 hover:bg-white dark:hover:bg-[#20332d] hover:text-[#0f766e] dark:hover:text-[#2dd4bf] transition-colors cursor-pointer flex items-center gap-1 text-xs"
                            title="التقاط صورة بالكاميرا وإدراجها في الملاحظة مباشرة"
                          >
                            <Camera className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                            <span className="text-[10px] hidden sm:inline">كاميرا</span>
                          </button>

                          {/* Web Image Link Insert */}
                          <button
                            type="button"
                            onClick={() => setIsImageUrlModalOpen(true)}
                            className="p-1.5 rounded-lg text-gray-700 dark:text-gray-200 hover:bg-white dark:hover:bg-[#20332d] hover:text-[#0f766e] dark:hover:text-[#2dd4bf] transition-colors cursor-pointer flex items-center gap-1 text-xs"
                            title="إدراج صورة عبر رابط ويب (URL)"
                          >
                            <Image className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                            <span className="text-[10px] hidden sm:inline">رابط صورة</span>
                          </button>

                          {/* Multi-format File Upload */}
                          <button
                            type="button"
                            onClick={() => fileImageInputRef.current?.click()}
                            className="p-1.5 rounded-lg text-gray-700 dark:text-gray-200 hover:bg-white dark:hover:bg-[#20332d] hover:text-[#0f766e] dark:hover:text-[#2dd4bf] transition-colors cursor-pointer flex items-center gap-1 text-xs"
                            title="رفع ملفات (PDF، تسجيل صوتي وتفريغه، مستند Word، أو صور)"
                          >
                            <Upload className="w-3.5 h-3.5 text-gray-500" />
                            <span className="text-[10px] hidden md:inline">رفع ملفات</span>
                          </button>

                          <span className="w-px h-4 bg-gray-300 dark:bg-gray-700 mx-0.5" />

                          {/* Export Note as PDF (jsPDF) */}
                          <button
                            type="button"
                            onClick={() => handleExportNotePdf()}
                            disabled={!newNoteText.trim() || isExportingPdf}
                            className={`p-1.5 px-2.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1 cursor-pointer shadow-2xs ${
                              !newNoteText.trim() || isExportingPdf
                                ? 'bg-gray-200 dark:bg-gray-800 text-gray-400 dark:text-gray-500 cursor-not-allowed'
                                : 'bg-[#0f766e] hover:bg-[#0d655e] text-white active:scale-95'
                            }`}
                            title="تحويل الملاحظة المنسقة الحالية إلى ملف PDF جاهز للطباعة باستخدام مكتبة jsPDF"
                          >
                            {isExportingPdf ? (
                              <>
                                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                                <span className="text-[10px]">جارٍ التصدير...</span>
                              </>
                            ) : (
                              <>
                                <FileDown className="w-3.5 h-3.5" />
                                <span className="text-[10px]">تصدير PDF</span>
                              </>
                            )}
                          </button>
                        </div>
                      )}

                      {/* Editor Textarea or Live Preview */}
                      {isNotePreview ? (
                        <div className="w-full min-h-[140px] p-4 border border-[#e2e8e5] dark:border-[#22352f] rounded-xl text-xs bg-[#f8fbfa] dark:bg-[#121b18] text-[#17201e] dark:text-[#eef7f4] leading-relaxed overflow-y-auto max-h-64 shadow-inner">
                          {newNoteText.trim() ? (
                            <EducationalContent content={newNoteText} />
                          ) : (
                            <span className="text-gray-400 italic">لا يوجد محتوى للمعاينة بعد... اكتب الملاحظات واستخدم شريط التنسيق.</span>
                          )}
                        </div>
                      ) : (
                        <textarea
                          ref={noteTextareaRef}
                          rows={6}
                          placeholder="اكتب تفاصيل الدرس، القوانين، الشواهد، والملاحظات التي تم استنتاجها... (يدعم التنسيق الغامق والمائل والقوائم)"
                          value={newNoteText}
                          onChange={(e) => setNewNoteText(e.target.value)}
                          onKeyDown={handleNoteTextKeyDown}
                          className="w-full p-3 border border-[#d2e5dd] dark:border-[#263c35] rounded-b-xl text-xs bg-[#f8fbfa] dark:bg-[#121b18] text-[#17201e] dark:text-[#eef7f4] leading-relaxed focus:outline-none focus:border-[#0f766e]"
                        />
                      )}
                    </div>

                    <div className="flex items-center justify-end gap-2 pt-2">
                      <button
                        type="button"
                        onClick={() => setIsAddingNote(false)}
                        className="px-3.5 py-1.5 border border-gray-300 dark:border-gray-700 text-xs font-bold rounded-xl cursor-pointer"
                      >
                        إلغاء
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          if (!newNoteTitle.trim() || !newNoteText.trim()) {
                            alert('يرجى ملء عنوان ونص التدوينة.');
                            return;
                          }
                          const tags = newNoteTags
                            .split(',')
                            .map((t) => t.trim())
                            .filter(Boolean);
                          onAddNote?.(newNoteTitle.trim(), newNoteText.trim(), tags);
                          setNewNoteTitle('');
                          setNewNoteText('');
                          setNewNoteTags('');
                          setIsAddingNote(false);
                        }}
                        className="px-4 py-1.5 bg-[#0f766e] text-white text-xs font-bold rounded-xl hover:bg-[#115e59] shadow-xs cursor-pointer"
                      >
                        حفظ التدوينة
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* Image via Web URL Modal Dialog */}
              {isImageUrlModalOpen && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-xs p-4 animate-in fade-in duration-150" dir="rtl">
                  <div className="bg-white dark:bg-[#14201c] border border-gray-200 dark:border-gray-800 rounded-2xl p-5 w-full max-w-md shadow-2xl space-y-4">
                    <div className="flex items-center justify-between border-b border-gray-100 dark:border-gray-800 pb-3">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-lg bg-teal-50 dark:bg-teal-950/60 text-[#0f766e] dark:text-[#2dd4bf] flex items-center justify-center">
                          <Image className="w-4 h-4" />
                        </div>
                        <div>
                          <h4 className="text-sm font-bold text-gray-900 dark:text-white">إدراج صورة عبر رابط ويب</h4>
                          <p className="text-[11px] text-gray-500 dark:text-gray-400">أدخل رابط الصورة لتضمينها داخل تدوينتك</p>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setIsImageUrlModalOpen(false);
                          setImageUrlInput('');
                          setImageCaptionInput('');
                        }}
                        className="p-1 rounded-lg text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800 cursor-pointer"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="space-y-3">
                      <div>
                        <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">
                          رابط الصورة (URL) <span className="text-red-500">*</span>:
                        </label>
                        <div className="relative">
                          <input
                            type="url"
                            placeholder="https://example.com/diagram.png"
                            value={imageUrlInput}
                            onChange={(e) => setImageUrlInput(e.target.value)}
                            className="w-full pl-3 pr-8 py-2 border border-gray-200 dark:border-gray-700 rounded-xl text-xs bg-gray-50 dark:bg-[#121c19] text-gray-900 dark:text-white focus:outline-none focus:border-[#0f766e] dir-ltr text-left"
                          />
                          <Link2 className="w-4 h-4 text-gray-400 absolute right-2.5 top-2.5" />
                        </div>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">
                          عنوان أو وصف الصورة (اختياري):
                        </label>
                        <input
                          type="text"
                          placeholder="مثال: مخطط بياني يوضح مسار التيار الكهربائي"
                          value={imageCaptionInput}
                          onChange={(e) => setImageCaptionInput(e.target.value)}
                          className="w-full px-3 py-2 border border-gray-200 dark:border-gray-700 rounded-xl text-xs bg-gray-50 dark:bg-[#121c19] text-gray-900 dark:text-white focus:outline-none focus:border-[#0f766e]"
                        />
                      </div>

                      {/* Live Thumbnail Preview */}
                      {imageUrlInput.trim() && (
                        <div className="p-2 border border-dashed border-gray-200 dark:border-gray-700 rounded-xl bg-gray-50 dark:bg-[#101815] text-center">
                          <p className="text-[10px] text-gray-500 mb-1.5 font-medium">معاينة الصورة المباشرة:</p>
                          <img
                            src={imageUrlInput.trim()}
                            alt="معاينة"
                            className="max-h-36 mx-auto rounded-lg object-contain shadow-xs bg-white dark:bg-black/40"
                            onError={(e) => {
                              (e.currentTarget as HTMLElement).style.display = 'none';
                            }}
                          />
                        </div>
                      )}
                    </div>

                    <div className="flex items-center justify-end gap-2 pt-2 border-t border-gray-100 dark:border-gray-800">
                      <button
                        type="button"
                        onClick={() => {
                          setIsImageUrlModalOpen(false);
                          setImageUrlInput('');
                          setImageCaptionInput('');
                        }}
                        className="px-3 py-1.5 rounded-xl text-xs font-semibold text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors cursor-pointer"
                      >
                        إلغاء
                      </button>
                      <button
                        type="button"
                        disabled={!imageUrlInput.trim()}
                        onClick={() => {
                          if (imageUrlInput.trim()) {
                            insertImageMarkdown(imageUrlInput.trim(), imageCaptionInput.trim());
                            setIsImageUrlModalOpen(false);
                            setImageUrlInput('');
                            setImageCaptionInput('');
                          }
                        }}
                        className="px-4 py-1.5 rounded-xl text-xs font-bold bg-[#0f766e] text-white hover:bg-[#0d655e] transition-colors disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
                      >
                        إدراج الصورة في الملاحظة
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* Template Confirmation Modal (Append vs Replace) */}
              {isTemplateConfirmOpen && pendingTemplate && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-xs p-4 animate-in fade-in duration-150" dir="rtl">
                  <div className="bg-white dark:bg-[#14201c] border border-gray-200 dark:border-gray-800 rounded-2xl p-5 w-full max-w-md shadow-2xl space-y-4">
                    <div className="flex items-center justify-between border-b border-gray-100 dark:border-gray-800 pb-3">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 flex items-center justify-center">
                          <LayoutTemplate className="w-4 h-4" />
                        </div>
                        <div>
                          <h4 className="text-sm font-bold text-gray-900 dark:text-white">
                            إدراج قالب: {pendingTemplate.name}
                          </h4>
                          <span className="text-[10px] text-gray-400">تطبيق الهيكل التنظيمي للملاحظة</span>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setIsTemplateConfirmOpen(false);
                          setPendingTemplate(null);
                        }}
                        className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 p-1 cursor-pointer"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    <p className="text-xs text-gray-600 dark:text-gray-300 leading-relaxed">
                      الملاحظة الحالية تحتوي بالفعل على نصوص مكتوبة. كيف تود تطبيق القالب؟
                    </p>

                    <div className="space-y-2 pt-1">
                      <button
                        type="button"
                        onClick={() => handleApplyPendingTemplate('append')}
                        className="w-full text-right p-3 rounded-xl border border-emerald-200 dark:border-emerald-800/60 bg-emerald-50/70 dark:bg-emerald-950/40 hover:bg-emerald-100 dark:hover:bg-emerald-900/40 transition-colors cursor-pointer"
                      >
                        <div className="text-xs font-bold text-emerald-800 dark:text-emerald-200">
                          ➕ إدراج القالب في نهاية الملاحظة الحالية (موصى به)
                        </div>
                        <p className="text-[10px] text-gray-500 dark:text-gray-400 mt-0.5">
                          يحافظ على كتابتك الحالية ويضيف هيكل القالب أسفلها كقسم جديد.
                        </p>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleApplyPendingTemplate('replace')}
                        className="w-full text-right p-3 rounded-xl border border-amber-200 dark:border-amber-800/60 bg-amber-50/70 dark:bg-amber-950/40 hover:bg-amber-100 dark:hover:bg-amber-900/40 transition-colors cursor-pointer"
                      >
                        <div className="text-xs font-bold text-amber-800 dark:text-amber-200">
                          ⚠️ استبدال محتوى الملاحظة بالكامل
                        </div>
                        <p className="text-[10px] text-gray-500 dark:text-gray-400 mt-0.5">
                          سيتم استبدال النص الحالي بهيكل القالب وعنوانه الأكاديمي.
                        </p>
                      </button>
                    </div>

                    <div className="flex justify-end pt-2 border-t border-gray-100 dark:border-gray-800">
                      <button
                        type="button"
                        onClick={() => {
                          setIsTemplateConfirmOpen(false);
                          setPendingTemplate(null);
                        }}
                        className="px-4 py-1.5 rounded-xl text-xs font-semibold text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 cursor-pointer"
                      >
                        إلغاء
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* KaTeX LaTeX Mathematical Formula Builder Modal */}
              {isMathModalOpen && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-xs p-4 animate-in fade-in duration-150" dir="rtl">
                  <div className="bg-white dark:bg-[#14201c] border border-gray-200 dark:border-gray-800 rounded-2xl p-5 w-full max-w-lg shadow-2xl space-y-4 max-h-[92vh] overflow-y-auto">
                    <div className="flex items-center justify-between border-b border-gray-100 dark:border-gray-800 pb-3">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-lg bg-purple-50 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 flex items-center justify-center">
                          <Sigma className="w-4 h-4" />
                        </div>
                        <div>
                          <h4 className="text-sm font-bold text-gray-900 dark:text-white">
                            إدراج معادلة وصيغة رياضية (LaTeX / KaTeX)
                          </h4>
                          <span className="text-[10px] text-gray-400">صياغة وعرض المعادلات الرياضية والفيزيائية المتقدمة</span>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => setIsMathModalOpen(false)}
                        className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 p-1 cursor-pointer"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    {/* Mode Toggle: Inline vs Display Block */}
                    <div className="flex items-center gap-2 p-1 bg-gray-100 dark:bg-[#101815] rounded-xl text-xs font-semibold">
                      <button
                        type="button"
                        onClick={() => setIsMathDisplayBlock(true)}
                        className={`flex-1 py-1.5 px-2 rounded-lg text-center transition-all cursor-pointer ${
                          isMathDisplayBlock
                            ? 'bg-white dark:bg-[#1a2723] text-purple-700 dark:text-purple-300 shadow-xs font-bold'
                            : 'text-gray-500 hover:text-gray-700 dark:hover:text-gray-300'
                        }`}
                      >
                        معادلة مستقلة (سطر كامل $$...$$)
                      </button>
                      <button
                        type="button"
                        onClick={() => setIsMathDisplayBlock(false)}
                        className={`flex-1 py-1.5 px-2 rounded-lg text-center transition-all cursor-pointer ${
                          !isMathDisplayBlock
                            ? 'bg-white dark:bg-[#1a2723] text-purple-700 dark:text-purple-300 shadow-xs font-bold'
                            : 'text-gray-500 hover:text-gray-700 dark:hover:text-gray-300'
                        }`}
                      >
                        صيغة مدمجة داخل النص ($...$)
                      </button>
                    </div>

                    {/* Live KaTeX Rendered Preview */}
                    <div className="p-4 rounded-xl border border-purple-200 dark:border-purple-900/60 bg-purple-50/50 dark:bg-purple-950/20 text-center min-h-[70px] flex items-center justify-center overflow-x-auto">
                      <div
                        className="katex-preview-container max-w-full text-base sm:text-lg"
                        dangerouslySetInnerHTML={{
                          __html: renderKaTeXHtml(mathLatexInput, isMathDisplayBlock),
                        }}
                      />
                    </div>

                    {/* Quick Formula and Symbol Chips */}
                    <div className="space-y-2">
                      <label className="block text-[11px] font-bold text-gray-700 dark:text-gray-300">
                        نماذج ورموز شائعة (انقر للإضافة):
                      </label>

                      {/* Math Operations & Roots */}
                      <div className="flex flex-wrap gap-1">
                        {[
                          { label: 'كسر a/b', code: '\\frac{a}{b}' },
                          { label: 'جذر √x', code: '\\sqrt{x}' },
                          { label: 'جذر نوني', code: '\\sqrt[n]{x}' },
                          { label: 'أس x²', code: 'x^{2}' },
                          { label: 'مؤشر x₁', code: 'x_{1}' },
                          { label: 'ضرب ·', code: '\\cdot' },
                          { label: 'زائد/ناقص ±', code: '\\pm' },
                          { label: 'تقريب ≈', code: '\\approx' },
                        ].map((chip) => (
                          <button
                            key={chip.label}
                            type="button"
                            onClick={() => setMathLatexInput((prev) => (prev ? `${prev} ${chip.code}` : chip.code))}
                            className="px-2 py-1 rounded-lg text-[10px] font-mono font-bold bg-gray-100 dark:bg-[#182622] hover:bg-purple-100 dark:hover:bg-purple-900/50 text-gray-800 dark:text-gray-200 transition-colors cursor-pointer border border-gray-200 dark:border-gray-800"
                          >
                            {chip.label}
                          </button>
                        ))}
                      </div>

                      {/* Calculus & Limits */}
                      <div className="flex flex-wrap gap-1">
                        {[
                          { label: 'تكامل ∫', code: '\\int_{a}^{b} f(x) \\, dx' },
                          { label: 'مجموع ∑', code: '\\sum_{i=1}^{n} x_i' },
                          { label: 'نهاية lim', code: '\\lim_{x \\to 0}' },
                          { label: 'مشتقة dy/dx', code: '\\frac{dy}{dx}' },
                          { label: 'تفاضل جزئي ∂', code: '\\frac{\\partial f}{\\partial x}' },
                          { label: 'لانهاية ∞', code: '\\infty' },
                        ].map((chip) => (
                          <button
                            key={chip.label}
                            type="button"
                            onClick={() => setMathLatexInput((prev) => (prev ? `${prev} ${chip.code}` : chip.code))}
                            className="px-2 py-1 rounded-lg text-[10px] font-mono font-bold bg-gray-100 dark:bg-[#182622] hover:bg-purple-100 dark:hover:bg-purple-900/50 text-gray-800 dark:text-gray-200 transition-colors cursor-pointer border border-gray-200 dark:border-gray-800"
                          >
                            {chip.label}
                          </button>
                        ))}
                      </div>

                      {/* Greek Symbols */}
                      <div className="flex flex-wrap gap-1">
                        {[
                          { label: 'α', code: '\\alpha' },
                          { label: 'β', code: '\\beta' },
                          { label: 'θ', code: '\\theta' },
                          { label: 'π', code: '\\pi' },
                          { label: 'Δ', code: '\\Delta' },
                          { label: 'λ', code: '\\lambda' },
                          { label: 'σ', code: '\\sigma' },
                          { label: 'μ', code: '\\mu' },
                          { label: 'ω', code: '\\omega' },
                        ].map((chip) => (
                          <button
                            key={chip.label}
                            type="button"
                            onClick={() => setMathLatexInput((prev) => (prev ? `${prev} ${chip.code}` : chip.code))}
                            className="px-2 py-1 rounded-lg text-[11px] font-serif font-bold bg-gray-100 dark:bg-[#182622] hover:bg-purple-100 dark:hover:bg-purple-900/50 text-gray-800 dark:text-gray-200 transition-colors cursor-pointer border border-gray-200 dark:border-gray-800"
                          >
                            {chip.label}
                          </button>
                        ))}
                      </div>

                      {/* Famous Formula Presets */}
                      <div className="flex flex-wrap gap-1 pt-1">
                        {[
                          { label: 'E = mc²', code: 'E = m \\cdot c^2' },
                          { label: 'F = m·a', code: 'F = m \\cdot a' },
                          { label: 'قانون فيثاغورس', code: 'a^2 + b^2 = c^2' },
                          { label: 'القانون العام للجذور', code: 'x = \\frac{-b \\pm \\sqrt{b^2 - 4ac}}{2a}' },
                          { label: 'متطابقة فيثاغورس المثلثية', code: '\\sin^2(\\theta) + \\cos^2(\\theta) = 1' },
                        ].map((chip) => (
                          <button
                            key={chip.label}
                            type="button"
                            onClick={() => setMathLatexInput(chip.code)}
                            className="px-2 py-1 rounded-lg text-[10px] font-bold bg-purple-100/60 dark:bg-purple-950/70 hover:bg-purple-200 dark:hover:bg-purple-900 text-purple-900 dark:text-purple-200 transition-colors cursor-pointer border border-purple-200 dark:border-purple-800"
                          >
                            ⚡ {chip.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* LaTeX Input Textarea */}
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="text-[11px] font-bold text-gray-700 dark:text-gray-300">
                          كود الصيغة الرياضية (LaTeX):
                        </label>
                        <button
                          type="button"
                          onClick={() => setMathLatexInput('')}
                          className="text-[10px] text-gray-400 hover:text-red-500 cursor-pointer"
                        >
                          مسح
                        </button>
                      </div>
                      <textarea
                        value={mathLatexInput}
                        onChange={(e) => setMathLatexInput(e.target.value)}
                        placeholder="اكتب كود LaTeX هنا، مثال: \frac{a}{b} أو E = mc^2"
                        rows={3}
                        className="w-full p-2.5 border border-gray-200 dark:border-gray-700 rounded-xl text-xs font-mono bg-gray-50 dark:bg-[#101815] text-gray-900 dark:text-white focus:outline-none focus:border-purple-600 dir-ltr text-left"
                      />
                    </div>

                    <div className="flex items-center justify-end gap-2 pt-2 border-t border-gray-100 dark:border-gray-800">
                      <button
                        type="button"
                        onClick={() => setIsMathModalOpen(false)}
                        className="px-3 py-1.5 rounded-xl text-xs font-semibold text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 cursor-pointer"
                      >
                        إلغاء
                      </button>
                      <button
                        type="button"
                        disabled={!mathLatexInput.trim()}
                        onClick={() => insertLatexToNote(mathLatexInput, isMathDisplayBlock)}
                        className="px-4 py-1.5 rounded-xl text-xs font-bold bg-purple-700 hover:bg-purple-800 text-white transition-colors disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer flex items-center gap-1.5 shadow-sm"
                      >
                        <Sigma className="w-3.5 h-3.5" />
                        <span>إدراج المعادلة في الملاحظة</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}
              <div
                ref={printableNoteRef}
                className="fixed -left-[9999px] top-0 pointer-events-none bg-white text-gray-900 p-8 w-[794px] font-sans"
                dir="rtl"
              >
                {/* Official Academic Header */}
                <div className="flex items-center justify-between border-b-2 border-[#0f766e] pb-3 mb-4">
                  <div>
                    <h1 className="text-xl font-black text-[#0f766e]">منصة المعلم الذكي — Smart Scholar AI</h1>
                    <p className="text-xs text-gray-500 font-medium">بطاقة تدوينات دراسية أكاديمية موثقة</p>
                  </div>
                  <div className="text-left text-xs text-gray-600 space-y-0.5">
                    <div><strong>التاريخ:</strong> {new Date().toLocaleDateString('ar-EG', { dateStyle: 'long' })}</div>
                    <div><strong>الدفتر:</strong> {notebookTitle || 'الدفتر الدراسي'}</div>
                  </div>
                </div>

                {/* Note Title & Tags */}
                <div className="mb-4 bg-teal-50/70 p-3.5 rounded-xl border-r-4 border-[#0f766e]">
                  <h2 className="text-lg font-bold text-teal-950 mb-1">
                    {activeExportNote?.title || newNoteTitle || 'تدوينة دراسية أكاديمية'}
                  </h2>
                  {((activeExportNote?.tags && activeExportNote.tags.length > 0) ||
                    (newNoteTags.trim() && newNoteTags.split(',').length > 0)) && (
                    <div className="flex flex-wrap gap-1.5 mt-2">
                      {(activeExportNote?.tags || newNoteTags.split(',').map((t) => t.trim()).filter(Boolean)).map((tag) => (
                        <span key={tag} className="text-[10px] font-bold px-2 py-0.5 bg-[#0f766e]/10 text-[#0f766e] rounded-md">
                          #{tag}
                        </span>
                      ))}
                    </div>
                  )}
                </div>

                {/* Note Formatted Content including Markdown, KaTeX, and Images */}
                <div className="note-academic-pdf-content text-sm leading-relaxed text-gray-800 space-y-3">
                  <EducationalContent content={activeExportNote?.text || newNoteText || ''} />
                </div>

                {/* Official Academic Footer */}
                <div className="mt-8 pt-3 border-t border-gray-200 flex items-center justify-between text-xs text-gray-400">
                  <span>تم التصدير بواسطة منصة المعلم الذكي للتحصيل الدراسي • صالحة للطباعة والمراجعة</span>
                  <span>صفحة ملخص أكاديمي</span>
                </div>
              </div>

              {/* Notes Filter and Search Bar */}
              {notes.length > 0 && (
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 bg-white dark:bg-[#14201c] p-3 rounded-2xl border border-[#e2e8e5] dark:border-[#22352f]">
                  <div className="relative flex-1">
                    <input
                      type="text"
                      placeholder="بحث في تدوينات وملاحظات الدفتر..."
                      value={notesSearch}
                      onChange={(e) => setNotesSearch(e.target.value)}
                      className="w-full px-3 py-1.5 bg-[#f6f8f7] dark:bg-[#1a2723] border border-[#e2e8e5] dark:border-[#22352f] rounded-xl text-xs focus:outline-none focus:border-[#0f766e]"
                    />
                  </div>

                  {/* Unique Tags Filter */}
                  {(() => {
                    const allTags = Array.from(new Set(notes.flatMap((n) => n.tags || []))).filter(Boolean);
                    if (allTags.length === 0) return null;
                    return (
                      <div className="flex items-center gap-1 overflow-x-auto text-[11px]">
                        <button
                          type="button"
                          onClick={() => setSelectedTagFilter('all')}
                          className={`px-2 py-0.5 rounded-lg font-bold shrink-0 cursor-pointer ${
                            selectedTagFilter === 'all'
                              ? 'bg-[#0f766e] text-white'
                              : 'bg-black/5 dark:bg-white/5 opacity-70'
                          }`}
                        >
                          الكل
                        </button>
                        {allTags.map((tag) => (
                          <button
                            key={tag}
                            type="button"
                            onClick={() => setSelectedTagFilter(tag)}
                            className={`px-2 py-0.5 rounded-lg font-bold shrink-0 cursor-pointer ${
                              selectedTagFilter === tag
                                ? 'bg-[#0f766e] text-white'
                                : 'bg-black/5 dark:bg-white/5 opacity-70'
                            }`}
                          >
                            #{tag}
                          </button>
                        ))}
                      </div>
                    );
                  })()}
                </div>
              )}

              {/* Notes List */}
              {notes.length === 0 ? (
                <div className="bg-white dark:bg-[#14201c] rounded-2xl border border-[#e2e8e5] dark:border-[#22352f] p-8 text-center space-y-3">
                  <div className="w-12 h-12 rounded-full bg-teal-50 dark:bg-teal-950/60 text-[#0f766e] dark:text-[#2dd4bf] flex items-center justify-center mx-auto">
                    <BookOpen className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-[#17201e] dark:text-[#eef7f4]">
                      لا توجد تدوينات دراسية محفوظة بعد في هذا الدفتر
                    </h4>
                    <p className="text-xs text-gray-500 max-w-md mx-auto mt-1">
                      يمكنك حفظ أي تظليل أو اقتباس من قارئ المصادر مباشرة بالنقر على «حفظ في تدوينات الدفتر»، أو إضافة تدوينتك الخاصة الآن.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setIsAddingNote(true)}
                    className="px-4 py-2 bg-[#0f766e] text-white text-xs font-bold rounded-xl hover:bg-[#115e59] inline-flex items-center gap-1.5 shadow-xs cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    <span>إنشاء أول تدوينة دراسية</span>
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {notes
                    .filter((note) => {
                      if (selectedTagFilter !== 'all' && (!note.tags || !note.tags.includes(selectedTagFilter))) {
                        return false;
                      }
                      if (notesSearch.trim()) {
                        const q = notesSearch.toLowerCase();
                        const matchTitle = note.title.toLowerCase().includes(q);
                        const matchText = note.text.toLowerCase().includes(q);
                        const matchTag = note.tags?.some((t) => t.toLowerCase().includes(q));
                        return matchTitle || matchText || matchTag;
                      }
                      return true;
                    })
                    .map((note) => (
                      <div
                        key={note.id}
                        className="bg-white dark:bg-[#14201c] rounded-2xl border border-[#e2e8e5] dark:border-[#22352f] p-4 shadow-xs flex flex-col justify-between gap-3 hover:border-[#0f766e] transition-all"
                      >
                        <div className="space-y-2">
                          <div className="flex items-start justify-between gap-2">
                            <div>
                              <h4 className="font-bold text-xs text-[#17201e] dark:text-[#eef7f4] leading-snug">
                                {note.title}
                              </h4>
                              <span className="text-[10px] text-gray-400 block mt-0.5">
                                {new Date(note.created).toLocaleDateString('ar-EG', {
                                  day: 'numeric',
                                  month: 'short',
                                  year: 'numeric',
                                })}
                              </span>
                            </div>

                            {/* Actions */}
                            <div className="flex items-center gap-1 shrink-0">
                              {onAskAboutNote && (
                                <button
                                  type="button"
                                  onClick={() => onAskAboutNote(note)}
                                  className="p-1.5 rounded-lg bg-purple-50 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 hover:bg-purple-600 hover:text-white transition-colors cursor-pointer"
                                  title="اسأل المعلم الذكي حول هذه التدوينة"
                                >
                                  <Sparkles className="w-3.5 h-3.5" />
                                </button>
                              )}
                              {/* Export note card as PDF via jsPDF */}
                              <button
                                type="button"
                                onClick={() => handleExportNotePdf({
                                  title: note.title,
                                  text: note.text,
                                  tags: note.tags,
                                  createdAt: note.created,
                                })}
                                className="p-1.5 rounded-lg text-gray-500 hover:text-[#0f766e] dark:hover:text-[#2dd4bf] hover:bg-teal-50 dark:hover:bg-teal-950/40 transition-colors cursor-pointer"
                                title="تصدير هذه التدوينة كملف PDF جاهز للطباعة (jsPDF)"
                              >
                                <FileDown className="w-3.5 h-3.5" />
                              </button>

                              {/* Listen to note via TTS */}
                              <button
                                type="button"
                                onClick={() => studySpeechEngine.speak(note.text, note.title)}
                                className="p-1.5 rounded-lg text-gray-500 hover:text-[#0f766e] dark:hover:text-[#2dd4bf] hover:bg-teal-50 dark:hover:bg-teal-950/40 transition-colors cursor-pointer"
                                title="الاستماع للملاحظة صوتياً (TTS)"
                              >
                                <Volume2 className="w-3.5 h-3.5" />
                              </button>

                              <button
                                type="button"
                                onClick={() => {
                                  navigator.clipboard.writeText(`${note.title}\n\n${note.text}`);
                                  setCopiedNoteId(note.id);
                                  setTimeout(() => setCopiedNoteId(null), 2000);
                                }}
                                className="p-1.5 rounded-lg text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors cursor-pointer"
                                title="نسخ نص التدوينة"
                              >
                                {copiedNoteId === note.id ? (
                                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                                ) : (
                                  <Copy className="w-3.5 h-3.5" />
                                )}
                              </button>
                              {onDeleteNote && (
                                <button
                                  type="button"
                                  onClick={() => onDeleteNote(note.id)}
                                  className="p-1.5 rounded-lg text-gray-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/40 transition-colors cursor-pointer"
                                  title="حذف التدوينة"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              )}
                            </div>
                          </div>

                          {/* Tags */}
                          {note.tags && note.tags.length > 0 && (
                            <div className="flex flex-wrap gap-1">
                              {note.tags.map((tag) => (
                                <span
                                  key={tag}
                                  className="text-[10px] font-bold px-2 py-0.5 bg-teal-50 dark:bg-teal-950/60 text-[#0f766e] dark:text-[#2dd4bf] rounded-md"
                                >
                                  #{tag}
                                </span>
                              ))}
                            </div>
                          )}

                          {/* Note Text with Educational Markdown Rendering */}
                          <div className="text-xs text-[#17201e] dark:text-[#eef7f4] leading-relaxed max-h-56 overflow-y-auto bg-[#f8fbfa] dark:bg-[#121b18] p-3.5 rounded-xl border border-black/5 dark:border-white/5">
                            <EducationalContent content={note.text} />
                          </div>
                        </div>

                        <div className="flex items-center justify-between text-[10px] text-gray-400 pt-1 border-t border-black/5 dark:border-white/5">
                          <span>دفتر: {notebookTitle || 'عام'}</span>
                          <span>{note.text.length} حرف</span>
                        </div>
                      </div>
                    ))}
                </div>
              )}
            </div>
          )}

          {/* Tab 2: Quick Memos */}
          {notesSubTab === 'memos' && (
            <div className="bg-white dark:bg-[#14201c] rounded-2xl border border-[#e2e8e5] dark:border-[#22352f] p-5 shadow-xs space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-black/5 dark:border-white/5">
                <div>
                  <h3 className="font-bold text-sm text-[#17201e] dark:text-[#eef7f4]">
                    الملاحظات والتذكيرات الدراسية السريعة
                  </h3>
                  <p className="text-xs text-gray-500 mt-0.5">
                    دوّن أفكارك وخواطرك اللحظية واستفساراتك قبل أن تنساها.
                  </p>
                </div>
                <span className="text-xs font-bold text-[#0f766e] dark:text-[#2dd4bf] bg-teal-50 dark:bg-teal-950/60 px-2.5 py-1 rounded-xl">
                  {memos.length} ملاحظة
                </span>
              </div>

              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (!newMemoText.trim()) return;
                  onAddMemo(newMemoText.trim());
                  setNewMemoText('');
                }}
                className="space-y-2.5"
              >
                <textarea
                  rows={3}
                  placeholder="اكتب فكرة سريعة، استفساراً، أو معلومة هامة للرجوع إليها..."
                  value={newMemoText}
                  onChange={(e) => setNewMemoText(e.target.value)}
                  className="w-full p-3 border border-[#e2e8e5] dark:border-[#22352f] rounded-xl text-xs bg-[#f8fbfa] dark:bg-[#121b18] text-[#17201e] dark:text-[#eef7f4] focus:outline-none focus:border-[#0f766e]"
                />
                <div className="flex justify-end">
                  <button
                    type="submit"
                    className="px-4 py-1.5 bg-[#0f766e] text-white rounded-xl text-xs font-bold hover:bg-[#115e59] shadow-xs cursor-pointer"
                  >
                    حفظ الملاحظة
                  </button>
                </div>
              </form>

              <div className="space-y-2 max-h-96 overflow-y-auto pt-2">
                {memos.length === 0 ? (
                  <p className="text-xs text-gray-400 text-center py-6">
                    لا توجد ملاحظات سريعة مسجلة حالياً.
                  </p>
                ) : (
                  memos.map((memo) => (
                    <div
                      key={memo.id}
                      className="p-3.5 bg-[#f8fbfa] dark:bg-[#121b18] border border-[#e2e8e5] dark:border-[#22352f] rounded-xl flex items-start justify-between gap-3 hover:border-[#0f766e] transition-colors"
                    >
                      <div className="text-xs text-[#17201e] dark:text-[#eef7f4] leading-relaxed whitespace-pre-wrap flex-1">
                        <EducationalContent content={memo.text} />
                      </div>
                      <button
                        type="button"
                        onClick={() => onDeleteMemo(memo.id)}
                        className="text-gray-400 hover:text-red-500 p-1 cursor-pointer"
                        title="حذف الملاحظة"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* Tab 3: Personal Glossary */}
          {notesSubTab === 'glossary' && (
            <div className="bg-white dark:bg-[#14201c] rounded-2xl border border-[#e2e8e5] dark:border-[#22352f] p-5 shadow-xs space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-black/5 dark:border-white/5">
                <div>
                  <h3 className="font-bold text-sm text-[#17201e] dark:text-[#eef7f4]">
                    معجم المصطلحات والمفاهيم الأكاديمية (Glossary)
                  </h3>
                  <p className="text-xs text-gray-500 mt-0.5">
                    احفظ التعريفات الدقيقة والمصطلحات التخصصية لربطها بالخرائط الذهنية واسترجاعها.
                  </p>
                </div>
                <span className="text-xs font-bold text-[#0f766e] dark:text-[#2dd4bf] bg-teal-50 dark:bg-teal-950/60 px-2.5 py-1 rounded-xl">
                  {glossary.length} مصطلح
                </span>
              </div>

              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (!newTerm.trim() || !newDef.trim()) return;
                  onAddGlossary(newTerm.trim(), newDef.trim(), newEx.trim());
                  setNewTerm('');
                  setNewDef('');
                  setNewEx('');
                }}
                className="space-y-2.5"
              >
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <input
                    type="text"
                    placeholder="المصطلح الأكاديمي (مثال: الانتشار الاسموزي)"
                    value={newTerm}
                    onChange={(e) => setNewTerm(e.target.value)}
                    className="p-2.5 border border-[#e2e8e5] dark:border-[#22352f] rounded-xl text-xs bg-[#f8fbfa] dark:bg-[#121b18] text-[#17201e] dark:text-[#eef7f4] focus:outline-none focus:border-[#0f766e]"
                  />
                  <input
                    type="text"
                    placeholder="التعريف العلمي الدقيق"
                    value={newDef}
                    onChange={(e) => setNewDef(e.target.value)}
                    className="p-2.5 border border-[#e2e8e5] dark:border-[#22352f] rounded-xl text-xs bg-[#f8fbfa] dark:bg-[#121b18] text-[#17201e] dark:text-[#eef7f4] focus:outline-none focus:border-[#0f766e]"
                  />
                </div>
                <input
                  type="text"
                  placeholder="مثال تطبيقي أو حالة دراسية (اختياري)"
                  value={newEx}
                  onChange={(e) => setNewEx(e.target.value)}
                  className="w-full p-2.5 border border-[#e2e8e5] dark:border-[#22352f] rounded-xl text-xs bg-[#f8fbfa] dark:bg-[#121b18] text-[#17201e] dark:text-[#eef7f4] focus:outline-none focus:border-[#0f766e]"
                />
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <button
                    type="button"
                    onClick={async () => {
                      try {
                        const items = await generateStudioGlossary({
                          notebookTitle: notebookTitle || 'مقرر دراسي',
                          notebookSubject: notebookSubject || 'المنهج الدراسي',
                          sources,
                          notes,
                          memos,
                          glossary,
                          fallbackConfig,
                        });
                        if (items && items.length > 0) {
                          items.forEach((it) => {
                            onAddGlossary(it.term, it.def, it.ex);
                          });
                          alert(`تم استخراج وإضافة ${items.length} مصطلحات بنجاح من محتوى الدفتر!`);
                        } else {
                          alert('لم يتم استخراج مصطلحات جديدة، يرجى مراجعة محتوى المصادر.');
                        }
                      } catch (e: any) {
                        alert('حدث خطأ أثناء استخراج المصطلحات: ' + (e.message || e));
                      }
                    }}
                    className="px-3 py-1.5 bg-teal-50 dark:bg-teal-950/70 border border-teal-500/40 text-teal-800 dark:text-teal-200 rounded-xl text-xs font-bold hover:bg-teal-100 flex items-center gap-1.5 cursor-pointer shadow-xs"
                    title="استخراج المصطلحات والمفاهيم تلقائياً بالذكاء الاصطناعي من سياق الدفتر"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                    <span>استخراج المصطلحات بالذكاء الاصطناعي</span>
                  </button>

                  <button
                    type="submit"
                    className="px-4 py-1.5 bg-[#0f766e] text-white rounded-xl text-xs font-bold hover:bg-[#115e59] shadow-xs cursor-pointer"
                  >
                    إضافة إلى المعجم
                  </button>
                </div>
              </form>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-96 overflow-y-auto pt-2">
                {glossary.length === 0 ? (
                  <p className="text-xs text-gray-400 text-center col-span-2 py-6">
                    لا توجد مصطلحات في المعجم بعد.
                  </p>
                ) : (
                  glossary.map((item) => (
                    <div
                      key={item.id}
                      className="p-3.5 bg-[#f8fbfa] dark:bg-[#121b18] border border-[#e2e8e5] dark:border-[#22352f] rounded-xl flex items-start justify-between gap-3 hover:border-[#0f766e] transition-colors"
                    >
                      <div>
                        <h4 className="font-bold text-xs text-[#0f766e] dark:text-[#2dd4bf]">
                          {item.term}
                        </h4>
                        <div className="text-xs text-[#17201e] dark:text-[#eef7f4] mt-1 leading-relaxed">
                          <EducationalContent content={item.def} />
                        </div>
                        {item.ex && (
                          <span className="text-[11px] text-gray-500 dark:text-gray-400 mt-1.5 block bg-black/5 dark:bg-white/5 px-2 py-0.5 rounded">
                            💡 مثال: {item.ex}
                          </span>
                        )}
                      </div>
                      <button
                        type="button"
                        onClick={() => onDeleteGlossary(item.id)}
                        className="text-gray-400 hover:text-red-500 p-1 cursor-pointer"
                        title="حذف المصطلح"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Academic Print & PDF Export Modal */}
      {(structuredSummaryData || isAcademicPrintLoading) && (
        <AcademicPrintModal
          isOpen={isAcademicPrintOpen}
          onClose={() => setIsAcademicPrintOpen(false)}
          summary={structuredSummaryData}
          isLoading={isAcademicPrintLoading}
        />
      )}

      {/* Voice-to-Text Reflection & Brainstorming Modal */}
      {isVoiceModalOpen && (
        <div className="fixed inset-0 z-50 p-4 bg-black/60 backdrop-blur-sm flex items-center justify-center animate-in fade-in duration-150">
          <div className="bg-white dark:bg-[#14201c] w-full max-w-lg rounded-3xl p-6 shadow-2xl border-2 border-rose-500/40 dark:border-rose-500/30 space-y-4">
            {/* Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-[#22352f]">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-rose-100 dark:bg-rose-950/80 text-rose-600 flex items-center justify-center">
                  <Mic className="w-5 h-5 animate-pulse" />
                </div>
                <div>
                  <h3 className="font-bold text-sm sm:text-base text-slate-900 dark:text-slate-100 flex items-center gap-2">
                    <span>تسجيل عصف ذهني وتأملات صوتية</span>
                    {isRecordingVoice && (
                      <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping" />
                    )}
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    تحدث بحرية باللغة العربية، وسيتم تحويل كلماتك إلى تدوينة نصية منظمة فورياً.
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  stopVoiceRecording();
                  setIsVoiceModalOpen(false);
                }}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Recording Controls & Visualizer Bar */}
            <div className="p-4 rounded-2xl bg-gradient-to-r from-rose-50/80 via-red-50/50 to-rose-50/80 dark:from-rose-950/30 dark:via-red-950/20 dark:to-rose-950/30 border border-rose-200 dark:border-rose-900/60 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  {isRecordingVoice ? (
                    <button
                      type="button"
                      onClick={stopVoiceRecording}
                      className="px-3.5 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-black text-xs shadow-md transition-all cursor-pointer flex items-center gap-1.5 animate-pulse"
                      title="إنهاء التسجيل وتفريغه فوراً بالذكاء الاصطناعي"
                    >
                      <Square className="w-4 h-4 fill-current" />
                      <span>إنهاء وتفريغ الصوت (Gemini)</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={startVoiceRecording}
                      className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs shadow-md transition-all cursor-pointer flex items-center gap-1.5 active:scale-95"
                    >
                      <Play className="w-4 h-4 fill-current" />
                      <span>{recordedAudioUrl ? 'تسجيل مقطع جديد' : 'بدء تسجيل الصوت'}</span>
                    </button>
                  )}

                  <div>
                    <div className="text-xs font-bold text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
                      <span className={`w-2 h-2 rounded-full ${isRecordingVoice ? 'bg-rose-500 animate-ping' : 'bg-slate-400'}`} />
                      <span>{isRecordingVoice ? 'جاري الاستماع وتسجيل صوتك بدقة...' : recordedAudioUrl ? 'اكتمل التسجيل وجاهز للحفظ' : 'جاهز للتسجيل'}</span>
                    </div>
                    <div className="text-[10px] text-slate-500 font-mono mt-0.5">
                      مدة التسجيل: {Math.floor(voiceDurationSeconds / 60).toString().padStart(2, '0')}:{(voiceDurationSeconds % 60).toString().padStart(2, '0')}
                    </div>
                  </div>
                </div>

                {/* Pulsing Audio Bar Waves */}
                <div className="flex items-center gap-1">
                  {[40, 70, 100, 60, 85, 45, 90, 60].map((h, i) => (
                    <div
                      key={i}
                      className={`w-1 rounded-full transition-all duration-300 ${
                        isRecordingVoice ? 'bg-rose-500' : 'bg-slate-300 dark:bg-slate-700'
                      }`}
                      style={{
                        height: isRecordingVoice ? `${Math.max(8, (h * (voiceDurationSeconds % 3 + 1)) % 28 + 6)}px` : '6px',
                      }}
                    />
                  ))}
                </div>
              </div>

              {/* Playable Recorded Audio Element */}
              {recordedAudioUrl && !isRecordingVoice && (
                <div className="pt-2 border-t border-rose-200/60 dark:border-rose-900/40 space-y-1.5">
                  <div className="flex items-center justify-between text-[11px] font-bold text-slate-700 dark:text-slate-300">
                    <span className="flex items-center gap-1.5 text-teal-700 dark:text-teal-400">
                      <Volume2 className="w-3.5 h-3.5" />
                      <span>المقطع الصوتي المسجل (يمكنك الاستماع والتحقق قبل الحفظ):</span>
                    </span>
                    {recordedAudioBlob && (
                      <button
                        type="button"
                        disabled={isTranscribingWithGemini}
                        onClick={() => transcribeAudioBlobWithGemini(recordedAudioBlob, recordedAudioMime)}
                        className="text-teal-700 dark:text-teal-300 hover:underline flex items-center gap-1 text-[10px] font-bold cursor-pointer disabled:opacity-50"
                      >
                        <RotateCcw className="w-3 h-3" />
                        <span>إعادة التفريغ عبر Gemini</span>
                      </button>
                    )}
                  </div>
                  <audio src={recordedAudioUrl} controls className="w-full h-8 rounded-lg" />
                </div>
              )}
            </div>

            {/* AI Transcription Progress Banner */}
            {isTranscribingWithGemini && (
              <div className="p-3 rounded-2xl bg-teal-50 dark:bg-teal-950/60 border border-teal-200 dark:border-teal-800 flex items-center gap-2.5 text-xs font-bold text-teal-800 dark:text-teal-200 animate-pulse">
                <Loader2 className="w-4 h-4 animate-spin text-teal-600 shrink-0" />
                <span>جارٍ تفريغ المقطع الصوتي وتحويله إلى نص دقيق بواسطة Gemini Audio AI...</span>
              </div>
            )}

            {/* Transcription Error Banner with Retry */}
            {transcriptionError && !isTranscribingWithGemini && (
              <div className="p-3 rounded-2xl bg-amber-50 dark:bg-amber-950/60 border border-amber-200 dark:border-amber-800 flex items-center justify-between gap-2 text-xs text-amber-800 dark:text-amber-200">
                <div className="flex items-center gap-1.5 min-w-0">
                  <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                  <span className="truncate">{transcriptionError}</span>
                </div>
                {recordedAudioBlob && (
                  <button
                    type="button"
                    onClick={() => transcribeAudioBlobWithGemini(recordedAudioBlob, recordedAudioMime)}
                    className="px-2.5 py-1 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-[10px] font-bold shrink-0 cursor-pointer flex items-center gap-1"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>إعادة المحاولة</span>
                  </button>
                )}
              </div>
            )}

            {/* Note Title Input */}
            <div>
              <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-200 mb-1">
                عنوان التدوينة أو جلسة العصف الذهني:
              </label>
              <input
                type="text"
                value={voiceReflectionTitle}
                onChange={(e) => setVoiceReflectionTitle(e.target.value)}
                placeholder="عنوان التدوينة..."
                className="w-full px-3.5 py-2 text-xs rounded-xl border border-slate-200 dark:border-[#22352f] bg-slate-50 dark:bg-[#1a2723] text-slate-800 dark:text-slate-100 focus:outline-none focus:border-rose-500"
              />
            </div>

            {/* Live Transcript Box */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-200">
                  النص المفرغ من صوتك (قابل للتعديل):
                </label>
                {voiceTranscript.trim() && (
                  <button
                    type="button"
                    onClick={handleFormatVoiceTranscriptWithAI}
                    disabled={isFormattingTranscript}
                    className="text-[10px] font-bold text-teal-700 dark:text-teal-300 hover:underline flex items-center gap-1 cursor-pointer disabled:opacity-40"
                  >
                    {isFormattingTranscript ? <Loader2 className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3 text-teal-600" />}
                    <span>تنظيم وهيكلة بالذكاء الاصطناعي</span>
                  </button>
                )}
              </div>

              <textarea
                value={voiceTranscript + (interimTranscript ? ` ${interimTranscript}` : '')}
                onChange={(e) => setVoiceTranscript(e.target.value)}
                placeholder="تحدث الآن وسيقوم النظام بتفريغ صوتك إلى نص هنا بشكل فوري..."
                rows={5}
                className="w-full p-3 text-xs rounded-xl border border-slate-200 dark:border-[#22352f] bg-slate-50 dark:bg-[#1a2723] text-slate-800 dark:text-slate-100 focus:outline-none focus:border-rose-500 resize-none leading-relaxed"
              />
            </div>

            {/* Actions */}
            <div className="flex items-center justify-end gap-2.5 pt-2 border-t border-slate-100 dark:border-[#22352f]">
              <button
                type="button"
                onClick={() => {
                  stopVoiceRecording();
                  setIsVoiceModalOpen(false);
                }}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-[#1a2723] transition-colors cursor-pointer"
              >
                إلغاء
              </button>

              <button
                type="button"
                onClick={handleSaveVoiceAsNote}
                disabled={!voiceTranscript.trim() && !interimTranscript.trim()}
                className="px-5 py-2.5 bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 text-white rounded-xl text-xs font-bold shadow-md shadow-teal-600/20 transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-40"
              >
                <Check className="w-4 h-4" />
                <span>تحويل إلى تدوينة دراسية وحفظ</span>
              </button>
            </div>
          </div>
        </div>
      )}
      {/* Interactive Speech Controller Dock (Text-to-Speech) */}
      <StudySpeechController />
    </div>
  );
};
