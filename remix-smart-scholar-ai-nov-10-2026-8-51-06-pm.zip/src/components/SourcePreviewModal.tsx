import React from 'react';
import { 
  X, 
  BookOpen, 
  FileText, 
  Globe, 
  Download, 
  Volume2, 
  Heart, 
  ExternalLink, 
  Clock, 
  Hash,
  ChevronLeft,
  Sparkles
} from 'lucide-react';
import { Source } from '../types';
import { exportSourceToPdf } from '../lib/sourcePdfExporter';
import { speakText } from '../lib/TextToSpeechService';

interface SourcePreviewModalProps {
  source: Source | null;
  isOpen: boolean;
  onClose: () => void;
  onOpenFullReader: (source: Source) => void;
  isFavorite: boolean;
  onToggleFavorite: (sourceId: string) => void;
  notebookName?: string;
}

export const SourcePreviewModal: React.FC<SourcePreviewModalProps> = ({
  source,
  isOpen,
  onClose,
  onOpenFullReader,
  isFavorite,
  onToggleFavorite,
  notebookName,
}) => {
  if (!isOpen || !source) return null;

  const previewSnippet = source.content.slice(0, 500);
  const totalLength = source.content.length;
  const wordCount = source.wordCount || source.content.split(/\s+/).filter(Boolean).length;
  const isTruncated = totalLength > 500;

  const handleExportPdf = () => {
    try {
      exportSourceToPdf(source, notebookName);
    } catch (err) {
      alert('حدث خطأ أثناء تصدير ملف PDF للمرجع.');
    }
  };

  const handleSpeak = () => {
    speakText(source.content, {
      title: `قراءة: ${source.title}`,
    });
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200"
      dir="rtl"
    >
      <div 
        className="relative w-full max-w-2xl bg-white dark:bg-[#14201c] rounded-3xl shadow-2xl border border-teal-100 dark:border-teal-900/50 overflow-hidden flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-100 dark:border-[#22352f] bg-slate-50/50 dark:bg-[#182622]/50">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-2xl bg-teal-600/10 dark:bg-teal-400/10 text-teal-700 dark:text-teal-300 flex items-center justify-center shrink-0">
              {source.type === 'wikipedia' ? (
                <Globe className="w-5 h-5" />
              ) : source.type === 'pdf' ? (
                <FileText className="w-5 h-5 text-rose-600" />
              ) : (
                <BookOpen className="w-5 h-5" />
              )}
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider bg-teal-100 dark:bg-teal-950 text-teal-800 dark:text-teal-200">
                  {source.type === 'wikipedia' ? 'ويكيبيديا' : source.type}
                </span>
                {notebookName && (
                  <span className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                    {notebookName}
                  </span>
                )}
              </div>
              <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 truncate mt-0.5">
                {source.title}
              </h3>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            {/* Favorite button */}
            <button
              type="button"
              onClick={() => onToggleFavorite(source.id)}
              className={`w-9 h-9 rounded-xl flex items-center justify-center transition cursor-pointer ${
                isFavorite
                  ? 'bg-rose-50 text-rose-600 dark:bg-rose-950/40 dark:text-rose-400'
                  : 'text-slate-400 hover:text-rose-600 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
              title={isFavorite ? 'إزالة من المفضلة' : 'إضافة للمفضلة'}
            >
              <Heart className={`w-4 h-4 ${isFavorite ? 'fill-current' : ''}`} />
            </button>

            {/* Close button */}
            <button
              type="button"
              onClick={onClose}
              className="w-9 h-9 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Metadata Strip */}
        <div className="px-5 py-2.5 bg-teal-500/5 border-b border-teal-500/10 flex flex-wrap items-center gap-4 text-xs text-slate-600 dark:text-slate-300">
          <div className="flex items-center gap-1.5">
            <Hash className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
            <span>{wordCount.toLocaleString('ar-EG')} كلمة</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
            <span>{new Date(source.createdAt).toLocaleDateString('ar-EG')}</span>
          </div>
          {source.uri && (
            <a
              href={source.uri}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1 text-teal-600 dark:text-teal-400 hover:underline mr-auto"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>الرابط الأصلي</span>
            </a>
          )}
        </div>

        {/* 500-Character Preview Section */}
        <div className="p-6 overflow-y-auto flex-1">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-teal-800 dark:text-teal-300 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
              معاينة سريعة (أول 500 حرف):
            </span>
            <span className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">
              500 / {totalLength.toLocaleString('ar-EG')} حرف
            </span>
          </div>

          <div className="relative rounded-2xl bg-slate-50 dark:bg-[#182622] p-4 border border-slate-200 dark:border-slate-800 text-sm leading-relaxed text-slate-700 dark:text-slate-200 whitespace-pre-wrap font-sans select-text">
            {previewSnippet}
            {isTruncated && (
              <span className="text-teal-600 dark:text-teal-400 font-bold"> ... [المزيد]</span>
            )}

            {isTruncated && (
              <div className="absolute inset-x-0 bottom-0 h-16 bg-gradient-to-t from-slate-50 dark:from-[#182622] to-transparent pointer-events-none rounded-b-2xl" />
            )}
          </div>
        </div>

        {/* Actions Footer */}
        <div className="p-4 border-t border-slate-100 dark:border-[#22352f] bg-slate-50/50 dark:bg-[#182622]/50 flex flex-wrap items-center justify-between gap-2.5">
          <div className="flex items-center gap-2">
            {/* Speak audio */}
            <button
              type="button"
              onClick={handleSpeak}
              className="px-3.5 py-2 rounded-xl text-xs font-bold bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-800 hover:bg-teal-100 dark:hover:bg-teal-900 transition flex items-center gap-1.5 cursor-pointer shadow-xs"
              title="الاستماع للمرجع كاملاً"
            >
              <Volume2 className="w-4 h-4" />
              <span>استماع صوتي</span>
            </button>

            {/* Export PDF */}
            <button
              type="button"
              onClick={handleExportPdf}
              className="px-3.5 py-2 rounded-xl text-xs font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 transition flex items-center gap-1.5 cursor-pointer shadow-xs"
              title="تصدير المرجع كملف PDF"
            >
              <Download className="w-4 h-4" />
              <span>تصدير PDF</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
            >
              إلغاء
            </button>

            {/* Read More Button */}
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenFullReader(source);
              }}
              className="px-5 py-2 rounded-xl text-xs font-black bg-teal-600 hover:bg-teal-700 text-white transition flex items-center gap-1.5 cursor-pointer shadow-md shadow-teal-700/20"
            >
              <span>قراءة المزيد</span>
              <ChevronLeft className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
