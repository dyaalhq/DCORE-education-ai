import React, { useState, useMemo, useEffect, useRef } from 'react';
import {
  GraduationCap,
  Stethoscope,
  Globe2,
  Search,
  BookOpen,
  Filter,
  CheckCircle2,
  XCircle,
  Clock,
  Sparkles,
  Share2,
  FileQuestion,
  HelpCircle,
  Award,
  ChevronRight,
  ChevronLeft,
  RotateCcw,
  Play,
  Bookmark,
  BookmarkCheck,
  Check,
  Copy,
  BrainCircuit,
  Send,
  Zap,
  Info,
  Layers,
  Compass,
  ArrowRight,
  X,
  Atom,
  FlaskConical,
  Dna,
  Calculator,
  Languages,
  Landmark,
  MapPin,
  HeartPulse,
  Folder,
  FolderOpen,
  FileText
} from 'lucide-react';
import {
  BankQuestion,
  QuestionSection,
  QuestionType,
  DifficultyLevel,
  MINISTERIAL_SUBJECTS,
  SUBJECT_UNITS_MAP,
  MEDICAL_BLOCKS,
  UNIVERSAL_CATEGORIES,
  QUESTION_BANK_DATABASE,
  filterQuestionBank,
  generateExamSimulation,
  solveAcademicallyOffline
} from '../lib/questionBankData';
import { SafeMathText } from './SafeMathText';
import { EncyclopedicChat } from './EncyclopedicChat';
import { EncyclopedicReader } from './EncyclopedicReader';
import {
  initializeOfflineDatabase,
  generateSyntheticAcademicQuestions,
  populateAndSaveQuestionsToIndexedDB,
  isCorruptedQuestion,
  cleanAndSanitizeCorruptedQuestions
} from '../lib/massiveQuestionGenerator';
import {
  generateYemeniLiteraryQuestions,
  generateYemeniPhysicsQuestions,
  generateYemeniChemistryQuestions,
  generateYemeniBiologyQuestions,
  generateYemeniMathQuestions,
  generateYemeniArabicAndIslamicQuestions,
  generateYemeniGrade9ScienceQuestions,
  generateYemeniGrade9SocialQuestions
} from '../lib/yemeniQuestionsEngine';
import { offlineDb, recordExamAttempt, EncyclopediaArticle } from '../lib/offlineDatabase';
import { searchEncyclopediaOffline, createDynamicWikipediaArticle } from '../lib/encyclopediaData';
import { backgroundSync } from '../lib/backgroundSync';
import { SupportedLanguage } from '../lib/i18n';
import { QuizResult, Source, SourceChunk } from '../types';

interface QuestionBankViewProps {
  onAskAboutQuestion?: (text: string) => void;
  onExportToNote?: (title: string, content: string) => void;
  onNavigateHome?: () => void;
  currentLang?: SupportedLanguage;
  onRecordExamQuiz?: (quiz: QuizResult) => void;
  sources?: Source[];
  quizzes?: QuizResult[];
  chunks?: SourceChunk[];
}

const OPTION_LETTERS = ['أ', 'ب', 'ج', 'د', 'هـ'];

export function inferStageForSubject(subject: string): 'تاسع أساسي' | 'ثالث ثانوي علمي' | 'ثالث ثانوي أدبي' {
  if (['التاريخ الحديث', 'الجغرافيا', 'الفلسفة وعلم النفس', 'التاريخ'].includes(subject)) {
    return 'ثالث ثانوي أدبي';
  }
  if (['العلوم', 'الاجتماعيات'].includes(subject)) {
    return 'تاسع أساسي';
  }
  if (['الفيزياء', 'الكيمياء', 'الأحياء', 'الرياضيات (تفاضل وتكامل وجبر)'].includes(subject)) {
    return 'ثالث ثانوي علمي';
  }
  return 'ثالث ثانوي علمي';
}

/**
 * Calculates similarity between two question texts based on token overlap (Jaccard + Bigram overlap)
 * with numerical normalization (masking digits to prevent trivial number change duplicates).
 */
export function calculateContentSimilarity(textA: string, textB: string): number {
  if (!textA || !textB) return 0;
  
  const normalize = (t: string) =>
    t
      .toLowerCase()
      .replace(/[0-9٠-٩]+(?:\.[0-9٠-٩]+)?/g, '#NUM#')
      .replace(/[^\p{L}\p{N}#]/gu, ' ')
      .replace(/\s+/g, ' ')
      .trim();

  const normA = normalize(textA);
  const normB = normalize(textB);

  if (normA === normB) return 1.0;

  const wordsA = normA.split(' ').filter((w) => w.length > 2);
  const wordsB = normB.split(' ').filter((w) => w.length > 2);

  if (wordsA.length === 0 || wordsB.length === 0) return 0;

  const setA = new Set(wordsA);
  const setB = new Set(wordsB);

  let intersection = 0;
  for (const w of setA) {
    if (setB.has(w)) intersection++;
  }
  const union = new Set([...wordsA, ...wordsB]).size;
  const jaccard = union > 0 ? intersection / union : 0;

  const getBigrams = (words: string[]) => {
    const bg: string[] = [];
    for (let i = 0; i < words.length - 1; i++) {
      bg.push(`${words[i]}_${words[i + 1]}`);
    }
    return bg;
  };

  const bgA = new Set(getBigrams(wordsA));
  const bgB = new Set(getBigrams(wordsB));

  let bgIntersection = 0;
  for (const b of bgA) {
    if (bgB.has(b)) bgIntersection++;
  }
  const bgUnion = new Set([...bgA, ...bgB]).size;
  const bgScore = bgUnion > 0 ? bgIntersection / bgUnion : 0;

  return jaccard * 0.5 + bgScore * 0.5;
}

/**
 * Filters candidate generated questions, rejecting any with similarity >= 0.65 (65%)
 * against existing questions in the database to guarantee 100% genuine diversity and zero repetition.
 */
export function filterCandidateQuestionsForUniqueness(
  candidates: BankQuestion[],
  existingQuestions: BankQuestion[],
  threshold = 0.65
): { uniqueQuestions: BankQuestion[]; rejectedCount: number } {
  const uniqueQuestions: BankQuestion[] = [];
  let rejectedCount = 0;

  for (const cand of candidates) {
    const poolToCompare = [
      ...existingQuestions.filter((q) => q.subject === cand.subject || q.section === cand.section),
      ...uniqueQuestions
    ];

    let isDuplicate = false;
    for (const ex of poolToCompare) {
      const sim = calculateContentSimilarity(cand.question, ex.question);
      if (sim >= threshold) {
        isDuplicate = true;
        break;
      }
    }

    if (!isDuplicate) {
      uniqueQuestions.push(cand);
    } else {
      rejectedCount++;
    }
  }

  return { uniqueQuestions, rejectedCount };
}

const INITIAL_SYNCHRONOUS_POOL: BankQuestion[] = (() => {
  const seeds: BankQuestion[] = [...QUESTION_BANK_DATABASE];
  try {
    seeds.push(
      ...generateYemeniLiteraryQuestions(35, 'التاريخ الحديث'),
      ...generateYemeniLiteraryQuestions(35, 'الجغرافيا'),
      ...generateYemeniLiteraryQuestions(35, 'الفلسفة وعلم النفس'),
      ...generateYemeniPhysicsQuestions(35, 'ثالث ثانوي علمي'),
      ...generateYemeniChemistryQuestions(35, 'ثالث ثانوي علمي'),
      ...generateYemeniBiologyQuestions(35, 'ثالث ثانوي علمي'),
      ...generateYemeniMathQuestions(35, 'ثالث ثانوي علمي'),
      ...generateYemeniGrade9ScienceQuestions(35),
      ...generateYemeniGrade9SocialQuestions(35),
      ...generateYemeniArabicAndIslamicQuestions(35, 'اللغة العربية'),
      ...generateYemeniArabicAndIslamicQuestions(35, 'القرآن والإسلامية')
    );
  } catch (err) {
    console.warn('Initial procedural seed warning:', err);
  }
  return seeds.filter((q) => !isCorruptedQuestion(q));
})();

export const QuestionBankView: React.FC<QuestionBankViewProps> = ({
  onAskAboutQuestion,
  onExportToNote,
  onNavigateHome,
  currentLang,
  onRecordExamQuiz,
  sources = [],
  quizzes = [],
  chunks = [],
}) => {
  // Active Portal Navigation State: 'hub' (master directory) | 'ministerial' | 'medical' | 'universal'
  const [activePortal, setActivePortal] = useState<'hub' | 'ministerial' | 'medical' | 'universal'>('hub');

  // Active Recall Quiz States
  const [isActiveRecallOpen, setIsActiveRecallOpen] = useState(false);
  const [activeRecallQuestions, setActiveRecallQuestions] = useState<Array<{
    id: string;
    question: string;
    options: string[];
    correctAnswer: number;
    explanation: string;
    sourceChunkTitle?: string;
    chunkSnippet?: string;
  }>>([]);
  const [activeRecallCurrentIndex, setActiveRecallCurrentIndex] = useState(0);
  const [activeRecallAnswers, setActiveRecallAnswers] = useState<Record<number, number>>({});
  const [activeRecallIsFinished, setActiveRecallIsFinished] = useState(false);
  const [activeRecallScore, setActiveRecallScore] = useState(0);
  const [activeRecallGenerating, setActiveRecallGenerating] = useState(false);

  // Main Tab: ministerial | medical | universal
  const [activeSection, setActiveSection] = useState<QuestionSection>('ministerial');

  // Hierarchical Drill-down Navigation States
  // Ministerial Flow: Stage Selection ('stage_select') -> Subject Selection ('subject_select') -> Unit Selection ('unit_select') -> Practice/Questions ('questions')
  const [ministerialStep, setMinisterialStep] = useState<'stage_select' | 'subject_select' | 'unit_select' | 'questions'>('stage_select');
  // Medical Flow: Block Selection ('block_select') -> Practice/Questions ('questions')
  const [medicalStep, setMedicalStep] = useState<'block_select' | 'questions'>('block_select');

  // Ministerial State (Strict Subject Isolation)
  const [ministerialStage, setMinisterialStage] = useState<'تاسع أساسي' | 'ثالث ثانوي علمي' | 'ثالث ثانوي أدبي'>('ثالث ثانوي علمي');
  const [selectedSubject, setSelectedSubject] = useState<string>('الفيزياء');
  const [selectedUnit, setSelectedUnit] = useState<string>('كافة الوحدات والدروس');
  const [selectedYear, setSelectedYear] = useState<string>('الكل');

  // Medical State (Strict Block Isolation)
  const [selectedBlock, setSelectedBlock] = useState<string>('Cardiovascular System (CVS)');
  const [medicalLang, setMedicalLang] = useState<'bilingual' | 'en' | 'ar'>('bilingual');

  // Universal State (Strictly Open Encyclopedic Chat & Reader - ZERO quizzes)
  const [selectedCategory, setSelectedCategory] = useState<string>('الفيزياء والكونيات');
  const [universalSubView, setUniversalSubView] = useState<'chat' | 'encyclopedia'>('encyclopedia');
  const [universalQueryInput, setUniversalQueryInput] = useState<string>('');
  const [universalQueryResult, setUniversalQueryResult] = useState<ReturnType<typeof solveAcademicallyOffline> | null>(null);
  const [isSolvingQuery, setIsSolvingQuery] = useState(false);

  // Stage change handler enforcing subject synchronization
  const handleStageChange = (newStage: 'تاسع أساسي' | 'ثالث ثانوي علمي' | 'ثالث ثانوي أدبي') => {
    setMinisterialStage(newStage);
    setSelectedUnit('كافة الوحدات والدروس');
    if (newStage === 'تاسع أساسي') {
      setSelectedSubject(MINISTERIAL_SUBJECTS.grade9[0]);
    } else if (newStage === 'ثالث ثانوي علمي') {
      setSelectedSubject(MINISTERIAL_SUBJECTS.sec3_sci[0]);
    } else {
      setSelectedSubject(MINISTERIAL_SUBJECTS.sec3_lit[0]);
    }
  };

  // Safe subject change handler with automatic stage alignment
  const handleSubjectChange = (newSubject: string) => {
    setSelectedSubject(newSubject);
    setMinisterialStage(inferStageForSubject(newSubject));
    setSelectedUnit('كافة الوحدات والدروس');
  };

  // IndexedDB & Massive Generator State
  const [indexedDbReady, setIndexedDbReady] = useState(false);
  const [totalIndexedQuestions, setTotalIndexedQuestions] = useState(INITIAL_SYNCHRONOUS_POOL.length);
  const [allQuestionsPool, setAllQuestionsPool] = useState<BankQuestion[]>(INITIAL_SYNCHRONOUS_POOL);
  const [isGeneratingMassive, setIsGeneratingMassive] = useState(false);
  const [generatorToast, setGeneratorToast] = useState('');

  // Common Filter State
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [difficultyFilter, setDifficultyFilter] = useState<DifficultyLevel | 'all'>('all');
  const [typeFilter, setTypeFilter] = useState<QuestionType | 'all'>('all');

  // Mode: 'practice' | 'exam'
  const [mode, setMode] = useState<'practice' | 'exam'>('practice');

  // Practice State: answers selected by questionId
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, number | string>>({});
  const [revealedExplanations, setRevealedExplanations] = useState<Record<string, boolean>>({});

  // Bookmarks (saved in localStorage)
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('yemeni_qb_bookmarks');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [showBookmarksOnly, setShowBookmarksOnly] = useState(false);

  // Student Mastery Index (مستوى إتقان الطالب الذكي)
  const [isAdaptiveMasteryActive, setIsAdaptiveMasteryActive] = useState<boolean>(false);

  const studentMastery = useMemo(() => {
    const matching = (quizzes || []).filter((q) => {
      const title = (q.title || '').toLowerCase();
      if (activeSection === 'ministerial') {
        return title.includes(selectedSubject.toLowerCase());
      }
      return title.includes('طب') || title.includes(selectedBlock.toLowerCase());
    });

    if (matching.length === 0) {
      return { percentage: 70, level: 'متوسط' as const, count: 0 };
    }

    const totalScored = matching.reduce((acc, q) => acc + (q.score / Math.max(1, q.count)), 0);
    const avgScore = Math.round((totalScored / matching.length) * 100);
    const clamped = Math.min(100, Math.max(0, avgScore));

    let level: 'مبتدئ' | 'متوسط' | 'متقدم' = 'متوسط';
    if (clamped < 55) level = 'مبتدئ';
    else if (clamped >= 75) level = 'متقدم';

    return { percentage: clamped, level, count: matching.length };
  }, [quizzes, selectedSubject, selectedBlock, activeSection]);

  // Generative AI Question Generator from Student Notebook Sources
  const [isSourceGenModalOpen, setIsSourceGenModalOpen] = useState(false);
  const [selectedSourceIdForGen, setSelectedSourceIdForGen] = useState<string>('');
  const [sourceGenCount, setSourceGenCount] = useState<number>(5);
  const [sourceGenDifficulty, setSourceGenDifficulty] = useState<DifficultyLevel>('medium');
  const [isGeneratingFromSource, setIsGeneratingFromSource] = useState(false);
  const [sourceGenToast, setSourceGenToast] = useState('');

  const handleGenerateFromSource = async () => {
    const src = sources.find((s) => s.id === selectedSourceIdForGen);
    if (!src || !src.content) {
      setSourceGenToast('يرجى اختيار مصدر يحتوي على نص دراسي كافٍ');
      return;
    }

    setIsGeneratingFromSource(true);
    setSourceGenToast(`جارٍ استخراج وتوليد ${sourceGenCount} أسئلة وزارية معتمدة من المصدر «${src.title}»...`);

    const prompt = `أنت الموجه الأول للجان الامتحانات الوزارية اليمنية والأكاديمية والطبية.
استخرج من محتوى المصدر الدراسي التالي عدد ${sourceGenCount} أسئلة اختبارات وزارية دقيقة واحترافية بدون أي تكرار وبأعلى معايير الدقة العلمية وصياغة الخيارات المتوازنة:

سياق المصدر:
العنوان: ${src.title}
المحتوى:
${src.content.slice(0, 4500)}

الشروط الصارمة:
1. نسق الإجابة بصيغة مصفوفة JSON نقية ومباشرة بدون أي أحرف أو علامات خارج المصفوفة:
[
  {
    "question": "نص السؤال الدقيق مع صياغة معادلات LaTeX داخل $...$ إن وجدت",
    "options": ["الخيار الأول", "الخيار الثاني", "الخيار الثالث", "الخيار الرابع"],
    "correctAnswer": 0,
    "explanation": "شرح نموذجي وتفصيلي مع ذكر القوانين الحاكمة",
    "difficulty": "${sourceGenDifficulty}",
    "type": "mcq",
    "subject": "${selectedSubject}",
    "unitOrTopic": "${src.title.slice(0, 30)}",
    "stage": "${ministerialStage}",
    "year": "2026 توليدي من المصادر"
  }
]`;

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt,
          mode: 'json',
          jsonMode: true,
        }),
      });

      if (!response.ok) throw new Error('فشل التوليد من الذكاء الاصطناعي');
      const data = await response.json();
      let text = data.text || '';
      text = text.replace(/```json\n?|\n?```/g, '').trim();
      const parsed = JSON.parse(text);

      if (Array.isArray(parsed) && parsed.length > 0) {
        const freshQuestions: BankQuestion[] = parsed.map((item, idx) => ({
          id: `source_gen_${Date.now()}_${idx}`,
          section: activeSection,
          stage: activeSection === 'ministerial' ? ministerialStage : undefined,
          subject: activeSection === 'ministerial' ? selectedSubject : 'طب عام',
          unitOrTopic: item.unitOrTopic || src.title,
          year: item.year || '2026 توليدي من المصادر',
          type: 'mcq',
          difficulty: (item.difficulty as DifficultyLevel) || sourceGenDifficulty,
          question: item.question,
          options: Array.isArray(item.options) ? item.options : ['أ', 'ب', 'ج', 'د'],
          correctAnswer: typeof item.correctAnswer === 'number' ? item.correctAnswer : 0,
          explanation: item.explanation || 'تم توليد السؤال وفق المعايير الوزارية من المصدر.',
          tags: [activeSection, selectedSubject, 'توليدي_من_المصادر', src.title.slice(0, 20)],
          clinicalContext: activeSection === 'medical' ? {
            scenarioAr: item.question,
            highYieldConcept: src.title,
          } : undefined
        }));

        try {
          await offlineDb.questions.bulkPut(freshQuestions);
        } catch (dbErr) {
          console.warn('Could not save generated questions to IndexedDB:', dbErr);
        }

        setAllQuestionsPool((prev) => [...freshQuestions, ...prev]);
        setTotalIndexedQuestions((prev) => prev + freshQuestions.length);
        setIsSourceGenModalOpen(false);
        setSourceGenToast('');
        setVisibleCount(30);
      } else {
        throw new Error('لم يرجع النموذج مصفوفة أسئلة صالحة');
      }
    } catch (err: any) {
      console.warn('Source question generation error:', err);
      setSourceGenToast('تعذر توليد الأسئلة حالياً. يرجى التأكد من نص المصدر والمحاولة مجدداً.');
    } finally {
      setIsGeneratingFromSource(false);
    }
  };
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Exam Simulation State & Infinite Round Engine
  const [examRound, setExamRound] = useState<number>(1);
  const [examBatchSize, setExamBatchSize] = useState<number>(30); // 30 by default, 40 or 20 selectable
  const [seenExamQuestionIds, setSeenExamQuestionIds] = useState<string[]>([]);
  const [isExamRunning, setIsExamRunning] = useState(false);
  const [examQuestions, setExamQuestions] = useState<BankQuestion[]>([]);
  const [currentExamIndex, setCurrentExamIndex] = useState(0);
  const [examAnswers, setExamAnswers] = useState<Record<string, number | string>>({});
  const [examTimeLimitMins, setExamTimeLimitMins] = useState(30);
  const [examTimeLeftSeconds, setExamTimeLeftSeconds] = useState(30 * 60);
  const [isExamFinished, setIsExamFinished] = useState(false);
  const [viewingWikiArticle, setViewingWikiArticle] = useState<EncyclopediaArticle | null>(null);

  // Initialize Dexie IndexedDB on component mount, sanitize cross-contamination, & load clean entries
  useEffect(() => {
    let isMounted = true;
    (async () => {
      try {
        // Automatically purge any corrupt, cross-contaminated or duplicate questions from older runs
        await cleanAndSanitizeCorruptedQuestions();
        const res = await initializeOfflineDatabase();
        if (!isMounted) return;
        setIndexedDbReady(true);
        const dbQuestions = await offlineDb.questions.toArray();
        const cleanQuestions = (dbQuestions || []).filter((q) => !isCorruptedQuestion(q));
        // Always merge IndexedDB with INITIAL_SYNCHRONOUS_POOL so no subject is ever empty
        const dbIdSet = new Set(cleanQuestions.map((q) => q.id));
        const mergedPool = [...cleanQuestions, ...INITIAL_SYNCHRONOUS_POOL.filter((q) => !dbIdSet.has(q.id))];
        setAllQuestionsPool(mergedPool);
        setTotalIndexedQuestions(mergedPool.length);
      } catch (err) {
        console.warn('Error fetching questions from IndexedDB:', err);
      }
    })();
    return () => { isMounted = false; };
  }, []);

  // Automatic Replenishment: Ensure the currently selected subject/block always has at least 1,000+ questions
  // Initial background cleanup and unique question indexing
  useEffect(() => {
    let isMounted = true;
    const cleanAndSync = async () => {
      try {
        const purged = await cleanAndSanitizeCorruptedQuestions();
        if (purged > 0) {
          console.log(`Cleaned ${purged} duplicates/corrupted questions from storage.`);
        }
        const allDb = await offlineDb.questions.toArray();
        const cleanPool = allDb.filter((q) => !isCorruptedQuestion(q));
        const dbIdSet = new Set(cleanPool.map((q) => q.id));
        const merged = [...cleanPool, ...INITIAL_SYNCHRONOUS_POOL.filter((q) => !dbIdSet.has(q.id))];
        if (isMounted && merged.length > 0) {
          setAllQuestionsPool(merged);
          setTotalIndexedQuestions(merged.length);
        }
      } catch (e) {
        console.warn('Background cleanup check:', e);
      }
    };

    cleanAndSync();
    return () => { isMounted = false; };
  }, []);

  // Automatic Replenishment: Ensure the currently selected subject always has rich verified questions
  useEffect(() => {
    if (activeSection !== 'ministerial') return;
    const correctStage = inferStageForSubject(selectedSubject);
    if (ministerialStage !== correctStage) {
      setMinisterialStage(correctStage);
    }

    const currentSubjectCount = allQuestionsPool.filter(
      (q) => q.section === 'ministerial' &&
        (q.subject === selectedSubject || (selectedSubject.includes('تاريخ') && q.subject.includes('تاريخ'))) &&
        !isCorruptedQuestion(q)
    ).length;

    if (currentSubjectCount < 20 && !isGeneratingMassive) {
      let newQuestions: BankQuestion[] = [];
      if (correctStage === 'ثالث ثانوي أدبي') {
        newQuestions = generateYemeniLiteraryQuestions(35, selectedSubject);
      } else if (correctStage === 'تاسع أساسي') {
        if (selectedSubject.includes('علوم')) {
          newQuestions = generateYemeniGrade9ScienceQuestions(35);
        } else if (selectedSubject.includes('اجتماعيات')) {
          newQuestions = generateYemeniGrade9SocialQuestions(35);
        } else {
          newQuestions = generateYemeniArabicAndIslamicQuestions(35, selectedSubject);
        }
      } else {
        // ثالث ثانوي علمي
        if (selectedSubject.includes('فيزياء')) {
          newQuestions = generateYemeniPhysicsQuestions(35, correctStage);
        } else if (selectedSubject.includes('كيمياء')) {
          newQuestions = generateYemeniChemistryQuestions(35, correctStage);
        } else if (selectedSubject.includes('أحياء')) {
          newQuestions = generateYemeniBiologyQuestions(35, correctStage);
        } else if (selectedSubject.includes('رياضيات')) {
          newQuestions = generateYemeniMathQuestions(35, correctStage);
        } else {
          newQuestions = generateYemeniArabicAndIslamicQuestions(35, selectedSubject);
        }
      }

      if (newQuestions.length > 0) {
        setAllQuestionsPool((prev) => [...prev, ...newQuestions]);
        setTotalIndexedQuestions((prev) => prev + newQuestions.length);
        offlineDb.questions.bulkPut(newQuestions).catch(() => {});
      }
    }
  }, [activeSection, ministerialStage, selectedSubject, isGeneratingMassive]);

  const handleGenerateMassiveQuestions = async (count: number = 1000) => {
    setIsGeneratingMassive(true);
    setGeneratorToast(`جارٍ توليد وتدقيق وحفظ ${count.toLocaleString()} سؤال أكاديمي معتمد لهذا القسم في قاعدة بيانات IndexedDB المحلية...`);
    try {
      const targetSubj = selectedSubject && selectedSubject !== 'الكل'
        ? selectedSubject
        : activeSection === 'ministerial'
        ? (ministerialStage === 'ثالث ثانوي علمي' ? 'الفيزياء' : ministerialStage === 'ثالث ثانوي أدبي' ? 'التاريخ الحديث' : 'العلوم')
        : selectedBlock || 'Cardiovascular System (CVS)';

      const newBatch = generateSyntheticAcademicQuestions({
        section: activeSection,
        subject: targetSubj,
        stage: ministerialStage,
        medicalBlock: activeSection === 'medical' ? (selectedBlock !== 'الكل' ? selectedBlock : undefined) : undefined,
        targetCount: count
      });

      const cleanBatch = newBatch.filter((q) => !isCorruptedQuestion(q));
      const newTotal = await populateAndSaveQuestionsToIndexedDB(cleanBatch);
      setAllQuestionsPool((prev) => {
        const cleanedPrev = prev.filter((q) => !isCorruptedQuestion(q));
        return [...cleanedPrev, ...cleanBatch];
      });
      setTotalIndexedQuestions(newTotal);
      setGeneratorToast(`✅ تم بنجاح توليد وتدقيق وحفظ ${cleanBatch.length.toLocaleString()} سؤال إضافي مدقق محلياً في قسم «${targetSubj}»! الإجمالي الآن: ${newTotal.toLocaleString()} سؤال بدون أي تكرار.`);
    } catch (e) {
      console.error(e);
      setGeneratorToast('تعذر إكمال التوليد التلقائي للأسئلة.');
    } finally {
      setIsGeneratingMassive(false);
      setTimeout(() => setGeneratorToast(''), 6000);
    }
  };

  // Subject icon helper for ministerial subjects grid
  const getSubjectIcon = (subj: string) => {
    if (subj.includes('فيزياء')) return <Zap className="w-6 h-6 text-amber-500" />;
    if (subj.includes('كيمياء')) return <FlaskConical className="w-6 h-6 text-emerald-500" />;
    if (subj.includes('أحياء')) return <Dna className="w-6 h-6 text-rose-500" />;
    if (subj.includes('رياضيات')) return <Calculator className="w-6 h-6 text-blue-500" />;
    if (subj.includes('قرآن') || subj.includes('إسلامية')) return <BookOpen className="w-6 h-6 text-teal-500" />;
    if (subj.includes('عربية')) return <Award className="w-6 h-6 text-amber-600" />;
    if (subj.includes('إنجليزية') || subj.includes('English')) return <Languages className="w-6 h-6 text-indigo-500" />;
    if (subj.includes('علوم')) return <Atom className="w-6 h-6 text-cyan-500" />;
    if (subj.includes('اجتماعيات') || subj.includes('جغرافيا')) return <MapPin className="w-6 h-6 text-emerald-600" />;
    if (subj.includes('تاريخ')) return <Landmark className="w-6 h-6 text-amber-700" />;
    if (subj.includes('فلسفة') || subj.includes('نفس')) return <BrainCircuit className="w-6 h-6 text-purple-500" />;
    return <GraduationCap className="w-6 h-6 text-teal-500" />;
  };

  // Targeted Ministerial AI Question Generator for Exact Subject & Unit
  const handleGenerateTargetedAiQuestions = async (subject: string, unit: string, stage: string) => {
    setIsGeneratingMassive(true);
    setGeneratorToast(`⚡ جارٍ توليد 10 أسئلة وزارية نموذجية دقيقة وعميقة لمادة «${subject}» - وحدة «${unit}» بالذكاء الاصطناعي (Gemini)...`);
    try {
      const prompt = `أنت الخبير الأول ورئيس لجان الامتحانات الوزارية في الجمهورية اليمنية لمرحلة «${stage}».
المطلوب: قم بتوليد 10 أسئلة وزارية مؤتمتة (اختيار من متعدد) جديدة كلياً وعميقة ودقيقة لمادة «${subject}» في الوحدة/الموضوع: «${unit}».
القواعد الصارمة:
1. الأسئلة يجب أن تكون أصلية تماماً ومن صلب المنهج اليمني المعتمد لـ «${stage}».
2. لا تكرر نفس صيغة السؤال مع تغيير الأرقام إطلاقاً؛ نوع بين المفاهيم النظرية، الحسابية، الاستنتاجية، والعلل.
3. كل سؤال له 4 خيارات (أ، ب، ج، د)، وإجابة صحيحة واحدة فقط (index من 0 إلى 3).
4. اكتب الرموز الرياضية والقوانين الفيزيائية والكيميائية بصيغة LaTeX واضحة ونظيفة داخل $...$ (مثال: $د_0 = \\frac{1}{2\\pi \\sqrt{\\text{حـ} \\times \\text{س}}}$ أو $[\\text{H}_3\\text{O}^+] = 10^{-pH}$).
5. قدم تعليلاً وشرحاً علمياً نموذجياً لكل سؤال مع ذكر القاعدة أو القانون المستخدم.
6. أرجع النتيجة كمصفوفة JSON نقية ومباشرة بدون أي نص تمهيدي أو ختامي وبدون علامات باك تيك خارجية:
[
  {
    "question": "نص السؤال الدقيق",
    "options": ["الخيار الأول", "الخيار الثاني", "الخيار الثالث", "الخيار الرابع"],
    "correctAnswer": 0,
    "explanation": "شرح علمي مفصل للإجابة الصحيحة ولماذا تم استبعاد باقي الخيارات",
    "formulaOrRule": "القاعدة أو القانون الفيزيائي/الرياضي بـ LaTeX",
    "difficulty": "medium",
    "unitOrTopic": "${unit}"
  }
]`;

      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt,
          mode: 'json',
          jsonMode: true,
        }),
      });

      if (!response.ok) throw new Error('فشل اتصال خادم الذكاء الاصطناعي');
      const data = await response.json();
      let text = data.text || '';
      text = text.replace(/```json\n?|\n?```/g, '').trim();
      const parsed = JSON.parse(text);

      if (Array.isArray(parsed) && parsed.length > 0) {
        const freshQuestions: BankQuestion[] = parsed.map((item: any, idx: number) => ({
          id: `gen_ai_target_${Date.now()}_${idx}_${Math.floor(Math.random() * 1000)}`,
          section: 'ministerial' as QuestionSection,
          stage: stage as any,
          subject: subject,
          unitOrTopic: item.unitOrTopic || unit,
          year: `وزاري جديد ${new Date().getFullYear()}`,
          difficulty: (['easy', 'medium', 'hard'].includes(item.difficulty) ? item.difficulty : 'medium') as DifficultyLevel,
          type: 'mcq' as QuestionType,
          question: item.question,
          options: item.options,
          correctAnswer: typeof item.correctAnswer === 'number' ? item.correctAnswer : 0,
          explanation: item.explanation || 'وفق المنهج اليمني المعتمد لوزارة التربية والتعليم.',
          formulaOrRule: item.formulaOrRule,
          tags: ['وزاري', 'ذكاء اصطناعي', subject, unit],
        })).filter((q) => !isCorruptedQuestion(q));

        if (freshQuestions.length > 0) {
          const newTotal = await populateAndSaveQuestionsToIndexedDB(freshQuestions);
          setAllQuestionsPool((prev) => [...freshQuestions, ...prev.filter((q) => !isCorruptedQuestion(q))]);
          setTotalIndexedQuestions(newTotal);
          setGeneratorToast(`✨ تم بنجاح توليد وحفظ ${freshQuestions.length} أسئلة وزارية جديدة تماماً لـ (${subject} - ${unit}) في قاعدة بياناتك!`);
          return;
        }
      }
      throw new Error('لم يتم استخراج أسئلة من استجابة النموذج');
    } catch (err) {
      console.warn('AI question generator fallback to local engine:', err);
      const localBatch = generateSyntheticAcademicQuestions({
        section: 'ministerial',
        subject: subject,
        stage: stage as any,
        targetCount: 10,
      }).filter((q) => !isCorruptedQuestion(q));

      if (localBatch.length > 0) {
        const newTotal = await populateAndSaveQuestionsToIndexedDB(localBatch);
        setAllQuestionsPool((prev) => [...localBatch, ...prev]);
        setTotalIndexedQuestions(newTotal);
        setGeneratorToast(`✅ تم توليد وتدقيق ${localBatch.length} أسئلة وزارية دقيقة لمادة ${subject} محلياً بدون نت وحفظها في قاعدة البيانات!`);
      }
    } finally {
      setIsGeneratingMassive(false);
      setTimeout(() => setGeneratorToast(''), 7000);
    }
  };

  // Targeted Clinical Medical AI Question Generator
  const handleGenerateTargetedMedicalQuestions = async (block: string) => {
    setIsGeneratingMassive(true);
    setGeneratorToast(`⚡ جارٍ توليد حالات إكلينيكية سريرية جديدة لبلك «${block}» بنظام USMLE بالذكاء الاصطناعي...`);
    try {
      const prompt = `You are a clinical medicine professor and USMLE question author.
Generate 5 high-yield, authentic clinical vignettes for medical students in block: "${block}".
Rules:
1. Each question must feature a realistic clinical patient scenario with age, gender, presentation, physical exam, and labs/imaging.
2. 4 multiple-choice options with exactly 1 correct answer (index 0 to 3).
3. Detailed academic explanation covering mechanism, diagnosis, and why distractors are incorrect.
4. Output as pure JSON Array with zero outer markdown:
[
  {
    "question": "Patient scenario and prompt in English and Arabic",
    "options": ["Option A", "Option B", "Option C", "Option D"],
    "correctAnswer": 0,
    "explanation": "Detailed clinical reasoning",
    "clinicalContext": {
      "scenarioEn": "English clinical vignette...",
      "scenarioAr": "السيناريو السريري بالعربية...",
      "highYieldConcept": "High-yield pearl..."
    },
    "difficulty": "hard",
    "unitOrTopic": "${block}"
  }
]`;

      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt,
          mode: 'json',
          jsonMode: true,
        }),
      });

      if (!response.ok) throw new Error('AI Server Error');
      const data = await response.json();
      let text = data.text || '';
      text = text.replace(/```json\n?|\n?```/g, '').trim();
      const parsed = JSON.parse(text);

      if (Array.isArray(parsed) && parsed.length > 0) {
        const freshQuestions: BankQuestion[] = parsed.map((item: any, idx: number) => ({
          id: `gen_med_target_${Date.now()}_${idx}_${Math.floor(Math.random() * 1000)}`,
          section: 'medical' as QuestionSection,
          medicalBlock: block,
          subject: block,
          unitOrTopic: item.unitOrTopic || block,
          year: `USMLE Clinical ${new Date().getFullYear()}`,
          difficulty: (['easy', 'medium', 'hard'].includes(item.difficulty) ? item.difficulty : 'hard') as DifficultyLevel,
          type: 'clinical_scenario' as QuestionType,
          question: item.question,
          options: item.options,
          correctAnswer: typeof item.correctAnswer === 'number' ? item.correctAnswer : 0,
          explanation: item.explanation || 'Verified USMLE clinical guideline.',
          formulaOrRule: item.formulaOrRule,
          clinicalContext: item.clinicalContext,
          tags: ['USMLE', 'طب سريري', block],
        })).filter((q) => !isCorruptedQuestion(q));

        if (freshQuestions.length > 0) {
          const newTotal = await populateAndSaveQuestionsToIndexedDB(freshQuestions);
          setAllQuestionsPool((prev) => [...freshQuestions, ...prev.filter((q) => !isCorruptedQuestion(q))]);
          setTotalIndexedQuestions(newTotal);
          setGeneratorToast(`✨ تم بنجاح توليد ${freshQuestions.length} حالة سريرية جديدة لبلك ${block} وحفظها في قاعدة البيانات!`);
          return;
        }
      }
    } catch (err) {
      console.warn('Medical generator fallback:', err);
    } finally {
      setIsGeneratingMassive(false);
      setTimeout(() => setGeneratorToast(''), 7000);
    }
  };

  // General Online Expansion (invokes targeted generator)
  const handleExpandQuestionsOnline = async () => {
    if (activeSection === 'ministerial') {
      await handleGenerateTargetedAiQuestions(selectedSubject, selectedUnit, ministerialStage);
    } else if (activeSection === 'medical') {
      await handleGenerateTargetedMedicalQuestions(selectedBlock);
    }
  };

  // One-click Database Sanitizer & Purge
  const handlePurgeAndFixDatabase = async () => {
    setIsGeneratingMassive(true);
    setGeneratorToast('🧹 جارٍ فحص وتطهير وتدقيق بنك الأسئلة من أي أسئلة متداخلة أو مخالفة لمادتها...');
    try {
      const purged = await cleanAndSanitizeCorruptedQuestions();
      const allDb = await offlineDb.questions.toArray();
      const allClean = allDb.filter((q) => !isCorruptedQuestion(q));
      setAllQuestionsPool(allClean);
      setTotalIndexedQuestions(allClean.length);
      setGeneratorToast(`✅ اكتمل التدقيق بنجاح! تم حذف ${purged} سؤالاً متداخلاً أو معطوباً، وتثبيت ${allClean.length.toLocaleString()} سؤالاً مدققاً ومنعزلاً تماماً.`);
    } catch (e) {
      console.error(e);
      setGeneratorToast('تعذر إكمال فحص وتدقيق قاعدة البيانات.');
    } finally {
      setIsGeneratingMassive(false);
      setTimeout(() => setGeneratorToast(''), 6000);
    }
  };

  // Synchronize Bookmarks to localStorage
  const toggleBookmark = (id: string) => {
    setBookmarkedIds((prev) => {
      const updated = prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id];
      try {
        localStorage.setItem('yemeni_qb_bookmarks', JSON.stringify(updated));
      } catch (e) {
        console.error(e);
      }
      return updated;
    });
  };

  // Copy Question & Solution
  const handleCopyQuestion = (q: BankQuestion) => {
    const text = `📌 سؤال: ${q.question}\n\n` +
      (q.options ? q.options.map((opt, i) => `${i + 1}. ${opt}`).join('\n') + '\n\n' : '') +
      `✅ الإجابة النموذجية: ${typeof q.correctAnswer === 'number' && q.options ? q.options[q.correctAnswer] : q.correctAnswer}\n\n` +
      `🔬 الشرح والتعليل: ${q.explanation}\n` +
      (q.formulaOrRule ? `📐 القاعدة/القانون: ${q.formulaOrRule}\n` : '') +
      `📚 المرجع: ${q.subject} - ${q.unitOrTopic} (${q.year || 'شامل'})`;

    navigator.clipboard.writeText(text);
    setCopiedId(q.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Active Recall Quiz Handlers (from current notebook chunks or current curriculum subject)
  const handleStartActiveRecallQuiz = () => {
    setActiveRecallGenerating(true);
    setIsActiveRecallOpen(true);
    setActiveRecallCurrentIndex(0);
    setActiveRecallAnswers({});
    setActiveRecallIsFinished(false);
    setActiveRecallScore(0);

    const questionsForRecall: Array<{
      id: string;
      question: string;
      options: string[];
      correctAnswer: number;
      explanation: string;
      sourceChunkTitle?: string;
      chunkSnippet?: string;
    }> = [];

    // 1. First priority: Generate directly from current notebook chunks
    if (chunks && chunks.length > 0) {
      const selectedChunks = [...chunks].sort(() => 0.5 - Math.random()).slice(0, 5);
      selectedChunks.forEach((chk, idx) => {
        const snippet = chk.text.slice(0, 240).replace(/\s+/g, ' ');
        const sentences = chk.text.split(/[.؟!؛\n]+/).map(s => s.trim()).filter(s => s.length > 25);
        const focusSentence = sentences[0] || snippet;

        questionsForRecall.push({
          id: `recall_chk_${idx}_${Date.now()}`,
          question: `استناداً إلى المرجع المعرفي «${chk.sourceTitle || 'المصدر الدراسي'}» (صفحة ${chk.pageNumber || 1})، ما الاستنتاج الأكاديمي الدقيق للفقرة التالية:\n«${focusSentence.slice(0, 180)}...»؟`,
          options: [
            `التحليل المنهجي المعتمد: ${focusSentence.slice(0, 85)}`,
            `مفهوم مناقض للحقائق الواردة في المرجع المعتمد`,
            `تأويل سطحي يغفل القواعد والتعاريف الأساسية للنص`,
            `افتراض غير مدعوم بالبيانات المعرفية الموثقة في الدفتر`
          ],
          correctAnswer: 0,
          explanation: `التأصيل الأكاديمي: تم استخراج هذا المفهوم مباشرة من «${chk.sourceTitle || 'المصدر الدراسي'}» - صفحة ${chk.pageNumber || 1} لتعزيز الاسترجاع النشط وتثبيت المعرفة.`,
          sourceChunkTitle: chk.sourceTitle,
          chunkSnippet: snippet
        });
      });
    }

    // 2. Replenish from filtered questions pool if chunks are fewer than 5
    if (questionsForRecall.length < 5) {
      const candidates = [...allQuestionsPool.filter(q => q.subject === selectedSubject || q.section === activeSection)]
        .sort(() => 0.5 - Math.random())
        .slice(0, 5 - questionsForRecall.length);

      candidates.forEach((q, idx) => {
        questionsForRecall.push({
          id: `recall_q_${q.id}_${idx}`,
          question: q.question,
          options: q.options || ['أ', 'ب', 'ج', 'د'],
          correctAnswer: typeof q.correctAnswer === 'number' ? q.correctAnswer : 0,
          explanation: q.explanation || 'الإجابة النموذجية المعتمدة وفق قواعد المنهج الأكاديمي.',
          sourceChunkTitle: `${q.subject} - ${q.unitOrTopic}`,
          chunkSnippet: q.explanation
        });
      });
    }

    // Fallback if still under 5
    if (questionsForRecall.length === 0) {
      const fallbackQuestions = generateSyntheticAcademicQuestions({
        section: activeSection,
        subject: selectedSubject,
        stage: ministerialStage,
        targetCount: 5
      });
      fallbackQuestions.slice(0, 5).forEach((q, idx) => {
        questionsForRecall.push({
          id: `recall_fb_${idx}`,
          question: q.question,
          options: q.options || ['أ', 'ب', 'ج', 'د'],
          correctAnswer: typeof q.correctAnswer === 'number' ? q.correctAnswer : 0,
          explanation: q.explanation,
          sourceChunkTitle: `${q.subject} - ${q.unitOrTopic}`
        });
      });
    }

    setActiveRecallQuestions(questionsForRecall.slice(0, 5));
    setActiveRecallGenerating(false);
  };

  const handleActiveRecallAnswerSelect = (optionIdx: number) => {
    if (activeRecallAnswers[activeRecallCurrentIndex] !== undefined) return;
    const currentQ = activeRecallQuestions[activeRecallCurrentIndex];
    if (!currentQ) return;

    const newAnswers = { ...activeRecallAnswers, [activeRecallCurrentIndex]: optionIdx };
    setActiveRecallAnswers(newAnswers);

    const isCorrect = optionIdx === currentQ.correctAnswer;
    if (isCorrect) {
      setActiveRecallScore(prev => prev + 1);
    }
  };

  const handleActiveRecallNext = () => {
    if (activeRecallCurrentIndex < activeRecallQuestions.length - 1) {
      setActiveRecallCurrentIndex(prev => prev + 1);
    } else {
      setActiveRecallIsFinished(true);
    }
  };

  // Filtered Questions for Practice Mode from dynamic allQuestionsPool (Strict Subject Isolation)
  const filteredQuestions = useMemo(() => {
    // In universal section, NO question cards are shown (pure open chat & knowledge engine)
    if (activeSection === 'universal') {
      return [];
    }

    let pool = allQuestionsPool.filter((q) => {
      if (isCorruptedQuestion(q)) return false;
      if (q.section !== activeSection) return false;

      // Strict ministerial stage & subject isolation
      if (activeSection === 'ministerial') {
        const isSameSubj = q.subject === selectedSubject ||
          (selectedSubject === 'التاريخ الحديث' && (q.subject.includes('تاريخ') || q.subject === 'التاريخ الحديث')) ||
          (selectedSubject === 'الفيزياء' && q.subject.includes('فيزياء')) ||
          (selectedSubject === 'الكيمياء' && q.subject.includes('كيمياء')) ||
          (selectedSubject === 'الأحياء' && q.subject.includes('أحياء')) ||
          (selectedSubject.includes('رياضيات') && q.subject.includes('رياضيات')) ||
          (selectedSubject === 'العلوم' && q.subject.includes('علوم')) ||
          (selectedSubject === 'الاجتماعيات' && q.subject.includes('اجتماعيات')) ||
          (selectedSubject.includes('عرب') && q.subject.includes('عرب')) ||
          (selectedSubject.includes('إسلام') && (q.subject.includes('إسلام') || q.subject.includes('قرآن')));

        if (!isSameSubj) return false;

        const subjectIsGrade9 = selectedSubject === 'العلوم' || selectedSubject === 'الاجتماعيات';
        const isLiterary = ['التاريخ الحديث', 'الجغرافيا', 'الفلسفة وعلم النفس'].includes(selectedSubject);
        const isScientific = ['الفيزياء', 'الكيمياء', 'الأحياء', 'الرياضيات (تفاضل وتكامل وجبر)'].includes(selectedSubject);

        if (subjectIsGrade9) {
          if (q.stage && !q.stage.includes('تاسع')) return false;
        } else if (isLiterary) {
          if (q.stage && q.stage.includes('تاسع')) return false;
          if (q.stage && q.stage.includes('علمي')) return false;
        } else if (isScientific) {
          if (q.stage && q.stage.includes('تاسع')) return false;
          if (q.stage && q.stage.includes('أدبي')) return false;
        }

        if (selectedUnit && selectedUnit !== 'كافة الوحدات والدروس') {
          const directMatch = q.unitOrTopic?.includes(selectedUnit) || selectedUnit.includes(q.unitOrTopic || '');
          if (!directMatch) {
            const unitTokens = selectedUnit
              .split(/[\s\-–—،,:]+/)
              .filter(w => w.length >= 3 && !['كافة', 'الوحدات', 'الدروس', 'تاريخ', 'جغرافية', 'علم', 'مادة', 'الوحدة'].includes(w));
            const hasCommonKeyword = unitTokens.some(token => (q.unitOrTopic || '').includes(token) || (q.tags || []).some(t => t.includes(token)));
            if (!hasCommonKeyword) return false;
          }
        }
      }
      // Strict medical block isolation
      if (activeSection === 'medical') {
        if (q.medicalBlock !== selectedBlock) return false;
      }
      if (difficultyFilter !== 'all' && q.difficulty !== difficultyFilter) return false;
      if (typeFilter !== 'all' && q.type !== typeFilter) return false;
      if (selectedYear !== 'الكل' && q.year && !q.year.includes(selectedYear)) return false;

      if (searchQuery && searchQuery.trim()) {
        const qLower = searchQuery.toLowerCase().trim();
        const inText = q.question.toLowerCase().includes(qLower);
        const inExpl = q.explanation.toLowerCase().includes(qLower);
        const inSubj = q.subject.toLowerCase().includes(qLower);
        const inTopic = q.unitOrTopic.toLowerCase().includes(qLower);
        const inOptions = q.options?.some((o) => o.toLowerCase().includes(qLower)) || false;
        const inClinical = q.clinicalContext
          ? (q.clinicalContext.scenarioAr?.toLowerCase().includes(qLower) ||
             q.clinicalContext.scenarioEn?.toLowerCase().includes(qLower) ||
             q.clinicalContext.highYieldConcept?.toLowerCase().includes(qLower))
          : false;

        return inText || inExpl || inSubj || inTopic || inOptions || inClinical;
      }

      return true;
    });

    // Zero-Deficit Safety: If filtering yields 0 questions, fall back gracefully to all questions for this subject
    if (pool.length === 0 && activeSection === 'ministerial') {
      pool = allQuestionsPool.filter((q) => {
        if (isCorruptedQuestion(q)) return false;
        if (q.section !== 'ministerial') return false;
        return q.subject === selectedSubject || (selectedSubject.includes('تاريخ') && q.subject.includes('تاريخ'));
      });

      if (pool.length === 0) {
        let fresh: BankQuestion[] = [];
        if (selectedSubject === 'التاريخ الحديث' || selectedSubject === 'الجغرافيا' || selectedSubject === 'الفلسفة وعلم النفس') {
          fresh = generateYemeniLiteraryQuestions(30, selectedSubject);
        } else if (selectedSubject === 'العلوم') {
          fresh = generateYemeniGrade9ScienceQuestions(30);
        } else if (selectedSubject === 'الاجتماعيات') {
          fresh = generateYemeniGrade9SocialQuestions(30);
        } else if (selectedSubject === 'الفيزياء') {
          fresh = generateYemeniPhysicsQuestions(30, ministerialStage);
        } else if (selectedSubject === 'الكيمياء') {
          fresh = generateYemeniChemistryQuestions(30, ministerialStage);
        } else if (selectedSubject === 'الأحياء') {
          fresh = generateYemeniBiologyQuestions(30, ministerialStage);
        } else if (selectedSubject.includes('رياضيات')) {
          fresh = generateYemeniMathQuestions(30, ministerialStage);
        } else {
          fresh = generateYemeniArabicAndIslamicQuestions(30, selectedSubject);
        }
        pool = fresh.filter((q) => !isCorruptedQuestion(q));
      }
    }

    // Strict runtime deduplication: prevent identical or numerical-template duplicate questions
    const seenPrompts = new Set<string>();
    const seenTemplates = new Map<string, number>();
    pool = pool.filter((q) => {
      const cleanPrompt = (q.question || '').trim().replace(/\s+/g, ' ');
      const exactKey = `${q.section}_${q.subject}_${cleanPrompt}`;
      if (seenPrompts.has(exactKey)) return false;
      seenPrompts.add(exactKey);

      // Max 1 question per numerical template variation
      const templateKey = `${q.section}_${q.subject}_${cleanPrompt.replace(/[0-9٠-٩]+(?:\.[0-9٠-٩]+)?/g, '#')}`;
      const count = seenTemplates.get(templateKey) || 0;
      if (count >= 1) return false;
      seenTemplates.set(templateKey, count + 1);
      return true;
    });

    // Intelligent Adaptive Mastery Filter
    if (isAdaptiveMasteryActive) {
      if (studentMastery.level === 'مبتدئ') {
        pool = pool.filter((q) => q.difficulty === 'easy' || q.difficulty === 'medium');
      } else if (studentMastery.level === 'متقدم') {
        pool = pool.filter((q) => q.difficulty === 'hard' || q.difficulty === 'medium');
      }
    }

    if (showBookmarksOnly) {
      return pool.filter((q) => bookmarkedIds.includes(q.id));
    }
    return pool;
  }, [
    allQuestionsPool,
    activeSection,
    ministerialStage,
    selectedBlock,
    selectedSubject,
    selectedUnit,
    difficultyFilter,
    typeFilter,
    selectedYear,
    searchQuery,
    showBookmarksOnly,
    bookmarkedIds,
    isAdaptiveMasteryActive,
    studentMastery
  ]);

  // Infinite Scroll & Progressive Rendering State (30 items per batch)
  const [visibleCount, setVisibleCount] = useState<number>(30);
  const sentinelRef = useRef<HTMLDivElement | null>(null);

  // Automatically reset pagination counter back to 30 whenever any filter or search query changes
  useEffect(() => {
    setVisibleCount(30);
  }, [
    activeSection,
    ministerialStage,
    selectedSubject,
    selectedYear,
    selectedBlock,
    medicalLang,
    selectedCategory,
    universalSubView,
    searchQuery,
    difficultyFilter,
    typeFilter,
    showBookmarksOnly
  ]);

  // Sliced questions currently rendered in the DOM
  const displayedQuestions = useMemo(() => {
    return filteredQuestions.slice(0, visibleCount);
  }, [filteredQuestions, visibleCount]);

  const hasMoreQuestions = visibleCount < filteredQuestions.length;

  // Progressive IntersectionObserver for high-speed infinite scroll without memory leaks
  useEffect(() => {
    if (!hasMoreQuestions) return;

    const observer = new IntersectionObserver(
      (entries) => {
        const first = entries[0];
        if (first && first.isIntersecting) {
          setVisibleCount((prev) => Math.min(prev + 30, filteredQuestions.length));
        }
      },
      {
        root: null,
        rootMargin: '300px', // Pre-fetch 300px before reaching the bottom for zero scroll lag
        threshold: 0.05,
      }
    );

    const targetSentinel = sentinelRef.current;
    if (targetSentinel) {
      observer.observe(targetSentinel);
    }

    return () => {
      if (targetSentinel) {
        observer.unobserve(targetSentinel);
      }
      observer.disconnect();
    };
  }, [hasMoreQuestions, filteredQuestions.length]);

  // Exam Countdown Timer
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isExamRunning && !isExamFinished && examTimeLeftSeconds > 0) {
      interval = setInterval(() => {
        setExamTimeLeftSeconds((prev) => {
          if (prev <= 1) {
            setIsExamFinished(true);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isExamRunning, isExamFinished, examTimeLeftSeconds]);

  // Start Exam Simulation (Continuous Infinite Sequential Rounds - 100% Strict Subject Isolation)
  const handleStartExam = async (isNextRound: boolean = false) => {
    const nextRoundNumber = isNextRound ? examRound + 1 : examRound;
    if (isNextRound) {
      setExamRound(nextRoundNumber);
    }

    const currentExcludeIds = isNextRound ? seenExamQuestionIds : [];

    // Strictly resolve target section, stage, and subject
    const targetSection = activeSection === 'medical' ? 'medical' : 'ministerial';
    const targetStage = targetSection === 'ministerial' ? ministerialStage : undefined;
    const targetSubject = targetSection === 'ministerial' ? selectedSubject : selectedBlock;
    const targetBlock = targetSection === 'medical' ? selectedBlock : undefined;

    // Check pool candidates strictly matching this exact subject and stage
    const poolCandidates = allQuestionsPool.filter((q) => {
      if (q.section !== targetSection) return false;
      if (targetSection === 'ministerial') {
        return q.stage === targetStage && q.subject === targetSubject;
      }
      if (targetSection === 'medical') {
        return q.medicalBlock === targetBlock;
      }
      return false;
    });

    const unseenCandidates = poolCandidates.filter((q) => !currentExcludeIds.includes(q.id));

    let activePool = allQuestionsPool;
    // If unseen questions pool is running low for this specific subject/block, synthesize 120+ fresh questions strictly for this subject
    if (unseenCandidates.length < examBatchSize) {
      try {
        const freshBatch = generateSyntheticAcademicQuestions({
          section: targetSection,
          subject: targetSubject,
          stage: targetStage,
          medicalBlock: targetBlock,
          targetCount: 120
        });

        await populateAndSaveQuestionsToIndexedDB(freshBatch);
        activePool = [...allQuestionsPool, ...freshBatch];
        setAllQuestionsPool(activePool);
        setTotalIndexedQuestions(activePool.length);
      } catch (err) {
        console.warn('Could not auto-generate background questions:', err);
      }
    }

    const questions = generateExamSimulation({
      section: targetSection,
      stage: targetStage,
      medicalBlock: targetBlock,
      subject: targetSubject,
      count: examBatchSize,
      excludeIds: currentExcludeIds,
      pool: activePool
    });

    if (questions.length === 0) return;

    // Track chosen question IDs so subsequent rounds never duplicate
    const newChosenIds = questions.map((q) => q.id);
    setSeenExamQuestionIds((prev) => Array.from(new Set([...(isNextRound ? prev : []), ...newChosenIds])));

    setExamQuestions(questions);
    setCurrentExamIndex(0);
    setExamAnswers({});
    const allocMins = examBatchSize;
    setExamTimeLimitMins(allocMins);
    setExamTimeLeftSeconds(allocMins * 60);
    setMode('exam');
    setIsExamRunning(true);
    setIsExamFinished(false);

    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleFinishExam = async () => {
    setIsExamFinished(true);
    const timeSpent = Math.max(1, (examTimeLimitMins * 60) - examTimeLeftSeconds);
    let correct = 0;
    const wrongIds: string[] = [];

    examQuestions.forEach((q) => {
      const userAns = examAnswers[q.id];
      if (userAns !== undefined && userAns === q.correctAnswer) {
        correct++;
      } else {
        wrongIds.push(q.id);
      }
    });

    const scorePct = examQuestions.length > 0 ? Math.round((correct / examQuestions.length) * 100) : 0;
    const subjTitle = selectedSubject !== 'الكل'
      ? selectedSubject
      : activeSection === 'medical'
      ? selectedBlock
      : 'شامل';

    // 1. Record into IndexedDB
    try {
      await recordExamAttempt({
        section: activeSection,
        subject: subjTitle,
        stageOrBlock: activeSection === 'ministerial' ? ministerialStage : activeSection === 'medical' ? selectedBlock : undefined,
        totalQuestions: examQuestions.length,
        correctAnswers: correct,
        scorePercentage: scorePct,
        timeSpentSeconds: timeSpent,
        date: Date.now(),
        wrongQuestionIds: wrongIds,
      });

      // 2. Sync to cloud via backgroundSync
      backgroundSync.markPendingChange();

      // 3. Notify parent app if callback provided
      if (onRecordExamQuiz) {
        onRecordExamQuiz({
          id: `exam_${Date.now()}`,
          notebookId: 'nb_default',
          title: `اختبار مؤتمت #${examRound}: ${subjTitle} (${scorePct}%)`,
          score: correct,
          count: examQuestions.length,
          date: Date.now(),
          kind: 'local',
          questions: examQuestions.map((q) => ({
            id: q.id,
            question: q.question,
            type: 'mcq',
            options: q.options || [],
            answer: q.correctAnswer,
            explanation: q.explanation,
            userAnswer: examAnswers[q.id],
          })),
        });
      }
    } catch (e) {
      console.warn('Error recording exam attempt:', e);
    }
  };

  // Exam Score Calculation with timing & academic rating
  const examScore = useMemo(() => {
    if (!isExamFinished || examQuestions.length === 0) {
      return { correct: 0, total: 0, percentage: 0, timeSpentSeconds: 0, rating: '' };
    }
    let correct = 0;
    examQuestions.forEach((q) => {
      const userAns = examAnswers[q.id];
      if (userAns !== undefined && userAns === q.correctAnswer) {
        correct++;
      }
    });
    const percentage = Math.round((correct / examQuestions.length) * 100);
    const timeSpentSeconds = Math.max(1, (examTimeLimitMins * 60) - examTimeLeftSeconds);

    let rating = 'ممتاز 🌟';
    if (percentage < 50) rating = 'بحاجة لمزيد من المذاكرة ⚠️';
    else if (percentage < 65) rating = 'مقبول 👍';
    else if (percentage < 80) rating = 'جيد جداً ✨';
    else if (percentage < 90) rating = 'ممتاز 🌟';
    else rating = 'امتياز مع مرتبة الشرف 🏆';

    return {
      correct,
      total: examQuestions.length,
      percentage,
      timeSpentSeconds,
      rating,
    };
  }, [isExamFinished, examQuestions, examAnswers, examTimeLimitMins, examTimeLeftSeconds]);

  // Handle Universal AI / Offline Question Solver
  const handleSolveUniversalQuery = (e: React.FormEvent) => {
    e.preventDefault();
    if (!universalQueryInput.trim()) return;

    setIsSolvingQuery(true);
    setTimeout(() => {
      const result = solveAcademicallyOffline(universalQueryInput);
      setUniversalQueryResult(result);
      setIsSolvingQuery(false);
    }, 200);
  };

  return (
    <div className="h-full w-full flex flex-col min-h-0 overflow-hidden animate-in fade-in duration-200">
      {/* ========================================================= */}
      {/* 0. MASTER HUB PORTAL DASHBOARD (WHEN activePortal === 'hub') */}
      {/* ========================================================= */}
      {activePortal === 'hub' && (
        <div className="h-full overflow-y-auto p-3 sm:p-4 lg:p-6 pb-28 space-y-6 animate-in fade-in duration-300">
          {/* Sleek Minimalist Top Header Bar (No bulky cards or clutter) */}
          <div className="flex flex-wrap items-center justify-between gap-3 pb-2 border-b border-[#e2e8e5] dark:border-[#22352f]">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-teal-500/10 dark:bg-teal-500/20 text-teal-600 dark:text-teal-400 flex items-center justify-center font-bold shrink-0">
                <FileQuestion className="w-5 h-5" />
              </div>
              <div>
                <h1 className="text-base sm:text-lg font-black text-[#17201e] dark:text-[#eef7f4] flex items-center gap-2">
                  <span>بنك الأسئلة والموسوعة الأكاديمية</span>
                  <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 border border-teal-200/50 dark:border-teal-800/40">
                    {totalIndexedQuestions.toLocaleString()} سؤال
                  </span>
                </h1>
                <p className="text-xs text-[#596762] dark:text-[#9ab3ab]">
                  اختر القسم المطلوب للدخول مباشرة إلى الواجهة المستقلة المخصصة
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={handlePurgeAndFixDatabase}
                disabled={isGeneratingMassive}
                className="px-3 py-1.5 rounded-xl bg-gray-100 hover:bg-gray-200 dark:bg-[#1a2723] dark:hover:bg-[#22352f] text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-gray-800 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer active:scale-95 disabled:opacity-50"
                title="فحص وتطهير بنك الأسئلة وحذف أي سؤال مخالف لمادته أو معطوب"
              >
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                <span>تدقيق وتطهير</span>
              </button>
            </div>
          </div>

          {/* Generator Toast Alert */}
          {generatorToast && (
            <div className="p-3 rounded-2xl bg-amber-500/15 border border-amber-400/40 text-amber-800 dark:text-amber-200 text-xs font-bold flex items-center gap-2 animate-in fade-in">
              <Sparkles className="w-4 h-4 text-amber-500 animate-spin shrink-0" />
              <span>{generatorToast}</span>
            </div>
          )}

          {/* 3 Sleek Rectangular Section Cards - World Class Clean Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
            {/* Card 1: Ministerial Portal */}
            <div
              onClick={() => {
                setActiveSection('ministerial');
                setActivePortal('ministerial');
                setMinisterialStep('stage_select');
                setIsExamRunning(false);
              }}
              className="group p-4 rounded-2xl bg-white dark:bg-[#14201c] border border-[#e2e8e5] dark:border-[#22352f] hover:border-teal-500/80 hover:shadow-md transition-all cursor-pointer flex flex-col justify-between"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-11 h-11 rounded-xl bg-teal-500/10 dark:bg-teal-500/20 text-teal-600 dark:text-teal-400 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                    <GraduationCap className="w-5 h-5" />
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <h2 className="text-sm font-bold text-[#17201e] dark:text-[#eef7f4] truncate">
                        الامتحانات الوزارية اليمنية
                      </h2>
                    </div>
                    <p className="text-[11px] text-[#596762] dark:text-[#9ab3ab] mt-0.5 truncate">
                      تاسع أساسي وثالث ثانوي • نماذج أتمتة 2020-2024
                    </p>
                  </div>
                </div>
                <span className="px-2 py-0.5 rounded-md bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 border border-teal-200/50 dark:border-teal-800/40 text-[10px] font-bold shrink-0">
                  مؤتمت 100%
                </span>
              </div>

              <div className="mt-3.5 pt-2.5 border-t border-gray-100 dark:border-gray-800/80 flex items-center justify-between text-xs text-teal-600 dark:text-teal-400 font-semibold">
                <span className="text-[11px] text-gray-500 dark:text-gray-400">علمي • أدبي • أساسي</span>
                <div className="flex items-center gap-1 group-hover:-translate-x-1 transition-transform">
                  <span>فتح القسم</span>
                  <ChevronLeft className="w-3.5 h-3.5" />
                </div>
              </div>
            </div>

            {/* Card 2: Medical Portal */}
            <div
              onClick={() => {
                setActiveSection('medical');
                setActivePortal('medical');
                setIsExamRunning(false);
              }}
              className="group p-4 rounded-2xl bg-white dark:bg-[#14201c] border border-[#e2e8e5] dark:border-[#22352f] hover:border-cyan-500/80 hover:shadow-md transition-all cursor-pointer flex flex-col justify-between"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-11 h-11 rounded-xl bg-cyan-500/10 dark:bg-cyan-500/20 text-cyan-600 dark:text-cyan-400 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                    <Stethoscope className="w-5 h-5" />
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <h2 className="text-sm font-bold text-[#17201e] dark:text-[#eef7f4] truncate">
                        البنك الطبي السريري
                      </h2>
                    </div>
                    <p className="text-[11px] text-[#596762] dark:text-[#9ab3ab] mt-0.5 truncate">
                      12 بلكاً طبياً سريرياً وحالات USMLE ثنائية اللغة
                    </p>
                  </div>
                </div>
                <span className="px-2 py-0.5 rounded-md bg-cyan-50 dark:bg-cyan-950/60 text-cyan-700 dark:text-cyan-300 border border-cyan-200/50 dark:border-cyan-800/40 text-[10px] font-bold shrink-0">
                  USMLE
                </span>
              </div>

              <div className="mt-3.5 pt-2.5 border-t border-gray-100 dark:border-gray-800/80 flex items-center justify-between text-xs text-cyan-600 dark:text-cyan-400 font-semibold">
                <span className="text-[11px] text-gray-500 dark:text-gray-400">CVS • CNS • Respiratory • GIT</span>
                <div className="flex items-center gap-1 group-hover:-translate-x-1 transition-transform">
                  <span>فتح القسم</span>
                  <ChevronLeft className="w-3.5 h-3.5" />
                </div>
              </div>
            </div>

            {/* Card 3: Universal Encyclopedia & Chat Portal */}
            <div
              onClick={() => {
                setActiveSection('universal');
                setActivePortal('universal');
                setIsExamRunning(false);
                setMode('practice');
              }}
              className="group p-4 rounded-2xl bg-white dark:bg-[#14201c] border border-[#e2e8e5] dark:border-[#22352f] hover:border-purple-500/80 hover:shadow-md transition-all cursor-pointer flex flex-col justify-between"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-11 h-11 rounded-xl bg-purple-500/10 dark:bg-purple-500/20 text-purple-600 dark:text-purple-400 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                    <Globe2 className="w-5 h-5" />
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <h2 className="text-sm font-bold text-[#17201e] dark:text-[#eef7f4] truncate">
                        الموسوعة العامة والمحادثة
                      </h2>
                    </div>
                    <p className="text-[11px] text-[#596762] dark:text-[#9ab3ab] mt-0.5 truncate">
                      إجابات نموذجية موسوعية ومحادثة معرفية بدون اختبارات
                    </p>
                  </div>
                </div>
                <span className="px-2 py-0.5 rounded-md bg-purple-50 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 border border-purple-200/50 dark:border-purple-800/40 text-[10px] font-bold shrink-0">
                  موسوعة شاملة
                </span>
              </div>

              <div className="mt-3.5 pt-2.5 border-t border-gray-100 dark:border-gray-800/80 flex items-center justify-between text-xs text-purple-600 dark:text-purple-400 font-semibold">
                <span className="text-[11px] text-gray-500 dark:text-gray-400">علوم • رياضيات • تاريخ • ذكاء</span>
                <div className="flex items-center gap-1 group-hover:-translate-x-1 transition-transform">
                  <span>فتح القسم</span>
                  <ChevronLeft className="w-3.5 h-3.5" />
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* INSIDE SECTION PORTAL (WHEN activePortal !== 'hub') */}
      {/* ========================================================= */}
      {activePortal !== 'hub' && (
        <div className="h-full flex flex-col min-h-0 overflow-hidden">
          {/* Dedicated Section Portal Navigation Toolbar */}
          <div className="shrink-0 mb-2 bg-white dark:bg-[#14201c] px-3.5 py-2.5 rounded-2xl border border-[#e2e8e5] dark:border-[#22352f] shadow-xs flex flex-wrap items-center justify-between gap-2.5">
            {/* Left: Back button + Rectangular Section Pill */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  setActivePortal('hub');
                  setIsExamRunning(false);
                }}
                className="px-3 py-1.5 rounded-xl bg-gray-100 hover:bg-gray-200 dark:bg-[#1a2723] dark:hover:bg-[#22352f] text-gray-700 dark:text-gray-300 font-bold text-xs flex items-center gap-1.5 border border-gray-200 dark:border-gray-800 transition-all cursor-pointer active:scale-95"
                title="الرجوع إلى دليل الأقسام الرئيسي"
              >
                <ChevronRight className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                <span>الأقسام</span>
              </button>

              {/* Sleek, rectangular, compact section tabs matching user specification */}
              <div className="flex items-center gap-1 bg-[#f6f8f7] dark:bg-[#1a2723] p-1 rounded-xl border border-gray-200 dark:border-gray-800">
                <button
                  type="button"
                  onClick={() => {
                    setActiveSection('ministerial');
                    setActivePortal('ministerial');
                    setMinisterialStep('stage_select');
                    setIsExamRunning(false);
                  }}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                    activeSection === 'ministerial'
                      ? 'bg-teal-600 text-white shadow-xs'
                      : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white'
                  }`}
                  title="القسم الوزاري للمنهج اليمني (تاسع وثالث ثانوي)"
                >
                  <GraduationCap className="w-3.5 h-3.5" />
                  <span>القسم الوزاري</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setActiveSection('medical');
                    setActivePortal('medical');
                    setIsExamRunning(false);
                  }}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                    activeSection === 'medical'
                      ? 'bg-cyan-600 text-white shadow-xs'
                      : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white'
                  }`}
                  title="البنك الطبي السريري (Clinical Blocks)"
                >
                  <Stethoscope className="w-3.5 h-3.5" />
                  <span>القسم الطبي</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setActiveSection('universal');
                    setActivePortal('universal');
                    setIsExamRunning(false);
                  }}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                    activeSection === 'universal'
                      ? 'bg-purple-600 text-white shadow-xs'
                      : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white'
                  }`}
                  title="الموسوعة الشاملة والمحادثة المفتوحة"
                >
                  <Globe2 className="w-3.5 h-3.5" />
                  <span>الموسوعة</span>
                </button>
              </div>
            </div>

            {/* Right: Mode Switch & Fast Actions */}
            {activeSection !== 'universal' ? (
              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  type="button"
                  onClick={() => handleGenerateMassiveQuestions(1000)}
                  disabled={isGeneratingMassive}
                  className="px-2.5 py-1 rounded-xl bg-gradient-to-r from-amber-400/20 to-amber-500/20 hover:from-amber-400/35 hover:to-amber-500/35 text-amber-900 dark:text-amber-200 border border-amber-400/40 text-xs font-bold flex items-center gap-1 cursor-pointer disabled:opacity-50 transition-all shadow-2xs active:scale-95"
                  title="توليد دفعة جديدة من 1,000 سؤال أكاديمي معتمد غير مكرر وحفظها في قاعدة البيانات المحلية"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                  <span className="hidden sm:inline">+1,000 سؤال</span>
                  <span className="sm:hidden">+1,000</span>
                </button>

                <div className="flex items-center bg-[#f6f8f7] dark:bg-[#1a2723] p-0.5 rounded-xl border border-gray-200 dark:border-gray-800 text-xs">
                  <button
                    onClick={() => {
                      setMode('practice');
                      setIsExamRunning(false);
                    }}
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      mode === 'practice'
                        ? 'bg-teal-600 text-white shadow-xs'
                        : 'text-gray-600 dark:text-gray-400 hover:text-gray-900'
                    }`}
                  >
                    تدريب
                  </button>
                  <button
                    onClick={() => {
                      setMode('exam');
                      if (!isExamRunning) handleStartExam();
                    }}
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      mode === 'exam'
                        ? 'bg-amber-500 text-slate-950 font-black shadow-xs'
                        : 'text-gray-600 dark:text-gray-400 hover:text-gray-900'
                    }`}
                  >
                    امتحان
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-1 bg-[#f6f8f7] dark:bg-[#1a2723] p-1 rounded-xl border border-gray-200 dark:border-gray-800 text-xs">
                <button
                  type="button"
                  onClick={() => setUniversalSubView('chat')}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                    universalSubView === 'chat'
                      ? 'bg-purple-600 text-white shadow-xs'
                      : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white'
                  }`}
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                  <span>المحادثة الموسوعية</span>
                </button>
                <button
                  type="button"
                  onClick={() => setUniversalSubView('encyclopedia')}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                    universalSubView === 'encyclopedia'
                      ? 'bg-purple-600 text-white shadow-xs'
                      : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white'
                  }`}
                >
                  <BookOpen className="w-3.5 h-3.5" />
                  <span>قارئ ويكيبيديا</span>
                </button>
              </div>
            )}
          </div>

      {/* ========================================================= */}
      {/* EXAM SIMULATION MODE (MINISTERIAL & MEDICAL ONLY) */}
      {/* ========================================================= */}
      {activeSection !== 'universal' && mode === 'exam' && (
        <div className="flex-1 min-h-0 overflow-y-auto p-1 sm:p-3 pb-28">
          <div className="bg-white dark:bg-[#14201c] rounded-3xl p-5 sm:p-7 border border-[#e2e8e5] dark:border-[#22352f] shadow-sm">
          {!isExamRunning && !isExamFinished && (
            <div className="text-center py-10 max-w-xl mx-auto space-y-5">
              <div className="w-16 h-16 rounded-3xl bg-amber-100 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 mx-auto flex items-center justify-center">
                <Award className="w-8 h-8" />
              </div>
              <div>
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-400/30 text-amber-600 dark:text-amber-300 text-xs font-bold mb-2">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>دورة الاختبار رقم #{examRound} • أسئلة مستقلة تماماً</span>
                </div>
                <h2 className="text-2xl font-black text-[#17201e] dark:text-[#eef7f4]">
                  محاكي الامتحانات المؤتمتة: {activeSection === 'ministerial' ? `مادة ${selectedSubject} (${ministerialStage})` : `بلك ${selectedBlock}`}
                </h2>
                <p className="text-sm text-[#596762] dark:text-[#9ab3ab] mt-1">
                  اختبار وزاري مستقل 100% لمادة {activeSection === 'ministerial' ? `${selectedSubject} - ${ministerialStage}` : selectedBlock} دون أي اختلاط بمواد أو صفوف أخرى. يختبرك في {examBatchSize} سؤالاً، ثم يقدم تحليلاً دقيقاً، وينقلك للنموذج التالي #{examRound + 1}.
                </p>
              </div>

              {/* Subject confirmation & quick switch in exam setup */}
              <div className="p-3 bg-amber-50/60 dark:bg-amber-950/30 rounded-2xl border border-amber-200/50 dark:border-amber-900/30 text-xs">
                <span className="font-bold text-amber-800 dark:text-amber-300 block mb-2">
                  المادة المحددة للاختبار (مستقلة 100%):
                </span>
                <div className="flex flex-wrap items-center justify-center gap-1.5">
                  {(activeSection === 'ministerial'
                    ? (ministerialStage === 'تاسع أساسي'
                        ? MINISTERIAL_SUBJECTS.grade9
                        : ministerialStage === 'ثالث ثانوي علمي'
                        ? MINISTERIAL_SUBJECTS.sec3_sci
                        : MINISTERIAL_SUBJECTS.sec3_lit)
                    : MEDICAL_BLOCKS
                  ).map((s) => {
                    const isCur = activeSection === 'ministerial' ? selectedSubject === s : selectedBlock === s;
                    return (
                      <button
                        key={s}
                        type="button"
                        onClick={() => {
                          if (activeSection === 'ministerial') setSelectedSubject(s);
                          else setSelectedBlock(s);
                        }}
                        className={`px-3 py-1 rounded-xl font-bold transition-all cursor-pointer text-xs ${
                          isCur
                            ? 'bg-amber-500 text-white shadow-xs ring-2 ring-amber-300/50'
                            : 'bg-white dark:bg-[#1a2723] text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-gray-800 hover:border-amber-400'
                        }`}
                      >
                        {s}
                      </button>
                    );
                  })}
                </div>
              </div>
              <div className="space-y-1.5 pt-1">
                <span className="text-xs font-bold text-gray-500 block">عدد أسئلة النموذج:</span>
                <div className="flex items-center justify-center gap-2">
                  {[30, 40, 20].map((count) => (
                    <button
                      key={count}
                      onClick={() => {
                        setExamBatchSize(count);
                        setExamTimeLimitMins(count);
                      }}
                      className={`px-4 py-2 rounded-xl text-xs font-bold cursor-pointer transition-all ${
                        examBatchSize === count
                          ? 'bg-teal-600 text-white shadow-sm ring-2 ring-teal-400/40'
                          : 'bg-gray-100 dark:bg-[#1a2723] text-gray-700 dark:text-gray-300 hover:bg-gray-200'
                      }`}
                    >
                      {count} سؤالاً {count === 30 ? '(النموذج الوزاري)' : ''}
                    </button>
                  ))}
                </div>
              </div>

              {/* Duration Selector */}
              <div className="space-y-1.5 pt-1">
                <span className="text-xs font-bold text-gray-500 block">مدة المؤقت الزمني:</span>
                <div className="flex items-center justify-center gap-2 flex-wrap">
                  {[20, 30, 45, 60].map((mins) => (
                    <button
                      key={mins}
                      onClick={() => setExamTimeLimitMins(mins)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold cursor-pointer transition-all ${
                        examTimeLimitMins === mins
                          ? 'bg-amber-500 text-white shadow-xs'
                          : 'bg-gray-100 dark:bg-[#1a2723] text-gray-700 dark:text-gray-300'
                      }`}
                    >
                      {mins} دقيقة
                    </button>
                  ))}
                </div>
              </div>

              <div className="pt-4">
                <button
                  onClick={() => handleStartExam(false)}
                  className="px-8 py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-600 to-amber-700 hover:from-amber-600 hover:to-amber-800 text-white font-black text-base shadow-lg shadow-amber-500/25 transition-transform active:scale-95 cursor-pointer flex items-center gap-2.5 mx-auto"
                >
                  <Play className="w-5 h-5 fill-current" />
                  <span>بدء اختبار مادة {activeSection === 'ministerial' ? selectedSubject : selectedBlock} ({examBatchSize} سؤالاً) — دورة #{examRound}</span>
                </button>
              </div>
            </div>
          )}

          {isExamRunning && !isExamFinished && examQuestions.length > 0 && (
            <div className="space-y-6">
              {/* Exam Header: Question Counter & Live Timer */}
              <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-2xl bg-[#f6f8f7] dark:bg-[#1a2723] border border-[#e2e8e5] dark:border-[#22352f]">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-500 text-white font-black flex items-center justify-center">
                    {currentExamIndex + 1}
                  </div>
                  <div>
                    <h3 className="font-bold text-sm text-[#17201e] dark:text-[#eef7f4]">
                      السؤال {currentExamIndex + 1} من {examQuestions.length}
                    </h3>
                    <p className="text-xs text-[#596762] dark:text-[#9ab3ab]">
                      {examQuestions[currentExamIndex].subject} — {examQuestions[currentExamIndex].unitOrTopic}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  {/* Timer Display */}
                  <div className={`px-4 py-2 rounded-xl font-mono text-lg font-black flex items-center gap-2 ${
                    examTimeLeftSeconds < 180
                      ? 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-500/30 animate-pulse'
                      : 'bg-black/5 dark:bg-black/40 text-amber-600 dark:text-amber-400 border border-amber-500/20'
                  }`}>
                    <Clock className="w-4 h-4" />
                    <span>
                      {Math.floor(examTimeLeftSeconds / 60).toString().padStart(2, '0')}:
                      {(examTimeLeftSeconds % 60).toString().padStart(2, '0')}
                    </span>
                  </div>

                  <button
                    onClick={handleFinishExam}
                    className="px-4 py-2 rounded-xl bg-rose-500 hover:bg-rose-600 text-white text-xs font-bold transition-all cursor-pointer"
                  >
                    تسليم وإنهاء الاختبار
                  </button>
                </div>
              </div>

              {/* Electronic Bubble Sheet Navigation Bar */}
              <div className="flex items-center gap-1.5 overflow-x-auto py-2 px-1">
                {examQuestions.map((q, idx) => {
                  const isAnswered = examAnswers[q.id] !== undefined;
                  const isCurrent = idx === currentExamIndex;
                  return (
                    <button
                      key={q.id}
                      onClick={() => setCurrentExamIndex(idx)}
                      className={`w-9 h-9 rounded-xl text-xs font-bold transition-all cursor-pointer shrink-0 flex items-center justify-center border ${
                        isCurrent
                          ? 'bg-amber-500 text-white border-amber-600 ring-2 ring-amber-400/50 shadow-xs'
                          : isAnswered
                          ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border-emerald-400/40'
                          : 'bg-white dark:bg-[#1a2723] text-gray-500 border-gray-200 dark:border-gray-800 hover:border-gray-400'
                      }`}
                    >
                      {idx + 1}
                    </button>
                  );
                })}
              </div>

              {/* Active Exam Question Box */}
              {(() => {
                const currentQ = examQuestions[currentExamIndex];
                const selected = examAnswers[currentQ.id];

                return (
                  <div className="p-6 rounded-2xl bg-white dark:bg-[#16221e] border border-[#e2e8e5] dark:border-[#22352f] space-y-6">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-teal-100 dark:bg-teal-950 text-teal-800 dark:text-teal-300 font-bold">
                          {currentQ.year || 'امتحان رسمي'}
                        </span>
                        <span className="text-[10px] px-2 py-0.5 rounded-md bg-gray-100 dark:bg-[#20322b] text-gray-600 dark:text-gray-300">
                          {currentQ.stage || currentQ.medicalBlock || currentQ.subject}
                        </span>
                      </div>
                      <h3 className="text-base sm:text-lg font-bold text-[#17201e] dark:text-[#eef7f4] leading-relaxed">
                        <SafeMathText text={currentQ.question} />
                      </h3>
                    </div>

                    {/* Options list */}
                    <div className="space-y-2.5">
                      {currentQ.options?.map((option, optIdx) => {
                        const isChosen = selected === optIdx;
                        return (
                          <button
                            key={optIdx}
                            onClick={() => {
                              setExamAnswers((prev) => ({ ...prev, [currentQ.id]: optIdx }));
                            }}
                            className={`w-full text-right p-4 rounded-xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                              isChosen
                                ? 'bg-amber-50 dark:bg-amber-950/40 border-amber-500 text-amber-900 dark:text-amber-200 ring-1 ring-amber-500 font-bold'
                                : 'bg-[#f8faf9] dark:bg-[#1a2723] border-[#e2e8e5] dark:border-[#22352f] text-[#17201e] dark:text-[#d5dedb] hover:border-teal-400'
                            }`}
                          >
                            <span className="text-sm leading-relaxed">
                              <SafeMathText text={option} />
                            </span>
                            <div className={`w-6 h-6 rounded-full border flex items-center justify-center shrink-0 ${
                              isChosen ? 'bg-amber-500 border-amber-600 text-white' : 'border-gray-300 dark:border-gray-600'
                            }`}>
                              {isChosen && <Check className="w-3.5 h-3.5" />}
                            </div>
                          </button>
                        );
                      })}
                    </div>

                    {/* Pagination Buttons */}
                    <div className="flex items-center justify-between pt-4 border-t border-[#e2e8e5] dark:border-[#22352f]">
                      <button
                        disabled={currentExamIndex === 0}
                        onClick={() => setCurrentExamIndex((p) => Math.max(0, p - 1))}
                        className="px-4 py-2 rounded-xl border border-gray-200 dark:border-gray-700 text-xs font-bold disabled:opacity-30 disabled:pointer-events-none cursor-pointer flex items-center gap-1.5"
                      >
                        <ChevronRight className="w-4 h-4" />
                        <span>السؤال السابق</span>
                      </button>

                      {currentExamIndex < examQuestions.length - 1 ? (
                        <button
                          onClick={() => setCurrentExamIndex((p) => Math.min(examQuestions.length - 1, p + 1))}
                          className="px-5 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold cursor-pointer flex items-center gap-1.5 shadow-xs"
                        >
                          <span>السؤال التالي</span>
                          <ChevronLeft className="w-4 h-4" />
                        </button>
                      ) : (
                        <button
                          onClick={handleFinishExam}
                          className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold cursor-pointer flex items-center gap-1.5 shadow-xs"
                        >
                          <span>إنهاء وتسليم الإجابات</span>
                          <Check className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })()}
            </div>
          )}

          {/* Exam Finished & Results Scorecard */}
          {isExamFinished && (
            <div className="space-y-6">
              <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-emerald-900 to-teal-950 text-white text-center space-y-4">
                <div className="w-20 h-20 rounded-full bg-white/10 mx-auto flex items-center justify-center border-2 border-emerald-400">
                  <Award className="w-10 h-10 text-amber-300" />
                </div>
                <div>
                  <h2 className="text-2xl sm:text-3xl font-black">
                    نتيجة اختبار: {activeSection === 'ministerial' ? `مادة ${selectedSubject}` : `بلك ${selectedBlock}`}
                  </h2>
                  <p className="text-sm text-teal-200">
                    {activeSection === 'ministerial' ? `الصف: ${ministerialStage}` : 'البلك السريري الطبي'} • تم تدقيق إجاباتك طبقاً للنموذج الأكاديمي المعتمد
                  </p>
                </div>

                <div className="flex flex-wrap items-center justify-center gap-6 sm:gap-10 py-3">
                  <div>
                    <div className="text-4xl font-black text-amber-300 font-mono">
                      %{examScore.percentage}
                    </div>
                    <div className="text-xs text-teal-200/80 mt-0.5">النسبة المئوية</div>
                  </div>
                  <div className="w-px h-10 bg-white/20 hidden sm:block" />
                  <div>
                    <div className="text-4xl font-black text-emerald-300 font-mono">
                      {examScore.correct} / {examScore.total}
                    </div>
                    <div className="text-xs text-teal-200/80 mt-0.5">الإجابات الصحيحة</div>
                  </div>
                  <div className="w-px h-10 bg-white/20 hidden sm:block" />
                  <div>
                    <div className="text-2xl font-black text-teal-200 font-mono">
                      {Math.floor(examScore.timeSpentSeconds / 60)}د {examScore.timeSpentSeconds % 60}ث
                    </div>
                    <div className="text-xs text-teal-200/80 mt-0.5">الوقت المستغرق</div>
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
                  <span className="px-3.5 py-1 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/40 text-xs font-bold">
                    التقييم: {examScore.rating}
                  </span>
                  <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-xs font-semibold flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>تم توثيق الاختبار محلياً في IndexedDB والمزامنة السحابية</span>
                  </span>
                </div>

                <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-3">
                  <button
                    onClick={() => handleStartExam(true)}
                    className="w-full sm:w-auto px-6 py-3.5 rounded-2xl bg-gradient-to-r from-emerald-400 via-teal-400 to-emerald-500 hover:from-emerald-500 hover:to-teal-600 text-slate-950 font-black text-sm shadow-xl shadow-teal-500/30 transition-all cursor-pointer flex items-center justify-center gap-2 transform active:scale-95"
                  >
                    <Play className="w-5 h-5 fill-current" />
                    <span>🚀 بدء الاختبار التالي لمادة {activeSection === 'ministerial' ? selectedSubject : selectedBlock} ({examBatchSize} سؤالاً جديداً غير مكرر — نموذج #{examRound + 1})</span>
                  </button>
                  <button
                    onClick={() => handleStartExam(false)}
                    className="w-full sm:w-auto px-5 py-3.5 rounded-2xl bg-white/15 hover:bg-white/25 text-white text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2"
                  >
                    <RotateCcw className="w-4 h-4" />
                    <span>إعادة حل هذا النموذج (#{examRound})</span>
                  </button>
                  <button
                    onClick={() => {
                      setMode('practice');
                      setIsExamRunning(false);
                      setIsExamFinished(false);
                    }}
                    className="w-full sm:w-auto px-5 py-3.5 rounded-2xl bg-black/30 hover:bg-black/50 text-white/90 text-xs font-bold transition-all cursor-pointer"
                  >
                    العودة للبنك المفتوح
                  </button>
                </div>
              </div>

              {/* Detailed Review of Exam Questions */}
              <div className="space-y-4">
                <h3 className="font-bold text-base text-[#17201e] dark:text-[#eef7f4]">
                  المراجعة التفصيلية وتصحيح الأخطاء:
                </h3>
                {examQuestions.map((q, idx) => {
                  const userAns = examAnswers[q.id];
                  const isCorrect = userAns !== undefined && userAns === q.correctAnswer;

                  return (
                    <div
                      key={`${q.id}_${idx}`}
                      className={`p-5 rounded-2xl border ${
                        isCorrect
                          ? 'bg-emerald-50/50 dark:bg-emerald-950/20 border-emerald-300 dark:border-emerald-800/40'
                          : 'bg-rose-50/50 dark:bg-rose-950/20 border-rose-300 dark:border-rose-800/40'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-center gap-2">
                          <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                            isCorrect ? 'bg-emerald-500 text-white' : 'bg-rose-500 text-white'
                          }`}>
                            {idx + 1}
                          </span>
                          <span className="text-xs font-bold text-gray-500">
                            {q.subject}
                          </span>
                        </div>
                        <span className={`text-xs font-bold px-2 py-0.5 rounded-md ${
                          isCorrect
                            ? 'bg-emerald-100 dark:bg-emerald-900/60 text-emerald-800 dark:text-emerald-200'
                            : 'bg-rose-100 dark:bg-rose-900/60 text-rose-800 dark:text-rose-200'
                        }`}>
                          {isCorrect ? 'إجابة صحيحة ✓' : 'إجابة خاطئة ✗'}
                        </span>
                      </div>

                      <p className="font-bold text-sm text-[#17201e] dark:text-[#eef7f4] mt-2.5">
                        <SafeMathText text={q.question} />
                      </p>

                      <div className="mt-3 p-3 rounded-xl bg-white dark:bg-[#1a2723] text-xs space-y-1.5 border border-black/5 dark:border-white/5">
                        <div className="text-emerald-700 dark:text-emerald-300 font-semibold flex items-center gap-1.5 flex-wrap">
                          <span>✅ الإجابة النموذجية:</span>
                          <SafeMathText
                            text={typeof q.correctAnswer === 'number' && q.options
                              ? q.options[q.correctAnswer]
                              : String(q.correctAnswer)}
                          />
                        </div>
                        {userAns !== undefined && userAns !== q.correctAnswer && (
                          <div className="text-rose-600 dark:text-rose-400 flex items-center gap-1.5 flex-wrap">
                            <span>❌ إجابتك:</span>
                            <SafeMathText
                              text={typeof userAns === 'number' && q.options
                                ? q.options[userAns]
                                : String(userAns)}
                            />
                          </div>
                        )}
                        <div className="text-gray-600 dark:text-gray-300 pt-1 leading-relaxed border-t border-gray-100 dark:border-gray-800">
                          <span className="font-bold block mb-1">الشرح والتعليل: </span>
                          <SafeMathText text={q.explanation} block />
                        </div>
                        {q.formulaOrRule && (
                          <div className="font-mono bg-teal-50 dark:bg-teal-950/60 text-teal-800 dark:text-teal-200 p-2 rounded-lg mt-1 text-[11px]">
                            <span className="font-bold block mb-1">📐 المعادلة أو القاعدة:</span>
                            <SafeMathText text={q.formulaOrRule} block />
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* 1. UNIVERSAL KNOWLEDGE & CHAT SECTION (NO QUIZZES / FULL-HEIGHT IMMERSIVE) */}
      {/* ========================================================= */}
      {activeSection === 'universal' && (
        <div className={`flex-1 min-h-0 h-full flex flex-col ${universalSubView === 'encyclopedia' ? 'overflow-y-auto' : 'overflow-hidden'} px-1 sm:px-2 pb-24 lg:pb-6 animate-in fade-in duration-200`}>
          {universalSubView === 'chat' ? (
            <EncyclopedicChat
              onExportToNote={onExportToNote}
            />
          ) : (
            <EncyclopedicReader
              onSaveAsNote={onExportToNote}
              onAskAiAboutTopic={(topicTitle, context) => {
                if (onAskAboutQuestion) {
                  onAskAboutQuestion(`اشرح لي بالتفصيل موضوع «${topicTitle}» في سياق الموسوعة العلمية: ${context}`);
                }
              }}
            />
          )}
        </div>
      )}

      {/* ========================================================= */}
      {/* 2. PRACTICE & EXPLORATION MODE (MINISTERIAL & MEDICAL ONLY) */}
      {/* ========================================================= */}
      {/* ========================================================= */}
      {/* 2. PRACTICE & EXPLORATION MODE (MINISTERIAL & MEDICAL ONLY) */}
      {/* ========================================================= */}
      {activeSection !== 'universal' && mode === 'practice' && (
        <div className="flex-1 min-h-0 overflow-y-auto p-1 sm:p-3 pb-28 space-y-5">
          {/* ---------------------------------------------------------- */}
          {/* MINISTERIAL STEP 1: STAGE SELECTION (ثالث ثانوي أو تاسع أساسي) */}
          {/* ---------------------------------------------------------- */}
          {activeSection === 'ministerial' && ministerialStep === 'stage_select' && (
            <div className="py-4 space-y-6 animate-in fade-in duration-300">
              <div className="text-center max-w-2xl mx-auto space-y-2">
                <div className="w-14 h-14 rounded-2xl bg-teal-500/10 dark:bg-teal-500/20 text-teal-600 dark:text-teal-400 mx-auto flex items-center justify-center font-bold">
                  <GraduationCap className="w-8 h-8" />
                </div>
                <h2 className="text-xl sm:text-2xl font-black text-[#17201e] dark:text-[#eef7f4]">
                  بنك الامتحانات والأسئلة الوزارية المؤتمتة (الجمهورية اليمنية)
                </h2>
                <p className="text-xs sm:text-sm text-[#596762] dark:text-[#9ab3ab]">
                  اختر مرحلتك الدراسية للدخول إلى المواد والوحدات المقررة مع نماذج الأتمتة المعتمدة
                </p>
              </div>

              {/* The 2 Primary Choices */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5 max-w-4xl mx-auto pt-2">
                {/* Choice 1: Third Secondary */}
                <div className="p-6 rounded-3xl bg-white dark:bg-[#14201c] border-2 border-[#e2e8e5] dark:border-[#22352f] hover:border-teal-500 transition-all shadow-sm flex flex-col justify-between space-y-5">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="w-12 h-12 rounded-2xl bg-teal-50 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400 flex items-center justify-center font-bold text-xl">
                        🎓
                      </span>
                      <span className="px-3 py-1 rounded-full bg-teal-100 dark:bg-teal-950 text-teal-800 dark:text-teal-200 text-xs font-bold border border-teal-300 dark:border-teal-800">
                        الثانوية العامة
                      </span>
                    </div>
                    <div>
                      <h3 className="text-lg font-black text-[#17201e] dark:text-[#eef7f4]">
                        الصف الثالث الثانوي (المرحلة الثانوية)
                      </h3>
                      <p className="text-xs text-[#596762] dark:text-[#9ab3ab] mt-1 leading-relaxed">
                        نماذج اختبارات وزارية مؤتمتة شاملة لكافة المحافظات اليمنية، تدعم القوانين والرموز الرياضية والفيزيائية والشروحات الأكاديمية المفصلة.
                      </p>
                    </div>
                  </div>

                  <div className="space-y-2 pt-2 border-t border-gray-100 dark:border-gray-800">
                    <button
                      type="button"
                      onClick={() => {
                        setMinisterialStage('ثالث ثانوي علمي');
                        setSelectedSubject('الفيزياء');
                        setSelectedUnit('كافة الوحدات والدروس');
                        setMinisterialStep('subject_select');
                      }}
                      className="w-full py-3 px-4 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs sm:text-sm flex items-center justify-between transition-all cursor-pointer shadow-xs active:scale-98"
                    >
                      <div className="flex items-center gap-2">
                        <Zap className="w-4 h-4 text-amber-300" />
                        <span>دخول القسم العلمي (فيزياء، كيمياء، أحياء، رياضيات...)</span>
                      </div>
                      <ChevronLeft className="w-4 h-4" />
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setMinisterialStage('ثالث ثانوي أدبي');
                        setSelectedSubject('التاريخ الحديث');
                        setSelectedUnit('كافة الوحدات والدروس');
                        setMinisterialStep('subject_select');
                      }}
                      className="w-full py-3 px-4 rounded-xl bg-gray-100 dark:bg-[#1a2723] hover:bg-gray-200 dark:hover:bg-[#22352f] text-gray-800 dark:text-gray-200 font-bold text-xs sm:text-sm flex items-center justify-between border border-gray-200 dark:border-gray-800 transition-all cursor-pointer active:scale-98"
                    >
                      <div className="flex items-center gap-2">
                        <Landmark className="w-4 h-4 text-teal-500" />
                        <span>دخول القسم الأدبي (تاريخ، جغرافيا، فلسفة، عربي...)</span>
                      </div>
                      <ChevronLeft className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Choice 2: Ninth Basic */}
                <div className="p-6 rounded-3xl bg-white dark:bg-[#14201c] border-2 border-[#e2e8e5] dark:border-[#22352f] hover:border-blue-500 transition-all shadow-sm flex flex-col justify-between space-y-5">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="w-12 h-12 rounded-2xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center font-bold text-xl">
                        📘
                      </span>
                      <span className="px-3 py-1 rounded-full bg-blue-100 dark:bg-blue-950 text-blue-800 dark:text-blue-200 text-xs font-bold border border-blue-300 dark:border-blue-800">
                        الشهادة الأساسية
                      </span>
                    </div>
                    <div>
                      <h3 className="text-lg font-black text-[#17201e] dark:text-[#eef7f4]">
                        الصف التاسع الأساسي (الشهادة الإعدادية)
                      </h3>
                      <p className="text-xs text-[#596762] dark:text-[#9ab3ab] mt-1 leading-relaxed">
                        بنك الأسئلة الوزارية ونماذج الأتمتة المعتمدة لشهادة التعليم الأساسي اليمني، وفق التحديث المعتمد لجميع المواد الدراسية.
                      </p>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-gray-100 dark:border-gray-800">
                    <button
                      type="button"
                      onClick={() => {
                        setMinisterialStage('تاسع أساسي');
                        setSelectedSubject('العلوم');
                        setSelectedUnit('كافة الوحدات والدروس');
                        setMinisterialStep('subject_select');
                      }}
                      className="w-full py-3.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs sm:text-sm flex items-center justify-between transition-all cursor-pointer shadow-xs active:scale-98"
                    >
                      <div className="flex items-center gap-2">
                        <Atom className="w-4 h-4 text-cyan-200" />
                        <span>دخول مواد الصف التاسع الأساسي (علوم، رياضيات، لغة...)</span>
                      </div>
                      <ChevronLeft className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ---------------------------------------------------------- */}
          {/* MINISTERIAL STEP 2: SUBJECT SELECTION (قائمة المواد) */}
          {/* ---------------------------------------------------------- */}
          {activeSection === 'ministerial' && ministerialStep === 'subject_select' && (
            <div className="py-2 space-y-5 animate-in fade-in duration-300">
              {/* Breadcrumb Header */}
              <div className="flex items-center justify-between gap-3 pb-3 border-b border-[#e2e8e5] dark:border-[#22352f]">
                <div className="flex items-center gap-2 text-xs">
                  <button
                    type="button"
                    onClick={() => setMinisterialStep('stage_select')}
                    className="px-3 py-1.5 rounded-xl bg-gray-100 dark:bg-[#1a2723] hover:bg-teal-50 dark:hover:bg-teal-950 text-teal-700 dark:text-teal-300 font-bold flex items-center gap-1.5 cursor-pointer border border-gray-200 dark:border-gray-800"
                  >
                    <ChevronRight className="w-4 h-4" />
                    <span>الرجوع للمراحل</span>
                  </button>
                  <span className="text-gray-400">/</span>
                  <span className="font-bold text-[#17201e] dark:text-[#eef7f4]">
                    مواد {ministerialStage}
                  </span>
                </div>

                {ministerialStage.includes('ثالث ثانوي') && (
                  <div className="flex items-center gap-1 bg-[#f6f8f7] dark:bg-[#1a2723] p-1 rounded-xl border border-gray-200 dark:border-gray-800 text-xs">
                    <button
                      type="button"
                      onClick={() => {
                        setMinisterialStage('ثالث ثانوي علمي');
                        setSelectedSubject('الفيزياء');
                      }}
                      className={`px-3 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                        ministerialStage === 'ثالث ثانوي علمي' ? 'bg-teal-600 text-white' : 'text-gray-600 dark:text-gray-400'
                      }`}
                    >
                      القسم العلمي
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setMinisterialStage('ثالث ثانوي أدبي');
                        setSelectedSubject('التاريخ الحديث');
                      }}
                      className={`px-3 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                        ministerialStage === 'ثالث ثانوي أدبي' ? 'bg-teal-600 text-white' : 'text-gray-600 dark:text-gray-400'
                      }`}
                    >
                      القسم الأدبي
                    </button>
                  </div>
                )}
              </div>

              <div>
                <h2 className="text-lg sm:text-xl font-black text-[#17201e] dark:text-[#eef7f4]">
                  مواد {ministerialStage}
                </h2>
                <p className="text-xs text-[#596762] dark:text-[#9ab3ab] mt-0.5">
                  انقر على المادة للانتقال إلى وحداتها المنهجية وتوليد أو حل الأسئلة الوزارية بدقة
                </p>
              </div>

              {/* Grid of Subjects */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 pt-1">
                {(ministerialStage === 'تاسع أساسي'
                  ? MINISTERIAL_SUBJECTS.grade9
                  : ministerialStage === 'ثالث ثانوي علمي'
                  ? MINISTERIAL_SUBJECTS.sec3_sci
                  : MINISTERIAL_SUBJECTS.sec3_lit
                ).map((subj) => {
                  const count = allQuestionsPool.filter(
                    (q) => q.section === 'ministerial' &&
                      (q.subject === subj || (subj.includes('تاريخ') && q.subject.includes('تاريخ'))) &&
                      !isCorruptedQuestion(q)
                  ).length;
                  const unitsCount = SUBJECT_UNITS_MAP[subj]?.length || 5;

                  return (
                    <div
                      key={subj}
                      onClick={() => {
                        handleSubjectChange(subj);
                        setMinisterialStep('unit_select');
                      }}
                      className="group p-5 rounded-2xl bg-white dark:bg-[#14201c] border-2 border-[#e2e8e5] dark:border-[#22352f] hover:border-teal-500 hover:shadow-md transition-all cursor-pointer flex flex-col justify-between space-y-4"
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-center gap-3">
                          <div className="w-12 h-12 rounded-xl bg-teal-50 dark:bg-teal-950/60 border border-teal-200/50 dark:border-teal-800/40 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                            {getSubjectIcon(subj)}
                          </div>
                          <div>
                            <h3 className="text-base font-black text-[#17201e] dark:text-[#eef7f4] group-hover:text-teal-600 dark:group-hover:text-teal-400 transition-colors">
                              {subj}
                            </h3>
                            <span className="text-[11px] text-gray-500 dark:text-gray-400">
                              {unitsCount} وحدات معتمدة
                            </span>
                          </div>
                        </div>

                        <span className="px-2 py-0.5 rounded-full bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 text-[10px] font-bold border border-teal-200/40">
                          {count.toLocaleString()} سؤال
                        </span>
                      </div>

                      <div className="pt-3 border-t border-gray-100 dark:border-gray-800 flex items-center justify-between text-xs font-bold text-teal-600 dark:text-teal-400">
                        <span>دخول إلى المادة والوحدات</span>
                        <ChevronLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* ---------------------------------------------------------- */}
          {/* MINISTERIAL STEP 3: UNIT SELECTION (قائمة الوحدات) */}
          {/* ---------------------------------------------------------- */}
          {activeSection === 'ministerial' && ministerialStep === 'unit_select' && (
            <div className="py-2 space-y-5 animate-in fade-in duration-300">
              {/* Breadcrumb Header */}
              <div className="flex items-center justify-between gap-3 pb-3 border-b border-[#e2e8e5] dark:border-[#22352f]">
                <div className="flex items-center gap-2 text-xs">
                  <button
                    type="button"
                    onClick={() => setMinisterialStep('subject_select')}
                    className="px-3 py-1.5 rounded-xl bg-gray-100 dark:bg-[#1a2723] hover:bg-teal-50 dark:hover:bg-teal-950 text-teal-700 dark:text-teal-300 font-bold flex items-center gap-1.5 cursor-pointer border border-gray-200 dark:border-gray-800"
                  >
                    <ChevronRight className="w-4 h-4" />
                    <span>الرجوع لمواد {ministerialStage}</span>
                  </button>
                  <span className="text-gray-400">/</span>
                  <span className="font-bold text-[#17201e] dark:text-[#eef7f4]">{selectedSubject}</span>
                </div>
              </div>

              <div>
                <h2 className="text-lg sm:text-xl font-black text-[#17201e] dark:text-[#eef7f4]">
                  وحدات ودروس مادة {selectedSubject}
                </h2>
                <p className="text-xs text-[#596762] dark:text-[#9ab3ab] mt-0.5">
                  اختر وحدة محددة للتدريب المركز وتوليد الأسئلة، أو اختر «كافة الوحدات والدروس» لبنك شامل
                </p>
              </div>

              {/* Units Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 pt-1">
                {/* Featured All-units card */}
                <div
                  onClick={() => {
                    setSelectedUnit('كافة الوحدات والدروس');
                    setMinisterialStep('questions');
                  }}
                  className="p-5 rounded-2xl bg-gradient-to-br from-teal-500/10 via-emerald-500/10 to-teal-500/5 border-2 border-teal-500/40 hover:border-teal-500 transition-all cursor-pointer flex items-center justify-between group shadow-xs sm:col-span-2"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl bg-teal-600 text-white flex items-center justify-center font-bold text-xl shadow-xs">
                      ✨
                    </div>
                    <div>
                      <h3 className="text-base font-black text-teal-900 dark:text-teal-100">
                        كافة الوحدات والدروس (بنك شامل للمادة)
                      </h3>
                      <p className="text-xs text-teal-700/80 dark:text-teal-300/80 mt-0.5">
                        مراجعة شاملة لجميع فصول المنهج مع اختبارات مؤتمتة متوازنة
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1 text-xs font-bold text-teal-700 dark:text-teal-300 group-hover:-translate-x-1 transition-transform">
                    <span>دخول للبنك الشامل</span>
                    <ChevronLeft className="w-4 h-4" />
                  </div>
                </div>

                {/* Specific curriculum units */}
                {(SUBJECT_UNITS_MAP[selectedSubject] || []).filter(u => u !== 'كافة الوحدات والدروس').map((unit, uIdx) => (
                  <div
                    key={unit}
                    onClick={() => {
                      setSelectedUnit(unit);
                      setMinisterialStep('questions');
                    }}
                    className="group p-4 rounded-2xl bg-white dark:bg-[#14201c] border-2 border-[#e2e8e5] dark:border-[#22352f] hover:border-teal-500 transition-all cursor-pointer flex items-center justify-between shadow-xs"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <span className="w-8 h-8 rounded-xl bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 flex items-center justify-center font-black text-xs shrink-0 border border-teal-200/50">
                        {uIdx + 1}
                      </span>
                      <div className="min-w-0">
                        <h4 className="text-xs sm:text-sm font-bold text-[#17201e] dark:text-[#eef7f4] truncate">
                          {unit}
                        </h4>
                        <span className="text-[10px] text-gray-500 dark:text-gray-400">
                          الوحدة المنهجية المعتمدة
                        </span>
                      </div>
                    </div>
                    <ChevronLeft className="w-4 h-4 text-gray-400 group-hover:text-teal-600 group-hover:-translate-x-1 transition-all shrink-0" />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ---------------------------------------------------------- */}
          {/* MEDICAL STEP 1: CLINICAL BLOCKS SELECTION */}
          {/* ---------------------------------------------------------- */}
          {activeSection === 'medical' && medicalStep === 'block_select' && (
            <div className="py-2 space-y-5 animate-in fade-in duration-300">
              <div className="text-center max-w-xl mx-auto space-y-1 pb-2">
                <div className="w-12 h-12 rounded-2xl bg-cyan-500/10 text-cyan-600 mx-auto flex items-center justify-center font-bold">
                  <Stethoscope className="w-6 h-6" />
                </div>
                <h2 className="text-lg sm:text-xl font-black text-[#17201e] dark:text-[#eef7f4]">
                  البنك الطبي السريري (Clinical Blocks)
                </h2>
                <p className="text-xs text-[#596762] dark:text-[#9ab3ab]">
                  اختر البلك الطبي المطلوب للدخول إلى الحالات السريرية ونظام USMLE
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
                {MEDICAL_BLOCKS.map((blk) => (
                  <div
                    key={blk}
                    onClick={() => {
                      setSelectedBlock(blk);
                      setMedicalStep('questions');
                    }}
                    className="group p-4 rounded-2xl bg-white dark:bg-[#14201c] border-2 border-[#e2e8e5] dark:border-[#22352f] hover:border-cyan-500 transition-all cursor-pointer flex items-center justify-between shadow-xs"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-10 h-10 rounded-xl bg-cyan-50 dark:bg-cyan-950/60 text-cyan-600 flex items-center justify-center shrink-0">
                        <HeartPulse className="w-5 h-5" />
                      </div>
                      <div className="min-w-0">
                        <h4 className="text-xs sm:text-sm font-bold text-[#17201e] dark:text-[#eef7f4] truncate">
                          {blk}
                        </h4>
                        <span className="text-[10px] text-gray-500">حالات سريرية ثنائية اللغة</span>
                      </div>
                    </div>
                    <ChevronLeft className="w-4 h-4 text-gray-400 group-hover:text-cyan-600 group-hover:-translate-x-1 transition-all shrink-0" />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ---------------------------------------------------------- */}
          {/* QUESTIONS WORKSPACE (SHOWN ONLY WHEN AT 'questions' STEP) */}
          {/* ---------------------------------------------------------- */}
          {((activeSection === 'ministerial' && ministerialStep === 'questions') ||
            (activeSection === 'medical' && medicalStep === 'questions')) && (
            <div className="space-y-4 animate-in fade-in duration-300">
              {/* Dynamic Breadcrumbs & Jumper Navigation Bar */}
              <div className="bg-white dark:bg-[#14201c] p-3 sm:p-4 rounded-2xl border border-[#e2e8e5] dark:border-[#22352f] shadow-xs flex flex-wrap items-center justify-between gap-2.5">
                <div className="flex items-center gap-2 flex-wrap text-xs">
                  {activeSection === 'ministerial' ? (
                    <>
                      <button
                        type="button"
                        onClick={() => setMinisterialStep('stage_select')}
                        className="px-2.5 py-1 rounded-lg bg-gray-100 dark:bg-[#1a2723] hover:bg-teal-50 text-gray-700 dark:text-gray-300 font-bold transition-all cursor-pointer flex items-center gap-1.5 border border-gray-200 dark:border-gray-800"
                        title="الرجوع لمجلد المراحل الدراسية"
                      >
                        <Folder className="w-3.5 h-3.5 text-amber-500" />
                        <span>{ministerialStage}</span>
                      </button>
                      <span className="text-gray-400">/</span>
                      <button
                        type="button"
                        onClick={() => setMinisterialStep('subject_select')}
                        className="px-2.5 py-1 rounded-lg bg-gray-100 dark:bg-[#1a2723] hover:bg-teal-50 text-gray-700 dark:text-gray-300 font-bold transition-all cursor-pointer flex items-center gap-1.5 border border-gray-200 dark:border-gray-800"
                        title="الرجوع لمجلد المواد"
                      >
                        <Folder className="w-3.5 h-3.5 text-teal-500" />
                        <span>{selectedSubject}</span>
                      </button>
                      <span className="text-gray-400">/</span>
                      <button
                        type="button"
                        onClick={() => setMinisterialStep('unit_select')}
                        className="px-2.5 py-1 rounded-lg bg-teal-50 dark:bg-teal-950 text-teal-800 dark:text-teal-200 border border-teal-300 dark:border-teal-800 font-black transition-all cursor-pointer flex items-center gap-1.5"
                        title="تغيير مجلد الوحدة والدرس"
                      >
                        <FolderOpen className="w-3.5 h-3.5 text-teal-600 animate-pulse" />
                        <span>{selectedUnit}</span>
                      </button>
                    </>
                  ) : (
                    <>
                      <button
                        type="button"
                        onClick={() => setMedicalStep('block_select')}
                        className="px-2.5 py-1 rounded-lg bg-cyan-50 dark:bg-cyan-950 text-cyan-800 dark:text-cyan-200 font-black cursor-pointer"
                      >
                        {selectedBlock}
                      </button>
                      <button
                        type="button"
                        onClick={() => setMedicalStep('block_select')}
                        className="text-xs text-cyan-600 font-bold hover:underline"
                      >
                        (تغيير البلك)
                      </button>
                    </>
                  )}
                </div>

                {/* Targeted AI Generator Button */}
                <div className="flex items-center gap-2 w-full sm:w-auto">
                  {activeSection === 'ministerial' ? (
                    <button
                      type="button"
                      onClick={() => handleGenerateTargetedAiQuestions(selectedSubject, selectedUnit, ministerialStage)}
                      disabled={isGeneratingMassive}
                      className="w-full sm:w-auto px-4 py-2 rounded-xl bg-gradient-to-r from-teal-600 via-emerald-600 to-teal-700 hover:from-teal-700 hover:to-emerald-800 text-white font-black text-xs shadow-md transition-all cursor-pointer flex items-center justify-center gap-2 active:scale-98 disabled:opacity-50"
                      title="توليد 10 أسئلة وزارية جديدة تماماً للمادة والوحدة بالذكاء الاصطناعي (Gemini) وحفظها فورياً في قاعدة البيانات"
                    >
                      <Zap className="w-4 h-4 text-amber-300 animate-pulse" />
                      <span>⚡ توليد أسئلة وزارية جديدة بالذكاء الاصطناعي ({selectedSubject})</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => handleGenerateTargetedMedicalQuestions(selectedBlock)}
                      disabled={isGeneratingMassive}
                      className="w-full sm:w-auto px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700 text-white font-black text-xs shadow-md transition-all cursor-pointer flex items-center justify-center gap-2 active:scale-98 disabled:opacity-50"
                    >
                      <Zap className="w-4 h-4 text-amber-300 animate-pulse" />
                      <span>⚡ توليد حالات سريرية جديدة ({selectedBlock})</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Practice Toolbar: Exam launcher + Search & Filters */}
              <div className="bg-white dark:bg-[#14201c] p-3.5 sm:p-4 rounded-2xl border border-[#e2e8e5] dark:border-[#22352f] shadow-xs space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2.5 pb-2 border-b border-gray-100 dark:border-gray-800">
                  <div className="flex items-center gap-2 text-xs font-bold text-gray-700 dark:text-gray-300">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                    <span>المادة النشطة: {activeSection === 'ministerial' ? `${selectedSubject} - ${selectedUnit}` : selectedBlock}</span>
                    <span className="text-teal-600 font-mono">({filteredQuestions.length} سؤال متاح)</span>
                  </div>

                  <div className="flex items-center gap-2 flex-wrap">
                    <button
                      type="button"
                      onClick={handleStartActiveRecallQuiz}
                      className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-purple-600 via-indigo-600 to-purple-700 hover:from-purple-700 hover:to-indigo-800 text-white font-black text-xs shadow-xs transition-all cursor-pointer flex items-center gap-1.5 active:scale-98"
                      title="توليد اختبار استرجاع نشط فوري من مصادر الدفتر المعتمدة"
                    >
                      <BrainCircuit className="w-3.5 h-3.5 text-amber-300 animate-pulse" />
                      <span>🧠 اختبار الاسترجاع النشط (5س)</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleStartExam(false)}
                      className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs shadow-xs transition-all cursor-pointer flex items-center gap-1.5"
                    >
                      <Play className="w-3.5 h-3.5 fill-current" />
                      <span>بدء محاكي الامتحان ({examBatchSize}س)</span>
                    </button>
                  </div>
                </div>

                {/* Search & Filter Row */}
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
                  <div className="relative flex-1">
                    <Search className="w-4 h-4 text-gray-400 absolute right-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="ابحث بالنص، القوانين، الكلمات المفتاحية..."
                      className="w-full bg-[#f6f8f7] dark:bg-[#1a2723] border border-[#e2e8e5] dark:border-[#22352f] rounded-xl pr-9 pl-4 py-1.5 text-xs text-[#17201e] dark:text-[#eef7f4] outline-none"
                    />
                  </div>

                  <div className="flex flex-wrap items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => setIsAdaptiveMasteryActive(!isAdaptiveMasteryActive)}
                      className={`px-2.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 border ${
                        isAdaptiveMasteryActive
                          ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white border-emerald-700 shadow-xs'
                          : 'bg-[#f6f8f7] dark:bg-[#1a2723] border-[#e2e8e5] dark:border-[#22352f] text-gray-700 dark:text-gray-300'
                      }`}
                      title="مؤشر إتقانك"
                    >
                      <Award className={`w-3.5 h-3.5 ${isAdaptiveMasteryActive ? 'text-amber-300' : 'text-emerald-500'}`} />
                      <span>إتقاني: {studentMastery.percentage}%</span>
                    </button>

                    {/* Clean Grid-Card Difficulty Selector (Replaced confusing dropdown) */}
                    <div className="flex items-center gap-1 bg-[#f6f8f7] dark:bg-[#1a2723] p-1 rounded-xl border border-[#e2e8e5] dark:border-[#22352f]">
                      {[
                        { id: 'all', label: 'كافة المستويات' },
                        { id: 'easy', label: 'سهل' },
                        { id: 'medium', label: 'متوسط' },
                        { id: 'hard', label: 'متقدم' },
                      ].map((diff) => (
                        <button
                          key={diff.id}
                          type="button"
                          onClick={() => setDifficultyFilter(diff.id as any)}
                          className={`px-2 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                            difficultyFilter === diff.id
                              ? 'bg-teal-600 text-white shadow-xs'
                              : 'text-gray-600 dark:text-gray-300 hover:text-teal-700 dark:hover:text-teal-300'
                          }`}
                        >
                          {diff.label}
                        </button>
                      ))}
                    </div>

                    <button
                      onClick={() => setShowBookmarksOnly(!showBookmarksOnly)}
                      className={`p-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1 border ${
                        showBookmarksOnly
                          ? 'bg-amber-500 text-white border-amber-600'
                          : 'bg-[#f6f8f7] dark:bg-[#1a2723] border-[#e2e8e5] dark:border-[#22352f] text-gray-600 dark:text-gray-300'
                      }`}
                      title="عرض الأسئلة المفضلة فقط"
                    >
                      <Bookmark className={`w-3.5 h-3.5 ${showBookmarksOnly ? 'fill-current' : ''}`} />
                      <span className="hidden sm:inline">({bookmarkedIds.length})</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Render Questions Feed ONLY when inside 'questions' step */}
          {((activeSection === 'ministerial' && ministerialStep === 'questions') ||
            (activeSection === 'medical' && medicalStep === 'questions')) && (
            <>
              {/* Questions Feed */}
              {filteredQuestions.length === 0 ? (
                <div className="text-center py-16 bg-white dark:bg-[#14201c] rounded-3xl border border-[#e2e8e5] dark:border-[#22352f] p-8 space-y-3">
                  <FileQuestion className="w-12 h-12 text-gray-300 mx-auto" />
                  <h3 className="font-bold text-base text-gray-700 dark:text-gray-200">
                    لم يتم العثور على أسئلة مطابقة للبحث أو للوحدة المحددة
                  </h3>
                  <p className="text-xs text-gray-500 max-w-sm mx-auto">
                    اضغط على زر «توليد أسئلة وزارية جديدة بالذكاء الاصطناعي» أعلاه لإنشاء دفعة معتمدة فورياً!
                  </p>
                </div>
              ) : (
                <div className="space-y-5">
              {displayedQuestions.map((q, qIndex) => {
                const userSelected = selectedAnswers[q.id];
                const isAnswered = userSelected !== undefined;
                const isCorrect = isAnswered && userSelected === q.correctAnswer;
                const isBookmarked = bookmarkedIds.includes(q.id);
                const isExplRevealed = revealedExplanations[q.id] || isAnswered;

                return (
                  <div
                    key={`${q.id}_${qIndex}`}
                    className="p-5 sm:p-7 rounded-3xl bg-white dark:bg-[#14201c] border-2 border-[#e2e8e5] dark:border-[#22352f] shadow-sm space-y-4 hover:border-teal-500/60 transition-all"
                  >
                    {/* Question Card Top Bar */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#e2e8e5] dark:border-[#22352f]">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="px-2.5 py-1 rounded-xl bg-teal-600 text-white text-xs font-black font-mono shadow-xs">
                          #{qIndex + 1}
                        </span>
                        <span className="px-3 py-1 rounded-xl bg-teal-50 dark:bg-teal-950/60 text-teal-800 dark:text-teal-300 text-xs font-bold border border-teal-300/40">
                          {q.subject}
                        </span>
                        <span className="text-xs text-[#596762] dark:text-[#9ab3ab] font-medium">
                          {q.unitOrTopic}
                        </span>
                        {q.year && (
                          <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border border-amber-300/40 font-bold">
                            {q.year}
                          </span>
                        )}
                        <span className={`text-[10px] px-2.5 py-0.5 rounded-full font-bold ${
                          q.difficulty === 'easy'
                            ? 'bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300'
                            : q.difficulty === 'medium'
                            ? 'bg-blue-50 dark:bg-blue-950/50 text-blue-700 dark:text-blue-300'
                            : 'bg-rose-50 dark:bg-rose-950/50 text-rose-700 dark:text-rose-300'
                        }`}>
                          {q.difficulty === 'easy' ? 'مستوى سهل' : q.difficulty === 'medium' ? 'مستوى متوسط' : 'متقدم/تحدي'}
                        </span>
                      </div>

                      {/* Action Tools: Bookmark, Copy, Discuss */}
                      <div className="flex items-center gap-1.5 self-end sm:self-auto">
                        <button
                          onClick={() => toggleBookmark(q.id)}
                          className={`p-2 rounded-xl transition-all cursor-pointer ${
                            isBookmarked
                              ? 'text-amber-500 bg-amber-50 dark:bg-amber-950/40 border border-amber-400/30'
                              : 'text-gray-400 hover:text-gray-600 hover:bg-gray-100 dark:hover:bg-gray-800'
                          }`}
                          title={isBookmarked ? 'إزالة من المفضلة' : 'حفظ في المفضلة'}
                        >
                          {isBookmarked ? <BookmarkCheck className="w-4 h-4 fill-current text-amber-500" /> : <Bookmark className="w-4 h-4" />}
                        </button>

                        <button
                          onClick={() => handleCopyQuestion(q)}
                          className="p-2 rounded-xl text-gray-400 hover:text-gray-600 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors cursor-pointer"
                          title="نسخ السؤال والشرح"
                        >
                          {copiedId === q.id ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
                        </button>

                        {onExportToNote && (
                          <button
                            onClick={() => onExportToNote(`سؤال ${q.subject}: ${q.unitOrTopic}`, `📌 السؤال: ${q.question}\n\n✅ الإجابة: ${typeof q.correctAnswer === 'number' && q.options ? q.options[q.correctAnswer] : q.correctAnswer}\n\n🔬 الشرح: ${q.explanation}`)}
                            className="p-2 rounded-xl text-gray-400 hover:text-gray-600 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors cursor-pointer"
                            title="تصدير إلى ملاحظات الدفتر"
                          >
                            <Layers className="w-4 h-4" />
                          </button>
                        )}

                        <button
                          onClick={() => {
                            const query = q.unitOrTopic || q.subject;
                            const matches = searchEncyclopediaOffline(query);
                            if (matches && matches.length > 0) {
                              setViewingWikiArticle(matches[0]);
                            } else {
                              setViewingWikiArticle(createDynamicWikipediaArticle(`${q.subject}: ${q.unitOrTopic}`, q.subject));
                            }
                          }}
                          className="p-2 rounded-xl text-teal-600 dark:text-teal-400 hover:bg-teal-50 dark:hover:bg-teal-950/40 transition-colors cursor-pointer"
                          title="تصفح الموسوعة الأكاديمية المطورة (Wikipedia) لهذا المفهوم"
                        >
                          <BookOpen className="w-4 h-4" />
                        </button>

                        {onAskAboutQuestion && (
                          <button
                            onClick={() => onAskAboutQuestion(`اشرح لي بالتفصيل هذا السؤال الوزاري/الأكاديمي:\n\nالسؤال: ${q.question}\nالموضوع: ${q.unitOrTopic} (${q.subject})\nالحل المعتمد: ${typeof q.correctAnswer === 'number' && q.options ? q.options[q.correctAnswer] : q.correctAnswer}\nالشرح: ${q.explanation}`)}
                            className="px-2.5 py-1.5 rounded-xl text-teal-700 dark:text-teal-300 bg-teal-50 dark:bg-teal-950/40 hover:bg-teal-100 border border-teal-300/40 transition-colors cursor-pointer font-bold text-xs flex items-center gap-1.5"
                            title="مناقشة السؤال مع المعلم الذكي AI"
                          >
                            <Sparkles className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                            <span>سؤال الذكاء الاصطناعي</span>
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Clinical Context Vignette (for medical section) */}
                    {q.clinicalContext && (
                      <div className="p-3.5 rounded-2xl bg-cyan-50/60 dark:bg-cyan-950/20 border border-cyan-200 dark:border-cyan-800/40 space-y-1.5">
                        <div className="flex items-center gap-1.5 text-cyan-800 dark:text-cyan-300 font-bold text-xs">
                          <Stethoscope className="w-3.5 h-3.5" />
                          <span>السياق السريري الإكلينيكي (Clinical Vignette):</span>
                        </div>
                        {medicalLang !== 'en' && q.clinicalContext.scenarioAr && (
                          <p className="text-xs text-gray-700 dark:text-gray-300 leading-relaxed">
                            <SafeMathText text={q.clinicalContext.scenarioAr} />
                          </p>
                        )}
                        {medicalLang !== 'ar' && q.clinicalContext.scenarioEn && (
                          <p className="text-xs text-gray-600 dark:text-gray-400 font-sans leading-relaxed">
                            <SafeMathText text={q.clinicalContext.scenarioEn} />
                          </p>
                        )}
                      </div>
                    )}

                    {/* Question Body */}
                    <div className="text-base sm:text-lg font-bold text-[#17201e] dark:text-[#eef7f4] leading-relaxed pt-1">
                      <SafeMathText text={q.question} />
                    </div>

                    {/* Options List with Arabic Letters */}
                    <div className="space-y-2.5 pt-1">
                      {q.options?.map((option, optIndex) => {
                        const isThisSelected = userSelected === optIndex;
                        const isThisCorrect = q.correctAnswer === optIndex;

                        let btnClasses = 'bg-[#f6f8f7] dark:bg-[#1a2723] border-[#e2e8e5] dark:border-[#22352f] text-[#17201e] dark:text-[#d5dedb] hover:border-teal-500/60';

                        if (isAnswered) {
                          if (isThisCorrect) {
                            btnClasses = 'bg-emerald-50 dark:bg-emerald-950/50 border-emerald-500 text-emerald-900 dark:text-emerald-200 font-bold ring-2 ring-emerald-500/50';
                          } else if (isThisSelected) {
                            btnClasses = 'bg-rose-50 dark:bg-rose-950/50 border-rose-500 text-rose-900 dark:text-rose-200 font-bold ring-2 ring-rose-500/50';
                          } else {
                            btnClasses = 'opacity-60 bg-[#f6f8f7] dark:bg-[#1a2723] border-gray-200 dark:border-gray-800';
                          }
                        }

                        return (
                          <button
                            key={optIndex}
                            onClick={() => {
                              setSelectedAnswers((prev) => ({ ...prev, [q.id]: optIndex }));
                            }}
                            className={`w-full p-3 sm:p-4 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 text-right ${btnClasses}`}
                          >
                            <div className="flex items-center gap-3 min-w-0 flex-1">
                              <span className={`w-7 h-7 rounded-xl flex items-center justify-center text-xs font-black shrink-0 transition-colors ${
                                isAnswered
                                  ? isThisCorrect
                                    ? 'bg-emerald-600 text-white'
                                    : isThisSelected
                                    ? 'bg-rose-600 text-white'
                                    : 'bg-gray-200 dark:bg-gray-800 text-gray-500'
                                  : 'bg-teal-100 dark:bg-teal-950/80 text-teal-800 dark:text-teal-300 border border-teal-300/40 dark:border-teal-700/40'
                              }`}>
                                {OPTION_LETTERS[optIndex] || optIndex + 1}
                              </span>
                              <div className="text-xs sm:text-sm leading-relaxed text-[#17201e] dark:text-[#eef7f4] font-medium flex-1 text-right">
                                <SafeMathText text={option} />
                              </div>
                            </div>

                            <div className="shrink-0 flex items-center justify-center">
                              {isAnswered && isThisCorrect && (
                                <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                              )}
                              {isAnswered && isThisSelected && !isThisCorrect && (
                                <XCircle className="w-5 h-5 text-rose-600 dark:text-rose-400" />
                              )}
                              {!isAnswered && (
                                <div className="w-5 h-5 rounded-full border-2 border-gray-300 dark:border-gray-600 flex items-center justify-center hover:border-teal-500 transition-colors" />
                              )}
                            </div>
                          </button>
                        );
                      })}
                    </div>

                    {/* Explanation & Steps Breakdown */}
                    {isExplRevealed && (
                      <div className="mt-3 p-4 rounded-2xl bg-teal-50/70 dark:bg-[#162923] border border-teal-200 dark:border-teal-800/40 space-y-2.5 animate-in fade-in duration-200 text-xs sm:text-sm">
                        <div className="flex items-center gap-1.5 font-bold text-teal-800 dark:text-teal-200">
                          <CheckCircle2 className="w-4 h-4 text-teal-600 dark:text-teal-400" />
                          <span>الشرح والتعليل العلمي الأكاديمي:</span>
                        </div>
                        <div className="text-[#17201e] dark:text-[#d5dedb] leading-relaxed">
                          <SafeMathText text={q.explanation} block />
                        </div>

                        {/* LaTeX Formula or Rule box */}
                        {q.formulaOrRule && (
                          <div className="p-3 rounded-xl bg-white dark:bg-[#111f1a] border border-teal-300/40 dark:border-teal-700/40 font-mono text-xs text-teal-900 dark:text-teal-200">
                            <span className="font-bold text-teal-700 dark:text-teal-400 block mb-1">
                              📐 القاعدة أو المعادلة الحاكمة:
                            </span>
                            <SafeMathText text={q.formulaOrRule} block />
                          </div>
                        )}

                        {q.clinicalContext?.highYieldConcept && (
                          <div className="p-2.5 rounded-xl bg-cyan-100/60 dark:bg-cyan-950/60 text-cyan-900 dark:text-cyan-200 text-xs font-semibold">
                            💡 High-Yield Concept: {q.clinicalContext.highYieldConcept}
                          </div>
                        )}

                        {/* Interactive Encyclopedic Wikipedia Deep Dive Button */}
                        <button
                          type="button"
                          onClick={() => {
                            const query = q.unitOrTopic || q.subject;
                            const matches = searchEncyclopediaOffline(query);
                            if (matches && matches.length > 0) {
                              setViewingWikiArticle(matches[0]);
                            } else {
                              setViewingWikiArticle(createDynamicWikipediaArticle(`${q.subject}: ${q.unitOrTopic}`, q.subject));
                            }
                          }}
                          className="w-full mt-2.5 py-2.5 px-3 rounded-xl bg-white dark:bg-[#111f1a] hover:bg-teal-50 dark:hover:bg-teal-950/60 border border-teal-300/50 dark:border-teal-700/50 text-teal-800 dark:text-teal-200 text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-2xs group"
                        >
                          <BookOpen className="w-4 h-4 text-teal-600 dark:text-teal-400 group-hover:scale-110 transition-transform" />
                          <span>📖 تصفح الموسوعة الأكاديمية المطورة لهذا المفهوم ({q.unitOrTopic})</span>
                        </button>
                      </div>
                    )}
                  </div>
                );
              })}

              {/* Infinite Scroll Sentinel & Batch Loader */}
              {hasMoreQuestions && (
                <div
                  ref={sentinelRef}
                  className="p-5 sm:p-6 rounded-3xl bg-teal-500/5 dark:bg-teal-400/5 border border-teal-500/20 dark:border-teal-400/20 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-right animate-pulse"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-7 h-7 border-3 border-teal-500 border-t-transparent rounded-full animate-spin shrink-0" />
                    <div>
                      <p className="text-xs sm:text-sm font-black text-teal-900 dark:text-teal-200">
                        جاري تحميل الدفعة التالية تلقائياً... ({displayedQuestions.length} من {filteredQuestions.length} سؤالاً)
                      </p>
                      <p className="text-[11px] text-[#596762] dark:text-[#9ab3ab] font-medium">
                        نظام Infinite Scroll الافتراضي: عرض 30 سؤالاً في كل دفعة بأعلى استجابة وبدون أي بطء.
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setVisibleCount((prev) => Math.min(prev + 30, filteredQuestions.length))}
                    className="px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold transition-all shadow-xs cursor-pointer shrink-0"
                  >
                    تحميل 30 سؤالاً إضافياً فوراً
                  </button>
                </div>
              )}

              {/* End of list confirmation */}
              {!hasMoreQuestions && filteredQuestions.length > 30 && (
                <div className="py-6 text-center text-xs font-bold text-[#596762] dark:text-[#9ab3ab] border-t border-[#e2e8e5] dark:border-[#22352f]">
                  ✨ تم عرض كامل الأسئلة المتطابقة في هذا القسم بنجاح ({filteredQuestions.length} سؤالاً)
                </div>
              )}
            </div>
          )}
        </>
      )}
    </div>
  )}
</div>
)}

  {/* ========================================================= */}
  {/* Dedicated Encyclopedic Article Viewer Modal */}
  {/* ========================================================= */}
  {viewingWikiArticle && (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200"
    >
      <div className="bg-white dark:bg-[#14201c] w-full max-w-3xl max-h-[90vh] rounded-3xl border border-[#e2e8e5] dark:border-[#22352f] shadow-2xl flex flex-col overflow-hidden text-right">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-[#e2e8e5] dark:border-[#22352f] flex items-center justify-between gap-3 bg-[#f6f8f7] dark:bg-[#1a2723]">
          <div className="flex items-center gap-2 min-w-0 flex-1">
            <span className="w-8 h-8 rounded-xl bg-teal-500/20 text-teal-700 dark:text-teal-300 flex items-center justify-center shrink-0">
              <BookOpen className="w-4 h-4" />
            </span>
            <div className="min-w-0 flex-1">
              <span className="text-[11px] font-bold text-teal-700 dark:text-teal-400 block truncate">
                {viewingWikiArticle.category} {viewingWikiArticle.subCategory ? `• ${viewingWikiArticle.subCategory}` : ''}
              </span>
              <h3 className="text-sm sm:text-base font-black text-[#17201e] dark:text-[#eef7f4] truncate">
                {viewingWikiArticle.title}
              </h3>
            </div>
          </div>

          <button
            onClick={() => setViewingWikiArticle(null)}
            className="w-8 h-8 rounded-xl bg-gray-200 dark:bg-gray-800 hover:bg-rose-500 hover:text-white text-gray-600 dark:text-gray-300 flex items-center justify-center transition-colors cursor-pointer shrink-0"
            title="إغلاق"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Scrollable Content */}
        <div className="p-5 sm:p-7 overflow-y-auto space-y-5 text-[#17201e] dark:text-[#d5dedb] leading-relaxed">
          {/* Summary Quote */}
          {viewingWikiArticle.summary && (
            <div className="p-4 rounded-2xl bg-teal-50/70 dark:bg-teal-950/30 border-r-4 border-teal-500 text-xs sm:text-sm font-medium text-teal-900 dark:text-teal-100">
              <SafeMathText text={viewingWikiArticle.summary} block />
            </div>
          )}

          {/* Key Concepts Pills */}
          {viewingWikiArticle.keyConcepts && viewingWikiArticle.keyConcepts.length > 0 && (
            <div className="space-y-2">
              <span className="text-xs font-bold text-[#596762] dark:text-[#9ab3ab] block">
                المفاهيم والركائز الجوهرية:
              </span>
              <div className="flex flex-wrap gap-1.5">
                {viewingWikiArticle.keyConcepts.map((concept, idx) => (
                  <span
                    key={idx}
                    className="px-3 py-1 rounded-xl bg-[#f6f8f7] dark:bg-[#1a2723] border border-[#e2e8e5] dark:border-[#22352f] text-xs font-bold text-gray-700 dark:text-gray-200"
                  >
                    • {concept}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Formula or Governing Law */}
          {viewingWikiArticle.formulaLatex && (
            <div className="p-3.5 rounded-2xl bg-[#f6f8f7] dark:bg-[#1a2723] border border-[#e2e8e5] dark:border-[#22352f]">
              <span className="text-xs font-bold text-teal-700 dark:text-teal-400 block mb-1">
                📐 الصيغة الرياضية / القانون العلمي:
              </span>
              <SafeMathText text={viewingWikiArticle.formulaLatex} block />
            </div>
          )}

          {/* Full Markdown Article Content */}
          <div className="prose dark:prose-invert max-w-none text-xs sm:text-sm pt-2 border-t border-[#e2e8e5] dark:border-[#22352f]">
            <SafeMathText text={viewingWikiArticle.markdownContent} block />
          </div>

          {/* References */}
          {viewingWikiArticle.references && viewingWikiArticle.references.length > 0 && (
            <div className="pt-4 border-t border-[#e2e8e5] dark:border-[#22352f] space-y-1.5 text-xs text-gray-500">
              <span className="font-bold text-gray-700 dark:text-gray-300 block">المراجع المعتمدة:</span>
              <ul className="list-disc pr-5 space-y-1">
                {viewingWikiArticle.references.map((ref, idx) => (
                  <li key={idx}>{ref}</li>
                ))}
              </ul>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-[#e2e8e5] dark:border-[#22352f] bg-[#f6f8f7] dark:bg-[#1a2723] flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            {onExportToNote && (
              <button
                onClick={() => {
                  onExportToNote(viewingWikiArticle.title, viewingWikiArticle.markdownContent);
                  setViewingWikiArticle(null);
                }}
                className="px-3 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <Layers className="w-3.5 h-3.5" />
                <span>حفظ في الدفتر</span>
              </button>
            )}

            {onAskAboutQuestion && (
              <button
                onClick={() => {
                  onAskAboutQuestion(`اشرح لي بالتفصيل مفهوم: «${viewingWikiArticle.title}» ومحتواه الموسوعي.`);
                  setViewingWikiArticle(null);
                }}
                className="px-3 py-1.5 rounded-xl bg-white dark:bg-[#111f1a] hover:bg-gray-100 text-teal-800 dark:text-teal-200 border border-teal-300 text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5 text-teal-600" />
                <span>سؤال الذكاء الاصطناعي</span>
              </button>
            )}
          </div>

          <button
            onClick={() => setViewingWikiArticle(null)}
            className="px-4 py-1.5 rounded-xl bg-gray-200 dark:bg-gray-800 hover:bg-gray-300 text-gray-700 dark:text-gray-200 text-xs font-bold transition-all cursor-pointer"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  )}

      {/* Source-Based Generative Question Modal */}
      {isSourceGenModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white dark:bg-[#121c19] border border-slate-200 dark:border-[#22352f] rounded-3xl max-w-lg w-full p-6 space-y-4 shadow-2xl relative">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-[#22352f]">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-teal-600 animate-spin" />
                <h3 className="font-black text-base text-slate-900 dark:text-slate-100">
                  توليد أسئلة وزارية وتطبيقية من المصادر
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsSourceGenModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              اختر المصدر الدراسي لتحليله بالذكاء الاصطناعي وتوليد أسئلة اختبارات مؤتمتة عميقة وغير مكررة وفق المعايير الوزارية والطبية:
            </p>

            <div className="space-y-4 text-xs">
              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1.5">
                  المصدر الدراسي المستهدف:
                </label>
                {sources.length === 0 ? (
                  <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-amber-800 dark:text-amber-200 text-xs">
                    لم تقم بإضافة مصادر إلى هذا الدفتر بعد. يمكنك استخدام بنك المنهج اليمني المدمج مباشرة.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 gap-2 max-h-40 overflow-y-auto pr-1">
                    {sources.map((src) => {
                      const isSelected = selectedSourceIdForGen === src.id;
                      return (
                        <div
                          key={src.id}
                          onClick={() => setSelectedSourceIdForGen(src.id)}
                          className={`p-2.5 rounded-xl border text-right transition-all cursor-pointer flex items-center justify-between ${
                            isSelected
                              ? 'bg-teal-50 dark:bg-teal-950/60 border-teal-500 shadow-xs'
                              : 'bg-slate-50 dark:bg-[#1a2723] border-slate-200 dark:border-[#22352f] hover:border-teal-300'
                          }`}
                        >
                          <div className="flex items-center gap-2 min-w-0">
                            <BookOpen className={`w-4 h-4 shrink-0 ${isSelected ? 'text-teal-600' : 'text-slate-400'}`} />
                            <span className="font-bold text-slate-800 dark:text-slate-100 truncate">
                              {src.title}
                            </span>
                          </div>
                          <div className="flex items-center gap-1.5 shrink-0">
                            <span className="text-[10px] px-2 py-0.5 rounded-md bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                              {src.type === 'web_clipped_article' ? 'مقال ويب' : src.type}
                            </span>
                            {isSelected && <Check className="w-3.5 h-3.5 text-teal-600" />}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1.5">
                  عدد الأسئلة المطلوبة:
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { count: 3, label: '3 أسئلة', sub: 'مركزة وسريعة' },
                    { count: 5, label: '5 أسئلة', sub: 'نموذج معتمد' },
                    { count: 10, label: '10 أسئلة', sub: 'شاملة ومفصلة' },
                  ].map((item) => (
                    <button
                      key={item.count}
                      type="button"
                      onClick={() => setSourceGenCount(item.count)}
                      className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                        sourceGenCount === item.count
                          ? 'bg-teal-600 text-white border-teal-700 shadow-xs'
                          : 'bg-slate-50 dark:bg-[#1a2723] border-slate-200 dark:border-[#22352f] text-slate-700 dark:text-slate-200 hover:border-teal-400'
                      }`}
                    >
                      <div className="font-bold text-xs">{item.label}</div>
                      <div className={`text-[10px] mt-0.5 ${sourceGenCount === item.count ? 'text-teal-100' : 'text-slate-400'}`}>
                        {item.sub}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1.5">
                  مستوى الصعوبة:
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'easy', label: 'سهل', desc: 'مفاهيم وقواعد' },
                    { id: 'medium', label: 'متوسط', desc: 'وزاري معتمد' },
                    { id: 'hard', label: 'متقدم', desc: 'تحدي ومسائل' },
                  ].map((lvl) => (
                    <button
                      key={lvl.id}
                      type="button"
                      onClick={() => setSourceGenDifficulty(lvl.id as DifficultyLevel)}
                      className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                        sourceGenDifficulty === lvl.id
                          ? 'bg-teal-600 text-white border-teal-700 shadow-xs'
                          : 'bg-slate-50 dark:bg-[#1a2723] border-slate-200 dark:border-[#22352f] text-slate-700 dark:text-slate-200 hover:border-teal-400'
                      }`}
                    >
                      <div className="font-bold text-xs">{lvl.label}</div>
                      <div className={`text-[10px] mt-0.5 ${sourceGenDifficulty === lvl.id ? 'text-teal-100' : 'text-slate-400'}`}>
                        {lvl.desc}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {sourceGenToast && (
                <div className="p-3 rounded-xl bg-teal-50 dark:bg-teal-950/50 border border-teal-300/40 text-teal-800 dark:text-teal-200 text-xs font-bold flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-teal-600 animate-spin shrink-0" />
                  <span>{sourceGenToast}</span>
                </div>
              )}
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200 dark:border-[#22352f]">
              <button
                type="button"
                onClick={() => setIsSourceGenModalOpen(false)}
                disabled={isGeneratingFromSource}
                className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-[#1a2925] text-slate-700 dark:text-slate-300 text-xs font-bold cursor-pointer hover:bg-slate-200"
              >
                إلغاء
              </button>
              <button
                type="button"
                disabled={isGeneratingFromSource}
                onClick={handleGenerateFromSource}
                className="px-5 py-2 rounded-xl bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 text-white text-xs font-black shadow-md cursor-pointer disabled:opacity-50 flex items-center gap-1.5"
              >
                <Sparkles className="w-4 h-4 text-amber-300" />
                <span>{isGeneratingFromSource ? 'جارٍ التوليد...' : 'توليد الأسئلة وإضافتها للبنك 🪄'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ---------------------------------------------------------- */}
      {/* ACTIVE RECALL QUIZ MODAL (Instant Grading & Explanations)  */}
      {/* ---------------------------------------------------------- */}
      {isActiveRecallOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-in fade-in">
          <div className="bg-white dark:bg-[#121c19] border-2 border-purple-500/40 rounded-3xl max-w-xl w-full p-5 sm:p-6 shadow-2xl relative space-y-4 max-h-[90vh] overflow-y-auto">
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 border-b border-gray-200 dark:border-gray-800">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-purple-100 dark:bg-purple-950/70 text-purple-600 dark:text-purple-300 flex items-center justify-center font-bold">
                  🧠
                </div>
                <div>
                  <h3 className="font-black text-sm sm:text-base text-gray-900 dark:text-gray-100">
                    اختبار الاسترجاع النشط (Active Recall Quiz)
                  </h3>
                  <p className="text-[11px] text-gray-500 dark:text-gray-400">
                    تقييم فوري وتثبيت معرفي من مراجع ودفاتر الطالب
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {!activeRecallIsFinished && activeRecallQuestions.length > 0 && (
                  <span className="px-2.5 py-1 rounded-full bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300 text-xs font-bold border border-purple-300 dark:border-purple-800">
                    سؤال {activeRecallCurrentIndex + 1} من {activeRecallQuestions.length}
                  </span>
                )}
                <button
                  type="button"
                  onClick={() => setIsActiveRecallOpen(false)}
                  className="w-8 h-8 rounded-full bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 text-gray-500 hover:text-gray-800 flex items-center justify-center transition-all cursor-pointer"
                >
                  ✕
                </button>
              </div>
            </div>

            {/* Quiz Content */}
            {activeRecallGenerating ? (
              <div className="py-12 text-center space-y-3">
                <Sparkles className="w-8 h-8 text-purple-600 animate-spin mx-auto" />
                <p className="text-xs font-bold text-gray-700 dark:text-gray-300">
                  جارٍ إعداد كتل الاسترجاع النشط والأسئلة من مصادر الدفتر...
                </p>
              </div>
            ) : activeRecallIsFinished ? (
              /* Finish Screen */
              <div className="py-6 text-center space-y-5 animate-in zoom-in-95 duration-200">
                <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-purple-500 to-indigo-500 text-white flex items-center justify-center text-3xl mx-auto shadow-lg shadow-purple-500/25">
                  🏆
                </div>

                <div className="space-y-1">
                  <h4 className="text-xl font-black text-gray-900 dark:text-gray-100">
                    اكتمل اختبار الاسترجاع النشط!
                  </h4>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    نتيجتك في تثبيت مفاهيم الدفتر والمصادر:
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-purple-50 dark:bg-purple-950/40 border border-purple-200 dark:border-purple-800/60 inline-block px-8">
                  <div className="text-3xl font-black text-purple-700 dark:text-purple-300">
                    {activeRecallScore} / {activeRecallQuestions.length}
                  </div>
                  <div className="text-xs font-bold text-purple-600 dark:text-purple-400 mt-1">
                    نسبة الإتقان: {Math.round((activeRecallScore / activeRecallQuestions.length) * 100)}%
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row items-center justify-center gap-2 pt-2">
                  <button
                    type="button"
                    onClick={handleStartActiveRecallQuiz}
                    className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs shadow-md transition-all cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <RotateCcw className="w-4 h-4" />
                    <span>إعادة الاختبار بأسئلة جديدة</span>
                  </button>

                  {onExportToNote && (
                    <button
                      type="button"
                      onClick={() => {
                        const noteContent = `### 🧠 تقرير اختبار الاسترجاع النشط (Active Recall)\n\n- **النتيجة:** ${activeRecallScore} من ${activeRecallQuestions.length} (${Math.round((activeRecallScore / activeRecallQuestions.length) * 100)}%)\n- **التاريخ:** ${new Date().toLocaleDateString('ar-YE')}\n\n#### الأسئلة والمفاهيم التي تم اختبارها:\n` +
                          activeRecallQuestions.map((q, i) => `${i + 1}. **السؤال:** ${q.question}\n   - **الإجابة النموذجية:** ${q.options[q.correctAnswer]}\n   - **التأصيل:** ${q.explanation}\n`).join('\n');
                        onExportToNote('تقرير استرجاع نشط: مصادر الدفتر', noteContent);
                        setIsActiveRecallOpen(false);
                      }}
                      className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-teal-50 dark:bg-teal-950 text-teal-800 dark:text-teal-200 border border-teal-300 dark:border-teal-800 font-bold text-xs hover:bg-teal-100 transition-all cursor-pointer flex items-center justify-center gap-1.5"
                    >
                      <Bookmark className="w-4 h-4 text-teal-600" />
                      <span>حفظ النتيجة كتدوينة في الدفتر</span>
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() => setIsActiveRecallOpen(false)}
                    className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 font-bold text-xs hover:bg-gray-200 transition-all cursor-pointer"
                  >
                    إغلاق
                  </button>
                </div>
              </div>
            ) : (
              /* Active Question */
              (() => {
                const currentQ = activeRecallQuestions[activeRecallCurrentIndex];
                if (!currentQ) return null;
                const userChoice = activeRecallAnswers[activeRecallCurrentIndex];
                const isAnswered = userChoice !== undefined;

                return (
                  <div className="space-y-4">
                    {/* Source context badge */}
                    {currentQ.sourceChunkTitle && (
                      <div className="flex items-center gap-1.5 text-[11px] font-bold text-purple-700 dark:text-purple-300 bg-purple-50 dark:bg-purple-950/60 p-2 rounded-xl border border-purple-200/60 dark:border-purple-800/40">
                        <BookOpen className="w-3.5 h-3.5 shrink-0" />
                        <span className="truncate">مصدر السؤال: {currentQ.sourceChunkTitle}</span>
                      </div>
                    )}

                    {/* Question text */}
                    <div className="p-4 rounded-2xl bg-gray-50 dark:bg-[#162320] border border-gray-200 dark:border-gray-800">
                      <div className="font-bold text-xs sm:text-sm text-gray-900 dark:text-gray-100 leading-relaxed">
                        <SafeMathText text={currentQ.question} />
                      </div>
                    </div>

                    {/* Options list with instant grading */}
                    <div className="space-y-2">
                      {currentQ.options.map((opt, optIdx) => {
                        const isSelected = userChoice === optIdx;
                        const isCorrectAnswer = optIdx === currentQ.correctAnswer;

                        let styleClasses = 'bg-white dark:bg-[#14201c] border-gray-200 dark:border-gray-800 text-gray-800 dark:text-gray-200 hover:border-purple-400';

                        if (isAnswered) {
                          if (isCorrectAnswer) {
                            styleClasses = 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-500 text-emerald-900 dark:text-emerald-100 font-black';
                          } else if (isSelected && !isCorrectAnswer) {
                            styleClasses = 'bg-rose-50 dark:bg-rose-950/60 border-rose-500 text-rose-900 dark:text-rose-100 font-bold';
                          } else {
                            styleClasses = 'opacity-50 border-gray-200 dark:border-gray-800 text-gray-500';
                          }
                        }

                        return (
                          <button
                            key={optIdx}
                            type="button"
                            disabled={isAnswered}
                            onClick={() => handleActiveRecallAnswerSelect(optIdx)}
                            className={`w-full p-3 rounded-xl border-2 text-right transition-all flex items-center justify-between gap-2.5 text-xs ${styleClasses} ${
                              !isAnswered ? 'cursor-pointer active:scale-98' : 'cursor-default'
                            }`}
                          >
                            <div className="flex items-center gap-2.5 min-w-0">
                              <span className="w-6 h-6 rounded-lg bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 font-bold text-xs flex items-center justify-center shrink-0">
                                {OPTION_LETTERS[optIdx] || optIdx + 1}
                              </span>
                              <span className="leading-relaxed">
                                <SafeMathText text={opt} />
                              </span>
                            </div>

                            {isAnswered && (
                              <div className="shrink-0">
                                {isCorrectAnswer ? (
                                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                                ) : isSelected ? (
                                  <XCircle className="w-4 h-4 text-rose-500" />
                                ) : null}
                              </div>
                            )}
                          </button>
                        );
                      })}
                    </div>

                    {/* Instant Feedback & Academic Explanation */}
                    {isAnswered && (
                      <div className="space-y-3 pt-2 animate-in fade-in duration-200">
                        <div className={`p-3.5 rounded-2xl border ${
                          userChoice === currentQ.correctAnswer
                            ? 'bg-emerald-50/70 dark:bg-emerald-950/40 border-emerald-300 dark:border-emerald-800'
                            : 'bg-amber-50/70 dark:bg-amber-950/40 border-amber-300 dark:border-amber-800'
                        }`}>
                          <div className="flex items-center gap-1.5 font-black text-xs mb-1">
                            {userChoice === currentQ.correctAnswer ? (
                              <span className="text-emerald-700 dark:text-emerald-300 flex items-center gap-1">
                                <Check className="w-3.5 h-3.5" />
                                إجابة صحيحة! أحسنت الاسترجاع
                              </span>
                            ) : (
                              <span className="text-amber-800 dark:text-amber-300 flex items-center gap-1">
                                <Info className="w-3.5 h-3.5" />
                                التعليل والحل النموذجي المعتمد:
                              </span>
                            )}
                          </div>
                          <div className="text-xs text-gray-700 dark:text-gray-300 leading-relaxed">
                            <SafeMathText text={currentQ.explanation} block />
                          </div>
                        </div>

                        <div className="flex items-center justify-end pt-1">
                          <button
                            type="button"
                            onClick={handleActiveRecallNext}
                            className="px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-black text-xs shadow-md transition-all cursor-pointer flex items-center gap-1.5 active:scale-98"
                          >
                            <span>{activeRecallCurrentIndex < activeRecallQuestions.length - 1 ? 'السؤال التالي' : 'عرض النتيجة النهائية 🏆'}</span>
                            <ChevronLeft className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })()
            )}
          </div>
        </div>
      )}
    </div>
  );
};
