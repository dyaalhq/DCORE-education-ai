import React, { useState, useEffect, useRef } from 'react';
import { 
  Bell, 
  Clock, 
  ShieldCheck, 
  Check, 
  Sparkles, 
  Timer, 
  Volume2, 
  AlertCircle,
  Play,
  RotateCcw
} from 'lucide-react';

interface StudyReminderSettings {
  enabled: boolean;
  dailyTime: string; // e.g. "18:00"
  inactivityThresholdMins: number; // e.g. 15, 30, 45, 60
  soundEnabled: boolean;
  lastNotifiedDate?: string;
}

const STORAGE_KEY = 'smart_teacher_study_reminder_settings';

export const StudyReminderController: React.FC = () => {
  const [settings, setSettings] = useState<StudyReminderSettings>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) return JSON.parse(stored);
    } catch (e) {
      // ignore
    }
    return {
      enabled: false,
      dailyTime: '18:00',
      inactivityThresholdMins: 20,
      soundEnabled: true,
    };
  });

  const [permission, setPermission] = useState<NotificationPermission>('default');
  const [isInactive, setIsInactive] = useState(false);
  const [inactiveSeconds, setInactiveSeconds] = useState(0);
  const [testSuccess, setTestSuccess] = useState(false);

  const lastActivityRef = useRef<number>(Date.now());
  const inactivityNotifiedRef = useRef<boolean>(false);

  // Check initial permission
  useEffect(() => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      setPermission(Notification.permission);
    }
  }, []);

  // Save settings
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
    } catch (e) {
      // ignore
    }
  }, [settings]);

  // Activity listeners to detect user inactivity
  useEffect(() => {
    if (!settings.enabled) return;

    const handleUserActivity = () => {
      lastActivityRef.current = Date.now();
      if (inactivityNotifiedRef.current) {
        inactivityNotifiedRef.current = false;
        setIsInactive(false);
      }
    };

    const events = ['mousemove', 'keydown', 'touchstart', 'scroll', 'click'];
    events.forEach((ev) => window.addEventListener(ev, handleUserActivity, { passive: true }));

    // Heartbeat timer checking every 5 seconds
    const interval = setInterval(() => {
      const now = Date.now();
      const elapsedMins = (now - lastActivityRef.current) / (1000 * 60);
      const elapsedSecs = Math.floor((now - lastActivityRef.current) / 1000);
      setInactiveSeconds(elapsedSecs);

      // Check Inactivity Alert
      if (elapsedMins >= settings.inactivityThresholdMins && !inactivityNotifiedRef.current) {
        inactivityNotifiedRef.current = true;
        setIsInactive(true);
        triggerNotification(
          '⏰ تذكير: لم تقم بأي نشاط مذاكرة منذ فترة!',
          `مرت ${settings.inactivityThresholdMins} دقيقة من دون نشاط في المعلم الذكي. عد الآن لإنجاز مهامك المقررة والاحتفاظ بسلسلة تركيزك 🎯`
        );
      }

      // Check Daily Scheduled Reminder Time (HH:MM)
      const currentHours = String(new Date().getHours()).padStart(2, '0');
      const currentMinutes = String(new Date().getMinutes()).padStart(2, '0');
      const currentTimeStr = `${currentHours}:${currentMinutes}`;
      const todayDateStr = new Date().toISOString().slice(0, 10);

      if (
        currentTimeStr === settings.dailyTime &&
        settings.lastNotifiedDate !== todayDateStr
      ) {
        setSettings((prev) => ({ ...prev, lastNotifiedDate: todayDateStr }));
        triggerNotification(
          '🔔 حان موعد المذاكرة اليومية المجدول!',
          'حان الوقت المخصص لمراجعة بطاقاتك التكرارية وإنهاء قائمة المهام في المعلم الذكي 📚'
        );
      }
    }, 5000);

    return () => {
      events.forEach((ev) => window.removeEventListener(ev, handleUserActivity));
      clearInterval(interval);
    };
  }, [settings]);

  const requestPermissionAndEnable = async () => {
    if (typeof window === 'undefined' || !('Notification' in window)) {
      alert('متصفحك الحالي لا يدعم إشعارات سطح المكتب (Browser Notifications).');
      return;
    }

    try {
      const res = await Notification.requestPermission();
      setPermission(res);
      if (res === 'granted') {
        setSettings((prev) => ({ ...prev, enabled: true }));
        triggerNotification('✅ تم تفعيل تذكيرات المذاكرة بنجاح', 'سنقوم بتنبيهك يومياً وعند الخمول لإبقائك على مسار التفوق الأكاديمي!');
      } else {
        alert('تم رفض إذن الإشعارات من المتصفح. يمكنك تفعيله يدويًا من إعدادات الموقع في شريط العناوين.');
      }
    } catch (e) {
      console.error('Notification error:', e);
    }
  };

  const triggerNotification = (title: string, body: string) => {
    if (typeof window === 'undefined' || !('Notification' in window)) return;

    if (Notification.permission === 'granted') {
      try {
        const notif = new Notification(title, {
          body,
          icon: '/favicon.ico',
          tag: 'study-reminder',
        });
        notif.onclick = () => {
          window.focus();
          notif.close();
        };

        // Play subtle sound if enabled
        if (settings.soundEnabled && 'AudioContext' in window) {
          try {
            const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
            osc.frequency.setValueAtTime(880, ctx.currentTime + 0.12); // A5
            gain.gain.setValueAtTime(0.2, ctx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.35);
            osc.start();
            osc.stop(ctx.currentTime + 0.35);
          } catch (audioErr) {
            // ignore
          }
        }
      } catch (e) {
        console.warn('Could not fire Notification:', e);
      }
    }
  };

  const handleTestNotification = () => {
    if (Notification.permission !== 'granted') {
      requestPermissionAndEnable();
      return;
    }
    triggerNotification(
      '🎯 تجربة إشعار المعلم الذكي',
      'يعمل نظام التذكير وإشعارات المتصفح بنجاح وبدقة متناهية!'
    );
    setTestSuccess(true);
    setTimeout(() => setTestSuccess(false), 3000);
  };

  return (
    <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-teal-50/90 via-emerald-50/50 to-white dark:from-[#13221d] dark:via-[#162721] dark:to-[#121c18] border border-teal-200/80 dark:border-teal-800/60 shadow-xs space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-teal-600 text-white flex items-center justify-center shrink-0 shadow-md shadow-teal-600/20">
            <Bell className="w-4 h-4" />
          </div>
          <div>
            <h4 className="font-extrabold text-xs sm:text-sm text-teal-950 dark:text-teal-100 flex items-center gap-2">
              <span>تذكير المذاكرة اليومي وإشعارات الخمول</span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-teal-100 dark:bg-teal-900/60 text-teal-800 dark:text-teal-300 font-mono font-bold">
                Browser Notification
              </span>
            </h4>
            <p className="text-[11px] text-teal-800/80 dark:text-teal-300/80 mt-0.5">
              ينبهك المتصفح بموعد دراستك اليومي، ويرسل إشعاراً إذا توقفت عن المذاكرة أو خمل التطبيق.
            </p>
          </div>
        </div>

        {/* Master Toggle */}
        <div className="flex items-center gap-2">
          {permission !== 'granted' ? (
            <button
              type="button"
              onClick={requestPermissionAndEnable}
              className="px-3.5 py-1.5 rounded-xl bg-teal-700 hover:bg-teal-800 text-white text-xs font-bold transition-all shadow-xs cursor-pointer flex items-center gap-1.5"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>منح إذن المتصفح وتفعيل</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={() => setSettings((s) => ({ ...s, enabled: !s.enabled }))}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                settings.enabled
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
              }`}
            >
              <span className={`w-2 h-2 rounded-full ${settings.enabled ? 'bg-white animate-pulse' : 'bg-slate-400'}`} />
              <span>{settings.enabled ? 'التذكير مفعّل' : 'التذكير معطل'}</span>
            </button>
          )}
        </div>
      </div>

      {/* Settings Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 border-t border-teal-200/50 dark:border-teal-800/40 text-xs">
        {/* 1. Daily Study Time */}
        <div className="p-3 rounded-xl bg-white/90 dark:bg-[#182923] border border-teal-100 dark:border-teal-900/60 space-y-1.5">
          <label className="text-[11px] font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
            <span>وقت التذكير اليومي:</span>
          </label>
          <input
            type="time"
            value={settings.dailyTime}
            onChange={(e) => setSettings((s) => ({ ...s, dailyTime: e.target.value }))}
            className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#121c18] font-mono text-xs font-bold text-teal-900 dark:text-teal-200 focus:outline-none focus:ring-1 focus:ring-teal-500"
          />
        </div>

        {/* 2. Inactivity Threshold */}
        <div className="p-3 rounded-xl bg-white/90 dark:bg-[#182923] border border-teal-100 dark:border-teal-900/60 space-y-1.5">
          <label className="text-[11px] font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
            <Timer className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
            <span>مدة الخمول قبل التنبيه:</span>
          </label>
          <select
            value={settings.inactivityThresholdMins}
            onChange={(e) => setSettings((s) => ({ ...s, inactivityThresholdMins: Number(e.target.value) }))}
            className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#121c18] text-xs font-bold text-teal-900 dark:text-teal-200 focus:outline-none focus:ring-1 focus:ring-teal-500"
          >
            <option value={10}>10 دقائق خمول</option>
            <option value={15}>15 دقيقة خمول</option>
            <option value={20}>20 دقيقة (موصى به)</option>
            <option value={30}>30 دقيقة خمول</option>
            <option value={45}>45 دقيقة خمول</option>
            <option value={60}>60 دقيقة (ساعة كاملة)</option>
          </select>
        </div>

        {/* 3. Actions & Test */}
        <div className="p-3 rounded-xl bg-white/90 dark:bg-[#182923] border border-teal-100 dark:border-teal-900/60 flex flex-col justify-between space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-[11px] font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1">
              <Volume2 className="w-3.5 h-3.5 text-teal-600" />
              <span>صوت التنبيه:</span>
            </label>
            <input
              type="checkbox"
              checked={settings.soundEnabled}
              onChange={(e) => setSettings((s) => ({ ...s, soundEnabled: e.target.checked }))}
              className="accent-teal-600 rounded cursor-pointer"
            />
          </div>

          <button
            type="button"
            onClick={handleTestNotification}
            className="w-full py-1.5 px-2 rounded-lg bg-teal-100 hover:bg-teal-200 dark:bg-teal-950/80 dark:hover:bg-teal-900/80 text-teal-900 dark:text-teal-200 text-[11px] font-bold transition flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
          >
            {testSuccess ? (
              <>
                <Check className="w-3 h-3 text-emerald-600" />
                <span>تم إرسال الإشعار!</span>
              </>
            ) : (
              <>
                <Play className="w-3 h-3 text-teal-600" />
                <span>اختبار الإشعار فورياً</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Live status badge */}
      {settings.enabled && (
        <div className="flex items-center justify-between text-[10px] text-teal-800/80 dark:text-teal-300/80 pt-1">
          <span className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
            <span>نظام مراقبة النشاط نشط: آخر نشاط مسجل منذ {inactiveSeconds} ثانية.</span>
          </span>
          <span className="font-mono">
            التذكير القادم: يومياً الساعة {settings.dailyTime}
          </span>
        </div>
      )}
    </div>
  );
};
