import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  FlaskConical,
  Atom,
  Dna,
  Microscope,
  Play,
  Pause,
  RotateCcw,
  Sparkles,
  Sliders,
  Compass,
  Layers,
  ChevronRight,
  BookOpen,
  MessageSquare,
  Printer,
  Plus,
  Check,
  Search,
  Info,
  Maximize2,
  Activity,
  Flame,
  Zap,
  Eye,
  FileText
} from 'lucide-react';
import { Notebook, Source } from '../types';
import { SafeBlockMath, SafeInlineMath } from './EducationalContent';
import { AcademicPrintModal } from './AcademicPrintModal';
import { StructuredSummary, extractStructuredSummary } from '../lib/academicFormatter';
import { InteractiveLab3DCanvas, Interactive3DTool, LAB_3D_TOOLS } from './InteractiveLab3DCanvas';
import { Box } from 'lucide-react';
import { AiLabAssistant } from './AiLabAssistant';

interface ScienceLabViewProps {
  currentNotebook: Notebook;
  notebookSources?: Source[];
  onAskAiAboutExperiment?: (experimentContext: string) => void;
  onSaveExperimentAsNote?: (title: string, content: string) => void;
}

// -------------------------------------------------------------
// Chemical Elements Periodic Table Dataset (Comprehensive)
// -------------------------------------------------------------
interface ChemicalElement {
  number: number;
  symbol: string;
  nameAr: string;
  nameEn: string;
  weight: number;
  category: 'alkali' | 'alkaline-earth' | 'transition' | 'post-transition' | 'metalloid' | 'nonmetal' | 'halogen' | 'noble-gas' | 'lanthanide' | 'actinide';
  electronConfig: string;
  shells: number[];
  electronegativity?: number;
  phase: 'gas' | 'liquid' | 'solid';
  meltingPoint?: number; // Kelvin
  boilingPoint?: number; // Kelvin
  descriptionAr: string;
}

const PERIODIC_ELEMENTS: ChemicalElement[] = [
  { number: 1, symbol: 'H', nameAr: 'هيدروجين', nameEn: 'Hydrogen', weight: 1.008, category: 'nonmetal', electronConfig: '1s¹', shells: [1], electronegativity: 2.20, phase: 'gas', meltingPoint: 14.01, boilingPoint: 20.28, descriptionAr: 'أخف العناصر وأكثرها وفرة في الكون، يشكل الماء ووقود النجوم والروابط الهيدروجينية الحيوية.' },
  { number: 2, symbol: 'He', nameAr: 'هيليوم', nameEn: 'Helium', weight: 4.0026, category: 'noble-gas', electronConfig: '1s²', shells: [2], electronegativity: undefined, phase: 'gas', meltingPoint: 0.95, boilingPoint: 4.22, descriptionAr: 'غاز نبيل خامل، ثاني أكثر العناصر وفرة، يُستخدم في التبريد الفائق والمناطيد.' },
  { number: 3, symbol: 'Li', nameAr: 'ليثيوم', nameEn: 'Lithium', weight: 6.94, category: 'alkali', electronConfig: '[He] 2s¹', shells: [2, 1], electronegativity: 0.98, phase: 'solid', meltingPoint: 453.69, boilingPoint: 1603, descriptionAr: 'فلز قلوي خفيف وفضي، شديد التفاعل مع الماء، أساس بطاريات الأجهزة والإلكترونيات الحديثة.' },
  { number: 4, symbol: 'Be', nameAr: 'بيريليوم', nameEn: 'Beryllium', weight: 9.0122, category: 'alkaline-earth', electronConfig: '[He] 2s²', shells: [2, 2], electronegativity: 1.57, phase: 'solid', meltingPoint: 1560, boilingPoint: 2742, descriptionAr: 'فلز قلوي ترابي خفيف وصلب، يُستخدم في سبائك الطيران والمفاعلات النووية.' },
  { number: 5, symbol: 'B', nameAr: 'بورون', nameEn: 'Boron', weight: 10.81, category: 'metalloid', electronConfig: '[He] 2s² 2p¹', shells: [2, 3], electronegativity: 2.04, phase: 'solid', meltingPoint: 2349, boilingPoint: 4200, descriptionAr: 'شبه فلز صلب ذو روابط تساهمية قوية، يدخل في صناعة زجاج البوروسيليكات وأشباه الموصلات.' },
  { number: 6, symbol: 'C', nameAr: 'كربون', nameEn: 'Carbon', weight: 12.011, category: 'nonmetal', electronConfig: '[He] 2s² 2p²', shells: [2, 4], electronegativity: 2.55, phase: 'solid', meltingPoint: 3800, boilingPoint: 4300, descriptionAr: 'أساس الكيمياء العضوية وكافة أشكال الحياة، يوجد في صور تآصلية مذهلة كالجرافيت والماس والجرافين.' },
  { number: 7, symbol: 'N', nameAr: 'نيتروجين', nameEn: 'Nitrogen', weight: 14.007, category: 'nonmetal', electronConfig: '[He] 2s² 2p³', shells: [2, 5], electronegativity: 3.04, phase: 'gas', meltingPoint: 63.15, boilingPoint: 77.36, descriptionAr: 'يشكل 78% من الغلاف الجوي، رابطته الثلاثية N≡N بالغة القوة، أساس الأحماض الأمينية والبروتينات.' },
  { number: 8, symbol: 'O', nameAr: 'أكسجين', nameEn: 'Oxygen', weight: 15.999, category: 'nonmetal', electronConfig: '[He] 2s² 2p⁴', shells: [2, 6], electronegativity: 3.44, phase: 'gas', meltingPoint: 54.36, boilingPoint: 90.20, descriptionAr: 'عنصر التنفس والاحتراق، عالي الكهروسالبية، يشكل خمس هواء الأرض وأغلب كتلة الماء في المحيطات.' },
  { number: 9, symbol: 'F', nameAr: 'فلور', nameEn: 'Fluorine', weight: 18.998, category: 'halogen', electronConfig: '[He] 2s² 2p⁵', shells: [2, 7], electronegativity: 3.98, phase: 'gas', meltingPoint: 53.53, boilingPoint: 85.03, descriptionAr: 'أعلى العناصر كهروسالبية وأشد الهالوجينات نشاطاً، يتفاعل مع سائر المواد تقريباً.' },
  { number: 10, symbol: 'Ne', nameAr: 'نيون', nameEn: 'Neon', weight: 20.180, category: 'noble-gas', electronConfig: '[He] 2s² 2p⁶', shells: [2, 8], electronegativity: undefined, phase: 'gas', meltingPoint: 24.56, boilingPoint: 27.07, descriptionAr: 'غاز خامل يتوهج ببريق برتقالي محمر رائع عند مرور تيار كهربائي عالي الجهد في أنابيبه.' },
  { number: 11, symbol: 'Na', nameAr: 'صوديوم', nameEn: 'Sodium', weight: 22.990, category: 'alkali', electronConfig: '[Ne] 3s¹', shells: [2, 8, 1], electronegativity: 0.93, phase: 'solid', meltingPoint: 370.87, boilingPoint: 1156, descriptionAr: 'فلز قلوي لين، يتفاعل بعنف مع الماء مطلقاً غاز الهيدروجين، أساس ملح الطعام NaCl.' },
  { number: 12, symbol: 'Mg', nameAr: 'مغنيسيوم', nameEn: 'Magnesium', weight: 24.305, category: 'alkaline-earth', electronConfig: '[Ne] 3s²', shells: [2, 8, 2], electronegativity: 1.31, phase: 'solid', meltingPoint: 923, boilingPoint: 1363, descriptionAr: 'فلز فضي يشتعل بضوء أبيض ساطع، الذرة المركزية في جزيء الكلوروفيل المسؤول عن البناء الضوئي.' },
  { number: 13, symbol: 'Al', nameAr: 'ألومنيوم', nameEn: 'Aluminium', weight: 26.982, category: 'post-transition', electronConfig: '[Ne] 3s² 3p¹', shells: [2, 8, 3], electronegativity: 1.61, phase: 'solid', meltingPoint: 933.47, boilingPoint: 2792, descriptionAr: 'فلز خفيف مقاوم للتآكل بسبب طبقة الأكسيد الواقية، واسع الاستخدام في الطائرات والأواني والإنشاءات.' },
  { number: 14, symbol: 'Si', nameAr: 'سيليكون', nameEn: 'Silicon', weight: 28.085, category: 'metalloid', electronConfig: '[Ne] 3s² 3p²', shells: [2, 8, 4], electronegativity: 1.90, phase: 'solid', meltingPoint: 1687, boilingPoint: 3538, descriptionAr: 'شبه فلز هو عصب الثورة الرقمية والمعالجات الدقيقة، ويشكل الجزء الأكبر من رمال الأرض وصخورها.' },
  { number: 15, symbol: 'P', nameAr: 'فوسفور', nameEn: 'Phosphorus', weight: 30.974, category: 'nonmetal', electronConfig: '[Ne] 3s² 3p³', shells: [2, 8, 5], electronegativity: 2.19, phase: 'solid', meltingPoint: 317.3, boilingPoint: 553.6, descriptionAr: 'عنصر حيوي يدخل في تركيب الحمض النووي DNA وعملة الطاقة الخلوية ATP والأسمدة الزراعية.' },
  { number: 16, symbol: 'S', nameAr: 'كبريت', nameEn: 'Sulfur', weight: 32.06, category: 'nonmetal', electronConfig: '[Ne] 3s² 3p⁴', shells: [2, 8, 6], electronegativity: 2.58, phase: 'solid', meltingPoint: 388.36, boilingPoint: 717.8, descriptionAr: 'لافلز أصفر فاقع، أساس حمض الكبريتيك H₂SO₄ أهم الأحماض الصناعية، ويدخل في روابط البروتينات.' },
  { number: 17, symbol: 'Cl', nameAr: 'كلور', nameEn: 'Chlorine', weight: 35.45, category: 'halogen', electronConfig: '[Ne] 3s² 3p⁵', shells: [2, 8, 7], electronegativity: 3.16, phase: 'gas', meltingPoint: 171.6, boilingPoint: 239.11, descriptionAr: 'غاز هالوجيني أصفر مخضر سام، عامل مؤكسد قوي يُستخدم في تعقيم المياه وصناعة البوليمرات PVC.' },
  { number: 18, symbol: 'Ar', nameAr: 'أرجون', nameEn: 'Argon', weight: 39.948, category: 'noble-gas', electronConfig: '[Ne] 3s² 3p⁶', shells: [2, 8, 8], electronegativity: undefined, phase: 'gas', meltingPoint: 83.80, boilingPoint: 87.30, descriptionAr: 'أكثر الغازات النبيلة وفرة في هواء الأرض (حوالي 0.93%)، يُستخدم كغاز خامل واقٍ في لحام المعادن.' },
  { number: 19, symbol: 'K', nameAr: 'بوتاسيوم', nameEn: 'Potassium', weight: 39.098, category: 'alkali', electronConfig: '[Ar] 4s¹', shells: [2, 8, 8, 1], electronegativity: 0.82, phase: 'solid', meltingPoint: 336.53, boilingPoint: 1032, descriptionAr: 'فلز قلوي شديد الفعالية، حيوي لعمل الخلايا العصبية والقلب وانتقال السيالات العصبية في الكائنات.' },
  { number: 20, symbol: 'Ca', nameAr: 'كالسيوم', nameEn: 'Calcium', weight: 40.078, category: 'alkaline-earth', electronConfig: '[Ar] 4s²', shells: [2, 8, 8, 2], electronegativity: 1.00, phase: 'solid', meltingPoint: 1115, boilingPoint: 1757, descriptionAr: 'المعدن الأساسي في بناء العظام والأسنان وقشور البيض والحجر الجيري CaCO₃، وحيوي لانقباض العضلات.' },
  { number: 26, symbol: 'Fe', nameAr: 'حديد', nameEn: 'Iron', weight: 55.845, category: 'transition', electronConfig: '[Ar] 3d⁶ 4s²', shells: [2, 8, 14, 2], electronegativity: 1.83, phase: 'solid', meltingPoint: 1811, boilingPoint: 3134, descriptionAr: 'عماد الحضارة الإنسانية والصناعات الثقيلة، والذرة المركزية في الهيموجلوبين لنقل الأكسجين في الدم.' },
  { number: 29, symbol: 'Cu', nameAr: 'نحاس', nameEn: 'Copper', weight: 63.546, category: 'transition', electronConfig: '[Ar] 3d¹⁰ 4s¹', shells: [2, 8, 18, 1], electronegativity: 1.90, phase: 'solid', meltingPoint: 1357.77, boilingPoint: 2835, descriptionAr: 'فلز أحمر مميز فائق التوصيل للكهرباء والحرارة، مضاد للبكتيريا، أساس الأسلاك والسبائك كالبرونز.' },
  { number: 30, symbol: 'Zn', nameAr: 'زنك (خارصين)', nameEn: 'Zinc', weight: 65.38, category: 'transition', electronConfig: '[Ar] 3d¹⁰ 4s²', shells: [2, 8, 18, 2], electronegativity: 1.65, phase: 'solid', meltingPoint: 692.68, boilingPoint: 1180, descriptionAr: 'فلز مقاوم للصدأ يُستخدم في جلفنة الحديد، وعنصر أثر حيوي في أكثر من 300 إنزيم في جسم الإنسان.' },
  { number: 47, symbol: 'Ag', nameAr: 'فضة', nameEn: 'Silver', weight: 107.87, category: 'transition', electronConfig: '[Kr] 4d¹⁰ 5s¹', shells: [2, 8, 18, 18, 1], electronegativity: 1.93, phase: 'solid', meltingPoint: 1234.93, boilingPoint: 2435, descriptionAr: 'أعلى العناصر توصيلاً للكهرباء والحرارة وأعلاها انعكاساً للضوء، وله خواص مطهرة ومعقمة عريقة.' },
  { number: 79, symbol: 'Au', nameAr: 'ذهب', nameEn: 'Gold', weight: 196.97, category: 'transition', electronConfig: '[Xe] 4f¹⁴ 5d¹⁰ 6s¹', shells: [2, 8, 18, 32, 18, 1], electronegativity: 2.54, phase: 'solid', meltingPoint: 1337.33, boilingPoint: 3129, descriptionAr: 'فلز نفيس غير قابل للتأكسد، رمز الثروة عبر التاريخ، ويُستخدم في الإلكترونيات الدقيقة والطب النانوي.' }
];

export const ScienceLabView: React.FC<ScienceLabViewProps> = ({
  currentNotebook,
  notebookSources = [],
  onAskAiAboutExperiment,
  onSaveExperimentAsNote,
}) => {
  // Main lab section
  const [activeLabDomain, setActiveLabDomain] = useState<'3d_lab' | 'ai_copilot' | 'physics' | 'chemistry' | 'biology' | 'research'>('3d_lab');
  const [activeInspected3DTool, setActiveInspected3DTool] = useState<Interactive3DTool | null>(null);

  // Academic Print Modal state for Lab Reports
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);
  const [printModalSummary, setPrintModalSummary] = useState<StructuredSummary | null>(null);

  // -------------------------------------------------------------
  // 1. PHYSICS LAB STATE: Simple Pendulum Simulation
  // -------------------------------------------------------------
  const [pendulumLength, setPendulumLength] = useState<number>(1.0); // meters
  const [pendulumGravity, setPendulumGravity] = useState<number>(9.8); // m/s^2 (Earth: 9.8, Moon: 1.62, Mars: 3.71, Jupiter: 24.79)
  const [pendulumMass, setPendulumMass] = useState<number>(0.5); // kg
  const [initialAngleDeg, setInitialAngleDeg] = useState<number>(25); // degrees
  const [isPendulumRunning, setIsPendulumRunning] = useState<boolean>(true);
  const pendulumTimeRef = useRef<number>(0);
  const pendulumCanvasRef = useRef<HTMLCanvasElement | null>(null);

  // Calculated pendulum theoretical values
  const theoreticalPeriod = useMemo(() => {
    return 2 * Math.PI * Math.sqrt(pendulumLength / Math.max(0.1, pendulumGravity));
  }, [pendulumLength, pendulumGravity]);

  const theoreticalFrequency = useMemo(() => {
    return 1 / theoreticalPeriod;
  }, [theoreticalPeriod]);

  // Pendulum Animation Loop
  useEffect(() => {
    let animId: number;
    let lastTimestamp = performance.now();

    const render = (now: number) => {
      const dt = (now - lastTimestamp) / 1000;
      lastTimestamp = now;

      if (isPendulumRunning) {
        pendulumTimeRef.current += dt;
      }

      const canvas = pendulumCanvasRef.current;
      if (canvas) {
        const ctx = canvas.getContext('2d');
        if (ctx) {
          const width = canvas.width;
          const height = canvas.height;
          ctx.clearRect(0, 0, width, height);

          const originX = width / 2;
          const originY = 35;
          const pixelLength = Math.min(height - 80, pendulumLength * 170);

          // Current angle using harmonic motion equation: theta(t) = theta0 * cos(omega * t)
          const omega = Math.sqrt(pendulumGravity / Math.max(0.1, pendulumLength));
          const angleRad = (initialAngleDeg * Math.PI / 180) * Math.cos(omega * pendulumTimeRef.current);

          const bobX = originX + pixelLength * Math.sin(angleRad);
          const bobY = originY + pixelLength * Math.cos(angleRad);

          // Draw Support pivot
          ctx.beginPath();
          ctx.fillStyle = '#64748b';
          ctx.rect(originX - 40, originY - 10, 80, 10);
          ctx.fill();

          // Draw Pivot point
          ctx.beginPath();
          ctx.arc(originX, originY, 5, 0, 2 * Math.PI);
          ctx.fillStyle = '#0f766e';
          ctx.fill();

          // Draw dashed vertical reference line
          ctx.beginPath();
          ctx.setLineDash([4, 4]);
          ctx.strokeStyle = '#94a3b8';
          ctx.moveTo(originX, originY);
          ctx.lineTo(originX, originY + pixelLength + 20);
          ctx.stroke();
          ctx.setLineDash([]);

          // Draw String
          ctx.beginPath();
          ctx.lineWidth = 2.5;
          ctx.strokeStyle = '#0f766e';
          ctx.moveTo(originX, originY);
          ctx.lineTo(bobX, bobY);
          ctx.stroke();

          // Draw Bob Mass
          const bobRadius = 14 + pendulumMass * 8;
          const grad = ctx.createRadialGradient(bobX - 4, bobY - 4, 2, bobX, bobY, bobRadius);
          grad.addColorStop(0, '#2dd4bf');
          grad.addColorStop(1, '#0f766e');

          ctx.beginPath();
          ctx.arc(bobX, bobY, bobRadius, 0, 2 * Math.PI);
          ctx.fillStyle = grad;
          ctx.shadowColor = 'rgba(15, 118, 110, 0.4)';
          ctx.shadowBlur = 10;
          ctx.fill();
          ctx.shadowBlur = 0;

          // Draw Mass Text on bob
          ctx.fillStyle = '#ffffff';
          ctx.font = 'bold 10px Tajawal, system-ui';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(`${pendulumMass}kg`, bobX, bobY);
        }
      }

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  }, [isPendulumRunning, pendulumLength, pendulumGravity, pendulumMass, initialAngleDeg]);

  // -------------------------------------------------------------
  // 2. PHYSICS LAB: Projectile Motion Experiment
  // -------------------------------------------------------------
  const [projSpeed, setProjSpeed] = useState<number>(25); // m/s
  const [projAngle, setProjAngle] = useState<number>(45); // deg
  const projGravity = 9.8;

  const projMaxHeight = useMemo(() => {
    const angleRad = (projAngle * Math.PI) / 180;
    return (Math.pow(projSpeed * Math.sin(angleRad), 2)) / (2 * projGravity);
  }, [projSpeed, projAngle]);

  const projFlightTime = useMemo(() => {
    const angleRad = (projAngle * Math.PI) / 180;
    return (2 * projSpeed * Math.sin(angleRad)) / projGravity;
  }, [projSpeed, projAngle]);

  const projRange = useMemo(() => {
    const angleRad = (projAngle * Math.PI) / 180;
    return (Math.pow(projSpeed, 2) * Math.sin(2 * angleRad)) / projGravity;
  }, [projSpeed, projAngle]);

  // -------------------------------------------------------------
  // 3. CHEMISTRY LAB: Acid-Base Titration & pH Simulator
  // -------------------------------------------------------------
  const [acidVolume, setAcidVolume] = useState<number>(25); // mL
  const [acidMolarity, setAcidMolarity] = useState<number>(0.1); // M (HCl)
  const [baseMolarity, setBaseMolarity] = useState<number>(0.1); // M (NaOH)
  const [addedBaseVolume, setAddedBaseVolume] = useState<number>(0); // mL added from burette
  const [indicator, setIndicator] = useState<'phenolphthalein' | 'bromothymol'>('phenolphthalein');

  // Titration pH calculation
  const currentPh = useMemo(() => {
    const molesAcid = (acidVolume / 1000) * acidMolarity;
    const molesBase = (addedBaseVolume / 1000) * baseMolarity;
    const totalVolume = (acidVolume + addedBaseVolume) / 1000;

    if (molesAcid > molesBase) {
      // Acidic solution
      const excessMolesH = molesAcid - molesBase;
      const concentrationH = excessMolesH / totalVolume;
      const ph = -Math.log10(Math.max(1e-14, concentrationH));
      return Math.min(14, Math.max(0, Number(ph.toFixed(2))));
    } else if (molesBase > molesAcid) {
      // Basic solution
      const excessMolesOH = molesBase - molesAcid;
      const concentrationOH = excessMolesOH / totalVolume;
      const pOH = -Math.log10(Math.max(1e-14, concentrationOH));
      const ph = 14 - pOH;
      return Math.min(14, Math.max(0, Number(ph.toFixed(2))));
    } else {
      // Equivalence point
      return 7.00;
    }
  }, [acidVolume, acidMolarity, baseMolarity, addedBaseVolume]);

  const equivalenceVolume = useMemo(() => {
    return (acidVolume * acidMolarity) / baseMolarity;
  }, [acidVolume, acidMolarity, baseMolarity]);

  // Color of solution based on pH and Indicator
  const solutionColor = useMemo(() => {
    if (indicator === 'phenolphthalein') {
      if (currentPh < 8.2) return 'rgba(230, 245, 245, 0.4)'; // Colorless
      if (currentPh < 10) return 'rgba(244, 114, 182, 0.55)'; // Light Pink
      return 'rgba(219, 39, 119, 0.85)'; // Intense Magenta/Pink
    } else {
      // Bromothymol blue
      if (currentPh < 6.0) return 'rgba(234, 179, 8, 0.7)'; // Yellow (acid)
      if (currentPh < 7.6) return 'rgba(34, 197, 94, 0.7)'; // Green (neutral)
      return 'rgba(59, 130, 246, 0.8)'; // Blue (base)
    }
  }, [currentPh, indicator]);

  // Periodic Table Active Selected Element
  const [selectedElement, setSelectedElement] = useState<ChemicalElement>(PERIODIC_ELEMENTS[5]); // Default: Carbon
  const [periodicSearch, setPeriodicSearch] = useState<string>('');

  const filteredElements = useMemo(() => {
    if (!periodicSearch.trim()) return PERIODIC_ELEMENTS;
    const q = periodicSearch.trim().toLowerCase();
    return PERIODIC_ELEMENTS.filter(
      (el) =>
        el.symbol.toLowerCase().includes(q) ||
        el.nameAr.toLowerCase().includes(q) ||
        el.nameEn.toLowerCase().includes(q) ||
        String(el.number).includes(q)
    );
  }, [periodicSearch]);

  // -------------------------------------------------------------
  // 4. BIOLOGY LAB: Punnett Square Genetics Simulator
  // -------------------------------------------------------------
  const [parent1Alleles, setParent1Alleles] = useState<string>('Bb'); // e.g., Eye Color: B (Brown, dominant), b (Blue, recessive)
  const [parent2Alleles, setParent2Alleles] = useState<string>('Bb');
  const [traitName, setTraitName] = useState<string>('لون العيون (البني B سائد / الأزرق b متنحي)');

  const punnettResults = useMemo(() => {
    const p1 = parent1Alleles.split('');
    const p2 = parent2Alleles.split('');
    if (p1.length < 2 || p2.length < 2) return null;

    const cells = [
      [p1[0] + p2[0], p1[1] + p2[0]],
      [p1[0] + p2[1], p1[1] + p2[1]]
    ].map(row => row.map(gen => gen.split('').sort().join('')));

    const flat = cells.flat();
    const counts: { [key: string]: number } = {};
    flat.forEach(g => counts[g] = (counts[g] || 0) + 1);

    // Dominant vs recessive count
    let dominantCount = 0;
    let recessiveCount = 0;
    flat.forEach(g => {
      if (g.includes('B')) dominantCount++;
      else recessiveCount++;
    });

    return {
      cells,
      counts,
      dominantPercent: (dominantCount / 4) * 100,
      recessivePercent: (recessiveCount / 4) * 100
    };
  }, [parent1Alleles, parent2Alleles]);

  // -------------------------------------------------------------
  // 5. SCIENTIFIC RESEARCH HUB & HYPOTHESIS BUILDER
  // -------------------------------------------------------------
  const [researchTitle, setResearchTitle] = useState('أثر طول الخيط والجاذبية على الزمن الدوري للبندول البسيط');
  const [researchHypothesis, setResearchHypothesis] = useState('يتناسب مربع الزمن الدوري للبندول طردياً مع طول الخيط وعكسياً مع تسارع الجاذبية الأرضية T² ∝ L / g.');
  const [independentVar, setIndependentVar] = useState('طول الخيط L (أمتار)');
  const [dependentVar, setDependentVar] = useState('الزمن الدوري T (ثوانٍ)');
  const [controlledVars, setControlledVars] = useState('كتلة الثقل m، وزاوية الإطلاق الابتدائية الصغيرة θ < 15°');
  const [researchConclusion, setResearchConclusion] = useState('أكدت القياسات العملية دقة النموذج النظري، حيث لم تؤثر كتلة الثقل على الزمن الدوري وتطابقت النتائج بنسبة دقة بلغت 98.4%.');

  // Trigger Academic Print Report for this Experiment
  const handlePrintExperimentReport = () => {
    const markdownContent = `
## 💡 المفاهيم الأساسية (Main Concepts)
- الفرضية العلمية: ${researchHypothesis}
- المتغير المستقل: ${independentVar}
- المتغير التابع: ${dependentVar}
- الضوابط التجريبية: ${controlledVars}

## 📌 الخلاصات والنقاط الجوهرية (Key Takeaways)
- ${researchConclusion}
- تم التحقق من صحة القوانين الفيزيائية الرياضية بدقة عالية ومطابقة النموذج النظري مع الملاحظات التجريبية.

## 📐 المنهجية والتطبيقات الإجرائية (Methodology)
- ضبط المتغير المستقل وتسجيل القياسات في معمل D.CORE Schooler AI.
- قياس المتغير التابع وتكرار التجربة 5 مرات لتقليل نسبة الخطأ العشوائي.
- قانون التجربة الحاكم: T = 2\\pi \\sqrt{\\frac{L}{g}}

## ⚖️ التحليل الأكاديمي والقوانين (Detailed Analysis)
- مقارنة القيم النظرية بالعملية.
- حساب نسبة الخطأ التجريبي المئوية.

## ⚠️ تنبيهات المذاكرة والاختبارات (Exam Tips)
- المحافظة على ثبات المتغيرات الضابطة لضمان صدق التجربة.
- زاوية الإطلاق الصغيرة شرط أساسي لتحقق الحركة التوافقية البسيطة.
`;

    const summary = extractStructuredSummary(
      markdownContent,
      currentNotebook.name,
      'الفيزياء والعلوم التجريبية'
    );
    summary.documentTitle = `تقرير بحثي معملي: ${researchTitle}`;

    setPrintModalSummary(summary);
    setIsPrintModalOpen(true);
  };

  const handleAskAiAboutLab = () => {
    if (!onAskAiAboutExperiment) return;
    let context = '';
    if (activeLabDomain === '3d_lab') {
      const tool = activeInspected3DTool || LAB_3D_TOOLS[0];
      context = `أنا أعمل في المختبر العلمي ثلاثي الأبعاد 3D وأتفحص أداة «${tool.nameAr}» (${tool.nameEn}).
القانون العلمي: ${tool.scientificLaw || 'مبادئ التحليل المخبري'}
الصيغة الكيميائية: ${tool.chemicalFormula || 'غير محدد'}
الوصف: ${tool.descriptionAr}
اشرح لي كيف تعمل هذه الأداة في التجارب المعملية الحديثة وما هي المفاهيم الفيزيائية/الكيميائية التي يمكن إثباتها بها بالتفصيل؟`;
    } else if (activeLabDomain === 'physics') {
      context = `أجريت تجربة في معمل الفيزياء حول البندول البسيط: طول الخيط L = ${pendulumLength}m، والجاذبية g = ${pendulumGravity}m/s²، وزاوية الإطلاق = ${initialAngleDeg}°، وكان الزمن الدوري النظري المحسوب = ${theoreticalPeriod.toFixed(3)} ثانية. هل يمكنك تحليل هذه التجربة وشرح كيفية استنتاج تسارع الجاذبية عملياً من الرسم البياني T² مقابل L؟`;
    } else if (activeLabDomain === 'chemistry') {
      context = `أجريت تجربة معايرة حمض وقاعدة في معمل الكيمياء: حمض HCl حجمه ${acidVolume}mL وتركيزه ${acidMolarity}M مع قاعدة NaOH بتركيز ${baseMolarity}M. حجم القاعدة عند نقطة التكافؤ المحسوب هو ${equivalenceVolume.toFixed(1)}mL والـ pH الحالي هو ${currentPh}. اشرح لي سلوك منحنى المعايرة وتغير لون كاشف ${indicator === 'phenolphthalein' ? 'الفينولفثالين' : 'أزرق البروموثيمول'}.`;
    } else if (activeLabDomain === 'biology') {
      context = `أجريت محاكاة لمربع بانيت الوراثي في معمل الأحياء: تزاوج بين الأبوين (${parent1Alleles} × ${parent2Alleles}) لصفة ${traitName}. نسبة النمط السائد المتوقعة هي ${punnettResults?.dominantPercent}% والمتنحي ${punnettResults?.recessivePercent}%. اشرح لي كيف تنطبق قوانين مندل للانعزال والتوزيع الحر على هذه النتيجة.`;
    } else {
      context = `أعمل على تصميم بحث علمي بعنوان: «${researchTitle}» بفرضية: «${researchHypothesis}». كيف أطور هذا البحث وأحدد مصادر الخطأ التجريبي وفق أحدث المراجع الأكاديمية؟`;
    }
    onAskAiAboutExperiment(context);
  };

  const handleSaveToNotes = () => {
    if (!onSaveExperimentAsNote) return;
    const title = `تجربة معملية: ${activeLabDomain === 'physics' ? 'البندول البسيط والتسارع' : activeLabDomain === 'chemistry' ? 'معايرة الأحماض والـ pH' : activeLabDomain === 'biology' ? 'مربع بانيت الوراثي' : researchTitle}`;
    const content = `### نتائج التجربة المعملية التفاعلية\n**الدفتر:** ${currentNotebook.name}\n**المجال:** ${activeLabDomain}\n\n**البيانات المسجلة:**\n- الزمن الدوري النظري: ${theoreticalPeriod.toFixed(3)} s\n- طول الخيط: ${pendulumLength} m\n- الجاذبية: ${pendulumGravity} m/s²\n- الاستنتاج: ${researchConclusion}\n\n*تم إجراء التجربة في معمل D.CORE Schooler AI التفاعلي.*`;
    onSaveExperimentAsNote(title, content);
  };

  return (
    <div className="space-y-4 max-w-7xl mx-auto pb-16 animate-in fade-in duration-200" dir="rtl">
      {/* Top Banner Header */}
      <div className="bg-gradient-to-l from-teal-800 via-teal-700 to-emerald-800 rounded-3xl p-5 sm:p-7 text-white shadow-lg relative overflow-hidden">
        <div className="absolute top-0 left-0 w-80 h-80 bg-white/10 rounded-full blur-3xl -translate-x-20 -translate-y-20 pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1.5 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/15 backdrop-blur-md text-teal-100 text-xs font-bold border border-white/20">
              <FlaskConical className="w-3.5 h-3.5 text-teal-300" />
              <span>المختبر العلمي التفاعلي ومركز البحوث</span>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
            </div>
            <h1 className="text-xl sm:text-2xl lg:text-3xl font-black tracking-tight text-white">
              معمل الفيزياء، الكيمياء، والأحياء التفاعلي
            </h1>
            <p className="text-xs sm:text-sm text-teal-100/90 leading-relaxed">
              محاكاة فيزيائية حقيقية، جدول دوري تفاعلي، معايرة الأحماض والـ pH، وراثة مندل، وأدوات تصميم الفرضيات والبحوث العلمية باللغة العربية.
            </p>
          </div>

          {/* Quick Actions */}
          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={handleAskAiAboutLab}
              className="px-3.5 py-2 rounded-xl bg-white/20 hover:bg-white/30 text-white text-xs font-bold border border-white/30 backdrop-blur-md flex items-center gap-1.5 transition-all cursor-pointer shadow-xs"
              title="مناقشة هذه التجربة مع الذكاء الاصطناعي الأكاديمي"
            >
              <MessageSquare className="w-4 h-4 text-teal-200" />
              <span>مناقشة بالذكاء الاصطناعي</span>
            </button>
            <button
              type="button"
              onClick={handleSaveToNotes}
              className="px-3.5 py-2 rounded-xl bg-white/20 hover:bg-white/30 text-white text-xs font-bold border border-white/30 backdrop-blur-md flex items-center gap-1.5 transition-all cursor-pointer shadow-xs"
              title="حفظ نتائج التجربة كملاحظة دراسية في الدفتر"
            >
              <FileText className="w-4 h-4 text-emerald-200" />
              <span>حفظ في الملاحظات</span>
            </button>
            <button
              type="button"
              onClick={handlePrintExperimentReport}
              className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold shadow-md flex items-center gap-1.5 transition-all cursor-pointer"
              title="تصدير تقرير معملي أكاديمي فاخر جاهز للطباعة"
            >
              <Printer className="w-4 h-4" />
              <span>تقرير معملي للطباعة</span>
            </button>
          </div>
        </div>

        {/* Lab Navigation Switcher */}
        <div className="mt-5 pt-4 border-t border-white/20 flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setActiveLabDomain('3d_lab')}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
              activeLabDomain === '3d_lab'
                ? 'bg-white text-teal-900 shadow-md font-black ring-2 ring-emerald-300'
                : 'bg-white/15 text-white hover:bg-white/25 border border-white/20'
            }`}
          >
            <Box className="w-4 h-4 text-emerald-300 animate-pulse" />
            <span>المختبر الواقعي 3D</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveLabDomain('ai_copilot')}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
              activeLabDomain === 'ai_copilot'
                ? 'bg-white text-teal-900 shadow-md font-black ring-2 ring-emerald-300'
                : 'bg-white/15 text-white hover:bg-white/25 border border-white/20'
            }`}
          >
            <Sparkles className="w-4 h-4 text-emerald-300 animate-spin" />
            <span>المساعد المعملي الذكي والمحاكي</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveLabDomain('physics')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
              activeLabDomain === 'physics'
                ? 'bg-white text-teal-900 shadow-md font-black'
                : 'bg-white/10 text-white hover:bg-white/20'
            }`}
          >
            <Atom className="w-4 h-4 text-cyan-400" />
            <span>معمل الفيزياء (البندول والمقذوفات)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveLabDomain('chemistry')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
              activeLabDomain === 'chemistry'
                ? 'bg-white text-teal-900 shadow-md font-black'
                : 'bg-white/10 text-white hover:bg-white/20'
            }`}
          >
            <FlaskConical className="w-4 h-4 text-emerald-400" />
            <span>معمل الكيمياء (الجدول والمعايرة)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveLabDomain('biology')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
              activeLabDomain === 'biology'
                ? 'bg-white text-teal-900 shadow-md font-black'
                : 'bg-white/10 text-white hover:bg-white/20'
            }`}
          >
            <Dna className="w-4 h-4 text-pink-400" />
            <span>معمل الأحياء (الوراثة)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveLabDomain('research')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
              activeLabDomain === 'research'
                ? 'bg-white text-teal-900 shadow-md font-black'
                : 'bg-white/10 text-white hover:bg-white/20'
            }`}
          >
            <Microscope className="w-4 h-4 text-amber-400" />
            <span>مركز البحوث والفرضيات</span>
          </button>
        </div>
      </div>

      {/* ========================================================= */}
      {/* 0. AI LAB COPILOT & INTERACTIVE REAL-TIME SIMULATOR       */}
      {/* ========================================================= */}
      {activeLabDomain === 'ai_copilot' && (
        <div className="space-y-4 animate-in fade-in duration-200">
          <AiLabAssistant
            activeDomain={activeLabDomain}
            onSaveExperimentAsNote={onSaveExperimentAsNote}
          />
        </div>
      )}

      {/* ========================================================= */}
      {/* 1. INTERACTIVE 3D LAB WORKBENCH SECTION                   */}
      {/* ========================================================= */}
      {activeLabDomain === '3d_lab' && (
        <div className="space-y-4 animate-in fade-in duration-200">
          {/* Main 3D WebGL Canvas */}
          <InteractiveLab3DCanvas
            onInspectTool={(tool) => setActiveInspected3DTool(tool)}
            onAskAiAboutTool={(ctx) => {
              if (onAskAiAboutExperiment) onAskAiAboutExperiment(ctx);
            }}
          />

          {/* Smart Floating Educational & Experimental Context Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
            {/* Quick Card 1: Interactive Chemistry & Flame */}
            <div className="p-4 rounded-2xl bg-white dark:bg-[#121c19] border border-slate-200/90 dark:border-[#1e342b] shadow-xs flex items-start gap-3">
              <div className="w-9 h-9 rounded-xl bg-cyan-50 dark:bg-cyan-950/60 text-cyan-600 dark:text-cyan-400 flex items-center justify-center shrink-0">
                <FlaskConical className="w-5 h-5" />
              </div>
              <div className="space-y-1">
                <h5 className="text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-100">
                  تفاعلات المحاليل والمعايرة
                </h5>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  انقر على الدورق الزجاجي في المساحة ثلاثية الأبعاد لتغيير المحلول واستكشاف دلالات الألوان الكيميائية ومؤشرات الـ pH.
                </p>
              </div>
            </div>

            {/* Quick Card 2: Physics & Mechanical Oscillation */}
            <div className="p-4 rounded-2xl bg-white dark:bg-[#121c19] border border-slate-200/90 dark:border-[#1e342b] shadow-xs flex items-start gap-3">
              <div className="w-9 h-9 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
                <Atom className="w-5 h-5" />
              </div>
              <div className="space-y-1">
                <h5 className="text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-100">
                  البندول وقوانين الحركة التوافقية
                </h5>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  تحكم ببدء وإيقاف الاهتزاز ثلاثي الأبعاد مباشرة من اللوحة العائمة لمشاهدة تحولات الطاقة الحركية وطاقة الوضع.
                </p>
              </div>
            </div>

            {/* Quick Card 3: Molecular Biology & DNA */}
            <div className="p-4 rounded-2xl bg-white dark:bg-[#121c19] border border-slate-200/90 dark:border-[#1e342b] shadow-xs flex items-start gap-3">
              <div className="w-9 h-9 rounded-xl bg-pink-50 dark:bg-pink-950/60 text-pink-600 dark:text-pink-400 flex items-center justify-center shrink-0">
                <Dna className="w-5 h-5" />
              </div>
              <div className="space-y-1">
                <h5 className="text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-100">
                  التركيب الجزيئي للحمض النووي
                </h5>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  دوران حي لولبي مزدوج للـ DNA مع القواعد النيتروجينية الأربع وروابط الهيدروجين وفق نموذج واطسون وكريك.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* 1. PHYSICS LAB SECTION                                    */}
      {/* ========================================================= */}
      {activeLabDomain === 'physics' && (
        <div className="space-y-5 animate-in fade-in duration-200">
          {/* Main Simulation Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
            {/* Left/Main: Visual Pendulum Simulation Canvas */}
            <div className="lg:col-span-7 bg-white dark:bg-[#121c19] rounded-2xl border border-slate-200/90 dark:border-[#1e342b] p-4 sm:p-5 flex flex-col justify-between shadow-xs">
              <div className="flex items-center justify-between pb-3 mb-2 border-b border-slate-100 dark:border-[#1e342b]">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-teal-50 dark:bg-teal-950/50 text-teal-700 dark:text-teal-300 flex items-center justify-center font-bold">
                    <Atom className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100">
                      محاكاة البندول البسيط والحركة التوافقية
                    </h3>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400">
                      تطبيق عملي لقانون نيوتن والجاذبية في الحركة الاهتزازية
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => setIsPendulumRunning(!isPendulumRunning)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1 transition-all cursor-pointer ${
                      isPendulumRunning
                        ? 'bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300'
                        : 'bg-teal-600 text-white shadow-xs'
                    }`}
                  >
                    {isPendulumRunning ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                    <span>{isPendulumRunning ? 'إيقاف مؤقت' : 'تشغيل'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      pendulumTimeRef.current = 0;
                    }}
                    className="p-1.5 rounded-xl text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                    title="إعادة التصفير"
                  >
                    <RotateCcw className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Canvas viewport */}
              <div className="relative w-full h-[280px] sm:h-[320px] bg-slate-50 dark:bg-[#0c1512] rounded-xl border border-slate-200/80 dark:border-[#1a2e26] overflow-hidden flex items-center justify-center">
                <canvas
                  ref={pendulumCanvasRef}
                  width={480}
                  height={320}
                  className="max-w-full max-h-full block"
                />

                {/* Floating Real-time HUD */}
                <div className="absolute top-2 right-2 p-2 rounded-xl bg-white/90 dark:bg-[#121c19]/90 border border-slate-200 dark:border-[#22352f] text-[11px] space-y-0.5 backdrop-blur-sm shadow-xs font-mono">
                  <div className="text-teal-700 dark:text-teal-300 font-bold">
                    الزمن الدوري T: {theoreticalPeriod.toFixed(3)} s
                  </div>
                  <div className="text-slate-600 dark:text-slate-300">
                    التردد f: {theoreticalFrequency.toFixed(3)} Hz
                  </div>
                  <div className="text-slate-500 dark:text-slate-400">
                    الجاذبية g: {pendulumGravity} m/s²
                  </div>
                </div>
              </div>

              {/* Formula & Scientific Law card */}
              <div className="mt-3 p-3 rounded-xl bg-teal-50/60 dark:bg-teal-950/30 border border-teal-500/20 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-teal-800 dark:text-teal-200">
                    القانون الفيزيائي الحاكم:
                  </span>
                  <span className="font-mono text-teal-700 dark:text-teal-300 dir-ltr text-xs">
                    T = 2\pi \sqrt{'{'}L / g{'}'}
                  </span>
                </div>
                <p className="text-[11px] text-slate-600 dark:text-slate-400 mt-1">
                  ملاحظة هامة: لا يعتمد الزمن الدوري على كتلة الثقل في التقريب التوافقي البسيط، ولكنه يتناسب طردياً مع الجذر التربيعي لطول الخيط L.
                </p>
              </div>
            </div>

            {/* Right: Controls & Parameters Panel */}
            <div className="lg:col-span-5 bg-white dark:bg-[#121c19] rounded-2xl border border-slate-200/90 dark:border-[#1e342b] p-4 sm:p-5 flex flex-col justify-between shadow-xs space-y-4">
              <div className="flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-[#1e342b]">
                <Sliders className="w-4 h-4 text-teal-600 dark:text-teal-400" />
                <h4 className="text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-100">
                  المتغيرات التجريبية والتحكم
                </h4>
              </div>

              {/* Slider 1: Length */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs font-bold">
                  <span className="text-slate-700 dark:text-slate-300">طول الخيط (L):</span>
                  <span className="text-teal-700 dark:text-teal-400 font-mono">{pendulumLength.toFixed(2)} متر</span>
                </div>
                <input
                  type="range"
                  min="0.2"
                  max="2.0"
                  step="0.05"
                  value={pendulumLength}
                  onChange={(e) => setPendulumLength(parseFloat(e.target.value))}
                  className="w-full accent-teal-600 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-400">
                  <span>0.2 m</span>
                  <span>1.0 m</span>
                  <span>2.0 m</span>
                </div>
              </div>

              {/* Slider 2: Mass */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs font-bold">
                  <span className="text-slate-700 dark:text-slate-300">كتلة الثقل (m):</span>
                  <span className="text-teal-700 dark:text-teal-400 font-mono">{pendulumMass.toFixed(2)} كجم</span>
                </div>
                <input
                  type="range"
                  min="0.1"
                  max="2.0"
                  step="0.1"
                  value={pendulumMass}
                  onChange={(e) => setPendulumMass(parseFloat(e.target.value))}
                  className="w-full accent-teal-600 cursor-pointer"
                />
              </div>

              {/* Slider 3: Initial Angle */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs font-bold">
                  <span className="text-slate-700 dark:text-slate-300">زاوية الإطلاق (θ₀):</span>
                  <span className="text-teal-700 dark:text-teal-400 font-mono">{initialAngleDeg}° درجات</span>
                </div>
                <input
                  type="range"
                  min="5"
                  max="45"
                  step="1"
                  value={initialAngleDeg}
                  onChange={(e) => setInitialAngleDeg(parseInt(e.target.value, 10))}
                  className="w-full accent-teal-600 cursor-pointer"
                />
              </div>

              {/* Planet / Gravity selector buttons */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
                  بيئة الجاذبية (تسارع السقوط الحر g):
                </label>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <button
                    type="button"
                    onClick={() => setPendulumGravity(9.8)}
                    className={`p-2 rounded-xl border text-right transition-all cursor-pointer ${
                      pendulumGravity === 9.8
                        ? 'border-teal-500 bg-teal-50 dark:bg-teal-950/40 text-teal-800 dark:text-teal-200 font-bold'
                        : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    <div>🌍 كوكب الأرض</div>
                    <div className="text-[10px] text-slate-500 font-mono">g = 9.80 m/s²</div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPendulumGravity(1.62)}
                    className={`p-2 rounded-xl border text-right transition-all cursor-pointer ${
                      pendulumGravity === 1.62
                        ? 'border-teal-500 bg-teal-50 dark:bg-teal-950/40 text-teal-800 dark:text-teal-200 font-bold'
                        : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    <div>🌕 سطح القمر</div>
                    <div className="text-[10px] text-slate-500 font-mono">g = 1.62 m/s²</div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPendulumGravity(3.71)}
                    className={`p-2 rounded-xl border text-right transition-all cursor-pointer ${
                      pendulumGravity === 3.71
                        ? 'border-teal-500 bg-teal-50 dark:bg-teal-950/40 text-teal-800 dark:text-teal-200 font-bold'
                        : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    <div>🔴 كوكب المريخ</div>
                    <div className="text-[10px] text-slate-500 font-mono">g = 3.71 m/s²</div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPendulumGravity(24.79)}
                    className={`p-2 rounded-xl border text-right transition-all cursor-pointer ${
                      pendulumGravity === 24.79
                        ? 'border-teal-500 bg-teal-50 dark:bg-teal-950/40 text-teal-800 dark:text-teal-200 font-bold'
                        : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    <div>🪐 المشتري العملاق</div>
                    <div className="text-[10px] text-slate-500 font-mono">g = 24.79 m/s²</div>
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Secondary Physics: Projectile Motion Calculator */}
          <div className="bg-white dark:bg-[#121c19] rounded-2xl border border-slate-200/90 dark:border-[#1e342b] p-4 sm:p-5 shadow-xs">
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-100 dark:border-[#1e342b]">
              <div className="flex items-center gap-2">
                <Compass className="w-5 h-5 text-teal-600 dark:text-teal-400" />
                <h4 className="text-sm font-bold text-slate-800 dark:text-slate-100">
                  تجربة حركة المقذوفات وزاوية الإطلاق (Projectile Motion)
                </h4>
              </div>
              <span className="text-[11px] font-bold text-teal-700 dark:text-teal-300 bg-teal-50 dark:bg-teal-950/50 px-2.5 py-1 rounded-full">
                حساب المسار المنحني
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
                  السرعة الابتدائية (v₀): <span className="text-teal-600 font-mono">{projSpeed} m/s</span>
                </label>
                <input
                  type="range"
                  min="5"
                  max="60"
                  value={projSpeed}
                  onChange={(e) => setProjSpeed(parseInt(e.target.value, 10))}
                  className="w-full accent-teal-600 cursor-pointer"
                />
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
                  زاوية الإطلاق (θ): <span className="text-teal-600 font-mono">{projAngle}°</span>
                </label>
                <input
                  type="range"
                  min="10"
                  max="85"
                  value={projAngle}
                  onChange={(e) => setProjAngle(parseInt(e.target.value, 10))}
                  className="w-full accent-teal-600 cursor-pointer"
                />
              </div>

              <div className="bg-slate-50 dark:bg-[#162520] p-3 rounded-xl border border-slate-200 dark:border-[#223930] grid grid-cols-3 gap-2 text-center text-xs">
                <div>
                  <div className="text-[10px] text-slate-500">أقصى ارتفاع H</div>
                  <div className="font-mono font-bold text-teal-700 dark:text-teal-300 text-sm mt-0.5">
                    {projMaxHeight.toFixed(1)} m
                  </div>
                </div>
                <div>
                  <div className="text-[10px] text-slate-500">المدى الأفقي R</div>
                  <div className="font-mono font-bold text-emerald-700 dark:text-emerald-300 text-sm mt-0.5">
                    {projRange.toFixed(1)} m
                  </div>
                </div>
                <div>
                  <div className="text-[10px] text-slate-500">زمن التحليق t</div>
                  <div className="font-mono font-bold text-cyan-700 dark:text-cyan-300 text-sm mt-0.5">
                    {projFlightTime.toFixed(2)} s
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* 2. CHEMISTRY LAB SECTION                                  */}
      {/* ========================================================= */}
      {activeLabDomain === 'chemistry' && (
        <div className="space-y-5 animate-in fade-in duration-200">
          {/* Titration Simulator Card */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
            {/* Visual Burette & Flask */}
            <div className="lg:col-span-6 bg-white dark:bg-[#121c19] rounded-2xl border border-slate-200/90 dark:border-[#1e342b] p-4 sm:p-5 flex flex-col justify-between shadow-xs">
              <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-100 dark:border-[#1e342b]">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300 flex items-center justify-center font-bold">
                    <FlaskConical className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100">
                      محاكاة معايرة الأحماض والقواعد (HCl + NaOH)
                    </h3>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400">
                      تتبع تغير اللون بدقة ومقياس الرقم الهيدروجيني pH
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setAddedBaseVolume(0)}
                  className="text-xs text-slate-500 hover:text-emerald-600 flex items-center gap-1 font-bold cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>تفريغ السحاحة</span>
                </button>
              </div>

              {/* Visual Apparatus Flask with Liquid */}
              <div className="relative h-64 bg-slate-50 dark:bg-[#0d1613] rounded-xl border border-slate-200 dark:border-[#1c3027] flex flex-col items-center justify-end p-4 overflow-hidden">
                {/* Burette top visual representation */}
                <div className="absolute top-2 w-7 h-28 border-2 border-slate-400 bg-white/40 dark:bg-black/30 rounded-t-sm flex flex-col items-center justify-end">
                  <div
                    className="w-full bg-cyan-400/40 transition-all duration-150"
                    style={{ height: `${Math.max(0, 100 - (addedBaseVolume / 50) * 100)}%` }}
                  />
                  <div className="w-1.5 h-4 bg-slate-500 rounded-b-xs" />
                </div>

                {/* Droplets when base is added */}
                {addedBaseVolume > 0 && (
                  <div className="absolute top-32 w-2 h-2 rounded-full bg-cyan-500 animate-ping" />
                )}

                {/* Erlenmeyer Flask Body */}
                <div className="relative w-36 h-36 border-4 border-slate-400/80 rounded-b-3xl rounded-t-lg bg-white/20 dark:bg-black/20 flex flex-col justify-end overflow-hidden shadow-md">
                  {/* Liquid fill */}
                  <div
                    className="w-full transition-colors duration-300 rounded-b-2xl relative"
                    style={{
                      height: `${Math.min(95, 30 + (addedBaseVolume / 50) * 50)}%`,
                      backgroundColor: solutionColor,
                    }}
                  >
                    <div className="absolute inset-0 bg-gradient-to-t from-black/10 to-transparent" />
                  </div>
                </div>

                {/* Digital pH Meter Display */}
                <div className="absolute bottom-3 right-3 bg-white/95 dark:bg-[#121c19]/95 p-2.5 rounded-xl border border-slate-200 dark:border-[#22352f] shadow-md text-right">
                  <div className="text-[10px] text-slate-500 font-bold">مقياس الـ pH الرقمي</div>
                  <div className={`text-xl font-black font-mono mt-0.5 ${
                    currentPh < 6 ? 'text-amber-600' : currentPh > 8 ? 'text-pink-600' : 'text-emerald-600'
                  }`}>
                    pH {currentPh.toFixed(2)}
                  </div>
                  <div className="text-[10px] text-slate-400 mt-0.5">
                    {currentPh < 6.8 ? 'وسط حمضي' : currentPh > 7.2 ? 'وسط قاعدي' : 'نقطة التعادل'}
                  </div>
                </div>
              </div>

              {/* Indicator Selector */}
              <div className="mt-3 flex items-center justify-between gap-2 text-xs">
                <span className="font-bold text-slate-700 dark:text-slate-300">الكاشف الكيميائي:</span>
                <div className="flex gap-1.5">
                  <button
                    type="button"
                    onClick={() => setIndicator('phenolphthalein')}
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                      indicator === 'phenolphthalein'
                        ? 'bg-pink-600 text-white shadow-xs'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    فينولفثالين (عديم اللون ← وردي)
                  </button>
                  <button
                    type="button"
                    onClick={() => setIndicator('bromothymol')}
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                      indicator === 'bromothymol'
                        ? 'bg-blue-600 text-white shadow-xs'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    أزرق البروموثيمول
                  </button>
                </div>
              </div>
            </div>

            {/* Titration Controls & Curve Details */}
            <div className="lg:col-span-6 bg-white dark:bg-[#121c19] rounded-2xl border border-slate-200/90 dark:border-[#1e342b] p-4 sm:p-5 flex flex-col justify-between shadow-xs space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-[#1e342b]">
                <h4 className="text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-100">
                  لوحة التحكم في السحاحة وإضافة القاعدة
                </h4>
                <span className="text-[11px] font-mono font-bold text-emerald-700 dark:text-emerald-300">
                  نقطة التكافؤ: {equivalenceVolume.toFixed(1)} mL
                </span>
              </div>

              {/* Volume Slider */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs font-bold">
                  <span className="text-slate-700 dark:text-slate-300">حجم هيدروكسيد الصوديوم المضاف (V_NaOH):</span>
                  <span className="text-emerald-600 font-mono font-bold">{addedBaseVolume.toFixed(1)} مل</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="50"
                  step="0.5"
                  value={addedBaseVolume}
                  onChange={(e) => setAddedBaseVolume(parseFloat(e.target.value))}
                  className="w-full accent-emerald-600 cursor-pointer"
                />
              </div>

              {/* Incremental Add Buttons */}
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-500 font-bold">إضافة سريعة:</span>
                <button
                  type="button"
                  onClick={() => setAddedBaseVolume((prev) => Math.min(50, prev + 1))}
                  className="px-2.5 py-1 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 text-xs font-bold hover:bg-emerald-100"
                >
                  +1.0 mL
                </button>
                <button
                  type="button"
                  onClick={() => setAddedBaseVolume((prev) => Math.min(50, prev + 5))}
                  className="px-2.5 py-1 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 text-xs font-bold hover:bg-emerald-100"
                >
                  +5.0 mL
                </button>
                <button
                  type="button"
                  onClick={() => setAddedBaseVolume(equivalenceVolume)}
                  className="px-2.5 py-1 rounded-lg bg-cyan-600 text-white text-xs font-bold hover:bg-cyan-700 shadow-xs"
                >
                  نقطة التكافؤ تماماً ({equivalenceVolume}mL)
                </button>
              </div>

              {/* Chemical Equations Box */}
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-[#15231e] border border-slate-200 dark:border-[#223930] space-y-2 text-xs">
                <div className="font-bold text-slate-800 dark:text-slate-100">
                  معادلة تفاعل التعادل الأيوني:
                </div>
                <div className="dir-ltr text-center font-mono text-teal-700 dark:text-teal-300 bg-white dark:bg-black/20 p-2 rounded-lg border border-slate-200/60 dark:border-slate-800">
                  HCl (aq) + NaOH (aq) ──&gt; NaCl (aq) + H2O (l)
                </div>
                <div className="text-[11px] text-slate-500 leading-relaxed">
                  عند إضافة {equivalenceVolume.toFixed(1)} مل من القاعدة، تتكافأ مولات أيونات H⁺ مع أيونات OH⁻، ويصل المحلول لدرجة التعادل التام pH = 7.00.
                </div>
              </div>
            </div>
          </div>

          {/* Interactive Periodic Table of Chemical Elements */}
          <div className="bg-white dark:bg-[#121c19] rounded-2xl border border-slate-200/90 dark:border-[#1e342b] p-4 sm:p-5 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 mb-4 border-b border-slate-100 dark:border-[#1e342b]">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                <div>
                  <h4 className="text-sm font-bold text-slate-800 dark:text-slate-100">
                    الجدول الدوري الحديث التفاعلي للعناصر الكيميائية
                  </h4>
                  <p className="text-[11px] text-slate-500">
                    استكشف الأعداد الذرية، التوزيع الإلكتروني، الكهروسالبية، ونماذج الذرة
                  </p>
                </div>
              </div>

              {/* Search Element input */}
              <div className="relative">
                <input
                  type="text"
                  placeholder="ابحث برمز أو اسم العنصر..."
                  value={periodicSearch}
                  onChange={(e) => setPeriodicSearch(e.target.value)}
                  className="pl-3 pr-8 py-1.5 text-xs rounded-xl bg-slate-50 dark:bg-[#172520] border border-slate-200 dark:border-[#243a32] text-slate-800 dark:text-slate-100 focus:outline-none focus:border-emerald-500 w-48 sm:w-56"
                />
                <Search className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-2.5" />
              </div>
            </div>

            {/* Elements Grid */}
            <div className="grid grid-cols-3 sm:grid-cols-5 md:grid-cols-7 lg:grid-cols-9 gap-2">
              {filteredElements.map((el) => {
                const isSelected = selectedElement.number === el.number;
                const catColor =
                  el.category === 'alkali' ? 'border-red-400 text-red-700 bg-red-50/70 dark:bg-red-950/30' :
                  el.category === 'alkaline-earth' ? 'border-orange-400 text-orange-700 bg-orange-50/70 dark:bg-orange-950/30' :
                  el.category === 'transition' ? 'border-amber-400 text-amber-700 bg-amber-50/70 dark:bg-amber-950/30' :
                  el.category === 'noble-gas' ? 'border-purple-400 text-purple-700 bg-purple-50/70 dark:bg-purple-950/30' :
                  el.category === 'halogen' ? 'border-emerald-400 text-emerald-700 bg-emerald-50/70 dark:bg-emerald-950/30' :
                  'border-teal-400 text-teal-700 bg-teal-50/70 dark:bg-teal-950/30';

                return (
                  <button
                    key={el.number}
                    type="button"
                    onClick={() => setSelectedElement(el)}
                    className={`p-2 rounded-xl border flex flex-col items-center justify-center transition-all cursor-pointer ${
                      isSelected
                        ? 'ring-2 ring-emerald-500 ring-offset-2 scale-105 shadow-md bg-emerald-600 text-white border-transparent'
                        : `${catColor} hover:scale-102`
                    }`}
                  >
                    <span className="text-[10px] font-mono font-bold opacity-75">{el.number}</span>
                    <span className="text-base font-black font-mono tracking-wider">{el.symbol}</span>
                    <span className="text-[10px] truncate max-w-full font-bold">{el.nameAr}</span>
                  </button>
                );
              })}
            </div>

            {/* Selected Element Detail Inspector */}
            {selectedElement && (
              <div className="mt-4 p-4 rounded-2xl bg-slate-50 dark:bg-[#162520] border border-slate-200 dark:border-[#223930] flex flex-col md:flex-row items-center justify-between gap-4 animate-in fade-in duration-150">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-2xl bg-emerald-600 text-white flex flex-col items-center justify-center font-mono shadow-md shrink-0">
                    <span className="text-xs opacity-75">{selectedElement.number}</span>
                    <span className="text-2xl font-black">{selectedElement.symbol}</span>
                  </div>
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <h5 className="text-base font-bold text-slate-800 dark:text-slate-100">
                        {selectedElement.nameAr} ({selectedElement.nameEn})
                      </h5>
                      <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-bold">
                        {selectedElement.category}
                      </span>
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed max-w-xl">
                      {selectedElement.descriptionAr}
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs shrink-0 w-full md:w-auto">
                  <div className="p-2 rounded-xl bg-white dark:bg-[#121c19] border border-slate-200/80 dark:border-slate-800 text-center">
                    <span className="text-[10px] text-slate-400 block">الكتلة الذرية</span>
                    <span className="font-mono font-bold text-slate-800 dark:text-slate-200">{selectedElement.weight} u</span>
                  </div>
                  <div className="p-2 rounded-xl bg-white dark:bg-[#121c19] border border-slate-200/80 dark:border-slate-800 text-center">
                    <span className="text-[10px] text-slate-400 block">التوزيع الإلكتروني</span>
                    <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400">{selectedElement.electronConfig}</span>
                  </div>
                  <div className="p-2 rounded-xl bg-white dark:bg-[#121c19] border border-slate-200/80 dark:border-slate-800 text-center">
                    <span className="text-[10px] text-slate-400 block">الكهروسالبية</span>
                    <span className="font-mono font-bold text-slate-800 dark:text-slate-200">
                      {selectedElement.electronegativity ? `${selectedElement.electronegativity} Pauling` : '—'}
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* 3. BIOLOGY & GENETICS LAB SECTION                         */}
      {/* ========================================================= */}
      {activeLabDomain === 'biology' && (
        <div className="space-y-5 animate-in fade-in duration-200">
          <div className="bg-white dark:bg-[#121c19] rounded-2xl border border-slate-200/90 dark:border-[#1e342b] p-4 sm:p-5 shadow-xs">
            <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-100 dark:border-[#1e342b]">
              <div className="flex items-center gap-2">
                <Dna className="w-5 h-5 text-pink-600 dark:text-pink-400" />
                <div>
                  <h4 className="text-sm font-bold text-slate-800 dark:text-slate-100">
                    محاكي مربع بانيت وقوانين الوراثة المندلية (Punnett Square)
                  </h4>
                  <p className="text-[11px] text-slate-500">
                    حساب الاحتمالات الوراثية والأنماط الجينية والمظهرية للنسل
                  </p>
                </div>
              </div>
              <span className="text-xs font-bold text-pink-700 dark:text-pink-300 bg-pink-50 dark:bg-pink-950/50 px-2.5 py-1 rounded-full">
                وراثة أحادية الهجين
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-5">
              {/* Controls */}
              <div className="md:col-span-4 space-y-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
                    الصفة الوراثية:
                  </label>
                  <input
                    type="text"
                    value={traitName}
                    onChange={(e) => setTraitName(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-[#182722] border border-slate-200 dark:border-[#223930] text-slate-800 dark:text-slate-100"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
                    جينات الأب (الأليلان):
                  </label>
                  <div className="flex gap-2">
                    {['BB (سائد نقي)', 'Bb (سائد هجين)', 'bb (متنحي)'].map((opt) => {
                      const code = opt.slice(0, 2);
                      return (
                        <button
                          key={code}
                          type="button"
                          onClick={() => setParent1Alleles(code)}
                          className={`flex-1 p-2 rounded-xl text-xs font-mono font-bold border transition-all cursor-pointer ${
                            parent1Alleles === code
                              ? 'bg-pink-600 text-white border-pink-600 shadow-xs'
                              : 'bg-white dark:bg-[#15231e] border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200'
                          }`}
                        >
                          {code}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
                    جينات الأم (الأليلان):
                  </label>
                  <div className="flex gap-2">
                    {['BB (سائد نقي)', 'Bb (سائد هجين)', 'bb (متنحي)'].map((opt) => {
                      const code = opt.slice(0, 2);
                      return (
                        <button
                          key={code}
                          type="button"
                          onClick={() => setParent2Alleles(code)}
                          className={`flex-1 p-2 rounded-xl text-xs font-mono font-bold border transition-all cursor-pointer ${
                            parent2Alleles === code
                              ? 'bg-pink-600 text-white border-pink-600 shadow-xs'
                              : 'bg-white dark:bg-[#15231e] border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200'
                          }`}
                        >
                          {code}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Punnett Visual Grid */}
              <div className="md:col-span-8 flex flex-col justify-between space-y-4">
                <div className="flex items-center justify-center">
                  <div className="grid grid-cols-3 gap-2 text-center font-mono">
                    {/* Header empty */}
                    <div className="p-3 bg-transparent" />
                    {/* Parent 1 Alleles */}
                    <div className="p-3 bg-pink-100 dark:bg-pink-950/60 text-pink-900 dark:text-pink-200 font-black rounded-xl text-lg">
                      {parent1Alleles[0]}
                    </div>
                    <div className="p-3 bg-pink-100 dark:bg-pink-950/60 text-pink-900 dark:text-pink-200 font-black rounded-xl text-lg">
                      {parent1Alleles[1]}
                    </div>

                    {/* Row 1 Parent 2 allele 0 */}
                    <div className="p-3 bg-pink-100 dark:bg-pink-950/60 text-pink-900 dark:text-pink-200 font-black rounded-xl text-lg flex items-center justify-center">
                      {parent2Alleles[0]}
                    </div>
                    <div className="p-4 bg-slate-50 dark:bg-[#1a2b25] border-2 border-pink-500/40 rounded-xl text-xl font-black text-slate-800 dark:text-slate-100 shadow-xs">
                      {punnettResults?.cells[0][0]}
                    </div>
                    <div className="p-4 bg-slate-50 dark:bg-[#1a2b25] border-2 border-pink-500/40 rounded-xl text-xl font-black text-slate-800 dark:text-slate-100 shadow-xs">
                      {punnettResults?.cells[0][1]}
                    </div>

                    {/* Row 2 Parent 2 allele 1 */}
                    <div className="p-3 bg-pink-100 dark:bg-pink-950/60 text-pink-900 dark:text-pink-200 font-black rounded-xl text-lg flex items-center justify-center">
                      {parent2Alleles[1]}
                    </div>
                    <div className="p-4 bg-slate-50 dark:bg-[#1a2b25] border-2 border-pink-500/40 rounded-xl text-xl font-black text-slate-800 dark:text-slate-100 shadow-xs">
                      {punnettResults?.cells[1][0]}
                    </div>
                    <div className="p-4 bg-slate-50 dark:bg-[#1a2b25] border-2 border-pink-500/40 rounded-xl text-xl font-black text-slate-800 dark:text-slate-100 shadow-xs">
                      {punnettResults?.cells[1][1]}
                    </div>
                  </div>
                </div>

                {/* Statistical Probabilities */}
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div className="p-3 rounded-xl bg-pink-50/70 dark:bg-pink-950/30 border border-pink-200 dark:border-pink-900 text-right">
                    <span className="text-[11px] font-bold text-pink-800 dark:text-pink-300 block">
                      النمط المظهري السائد (Dominant):
                    </span>
                    <span className="text-xl font-black font-mono text-pink-700 dark:text-pink-300 mt-1 block">
                      {punnettResults?.dominantPercent}%
                    </span>
                    <span className="text-[10px] text-slate-500">يحمل أليلاً واحداً سائد B على الأقل</span>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-50 dark:bg-[#182722] border border-slate-200 dark:border-[#223930] text-right">
                    <span className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block">
                      النمط المظهري المتنحي (Recessive):
                    </span>
                    <span className="text-xl font-black font-mono text-slate-800 dark:text-slate-200 mt-1 block">
                      {punnettResults?.recessivePercent}%
                    </span>
                    <span className="text-[10px] text-slate-500">أليلان متنحيان نقيان bb</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* 4. SCIENTIFIC RESEARCH & HYPOTHESIS BUILDER               */}
      {/* ========================================================= */}
      {activeLabDomain === 'research' && (
        <div className="space-y-5 animate-in fade-in duration-200">
          <div className="bg-white dark:bg-[#121c19] rounded-2xl border border-slate-200/90 dark:border-[#1e342b] p-4 sm:p-6 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-[#1e342b]">
              <div className="flex items-center gap-2">
                <Microscope className="w-5 h-5 text-amber-600 dark:text-amber-400" />
                <div>
                  <h4 className="text-sm sm:text-base font-bold text-slate-800 dark:text-slate-100">
                    أداة تصميم البحث العلمي وصياغة الفرضيات المنهجية
                  </h4>
                  <p className="text-[11px] text-slate-500">
                    اتبع خطوات المنهج العلمي من صياغة المشكلة إلى الاستنتاج الأكاديمي الموثق
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={handlePrintExperimentReport}
                className="px-3.5 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>طباعة البحث الأكاديمي</span>
              </button>
            </div>

            <div className="space-y-3.5">
              <div>
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  ١. عنوان البحث أو التساؤل العلمي:
                </label>
                <input
                  type="text"
                  value={researchTitle}
                  onChange={(e) => setResearchTitle(e.target.value)}
                  className="w-full px-3 py-2 text-xs sm:text-sm rounded-xl bg-slate-50 dark:bg-[#182722] border border-slate-200 dark:border-[#223930] text-slate-800 dark:text-slate-100 focus:outline-none focus:border-teal-600"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  ٢. الفرضية العلمية المصاغة (Hypothesis):
                </label>
                <textarea
                  rows={2}
                  value={researchHypothesis}
                  onChange={(e) => setResearchHypothesis(e.target.value)}
                  className="w-full px-3 py-2 text-xs sm:text-sm rounded-xl bg-slate-50 dark:bg-[#182722] border border-slate-200 dark:border-[#223930] text-slate-800 dark:text-slate-100 focus:outline-none focus:border-teal-600 leading-relaxed"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                    المتغير المستقل (Independent):
                  </label>
                  <input
                    type="text"
                    value={independentVar}
                    onChange={(e) => setIndependentVar(e.target.value)}
                    className="w-full px-3 py-1.5 text-xs rounded-xl bg-slate-50 dark:bg-[#182722] border border-slate-200 dark:border-[#223930] text-slate-800 dark:text-slate-100"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                    المتغير التابع (Dependent):
                  </label>
                  <input
                    type="text"
                    value={dependentVar}
                    onChange={(e) => setDependentVar(e.target.value)}
                    className="w-full px-3 py-1.5 text-xs rounded-xl bg-slate-50 dark:bg-[#182722] border border-slate-200 dark:border-[#223930] text-slate-800 dark:text-slate-100"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                    المتغيرات الضابطة (Controlled):
                  </label>
                  <input
                    type="text"
                    value={controlledVars}
                    onChange={(e) => setControlledVars(e.target.value)}
                    className="w-full px-3 py-1.5 text-xs rounded-xl bg-slate-50 dark:bg-[#182722] border border-slate-200 dark:border-[#223930] text-slate-800 dark:text-slate-100"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  ٣. الاستنتاج العلمي وتفسير البيانات (Conclusion):
                </label>
                <textarea
                  rows={3}
                  value={researchConclusion}
                  onChange={(e) => setResearchConclusion(e.target.value)}
                  className="w-full px-3 py-2 text-xs sm:text-sm rounded-xl bg-slate-50 dark:bg-[#182722] border border-slate-200 dark:border-[#223930] text-slate-800 dark:text-slate-100 focus:outline-none focus:border-teal-600 leading-relaxed"
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Academic Print Report Modal */}
      {isPrintModalOpen && printModalSummary && (
        <AcademicPrintModal
          isOpen={isPrintModalOpen}
          onClose={() => setIsPrintModalOpen(false)}
          summary={printModalSummary}
        />
      )}
    </div>
  );
};
