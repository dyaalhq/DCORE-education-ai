import React, { useState } from 'react';
import {
  BookOpen,
  Download,
  Printer,
  Sparkles,
  FileText,
  Bookmark,
  Share2,
  Check,
  Copy,
  ChevronLeft,
  ChevronRight,
  ArrowRight,
  Layers,
  HelpCircle,
  FolderDown,
  ExternalLink,
  Calendar,
  User,
  ShieldCheck,
  BookMarked,
  Tag,
  Search,
} from 'lucide-react';
import { SharedNotebookPayload } from '../lib/shareService';
import { EducationalContent } from './EducationalContent';

interface SharedNotebookViewProps {
  shareData: SharedNotebookPayload;
  onImportToWorkspace: (shareData: SharedNotebookPayload) => void;
  onExitSharedView: () => void;
  onPrintSummary?: (title: string, content: string) => void;
}

export const SharedNotebookView: React.FC<SharedNotebookViewProps> = ({
  shareData,
  onImportToWorkspace,
  onExitSharedView,
  onPrintSummary,
}) => {
  const [activeTab, setActiveTab] = useState<'summaries' | 'notes' | 'glossary' | 'flashcards' | 'sources'>('summaries');
  const [selectedSummaryIndex, setSelectedSummaryIndex] = useState<number>(0);
  const [flashcardIndex, setFlashcardIndex] = useState<number>(0);
  const [showFlashcardBack, setShowFlashcardBack] = useState<boolean>(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [copiedLink, setCopiedLink] = useState(false);
  const [imported, setImported] = useState(false);

  const { notebook, authorName, createdAt, summaries, notes, memos, glossary, flashcards, sourcesOverview } = shareData;

  const handleCopyCurrentLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleImport = () => {
    onImportToWorkspace(shareData);
    setImported(true);
    setTimeout(() => setImported(false), 3000);
  };

  const currentSummary = summaries[selectedSummaryIndex] || summaries[0];

  const filteredNotes = notes.filter(
    (n) =>
      n.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      n.text.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (n.tags && n.tags.some((t) => t.toLowerCase().includes(searchTerm.toLowerCase())))
  );

  const filteredGlossary = glossary.filter(
    (g) =>
      g.term.toLowerCase().includes(searchTerm.toLowerCase()) ||
      g.def.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-[#f8fbfa] dark:bg-[#0c1311] text-[#17201e] dark:text-[#eef7f4] font-sans antialiased" dir="rtl">
      {/* Top Banner indicating Shared Public Mode */}
      <header className="sticky top-0 z-30 bg-white/95 dark:bg-[#121b18]/95 backdrop-blur-md border-b border-[#e2e8e5] dark:border-[#22352f] shadow-xs">
        <div className="max-w-7xl mx-auto px-4 py-3 sm:px-6 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <button
              onClick={onExitSharedView}
              className="p-2 rounded-xl text-gray-500 hover:text-gray-800 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors flex items-center gap-1 text-xs font-semibold"
              title="العودة لمساحة عملي"
            >
              <ArrowRight className="w-4 h-4 rotate-180" />
              <span>مساحة العمل</span>
            </button>

            <div className="h-5 w-px bg-gray-200 dark:bg-gray-800" />

            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-teal-500 animate-pulse" />
              <span className="text-xs font-bold text-teal-800 dark:text-teal-300 bg-teal-100 dark:bg-teal-950 px-2 py-0.5 rounded-md">
                دفتر دراسي مشترك (Public View)
              </span>
              <span className="text-xs font-semibold text-gray-500 hidden sm:inline">
                بواسطة: {authorName || 'زميل دراسي'}
              </span>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2">
            <button
              onClick={handleCopyCurrentLink}
              className="px-3 py-1.5 rounded-xl border border-gray-200 dark:border-gray-700 text-xs font-semibold hover:bg-gray-50 dark:hover:bg-gray-800 flex items-center gap-1.5 transition-colors"
            >
              {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Share2 className="w-3.5 h-3.5" />}
              <span>{copiedLink ? 'تم النسخ' : 'نسخ الرابط'}</span>
            </button>

            <button
              onClick={handleImport}
              className={`px-4 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs ${
                imported
                  ? 'bg-emerald-600 text-white'
                  : 'bg-[#0f766e] text-white hover:bg-[#115e59]'
              }`}
            >
              {imported ? <Check className="w-3.5 h-3.5" /> : <FolderDown className="w-3.5 h-3.5" />}
              <span>{imported ? 'تم الحفظ في دفاترك!' : 'حفظ نسخة في دفاتري'}</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="max-w-7xl mx-auto px-4 py-6 sm:px-6 space-y-6">
        {/* Notebook Hero Header Card */}
        <div className="bg-gradient-to-l from-teal-900/10 via-teal-800/5 to-transparent bg-white dark:bg-[#14201c] rounded-2xl border border-teal-200/80 dark:border-teal-900/60 p-6 shadow-sm">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span className="px-2.5 py-0.5 rounded-lg bg-teal-600 text-white text-xs font-bold">
                  {notebook.subject || 'منهج دراسي'}
                </span>
                <span className="text-xs text-gray-500 flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5" />
                  <span>{new Date(createdAt).toLocaleDateString('ar-SA')}</span>
                </span>
              </div>
              <h1 className="text-2xl font-black text-[#17201e] dark:text-[#eef7f4]">
                {notebook.name}
              </h1>
              {notebook.description && (
                <p className="text-xs text-[#596762] dark:text-[#9ab3ab] mt-1.5 max-w-2xl leading-relaxed">
                  {notebook.description}
                </p>
              )}
            </div>

            {/* Stats chips */}
            <div className="flex flex-wrap items-center gap-2 text-xs">
              <span className="px-3 py-1.5 rounded-xl bg-gray-100 dark:bg-[#1e2d27] font-semibold text-gray-700 dark:text-gray-300">
                📑 {summaries.length} ملخصات
              </span>
              <span className="px-3 py-1.5 rounded-xl bg-gray-100 dark:bg-[#1e2d27] font-semibold text-gray-700 dark:text-gray-300">
                📝 {notes.length + memos.length} ملاحظات وتدوينات
              </span>
              <span className="px-3 py-1.5 rounded-xl bg-gray-100 dark:bg-[#1e2d27] font-semibold text-gray-700 dark:text-gray-300">
                📖 {glossary.length} مصطلحات
              </span>
              <span className="px-3 py-1.5 rounded-xl bg-gray-100 dark:bg-[#1e2d27] font-semibold text-gray-700 dark:text-gray-300">
                🗂️ {flashcards.length} بطاقات
              </span>
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 border-b border-gray-200 dark:border-gray-800 pb-2 overflow-x-auto">
          <button
            onClick={() => setActiveTab('summaries')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 shrink-0 ${
              activeTab === 'summaries'
                ? 'bg-[#0f766e] text-white shadow-xs'
                : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>الملخصات الأكاديمية ({summaries.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('notes')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 shrink-0 ${
              activeTab === 'notes'
                ? 'bg-[#0f766e] text-white shadow-xs'
                : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800'
            }`}
          >
            <Bookmark className="w-4 h-4" />
            <span>الملاحظات والتدوينات ({notes.length + memos.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('glossary')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 shrink-0 ${
              activeTab === 'glossary'
                ? 'bg-[#0f766e] text-white shadow-xs'
                : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>معجم المفاهيم والمصطلحات ({glossary.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('flashcards')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 shrink-0 ${
              activeTab === 'flashcards'
                ? 'bg-[#0f766e] text-white shadow-xs'
                : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>بطاقات المراجعة ({flashcards.length})</span>
          </button>

          {sourcesOverview.length > 0 && (
            <button
              onClick={() => setActiveTab('sources')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 shrink-0 ${
                activeTab === 'sources'
                  ? 'bg-[#0f766e] text-white shadow-xs'
                  : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800'
              }`}
            >
              <BookMarked className="w-4 h-4" />
              <span>المصادر المرجعية ({sourcesOverview.length})</span>
            </button>
          )}
        </div>

        {/* Tab 1: Summaries */}
        {activeTab === 'summaries' && (
          <div className="space-y-4">
            {summaries.length === 0 ? (
              <div className="text-center py-16 bg-white dark:bg-[#14201c] rounded-2xl border border-gray-200 dark:border-gray-800 p-8">
                <FileText className="w-12 h-12 text-gray-300 dark:text-gray-600 mx-auto mb-3" />
                <h3 className="font-bold text-base text-gray-700 dark:text-gray-300">
                  لم يتم تضمين ملخصات في هذا الرابط
                </h3>
                <p className="text-xs text-gray-500 mt-1">
                  يمكنك استعراض الملاحظات أو معجم المصطلحات من التبويبات أعلاه.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
                {/* Summaries list column if multiple */}
                {summaries.length > 1 && (
                  <div className="lg:col-span-1 space-y-2">
                    <span className="text-xs font-bold text-gray-500 block mb-1">
                      الملخصات المتاحة بالدفتر:
                    </span>
                    {summaries.map((sum, idx) => (
                      <button
                        key={sum.id || idx}
                        onClick={() => setSelectedSummaryIndex(idx)}
                        className={`w-full text-right p-3 rounded-xl text-xs font-bold transition-all border block ${
                          selectedSummaryIndex === idx
                            ? 'bg-teal-50 dark:bg-teal-950/60 border-teal-500 text-teal-800 dark:text-teal-200'
                            : 'bg-white dark:bg-[#14201c] border-gray-200 dark:border-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-50'
                        }`}
                      >
                        <span className="block truncate">{sum.title}</span>
                        {sum.date && (
                          <span className="text-[10px] text-gray-400 font-normal block mt-0.5">
                            {sum.date}
                          </span>
                        )}
                      </button>
                    ))}
                  </div>
                )}

                {/* Main Summary Content */}
                <div className={summaries.length > 1 ? 'lg:col-span-3' : 'lg:col-span-4'}>
                  <div className="bg-white dark:bg-[#14201c] rounded-2xl border border-[#e2e8e5] dark:border-[#22352f] p-6 shadow-sm space-y-6">
                    <div className="flex flex-wrap items-center justify-between pb-4 border-b border-gray-200 dark:border-gray-800 gap-2">
                      <div>
                        <h2 className="text-xl font-bold text-[#17201e] dark:text-[#eef7f4]">
                          {currentSummary.title}
                        </h2>
                        <span className="text-xs text-teal-600 dark:text-teal-400 font-semibold">
                          تقرير أكاديمي منظم بأسلوب NotebookLM
                        </span>
                      </div>

                      {onPrintSummary && (
                        <button
                          onClick={() => onPrintSummary(currentSummary.title, currentSummary.content)}
                          className="px-3 py-1.5 bg-gray-100 dark:bg-[#1a2723] hover:bg-gray-200 rounded-xl text-xs font-bold text-gray-700 dark:text-gray-300 flex items-center gap-1.5 transition-colors"
                          title="طباعة هذا الملخص"
                        >
                          <Printer className="w-3.5 h-3.5" />
                          <span>طباعة PDF</span>
                        </button>
                      )}
                    </div>

                    {/* Educational Rendered Content */}
                    <div className="prose prose-sm dark:prose-invert max-w-none text-[#17201e] dark:text-[#eef7f4] leading-relaxed">
                      <EducationalContent content={currentSummary.content} />
                    </div>

                    {/* Boxes if present */}
                    {currentSummary.boxes && currentSummary.boxes.length > 0 && (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-4 border-t border-gray-200 dark:border-gray-800">
                        {currentSummary.boxes.map((box) => (
                          <div
                            key={box.id}
                            className="p-3.5 rounded-xl border border-teal-200 dark:border-teal-900 bg-teal-50/40 dark:bg-teal-950/30 text-xs space-y-1"
                          >
                            <span className="font-bold text-teal-800 dark:text-teal-300 block">
                              {box.title}
                            </span>
                            <p className="text-gray-700 dark:text-gray-300 leading-normal">
                              {box.body}
                            </p>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Tab 2: Notes & Study Memos */}
        {activeTab === 'notes' && (
          <div className="space-y-4">
            {/* Search filter */}
            <div className="relative max-w-md">
              <Search className="w-4 h-4 text-gray-400 absolute right-3 top-3 pointer-events-none" />
              <input
                type="text"
                placeholder="ابحث في الملاحظات والتدوينات..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pr-9 pl-4 py-2 bg-white dark:bg-[#14201c] border border-gray-200 dark:border-gray-800 rounded-xl text-xs text-[#17201e] dark:text-[#eef7f4] focus:outline-none focus:border-teal-500"
              />
            </div>

            {/* Notes Grid */}
            {notes.length === 0 && memos.length === 0 ? (
              <div className="text-center py-16 bg-white dark:bg-[#14201c] rounded-2xl border border-gray-200 dark:border-gray-800 p-8">
                <Bookmark className="w-12 h-12 text-gray-300 dark:text-gray-600 mx-auto mb-3" />
                <h3 className="font-bold text-base text-gray-700 dark:text-gray-300">
                  لا توجد ملاحظات منشورة في هذا الدفتر
                </h3>
              </div>
            ) : (
              <div className="space-y-6">
                {/* Notes cards */}
                {filteredNotes.length > 0 && (
                  <div>
                    <h3 className="text-sm font-bold text-gray-600 dark:text-gray-400 mb-3 flex items-center gap-2">
                      <Bookmark className="w-4 h-4 text-teal-600" />
                      <span>الملاحظات والتظليلات الأكاديمية ({filteredNotes.length})</span>
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {filteredNotes.map((note) => (
                        <div
                          key={note.id}
                          className="bg-white dark:bg-[#14201c] rounded-xl border border-gray-200 dark:border-gray-800 p-4 shadow-xs space-y-3"
                        >
                          <div className="flex items-start justify-between gap-2">
                            <h4 className="font-bold text-sm text-[#17201e] dark:text-[#eef7f4]">
                              {note.title}
                            </h4>
                            {note.goal && (
                              <span className="text-[10px] px-2 py-0.5 rounded bg-teal-100 dark:bg-teal-950 text-teal-800 dark:text-teal-300 font-semibold shrink-0">
                                {note.goal}
                              </span>
                            )}
                          </div>

                          <div className="text-xs text-gray-600 dark:text-gray-300 leading-relaxed max-h-48 overflow-y-auto whitespace-pre-wrap">
                            {note.text}
                          </div>

                          {note.tags && note.tags.length > 0 && (
                            <div className="flex flex-wrap gap-1 pt-2 border-t border-gray-100 dark:border-gray-800">
                              {note.tags.map((tag, tIdx) => (
                                <span
                                  key={tIdx}
                                  className="text-[10px] bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300 px-2 py-0.5 rounded-md flex items-center gap-1"
                                >
                                  <Tag className="w-2.5 h-2.5" />
                                  <span>{tag}</span>
                                </span>
                              ))}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Memos cards */}
                {memos.length > 0 && (
                  <div>
                    <h3 className="text-sm font-bold text-gray-600 dark:text-gray-400 mb-3 flex items-center gap-2">
                      <FileText className="w-4 h-4 text-teal-600" />
                      <span>مذكرات وتدوينات سريعة ({memos.length})</span>
                    </h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                      {memos.map((memo) => (
                        <div
                          key={memo.id}
                          className="bg-amber-50/50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/40 rounded-xl p-3 text-xs text-amber-950 dark:text-amber-200 leading-relaxed shadow-xs"
                        >
                          <p>{memo.text}</p>
                          {memo.createdAt && (
                            <span className="text-[10px] text-amber-700/60 dark:text-amber-400/60 block mt-2 text-left">
                              {new Date(memo.createdAt).toLocaleDateString('ar-SA')}
                            </span>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* Tab 3: Glossary */}
        {activeTab === 'glossary' && (
          <div className="space-y-4">
            <div className="relative max-w-md">
              <Search className="w-4 h-4 text-gray-400 absolute right-3 top-3 pointer-events-none" />
              <input
                type="text"
                placeholder="ابحث في معجم المصطلحات والمفاهيم..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pr-9 pl-4 py-2 bg-white dark:bg-[#14201c] border border-gray-200 dark:border-gray-800 rounded-xl text-xs text-[#17201e] dark:text-[#eef7f4] focus:outline-none focus:border-teal-500"
              />
            </div>

            {filteredGlossary.length === 0 ? (
              <div className="text-center py-16 bg-white dark:bg-[#14201c] rounded-2xl border border-gray-200 dark:border-gray-800 p-8">
                <BookOpen className="w-12 h-12 text-gray-300 dark:text-gray-600 mx-auto mb-3" />
                <h3 className="font-bold text-base text-gray-700 dark:text-gray-300">
                  لا توجد مصطلحات في معجم هذا الدفتر
                </h3>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredGlossary.map((item) => (
                  <div
                    key={item.id}
                    className="bg-white dark:bg-[#14201c] rounded-xl border border-teal-100 dark:border-teal-900/60 p-4 shadow-xs space-y-2 hover:border-teal-400 transition-colors"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-black text-sm text-[#0f766e] dark:text-[#2dd4bf]">
                        {item.term}
                      </span>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-teal-50 dark:bg-teal-950 text-teal-700 dark:text-teal-300 font-bold">
                        مفهوم أساسي
                      </span>
                    </div>
                    <p className="text-xs text-gray-700 dark:text-gray-300 leading-relaxed">
                      {item.def}
                    </p>
                    {item.ex && (
                      <div className="text-[11px] bg-gray-50 dark:bg-[#182520] p-2 rounded-lg text-gray-600 dark:text-gray-400">
                        <span className="font-bold text-teal-700 dark:text-teal-300">مثال توضيحي: </span>
                        {item.ex}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Tab 4: Flashcards */}
        {activeTab === 'flashcards' && (
          <div className="space-y-6">
            {flashcards.length === 0 ? (
              <div className="text-center py-16 bg-white dark:bg-[#14201c] rounded-2xl border border-gray-200 dark:border-gray-800 p-8">
                <Layers className="w-12 h-12 text-gray-300 dark:text-gray-600 mx-auto mb-3" />
                <h3 className="font-bold text-base text-gray-700 dark:text-gray-300">
                  لا توجد بطاقات مراجعة في هذا الدفتر المشترك
                </h3>
              </div>
            ) : (
              <div className="max-w-xl mx-auto space-y-4">
                <div className="flex items-center justify-between text-xs text-gray-500">
                  <span>
                    بطاقة {flashcardIndex + 1} من {flashcards.length}
                  </span>
                  <span>انقر على البطاقة لقلبها</span>
                </div>

                {/* Interactive Flashcard */}
                <div
                  onClick={() => setShowFlashcardBack(!showFlashcardBack)}
                  className="w-full min-h-[220px] bg-white dark:bg-[#14201c] rounded-2xl border-2 border-teal-500/40 hover:border-teal-500 p-8 shadow-md flex flex-col justify-between cursor-pointer transition-all text-center select-none"
                >
                  <span className="text-xs font-bold text-teal-600 dark:text-teal-400">
                    {showFlashcardBack ? 'الإجابة والشرح' : 'السؤال والمفهوم'}
                  </span>

                  <div className="py-4 text-base sm:text-lg font-bold text-[#17201e] dark:text-[#eef7f4] leading-relaxed">
                    {showFlashcardBack
                      ? flashcards[flashcardIndex].back
                      : flashcards[flashcardIndex].front}
                  </div>

                  <span className="text-[11px] text-gray-400">
                    {showFlashcardBack ? 'انقر للعودة للسؤال ↺' : 'انقر لإظهار الإجابة ↻'}
                  </span>
                </div>

                {/* Controls */}
                <div className="flex items-center justify-between pt-2">
                  <button
                    onClick={() => {
                      setShowFlashcardBack(false);
                      setFlashcardIndex((prev) => Math.max(0, prev - 1));
                    }}
                    disabled={flashcardIndex === 0}
                    className="px-4 py-2 rounded-xl text-xs font-bold border border-gray-300 dark:border-gray-700 disabled:opacity-40 flex items-center gap-1"
                  >
                    <ChevronRight className="w-4 h-4" />
                    <span>السابق</span>
                  </button>

                  <button
                    onClick={() => setShowFlashcardBack(!showFlashcardBack)}
                    className="px-4 py-2 bg-teal-50 dark:bg-teal-950 text-teal-700 dark:text-teal-300 rounded-xl text-xs font-bold"
                  >
                    قلب البطاقة
                  </button>

                  <button
                    onClick={() => {
                      setShowFlashcardBack(false);
                      setFlashcardIndex((prev) => Math.min(flashcards.length - 1, prev + 1));
                    }}
                    disabled={flashcardIndex === flashcards.length - 1}
                    className="px-4 py-2 rounded-xl text-xs font-bold border border-gray-300 dark:border-gray-700 disabled:opacity-40 flex items-center gap-1"
                  >
                    <span>التالي</span>
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Tab 5: Sources Overview */}
        {activeTab === 'sources' && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {sourcesOverview.map((src) => (
                <div
                  key={src.id}
                  className="bg-white dark:bg-[#14201c] rounded-xl border border-gray-200 dark:border-gray-800 p-4 shadow-xs space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-sm text-[#17201e] dark:text-[#eef7f4]">
                      {src.title}
                    </span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300">
                      {src.type}
                    </span>
                  </div>
                  {src.summary && (
                    <p className="text-xs text-gray-600 dark:text-gray-400 leading-relaxed">
                      {src.summary}
                    </p>
                  )}
                  {src.wordCount && (
                    <span className="text-[10px] text-gray-400 block">
                      حجم المحتوى: {src.wordCount} كلمة
                    </span>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </main>
    </div>
  );
};
