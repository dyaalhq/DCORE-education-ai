import React, { useRef, useState, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import {
  OrbitControls,
  Text,
  Float,
  MeshTransmissionMaterial,
  Sparkles,
  ContactShadows,
  PerspectiveCamera,
  Environment,
  Html
} from '@react-three/drei';
import * as THREE from 'three';
import {
  FlaskConical,
  Atom,
  Flame,
  Zap,
  RotateCcw,
  Sparkles as SparklesIcon,
  HelpCircle,
  Eye,
  Check,
  Maximize2,
  Minimize2,
  Info,
  X,
  ChevronDown,
  ChevronUp,
  Sliders,
  Play,
  Pause
} from 'lucide-react';
import { SafeInlineMath } from './EducationalContent';

export interface Interactive3DTool {
  id: string;
  nameAr: string;
  nameEn: string;
  category: 'chemistry' | 'physics' | 'biology';
  color: string;
  position: [number, number, number];
  descriptionAr: string;
  chemicalFormula?: string;
  scientificLaw?: string;
  simulationType: 'reaction' | 'pendulum' | 'dna' | 'burner' | 'centrifuge' | 'spectrometer';
}

export const LAB_3D_TOOLS: Interactive3DTool[] = [
  {
    id: 'erlenmeyer',
    nameAr: 'دورق إرلنماير للمعايرة الكيميائية',
    nameEn: 'Erlenmeyer Titration Flask',
    category: 'chemistry',
    color: '#06b6d4',
    position: [-2.2, 0.45, 0.2],
    descriptionAr: 'وعاء زجاجي مخروطي مخبري لمزج السوائل والمعايرة الدقيقة وتجنب تناثر الأحماض والقواعد.',
    chemicalFormula: 'HCl_{(aq)} + NaOH_{(aq)} \\rightarrow NaCl_{(aq)} + H_2O_{(l)}',
    scientificLaw: 'قانون التكافؤ الأيوني: N_1 V_1 = N_2 V_2',
    simulationType: 'reaction'
  },
  {
    id: 'bunsen',
    nameAr: 'موقد بنسن الحراري',
    nameEn: 'Bunsen Burner Flame',
    category: 'chemistry',
    color: '#f97316',
    position: [-0.7, 0.5, -0.6],
    descriptionAr: 'مصدر لهب مخبري معقم يعتمد على احتراق الميثان لإنتاج لهب أزرق مؤكسد عالي الحرارة يصل إلى 1500°C.',
    chemicalFormula: 'CH_{4(g)} + 2O_{2(g)} \\rightarrow CO_{2(g)} + 2H_2O_{(g)} + \\Delta H',
    scientificLaw: 'قانون الاحتراق التام والديناميكا الحرارية الأول',
    simulationType: 'burner'
  },
  {
    id: 'pendulum_3d',
    nameAr: 'جهاز البندول التوافقي الميكانيكي',
    nameEn: 'Harmonic Motion Pendulum',
    category: 'physics',
    color: '#10b981',
    position: [0.8, 0.7, 0.3],
    descriptionAr: 'نظام اهتزازي دوري يتكون من خيط عديم الوزن معلق به ثقل، يوضح تحول طاقة الوضع إلى طاقة حركة.',
    scientificLaw: 'الزمن الدوري للبندول: T = 2\\pi \\sqrt{\\frac{L}{g}}',
    simulationType: 'pendulum'
  },
  {
    id: 'dna_helix',
    nameAr: 'جهاز تحليل الجينات والـ DNA الحلزوني',
    nameEn: 'DNA Molecular Double Helix',
    category: 'biology',
    color: '#ec4899',
    position: [2.3, 0.6, -0.2],
    descriptionAr: 'نموذج واتسون وكريك للولب المزدوج للحمض النووي DNA المكون من نيكليوتيدات وروابط هيدروجينية وقواعد نيتروجينية (A-T, G-C).',
    scientificLaw: 'قاعدة تشارجاف: A = T \\quad \\text{و} \\quad G \\equiv C',
    simulationType: 'dna'
  }
];

// ----------------------------------------------------------------------
// 3D Erlenmeyer Flask Model
// ----------------------------------------------------------------------
const ErlenmeyerFlask: React.FC<{
  isSelected: boolean;
  isHovered: boolean;
  liquidColor: string;
  onClick: () => void;
  onPointerOver: () => void;
  onPointerOut: () => void;
}> = ({ isSelected, isHovered, liquidColor, onClick, onPointerOver, onPointerOut }) => {
  const liquidRef = useRef<THREE.Mesh>(null);
  const bubblesRef = useRef<THREE.Group>(null);

  useFrame((state) => {
    if (liquidRef.current) {
      const t = state.clock.getElapsedTime();
      liquidRef.current.position.y = -0.15 + Math.sin(t * 3) * 0.015;
    }
    if (bubblesRef.current) {
      bubblesRef.current.rotation.y += 0.01;
    }
  });

  return (
    <group
      position={[-2.2, 0.5, 0.2]}
      onClick={(e) => {
        e.stopPropagation();
        onClick();
      }}
      onPointerOver={(e) => {
        e.stopPropagation();
        onPointerOver();
      }}
      onPointerOut={onPointerOut}
    >
      {/* Selection Glow Indicator Ring */}
      {(isSelected || isHovered) && (
        <mesh position={[0, -0.48, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <ringGeometry args={[0.5, 0.62, 32]} />
          <meshBasicMaterial
            color={isSelected ? '#06b6d4' : '#67e8f9'}
            transparent
            opacity={isSelected ? 0.9 : 0.5}
            side={THREE.DoubleSide}
          />
        </mesh>
      )}

      {/* Floating 3D Label */}
      {(isSelected || isHovered) && (
        <Html position={[0, 0.85, 0]} center distanceFactor={10} pointerEvents="none">
          <div className="bg-slate-900/90 text-cyan-300 border border-cyan-500/50 px-2.5 py-1 rounded-xl text-[11px] font-bold shadow-lg backdrop-blur-md whitespace-nowrap animate-in fade-in zoom-in-95 pointer-events-none select-none" dir="rtl">
            🧪 دورق إرلنماير (انقر للفحص)
          </div>
        </Html>
      )}

      {/* Glass Body (Cone/Cylinder) */}
      <mesh position={[0, 0, 0]}>
        <cylinderGeometry args={[0.18, 0.48, 0.75, 32]} />
        <meshPhysicalMaterial
          color="#ffffff"
          transmission={0.88}
          roughness={0.05}
          ior={1.5}
          thickness={0.5}
          transparent
          opacity={0.65}
          envMapIntensity={1.5}
        />
      </mesh>

      {/* Neck */}
      <mesh position={[0, 0.42, 0]}>
        <cylinderGeometry args={[0.14, 0.14, 0.25, 32]} />
        <meshPhysicalMaterial
          color="#ffffff"
          transmission={0.88}
          roughness={0.05}
          ior={1.5}
          thickness={0.4}
          transparent
          opacity={0.65}
        />
      </mesh>

      {/* Rim Lip */}
      <mesh position={[0, 0.54, 0]}>
        <torusGeometry args={[0.14, 0.02, 16, 32]} />
        <meshStandardMaterial color="#cbd5e1" roughness={0.2} metalness={0.1} />
      </mesh>

      {/* Chemical Liquid Inside */}
      <mesh ref={liquidRef} position={[0, -0.15, 0]}>
        <cylinderGeometry args={[0.26, 0.44, 0.4, 32]} />
        <meshStandardMaterial
          color={liquidColor}
          emissive={liquidColor}
          emissiveIntensity={0.25}
          roughness={0.1}
          metalness={0.1}
          transparent
          opacity={0.85}
        />
      </mesh>

      {/* Micro effervescence bubbles */}
      <group ref={bubblesRef} position={[0, -0.15, 0]}>
        <Sparkles count={15} scale={[0.4, 0.35, 0.4]} size={2.5} speed={1.5} color="#ffffff" />
      </group>
    </group>
  );
};

// ----------------------------------------------------------------------
// 3D Bunsen Burner Model
// ----------------------------------------------------------------------
const BunsenBurner: React.FC<{
  isSelected: boolean;
  isHovered: boolean;
  isFlameActive: boolean;
  onClick: () => void;
  onPointerOver: () => void;
  onPointerOut: () => void;
}> = ({ isSelected, isHovered, isFlameActive, onClick, onPointerOver, onPointerOut }) => {
  const flameLightRef = useRef<THREE.PointLight>(null);
  const flameMeshRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    const t = state.clock.getElapsedTime();
    if (flameLightRef.current && isFlameActive) {
      flameLightRef.current.intensity = 2.5 + Math.sin(t * 15) * 0.7;
    }
    if (flameMeshRef.current && isFlameActive) {
      const scale = 1 + Math.sin(t * 18) * 0.12;
      flameMeshRef.current.scale.set(scale, scale * 1.1, scale);
    }
  });

  return (
    <group
      position={[-0.7, 0.45, -0.6]}
      onClick={(e) => {
        e.stopPropagation();
        onClick();
      }}
      onPointerOver={(e) => {
        e.stopPropagation();
        onPointerOver();
      }}
      onPointerOut={onPointerOut}
    >
      {(isSelected || isHovered) && (
        <mesh position={[0, -0.44, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <ringGeometry args={[0.4, 0.52, 32]} />
          <meshBasicMaterial
            color={isSelected ? '#f97316' : '#fdba74'}
            transparent
            opacity={isSelected ? 0.9 : 0.5}
            side={THREE.DoubleSide}
          />
        </mesh>
      )}

      {(isSelected || isHovered) && (
        <Html position={[0, 0.85, 0]} center distanceFactor={10} pointerEvents="none">
          <div className="bg-slate-900/90 text-orange-300 border border-orange-500/50 px-2.5 py-1 rounded-xl text-[11px] font-bold shadow-lg backdrop-blur-md whitespace-nowrap animate-in fade-in zoom-in-95 pointer-events-none select-none" dir="rtl">
            🔥 موقد بنسن (انقر للتشغيل/الفحص)
          </div>
        </Html>
      )}

      {/* Heavy Base Plate */}
      <mesh position={[0, -0.4, 0]}>
        <cylinderGeometry args={[0.35, 0.38, 0.08, 32]} />
        <meshStandardMaterial color="#334155" metalness={0.8} roughness={0.3} />
      </mesh>

      {/* Brass Air Collar */}
      <mesh position={[0, -0.28, 0]}>
        <cylinderGeometry args={[0.1, 0.1, 0.14, 24]} />
        <meshStandardMaterial color="#d97706" metalness={0.9} roughness={0.2} />
      </mesh>

      {/* Metal Chimney Tube */}
      <mesh position={[0, 0.05, 0]}>
        <cylinderGeometry args={[0.08, 0.08, 0.55, 32]} />
        <meshStandardMaterial color="#94a3b8" metalness={0.85} roughness={0.2} />
      </mesh>

      {/* Burner Flame */}
      {isFlameActive && (
        <>
          <pointLight ref={flameLightRef} position={[0, 0.48, 0]} color="#38bdf8" distance={4} intensity={2.8} />
          {/* Inner hot blue cone */}
          <mesh ref={flameMeshRef} position={[0, 0.42, 0]}>
            <coneGeometry args={[0.07, 0.28, 16]} />
            <meshBasicMaterial color="#38bdf8" transparent opacity={0.9} />
          </mesh>
          {/* Outer orange flame halo */}
          <mesh position={[0, 0.48, 0]}>
            <coneGeometry args={[0.12, 0.42, 16]} />
            <meshBasicMaterial color="#fb923c" transparent opacity={0.65} />
          </mesh>
          <Sparkles position={[0, 0.5, 0]} count={12} scale={[0.3, 0.5, 0.3]} size={3} speed={2} color="#f59e0b" />
        </>
      )}
    </group>
  );
};

// ----------------------------------------------------------------------
// 3D Harmonic Pendulum Model
// ----------------------------------------------------------------------
const Pendulum3D: React.FC<{
  isSelected: boolean;
  isHovered: boolean;
  isOscillating: boolean;
  onClick: () => void;
  onPointerOver: () => void;
  onPointerOut: () => void;
}> = ({ isSelected, isHovered, isOscillating, onClick, onPointerOver, onPointerOut }) => {
  const armRef = useRef<THREE.Group>(null);

  useFrame((state) => {
    if (armRef.current && isOscillating) {
      const t = state.clock.getElapsedTime();
      const angle = 0.55 * Math.sin(t * 3.5);
      armRef.current.rotation.z = angle;
    }
  });

  return (
    <group
      position={[0.8, 0.5, 0.3]}
      onClick={(e) => {
        e.stopPropagation();
        onClick();
      }}
      onPointerOver={(e) => {
        e.stopPropagation();
        onPointerOver();
      }}
      onPointerOut={onPointerOut}
    >
      {(isSelected || isHovered) && (
        <mesh position={[0, -0.48, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <ringGeometry args={[0.45, 0.58, 32]} />
          <meshBasicMaterial
            color={isSelected ? '#10b981' : '#6ee7b7'}
            transparent
            opacity={isSelected ? 0.9 : 0.5}
            side={THREE.DoubleSide}
          />
        </mesh>
      )}

      {(isSelected || isHovered) && (
        <Html position={[0, 0.85, 0]} center distanceFactor={10} pointerEvents="none">
          <div className="bg-slate-900/90 text-emerald-300 border border-emerald-500/50 px-2.5 py-1 rounded-xl text-[11px] font-bold shadow-lg backdrop-blur-md whitespace-nowrap animate-in fade-in zoom-in-95 pointer-events-none select-none" dir="rtl">
            ⚙️ جهاز البندول الميكانيكي (انقر للتحكم)
          </div>
        </Html>
      )}

      {/* Support Stand Base */}
      <mesh position={[0, -0.45, 0]}>
        <boxGeometry args={[0.5, 0.06, 0.35]} />
        <meshStandardMaterial color="#1e293b" roughness={0.3} metalness={0.7} />
      </mesh>

      {/* Support Vertical Rod */}
      <mesh position={[0.2, 0.05, 0]}>
        <cylinderGeometry args={[0.025, 0.025, 1.0, 16]} />
        <meshStandardMaterial color="#cbd5e1" roughness={0.15} metalness={0.9} />
      </mesh>

      {/* Horizontal Top Arm */}
      <mesh position={[0.05, 0.55, 0]} rotation={[0, 0, Math.PI / 2]}>
        <cylinderGeometry args={[0.025, 0.025, 0.35, 16]} />
        <meshStandardMaterial color="#cbd5e1" roughness={0.15} metalness={0.9} />
      </mesh>

      {/* Pivot Pivot Mount */}
      <mesh position={[-0.1, 0.55, 0]}>
        <sphereGeometry args={[0.04, 16, 16]} />
        <meshStandardMaterial color="#0f766e" metalness={0.8} roughness={0.2} />
      </mesh>

      {/* Swinging Arm Group */}
      <group ref={armRef} position={[-0.1, 0.55, 0]}>
        {/* Cord Wire */}
        <mesh position={[0, -0.38, 0]}>
          <cylinderGeometry args={[0.005, 0.005, 0.75, 8]} />
          <meshStandardMaterial color="#94a3b8" />
        </mesh>
        {/* Metallic Bob Sphere */}
        <mesh position={[0, -0.78, 0]}>
          <sphereGeometry args={[0.11, 32, 32]} />
          <meshStandardMaterial
            color="#10b981"
            emissive="#047857"
            emissiveIntensity={0.2}
            metalness={0.9}
            roughness={0.15}
          />
        </mesh>
      </group>
    </group>
  );
};

// ----------------------------------------------------------------------
// 3D DNA Helix Molecular Model
// ----------------------------------------------------------------------
const DnaHelix3D: React.FC<{
  isSelected: boolean;
  isHovered: boolean;
  onClick: () => void;
  onPointerOver: () => void;
  onPointerOut: () => void;
}> = ({ isSelected, isHovered, onClick, onPointerOver, onPointerOut }) => {
  const helixGroupRef = useRef<THREE.Group>(null);

  useFrame((state) => {
    if (helixGroupRef.current) {
      helixGroupRef.current.rotation.y = state.clock.getElapsedTime() * 0.9;
    }
  });

  const basePairs = useMemo(() => {
    const pairs = [];
    const count = 14;
    const height = 0.9;
    for (let i = 0; i < count; i++) {
      const t = (i / count) - 0.5;
      const y = t * height;
      const angle = i * 0.55;
      const r = 0.22;
      const x1 = Math.cos(angle) * r;
      const z1 = Math.sin(angle) * r;
      const x2 = -x1;
      const z2 = -z1;
      const color1 = i % 2 === 0 ? '#ec4899' : '#06b6d4'; // Adenine / Thymine
      const color2 = i % 2 === 0 ? '#a855f7' : '#10b981'; // Guanine / Cytosine
      pairs.push({ id: i, y, x1, z1, x2, z2, color1, color2, angle });
    }
    return pairs;
  }, []);

  return (
    <group
      position={[2.3, 0.6, -0.2]}
      onClick={(e) => {
        e.stopPropagation();
        onClick();
      }}
      onPointerOver={(e) => {
        e.stopPropagation();
        onPointerOver();
      }}
      onPointerOut={onPointerOut}
    >
      {(isSelected || isHovered) && (
        <mesh position={[0, -0.58, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <ringGeometry args={[0.45, 0.58, 32]} />
          <meshBasicMaterial
            color={isSelected ? '#ec4899' : '#f472b6'}
            transparent
            opacity={isSelected ? 0.9 : 0.5}
            side={THREE.DoubleSide}
          />
        </mesh>
      )}

      {(isSelected || isHovered) && (
        <Html position={[0, 0.85, 0]} center distanceFactor={10} pointerEvents="none">
          <div className="bg-slate-900/90 text-pink-300 border border-pink-500/50 px-2.5 py-1 rounded-xl text-[11px] font-bold shadow-lg backdrop-blur-md whitespace-nowrap animate-in fade-in zoom-in-95 pointer-events-none select-none" dir="rtl">
            🧬 لولب DNA الجزيئي (انقر للفحص)
          </div>
        </Html>
      )}

      {/* High-tech Pedestal Stand */}
      <mesh position={[0, -0.5, 0]}>
        <cylinderGeometry args={[0.3, 0.35, 0.08, 32]} />
        <meshStandardMaterial color="#0f172a" metalness={0.9} roughness={0.2} />
      </mesh>
      <mesh position={[0, -0.45, 0]}>
        <torusGeometry args={[0.26, 0.015, 16, 32]} />
        <meshStandardMaterial color="#ec4899" emissive="#ec4899" emissiveIntensity={0.8} />
      </mesh>

      {/* Rotating DNA Strands */}
      <group ref={helixGroupRef} position={[0, 0.05, 0]}>
        {basePairs.map((bp) => (
          <group key={bp.id} position={[0, bp.y, 0]}>
            {/* Horizontal Hydrogen Bond Rung */}
            <mesh rotation={[0, bp.angle, 0]}>
              <cylinderGeometry args={[0.012, 0.012, 0.44, 8]} />
              <meshStandardMaterial color="#e2e8f0" metalness={0.5} roughness={0.3} />
            </mesh>
            {/* Strand 1 Nucleotide Sphere */}
            <mesh position={[bp.x1, 0, bp.z1]}>
              <sphereGeometry args={[0.045, 16, 16]} />
              <meshStandardMaterial
                color={bp.color1}
                emissive={bp.color1}
                emissiveIntensity={0.4}
                roughness={0.2}
              />
            </mesh>
            {/* Strand 2 Nucleotide Sphere */}
            <mesh position={[bp.x2, 0, bp.z2]}>
              <sphereGeometry args={[0.045, 16, 16]} />
              <meshStandardMaterial
                color={bp.color2}
                emissive={bp.color2}
                emissiveIntensity={0.4}
                roughness={0.2}
              />
            </mesh>
          </group>
        ))}
      </group>

      <Sparkles count={20} scale={[0.8, 1.2, 0.8]} size={2} speed={1.2} color="#f472b6" />
    </group>
  );
};

// ----------------------------------------------------------------------
// 3D Laboratory Workbench Scene
// ----------------------------------------------------------------------
const LaboratoryWorkbenchScene: React.FC<{
  selectedToolId: string | null;
  onSelectTool: (id: string | null) => void;
  isFlameActive: boolean;
  isPendulumActive: boolean;
  chemicalLiquidColor: string;
}> = ({
  selectedToolId,
  onSelectTool,
  isFlameActive,
  isPendulumActive,
  chemicalLiquidColor
}) => {
  const [hoveredToolId, setHoveredToolId] = useState<string | null>(null);

  return (
    <>
      {/* Dynamic Studio Lighting */}
      <ambientLight intensity={0.7} />
      <directionalLight
        position={[4, 6, 4]}
        intensity={1.4}
        castShadow
        shadow-mapSize={[1024, 1024]}
        shadow-camera-near={0.5}
        shadow-camera-far={20}
      />
      <directionalLight position={[-4, 4, -3]} intensity={0.6} color="#38bdf8" />
      <pointLight position={[0, 3, 0]} intensity={0.5} color="#ec4899" />

      {/* Main Laboratory Workbench Table Surface */}
      <group position={[0, -0.05, 0]}>
        {/* Table Slab (Granite/Polymer Top) - Clicking deselects */}
        <mesh 
          position={[0, 0, 0]} 
          receiveShadow
          onClick={(e) => {
            e.stopPropagation();
            onSelectTool(null);
          }}
        >
          <boxGeometry args={[7.2, 0.16, 3.2]} />
          <meshStandardMaterial
            color="#0f172a"
            roughness={0.25}
            metalness={0.4}
            envMapIntensity={0.8}
          />
        </mesh>

        {/* Shiny Edge Trim */}
        <mesh position={[0, 0, 1.62]}>
          <boxGeometry args={[7.24, 0.18, 0.04]} />
          <meshStandardMaterial color="#0f766e" metalness={0.8} roughness={0.2} />
        </mesh>

        {/* Realistic Contact Shadow on table */}
        <ContactShadows
          position={[0, 0.09, 0]}
          opacity={0.65}
          scale={7}
          blur={1.5}
          far={1.8}
        />
      </group>

      {/* Interactive 3D Instruments */}
      <ErlenmeyerFlask
        isSelected={selectedToolId === 'erlenmeyer'}
        isHovered={hoveredToolId === 'erlenmeyer'}
        liquidColor={chemicalLiquidColor}
        onClick={() => onSelectTool('erlenmeyer')}
        onPointerOver={() => setHoveredToolId('erlenmeyer')}
        onPointerOut={() => setHoveredToolId(null)}
      />

      <BunsenBurner
        isSelected={selectedToolId === 'bunsen'}
        isHovered={hoveredToolId === 'bunsen'}
        isFlameActive={isFlameActive}
        onClick={() => onSelectTool('bunsen')}
        onPointerOver={() => setHoveredToolId('bunsen')}
        onPointerOut={() => setHoveredToolId(null)}
      />

      <Pendulum3D
        isSelected={selectedToolId === 'pendulum_3d'}
        isHovered={hoveredToolId === 'pendulum_3d'}
        isOscillating={isPendulumActive}
        onClick={() => onSelectTool('pendulum_3d')}
        onPointerOver={() => setHoveredToolId('pendulum_3d')}
        onPointerOut={() => setHoveredToolId(null)}
      />

      <DnaHelix3D
        isSelected={selectedToolId === 'dna_helix'}
        isHovered={hoveredToolId === 'dna_helix'}
        onClick={() => onSelectTool('dna_helix')}
        onPointerOver={() => setHoveredToolId('dna_helix')}
        onPointerOut={() => setHoveredToolId(null)}
      />

      {/* Modern Background Grid Accent */}
      <gridHelper
        args={[10, 20, '#0f766e', '#1e293b']}
        position={[0, -0.15, 0]}
      />

      <OrbitControls
        makeDefault
        minPolarAngle={Math.PI / 6}
        maxPolarAngle={Math.PI / 2.1}
        minDistance={2.5}
        maxDistance={8}
        enablePan={true}
        enableZoom={true}
      />
    </>
  );
};

// ----------------------------------------------------------------------
// Main Exported Component: InteractiveLab3DCanvas
// ----------------------------------------------------------------------
interface InteractiveLab3DCanvasProps {
  onInspectTool?: (tool: Interactive3DTool) => void;
  onAskAiAboutTool?: (context: string) => void;
}

export const InteractiveLab3DCanvas: React.FC<InteractiveLab3DCanvasProps> = ({
  onInspectTool,
  onAskAiAboutTool
}) => {
  const [selectedToolId, setSelectedToolId] = useState<string | null>(null);
  const [isPanelMinimized, setIsPanelMinimized] = useState<boolean>(false);
  const [isFlameActive, setIsFlameActive] = useState<boolean>(true);
  const [flameTemp, setFlameTemp] = useState<number>(1200);
  const [isPendulumActive, setIsPendulumActive] = useState<boolean>(true);
  const [liquidIndex, setLiquidIndex] = useState<number>(0);
  const [titrationDrops, setTitrationDrops] = useState<number>(0);
  const [dnaSpeed, setDnaSpeed] = useState<number>(1.0);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);

  const liquidColors = [
    { color: '#06b6d4', name: 'حمض الهيدروكلوريك HCl', ph: '1.2' },
    { color: '#ec4899', name: 'فينولفثالين في وسط قاعدي', ph: '9.8' },
    { color: '#3b82f6', name: 'محلول كبريتات النحاس CuSO₄', ph: '4.5' },
    { color: '#8b5cf6', name: 'برمنغنات البوتاسيوم KMnO₄', ph: '7.0' },
    { color: '#10b981', name: 'كاشف عام متعادل', ph: '7.0' }
  ];
  const currentLiquid = liquidColors[liquidIndex];

  const selectedTool = useMemo(() => {
    if (!selectedToolId) return null;
    return LAB_3D_TOOLS.find((t) => t.id === selectedToolId) || null;
  }, [selectedToolId]);

  const handleSelectTool = (id: string | null) => {
    if (id === null || id === selectedToolId) {
      setSelectedToolId(null);
      return;
    }
    setSelectedToolId(id);
    setIsPanelMinimized(false);
    const tool = LAB_3D_TOOLS.find((t) => t.id === id);
    if (tool && onInspectTool) {
      onInspectTool(tool);
    }
  };

  const handleDeselectTool = () => {
    setSelectedToolId(null);
  };

  const handleCycleLiquid = () => {
    setLiquidIndex((prev) => (prev + 1) % liquidColors.length);
  };

  const handleAddTitrationDrop = () => {
    setTitrationDrops((prev) => prev + 1);
  };

  const handleAskAboutSelectedTool = () => {
    if (!onAskAiAboutTool || !selectedTool) return;
    const prompt = `أنا أتفحص أداة «${selectedTool.nameAr}» (${selectedTool.nameEn}) في المختبر ثلاثي الأبعاد 3D.
القانون العلمي المرتبط: ${selectedTool.scientificLaw || 'غير محدد'}
الصيغة الكيميائية: ${selectedTool.chemicalFormula || 'غير محدد'}
الوصف: ${selectedTool.descriptionAr}

اشرح لي كيف تعمل هذه الأداة في المختبر الحقيقي، وما هي احتياطات السلامة المعملية والتجارب الأكاديمية التي تُستخدم فيها بالتفصيل؟`;
    onAskAiAboutTool(prompt);
  };

  return (
    <div
      className={`relative w-full rounded-3xl overflow-hidden border border-slate-200/90 dark:border-[#223930] bg-gradient-to-b from-[#09110f] via-[#0d1a16] to-[#080d0c] shadow-xl transition-all duration-300 ${
        isFullscreen ? 'fixed inset-4 z-50 h-[calc(100vh-2rem)]' : 'h-[460px] sm:h-[520px]'
      }`}
      dir="rtl"
    >
      {/* 3D Canvas Area */}
      <Canvas
        shadows
        dpr={[1, 1.5]}
        camera={{ position: [0, 2.5, 4.5], fov: 45 }}
        gl={{ antialias: true, powerPreference: 'high-performance' }}
        className="w-full h-full cursor-grab active:cursor-grabbing block"
      >
        <Environment preset="studio" environmentIntensity={0.65} />
        <LaboratoryWorkbenchScene
          selectedToolId={selectedToolId}
          onSelectTool={handleSelectTool}
          isFlameActive={isFlameActive}
          isPendulumActive={isPendulumActive}
          chemicalLiquidColor={currentLiquid.color}
        />
      </Canvas>

      {/* Top Floating Glass Bar: Lab Mode Indicator & Controls */}
      <div className="absolute top-3.5 inset-x-3.5 flex items-center justify-between pointer-events-none z-10">
        <div className="flex items-center gap-2 pointer-events-auto">
          <div className="px-3 py-1.5 rounded-2xl bg-black/60 backdrop-blur-md border border-white/15 text-white flex items-center gap-2 shadow-lg">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
            <span className="text-xs font-black tracking-wide">
              مختبر 3D الواقعي التفاعلي (WebGL)
            </span>
          </div>

          <div className="hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-2xl bg-black/50 backdrop-blur-md border border-white/10 text-slate-300 text-[11px]">
            <Eye className="w-3.5 h-3.5 text-teal-400" />
            <span>حرّك بالفأرة للتدوير • انقر على أي أداة لاختيارها</span>
          </div>
        </div>

        {/* Quick Top Actions */}
        <div className="flex items-center gap-1.5 pointer-events-auto">
          {selectedTool && (
            <button
              type="button"
              onClick={handleDeselectTool}
              className="px-3 py-1.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-white backdrop-blur-md border border-white/15 text-xs font-bold transition-all shadow-md cursor-pointer flex items-center gap-1"
              title="إلغاء التحديد وإخفاء اللوحة العائمة"
            >
              <X className="w-3.5 h-3.5 text-rose-400" />
              <span>إغلاق التحديد</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="p-2 rounded-xl bg-black/60 hover:bg-black/80 text-white backdrop-blur-md border border-white/15 transition-all shadow-md cursor-pointer"
            title={isFullscreen ? 'تصغير' : 'ملء الشاشة'}
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Dynamic Context-Aware Floating Control Panel (Appears ONLY when a tool is selected) */}
      {selectedTool ? (
        <div className="absolute top-14 left-3.5 max-w-sm sm:max-w-md w-full p-4 rounded-3xl bg-slate-900/90 backdrop-blur-xl border border-slate-700/80 text-white shadow-2xl z-20 space-y-3 pointer-events-auto transition-all duration-300 animate-in fade-in slide-in-from-top-3">
          {/* Panel Header */}
          <div className="flex items-center justify-between pb-2.5 border-b border-slate-800">
            <div className="flex items-center gap-2.5">
              <span
                className="w-3.5 h-3.5 rounded-full shrink-0 shadow-md ring-2 ring-white/20"
                style={{ backgroundColor: selectedTool.color }}
              />
              <div>
                <h5 className="text-xs sm:text-sm font-black text-slate-100 flex items-center gap-1.5">
                  <span>{selectedTool.nameAr}</span>
                </h5>
                <span className="text-[10px] text-teal-400 font-mono block" dir="ltr">
                  {selectedTool.nameEn}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => setIsPanelMinimized(!isPanelMinimized)}
                className="p-1.5 rounded-xl hover:bg-slate-800 text-slate-400 hover:text-white transition cursor-pointer"
                title={isPanelMinimized ? 'توسيع اللوحة' : 'تصغير اللوحة'}
              >
                {isPanelMinimized ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
              </button>
              <button
                type="button"
                onClick={handleDeselectTool}
                className="p-1.5 rounded-xl hover:bg-rose-950/60 text-slate-400 hover:text-rose-400 transition cursor-pointer"
                title="إخفاء لوحة التحكم"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {!isPanelMinimized && (
            <>
              {/* Description */}
              <p className="text-xs text-slate-300 leading-relaxed">
                {selectedTool.descriptionAr}
              </p>

              {/* Dynamic Instrument-Specific Controls */}
              <div className="p-3 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-2.5 text-xs">
                <div className="flex items-center justify-between text-slate-400 text-[11px] font-bold border-b border-slate-800/80 pb-1">
                  <span className="flex items-center gap-1">
                    <Sliders className="w-3 h-3 text-teal-400" />
                    <span>عناصر التحكم الحية بالأداة:</span>
                  </span>
                  <span className="text-teal-400">سياق نشط</span>
                </div>

                {/* A. Erlenmeyer Specific Controls */}
                {selectedTool.id === 'erlenmeyer' && (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-300">المحلول الحالي:</span>
                      <span className="font-bold text-cyan-300 truncate max-w-[170px]">{currentLiquid.name}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-300">الرقم الهيدروجيني (pH):</span>
                      <span className="font-mono font-bold px-2 py-0.5 rounded bg-slate-800 text-teal-300">{currentLiquid.ph}</span>
                    </div>
                    <div className="flex items-center gap-2 pt-1">
                      <button
                        type="button"
                        onClick={handleCycleLiquid}
                        className="flex-1 py-1.5 px-3 rounded-xl bg-cyan-600 hover:bg-cyan-700 text-white font-bold transition flex items-center justify-center gap-1 cursor-pointer"
                      >
                        <FlaskConical className="w-3.5 h-3.5" />
                        <span>تغيير المحلول ({liquidIndex + 1}/5)</span>
                      </button>
                      <button
                        type="button"
                        onClick={handleAddTitrationDrop}
                        className="py-1.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold transition flex items-center gap-1 cursor-pointer"
                        title="إضافة قطرة معايرة"
                      >
                        <span>+ قطرة ({titrationDrops})</span>
                      </button>
                    </div>
                  </div>
                )}

                {/* B. Bunsen Burner Specific Controls */}
                {selectedTool.id === 'bunsen' && (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-300">حالة اللهب:</span>
                      <span className={`font-bold ${isFlameActive ? 'text-amber-400' : 'text-slate-500'}`}>
                        {isFlameActive ? 'مشتعل (لهب أزرق مؤكسد)' : 'مطفأ'}
                      </span>
                    </div>
                    <div>
                      <div className="flex justify-between text-[11px] mb-1">
                        <span className="text-slate-400">درجة حرارة اللهب:</span>
                        <span className="font-mono font-bold text-amber-300">{flameTemp}°C</span>
                      </div>
                      <input
                        type="range"
                        min="300"
                        max="1500"
                        step="50"
                        value={flameTemp}
                        disabled={!isFlameActive}
                        onChange={(e) => setFlameTemp(Number(e.target.value))}
                        className="w-full accent-amber-500 cursor-pointer"
                      />
                    </div>
                    <button
                      type="button"
                      onClick={() => setIsFlameActive(!isFlameActive)}
                      className={`w-full py-1.5 px-3 rounded-xl font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                        isFlameActive ? 'bg-rose-700 hover:bg-rose-800 text-white' : 'bg-amber-600 hover:bg-amber-700 text-white'
                      }`}
                    >
                      <Flame className="w-3.5 h-3.5" />
                      <span>{isFlameActive ? 'إطفاء موقد بنسن' : 'إشعال اللهب 1500°C'}</span>
                    </button>
                  </div>
                )}

                {/* C. Pendulum Specific Controls */}
                {selectedTool.id === 'pendulum_3d' && (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-300">حالة الحركة:</span>
                      <span className={`font-bold ${isPendulumActive ? 'text-emerald-400' : 'text-slate-500'}`}>
                        {isPendulumActive ? 'حركة توافقية مستمرة' : 'متوقف'}
                      </span>
                    </div>
                    <div className="flex items-center justify-between font-mono text-[11px] bg-slate-900 p-1.5 rounded-lg border border-slate-800">
                      <span className="text-slate-400">الزمن الدوري T:</span>
                      <span className="text-emerald-300 font-bold">2.01 s (الأرض)</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setIsPendulumActive(!isPendulumActive)}
                      className={`w-full py-1.5 px-3 rounded-xl font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                        isPendulumActive ? 'bg-slate-800 hover:bg-slate-700 text-slate-200' : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                      }`}
                    >
                      {isPendulumActive ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                      <span>{isPendulumActive ? 'إيقاف الاهتزاز مؤقتاً' : 'استئناف الاهتزاز'}</span>
                    </button>
                  </div>
                )}

                {/* D. DNA Helix Specific Controls */}
                {selectedTool.id === 'dna_helix' && (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-300">سرعة الدوران:</span>
                      <span className="font-mono font-bold text-pink-400">{dnaSpeed.toFixed(1)}x</span>
                    </div>
                    <input
                      type="range"
                      min="0.2"
                      max="3.0"
                      step="0.2"
                      value={dnaSpeed}
                      onChange={(e) => setDnaSpeed(Number(e.target.value))}
                      className="w-full accent-pink-500 cursor-pointer"
                    />
                    <div className="text-[10px] text-slate-400 bg-slate-900 p-1.5 rounded-lg">
                      قاعدة تشارجاف: الأدينين يربط بالثايمين (A=T)، والجوانين بالسيتوسين (G≡C).
                    </div>
                  </div>
                )}
              </div>

              {/* Scientific Law / Math Formula */}
              {selectedTool.scientificLaw && (
                <div className="p-2.5 rounded-xl bg-slate-950/80 border border-teal-500/30 text-xs">
                  <span className="text-[10px] text-teal-300 font-bold block mb-1">
                    القانون العلمي المرتبط:
                  </span>
                  <div className="font-mono text-teal-200 text-xs" dir="ltr">
                    <SafeInlineMath math={selectedTool.scientificLaw} />
                  </div>
                </div>
              )}

              {/* Chemical Formula */}
              {selectedTool.chemicalFormula && (
                <div className="p-2.5 rounded-xl bg-slate-950/80 border border-cyan-500/30 text-xs">
                  <span className="text-[10px] text-cyan-300 font-bold block mb-1">
                    معادلة التفاعل الكيميائي:
                  </span>
                  <div className="font-mono text-cyan-200 text-xs" dir="ltr">
                    <SafeInlineMath math={selectedTool.chemicalFormula} />
                  </div>
                </div>
              )}

              {/* AI Discussion Action */}
              <button
                type="button"
                onClick={handleAskAboutSelectedTool}
                className="w-full py-2 px-3 rounded-xl bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-600 hover:to-emerald-600 text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-md transition cursor-pointer"
              >
                <SparklesIcon className="w-3.5 h-3.5 text-amber-200" />
                <span>ناقش وحلل هذه الأداة مع المعلم الذكي</span>
              </button>
            </>
          )}
        </div>
      ) : (
        /* Floating Guidance Pill When Nothing is Selected */
        <div className="absolute top-14 left-3.5 pointer-events-auto">
          <div className="px-3.5 py-2 rounded-2xl bg-slate-900/80 backdrop-blur-md border border-teal-500/40 text-teal-200 text-xs shadow-xl flex items-center gap-2 animate-pulse">
            <SparklesIcon className="w-4 h-4 text-teal-400" />
            <span>انقر على أي أداة في المشهد لإظهار لوحة التحكم التفاعلية</span>
          </div>
        </div>
      )}

      {/* Floating Smart Tool Selector (Bottom Left/Center) */}
      <div className="absolute bottom-3.5 inset-x-3.5 flex flex-col md:flex-row items-stretch md:items-end justify-between gap-3 pointer-events-none z-10">
        {/* Tool Switching Pills */}
        <div className="flex flex-wrap items-center gap-1.5 p-1.5 rounded-2xl bg-slate-900/85 backdrop-blur-md border border-white/15 shadow-2xl pointer-events-auto max-w-xl">
          {LAB_3D_TOOLS.map((tool) => {
            const isActive = tool.id === selectedToolId;
            return (
              <button
                key={tool.id}
                type="button"
                onClick={() => handleSelectTool(tool.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                  isActive
                    ? 'bg-teal-600 text-white shadow-md shadow-teal-600/30 font-black scale-105'
                    : 'text-slate-300 hover:text-white hover:bg-white/10'
                }`}
              >
                <span
                  className="w-2 h-2 rounded-full shrink-0"
                  style={{ backgroundColor: tool.color }}
                />
                <span>{tool.nameAr}</span>
              </button>
            );
          })}

          {selectedToolId && (
            <button
              type="button"
              onClick={handleDeselectTool}
              className="px-2.5 py-1.5 rounded-xl text-xs font-bold text-rose-300 hover:bg-rose-950/60 transition cursor-pointer flex items-center gap-1"
              title="إلغاء التحديد وإخفاء اللوحة"
            >
              <X className="w-3.5 h-3.5" />
              <span>إخفاء</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
