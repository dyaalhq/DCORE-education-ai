import React, { useState } from 'react';
import { 
  X, 
  Search, 
  Globe, 
  Loader2, 
  Plus, 
  ExternalLink, 
  BookOpen, 
  Check, 
  AlertCircle,
  Hash,
  Sparkles
} from 'lucide-react';
import { searchWikipedia, fetchWikipediaArticle, WikipediaSearchResult } from '../lib/wikipediaService';
import { Source, SourceChunk } from '../types';

interface WikipediaSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddSource: (source: Source, chunks: SourceChunk[]) => void;
  notebookId: string;
  notebookName?: string;
}

export const WikipediaSearchModal: React.FC<WikipediaSearchModalProps> = ({
  isOpen,
  onClose,
  onAddSource,
  notebookId,
  notebookName,
}) => {
  const [query, setQuery] = useState('');
  const [language, setLanguage] = useState<'ar' | 'en'>('ar');
  const [isLoading, setIsLoading] = useState(false);
  const [results, setResults] = useState<WikipediaSearchResult[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [importingTitle, setImportingTitle] = useState<string | null>(null);
  const [importedTitles, setImportedTitles] = useState<Set<string>>(new Set());

  if (!isOpen) return null;

  const handleSearch = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!query.trim()) return;

    setIsLoading(true);
    setError(null);
    try {
      const searchRes = await searchWikipedia(query, language, 10);
      setResults(searchRes);
      if (searchRes.length === 0) {
        setError('لم يتم العثور على مقالات تطابق بحثك في ويكيبيديا. جرب كلمات بحث أخرى.');
      }
    } catch (err: any) {
      setError('تعذر الاتصال بخدمة ويكيبيديا. تأكد من اتصال الإنترنت وحاول مجدداً.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleImport = async (item: WikipediaSearchResult) => {
    setImportingTitle(item.title);
    setError(null);
    try {
      const details = await fetchWikipediaArticle(item.title, language);
      const sourceId = `wiki_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      
      const newSource: Source = {
        id: sourceId,
        notebookId,
        title: `${details.title} (ويكيبيديا)`,
        uri: details.canonicalurl,
        type: 'wikipedia',
        size: details.extract.length,
        status: 'Ready',
        content: details.extract,
        wordCount: details.wordCount,
        headings: details.headings,
        createdAt: Date.now(),
        updatedAt: Date.now(),
        favorite: false,
      };

      // Generate structural chunks for RAG vector search
      const paragraphs = details.extract.split('\n\n').filter(Boolean);
      const chunks: SourceChunk[] = [];
      let currentSection = 'المقدمة';

      paragraphs.forEach((p, idx) => {
        const trimmed = p.trim();
        if (trimmed.startsWith('##')) {
          currentSection = trimmed.replace(/^#+\s*/, '');
          return;
        }

        chunks.push({
          id: `chunk_${sourceId}_${idx}`,
          sourceId,
          sourceTitle: newSource.title,
          notebookId,
          text: trimmed,
          section: currentSection,
          pageNumber: 1,
          metadata: {
            sectionTitle: currentSection,
            charLength: trimmed.length,
            keywords: [details.title, ...details.headings.slice(0, 5)],
          },
        });
      });

      // If chunks empty, add full text as fallback chunk
      if (chunks.length === 0) {
        chunks.push({
          id: `chunk_${sourceId}_0`,
          sourceId,
          sourceTitle: newSource.title,
          notebookId,
          text: details.extract.slice(0, 1500),
          section: 'المقال كاملاً',
          pageNumber: 1,
        });
      }

      onAddSource(newSource, chunks);
      setImportedTitles((prev) => new Set([...prev, item.title]));
    } catch (err: any) {
      setError(err?.message || 'فشل استيراد المقال من ويكيبيديا.');
    } finally {
      setImportingTitle(null);
    }
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200"
      dir="rtl"
    >
      <div 
        className="relative w-full max-w-3xl bg-white dark:bg-[#14201c] rounded-3xl shadow-2xl border border-teal-100 dark:border-teal-900/50 overflow-hidden flex flex-col max-h-[88vh] animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-100 dark:border-[#22352f] bg-slate-50/70 dark:bg-[#182622]/70">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-teal-600/10 text-teal-700 dark:text-teal-300 flex items-center justify-center">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-black text-slate-900 dark:text-slate-100">
                  محرك البحث الموسوعي ويكيبيديا
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-teal-100 dark:bg-teal-950 text-teal-800 dark:text-teal-200 flex items-center gap-1">
                  <Sparkles className="w-3 h-3" />
                  Wikipedia API
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                ابحث واستورد مقالات موسوعية دقيقة ومحدثة مباشرة كمرجع مستقل في دفترك «{notebookName || 'الحالي'}»
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search Bar & Language Selector */}
        <div className="p-5 border-b border-slate-100 dark:border-[#22352f] bg-white dark:bg-[#14201c]">
          <form onSubmit={handleSearch} className="flex flex-col sm:flex-row gap-2.5">
            <div className="relative flex-1">
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="ابحث عن أي مفهوم علمي، شخصية، نظرية، أو حدث تاريخي..."
                className="w-full pl-10 pr-4 py-2.5 rounded-2xl border border-slate-200 dark:border-[#22352f] bg-slate-50 dark:bg-[#182622] text-sm focus:outline-none focus:ring-2 focus:ring-teal-600 dark:text-slate-100 text-right"
                autoFocus
              />
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
            </div>

            {/* Language Toggle */}
            <div className="flex items-center rounded-2xl p-1 bg-slate-100 dark:bg-[#182622] border border-slate-200 dark:border-[#22352f] shrink-0">
              <button
                type="button"
                onClick={() => setLanguage('ar')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                  language === 'ar'
                    ? 'bg-teal-600 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-300 hover:text-teal-600'
                }`}
              >
                العربية (ar)
              </button>
              <button
                type="button"
                onClick={() => setLanguage('en')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                  language === 'en'
                    ? 'bg-teal-600 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-300 hover:text-teal-600'
                }`}
              >
                English (en)
              </button>
            </div>

            {/* Search Button */}
            <button
              type="submit"
              disabled={isLoading || !query.trim()}
              className="px-5 py-2.5 rounded-2xl font-bold text-xs bg-teal-600 hover:bg-teal-700 text-white disabled:opacity-50 transition flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-teal-700/15"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>جارٍ البحث...</span>
                </>
              ) : (
                <>
                  <Search className="w-4 h-4" />
                  <span>بحث</span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* Results List */}
        <div className="p-5 overflow-y-auto flex-1 space-y-3">
          {error && (
            <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-800 dark:text-amber-200 text-xs flex items-center gap-2.5">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {results.length === 0 && !isLoading && !error && (
            <div className="py-12 text-center text-slate-400">
              <Globe className="w-12 h-12 mx-auto stroke-1 opacity-40 mb-3" />
              <p className="text-sm font-bold">ابدأ بكتابة الكلمات المفتاحية للبحث في أرشيف ويكيبيديا المليء بالمعلومات</p>
              <p className="text-xs text-slate-400 mt-1">مثل: «النسبية العامة»، «الخلية النباتية»، «ابن سينا»، «الذكاء الاصطناعي»</p>
            </div>
          )}

          {results.map((item) => {
            const isImported = importedTitles.has(item.title);
            const isImporting = importingTitle === item.title;

            return (
              <div
                key={item.pageid}
                className="p-4 rounded-2xl bg-slate-50 dark:bg-[#182622] border border-slate-200/80 dark:border-[#22352f] hover:border-teal-500/40 transition flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
              >
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <h4 className="text-sm font-black text-slate-900 dark:text-slate-100 hover:text-teal-600 transition">
                      {item.title}
                    </h4>
                    <span className="text-[10px] text-slate-500 dark:text-slate-400 flex items-center gap-1">
                      <Hash className="w-3 h-3" />
                      {item.wordcount.toLocaleString('ar-EG')} كلمة
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 line-clamp-2 leading-relaxed">
                    {item.snippet}
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                  <a
                    href={`https://${language}.wikipedia.org/wiki/${encodeURIComponent(item.title)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 rounded-xl text-slate-400 hover:text-teal-600 hover:bg-white dark:hover:bg-[#14201c] transition"
                    title="فتح المقال في ويكيبيديا"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </a>

                  <button
                    type="button"
                    onClick={() => handleImport(item)}
                    disabled={isImported || isImporting}
                    className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                      isImported
                        ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300'
                        : 'bg-teal-600 hover:bg-teal-700 text-white shadow-xs'
                    }`}
                  >
                    {isImporting ? (
                      <>
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        <span>جارٍ الإضافة...</span>
                      </>
                    ) : isImported ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>تمت الإضافة كمرجع</span>
                      </>
                    ) : (
                      <>
                        <Plus className="w-3.5 h-3.5" />
                        <span>إضافة كمرجع في الدفتر</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 dark:border-[#22352f] bg-slate-50/70 dark:bg-[#182622]/70 flex items-center justify-between">
          <div className="text-[11px] text-slate-500 dark:text-slate-400">
            المقالات المستوردة يتم فهرستها تلقائياً بالمتجهات (Vectors) لتمكين الذكاء الاصطناعي من الإجابة عنها بدقة.
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-800 transition cursor-pointer"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
