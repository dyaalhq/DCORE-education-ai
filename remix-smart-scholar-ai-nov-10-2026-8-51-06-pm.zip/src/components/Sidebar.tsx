import React, { useState } from 'react';
import { 
  BookOpen, 
  MessageSquare, 
  FileText, 
  Sparkles, 
  Calculator, 
  Settings, 
  FolderPlus, 
  Check, 
  Moon, 
  Sun, 
  Download, 
  Copy, 
  Trash2, 
  X,
  Layers,
  Share2,
  Globe,
  GitFork,
  Mail,
  FlaskConical,
  User,
  FileQuestion,
  Award
} from 'lucide-react';
import { Notebook } from '../types';
import { AppLogo } from './AppLogo';
import { PWAInstallButton } from './PWAInstallButton';
import { t, getStoredLanguage } from '../lib/i18n';

interface SidebarProps {
  currentTab: string;
  onSelectTab: (tab: string) => void;
  notebooks: Notebook[];
  currentNotebook: Notebook;
  onSelectNotebook: (id: string) => void;
  onCreateNotebook: (name: string, subject: string, desc: string) => void;
  onDuplicateNotebook: (id: string) => void;
  onDeleteNotebook: (id: string) => void;
  onBackup: () => void;
  onOpenShareNotebook?: (notebookId?: string) => void;
  isOpen: boolean;
  onClose: () => void;
  isDark: boolean;
  onToggleTheme: () => void;
  sourceCount: number;
  onOpenSupportModal?: () => void;
  currentLang?: import('../lib/i18n').SupportedLanguage;
  notebookFlashcards?: any[];
  notebookNotesCount?: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onSelectTab,
  notebooks,
  currentNotebook,
  onSelectNotebook,
  onCreateNotebook,
  onDuplicateNotebook,
  onDeleteNotebook,
  onBackup,
  onOpenShareNotebook,
  isOpen,
  onClose,
  isDark,
  onToggleTheme,
  sourceCount,
  onOpenSupportModal,
  currentLang: propLang,
  notebookFlashcards = [],
  notebookNotesCount = 0,
}) => {
  const [showNbModal, setShowNbModal] = useState(false);
  const [showNbSwitcher, setShowNbSwitcher] = useState(false);
  const [newNbName, setNewNbName] = useState('');
  const [newNbSubject, setNewNbSubject] = useState('');
  const [newNbDesc, setNewNbDesc] = useState('');
  const currentLang = propLang || getStoredLanguage();

  // Learning Progress calculation for current notebook
  const totalCards = notebookFlashcards.length;
  const masteredCards = notebookFlashcards.filter(
    (f: any) => (f.repetitionLevel && f.repetitionLevel >= 2) || (f.intervalDays && f.intervalDays >= 3) || f.lastReviewStatus === 'easy'
  ).length;
  const cardMasteryRatio = totalCards > 0 ? masteredCards / totalCards : 0;
  const notesWeight = Math.min(1, notebookNotesCount / 4);
  const learningProgress = totalCards > 0
    ? Math.round((cardMasteryRatio * 0.7 + notesWeight * 0.3) * 100)
    : notebookNotesCount > 0
    ? Math.round(notesWeight * 60)
    : 0;

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNbName.trim()) return;
    onCreateNotebook(newNbName.trim(), newNbSubject.trim() || 'عام', newNbDesc.trim());
    setNewNbName('');
    setNewNbSubject('');
    setNewNbDesc('');
    setShowNbModal(false);
  };

  interface NavItem {
    id: string;
    label: string;
    icon: any;
    count?: number | null;
    highlight?: boolean;
    badge?: string;
  }

  interface NavSection {
    title: string;
    items: NavItem[];
  }

  const navSections: NavSection[] = [
    {
      title: t('nav.section.study', currentLang, 'المساحة الدراسية والأكاديمية'),
      items: [
        { id: 'question_bank', label: 'بنك الأسئلة الشامل', icon: FileQuestion, count: null, highlight: true, badge: 'وزاري + طبي + موسوعة' },
        { id: 'studio', label: t('nav.studio', currentLang, 'استوديو المذاكرة والبطاقات'), icon: Sparkles, count: null, badge: 'استوديو' },
      ],
    },
    {
      title: t('nav.section.studio', currentLang, 'المعامل والأدوات المتقدمة'),
      items: [
        { id: 'science', label: t('nav.science', currentLang, 'المختبر العلمي 3D'), icon: FlaskConical, count: null, badge: 'معمل تفاعلي' },
        { id: 'mindmap', label: t('nav.mindmap', currentLang, 'الخريطة الذهنية (2D/3D)'), icon: GitFork, count: null },
        { id: 'achievements', label: 'لوحة إنجازاتي', icon: Award, count: null, badge: 'D3 إحصائيات' },
        { id: 'tools', label: t('nav.tools', currentLang, 'مؤقت التركيز والحاسبة'), icon: Calculator, count: null },
        { id: 'export', label: t('nav.export', currentLang, 'مركز التصدير و PDF'), icon: Layers, count: null },
      ],
    },
  ];

  return (
    <>
      {/* Mobile backdrop */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 bg-black/40 z-40 lg:hidden backdrop-blur-sm transition-opacity"
        />
      )}

      <aside
        className={`fixed top-0 bottom-0 right-0 z-50 w-72 bg-white dark:bg-[#121b18] border-l border-[#e2e8e5] dark:border-[#22352f] flex flex-col transition-transform duration-300 ease-in-out lg:translate-x-0 ${
          isOpen ? 'translate-x-0 shadow-2xl' : 'translate-x-full'
        } lg:static lg:w-64 xl:w-72 lg:z-10`}
      >
        {/* Brand header */}
        <div className="p-4 border-b border-[#e2e8e5] dark:border-[#22352f] flex items-center justify-between">
          <AppLogo size="md" showText={true} />
          <button
            onClick={onClose}
            className="lg:hidden p-1.5 rounded-xl text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800 cursor-pointer"
            aria-label="إغلاق القائمة"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Notebook Selector Card - Clean & Minimalist */}
        <div className="p-3 border-b border-[#e2e8e5] dark:border-[#22352f]">
          <div className="bg-[#f6f8f7] dark:bg-[#1a2723] rounded-2xl p-2.5 border border-[#e2e8e5] dark:border-[#22352f] shadow-2xs">
            <div className="flex items-center justify-between mb-1 px-1">
              <span className="text-[11px] font-bold text-[#596762] dark:text-[#9ab3ab]">
                الدفتر النشط
              </span>
              <button
                onClick={() => setShowNbModal(true)}
                className="text-[11px] text-teal-700 dark:text-teal-300 hover:bg-teal-50 dark:hover:bg-teal-950/60 px-2 py-0.5 rounded-lg font-bold flex items-center gap-1 transition-colors cursor-pointer"
                title="إنشاء دفتر جديد"
              >
                <FolderPlus className="w-3.5 h-3.5" />
                <span>جديد</span>
              </button>
            </div>

            <button
              onClick={() => setShowNbSwitcher(!showNbSwitcher)}
              className="w-full text-right flex items-center justify-between p-2 rounded-xl bg-white dark:bg-[#14201c] hover:bg-teal-50/50 dark:hover:bg-[#182722] border border-slate-200/60 dark:border-[#233830] transition-all cursor-pointer shadow-2xs"
            >
              <div className="truncate">
                <div className="font-bold text-xs sm:text-sm text-[#17201e] dark:text-[#eef7f4] truncate">
                  {currentNotebook.name}
                </div>
                <div className="text-[10px] text-[#596762] dark:text-[#9ab3ab] flex items-center gap-1.5 mt-0.5">
                  <span className="font-medium">{currentNotebook.subject}</span>
                  <span>•</span>
                  <span>{sourceCount} مصادر</span>
                </div>
              </div>
              <span className="text-xs text-[#596762] dark:text-[#9ab3ab] px-1 font-bold">▾</span>
            </button>

            {/* Notebook Switcher Dropdown */}
            {showNbSwitcher && (
              <div className="mt-2 pt-2 border-t border-[#e2e8e5] dark:border-[#22352f] max-h-48 overflow-y-auto space-y-1">
                {notebooks.map((nb) => {
                  const isActive = nb.id === currentNotebook.id;
                  return (
                    <div
                      key={nb.id}
                      className={`flex items-center justify-between p-1.5 rounded-lg text-xs transition-colors ${
                        isActive
                          ? 'bg-[#0f766e] text-white font-bold'
                          : 'hover:bg-white dark:hover:bg-[#14201c] text-[#17201e] dark:text-[#eef7f4]'
                      }`}
                    >
                      <button
                        onClick={() => {
                          onSelectNotebook(nb.id);
                          setShowNbSwitcher(false);
                        }}
                        className="flex-1 text-right truncate"
                      >
                        {nb.name}
                      </button>
                      <div className="flex items-center gap-1">
                        {isActive && <Check className="w-3.5 h-3.5 mr-0.5" />}
                        {notebooks.length > 1 && (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              if (confirm(`حذف «${nb.name}»؟`)) onDeleteNotebook(nb.id);
                            }}
                            className="p-1 hover:text-red-400 opacity-70 hover:opacity-100"
                            title="حذف الدفتر"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Navigation list */}
        <nav className="flex-1 p-3 space-y-4 overflow-y-auto">
          {navSections.map((section, sIdx) => (
            <div key={sIdx} className="space-y-1">
              <div className="text-[10px] font-bold text-[#8ba29a] dark:text-[#6a837a] uppercase tracking-wider px-2 py-0.5">
                {section.title}
              </div>
              {section.items.map((item) => {
                const Icon = item.icon;
                const isActive = currentTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      onSelectTab(item.id);
                      onClose();
                    }}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                      isActive
                        ? 'bg-[#0f766e] text-white shadow-md shadow-[#0f766e]/15'
                        : item.highlight
                        ? 'text-teal-700 dark:text-teal-300 bg-teal-50/60 dark:bg-teal-950/30 hover:bg-teal-100/60'
                        : 'text-[#596762] dark:text-[#9ab3ab] hover:bg-[#f6f8f7] dark:hover:bg-[#1a2723] hover:text-[#17201e] dark:hover:text-[#eef7f4]'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-white' : 'text-[#0f766e] dark:text-[#2dd4bf]'}`} />
                      <span className="truncate">{item.label}</span>
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0">
                      {item.badge && (
                        <span className={`text-[9px] font-black px-1.5 py-0.5 rounded-md ${
                          isActive ? 'bg-white/20 text-white' : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                        }`}>
                          {item.badge}
                        </span>
                      )}
                      {typeof item.count === 'number' && item.count > 0 && (
                        <span
                          className={`text-[10px] px-1.5 py-0.5 rounded-full font-bold ${
                            isActive
                              ? 'bg-white/20 text-white'
                              : 'bg-[#e6f4f1] text-[#0f766e] dark:bg-[#132e29] dark:text-[#2dd4bf]'
                          }`}
                        >
                          {item.count}
                        </span>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          ))}
        </nav>

        {/* Learning Progress Tracker for Active Notebook */}
        <div className="mx-3 my-2 p-3 rounded-2xl bg-gradient-to-br from-teal-500/10 via-emerald-500/10 to-teal-500/5 dark:from-teal-950/40 dark:via-emerald-950/30 dark:to-teal-950/20 border border-teal-500/25 dark:border-teal-700/40 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
              <Award className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
              <span>إتقان الدفتر (Progress)</span>
            </span>
            <span className="text-[11px] font-mono font-black text-teal-700 dark:text-teal-300 px-1.5 py-0.5 rounded-full bg-teal-100 dark:bg-teal-900/60">
              {learningProgress}%
            </span>
          </div>

          {/* Progress Bar */}
          <div className="w-full bg-slate-200/80 dark:bg-[#1a2924] h-2 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-teal-500 to-emerald-400 rounded-full transition-all duration-500"
              style={{ width: `${Math.max(5, learningProgress)}%` }}
            />
          </div>

          <div className="flex items-center justify-between text-[10px] text-slate-500 dark:text-slate-400 font-medium">
            <span>{masteredCards}/{totalCards} بطاقات مستوعبة</span>
            <span>{notebookNotesCount} تدوينات</span>
          </div>
        </div>

        {/* Footer controls */}
        <div className="p-3 border-t border-[#e2e8e5] dark:border-[#22352f] space-y-2">
          {/* PWA Install Button */}
          <PWAInstallButton variant="sidebar" />

          <div className="flex items-center justify-between text-xs text-[#596762] dark:text-[#9ab3ab] pt-1">
            <button
              onClick={onToggleTheme}
              className="flex items-center gap-1.5 p-1.5 rounded-lg hover:bg-[#f6f8f7] dark:hover:bg-[#1a2723] transition-colors cursor-pointer"
              title="تبديل المظهر"
            >
              {isDark ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-gray-600" />}
              <span>{isDark ? 'نهاري' : 'ليلي'}</span>
            </button>

            <button
              type="button"
              onClick={() => {
                if (onOpenSupportModal) {
                  onOpenSupportModal();
                  onClose();
                }
              }}
              className="flex items-center gap-1.5 p-1.5 rounded-lg hover:bg-[#f6f8f7] dark:hover:bg-[#1a2723] text-teal-700 dark:text-teal-300 transition-colors cursor-pointer"
              title="تواصل مع الدعم الفني"
            >
              <Mail className="w-3.5 h-3.5" />
              <span>الدعم</span>
            </button>

            <button
              onClick={onBackup}
              className="flex items-center gap-1.5 p-1.5 rounded-lg hover:bg-[#f6f8f7] dark:hover:bg-[#1a2723] transition-colors cursor-pointer"
              title="نسخة احتياطية"
            >
              <Download className="w-3.5 h-3.5" />
              <span>نسخ</span>
            </button>
          </div>

          <div className="pt-2 px-1 text-[10px] text-center text-slate-500 dark:text-slate-400 border-t border-slate-200/60 dark:border-[#22352f]/60 leading-relaxed">
            <div className="font-bold text-teal-800 dark:text-teal-300">
              Developed by Dhiyaa Al-Haq Subayqaa & The D.CORE Academic Team
            </div>
            <div className="text-[9px] text-slate-400 dark:text-slate-500 mt-0.5">
              تم التطوير بواسطة المهندس ضياء الحق سبيقاء وفريق D.CORE الأكاديمي
            </div>
          </div>
        </div>
      </aside>

      {/* Create Notebook Modal */}
      {showNbModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="bg-white dark:bg-[#14201c] rounded-2xl max-w-md w-full p-6 shadow-2xl border border-[#e2e8e5] dark:border-[#22352f]">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-lg text-[#17201e] dark:text-[#eef7f4]">
                إنشاء دفتر دراسة جديد
              </h3>
              <button
                onClick={() => setShowNbModal(false)}
                className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreate} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-[#596762] dark:text-[#9ab3ab] mb-1">
                  اسم الدفتر *
                </label>
                <input
                  type="text"
                  required
                  placeholder="مثال: أحياء ثالث ثانوي، تفاضل وتكامل..."
                  value={newNbName}
                  onChange={(e) => setNewNbName(e.target.value)}
                  className="w-full px-3 py-2 border border-[#e2e8e5] dark:border-[#22352f] rounded-xl bg-[#f6f8f7] dark:bg-[#1a2723] text-sm text-[#17201e] dark:text-[#eef7f4] focus:outline-none focus:border-[#0f766e]"
                  autoFocus
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#596762] dark:text-[#9ab3ab] mb-1">
                  المادة / المجال
                </label>
                <input
                  type="text"
                  placeholder="مثال: علوم، رياضيات، برمجة..."
                  value={newNbSubject}
                  onChange={(e) => setNewNbSubject(e.target.value)}
                  className="w-full px-3 py-2 border border-[#e2e8e5] dark:border-[#22352f] rounded-xl bg-[#f6f8f7] dark:bg-[#1a2723] text-sm text-[#17201e] dark:text-[#eef7f4] focus:outline-none focus:border-[#0f766e]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#596762] dark:text-[#9ab3ab] mb-1">
                  وصف مختصر
                </label>
                <textarea
                  rows={3}
                  placeholder="ما الذي ستركز عليه في هذا الدفتر؟"
                  value={newNbDesc}
                  onChange={(e) => setNewNbDesc(e.target.value)}
                  className="w-full px-3 py-2 border border-[#e2e8e5] dark:border-[#22352f] rounded-xl bg-[#f6f8f7] dark:bg-[#1a2723] text-sm text-[#17201e] dark:text-[#eef7f4] focus:outline-none focus:border-[#0f766e] resize-none"
                />
              </div>

              <div className="flex gap-2 justify-end pt-2">
                <button
                  type="button"
                  onClick={() => setShowNbModal(false)}
                  className="px-4 py-2 rounded-xl text-sm font-semibold border border-[#e2e8e5] dark:border-[#22352f] text-[#596762] hover:bg-gray-100 dark:hover:bg-gray-800"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-sm font-bold bg-[#0f766e] text-white hover:bg-[#115e59] shadow-md shadow-[#0f766e]/20"
                >
                  إنشاء ومتابعة
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
};
