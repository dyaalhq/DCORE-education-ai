import React, { useState, useEffect } from 'react';
import { Wifi, WifiOff, CheckCircle } from 'lucide-react';

export function useOnlineStatus() {
  const [isOnline, setIsOnline] = useState(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  return isOnline;
}

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();
  const [showToast, setShowToast] = useState(false);
  const [justCameOnline, setJustCameOnline] = useState(false);

  useEffect(() => {
    if (!isOnline) {
      setShowToast(true);
      setJustCameOnline(false);
    } else {
      setJustCameOnline(true);
      const timer = setTimeout(() => {
        setShowToast(false);
        setJustCameOnline(false);
      }, 3500);
      return () => clearTimeout(timer);
    }
  }, [isOnline]);

  if (isOnline && !justCameOnline) return null;

  return (
    <div
      dir="rtl"
      className={`fixed bottom-16 sm:bottom-6 left-4 z-50 flex items-center gap-2.5 px-3.5 py-2 rounded-2xl text-xs font-bold shadow-xl backdrop-blur-md transition-all duration-300 animate-in slide-in-from-bottom-2 ${
        isOnline
          ? 'bg-emerald-600/90 text-white border border-emerald-400/40 shadow-emerald-600/20'
          : 'bg-slate-900/95 text-amber-200 border border-amber-500/40 shadow-black/40'
      }`}
    >
      {isOnline ? (
        <>
          <CheckCircle className="w-4 h-4 text-emerald-300 animate-bounce" />
          <span>تمت استعادة الاتصال بالإنترنت — كافة الميزات السحابية متاحة.</span>
        </>
      ) : (
        <>
          <WifiOff className="w-4 h-4 text-amber-400 animate-pulse" />
          <div>
            <span>وضع العمل بدون إنترنت (PWA Offline)</span>
            <span className="text-[10px] block text-slate-300 font-normal">
              بنك الأسئلة، والموسوعة، والمعمل، والملاحظات تعمل محلياً بدقة 100%.
            </span>
          </div>
        </>
      )}
    </div>
  );
};
