import React, { useState } from 'react';
import { 
  Copy, 
  Trash2, 
  BookOpen, 
  Globe, 
  ExternalLink, 
  Check, 
  Zap, 
  ShieldCheck, 
  Printer, 
  Highlighter,
  ThumbsUp,
  ThumbsDown,
  RotateCcw,
  ChevronDown,
  ChevronUp,
  ArrowLeft,
  Sparkles,
  Volume2,
  VolumeX,
  GitFork
} from 'lucide-react';
import { ChatMessage, Citation } from '../types';
import { EducationalContent } from './EducationalContent';
import { speakText, stopSpeaking } from '../lib/studySpeechEngine';

export interface ChatMessageItemProps {
  msg: ChatMessage;
  isLastAiMessage: boolean;
  isGenerating: boolean;
  copiedId: string | null;
  userFeedback: 'like' | 'dislike' | null | undefined;
  savedNoteMsgId: string | null;
  onCopy: (text: string, id: string) => void;
  onRegenerate: (msgId: string) => void;
  onDelete: (msgId: string) => void;
  onFeedback: (msgId: string, type: 'like' | 'dislike') => void;
  onOpenSourceLinker: (citation: Citation) => void;
  onExportPdf: (text: string) => void;
  onExportNote?: (text: string, msgId: string) => void;
  onQuickPrompt: (prompt: string) => void;
  onGenerateMindMapFromText?: (text: string) => void;
}

export const ChatMessageItem = React.memo<ChatMessageItemProps>(({
  msg,
  isLastAiMessage,
  isGenerating,
  copiedId,
  userFeedback,
  savedNoteMsgId,
  onCopy,
  onRegenerate,
  onDelete,
  onFeedback,
  onOpenSourceLinker,
  onExportPdf,
  onExportNote,
  onQuickPrompt,
  onGenerateMindMapFromText,
}) => {
  const isUser = msg.role === 'user';
  const feedback = userFeedback ?? msg.feedback;
  const isCopied = copiedId === msg.id;
  const isSavedNote = savedNoteMsgId === msg.id;
  const [showCitations, setShowCitations] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [speechRate, setSpeechRate] = useState<number>(1.0);

  const SPEECH_RATES = [0.75, 1.0, 1.25, 1.5, 2.0];

  const handleCycleSpeed = (e: React.MouseEvent) => {
    e.stopPropagation();
    const currentIdx = SPEECH_RATES.indexOf(speechRate);
    const nextRate = SPEECH_RATES[(currentIdx + 1) % SPEECH_RATES.length];
    setSpeechRate(nextRate);

    // If currently speaking, restart with new rate immediately
    if (isSpeaking) {
      speakTextWithRate(nextRate);
    }
  };

  const speakTextWithRate = (rate: number) => {
    speakText(msg.text, {
      title: 'شرح المعلم الذكي',
      speed: rate,
      onStart: () => setIsSpeaking(true),
      onEnd: () => setIsSpeaking(false),
      onError: () => setIsSpeaking(false),
    });
  };

  // Text-To-Speech Handler
  const handleToggleSpeak = () => {
    if (isSpeaking) {
      stopSpeaking();
      setIsSpeaking(false);
      return;
    }

    speakTextWithRate(speechRate);
  };

  // Extract next unit prompt if provided by RAG outline or embedded in message text
  const nextUnitMatch = !msg.suggestedNextUnit && msg.text && !isUser
    ? msg.text.match(/(?:الوحدة|الفصل|الباب)\s+(الثانية|الثالثة|الرابعة|الخامسة|السادسة|السابعة|الثامنة|التاسعة|العاشرة|\d+)(?:[:\s\-–]+([^\n\r.]+))?/i)
    : null;
  const detectedNextUnit = msg.suggestedNextUnit || (nextUnitMatch ? nextUnitMatch[0].trim() : null);
  const effectiveNextPrompt = msg.suggestedNextPrompt || (detectedNextUnit ? `متابعة استكمال شرح ${detectedNextUnit} بالتفصيل الممل مع كافة القوانين والأمثلة المحلولة` : null);

  return (
    <div
      className={`flex gap-2.5 sm:gap-3.5 max-w-4xl w-full min-w-0 ${isUser ? 'mr-auto flex-row-reverse justify-start' : 'ml-auto justify-start'} animate-in fade-in-50 slide-in-from-bottom-2 duration-200`}
    >
      {/* Avatar */}
      <div
        className={`w-8 h-8 sm:w-9 sm:h-9 rounded-2xl flex items-center justify-center font-bold text-xs shrink-0 select-none shadow-xs ${
          isUser
            ? 'bg-gradient-to-br from-teal-700 to-teal-800 text-white shadow-teal-800/20'
            : 'bg-gradient-to-tr from-teal-600 via-teal-500 to-emerald-400 text-white shadow-teal-500/20 font-black'
        }`}
      >
        {isUser ? 'أنت' : '✦'}
      </div>

      {/* Message Bubble Container */}
      <div className={`space-y-1.5 flex-1 min-w-0 max-w-full flex flex-col ${isUser ? 'items-end' : 'items-start'}`}>
        <div
          className={`p-4 sm:p-5 rounded-3xl text-xs sm:text-sm leading-relaxed overflow-hidden break-words [overflow-wrap:anywhere] [word-break:break-word] shadow-sm transition-all box-border ${
            isUser
              ? 'w-fit max-w-[90%] sm:max-w-[82%] bg-gradient-to-l from-teal-800 via-teal-700 to-emerald-700 text-white rounded-tl-sm whitespace-pre-wrap font-medium selection:bg-teal-950 selection:text-white border border-teal-500/30 shadow-md shadow-teal-900/10'
              : 'w-full max-w-full bg-white/95 dark:bg-[#121f1a]/95 backdrop-blur-xl text-slate-800 dark:text-[#f0f9f6] border border-slate-200/90 dark:border-[#1e342b] rounded-tr-sm shadow-[0_4px_24px_rgba(0,0,0,0.03)] dark:shadow-[0_8px_32px_rgba(0,0,0,0.35)]'
          }`}
        >
          {isUser ? (
            <div className="min-w-0 max-w-full overflow-hidden break-words [overflow-wrap:anywhere]">
              <div className="flex items-center justify-between pb-1.5 mb-2 border-b border-teal-500/40 select-none text-[10px] text-teal-200">
                <span className="font-bold">أنت (سؤال دراسي)</span>
                <span className="font-mono text-teal-200/80">
                  {msg.date ? new Date(msg.date).toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' }) : ''}
                </span>
              </div>
              <div className="leading-relaxed text-white break-words [overflow-wrap:anywhere] [word-break:break-word]">
                <EducationalContent content={msg.text} className="text-white" />
              </div>
            </div>
          ) : (
            <div className="space-y-3 min-w-0 max-w-full overflow-hidden break-words [overflow-wrap:anywhere] [word-break:break-word]">
              {/* AI Teacher Header Identity Tag */}
              <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-[#1e342b]/70 select-none">
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-extrabold text-teal-800 dark:text-teal-300">
                    ✦ المعلم الذكي AI
                  </span>
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                </div>
                <span className="text-[10px] font-mono text-slate-400 dark:text-slate-500">
                  {msg.date ? new Date(msg.date).toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' }) : ''}
                </span>
              </div>

              {/* Main Rich Markdown Body with LaTeX Math and Arabic Formatting */}
              <EducationalContent
                content={msg.text}
                citations={msg.citations}
                onCitationClick={onOpenSourceLinker}
              />

              {/* RAG Citations - Sleek Collapsible Button / Accordion */}
              {msg.citations && msg.citations.length > 0 && (
                <div className="mt-3 pt-2.5 border-t border-slate-100 dark:border-[#22352f]/60">
                  <div className="flex items-center justify-between gap-2">
                    <button
                      type="button"
                      onClick={() => setShowCitations(!showCitations)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-50/90 dark:bg-[#182622] hover:bg-teal-50 dark:hover:bg-teal-950/50 border border-slate-200/80 dark:border-[#243a33] text-slate-700 dark:text-slate-200 hover:text-teal-700 dark:hover:text-teal-300 text-xs font-semibold transition-all cursor-pointer shadow-2xs group"
                      title={showCitations ? "إخفاء المراجع المستخدمة" : "عرض المراجع المستخدمة"}
                    >
                      <BookOpen className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400 group-hover:scale-110 transition-transform" />
                      <span>المراجع المستخدمة ({msg.citations.length})</span>
                      {showCitations ? (
                        <ChevronUp className="w-3.5 h-3.5 text-slate-500 group-hover:text-teal-600 transition-colors" />
                      ) : (
                        <ChevronDown className="w-3.5 h-3.5 text-slate-500 group-hover:text-teal-600 transition-colors" />
                      )}
                    </button>
                    <span className="text-[10px] font-mono text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/50 px-2 py-0.5 rounded-lg border border-emerald-200/60 dark:border-emerald-800/50">
                      دقة المطابقة: {msg.citations[0]?.confidenceScore || 96}%
                    </span>
                  </div>

                  {showCitations && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2.5 animate-in fade-in slide-in-from-top-1 duration-150">
                      {msg.citations.map((cite, i) => (
                        <button
                          key={i}
                          type="button"
                          onClick={() => onOpenSourceLinker(cite)}
                          className="p-2.5 rounded-2xl bg-white dark:bg-[#15231e] border border-slate-200/80 dark:border-[#243a33] hover:border-teal-500 dark:hover:border-teal-400 transition-all text-right flex flex-col gap-1 group cursor-pointer shadow-xs"
                        >
                          <div className="flex items-center justify-between text-[11px] font-bold text-slate-800 dark:text-slate-100 w-full">
                            <span className="truncate max-w-[150px]">{cite.sourceTitle}</span>
                            {cite.pageNumber && (
                              <span className="text-[10px] text-teal-600 dark:text-teal-400 font-mono">
                                ص {cite.pageNumber}
                              </span>
                            )}
                          </div>
                          {cite.quote && (
                            <p className="text-[10px] text-slate-500 dark:text-slate-400 line-clamp-2 leading-relaxed italic">
                              «{cite.quote.slice(0, 90)}...»
                            </p>
                          )}
                          <div className="flex items-center justify-between text-[10px] text-teal-600 dark:text-teal-400 pt-1 border-t border-slate-100 dark:border-slate-800/40 w-full font-medium">
                            <span className="flex items-center gap-1">
                              <Highlighter className="w-3 h-3 group-hover:scale-110 transition-transform" />
                              <span>تظليل وقفز فوري في الـ PDF</span>
                            </span>
                            <ExternalLink className="w-2.5 h-2.5 group-hover:translate-x-0.5 transition-transform" />
                          </div>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Google Search Grounding References */}
              {msg.groundingSources && msg.groundingSources.length > 0 && (
                <div className="mt-3 pt-2.5 border-t border-slate-200/80 dark:border-[#22352f] space-y-1.5">
                  <div className="text-[11px] font-bold text-emerald-800 dark:text-emerald-300 flex items-center justify-between gap-1">
                    <span className="flex items-center gap-1.5">
                      <Globe className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                      <span>مراجع الويب الموثقة (Google Grounding):</span>
                    </span>
                    <span className="text-[10px] font-mono text-emerald-700 dark:text-emerald-300">
                      {msg.groundingSources.length} مراجع
                    </span>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {msg.groundingSources.map((g, gi) => (
                      <a
                        key={gi}
                        href={g.uri}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-[11px] px-2.5 py-1 rounded-xl bg-slate-50 dark:bg-[#182622] border border-emerald-200/80 dark:border-emerald-800/60 text-emerald-900 dark:text-emerald-200 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 flex items-center gap-1.5 transition-all group"
                      >
                        <span className="font-mono text-[10px] font-bold text-emerald-600">{gi + 1}.</span>
                        <span className="truncate max-w-[160px] font-medium">{g.title}</span>
                        <ExternalLink className="w-2.5 h-2.5 text-emerald-600 group-hover:translate-x-0.5 transition-transform shrink-0" />
                      </a>
                    ))}
                  </div>
                </div>
              )}

              {/* Interactive Multi-Step Curriculum Next Unit Continuation Button */}
              {!isUser && !isGenerating && (effectiveNextPrompt || detectedNextUnit) && (
                <div className="mt-4 pt-3 border-t border-teal-500/20 dark:border-teal-700/30 animate-in fade-in slide-in-from-bottom-1 duration-200">
                  <div className="text-[11px] font-bold text-teal-800 dark:text-teal-300 mb-2 flex items-center justify-between">
                    <span className="flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                      <span>المحطة المنهجية التالية في مسار استيعاب الكتاب:</span>
                    </span>
                    <span className="text-[10px] bg-teal-100 dark:bg-teal-950/80 text-teal-800 dark:text-teal-200 px-2 py-0.5 rounded-md font-semibold">
                      تغطية هرمية شاملة 100%
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => onQuickPrompt(effectiveNextPrompt!)}
                    className="w-full py-2.5 px-3.5 rounded-2xl bg-gradient-to-r from-teal-700 via-teal-600 to-emerald-600 hover:from-teal-800 hover:to-emerald-700 text-white font-bold text-xs sm:text-sm flex items-center justify-between gap-2 shadow-md hover:shadow-lg transition-all cursor-pointer group active:scale-[0.98]"
                    title="الاستمرار التلقائي واستدعاء مقاطع الوحدة التالية دون إسقاط أي درس"
                  >
                    <div className="flex items-center gap-2 text-right">
                      <span className="text-base shrink-0">📖</span>
                      <span className="line-clamp-1">
                        متابعة استكمال شرح الوحدة التالية بالتفصيل الممل
                        {detectedNextUnit ? `: «${detectedNextUnit}»` : ''}
                      </span>
                    </div>
                    <ArrowLeft className="w-4 h-4 shrink-0 group-hover:-translate-x-1 transition-transform" />
                  </button>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Progressive Disclosure Action Bar (Subtle & Clean, Hover-revealed on Desktop) */}
        <div className="flex flex-wrap items-center justify-between gap-1.5 px-1 text-[11px] text-slate-500 dark:text-slate-400 pt-1 w-full transition-opacity duration-200 sm:opacity-85 sm:hover:opacity-100">
          <div className="flex items-center gap-1.5 flex-wrap">
            {/* Quick Copy Button */}
            <button
              type="button"
              onClick={() => onCopy(msg.text, msg.id)}
              className="p-1.5 sm:px-2.5 sm:py-1 rounded-xl bg-slate-100/90 dark:bg-[#182622] hover:bg-teal-50 dark:hover:bg-teal-950/40 hover:text-teal-700 dark:hover:text-teal-300 border border-slate-200/60 dark:border-[#22352f] flex items-center gap-1.5 transition-all cursor-pointer text-xs font-medium active:scale-95"
              title="نسخ نص الإجابة"
            >
              {isCopied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-500" />
                  <span className="text-emerald-600 dark:text-emerald-400 font-bold hidden sm:inline">تم النسخ</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" />
                  <span className="hidden sm:inline">نسخ</span>
                </>
              )}
            </button>

            {/* Audio Read-Aloud Button & Speed Control */}
            {!isUser && (
              <div className="flex items-center">
                <button
                  type="button"
                  onClick={handleToggleSpeak}
                  className={`p-1.5 sm:px-2.5 sm:py-1 rounded-r-xl border flex items-center gap-1.5 transition-all cursor-pointer text-xs font-medium active:scale-95 ${
                    isSpeaking
                      ? 'bg-amber-500 text-white border-amber-600 shadow-2xs font-bold animate-pulse'
                      : 'bg-slate-100/90 dark:bg-[#182622] hover:bg-teal-50 dark:hover:bg-teal-950/40 hover:text-teal-700 dark:hover:text-teal-300 border-slate-200/60 dark:border-[#22352f]'
                  }`}
                  title={isSpeaking ? 'إيقاف القراءة الصوتية' : 'استمع للشرح صوتياً'}
                >
                  {isSpeaking ? (
                    <>
                      <VolumeX className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">إيقاف</span>
                    </>
                  ) : (
                    <>
                      <Volume2 className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                      <span className="hidden sm:inline">استماع</span>
                    </>
                  )}
                </button>
                <button
                  type="button"
                  onClick={handleCycleSpeed}
                  className={`px-1.5 py-1 rounded-l-xl border-y border-l text-[10px] font-mono font-bold transition-all cursor-pointer select-none ${
                    isSpeaking
                      ? 'bg-amber-600 text-white border-amber-700 hover:bg-amber-700'
                      : 'bg-slate-50 dark:bg-[#15231e] text-slate-600 dark:text-slate-300 border-slate-200/60 dark:border-[#22352f] hover:bg-teal-50 dark:hover:bg-teal-950/40 hover:text-teal-700 dark:hover:text-teal-300'
                  }`}
                  title="تغيير سرعة القراءة الصوتية (0.75x, 1x, 1.25x, 1.5x, 2x)"
                >
                  {speechRate}x
                </button>
              </div>
            )}

            {!isUser && (
              <>
                {/* Export to Clean Academic PDF */}
                <button
                  type="button"
                  onClick={() => onExportPdf(msg.text)}
                  className="p-1.5 sm:px-2.5 sm:py-1 rounded-xl bg-slate-100/90 dark:bg-[#182622] hover:bg-teal-50 dark:hover:bg-teal-950/40 text-teal-700 dark:text-teal-300 border border-slate-200/60 dark:border-[#22352f] flex items-center gap-1 transition-colors cursor-pointer text-xs font-medium"
                  title="تصدير الشرح كتقرير دراسي PDF نظيف وأكاديمي"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">PDF</span>
                </button>

                {/* Convert to Deep Interactive Mind Map (Single Message Only) */}
                {onGenerateMindMapFromText && (
                  <button
                    type="button"
                    onClick={() => onGenerateMindMapFromText(msg.text)}
                    className="p-1.5 sm:px-2.5 sm:py-1 rounded-xl bg-teal-50 dark:bg-teal-950/60 hover:bg-teal-100 dark:hover:bg-teal-900/60 text-teal-800 dark:text-teal-200 border border-teal-200/80 dark:border-teal-800/80 flex items-center gap-1 transition-all cursor-pointer text-xs font-bold active:scale-95 shadow-2xs group"
                    title="توليد خريطة ذهنية تفاعلية بالذكاء الاصطناعي لهذه الرسالة فقط دون بقية الرسائل"
                  >
                    <GitFork className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400 group-hover:rotate-12 transition-transform" />
                    <span className="hidden sm:inline">خريطة هذا الرد (AI)</span>
                  </button>
                )}

                {/* Save to Notebook Note */}
                {onExportNote && (
                  <button
                    type="button"
                    onClick={() => onExportNote(msg.text, msg.id)}
                    className="p-1.5 sm:px-2 sm:py-1 rounded-xl bg-slate-100/90 dark:bg-[#182622] text-teal-700 dark:text-teal-300 hover:bg-teal-50 dark:hover:bg-teal-950/40 border border-slate-200/60 dark:border-[#22352f] flex items-center gap-1 transition-colors cursor-pointer text-xs font-medium"
                    title="حفظ الشرح في دفتر الملاحظات"
                  >
                    {isSavedNote ? (
                      <Check className="w-3.5 h-3.5 text-emerald-500" />
                    ) : (
                      <BookOpen className="w-3.5 h-3.5" />
                    )}
                    <span className="hidden lg:inline">{isSavedNote ? 'تم الحفظ' : 'حفظ بالدفتر'}</span>
                  </button>
                )}

                {/* Regenerate Button */}
                <button
                  type="button"
                  onClick={() => onRegenerate(msg.id)}
                  disabled={isGenerating}
                  className="p-1.5 sm:px-2 sm:py-1 rounded-xl bg-slate-100/90 dark:bg-[#182622] hover:bg-teal-50 dark:hover:bg-teal-950/40 hover:text-teal-700 dark:hover:text-teal-300 border border-slate-200/60 dark:border-[#22352f] flex items-center gap-1 transition-all cursor-pointer text-xs font-medium disabled:opacity-40 active:scale-95"
                  title="إعادة التوليد"
                >
                  <RotateCcw className={`w-3.5 h-3.5 text-teal-600 dark:text-teal-400 ${isGenerating ? 'animate-spin' : ''}`} />
                  <span className="hidden lg:inline">إعادة</span>
                </button>

                {/* Rating Feedback Group */}
                <div className="flex items-center bg-slate-100/90 dark:bg-[#182622] rounded-xl p-0.5 border border-slate-200/60 dark:border-[#22352f]">
                  <button
                    type="button"
                    onClick={() => onFeedback(msg.id, 'like')}
                    className={`p-1 sm:px-1.5 sm:py-0.5 rounded-lg flex items-center gap-1 transition-all cursor-pointer text-xs ${
                      feedback === 'like' 
                        ? 'bg-emerald-500 text-white shadow-2xs font-bold' 
                        : 'text-slate-500 dark:text-slate-400 hover:text-emerald-600'
                    }`}
                    title="مفيد وممتاز"
                  >
                    <ThumbsUp className={`w-3 h-3 ${feedback === 'like' ? 'fill-current' : ''}`} />
                  </button>

                  <button
                    type="button"
                    onClick={() => onFeedback(msg.id, 'dislike')}
                    className={`p-1 sm:px-1.5 sm:py-0.5 rounded-lg flex items-center gap-1 transition-all cursor-pointer text-xs ${
                      feedback === 'dislike' 
                        ? 'bg-rose-500 text-white shadow-2xs font-bold' 
                        : 'text-slate-500 dark:text-slate-400 hover:text-rose-600'
                    }`}
                    title="يحتاج لتحسين"
                  >
                    <ThumbsDown className={`w-3 h-3 ${feedback === 'dislike' ? 'fill-current' : ''}`} />
                  </button>
                </div>
              </>
            )}

            {/* Delete Message */}
            <button
              type="button"
              onClick={() => onDelete(msg.id)}
              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/30 transition-colors cursor-pointer"
              title="حذف الرسالة"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Quick Follow-up Shortcuts (Shown cleanly only for the latest message to avoid repeating rows in history) */}
          {!isUser && !isGenerating && isLastAiMessage && (
            <div className="flex items-center gap-1 flex-wrap mt-1 sm:mt-0 animate-in fade-in duration-200">
              <button
                type="button"
                onClick={() => onQuickPrompt('اشرح لي هذا المفهوم بأسلوب أبسط مع مثال عملي وتطبيقي ممتع.')}
                className="px-2 py-0.5 rounded-lg bg-teal-50 dark:bg-teal-950/40 hover:bg-teal-100 text-teal-800 dark:text-teal-300 text-[10px] font-semibold border border-teal-200/60 dark:border-teal-800/60 transition-colors cursor-pointer shadow-2xs"
              >
                💡 بسّط الشرح
              </button>

              <button
                type="button"
                onClick={() => onQuickPrompt('اعطني مسألة منهجية تطبيقية محلولة بالخطوات الخمس (المعطيات، المطلوب، القانون، التعويض، الناتج).')}
                className="px-2 py-0.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100 text-emerald-800 dark:text-emerald-300 text-[10px] font-semibold border border-emerald-200/60 dark:border-emerald-800/60 transition-colors cursor-pointer shadow-2xs"
              >
                📐 مسألة محلولة
              </button>

              <button
                type="button"
                onClick={() => onQuickPrompt('اطرح علي سؤالين تدريبيين لاختبار فهمي لما ورد في هذا الشرح مع إخفاء الإجابة لأجرب أولاً.')}
                className="px-2 py-0.5 rounded-lg bg-blue-50 dark:bg-blue-950/40 hover:bg-blue-100 text-blue-800 dark:text-blue-300 text-[10px] font-semibold border border-blue-200/60 dark:border-blue-800/60 transition-colors cursor-pointer shadow-2xs"
              >
                ❓ اختبرني
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
});
