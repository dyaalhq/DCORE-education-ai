import React, { useState, useEffect, useRef, useMemo } from 'react';
import { 
  Calculator, 
  Clock, 
  Play, 
  Pause, 
  RotateCcw, 
  Volume2, 
  CheckCircle2, 
  History, 
  Delete, 
  Check, 
  Sparkles,
  PieChart as PieChartIcon,
  BarChart3,
  BookOpen,
  Award,
  TrendingUp,
  Flame,
  Calendar,
  Layers
} from 'lucide-react';
import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip as RechartsTooltip, Legend } from 'recharts';
import { CalculatorEngine } from '../lib/calculatorEngine';
import { playAlarmSound } from '../lib/audioAlarm';
import { FocusSession, Notebook } from '../types';

interface ToolsViewProps {
  currentNotebookId: string;
  focusSessions: FocusSession[];
  allFocusSessions?: FocusSession[];
  notebooks?: Notebook[];
  onAddFocusSession: (session: FocusSession) => void;
}

const engine = new CalculatorEngine();

const STATS_COLORS = [
  '#0f766e', // Teal
  '#0284c7', // Sky
  '#8b5cf6', // Violet
  '#f59e0b', // Amber
  '#10b981', // Emerald
  '#ec4899', // Pink
  '#6366f1', // Indigo
  '#14b8a6', // Cyan
  '#f97316', // Orange
];

export const ToolsView: React.FC<ToolsViewProps> = ({
  currentNotebookId,
  focusSessions,
  allFocusSessions = [],
  notebooks = [],
  onAddFocusSession,
}) => {
  const [toolTab, setToolTab] = useState<'calc' | 'timer' | 'stats'>('calc');
  const [statsScope, setStatsScope] = useState<'all' | 'current'>('all');
  const [statsViewMode, setStatsViewMode] = useState<'subject' | 'notebook'>('subject');

  // Calculator State
  const [calcInput, setCalcInput] = useState('');
  const [calcResult, setCalcResult] = useState('');
  const [calcError, setCalcError] = useState('');
  const [isDegree, setIsDegree] = useState(true);
  const [calcHistory, setCalcHistory] = useState<{ expr: string; res: string }[]>([]);
  const [memoryVal, setMemoryVal] = useState(0);

  // Timer State
  const [timerDurationMins, setTimerDurationMins] = useState(25);
  const [timeLeftSeconds, setTimeLeftSeconds] = useState(25 * 60);
  const [isRunning, setIsRunning] = useState(false);
  const [alarmSound, setAlarmSound] = useState<'chime' | 'digital' | 'classic' | 'alarm'>('chime');
  const timerRef = useRef<any>(null);

  // Sync DEG/RAD with engine
  useEffect(() => {
    engine.setDegreeMode(isDegree);
  }, [isDegree]);

  // Calculator input handlers
  const handleCalcClick = (val: string) => {
    setCalcError('');
    if (val === 'C') {
      setCalcInput('');
      setCalcResult('');
    } else if (val === 'DEL') {
      setCalcInput((prev) => prev.slice(0, -1));
    } else if (val === '=') {
      try {
        const res = engine.evaluate(calcInput);
        const formatted = Number.isInteger(res) ? res.toString() : parseFloat(res.toFixed(8)).toString();
        setCalcResult(formatted);
        setCalcHistory((prev) => [{ expr: calcInput, res: formatted }, ...prev.slice(0, 19)]);
      } catch (e: any) {
        setCalcError(e.message || 'خطأ في التعبير');
      }
    } else if (val === 'MC') {
      engine.setMemory(0);
      setMemoryVal(0);
    } else if (val === 'MR') {
      setCalcInput((prev) => prev + engine.getMemory().toString());
    } else if (val === 'M+') {
      try {
        const res = engine.evaluate(calcInput || calcResult);
        engine.setMemory(engine.getMemory() + res);
        setMemoryVal(engine.getMemory());
      } catch {}
    } else if (val === 'M-') {
      try {
        const res = engine.evaluate(calcInput || calcResult);
        engine.setMemory(engine.getMemory() - res);
        setMemoryVal(engine.getMemory());
      } catch {}
    } else {
      setCalcInput((prev) => prev + val);
    }
  };

  // Timer interval handling
  useEffect(() => {
    if (isRunning) {
      timerRef.current = setInterval(() => {
        setTimeLeftSeconds((prev) => {
          if (prev <= 1) {
            clearInterval(timerRef.current);
            setIsRunning(false);
            playAlarmSound(alarmSound);

            // Record completed session
            onAddFocusSession({
              id: `focus_${Date.now()}`,
              notebookId: currentNotebookId,
              durationMins: timerDurationMins,
              timestamp: Date.now(),
              sound: alarmSound,
            });

            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      clearInterval(timerRef.current);
    }
    return () => clearInterval(timerRef.current);
  }, [isRunning, timerDurationMins, alarmSound, currentNotebookId]);

  const handleStartTimer = () => setIsRunning(true);
  const handlePauseTimer = () => setIsRunning(false);
  const handleResetTimer = () => {
    setIsRunning(false);
    setTimeLeftSeconds(timerDurationMins * 60);
  };

  const handleSelectPreset = (mins: number) => {
    setIsRunning(false);
    setTimerDurationMins(mins);
    setTimeLeftSeconds(mins * 60);
  };

  const minutes = Math.floor(timeLeftSeconds / 60);
  const seconds = timeLeftSeconds % 60;
  const progressPercent = ((timerDurationMins * 60 - timeLeftSeconds) / (timerDurationMins * 60)) * 100;

  // Study Statistics Aggregation across Subjects and Notebooks
  const {
    chartData,
    isSampleData,
    totalMinutes,
    totalHours,
    totalSessionsCount,
    topSubject,
    averageDuration,
  } = useMemo(() => {
    // Select sessions to analyze based on scope:
    const activeSessions =
      statsScope === 'all' && allFocusSessions.length > 0
        ? allFocusSessions
        : focusSessions.length > 0
        ? focusSessions
        : allFocusSessions;

    // Create a lookup map for notebook subjects
    const notebookMap = new Map<string, { subject: string; name: string }>();
    notebooks.forEach((nb) => {
      notebookMap.set(nb.id, {
        subject: nb.subject?.trim() || 'المذاكرة العامة',
        name: nb.name?.trim() || 'دفتر المذاكرة',
      });
    });

    const subjectTotals: Record<string, { minutes: number; count: number; name: string }> = {};

    activeSessions.forEach((sess) => {
      const nbInfo = sess.notebookId ? notebookMap.get(sess.notebookId) : null;
      const key =
        statsViewMode === 'subject'
          ? nbInfo?.subject || 'المذاكرة العامة'
          : nbInfo?.name || 'جلسات دراسية عامة';
      const mins = sess.durationMins || sess.minutes || 25;

      if (!subjectTotals[key]) {
        subjectTotals[key] = { minutes: 0, count: 0, name: key };
      }
      subjectTotals[key].minutes += mins;
      subjectTotals[key].count += 1;
    });

    const totalMins = Object.values(subjectTotals).reduce((acc, s) => acc + s.minutes, 0);
    const totalSess = Object.values(subjectTotals).reduce((acc, s) => acc + s.count, 0);

    let rawData = Object.values(subjectTotals)
      .map((item, index) => {
        const percentage = totalMins > 0 ? Math.round((item.minutes / totalMins) * 100) : 0;
        return {
          name: item.name,
          value: item.minutes,
          minutes: item.minutes,
          hours: Number((item.minutes / 60).toFixed(1)),
          sessions: item.count,
          percentage,
          color: STATS_COLORS[index % STATS_COLORS.length],
        };
      })
      .sort((a, b) => b.value - a.value);

    const isMock = false;
    const calculatedTotalMins = totalMins;
    const calculatedTotalSessions = totalSess;
    const top = rawData.length > 0 ? rawData[0].name : '—';
    const avg = calculatedTotalSessions > 0 ? Math.round(calculatedTotalMins / calculatedTotalSessions) : 0;

    return {
      chartData: rawData,
      isSampleData: isMock,
      totalMinutes: calculatedTotalMins,
      totalHours: (calculatedTotalMins / 60).toFixed(1),
      totalSessionsCount: calculatedTotalSessions,
      topSubject: top,
      averageDuration: avg,
    };
  }, [focusSessions, allFocusSessions, notebooks, statsScope, statsViewMode]);

  return (
    <div className="space-y-5">
      {/* Header Tab Switcher */}
      <div className="bg-white dark:bg-[#14201c] rounded-2xl border border-[#e2e8e5] dark:border-[#22352f] p-4 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-[#17201e] dark:text-[#eef7f4] flex items-center gap-2">
            <Calculator className="w-5 h-5 text-[#0f766e] dark:text-[#2dd4bf]" />
            <span>الأدوات المساعدة للتعلم والتركيز</span>
          </h2>
          <p className="text-xs text-[#596762] dark:text-[#9ab3ab]">
            حاسبة علمية متقدمة خالية من الأخطاء، ومؤقت تركيز بأسلوب بومودورو مع تنبيهات صوتية.
          </p>
        </div>

        <div className="flex gap-2">
          <button
            onClick={() => setToolTab('calc')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              toolTab === 'calc'
                ? 'bg-[#0f766e] text-white shadow-sm'
                : 'bg-[#f6f8f7] dark:bg-[#1a2723] text-[#596762] dark:text-[#9ab3ab]'
            }`}
          >
            <Calculator className="w-4 h-4" />
            <span>الحاسبة العلمية</span>
          </button>

          <button
            onClick={() => setToolTab('timer')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              toolTab === 'timer'
                ? 'bg-[#0f766e] text-white shadow-sm'
                : 'bg-[#f6f8f7] dark:bg-[#1a2723] text-[#596762] dark:text-[#9ab3ab]'
            }`}
          >
            <Clock className="w-4 h-4" />
            <span>مؤقت التركيز</span>
          </button>

          <button
            onClick={() => setToolTab('stats')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              toolTab === 'stats'
                ? 'bg-[#0f766e] text-white shadow-sm'
                : 'bg-[#f6f8f7] dark:bg-[#1a2723] text-[#596762] dark:text-[#9ab3ab]'
            }`}
          >
            <PieChartIcon className="w-4 h-4" />
            <span>إحصائيات المذاكرة</span>
          </button>
        </div>
      </div>

      {/* 1. Scientific Calculator */}
      {toolTab === 'calc' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Main Calculator Body */}
          <div className="lg:col-span-8 bg-white dark:bg-[#14201c] rounded-2xl border border-[#e2e8e5] dark:border-[#22352f] p-5 shadow-sm space-y-4">
            {/* Display LCD Screen */}
            <div className="p-4 bg-[#f6f8f7] dark:bg-[#121b18] border border-[#e2e8e5] dark:border-[#22352f] rounded-2xl text-left" dir="ltr">
              <div className="flex items-center justify-between text-[11px] text-[#596762] dark:text-[#9ab3ab] mb-1 font-mono">
                <span>{isDegree ? 'DEG' : 'RAD'}</span>
                <span>{memoryVal !== 0 ? `M = ${memoryVal}` : ''}</span>
              </div>
              <input
                type="text"
                value={calcInput}
                onChange={(e) => setCalcInput(e.target.value)}
                placeholder="0"
                className="w-full text-lg sm:text-xl font-mono text-[#17201e] dark:text-[#eef7f4] bg-transparent border-none outline-none text-right"
              />
              <div className="text-xl sm:text-2xl font-bold font-mono text-[#0f766e] dark:text-[#2dd4bf] text-right mt-1 min-h-[32px]">
                {calcResult || (calcError ? <span className="text-red-500 text-sm">{calcError}</span> : '')}
              </div>
            </div>

            {/* Mode & Memory row */}
            <div className="flex items-center justify-between gap-2 text-xs">
              <div className="flex gap-1">
                <button
                  onClick={() => setIsDegree(!isDegree)}
                  className="px-3 py-1.5 rounded-lg bg-[#f6f8f7] dark:bg-[#1a2723] border border-[#e2e8e5] dark:border-[#22352f] font-bold text-[#0f766e] dark:text-[#2dd4bf]"
                >
                  {isDegree ? 'DEG (درجات)' : 'RAD (راديان)'}
                </button>
              </div>

              <div className="flex gap-1">
                {['MC', 'MR', 'M+', 'M-'].map((btn) => (
                  <button
                    key={btn}
                    onClick={() => handleCalcClick(btn)}
                    className="px-2.5 py-1.5 rounded-lg bg-[#f6f8f7] dark:bg-[#1a2723] border border-[#e2e8e5] dark:border-[#22352f] font-mono text-[11px] font-bold text-[#596762] dark:text-[#9ab3ab]"
                  >
                    {btn}
                  </button>
                ))}
              </div>
            </div>

            {/* Keypad Grid */}
            <div className="grid grid-cols-5 gap-2 font-mono text-sm">
              {[
                { label: 'sin', val: 'sin(' },
                { label: 'cos', val: 'cos(' },
                { label: 'tan', val: 'tan(' },
                { label: 'C', val: 'C', red: true },
                { label: 'DEL', val: 'DEL', amber: true },

                { label: 'asin', val: 'asin(' },
                { label: 'acos', val: 'acos(' },
                { label: 'atan', val: 'atan(' },
                { label: '(', val: '(' },
                { label: ')', val: ')' },

                { label: '√', val: 'sqrt(' },
                { label: '^', val: '^' },
                { label: '!', val: '!' },
                { label: '%', val: '%' },
                { label: '÷', val: '/' },

                { label: 'ln', val: 'ln(' },
                { label: '7', val: '7', num: true },
                { label: '8', val: '8', num: true },
                { label: '9', val: '9', num: true },
                { label: '×', val: '*' },

                { label: 'log', val: 'log(' },
                { label: '4', val: '4', num: true },
                { label: '5', val: '5', num: true },
                { label: '6', val: '6', num: true },
                { label: '−', val: '-' },

                { label: 'π', val: 'pi' },
                { label: '1', val: '1', num: true },
                { label: '2', val: '2', num: true },
                { label: '3', val: '3', num: true },
                { label: '+', val: '+' },

                { label: 'e', val: 'e' },
                { label: '0', val: '0', num: true },
                { label: '.', val: '.', num: true },
                { label: 'Ans', val: 'ans' },
                { label: '=', val: '=', primary: true },
              ].map((btn, i) => {
                let btnStyle = 'bg-[#f6f8f7] dark:bg-[#1a2723] text-[#17201e] dark:text-[#eef7f4] hover:bg-gray-200 dark:hover:bg-gray-800';
                if (btn.num) btnStyle = 'bg-white dark:bg-[#121b18] text-[#17201e] dark:text-[#eef7f4] font-bold shadow-xs';
                if (btn.primary) btnStyle = 'bg-[#0f766e] text-white hover:bg-[#115e59] font-bold shadow-md shadow-[#0f766e]/20';
                if (btn.red) btnStyle = 'bg-red-50 dark:bg-red-950/40 text-red-600 font-bold';
                if (btn.amber) btnStyle = 'bg-amber-50 dark:bg-amber-950/40 text-amber-600 font-bold';

                return (
                  <button
                    key={i}
                    onClick={() => handleCalcClick(btn.val)}
                    className={`h-11 sm:h-12 rounded-xl border border-[#e2e8e5] dark:border-[#22352f] flex items-center justify-center transition-all active:scale-95 ${btnStyle}`}
                  >
                    {btn.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Calculator History Sidebar */}
          <div className="lg:col-span-4 bg-white dark:bg-[#14201c] rounded-2xl border border-[#e2e8e5] dark:border-[#22352f] p-4 shadow-sm flex flex-col h-full min-h-[380px]">
            <div className="flex items-center justify-between pb-3 border-b border-[#e2e8e5] dark:border-[#22352f] mb-2">
              <h4 className="font-bold text-xs text-[#17201e] dark:text-[#eef7f4] flex items-center gap-1.5">
                <History className="w-3.5 h-3.5 text-[#0f766e]" />
                <span>سجل العمليات السابقة</span>
              </h4>
              {calcHistory.length > 0 && (
                <button
                  onClick={() => setCalcHistory([])}
                  className="text-[11px] text-gray-400 hover:text-red-500"
                >
                  مسح
                </button>
              )}
            </div>

            <div className="flex-1 overflow-y-auto space-y-2">
              {calcHistory.length === 0 ? (
                <div className="p-8 text-center text-xs text-[#596762] dark:text-[#9ab3ab]">
                  لا توجد عمليات سابقة. ستظهر الحسابات هنا فور إجرائها.
                </div>
              ) : (
                calcHistory.map((item, idx) => (
                  <div
                    key={idx}
                    onClick={() => {
                      setCalcInput(item.res);
                      setCalcResult('');
                    }}
                    className="p-2.5 rounded-xl bg-[#f8fbfa] dark:bg-[#121b18] border border-[#e2e8e5] dark:border-[#22352f] cursor-pointer hover:border-[#0f766e] transition-colors"
                  >
                    <div className="text-[11px] font-mono text-gray-500 truncate" dir="ltr">
                      {item.expr}
                    </div>
                    <div className="text-sm font-mono font-bold text-[#0f766e] dark:text-[#2dd4bf] text-right" dir="ltr">
                      = {item.res}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* 2. Focus Timer (Pomodoro) */}
      {toolTab === 'timer' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Main Timer Display */}
          <div className="lg:col-span-8 bg-white dark:bg-[#14201c] rounded-2xl border border-[#e2e8e5] dark:border-[#22352f] p-8 shadow-sm text-center space-y-6 flex flex-col items-center">
            {/* Presets Row */}
            <div className="flex flex-wrap justify-center gap-2">
              {[
                { label: 'بومودورو (25 د)', mins: 25 },
                { label: 'مذاكرة مركزة (45 د)', mins: 45 },
                { label: 'استيعاب عميق (60 د)', mins: 60 },
                { label: 'استراحة قصيرة (5 د)', mins: 5 },
                { label: 'استراحة طويلة (15 د)', mins: 15 },
              ].map((p) => (
                <button
                  key={p.mins}
                  onClick={() => handleSelectPreset(p.mins)}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                    timerDurationMins === p.mins
                      ? 'bg-[#0f766e] text-white shadow-md shadow-[#0f766e]/20'
                      : 'bg-[#f6f8f7] dark:bg-[#1a2723] text-[#596762] dark:text-[#9ab3ab] border border-[#e2e8e5] dark:border-[#22352f]'
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>

            {/* Circular Timer Visual */}
            <div className="relative w-64 h-64 flex items-center justify-center">
              <svg className="w-full h-full -rotate-90 transform" viewBox="0 0 100 100">
                {/* Background Ring */}
                <circle
                  cx="50"
                  cy="50"
                  r="42"
                  className="stroke-[#e2e8e5] dark:stroke-[#22352f]"
                  strokeWidth="6"
                  fill="none"
                />
                {/* Active Progress Ring */}
                <circle
                  cx="50"
                  cy="50"
                  r="42"
                  className="stroke-[#0f766e] dark:stroke-[#2dd4bf] transition-all duration-1000 ease-linear"
                  strokeWidth="6"
                  strokeDasharray={264}
                  strokeDashoffset={264 - (264 * progressPercent) / 100}
                  strokeLinecap="round"
                  fill="none"
                />
              </svg>

              <div className="absolute flex flex-col items-center">
                <span className="font-mono text-4xl sm:text-5xl font-extrabold text-[#17201e] dark:text-[#eef7f4]">
                  {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
                </span>
                <span className="text-xs font-bold text-[#596762] dark:text-[#9ab3ab] mt-2">
                  {isRunning ? 'جلسة تركيز نشطة ✦' : 'جاهز للبدء'}
                </span>
              </div>
            </div>

            {/* Controls Row */}
            <div className="flex items-center gap-3">
              {!isRunning ? (
                <button
                  onClick={handleStartTimer}
                  className="px-8 py-3 bg-[#0f766e] hover:bg-[#115e59] text-white rounded-2xl font-bold text-sm flex items-center gap-2 shadow-lg shadow-[#0f766e]/25 transition-all"
                >
                  <Play className="w-5 h-5 fill-current" />
                  <span>ابدأ التركيز</span>
                </button>
              ) : (
                <button
                  onClick={handlePauseTimer}
                  className="px-8 py-3 bg-amber-500 hover:bg-amber-600 text-white rounded-2xl font-bold text-sm flex items-center gap-2 shadow-lg shadow-amber-500/25 transition-all"
                >
                  <Pause className="w-5 h-5 fill-current" />
                  <span>إيقاف مؤقت</span>
                </button>
              )}

              <button
                onClick={handleResetTimer}
                className="p-3 border border-[#e2e8e5] dark:border-[#22352f] hover:bg-[#f6f8f7] dark:hover:bg-[#1a2723] rounded-2xl text-[#596762] dark:text-[#9ab3ab]"
                title="إعادة تعيين"
              >
                <RotateCcw className="w-5 h-5" />
              </button>
            </div>

            {/* Sound Selector */}
            <div className="flex items-center gap-2 text-xs text-[#596762] dark:text-[#9ab3ab]">
              <Volume2 className="w-4 h-4 text-[#0f766e]" />
              <span>نغمة التنبيه عند الانتهاء:</span>
              <select
                value={alarmSound}
                onChange={(e: any) => setAlarmSound(e.target.value)}
                className="bg-[#f6f8f7] dark:bg-[#1a2723] border border-[#e2e8e5] dark:border-[#22352f] rounded-lg px-2 py-1 font-bold text-xs"
              >
                <option value="chime">رنين هادئ (Chime)</option>
                <option value="digital">نغمة رقمية (Digital)</option>
                <option value="classic">نغمة كلاسيكية (Classic)</option>
                <option value="alarm">إنذار دراسي (Alarm)</option>
              </select>
              <button
                onClick={() => playAlarmSound(alarmSound)}
                className="text-[11px] text-[#0f766e] dark:text-[#2dd4bf] hover:underline font-bold"
              >
                تجربة الصوت
              </button>
            </div>
          </div>

          {/* Completed Sessions Log */}
          <div className="lg:col-span-4 bg-white dark:bg-[#14201c] rounded-2xl border border-[#e2e8e5] dark:border-[#22352f] p-5 shadow-sm space-y-4">
            <h3 className="font-bold text-sm text-[#17201e] dark:text-[#eef7f4] flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-500" />
              <span>الجلسات المنجزة اليوم</span>
            </h3>

            <div className="space-y-2 max-h-80 overflow-y-auto">
              {focusSessions.length === 0 ? (
                <div className="p-8 text-center text-xs text-[#596762] dark:text-[#9ab3ab]">
                  لم تكمل أي جلسة تركيز بعد. أكمل جلستك الأولى لتحتسب في سجل إنجازاتك اليومي.
                </div>
              ) : (
                focusSessions.map((session) => (
                  <div
                    key={session.id}
                    className="p-3 bg-[#f8fbfa] dark:bg-[#121b18] border border-[#e2e8e5] dark:border-[#22352f] rounded-xl flex items-center justify-between text-xs"
                  >
                    <div>
                      <span className="font-bold text-[#17201e] dark:text-[#eef7f4]">
                        جلسة تركيز ({session.durationMins} دقيقة)
                      </span>
                      <div className="text-[10px] text-[#596762] dark:text-[#9ab3ab]">
                        {new Date(session.timestamp || session.date || Date.now()).toLocaleTimeString('ar', { hour: '2-digit', minute: '2-digit' })}
                      </div>
                    </div>
                    <span className="text-emerald-500 font-bold">✓ تم الإنجاز</span>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* 3. Study Statistics & Focus Distribution (إحصائيات المذاكرة وتوزيع وقت التركيز) */}
      {toolTab === 'stats' && (
        <div className="space-y-5 animate-in fade-in duration-200">
          {/* Controls & Scope Selector */}
          <div className="bg-white dark:bg-[#14201c] rounded-2xl border border-[#e2e8e5] dark:border-[#22352f] p-4 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="font-bold text-sm text-[#17201e] dark:text-[#eef7f4] flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-teal-600 dark:text-teal-400" />
                <span>لوحة تحليلات وقت التركيز الأكاديمي</span>
              </h3>
              <p className="text-xs text-[#596762] dark:text-[#9ab3ab] mt-0.5">
                توزيع ساعات المذاكرة وجلسات بومودورو عبر المناهج والمواد المختلفة.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <div className="flex bg-[#f6f8f7] dark:bg-[#1a2723] p-1 rounded-xl text-xs font-semibold">
                <button
                  type="button"
                  onClick={() => setStatsViewMode('subject')}
                  className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                    statsViewMode === 'subject'
                      ? 'bg-white dark:bg-[#14201c] text-teal-700 dark:text-teal-300 shadow-2xs font-bold'
                      : 'text-[#596762] dark:text-[#9ab3ab]'
                  }`}
                >
                  حسب المادة
                </button>
                <button
                  type="button"
                  onClick={() => setStatsViewMode('notebook')}
                  className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                    statsViewMode === 'notebook'
                      ? 'bg-white dark:bg-[#14201c] text-teal-700 dark:text-teal-300 shadow-2xs font-bold'
                      : 'text-[#596762] dark:text-[#9ab3ab]'
                  }`}
                >
                  حسب الدفتر
                </button>
              </div>

              <div className="flex bg-[#f6f8f7] dark:bg-[#1a2723] p-1 rounded-xl text-xs font-semibold">
                <button
                  type="button"
                  onClick={() => setStatsScope('all')}
                  className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                    statsScope === 'all'
                      ? 'bg-teal-600 text-white shadow-2xs font-bold'
                      : 'text-[#596762] dark:text-[#9ab3ab]'
                  }`}
                >
                  كافة الدفاتر ({notebooks.length})
                </button>
                <button
                  type="button"
                  onClick={() => setStatsScope('current')}
                  className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                    statsScope === 'current'
                      ? 'bg-teal-600 text-white shadow-2xs font-bold'
                      : 'text-[#596762] dark:text-[#9ab3ab]'
                  }`}
                >
                  الدفتر الحالي
                </button>
              </div>
            </div>
          </div>

          {/* Vitals KPI Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-white dark:bg-[#14201c] rounded-2xl border border-[#e2e8e5] dark:border-[#22352f] p-4 shadow-xs">
              <div className="flex items-center justify-between text-xs text-[#596762] dark:text-[#9ab3ab]">
                <span>إجمالي وقت التركيز</span>
                <Clock className="w-4 h-4 text-teal-600" />
              </div>
              <div className="text-xl sm:text-2xl font-black text-[#17201e] dark:text-[#eef7f4] mt-1.5">
                {totalHours} <span className="text-xs font-normal text-slate-400">ساعة</span>
              </div>
              <div className="text-[11px] text-teal-700 dark:text-teal-400 mt-0.5">
                {totalMinutes} دقيقة مذاكرة حقيقية
              </div>
            </div>

            <div className="bg-white dark:bg-[#14201c] rounded-2xl border border-[#e2e8e5] dark:border-[#22352f] p-4 shadow-xs">
              <div className="flex items-center justify-between text-xs text-[#596762] dark:text-[#9ab3ab]">
                <span>جلسات بومودورو</span>
                <CheckCircle2 className="w-4 h-4 text-emerald-500" />
              </div>
              <div className="text-xl sm:text-2xl font-black text-[#17201e] dark:text-[#eef7f4] mt-1.5">
                {totalSessionsCount} <span className="text-xs font-normal text-slate-400">جلسة</span>
              </div>
              <div className="text-[11px] text-emerald-600 dark:text-emerald-400 mt-0.5">
                مكتملة بنجاح
              </div>
            </div>

            <div className="bg-white dark:bg-[#14201c] rounded-2xl border border-[#e2e8e5] dark:border-[#22352f] p-4 shadow-xs">
              <div className="flex items-center justify-between text-xs text-[#596762] dark:text-[#9ab3ab]">
                <span>المادة الأكثر دراسة</span>
                <Flame className="w-4 h-4 text-amber-500" />
              </div>
              <div className="text-sm sm:text-base font-black text-[#17201e] dark:text-[#eef7f4] mt-1.5 truncate">
                {topSubject}
              </div>
              <div className="text-[11px] text-amber-600 dark:text-amber-400 mt-0.5">
                أعلى تركيز منهجي
              </div>
            </div>

            <div className="bg-white dark:bg-[#14201c] rounded-2xl border border-[#e2e8e5] dark:border-[#22352f] p-4 shadow-xs">
              <div className="flex items-center justify-between text-xs text-[#596762] dark:text-[#9ab3ab]">
                <span>متوسط الجلسة</span>
                <TrendingUp className="w-4 h-4 text-indigo-500" />
              </div>
              <div className="text-xl sm:text-2xl font-black text-[#17201e] dark:text-[#eef7f4] mt-1.5">
                {averageDuration} <span className="text-xs font-normal text-slate-400">دقيقة</span>
              </div>
              <div className="text-[11px] text-indigo-600 dark:text-indigo-400 mt-0.5">
                معدل الاستدامة الذهنية
              </div>
            </div>
          </div>

          {/* Sample Data Notice if empty */}
          {isSampleData && (
            <div className="p-3.5 bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-800 rounded-2xl text-xs text-teal-800 dark:text-teal-200 flex items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-teal-600 shrink-0" />
                <span>
                  <strong>ملاحظة توجيهية:</strong> لم تقم بتسجيل جلسات تركيز كافية بعد. نعرض لك نموذج توزيع استرشادي، وسيتحدث الرسم الدائري آلياً عند إكمال جلسات عبر «مؤقت التركيز»!
                </span>
              </div>
              <button
                type="button"
                onClick={() => setToolTab('timer')}
                className="px-3 py-1.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl font-bold text-xs shrink-0 cursor-pointer transition-colors"
              >
                بدء جلسة الآن
              </button>
            </div>
          )}

          {/* Main Chart & Detailed Table Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
            {/* Interactive Pie Chart using Recharts */}
            <div className="lg:col-span-7 bg-white dark:bg-[#14201c] rounded-2xl border border-[#e2e8e5] dark:border-[#22352f] p-5 shadow-sm space-y-4">
              <div className="flex items-center justify-between border-b border-[#e2e8e5] dark:border-[#22352f] pb-3">
                <h4 className="font-bold text-sm text-[#17201e] dark:text-[#eef7f4] flex items-center gap-2">
                  <PieChartIcon className="w-4 h-4 text-teal-600" />
                  <span>توزيع وقت التركيز عبر المواد الدراسية (Pie Chart)</span>
                </h4>
                <span className="text-[11px] text-slate-400">
                  {chartData.length} مواد مسجلة
                </span>
              </div>

              {/* Chart Container */}
              <div className="h-[290px] w-full flex items-center justify-center relative" dir="ltr">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={chartData}
                      dataKey="value"
                      nameKey="name"
                      cx="50%"
                      cy="50%"
                      innerRadius={65}
                      outerRadius={105}
                      paddingAngle={3}
                      stroke="#ffffff"
                      strokeWidth={2}
                    >
                      {chartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <RechartsTooltip
                      content={({ active, payload }) => {
                        if (active && payload && payload.length) {
                          const data = payload[0].payload;
                          return (
                            <div className="bg-white dark:bg-[#14201c] p-3 rounded-2xl shadow-xl border border-slate-200 dark:border-[#22352f] text-xs space-y-1 text-right font-sans min-w-[150px]">
                              <div className="font-bold text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
                                <span
                                  className="w-2.5 h-2.5 rounded-full shrink-0"
                                  style={{ backgroundColor: data.color }}
                                />
                                <span>{data.name}</span>
                              </div>
                              <div className="text-teal-700 dark:text-teal-400 font-black">
                                {data.minutes} دقيقة ({data.hours} ساعة)
                              </div>
                              <div className="text-slate-500 dark:text-slate-400 text-[11px]">
                                نسبة الوقت: <strong className="text-slate-700 dark:text-slate-200">{data.percentage}%</strong>
                              </div>
                              <div className="text-[10px] text-slate-400">
                                الجلسات: {data.sessions} جلسة
                              </div>
                            </div>
                          );
                        }
                        return null;
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>

                {/* Donut Center Display */}
                <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none text-center">
                  <div className="text-xl font-black text-slate-800 dark:text-slate-100 font-mono">
                    {totalHours}h
                  </div>
                  <div className="text-[10px] text-slate-400 font-semibold">
                    إجمالي التركيز
                  </div>
                </div>
              </div>

              {/* Chart Legend Badges */}
              <div className="flex flex-wrap items-center justify-center gap-2 pt-2 border-t border-[#e2e8e5] dark:border-[#22352f]">
                {chartData.map((item) => (
                  <div
                    key={item.name}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-slate-50 dark:bg-[#1a2723] text-xs font-semibold text-slate-700 dark:text-slate-200 border border-slate-200/80 dark:border-[#22352f]"
                  >
                    <span
                      className="w-2.5 h-2.5 rounded-full shrink-0"
                      style={{ backgroundColor: item.color }}
                    />
                    <span className="truncate max-w-[100px]">{item.name}</span>
                    <span className="text-slate-400 text-[11px] font-mono">({item.percentage}%)</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Subject Distribution Breakdown Table */}
            <div className="lg:col-span-5 bg-white dark:bg-[#14201c] rounded-2xl border border-[#e2e8e5] dark:border-[#22352f] p-5 shadow-sm space-y-4 flex flex-col justify-between">
              <div className="space-y-3">
                <div className="flex items-center justify-between border-b border-[#e2e8e5] dark:border-[#22352f] pb-3">
                  <h4 className="font-bold text-sm text-[#17201e] dark:text-[#eef7f4] flex items-center gap-2">
                    <Layers className="w-4 h-4 text-emerald-600" />
                    <span>جدول تفصيل المواد والدفاتر</span>
                  </h4>
                  <span className="text-[11px] font-bold text-teal-700 dark:text-teal-400">
                    النسبة المئوية
                  </span>
                </div>

                <div className="space-y-3 max-h-[300px] overflow-y-auto pr-0.5">
                  {chartData.map((item) => (
                    <div
                      key={item.name}
                      className="p-3 bg-slate-50/70 dark:bg-[#121b18] rounded-xl border border-slate-200/80 dark:border-[#1c2c26] space-y-1.5"
                    >
                      <div className="flex items-center justify-between text-xs">
                        <div className="flex items-center gap-2 font-bold text-slate-800 dark:text-slate-100">
                          <span
                            className="w-3 h-3 rounded-full shrink-0"
                            style={{ backgroundColor: item.color }}
                          />
                          <span className="truncate max-w-[130px]">{item.name}</span>
                        </div>
                        <div className="font-mono text-teal-700 dark:text-teal-400 font-bold">
                          {item.hours} س ({item.minutes} د)
                        </div>
                      </div>

                      {/* Distribution Bar */}
                      <div className="flex items-center gap-2">
                        <div className="flex-1 h-2 bg-slate-200 dark:bg-[#22352f] rounded-full overflow-hidden">
                          <div
                            className="h-full rounded-full transition-all duration-500"
                            style={{ width: `${item.percentage}%`, backgroundColor: item.color }}
                          />
                        </div>
                        <span className="text-[11px] font-mono text-slate-500 font-bold w-9 text-left">
                          {item.percentage}%
                        </span>
                      </div>

                      <div className="text-[10px] text-slate-400 flex items-center justify-between pt-0.5">
                        <span>الجلسات المنجزة: {item.sessions}</span>
                        <span>معدل التركيز: {Math.round(item.minutes / (item.sessions || 1))} د/جلسة</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Study Tip footer */}
              <div className="p-3 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/60 rounded-xl text-[11px] text-amber-800 dark:text-amber-200 leading-relaxed flex items-center gap-2">
                <Award className="w-4 h-4 text-amber-600 shrink-0" />
                <span>
                  <strong>توجيه ذكي:</strong> وازن بين المواد ذات الحجم المعرفي الأكبر مثل <strong>{topSubject}</strong> والمواد الأخرى لتجنب تراكم المنهج قبل موعد الامتحانات.
                </span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
