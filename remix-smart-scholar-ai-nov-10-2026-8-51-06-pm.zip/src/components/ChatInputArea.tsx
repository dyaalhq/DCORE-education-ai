import React, { useState, useRef, useEffect, useCallback } from 'react';
import { 
  Send, 
  StopCircle, 
  Sparkles, 
  Globe, 
  Mic, 
  MicOff, 
  AlertCircle,
  ChevronDown,
  ChevronUp,
  X,
  Plus
} from 'lucide-react';
import { AIMode } from '../types';
import { t } from '../lib/i18n';

export interface ChatInputAreaProps {
  isGenerating: boolean;
  onSendMessage: (text: string) => void;
  onStop: () => void;
  aiMode: AIMode;
  notebookTitle?: string;
  sourcesCount: number;
  selectedSourcesCount: number;
  isSearchGroundingEnabled: boolean;
  onToggleSearchGrounding: () => void;
  smartTips: string[];
  hasLastAiMessage: boolean;
  prefilledPrompt?: string;
  onClearPrefilledPrompt?: () => void;
}

export const ChatInputArea = React.memo<ChatInputAreaProps>(({
  isGenerating,
  onSendMessage,
  onStop,
  aiMode,
  notebookTitle,
  sourcesCount,
  selectedSourcesCount,
  isSearchGroundingEnabled,
  onToggleSearchGrounding,
  smartTips,
  hasLastAiMessage,
  prefilledPrompt,
  onClearPrefilledPrompt,
}) => {
  // Completely isolated local input state - typing NEVER re-renders the message list!
  const [input, setInput] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [speechError, setSpeechError] = useState<string | null>(null);
  const [isToolsOpen, setIsToolsOpen] = useState(false);

  // Persistent Smart Tips Collapsible State in LocalStorage (Hidden by default to save reading space)
  const [isTipsCollapsed, setIsTipsCollapsed] = useState<boolean>(() => {
    try {
      const stored = localStorage.getItem('dcore_smart_tips_collapsed');
      return stored !== null ? stored === 'true' : true; // Hidden by default
    } catch {
      return true;
    }
  });

  const toggleTipsCollapsed = useCallback(() => {
    setIsTipsCollapsed((prev) => {
      const next = !prev;
      try {
        localStorage.setItem('dcore_smart_tips_collapsed', String(next));
      } catch {}
      return next;
    });
  }, []);

  const closeTips = useCallback(() => {
    setIsTipsCollapsed(true);
    try {
      localStorage.setItem('dcore_smart_tips_collapsed', 'true');
    } catch {}
  }, []);

  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const containerRef = useRef<HTMLElement>(null);
  const recognitionRef = useRef<any>(null);

  // Sync prefilled prompt when provided by parent
  useEffect(() => {
    if (prefilledPrompt) {
      setInput(prefilledPrompt);
      onClearPrefilledPrompt?.();
      setTimeout(() => {
        if (textareaRef.current) {
          textareaRef.current.focus();
          textareaRef.current.style.height = 'auto';
          textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 160)}px`;
        }
      }, 50);
    }
  }, [prefilledPrompt, onClearPrefilledPrompt]);

  // Clean up speech recognition on unmount
  useEffect(() => {
    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.abort();
      }
    };
  }, []);

  // Textarea input handler with micro-debounced visual height update
  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const val = e.target.value;
    setInput(val);
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 160)}px`;
    }
  };

  // Submit message
  const handleSubmit = useCallback((e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (isListening && recognitionRef.current) {
      recognitionRef.current.stop();
      setIsListening(false);
    }

    const textToSend = input.trim();
    if (!textToSend || isGenerating) return;

    // Reset local input immediately
    setInput('');
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }

    onSendMessage(textToSend);
  }, [input, isGenerating, isListening, onSendMessage]);

  // Voice Input (Web Speech API)
  const toggleVoiceInput = useCallback(() => {
    if (isListening) {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      setIsListening(false);
      return;
    }

    // @ts-ignore
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setSpeechError('عذرًا، المتصفح الحالي لا يدعم التعرف الصوتي المباشر. يرجى تجربة Chrome أو Edge أو Safari.');
      setTimeout(() => setSpeechError(null), 5000);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.lang = 'ar-SA';
      recognition.continuous = false;
      recognition.interimResults = true;

      recognition.onstart = () => {
        setIsListening(true);
        setSpeechError(null);
      };

      recognition.onresult = (event: any) => {
        let interimTranscript = '';
        let finalTranscript = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          } else {
            interimTranscript += event.results[i][0].transcript;
          }
        }

        const spoken = (finalTranscript || interimTranscript).trim();
        if (spoken) {
          setInput((prev) => {
            const trimmed = prev.trim();
            if (!trimmed) return spoken;
            return `${trimmed} ${spoken}`;
          });
        }
      };

      recognition.onerror = (event: any) => {
        console.warn('Speech recognition error:', event.error);
        if (event.error === 'not-allowed') {
          setSpeechError('تم رفض الإذن للوصول إلى الميكروفون. يرجى السماح بالوصول من إعدادات المتصفح.');
        } else if (event.error !== 'no-speech') {
          setSpeechError(`تنبيه الميكروفون: ${event.error}`);
        }
        setIsListening(false);
        setTimeout(() => setSpeechError(null), 5000);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
      recognition.start();
    } catch (err: any) {
      console.error('Speech initialization error:', err);
      setIsListening(false);
      setSpeechError('تعذر بدء التقاط الصوت.');
    }
  }, [isListening]);

  return (
    <footer 
      ref={containerRef}
      style={{ flexShrink: 0 }}
      className="shrink-0 sticky bottom-[52px] lg:bottom-0 z-20 backdrop-blur-xl bg-white/95 dark:bg-[#0c1411]/95 border-t border-slate-200/80 dark:border-[#1c2c26] p-2 sm:p-3 shadow-[0_-8px_30px_rgba(0,0,0,0.06)] dark:shadow-[0_-8px_30px_rgba(0,0,0,0.35)]"
    >
      {/* Progressive Disclosure Tools Panel (Revealed on clicking '+') */}
      {isToolsOpen && (
        <div className="mb-2.5 p-3 rounded-2xl bg-white dark:bg-[#14221d] border border-slate-200/90 dark:border-[#22352f] shadow-lg animate-in fade-in slide-in-from-bottom-2 duration-150">
          <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-100 dark:border-[#1c2c26]">
            <span className="text-xs font-bold text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-teal-600" />
              <span>أدوات وخيارات الذكاء الاصطناعي المتقدمة</span>
            </span>
            <button
              type="button"
              onClick={() => setIsToolsOpen(false)}
              className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-0.5 cursor-pointer rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
              title="إغلاق"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Google Web Search Grounding Toggle */}
            <button
              type="button"
              onClick={onToggleSearchGrounding}
              className={`px-3 py-1.5 rounded-xl border flex items-center gap-2 text-xs font-medium transition-all cursor-pointer ${
                isSearchGroundingEnabled || aiMode === 'hybrid'
                  ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                  : 'bg-slate-50 dark:bg-[#182622] text-slate-700 dark:text-slate-300 border-slate-200 dark:border-[#22352f] hover:border-emerald-500'
              }`}
            >
              <Globe className="w-3.5 h-3.5" />
              <span>بحث ويب مباشر (Google Grounding)</span>
              <span className={`text-[10px] px-1.5 py-0.2 rounded font-mono ${
                isSearchGroundingEnabled || aiMode === 'hybrid' ? 'bg-emerald-700 text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
              }`}>
                {isSearchGroundingEnabled || aiMode === 'hybrid' ? 'مفعّل' : 'معطّل'}
              </span>
            </button>

            {/* Voice Dictation Switch */}
            <button
              type="button"
              onClick={toggleVoiceInput}
              className={`px-3 py-1.5 rounded-xl border flex items-center gap-2 text-xs font-medium transition-all cursor-pointer ${
                isListening
                  ? 'bg-red-500 text-white border-red-600 animate-pulse'
                  : 'bg-slate-50 dark:bg-[#182622] text-slate-700 dark:text-slate-300 border-slate-200 dark:border-[#22352f] hover:border-teal-500'
              }`}
            >
              {isListening ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5 text-teal-600" />}
              <span>{isListening ? 'إيقاف التسجيل الصوتي' : 'تحدث بسؤالك عبر الصوت'}</span>
            </button>
          </div>

          {/* Smart Follow-up Tips if available */}
          {!isGenerating && hasLastAiMessage && smartTips.length > 0 && (
            <div className="mt-2.5 pt-2 border-t border-slate-100 dark:border-[#1c2c26]">
              <div className="text-[11px] font-bold text-teal-800 dark:text-teal-300 mb-1.5 flex items-center gap-1">
                <span>أسئلة ومسائل مقترحة للمتابعة:</span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {smartTips.slice(0, 3).map((tip: string, idx: number) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      setIsToolsOpen(false);
                      onSendMessage(tip);
                    }}
                    className="text-right text-xs px-2.5 py-1 rounded-xl bg-slate-50 dark:bg-[#182622] hover:bg-teal-600 hover:text-white dark:hover:bg-teal-600 text-slate-700 dark:text-slate-200 border border-teal-200/60 dark:border-teal-800/40 shadow-2xs transition-all cursor-pointer truncate max-w-full"
                  >
                    {tip}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Voice Error Notification */}
      {speechError && (
        <div className="mb-2 p-2 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900 rounded-xl text-xs text-amber-800 dark:text-amber-200 flex items-center gap-2 animate-in fade-in">
          <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
          <span>{speechError}</span>
        </div>
      )}

      {/* Voice Active Alert */}
      {isListening && (
        <div className="mb-2 p-2 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 rounded-xl flex items-center justify-between text-xs text-red-700 dark:text-red-300 animate-pulse">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-red-600 animate-ping" />
            <span className="font-bold">الميكروفون نشط: تحدث بسؤالك باللغة العربية الآن...</span>
          </div>
          <button
            type="button"
            onClick={toggleVoiceInput}
            className="text-xs font-bold text-red-600 hover:underline cursor-pointer"
          >
            إيقاف
          </button>
        </div>
      )}

      {/* Zero-Clutter Modern Chat Input Bar */}
      <form
        onSubmit={handleSubmit}
        className="relative flex items-end gap-1.5 sm:gap-2 bg-slate-50/95 dark:bg-[#14221d] rounded-3xl border border-slate-200/90 dark:border-[#22352f] p-1.5 sm:p-2 focus-within:border-teal-600 dark:focus-within:border-teal-400 focus-within:ring-2 focus-within:ring-teal-500/10 transition-all shadow-xs"
      >
        {/* Progressive Disclosure (+) Tools Trigger */}
        <button
          type="button"
          onClick={() => setIsToolsOpen(!isToolsOpen)}
          className={`relative w-9 h-9 rounded-2xl flex items-center justify-center transition-all shrink-0 cursor-pointer ${
            isToolsOpen
              ? 'bg-teal-600 text-white shadow-xs rotate-45'
              : 'text-slate-500 dark:text-slate-400 hover:text-teal-700 dark:hover:text-teal-300 hover:bg-white dark:hover:bg-[#1a2d26]'
          }`}
          title={isToolsOpen ? 'إغلاق الأدوات' : 'أدوات إضافية وخيارات البحث والذكاء الاصطناعي (+)'}
        >
          <Plus className="w-4 h-4 transition-transform duration-200" />
          {/* Subtle indicator dot if search grounding is active */}
          {(isSearchGroundingEnabled || aiMode === 'hybrid') && !isToolsOpen && (
            <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-emerald-500 border border-white dark:border-[#14221d]" />
          )}
        </button>

        {/* Growing Input Textarea */}
        <textarea
          ref={textareaRef}
          rows={1}
          value={input}
          onChange={handleInputChange}
          onFocus={() => {
            setTimeout(() => {
              textareaRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
            }, 100);
          }}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing && e.keyCode !== 229) {
              e.preventDefault();
              handleSubmit();
            }
          }}
          placeholder={
            aiMode === 'general'
              ? 'اطرح أي سؤال في العلوم، صياغة المقالات، استشارات المذاكرة... (Shift+Enter لسطر جديد)'
              : 'اسأل المعلم الذكي عن أي مفهوم أو مسألة في مراجعك المرفوعة... (Shift+Enter لسطر جديد)'
          }
          className="flex-1 bg-transparent px-2 py-1.5 text-xs sm:text-sm text-slate-800 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none resize-none max-h-52 min-h-[38px] leading-relaxed"
        />

        {/* Quick Voice Mic Button */}
        <button
          type="button"
          onClick={toggleVoiceInput}
          className={`w-9 h-9 rounded-2xl flex items-center justify-center transition-all shrink-0 cursor-pointer ${
            isListening
              ? 'bg-red-500 text-white animate-bounce shadow-md shadow-red-500/30'
              : 'text-slate-400 hover:text-teal-700 dark:hover:text-teal-300 hover:bg-white dark:hover:bg-[#1a2d26]'
          }`}
          title={isListening ? 'إيقاف التسجيل' : 'تحدث بسؤالك عبر الميكروفون'}
        >
          {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
        </button>

        {/* Action Trigger (Stop or Send) */}
        {isGenerating ? (
          <button
            type="button"
            onClick={onStop}
            className="px-3 h-9 bg-rose-500 hover:bg-rose-600 text-white rounded-2xl shadow-md shadow-rose-500/20 transition-all flex items-center gap-1.5 text-xs font-bold shrink-0 animate-pulse cursor-pointer"
            title="إيقاف التوليد"
          >
            <StopCircle className="w-4 h-4" />
            <span className="hidden sm:inline">إيقاف</span>
          </button>
        ) : (
          <button
            type="submit"
            disabled={!input.trim()}
            className="w-9 h-9 bg-teal-600 hover:bg-teal-700 disabled:opacity-30 disabled:hover:bg-teal-600 text-white rounded-2xl shadow-md shadow-teal-600/20 transition-all flex items-center justify-center shrink-0 active:scale-95 cursor-pointer"
            title="إرسال السؤال"
          >
            <Send className="w-4 h-4" />
          </button>
        )}
      </form>
    </footer>
  );
});
