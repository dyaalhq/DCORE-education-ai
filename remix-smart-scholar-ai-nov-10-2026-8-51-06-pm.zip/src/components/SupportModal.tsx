import React, { useState } from 'react';
import { Mail, Send, CheckCircle2, AlertCircle, X, ExternalLink, Clock, MessageSquare, Sparkles } from 'lucide-react';
import { SupportedLanguage, t } from '../lib/i18n';

export interface SupportModalProps {
  isOpen: boolean;
  onClose: () => void;
  userProfile?: { displayName: string; email: string } | null;
  currentLang?: SupportedLanguage;
}

export interface SupportTicketRecord {
  id: string;
  date: number;
  subject: string;
  category: string;
  message: string;
  recipient: string;
}

const SUPPORT_EMAIL = 'dyaalhqsbyqa10@gmail.com';
const TICKETS_STORAGE_KEY = 'almoallim_support_tickets_v1';

export const SupportModal: React.FC<SupportModalProps> = ({
  isOpen,
  onClose,
  userProfile,
  currentLang = 'ar',
}) => {
  const [name, setName] = useState(userProfile?.displayName || '');
  const [email, setEmail] = useState(userProfile?.email || '');
  const [category, setCategory] = useState<'inquiry' | 'suggestion' | 'bug' | 'other'>('inquiry');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [sentSuccess, setSentSuccess] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'form' | 'history'>('form');
  const [ticketsHistory, setTicketsHistory] = useState<SupportTicketRecord[]>(() => {
    try {
      const raw = localStorage.getItem(TICKETS_STORAGE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  });

  if (!isOpen) return null;

  const categoryLabels = {
    inquiry: currentLang === 'ar' ? 'استفسار دراسي / أكاديمي' : 'Academic Inquiry',
    suggestion: currentLang === 'ar' ? 'اقتراح ميزة وتطوير' : 'Feature Suggestion',
    bug: currentLang === 'ar' ? 'إبلاغ عن مشكلة فنية' : 'Bug Report',
    other: currentLang === 'ar' ? 'استفسار عام' : 'General Support',
  };

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) {
      setErrorMsg(currentLang === 'ar' ? 'يرجى كتابة نص الرسالة أولاً' : 'Please enter your message');
      return;
    }

    setIsSending(true);
    setErrorMsg(null);

    const payload = {
      name: name.trim() || (userProfile?.displayName ?? 'طالب المعلم الذكي'),
      email: email.trim() || (userProfile?.email ?? 'غير محدد'),
      category: categoryLabels[category],
      subject: subject.trim() || 'رسالة استفسار ودعم من منصة المعلم الذكي',
      message: message.trim(),
      systemInfo: `المتصفح: ${navigator.userAgent.slice(0, 80)} | دقة الشاشة: ${window.innerWidth}x${window.innerHeight}`,
    };

    try {
      const res = await fetch('/api/support/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await res.json().catch(() => ({}));

      if (res.ok && data.success) {
        const ticketId = data.ticketId || `SUP-${Date.now().toString().slice(-6)}`;
        setSentSuccess(data.message || `تم إرسال رسالتك بنجاح إلى فريق الدعم (${SUPPORT_EMAIL}) برقم تذكرة #${ticketId}`);

        // Save to tickets history in localStorage
        const newRecord: SupportTicketRecord = {
          id: ticketId,
          date: Date.now(),
          subject: payload.subject,
          category: payload.category,
          message: payload.message,
          recipient: SUPPORT_EMAIL,
        };
        const updatedHistory = [newRecord, ...ticketsHistory];
        setTicketsHistory(updatedHistory);
        try {
          localStorage.setItem(TICKETS_STORAGE_KEY, JSON.stringify(updatedHistory.slice(0, 20)));
        } catch {}

        setMessage('');
        setSubject('');
      } else {
        throw new Error(data.error || 'تعذر إرسال الرسالة عبر الخادم');
      }
    } catch (err: any) {
      console.warn('Support API send error, offering direct mail fallback:', err);
      // Even if network fails, register locally and provide mailto link
      const fallbackTicketId = `SUP-LOCAL-${Date.now().toString().slice(-4)}`;
      const newRecord: SupportTicketRecord = {
        id: fallbackTicketId,
        date: Date.now(),
        subject: payload.subject,
        category: payload.category,
        message: payload.message,
        recipient: SUPPORT_EMAIL,
      };
      const updatedHistory = [newRecord, ...ticketsHistory];
      setTicketsHistory(updatedHistory);
      try {
        localStorage.setItem(TICKETS_STORAGE_KEY, JSON.stringify(updatedHistory.slice(0, 20)));
      } catch {}

      setSentSuccess(`تم حفظ رسالتك محلياً وتجهيزها للإرسال إلى (${SUPPORT_EMAIL}). اضغط بالأسفل لفتح تطبيق بريدك مباشرة.`);
    } finally {
      setIsSending(false);
    }
  };

  const mailtoUrl = `mailto:${SUPPORT_EMAIL}?subject=${encodeURIComponent(
    `[المعلم الذكي - ${categoryLabels[category]}] ${subject || 'رسالة دعم'}`
  )}&body=${encodeURIComponent(
    `الاسم: ${name || 'طالب'}\nالبريد: ${email || 'لم يحدد'}\nالنوع: ${categoryLabels[category]}\n\nنص الرسالة:\n${message}\n\n---\nأرسلت من منصة المعلم الذكي`
  )}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="bg-white dark:bg-[#121c18] border border-slate-200 dark:border-[#22352f] rounded-3xl w-full max-w-xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
        dir={currentLang === 'ar' ? 'rtl' : 'ltr'}
      >
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 dark:border-[#1d2d27] flex items-center justify-between bg-gradient-to-r from-teal-500/10 via-emerald-500/5 to-transparent">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-teal-600 text-white flex items-center justify-center shadow-md shadow-teal-600/20 font-bold shrink-0">
              <Mail className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-base sm:text-lg text-slate-800 dark:text-slate-100">
                {currentLang === 'ar' ? 'تواصل مع الدعم الفني والتطوير' : 'Contact Support & Development'}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {currentLang === 'ar' ? 'رسالتك تصل مباشرة إلى:' : 'Your message is sent directly to:'}{' '}
                <span className="font-mono font-bold text-teal-600 dark:text-teal-400 text-[11px] underline">
                  {SUPPORT_EMAIL}
                </span>
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-[#1a2723] transition-colors cursor-pointer"
            aria-label="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Subtabs */}
        <div className="px-5 pt-3 pb-1 border-b border-slate-100 dark:border-[#1d2d27] flex gap-2">
          <button
            type="button"
            onClick={() => { setActiveTab('form'); setSentSuccess(null); }}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'form'
                ? 'bg-teal-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-[#1a2723]'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>{currentLang === 'ar' ? 'كتابة رسالة جديدة' : 'New Message'}</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('history')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'history'
                ? 'bg-teal-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-[#1a2723]'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>{currentLang === 'ar' ? `سجل الرسائل (${ticketsHistory.length})` : `History (${ticketsHistory.length})`}</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4 flex-1">
          {sentSuccess ? (
            <div className="p-5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 text-center space-y-4 animate-in fade-in duration-200">
              <div className="w-14 h-14 rounded-full bg-emerald-500 text-white mx-auto flex items-center justify-center shadow-lg shadow-emerald-500/20">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <div className="space-y-1.5">
                <h4 className="font-extrabold text-base text-emerald-900 dark:text-emerald-100">
                  {currentLang === 'ar' ? 'تم استلام وإرسال رسالتك بنجاح!' : 'Message Sent Successfully!'}
                </h4>
                <p className="text-xs text-emerald-700 dark:text-emerald-300 leading-relaxed max-w-md mx-auto">
                  {sentSuccess}
                </p>
                <div className="text-[11px] text-slate-500 pt-1">
                  المستلم: <b className="font-mono text-teal-700 dark:text-teal-300">{SUPPORT_EMAIL}</b>
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => { setSentSuccess(null); setActiveTab('form'); }}
                  className="px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold transition-colors cursor-pointer"
                >
                  {currentLang === 'ar' ? 'إرسال رسالة أخرى' : 'Send Another Message'}
                </button>
                <a
                  href={mailtoUrl}
                  className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-[#1a2723] hover:bg-slate-200 dark:hover:bg-[#20302b] text-slate-700 dark:text-slate-200 text-xs font-bold transition-colors inline-flex items-center gap-1.5"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>{currentLang === 'ar' ? 'فتح تطبيق البريد' : 'Open Mail Client'}</span>
                </a>
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-600 dark:text-slate-400 text-xs font-bold hover:bg-slate-50 transition-colors cursor-pointer"
                >
                  {currentLang === 'ar' ? 'إغلاق النافذة' : 'Close'}
                </button>
              </div>
            </div>
          ) : activeTab === 'form' ? (
            <form onSubmit={handleSend} className="space-y-3.5">
              {errorMsg && (
                <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-300 text-xs text-red-700 dark:text-red-300 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{errorMsg}</span>
                </div>
              )}

              {/* Name & Email */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    {currentLang === 'ar' ? 'اسمك الكريم' : 'Your Name'}
                  </label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder={currentLang === 'ar' ? 'اسم الطالب أو المستخدم' : 'Full Name'}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-[#22352f] bg-slate-50 dark:bg-[#172520] text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:border-teal-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    {currentLang === 'ar' ? 'بريدك الإلكتروني (للرد عليك) *' : 'Your Email *'}
                  </label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="student@example.com"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-[#22352f] bg-slate-50 dark:bg-[#172520] text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:border-teal-500 font-mono"
                  />
                </div>
              </div>

              {/* Category selector */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  {currentLang === 'ar' ? 'نوع الرسالة أو الاستفسار' : 'Category'}
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                  {(['inquiry', 'suggestion', 'bug', 'other'] as const).map((cat) => (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setCategory(cat)}
                      className={`p-2 rounded-xl text-xs font-bold text-center border transition-all cursor-pointer ${
                        category === cat
                          ? 'bg-teal-50 dark:bg-teal-950/60 border-teal-600 text-teal-800 dark:text-teal-200 shadow-2xs'
                          : 'border-slate-200 dark:border-[#22352f] bg-slate-50/50 dark:bg-[#16231e] text-slate-600 dark:text-slate-400 hover:border-teal-400'
                      }`}
                    >
                      {categoryLabels[cat]}
                    </button>
                  ))}
                </div>
              </div>

              {/* Subject */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  {currentLang === 'ar' ? 'موضوع الرسالة' : 'Subject'}
                </label>
                <input
                  type="text"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder={currentLang === 'ar' ? 'ملخص موجز لطلبك أو استفسارك...' : 'Brief summary...'}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-[#22352f] bg-slate-50 dark:bg-[#172520] text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:border-teal-500"
                />
              </div>

              {/* Detailed Message Textarea */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                    {currentLang === 'ar' ? 'تفاصيل الرسالة أو الاستفسار *' : 'Message Details *'}
                  </label>
                  <span className="text-[10px] text-slate-400">
                    {message.length} {currentLang === 'ar' ? 'حرف' : 'chars'}
                  </span>
                </div>
                <textarea
                  required
                  rows={5}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder={
                    currentLang === 'ar'
                      ? 'اكتب رسالتك واستفسارك بالتفصيل هنا... سيتلقاها المشرف مباشرة على dyaalhqsbyqa10@gmail.com وسنرد على بريدك.'
                      : 'Write your message in detail here. It will be sent directly to dyaalhqsbyqa10@gmail.com...'
                  }
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-[#22352f] bg-slate-50 dark:bg-[#172520] text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:border-teal-500 resize-none leading-relaxed"
                />
              </div>

              {/* Target info reminder */}
              <div className="p-2.5 rounded-xl bg-teal-50/70 dark:bg-teal-950/30 border border-teal-200/60 dark:border-teal-800/60 flex items-center justify-between text-[11px] text-teal-800 dark:text-teal-300">
                <span className="flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-teal-600 shrink-0" />
                  <span>تأكيد الوجهة: يتم الإرسال إلى <b>{SUPPORT_EMAIL}</b></span>
                </span>
                <span className="font-semibold text-emerald-600 dark:text-emerald-400">فوري ومؤمن ✦</span>
              </div>

              {/* Submit Button */}
              <div className="flex items-center justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2.5 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-[#1a2723] transition-colors cursor-pointer"
                >
                  {currentLang === 'ar' ? 'إلغاء' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  disabled={isSending || !message.trim()}
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-teal-700 via-teal-600 to-emerald-600 hover:from-teal-800 hover:to-emerald-700 text-white text-xs font-bold transition-all shadow-md shadow-teal-700/20 disabled:opacity-40 flex items-center gap-2 cursor-pointer active:scale-95"
                >
                  <Send className={`w-3.5 h-3.5 ${isSending ? 'animate-bounce' : ''}`} />
                  <span>
                    {isSending
                      ? (currentLang === 'ar' ? 'جاري الإرسال للدعم...' : 'Sending...')
                      : (currentLang === 'ar' ? 'إرسال الرسالة للدعم الآن' : 'Send Message Now')}
                  </span>
                </button>
              </div>
            </form>
          ) : (
            /* Tickets History Tab */
            <div className="space-y-3">
              {ticketsHistory.length === 0 ? (
                <div className="text-center py-8 text-slate-400 text-xs">
                  {currentLang === 'ar' ? 'لم تقم بإرسال أي رسائل دعم حتى الآن.' : 'No sent messages yet.'}
                </div>
              ) : (
                ticketsHistory.map((t) => (
                  <div
                    key={t.id}
                    className="p-3.5 rounded-2xl border border-slate-200 dark:border-[#22352f] bg-slate-50/60 dark:bg-[#16231f] space-y-1.5"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-mono font-bold text-teal-700 dark:text-teal-400">
                        #{t.id}
                      </span>
                      <span className="text-[10px] text-slate-400">
                        {new Date(t.date).toLocaleDateString(currentLang === 'ar' ? 'ar-EG' : 'en-US', {
                          year: 'numeric',
                          month: 'short',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>
                    </div>
                    <div className="text-xs font-bold text-slate-800 dark:text-slate-100">
                      {t.subject}
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-300 line-clamp-3 leading-relaxed">
                      {t.message}
                    </p>
                    <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1 border-t border-slate-200/50 dark:border-slate-800/50">
                      <span>الفئة: {t.category}</span>
                      <span>المرسل إليه: {t.recipient}</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
