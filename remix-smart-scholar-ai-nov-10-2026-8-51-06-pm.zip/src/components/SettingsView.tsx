import React from 'react';
import { AccountView, AccountViewProps } from './AccountView';

export type SettingsViewProps = AccountViewProps;

export const SettingsView: React.FC<SettingsViewProps> = (props) => {
  return <AccountView {...props} />;
};
