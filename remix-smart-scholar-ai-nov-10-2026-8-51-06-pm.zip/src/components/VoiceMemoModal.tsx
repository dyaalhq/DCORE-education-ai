import React, { useState, useRef, useEffect } from 'react';
import {
  Mic,
  MicOff,
  Square,
  Sparkles,
  X,
  AlertCircle,
  Loader2,
  Save,
  Check,
  Copy,
  RotateCcw,
  Volume2
} from 'lucide-react';
import { MemoItem, Notebook } from '../types';

interface VoiceMemoModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentNotebook: Notebook;
  onSaveMemo: (memoText: string) => void;
  onNavigateToStudioMemos?: () => void;
}

type RecordingState = 'idle' | 'recording' | 'paused' | 'transcribing' | 'success' | 'error';

export const VoiceMemoModal: React.FC<VoiceMemoModalProps> = ({
  isOpen,
  onClose,
  currentNotebook,
  onSaveMemo,
  onNavigateToStudioMemos,
}) => {
  const [recordingState, setRecordingState] = useState<RecordingState>('idle');
  const [durationSeconds, setDurationSeconds] = useState<number>(0);
  const [transcribedText, setTranscribedText] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [isCopied, setIsCopied] = useState<boolean>(false);
  const [audioLevel, setAudioLevel] = useState<number>(0);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [mimeTypeUsed, setMimeTypeUsed] = useState<string>('audio/webm');

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animFrameRef = useRef<number | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);

  // Clean up all streams and timers on unmount or close
  const cleanupRecording = () => {
    if (timerIntervalRef.current) {
      clearInterval(timerIntervalRef.current);
      timerIntervalRef.current = null;
    }
    if (animFrameRef.current) {
      cancelAnimationFrame(animFrameRef.current);
      animFrameRef.current = null;
    }
    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
      audioContextRef.current.close().catch(() => {});
      audioContextRef.current = null;
    }
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      mediaStreamRef.current = null;
    }
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      try {
        mediaRecorderRef.current.stop();
      } catch {
        // Ignore inactive stop error
      }
      mediaRecorderRef.current = null;
    }
  };

  useEffect(() => {
    if (!isOpen) {
      cleanupRecording();
      setRecordingState('idle');
      setDurationSeconds(0);
      setTranscribedText('');
      setErrorMessage('');
      setAudioLevel(0);
    }
    return () => {
      cleanupRecording();
    };
  }, [isOpen]);

  // Audio visualizer loop
  const startAudioVisualizer = (stream: MediaStream) => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const audioCtx = new AudioCtx();
      audioContextRef.current = audioCtx;
      const analyser = audioCtx.createAnalyser();
      analyser.fftSize = 64;
      analyserRef.current = analyser;

      const source = audioCtx.createMediaStreamSource(stream);
      source.connect(analyser);

      const dataArray = new Uint8Array(analyser.frequencyBinCount);
      const updateLevel = () => {
        if (!analyserRef.current) return;
        analyserRef.current.getByteFrequencyData(dataArray);
        let sum = 0;
        for (let i = 0; i < dataArray.length; i++) {
          sum += dataArray[i];
        }
        const avg = sum / dataArray.length;
        setAudioLevel(Math.min(100, Math.round((avg / 255) * 100)));
        animFrameRef.current = requestAnimationFrame(updateLevel);
      };
      updateLevel();
    } catch (e) {
      console.warn('Audio visualization not supported:', e);
    }
  };

  // Start Voice Recording
  const handleStartRecording = async () => {
    setErrorMessage('');
    setTranscribedText('');
    audioChunksRef.current = [];
    setDurationSeconds(0);

    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setRecordingState('error');
      setErrorMessage('متصفحك لا يدعم الوصول المباشر إلى الميكروفون (getUserMedia).');
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });
      mediaStreamRef.current = stream;

      // Select supported audio MIME type
      let mimeType = 'audio/webm';
      if (typeof MediaRecorder.isTypeSupported === 'function') {
        if (MediaRecorder.isTypeSupported('audio/webm;codecs=opus')) {
          mimeType = 'audio/webm;codecs=opus';
        } else if (MediaRecorder.isTypeSupported('audio/webm')) {
          mimeType = 'audio/webm';
        } else if (MediaRecorder.isTypeSupported('audio/mp4')) {
          mimeType = 'audio/mp4';
        } else if (MediaRecorder.isTypeSupported('audio/ogg')) {
          mimeType = 'audio/ogg';
        }
      }

      const recorder = new MediaRecorder(stream, mimeType ? { mimeType } : undefined);
      mediaRecorderRef.current = recorder;

      recorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      recorder.onstop = () => {
        const cleanMime = (mimeType || 'audio/webm').split(';')[0];
        const blob = new Blob(audioChunksRef.current, { type: cleanMime });
        const url = URL.createObjectURL(blob);
        setAudioBlob(blob);
        setAudioUrl(url);
        setMimeTypeUsed(cleanMime);
        transcribeAudioBlob(blob, cleanMime);
      };

      recorder.start(500); // chunk every 500ms
      setRecordingState('recording');
      startAudioVisualizer(stream);

      // Start duration counter
      timerIntervalRef.current = setInterval(() => {
        setDurationSeconds((prev) => prev + 1);
      }, 1000);
    } catch (err: any) {
      console.error('Microphone access error:', err);
      setRecordingState('error');
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        setErrorMessage('تم رفض الإذن للوصول إلى الميكروفون. يرجى تفعيل إذن الميكروفون في المتصفح لاستخدام التسجيل الصوتي.');
      } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
        setErrorMessage('لم يتم العثور على ميكروفون متصل بجهازك.');
      } else {
        setErrorMessage(err.message || 'تعذر تشغيل الميكروفون وتسجيل الصوت.');
      }
    }
  };

  // Stop Recording and trigger transcription
  const handleStopRecording = () => {
    if (timerIntervalRef.current) {
      clearInterval(timerIntervalRef.current);
      timerIntervalRef.current = null;
    }
    if (animFrameRef.current) {
      cancelAnimationFrame(animFrameRef.current);
      animFrameRef.current = null;
    }
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      mediaStreamRef.current = null;
    }
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      setRecordingState('transcribing');
      mediaRecorderRef.current.stop();
    }
  };

  // Transcribe Blob with Gemini Audio API (/api/transcribe-audio)
  const transcribeAudioBlob = async (blob: Blob, mimeType: string) => {
    setRecordingState('transcribing');
    try {
      // Convert blob to Base64
      const reader = new FileReader();
      const base64Promise = new Promise<string>((resolve, reject) => {
        reader.onloadend = () => {
          const res = reader.result as string;
          resolve(res);
        };
        reader.onerror = reject;
      });
      reader.readAsDataURL(blob);
      const base64Audio = await base64Promise;

      const response = await fetch('/api/transcribe-audio', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          audioBase64: base64Audio,
          mimeType: mimeType || 'audio/webm',
          fileName: `ملاحظة صوتية - دفتر ${currentNotebook.name}`,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `خطأ في الخادم (${response.status}) أثناء تفريغ الصوت.`);
      }

      const data = await response.json();
      if (!data.success || !data.text) {
        throw new Error(data.error || 'لم يتم استخراج نص من التسجيل الصوتي.');
      }

      const text = data.text.trim();
      setTranscribedText(text);
      setRecordingState('success');

      // Automatically save as MemoItem in the current notebook
      onSaveMemo(text);
    } catch (err: any) {
      console.error('Transcription error:', err);
      // Fallback: If Web Speech Recognition API is available, try local speech recognition note
      setRecordingState('error');
      setErrorMessage(err.message || 'تعذر تفريغ الصوت عبر Gemini. تأكد من جودة الصوت واتصالك بالإنترنت.');
    }
  };

  // Format seconds to mm:ss
  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remSecs = secs % 60;
    return `${mins.toString().padStart(2, '0')}:${remSecs.toString().padStart(2, '0')}`;
  };

  // Copy text helper
  const handleCopy = () => {
    if (transcribedText) {
      navigator.clipboard.writeText(transcribedText);
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2000);
    }
  };

  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200"
    >
      <div className="bg-white dark:bg-[#14201c] w-full max-w-lg rounded-3xl border border-[#e2e8e5] dark:border-[#22352f] shadow-2xl flex flex-col overflow-hidden text-right">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-[#e2e8e5] dark:border-[#22352f] flex items-center justify-between gap-3 bg-[#f6f8f7] dark:bg-[#1a2723]">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-10 h-10 rounded-2xl bg-teal-500/15 text-teal-600 dark:text-teal-400 flex items-center justify-center shrink-0 border border-teal-500/30">
              <Mic className="w-5 h-5 animate-pulse" />
            </div>
            <div className="min-w-0">
              <h3 className="text-sm sm:text-base font-black text-[#17201e] dark:text-[#eef7f4] truncate">
                تسجيل ملاحظة صوتية (Speech-to-Text)
              </h3>
              <p className="text-[11px] text-[#596762] dark:text-[#9ab3ab] truncate">
                تفريغ الصوت بدقة فائقة بالذكاء الاصطناعي وحفظه في «{currentNotebook.name}»
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-xl bg-gray-200 dark:bg-gray-800 hover:bg-rose-500 hover:text-white text-gray-600 dark:text-gray-300 flex items-center justify-center transition-colors cursor-pointer shrink-0"
            title="إغلاق"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-6 text-center">
          {/* Status Display Container */}
          {recordingState === 'idle' && (
            <div className="space-y-4 py-6">
              <div className="w-24 h-24 rounded-full bg-teal-500/10 dark:bg-teal-500/20 text-teal-600 dark:text-teal-400 mx-auto flex items-center justify-center border-2 border-dashed border-teal-500/40">
                <Mic className="w-10 h-10" />
              </div>
              <div>
                <h4 className="text-base font-bold text-[#17201e] dark:text-[#eef7f4]">
                  جاهز لتسجيل ملاحظتك الصوتية
                </h4>
                <p className="text-xs text-[#596762] dark:text-[#9ab3ab] max-w-sm mx-auto mt-1 leading-relaxed">
                  تحدث بحرية باللغة العربية أو الإنجليزية لشرح فكرة، تدوين تلخيص، أو تسجيل خاطرة دراسية. سيقوم Gemini بتحويل كلامك فوراً إلى نص منظم.
                </p>
              </div>

              <button
                type="button"
                onClick={handleStartRecording}
                className="px-6 py-3 rounded-2xl bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 text-white font-black text-sm shadow-lg transition-all cursor-pointer flex items-center justify-center gap-2 mx-auto active:scale-98"
              >
                <Mic className="w-5 h-5" />
                <span>بدء التسجيل الآن</span>
              </button>
            </div>
          )}

          {recordingState === 'recording' && (
            <div className="space-y-5 py-4 animate-in fade-in">
              {/* Animated Waveform & Timer */}
              <div className="relative w-28 h-28 mx-auto flex items-center justify-center">
                <div
                  className="absolute inset-0 rounded-full bg-rose-500/20 animate-ping"
                  style={{ animationDuration: '2s' }}
                />
                <div
                  className="w-24 h-24 rounded-full bg-rose-500 text-white flex items-center justify-center shadow-xl transition-transform"
                  style={{ transform: `scale(${1 + (audioLevel / 250)})` }}
                >
                  <Mic className="w-10 h-10 animate-pulse" />
                </div>
              </div>

              {/* Dynamic Equalizer Bars */}
              <div className="flex items-center justify-center gap-1.5 h-8">
                {[12, 24, 38, 20, 45, 30, 16, 40, 22, 34, 18].map((height, i) => (
                  <div
                    key={i}
                    className="w-1.5 bg-rose-500 rounded-full transition-all duration-75"
                    style={{
                      height: `${Math.max(6, Math.min(32, height * (0.3 + (audioLevel / 100))))}px`,
                      opacity: audioLevel > 5 ? 1 : 0.4,
                    }}
                  />
                ))}
              </div>

              <div>
                <div className="text-3xl font-black font-mono text-rose-600 dark:text-rose-400 tracking-wider">
                  {formatTime(durationSeconds)}
                </div>
                <p className="text-xs text-[#596762] dark:text-[#9ab3ab] mt-1 font-medium">
                  جارٍ الاستماع وتسجيل صوتك بوضوح...
                </p>
              </div>

              <div className="flex items-center justify-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={handleStopRecording}
                  className="px-6 py-2.5 rounded-2xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-md transition-all cursor-pointer flex items-center gap-2 active:scale-95"
                >
                  <Square className="w-4 h-4 fill-current" />
                  <span>إيقاف وتفريغ النص</span>
                </button>

                <button
                  type="button"
                  onClick={cleanupRecording}
                  className="px-4 py-2.5 rounded-2xl bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300 font-bold text-xs transition-all cursor-pointer"
                >
                  إلغاء
                </button>
              </div>
            </div>
          )}

          {recordingState === 'transcribing' && (
            <div className="space-y-4 py-8 animate-in fade-in">
              <div className="w-20 h-20 rounded-3xl bg-teal-500/10 dark:bg-teal-500/20 text-teal-600 dark:text-teal-400 mx-auto flex items-center justify-center">
                <Loader2 className="w-10 h-10 animate-spin text-teal-600" />
              </div>
              <div className="space-y-1">
                <h4 className="text-base font-bold text-[#17201e] dark:text-[#eef7f4] flex items-center justify-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-500 animate-spin" />
                  <span>تفريغ الصوت بالذكاء الاصطناعي (Gemini)</span>
                </h4>
                <p className="text-xs text-[#596762] dark:text-[#9ab3ab] max-w-sm mx-auto">
                  يتم الآن تحليل المقطع الصوتي واستخراج الكلمات والمصطلحات الأكاديمية بدقة متناهية...
                </p>
              </div>
            </div>
          )}

          {recordingState === 'success' && (
            <div className="space-y-4 animate-in fade-in text-right">
              <div className="flex items-center justify-between pb-2 border-b border-emerald-500/20">
                <div className="flex items-center gap-2 text-xs font-bold text-emerald-700 dark:text-emerald-400">
                  <Check className="w-4 h-4 text-emerald-600" />
                  <span>تم تفريغ الملاحظة وحفظها كـ MemoItem بنجاح!</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={handleCopy}
                    className="p-1.5 rounded-lg text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors cursor-pointer text-xs flex items-center gap-1"
                    title="نسخ النص"
                  >
                    {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{isCopied ? 'تم النسخ' : 'نسخ'}</span>
                  </button>
                </div>
              </div>

              {/* Playable Recorded Audio Preview */}
              {audioUrl && (
                <div className="p-3 rounded-2xl bg-teal-50/70 dark:bg-teal-950/40 border border-teal-200/80 dark:border-teal-800/60 space-y-1.5">
                  <div className="flex items-center justify-between text-[11px] font-bold text-teal-800 dark:text-teal-300">
                    <span className="flex items-center gap-1.5">
                      <Volume2 className="w-3.5 h-3.5 text-teal-600" />
                      <span>المقطع الصوتي المسجل ({formatTime(durationSeconds)}):</span>
                    </span>
                    {audioBlob && (
                      <button
                        type="button"
                        onClick={() => transcribeAudioBlob(audioBlob, mimeTypeUsed)}
                        className="text-teal-700 dark:text-teal-300 hover:underline flex items-center gap-1 text-[10px] font-bold cursor-pointer"
                      >
                        <RotateCcw className="w-3 h-3" />
                        <span>إعادة التفريغ بالذكاء الاصطناعي</span>
                      </button>
                    )}
                  </div>
                  <audio src={audioUrl} controls className="w-full h-8 rounded-lg" />
                </div>
              )}

              {/* Editable transcribed text */}
              <div className="relative">
                <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                  النص المفرغ من صوتك (يمكنك التعديل والإضافة عليه):
                </label>
                <textarea
                  value={transcribedText}
                  onChange={(e) => setTranscribedText(e.target.value)}
                  className="w-full h-32 p-3.5 rounded-2xl bg-[#f6f8f7] dark:bg-[#1a2723] border border-[#e2e8e5] dark:border-[#22352f] text-xs sm:text-sm text-[#17201e] dark:text-[#eef7f4] leading-relaxed resize-none focus:outline-none focus:ring-2 focus:ring-teal-500"
                  dir="auto"
                />
              </div>

              <div className="flex flex-wrap items-center justify-between gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    if (transcribedText.trim()) {
                      onSaveMemo(transcribedText.trim());
                    }
                    onClose();
                  }}
                  className="px-5 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs shadow-sm transition-all cursor-pointer flex items-center gap-1.5"
                >
                  <Save className="w-4 h-4" />
                  <span>حفظ التعديلات وإغلاق</span>
                </button>

                <div className="flex items-center gap-2">
                  {onNavigateToStudioMemos && (
                    <button
                      type="button"
                      onClick={() => {
                        onClose();
                        onNavigateToStudioMemos();
                      }}
                      className="px-3.5 py-2.5 rounded-xl bg-gray-100 dark:bg-[#1a2723] hover:bg-teal-50 text-teal-700 dark:text-teal-300 font-bold text-xs transition-all cursor-pointer"
                    >
                      عرض في استوديو الملاحظات
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={handleStartRecording}
                    className="px-3.5 py-2.5 rounded-xl border border-gray-200 dark:border-gray-800 hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-700 dark:text-gray-300 font-bold text-xs transition-all cursor-pointer flex items-center gap-1"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>تسجيل ملاحظة أخرى</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {recordingState === 'error' && (
            <div className="space-y-4 py-4 animate-in fade-in text-center">
              <div className="w-16 h-16 rounded-2xl bg-rose-500/10 text-rose-600 mx-auto flex items-center justify-center">
                <AlertCircle className="w-8 h-8" />
              </div>
              <div className="space-y-1">
                <h4 className="text-sm font-bold text-rose-700 dark:text-rose-400">
                  حدث تعذر أثناء تفريغ التسجيل الصوتي
                </h4>
                <p className="text-xs text-gray-600 dark:text-gray-300 max-w-sm mx-auto leading-relaxed">
                  {errorMessage}
                </p>
              </div>

              {/* Audio Player if audio was recorded despite transcription failure */}
              {audioUrl && (
                <div className="p-3 rounded-2xl bg-slate-50 dark:bg-[#1a2723] border border-slate-200 dark:border-slate-800 max-w-sm mx-auto text-right space-y-1">
                  <span className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block">
                    المقطع الصوتي تم حفظه بنجاح، يمكنك الاستماع إليه:
                  </span>
                  <audio src={audioUrl} controls className="w-full h-8" />
                </div>
              )}

              <div className="flex items-center justify-center gap-2 pt-2">
                {audioBlob && (
                  <button
                    type="button"
                    onClick={() => transcribeAudioBlob(audioBlob, mimeTypeUsed)}
                    className="px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs transition-all cursor-pointer flex items-center gap-1.5"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>إعادة محاولة التفريغ عبر Gemini</span>
                  </button>
                )}
                <button
                  type="button"
                  onClick={handleStartRecording}
                  className="px-4 py-2 rounded-xl border border-gray-200 dark:border-gray-800 hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-700 dark:text-gray-300 font-bold text-xs transition-all cursor-pointer flex items-center gap-1.5"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>تسجيل جديد</span>
                </button>
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 rounded-xl bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300 font-bold text-xs transition-all cursor-pointer"
                >
                  إغلاق
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
