import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  X,
  ChevronRight,
  ChevronLeft,
  Search,
  Type,
  Maximize2,
  Minimize2,
  Volume2,
  VolumeX,
  Play,
  Pause,
  RotateCcw,
  Sparkles,
  Copy,
  Check,
  BookOpen,
  Eye,
  Sliders,
  Sun,
  Moon,
  AlignJustify,
  Layers,
  ArrowRight,
  Bookmark
} from 'lucide-react';
import { Source, SourceChunk } from '../types';
import { ensureDocumentPages } from '../lib/annotationMatcher';

export type HighContrastTheme =
  | 'contrast-black-white'
  | 'contrast-white-black'
  | 'contrast-yellow-black'
  | 'contrast-green-black'
  | 'sepia'
  | 'paper';

export type ReaderLineHeight = 'compact' | 'standard' | 'relaxed' | 'accessible';
export type ReaderColumnWidth = 'narrow' | 'medium' | 'wide' | 'full';
export type ReaderFontFamily = 'font-amiri' | 'font-tajawal' | 'font-cairo' | 'font-sans';

export interface AccessibleReaderViewProps {
  source: Source;
  chunks?: SourceChunk[];
  initialPage?: number;
  onClose: () => void;
  onAskAboutQuote?: (quote: string, pageNumber: number) => void;
  onExportToNote?: (title: string, content: string) => void;
}

export const AccessibleReaderView: React.FC<AccessibleReaderViewProps> = ({
  source,
  chunks = [],
  initialPage = 1,
  onClose,
  onAskAboutQuote,
  onExportToNote,
}) => {
  // 1. Pages normalization
  const documentPages = useMemo(() => {
    return ensureDocumentPages(source.content, source.pages);
  }, [source.content, source.pages]);

  const totalPages = Math.max(1, documentPages.length, source.pageCount || 1);

  // 2. Navigation State
  const [currentPage, setCurrentPage] = useState<number>(() => {
    return Math.min(Math.max(1, initialPage), totalPages);
  });
  const [readingMode, setReadingMode] = useState<'paginated' | 'continuous'>('paginated');

  // 3. Accessibility & High-Contrast Typography State
  const [theme, setTheme] = useState<HighContrastTheme>(() => {
    // Check saved preference or default to high-contrast dark for maximum eye comfort
    const saved = localStorage.getItem('nb_reader_theme');
    return (saved as HighContrastTheme) || 'contrast-black-white';
  });

  const [fontSize, setFontSize] = useState<number>(() => {
    const saved = localStorage.getItem('nb_reader_font_size');
    return saved ? parseInt(saved, 10) : 20; // 20px accessible default
  });

  const [lineHeight, setLineHeight] = useState<ReaderLineHeight>(() => {
    const saved = localStorage.getItem('nb_reader_line_height');
    return (saved as ReaderLineHeight) || 'relaxed'; // 2.2x accessible default
  });

  const [columnWidth, setColumnWidth] = useState<ReaderColumnWidth>('medium');
  const [fontFamily, setFontFamily] = useState<ReaderFontFamily>('font-tajawal');
  const [showReadingRuler, setShowReadingRuler] = useState<boolean>(false);
  const [rulerY, setRulerY] = useState<number>(200);

  // 4. In-Document Quick Search
  const [isSearchOpen, setIsSearchOpen] = useState<boolean>(false);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [activeMatchIndex, setActiveMatchIndex] = useState<number>(0);

  // 5. Speech Synthesis (Text-to-Speech)
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [speechRate, setSpeechRate] = useState<number>(1.0);
  const speechUtteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  // 6. Selection & Popover
  const [selectedText, setSelectedText] = useState<string>('');
  const [selectionPage, setSelectionPage] = useState<number>(currentPage);
  const [toastMsg, setToastMsg] = useState<string>('');

  // 7. Accessibility Controls Drawer / Toolbar visibility
  const [showControlsDrawer, setShowControlsDrawer] = useState<boolean>(false);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Save preferences
  useEffect(() => {
    localStorage.setItem('nb_reader_theme', theme);
  }, [theme]);

  useEffect(() => {
    localStorage.setItem('nb_reader_font_size', fontSize.toString());
  }, [fontSize]);

  useEffect(() => {
    localStorage.setItem('nb_reader_line_height', lineHeight);
  }, [lineHeight]);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(''), 2500);
  };

  // Keyboard Navigation: Arrows, Escape, Spacebar
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't intercept if user is typing in an input
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement)?.tagName)) {
        return;
      }

      if (e.key === 'Escape') {
        if (isSearchOpen) {
          setIsSearchOpen(false);
        } else if (showControlsDrawer) {
          setShowControlsDrawer(false);
        } else {
          onClose();
        }
      } else if (e.key === 'ArrowLeft' || e.key === 'PageDown') {
        // Next page
        setCurrentPage((prev) => Math.min(totalPages, prev + 1));
      } else if (e.key === 'ArrowRight' || e.key === 'PageUp') {
        // Previous page
        setCurrentPage((prev) => Math.max(1, prev - 1));
      } else if (e.key === ' ' && !e.shiftKey) {
        // Spacebar to advance
        e.preventDefault();
        setCurrentPage((prev) => Math.min(totalPages, prev + 1));
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [totalPages, isSearchOpen, showControlsDrawer, onClose]);

  // Current Page Data
  const currentPageItem = useMemo(() => {
    return documentPages.find((p) => p.pageNumber === currentPage) || documentPages[0] || { pageNumber: 1, text: '' };
  }, [documentPages, currentPage]);

  // Search Matches across all pages
  const searchMatches = useMemo(() => {
    if (!searchTerm.trim()) return [];
    const term = searchTerm.trim().toLowerCase();
    const matches: Array<{ pageNumber: number; snippet: string; index: number }> = [];

    documentPages.forEach((p) => {
      const lower = p.text.toLowerCase();
      let pos = lower.indexOf(term);
      while (pos !== -1) {
        const start = Math.max(0, pos - 30);
        const end = Math.min(p.text.length, pos + term.length + 30);
        matches.push({
          pageNumber: p.pageNumber,
          snippet: p.text.slice(start, end),
          index: pos,
        });
        pos = lower.indexOf(term, pos + 1);
      }
    });

    return matches;
  }, [documentPages, searchTerm]);

  const handleNextMatch = () => {
    if (searchMatches.length === 0) return;
    const nextIdx = (activeMatchIndex + 1) % searchMatches.length;
    setActiveMatchIndex(nextIdx);
    const target = searchMatches[nextIdx];
    setCurrentPage(target.pageNumber);
  };

  const handlePrevMatch = () => {
    if (searchMatches.length === 0) return;
    const prevIdx = (activeMatchIndex - 1 + searchMatches.length) % searchMatches.length;
    setActiveMatchIndex(prevIdx);
    const target = searchMatches[prevIdx];
    setCurrentPage(target.pageNumber);
  };

  // Text Selection
  const handleMouseUp = () => {
    const sel = window.getSelection();
    if (!sel || sel.isCollapsed) {
      setSelectedText('');
      return;
    }
    const txt = sel.toString().trim();
    if (txt.length >= 2) {
      setSelectedText(txt);
      setSelectionPage(currentPage);
    }
  };

  // Reading Ruler cursor follower
  const handleMouseMove = (e: React.MouseEvent) => {
    if (showReadingRuler) {
      setRulerY(e.clientY);
    }
  };

  // Text-To-Speech Functions
  const handleStartSpeech = (textToRead?: string) => {
    if (!('speechSynthesis' in window)) {
      showToast('المتصفح الحالي لا يدعم القراءة الصوتية');
      return;
    }

    window.speechSynthesis.cancel();
    const rawText = textToRead || currentPageItem.text;
    if (!rawText.trim()) return;

    // Clean up markers like [الصفحة 1]
    const cleanText = rawText.replace(/\[الصفحة \d+[^\]]*\]/g, '').trim();

    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.lang = 'ar-SA';
    utterance.rate = speechRate;

    utterance.onend = () => {
      setIsSpeaking(false);
      setIsPaused(false);
    };

    utterance.onerror = () => {
      setIsSpeaking(false);
      setIsPaused(false);
    };

    speechUtteranceRef.current = utterance;
    window.speechSynthesis.speak(utterance);
    setIsSpeaking(true);
    setIsPaused(false);
  };

  const handlePauseResumeSpeech = () => {
    if (!('speechSynthesis' in window)) return;

    if (isPaused) {
      window.speechSynthesis.resume();
      setIsPaused(false);
      setIsSpeaking(true);
    } else if (isSpeaking) {
      window.speechSynthesis.pause();
      setIsPaused(true);
    }
  };

  const handleStopSpeech = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setIsSpeaking(false);
    setIsPaused(false);
  };

  // Clean up speech on unmount
  useEffect(() => {
    return () => {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  // Theme Styling Configuration
  const themeStyles = useMemo(() => {
    switch (theme) {
      case 'contrast-black-white':
        // Pitch Black & Pure White (Maximum Accessibility Dark)
        return {
          bg: 'bg-black',
          text: 'text-white',
          border: 'border-neutral-800',
          card: 'bg-black border border-neutral-800 shadow-none',
          accent: 'text-sky-400',
          accentBg: 'bg-sky-500 text-black',
          toolbar: 'bg-neutral-950 border-neutral-800 text-white',
          mark: 'bg-sky-400 text-black font-extrabold px-1 rounded-xs',
          ruler: 'bg-sky-400/25 border-y border-sky-400',
        };
      case 'contrast-white-black':
        // Pure White & Jet Black (Maximum Accessibility Light)
        return {
          bg: 'bg-white',
          text: 'text-black',
          border: 'border-black',
          card: 'bg-white border-2 border-black shadow-none',
          accent: 'text-black font-extrabold',
          accentBg: 'bg-black text-white font-bold',
          toolbar: 'bg-neutral-100 border-black text-black',
          mark: 'bg-yellow-300 text-black font-extrabold px-1 rounded-xs border border-black',
          ruler: 'bg-yellow-300/30 border-y-2 border-black',
        };
      case 'contrast-yellow-black':
        // Vivid Yellow on Black (Low Vision Standard)
        return {
          bg: 'bg-black',
          text: 'text-yellow-300',
          border: 'border-yellow-600',
          card: 'bg-black border border-yellow-700/80 shadow-none',
          accent: 'text-yellow-400',
          accentBg: 'bg-yellow-400 text-black font-black',
          toolbar: 'bg-neutral-950 border-yellow-800 text-yellow-300',
          mark: 'bg-yellow-400 text-black font-black px-1 rounded-xs',
          ruler: 'bg-yellow-400/20 border-y border-yellow-400',
        };
      case 'contrast-green-black':
        // Soft Neon Green on Black (Photophobia & Eye Fatigue)
        return {
          bg: 'bg-black',
          text: 'text-emerald-300',
          border: 'border-emerald-800',
          card: 'bg-black border border-emerald-900 shadow-none',
          accent: 'text-emerald-400',
          accentBg: 'bg-emerald-400 text-black font-bold',
          toolbar: 'bg-neutral-950 border-emerald-900 text-emerald-300',
          mark: 'bg-emerald-400 text-black font-black px-1 rounded-xs',
          ruler: 'bg-emerald-400/20 border-y border-emerald-400',
        };
      case 'sepia':
        // Warm Book Sepia
        return {
          bg: 'bg-[#fbf0d9]',
          text: 'text-[#432818]',
          border: 'border-[#dfc69f]',
          card: 'bg-[#f5e7ce] border border-[#dfc69f] shadow-xs',
          accent: 'text-[#8b4513]',
          accentBg: 'bg-[#8b4513] text-white',
          toolbar: 'bg-[#f2dec1] border-[#dfc69f] text-[#432818]',
          mark: 'bg-[#e2b978] text-[#2b170c] font-bold px-1 rounded-xs',
          ruler: 'bg-[#8b4513]/15 border-y border-[#8b4513]/50',
        };
      case 'paper':
      default:
        // Academic Paper Soft Dark
        return {
          bg: 'bg-[#0f172a]',
          text: 'text-slate-100',
          border: 'border-slate-800',
          card: 'bg-[#1e293b] border border-slate-700/80 shadow-md',
          accent: 'text-teal-400',
          accentBg: 'bg-teal-500 text-slate-950 font-bold',
          toolbar: 'bg-[#1e293b] border-slate-700 text-slate-100',
          mark: 'bg-amber-400 text-slate-950 font-bold px-1 rounded-xs',
          ruler: 'bg-teal-400/20 border-y border-teal-400',
        };
    }
  }, [theme]);

  // Line Height class and style
  const lineHeightValue = useMemo(() => {
    switch (lineHeight) {
      case 'compact':
        return 1.5;
      case 'standard':
        return 1.9;
      case 'relaxed':
        return 2.3;
      case 'accessible':
        return 2.7;
    }
  }, [lineHeight]);

  // Column width class
  const columnWidthClass = useMemo(() => {
    switch (columnWidth) {
      case 'narrow':
        return 'max-w-2xl'; // ~65ch
      case 'medium':
        return 'max-w-3xl'; // ~80ch
      case 'wide':
        return 'max-w-5xl'; // ~100ch
      case 'full':
        return 'max-w-full px-4 sm:px-10';
    }
  }, [columnWidth]);

  // Reading Progress Percentage
  const progressPercent = Math.round((currentPage / totalPages) * 100);

  // Render text with search highlighting
  const renderTextContent = (text: string) => {
    if (!searchTerm.trim()) {
      return text;
    }

    const term = searchTerm.trim().toLowerCase();
    const parts: React.ReactNode[] = [];
    let lastIdx = 0;
    const lower = text.toLowerCase();
    let pos = lower.indexOf(term);

    while (pos !== -1) {
      if (pos > lastIdx) {
        parts.push(text.slice(lastIdx, pos));
      }
      parts.push(
        <mark key={`m-${pos}`} className={themeStyles.mark}>
          {text.slice(pos, pos + term.length)}
        </mark>
      );
      lastIdx = pos + term.length;
      pos = lower.indexOf(term, lastIdx);
    }

    if (lastIdx < text.length) {
      parts.push(text.slice(lastIdx));
    }

    return parts;
  };

  return (
    <div
      ref={containerRef}
      onMouseMove={handleMouseMove}
      className={`fixed inset-0 z-50 flex flex-col select-text ${themeStyles.bg} ${themeStyles.text} ${fontFamily} transition-colors duration-200 overflow-hidden`}
      dir="rtl"
    >
      {/* Toast Feedback */}
      {toastMsg && (
        <div className="fixed top-14 left-1/2 -translate-x-1/2 z-[70] px-4 py-2 bg-neutral-900 text-white text-xs font-bold rounded-full shadow-2xl border border-neutral-700 animate-in fade-in slide-in-from-top-3 flex items-center gap-2">
          <Check className="w-4 h-4 text-emerald-400" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* Visual Focus Reading Ruler */}
      {showReadingRuler && (
        <div
          className={`fixed left-0 right-0 pointer-events-none z-30 transition-transform duration-75 ${themeStyles.ruler}`}
          style={{
            top: `${rulerY - 18}px`,
            height: `${fontSize * lineHeightValue + 16}px`,
          }}
        />
      )}

      {/* Reading Progress Top Bar */}
      <div className="w-full h-1 bg-neutral-800/40 relative z-40">
        <div
          className="h-full bg-gradient-to-l from-teal-500 to-sky-400 transition-all duration-300"
          style={{ width: `${progressPercent}%` }}
        />
      </div>

      {/* Top Distraction-Free Header Bar */}
      <header
        className={`px-3 sm:px-6 py-2.5 border-b ${themeStyles.border} ${themeStyles.toolbar} flex items-center justify-between gap-3 shrink-0 z-40`}
      >
        {/* Document Info & Clutter-Free Exit */}
        <div className="flex items-center gap-2.5 truncate">
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl hover:bg-black/15 dark:hover:bg-white/10 text-inherit transition-colors cursor-pointer flex items-center gap-1.5 font-bold text-xs"
            title="خروج من وضع القارئ المريح (Esc)"
          >
            <ArrowRight className="w-4 h-4" />
            <span className="hidden sm:inline">العودة للدفتر</span>
          </button>

          <span className="opacity-30">|</span>

          <div className="flex items-center gap-2 truncate">
            <span className="p-1 rounded-lg bg-teal-500/20 text-teal-400 shrink-0">
              <BookOpen className="w-3.5 h-3.5" />
            </span>
            <h1 className="font-bold text-xs sm:text-sm truncate max-w-[200px] sm:max-w-md">
              {source.title}
            </h1>
            <span className="hidden md:inline px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-neutral-800/60 border border-neutral-700/60 text-neutral-300">
              {readingMode === 'paginated' ? `صفحة ${currentPage} من ${totalPages}` : `سرد كامل (${totalPages} صفحة)`}
            </span>
          </div>
        </div>

        {/* Central Controls: Audio, Search, Quick Paging */}
        <div className="flex items-center gap-1.5">
          {/* Text-To-Speech Playback */}
          <div className="flex items-center bg-black/10 dark:bg-white/5 border border-black/15 dark:border-white/10 rounded-xl p-0.5">
            {!isSpeaking ? (
              <button
                type="button"
                onClick={() => handleStartSpeech()}
                className="px-2.5 py-1 rounded-lg hover:bg-black/10 dark:hover:bg-white/10 font-bold text-xs flex items-center gap-1.5 cursor-pointer text-emerald-400"
                title="قراءة صوتية ذكية للصفحة الحالية"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span className="hidden sm:inline">استماع</span>
              </button>
            ) : (
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={handlePauseResumeSpeech}
                  className="p-1 rounded-lg hover:bg-black/10 dark:hover:bg-white/10 text-amber-400"
                  title={isPaused ? 'استئناف القراءة' : 'إيقاف مؤقت'}
                >
                  {isPaused ? <Play className="w-3.5 h-3.5" /> : <Pause className="w-3.5 h-3.5" />}
                </button>
                <button
                  type="button"
                  onClick={handleStopSpeech}
                  className="p-1 rounded-lg hover:bg-black/10 dark:hover:bg-white/10 text-red-400"
                  title="إنهاء الاستماع"
                >
                  <VolumeX className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
          </div>

          {/* Quick Light / Dark Mode Toggle */}
          <button
            type="button"
            onClick={() => {
              if (theme === 'contrast-white-black' || theme === 'sepia') {
                setTheme('contrast-black-white');
              } else {
                setTheme('contrast-white-black');
              }
            }}
            className="p-1.5 rounded-xl border border-black/15 dark:border-white/10 hover:bg-black/10 dark:hover:bg-white/10 transition-colors cursor-pointer text-inherit"
            title={theme === 'contrast-white-black' || theme === 'sepia' ? 'التبديل إلى الوضع الداكن عالي التباين' : 'التبديل إلى الوضع الفاتح عالي التباين'}
          >
            {theme === 'contrast-white-black' || theme === 'sepia' ? (
              <Moon className="w-4 h-4 text-sky-400" />
            ) : (
              <Sun className="w-4 h-4 text-amber-400" />
            )}
          </button>

          {/* Quick Font Size Controls (A- / A+) */}
          <div className="hidden sm:flex items-center bg-black/10 dark:bg-white/5 border border-black/15 dark:border-white/10 rounded-xl p-0.5 text-xs font-bold">
            <button
              type="button"
              onClick={() => setFontSize((s) => Math.max(14, s - 2))}
              className="px-2 py-1 rounded-lg hover:bg-black/10 dark:hover:bg-white/10 cursor-pointer"
              title="تصغير حجم الخط"
            >
              A-
            </button>
            <span className="px-1.5 font-mono text-[11px] text-teal-400 font-bold">{fontSize}px</span>
            <button
              type="button"
              onClick={() => setFontSize((s) => Math.min(38, s + 2))}
              className="px-2 py-1 rounded-lg hover:bg-black/10 dark:hover:bg-white/10 cursor-pointer"
              title="تكبير حجم الخط (حتى 38px)"
            >
              A+
            </button>
          </div>

          {/* Quick Line Spacing Switcher */}
          <button
            type="button"
            onClick={() => {
              const order: ReaderLineHeight[] = ['compact', 'standard', 'relaxed', 'accessible'];
              const next = order[(order.indexOf(lineHeight) + 1) % order.length];
              setLineHeight(next);
            }}
            className="hidden sm:flex items-center gap-1 px-2 py-1 rounded-xl border border-black/15 dark:border-white/10 hover:bg-black/10 dark:hover:bg-white/10 text-[11px] font-bold cursor-pointer text-inherit"
            title="تغيير تباعد الأسطر"
          >
            <AlignJustify className="w-3.5 h-3.5" />
            <span>{lineHeightValue}x</span>
          </button>

          {/* Search in Document Toggle */}
          <button
            type="button"
            onClick={() => setIsSearchOpen(!isSearchOpen)}
            className={`p-1.5 rounded-xl border border-black/15 dark:border-white/10 transition-colors cursor-pointer ${
              isSearchOpen || searchTerm
                ? 'bg-amber-400 text-black font-bold'
                : 'hover:bg-black/10 dark:hover:bg-white/10 text-inherit'
            }`}
            title="بحث فوري داخل نص الكتاب"
          >
            <Search className="w-4 h-4" />
          </button>

          {/* Quick Page Navigator */}
          {readingMode === 'paginated' && (
            <div className="flex items-center bg-black/10 dark:bg-white/5 border border-black/15 dark:border-white/10 rounded-xl p-0.5 text-xs font-bold">
              <button
                type="button"
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                disabled={currentPage <= 1}
                className="p-1 rounded-lg hover:bg-black/10 dark:hover:bg-white/10 disabled:opacity-30 cursor-pointer"
                title="الصفحة السابقة (السهم الأيمن)"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
              <div className="px-1.5 flex items-center gap-1 text-[11px]">
                <input
                  type="number"
                  min={1}
                  max={totalPages}
                  value={currentPage}
                  onChange={(e) => {
                    const val = parseInt(e.target.value, 10);
                    if (!isNaN(val)) setCurrentPage(Math.min(totalPages, Math.max(1, val)));
                  }}
                  className="w-10 text-center py-0.5 bg-transparent border-b border-current font-bold text-xs"
                />
                <span className="opacity-60">/ {totalPages}</span>
              </div>
              <button
                type="button"
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                disabled={currentPage >= totalPages}
                className="p-1 rounded-lg hover:bg-black/10 dark:hover:bg-white/10 disabled:opacity-30 cursor-pointer"
                title="الصفحة التالية (السهم الأيسر)"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Accessibility Settings Drawer Toggle */}
          <button
            type="button"
            onClick={() => setShowControlsDrawer(!showControlsDrawer)}
            className={`px-3 py-1.5 rounded-xl border border-black/15 dark:border-white/10 flex items-center gap-1.5 text-xs font-bold transition-all cursor-pointer ${
              showControlsDrawer
                ? 'bg-teal-500 text-black shadow-md'
                : 'hover:bg-black/10 dark:hover:bg-white/10 text-inherit'
            }`}
            title="تخصيص الخط والتباين والمسافات (إمكانية الوصول)"
          >
            <Sliders className="w-3.5 h-3.5" />
            <span className="hidden md:inline">خيارات القراءة والتباين</span>
          </button>
        </div>
      </header>

      {/* Search Input Bar (Dropdown) */}
      {isSearchOpen && (
        <div className={`px-4 py-2 border-b ${themeStyles.border} ${themeStyles.toolbar} flex items-center justify-between gap-3 animate-in slide-in-from-top-2 duration-150`}>
          <div className="flex items-center gap-2 flex-1 max-w-lg">
            <Search className="w-4 h-4 opacity-50 shrink-0" />
            <input
              type="text"
              autoFocus
              placeholder="ابحث عن أي مصطلح أو كلمة في صفحات الكتاب..."
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setActiveMatchIndex(0);
              }}
              className="w-full bg-transparent text-xs sm:text-sm focus:outline-none placeholder-current placeholder-opacity-40"
            />
            {searchTerm && (
              <span className="text-[11px] font-mono px-2 py-0.5 rounded-md bg-black/20 text-inherit shrink-0">
                {searchMatches.length > 0
                  ? `${activeMatchIndex + 1} من ${searchMatches.length}`
                  : 'لا توجد نتائج'}
              </span>
            )}
          </div>

          <div className="flex items-center gap-1 shrink-0">
            <button
              type="button"
              onClick={handlePrevMatch}
              disabled={searchMatches.length <= 1}
              className="p-1 rounded-lg hover:bg-black/10 dark:hover:bg-white/10 disabled:opacity-30 cursor-pointer"
              title="النتيجة السابقة"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={handleNextMatch}
              disabled={searchMatches.length <= 1}
              className="p-1 rounded-lg hover:bg-black/10 dark:hover:bg-white/10 disabled:opacity-30 cursor-pointer"
              title="النتيجة التالية"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => {
                setSearchTerm('');
                setIsSearchOpen(false);
              }}
              className="p-1 rounded-lg hover:bg-black/10 dark:hover:bg-white/10 opacity-70 hover:opacity-100 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Accessible Reading Preferences Drawer (Slide-down Panel) */}
      {showControlsDrawer && (
        <div
          className={`border-b ${themeStyles.border} ${themeStyles.toolbar} p-4 sm:p-5 shadow-2xl animate-in slide-in-from-top-4 duration-200 z-40 max-h-[70vh] overflow-y-auto`}
        >
          <div className="max-w-4xl mx-auto space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-black/10 dark:border-white/10">
              <div className="flex items-center gap-2">
                <Sliders className="w-4 h-4 text-teal-400" />
                <h2 className="font-bold text-sm">لوحة التحكم في إمكانية الوصول وراحة القراءة (Accessibility & High Contrast)</h2>
              </div>
              <button
                type="button"
                onClick={() => setShowControlsDrawer(false)}
                className="p-1 rounded-lg hover:bg-black/10 dark:hover:bg-white/10 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Grid of Controls */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
              {/* 1. High Contrast Themes */}
              <div className="space-y-1.5">
                <label className="font-bold block opacity-80">أنماط التباين البصري العالي (Themes):</label>
                <div className="grid grid-cols-2 gap-1.5">
                  <button
                    type="button"
                    onClick={() => setTheme('contrast-black-white')}
                    className={`p-2 rounded-xl border text-center font-bold transition-all cursor-pointer ${
                      theme === 'contrast-black-white'
                        ? 'bg-neutral-900 text-white border-sky-400 ring-2 ring-sky-400'
                        : 'bg-black text-white border-neutral-700 hover:border-neutral-500'
                    }`}
                  >
                    أسود حالك & أبيض
                  </button>
                  <button
                    type="button"
                    onClick={() => setTheme('contrast-white-black')}
                    className={`p-2 rounded-xl border text-center font-bold transition-all cursor-pointer ${
                      theme === 'contrast-white-black'
                        ? 'bg-white text-black border-black ring-2 ring-black font-black'
                        : 'bg-white text-black border-neutral-300 hover:border-black'
                    }`}
                  >
                    أبيض ناصع & أسود
                  </button>
                  <button
                    type="button"
                    onClick={() => setTheme('contrast-yellow-black')}
                    className={`p-2 rounded-xl border text-center font-bold transition-all cursor-pointer ${
                      theme === 'contrast-yellow-black'
                        ? 'bg-black text-yellow-300 border-yellow-400 ring-2 ring-yellow-400'
                        : 'bg-black text-yellow-500 border-yellow-800 hover:border-yellow-600'
                    }`}
                  >
                    أصفر على أسود (ضعف البصر)
                  </button>
                  <button
                    type="button"
                    onClick={() => setTheme('contrast-green-black')}
                    className={`p-2 rounded-xl border text-center font-bold transition-all cursor-pointer ${
                      theme === 'contrast-green-black'
                        ? 'bg-black text-emerald-300 border-emerald-400 ring-2 ring-emerald-400'
                        : 'bg-black text-emerald-500 border-emerald-800 hover:border-emerald-600'
                    }`}
                  >
                    أخضر زمردي على أسود
                  </button>
                  <button
                    type="button"
                    onClick={() => setTheme('sepia')}
                    className={`p-2 rounded-xl border text-center font-bold transition-all cursor-pointer ${
                      theme === 'sepia'
                        ? 'bg-[#f5e7ce] text-[#432818] border-[#8b4513] ring-2 ring-[#8b4513]'
                        : 'bg-[#fbf0d9] text-[#432818] border-[#dfc69f]'
                    }`}
                  >
                    سيبيا كتاب دافئ
                  </button>
                  <button
                    type="button"
                    onClick={() => setTheme('paper')}
                    className={`p-2 rounded-xl border text-center font-bold transition-all cursor-pointer ${
                      theme === 'paper'
                        ? 'bg-slate-800 text-white border-teal-400 ring-2 ring-teal-400'
                        : 'bg-slate-900 text-slate-300 border-slate-700'
                    }`}
                  >
                    ليلي أكاديمي هادئ
                  </button>
                </div>
              </div>

              {/* 2. Font Size (Slider & Quick Steppers) */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="font-bold opacity-80">حجم الخط (Font Size):</label>
                  <span className="font-mono font-bold px-2 py-0.5 bg-black/20 rounded text-teal-400">
                    {fontSize}px
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setFontSize((s) => Math.max(14, s - 2))}
                    className="px-2.5 py-1.5 rounded-lg border border-current hover:bg-black/10 font-bold"
                    title="تصغير الخط"
                  >
                    A-
                  </button>
                  <input
                    type="range"
                    min={14}
                    max={38}
                    step={1}
                    value={fontSize}
                    onChange={(e) => setFontSize(parseInt(e.target.value, 10))}
                    className="w-full accent-teal-400 cursor-pointer"
                  />
                  <button
                    type="button"
                    onClick={() => setFontSize((s) => Math.min(38, s + 2))}
                    className="px-2.5 py-1.5 rounded-lg border border-current hover:bg-black/10 font-bold"
                    title="تكبير الخط"
                  >
                    A+
                  </button>
                </div>
                <p className="text-[10px] opacity-60">يدعم تكبير الخط حتى 38px للطلاب الذين يعانون من ضعف الرؤية.</p>
              </div>

              {/* 3. Line Height (تباعد الأسطر) */}
              <div className="space-y-1.5">
                <label className="font-bold block opacity-80">تباعد الأسطر (Line Height):</label>
                <div className="grid grid-cols-2 gap-1.5">
                  <button
                    type="button"
                    onClick={() => setLineHeight('compact')}
                    className={`p-2 rounded-xl border text-center font-bold transition-all cursor-pointer ${
                      lineHeight === 'compact' ? 'border-teal-400 bg-teal-500/20 text-teal-300' : 'border-black/20 dark:border-white/20'
                    }`}
                  >
                    مضغوط (1.5x)
                  </button>
                  <button
                    type="button"
                    onClick={() => setLineHeight('standard')}
                    className={`p-2 rounded-xl border text-center font-bold transition-all cursor-pointer ${
                      lineHeight === 'standard' ? 'border-teal-400 bg-teal-500/20 text-teal-300' : 'border-black/20 dark:border-white/20'
                    }`}
                  >
                    مريح قياسي (1.9x)
                  </button>
                  <button
                    type="button"
                    onClick={() => setLineHeight('relaxed')}
                    className={`p-2 rounded-xl border text-center font-bold transition-all cursor-pointer ${
                      lineHeight === 'relaxed' ? 'border-teal-400 bg-teal-500/20 text-teal-300' : 'border-black/20 dark:border-white/20'
                    }`}
                  >
                    واسع مريح (2.3x)
                  </button>
                  <button
                    type="button"
                    onClick={() => setLineHeight('accessible')}
                    className={`p-2 rounded-xl border text-center font-bold transition-all cursor-pointer ${
                      lineHeight === 'accessible' ? 'border-teal-400 bg-teal-500/20 text-teal-300' : 'border-black/20 dark:border-white/20'
                    }`}
                  >
                    فائق الاتساع (2.7x)
                  </button>
                </div>
                <p className="text-[10px] opacity-60">تباعد أوسع يساعد على تفادي تداخل الأسطر وصعوبات القراءة (Dyslexia).</p>
              </div>

              {/* 4. Reading Guide Ruler & Column Width */}
              <div className="space-y-1.5">
                <label className="font-bold block opacity-80">أدوات التركيز البصري:</label>
                <div className="space-y-2">
                  <button
                    type="button"
                    onClick={() => setShowReadingRuler(!showReadingRuler)}
                    className={`w-full p-2 rounded-xl border text-center font-bold flex items-center justify-center gap-2 cursor-pointer ${
                      showReadingRuler
                        ? 'border-amber-400 bg-amber-400 text-black font-extrabold shadow-sm'
                        : 'border-black/20 dark:border-white/20 hover:bg-black/5'
                    }`}
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>{showReadingRuler ? 'إيقاف مسطرة القراءة' : 'تفعيل مسطرة التركيز البصرية'}</span>
                  </button>

                  <div className="grid grid-cols-2 gap-1.5 pt-1">
                    <button
                      type="button"
                      onClick={() => setColumnWidth(columnWidth === 'narrow' ? 'wide' : 'narrow')}
                      className="p-1.5 rounded-lg border border-black/20 dark:border-white/20 text-center font-bold text-[11px]"
                    >
                      {columnWidth === 'narrow' ? 'عمود واسع' : 'عمود مريح (65ch)'}
                    </button>
                    <button
                      type="button"
                      onClick={() => setReadingMode(readingMode === 'paginated' ? 'continuous' : 'paginated')}
                      className="p-1.5 rounded-lg border border-black/20 dark:border-white/20 text-center font-bold text-[11px]"
                    >
                      {readingMode === 'paginated' ? 'سرد مستمر' : 'صفحة بصفحة'}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Main Reading Flow Container */}
      <main
        onMouseUp={handleMouseUp}
        onTouchEnd={handleMouseUp}
        className="flex-1 min-h-0 overflow-y-auto px-4 sm:px-8 py-6 sm:py-10 flex flex-col items-center select-text relative"
      >
        {readingMode === 'continuous' ? (
          /* Continuous All Pages View */
          <div className={`w-full ${columnWidthClass} space-y-10`}>
            {documentPages.map((page) => (
              <article
                key={`reader-p-${page.pageNumber}`}
                className={`p-6 sm:p-10 rounded-2xl ${themeStyles.card} transition-colors`}
              >
                <div className="flex items-center justify-between pb-3 mb-6 border-b border-black/10 dark:border-white/10 opacity-70 text-xs font-bold">
                  <span>الصفحة {page.pageNumber} من {totalPages}</span>
                  <button
                    type="button"
                    onClick={() => handleStartSpeech(page.text)}
                    className="hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <Volume2 className="w-3.5 h-3.5" />
                    <span>قراءة هذه الصفحة</span>
                  </button>
                </div>

                <div
                  style={{
                    fontSize: `${fontSize}px`,
                    lineHeight: lineHeightValue,
                  }}
                  className="whitespace-pre-wrap leading-relaxed select-text"
                >
                  {renderTextContent(page.text)}
                </div>
              </article>
            ))}
          </div>
        ) : (
          /* Paginated Single Page Clean View */
          <div className={`w-full ${columnWidthClass}`}>
            <article
              className={`p-6 sm:p-12 rounded-3xl ${themeStyles.card} transition-colors min-h-[70vh] flex flex-col justify-between`}
            >
              <div>
                {/* Page Header */}
                <div className="flex items-center justify-between pb-4 mb-6 border-b border-black/10 dark:border-white/10 opacity-75 text-xs font-bold">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded-lg bg-teal-500/20 text-teal-400 font-mono font-bold">
                      الصفحة {currentPageItem.pageNumber} / {totalPages}
                    </span>
                    <span className="hidden sm:inline opacity-60">|</span>
                    <span className="hidden sm:inline font-mono opacity-80">{progressPercent}% تم إنجازه</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleStartSpeech(currentPageItem.text)}
                      className="px-2.5 py-1 rounded-lg border border-black/15 dark:border-white/15 hover:bg-black/5 dark:hover:bg-white/10 flex items-center gap-1.5 transition-colors cursor-pointer text-xs"
                      title="استماع صوتي للصفحة الحالية"
                    >
                      <Volume2 className="w-3.5 h-3.5 text-emerald-400" />
                      <span>قراءة صوتية</span>
                    </button>
                  </div>
                </div>

                {/* Main Accessible Text Content */}
                <div
                  style={{
                    fontSize: `${fontSize}px`,
                    lineHeight: lineHeightValue,
                  }}
                  className="whitespace-pre-wrap leading-relaxed select-text font-normal tracking-wide"
                >
                  {renderTextContent(currentPageItem.text)}
                </div>
              </div>

              {/* Bottom Page Navigation Controls */}
              <div className="pt-8 mt-10 border-t border-black/10 dark:border-white/10 flex items-center justify-between gap-3 text-xs">
                <button
                  type="button"
                  onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                  disabled={currentPage <= 1}
                  className="px-4 py-2 rounded-xl border border-current hover:bg-black/10 dark:hover:bg-white/10 disabled:opacity-30 flex items-center gap-2 font-bold cursor-pointer transition-colors"
                >
                  <ChevronRight className="w-4 h-4" />
                  <span>الصفحة السابقة</span>
                </button>

                <div className="text-center font-mono opacity-70">
                  {currentPage} من {totalPages}
                </div>

                <button
                  type="button"
                  onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                  disabled={currentPage >= totalPages}
                  className="px-4 py-2 rounded-xl border border-current hover:bg-black/10 dark:hover:bg-white/10 disabled:opacity-30 flex items-center gap-2 font-bold cursor-pointer transition-colors"
                >
                  <span>الصفحة التالية</span>
                  <ChevronLeft className="w-4 h-4" />
                </button>
              </div>
            </article>
          </div>
        )}

        {/* Floating Quick Action for Text Selection */}
        {selectedText && (
          <div className="fixed bottom-8 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-2xl bg-neutral-900 text-white border border-neutral-700 shadow-2xl flex items-center gap-2 animate-in fade-in slide-in-from-bottom-3">
            <span className="text-xs text-neutral-300 font-bold max-w-[150px] truncate">
              «{selectedText}»
            </span>

            {onAskAboutQuote && (
              <button
                type="button"
                onClick={() => {
                  onAskAboutQuote(selectedText, selectionPage);
                  onClose();
                }}
                className="px-3 py-1 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-bold flex items-center gap-1 cursor-pointer shadow-sm"
              >
                <Sparkles className="w-3 h-3 text-purple-200" />
                <span>اسأل AI</span>
              </button>
            )}

            <button
              type="button"
              onClick={() => {
                const quoteText = `«${selectedText}» — [${source.title}، ص ${selectionPage}]`;
                navigator.clipboard.writeText(quoteText);
                showToast('تم نسخ الاقتباس الموثق');
                setSelectedText('');
              }}
              className="p-1.5 rounded-lg hover:bg-white/10 text-neutral-300 hover:text-white cursor-pointer"
              title="نسخ مع توثيق المرجع"
            >
              <Copy className="w-3.5 h-3.5" />
            </button>

            <button
              type="button"
              onClick={() => setSelectedText('')}
              className="p-1 rounded-lg hover:bg-white/10 text-neutral-400 hover:text-white cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </main>
    </div>
  );
};
