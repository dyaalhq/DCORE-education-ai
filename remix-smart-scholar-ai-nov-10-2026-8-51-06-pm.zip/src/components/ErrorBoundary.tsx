import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RotateCcw, Trash2, Home, CheckCircle2 } from 'lucide-react';
import { offlineDb } from '../lib/offlineDatabase';

interface Props {
  children: ReactNode;
  fallbackTitle?: string;
  onReset?: () => void;
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
  isRecovering: boolean;
  recoveryMessage: string | null;
}

export class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
    errorInfo: null,
    isRecovering: false,
    recoveryMessage: null,
  };

  public static getDerivedStateFromError(error: Error): State {
    return {
      hasError: true,
      error,
      errorInfo: null,
      isRecovering: false,
      recoveryMessage: null,
    };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('[ErrorBoundary Caught Fatal Error]:', error, errorInfo);
    this.setState({ errorInfo });
  }

  private handleSoftReset = () => {
    this.setState({ hasError: false, error: null, errorInfo: null });
    if (this.props.onReset) {
      this.props.onReset();
    } else {
      window.location.reload();
    }
  };

  private handleHardCleanRecovery = async () => {
    this.setState({ isRecovering: true, recoveryMessage: 'جارٍ تنظيف الذاكرة التالفة وإعادة بناء قاعدة البيانات...' });
    try {
      // 1. Purge potentially corrupted questions from IndexedDB
      try {
        await offlineDb.questions.clear();
      } catch (dbErr) {
        console.warn('Could not clear questions table, deleting database:', dbErr);
        await offlineDb.delete();
      }

      // 2. Clear corrupted local storage entries related to state
      localStorage.removeItem('yemeni_qb_bookmarks');
      sessionStorage.clear();

      this.setState({ recoveryMessage: 'تم إصلاح وتنظيف البيانات بنجاح! جارٍ إعادة تشغيل التطبيق...' });
      setTimeout(() => {
        window.location.reload();
      }, 1000);
    } catch (e) {
      console.error('Hard recovery failed:', e);
      this.setState({
        isRecovering: false,
        recoveryMessage: 'تمت المحاولة، يرجى النقر على زر إعادة التحميل الآن.',
      });
    }
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#f8faf9] dark:bg-[#0c1412] text-[#1c2a26] dark:text-[#eef7f4] flex items-center justify-center p-4" dir="rtl">
          <div className="max-w-xl w-full bg-white dark:bg-[#14201c] rounded-3xl border border-rose-200 dark:border-rose-900/50 p-6 sm:p-8 shadow-2xl space-y-6 text-right">
            {/* Header */}
            <div className="flex items-center gap-3 border-b border-gray-100 dark:border-gray-800 pb-4">
              <div className="w-12 h-12 rounded-2xl bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center shrink-0">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div>
                <h1 className="text-lg sm:text-xl font-black text-rose-700 dark:text-rose-400">
                  {this.props.fallbackTitle || 'تم تفادي خطأ في معالجة البيانات بنجاح'}
                </h1>
                <p className="text-xs text-gray-500 dark:text-gray-400 font-medium mt-0.5">
                  قام درع الحماية بالتقاط المشكلة لمنع توقف التطبيق أو تلف البيانات المخزنة
                </p>
              </div>
            </div>

            {/* Error Message Details */}
            <div className="p-4 rounded-2xl bg-rose-50/70 dark:bg-rose-950/30 border border-rose-200/60 dark:border-rose-800/40 text-xs font-mono space-y-2">
              <p className="font-bold text-rose-800 dark:text-rose-300 font-sans">
                تفاصيل الخطأ المسجل:
              </p>
              <p className="text-rose-600 dark:text-rose-400 break-words dir-ltr text-left">
                {this.state.error?.message || 'Unknown runtime error occurred.'}
              </p>
            </div>

            {/* Recovery Status Alert */}
            {this.state.recoveryMessage && (
              <div className="p-3.5 rounded-2xl bg-teal-50 dark:bg-teal-950/50 border border-teal-300/50 text-teal-800 dark:text-teal-300 text-xs font-bold flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0" />
                <span>{this.state.recoveryMessage}</span>
              </div>
            )}

            {/* Actions */}
            <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
              <button
                type="button"
                onClick={this.handleSoftReset}
                disabled={this.state.isRecovering}
                className="w-full sm:flex-1 py-3 px-4 rounded-xl bg-teal-600 hover:bg-teal-700 active:scale-98 text-white font-black text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md disabled:opacity-50"
              >
                <RotateCcw className="w-4 h-4" />
                <span>إعادة المحاولة الفورية</span>
              </button>

              <button
                type="button"
                onClick={this.handleHardCleanRecovery}
                disabled={this.state.isRecovering}
                className="w-full sm:flex-1 py-3 px-4 rounded-xl bg-gray-100 hover:bg-rose-50 dark:bg-[#1a2723] dark:hover:bg-rose-950/40 text-gray-700 hover:text-rose-700 dark:text-gray-300 dark:hover:text-rose-300 font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer border border-gray-200 dark:border-gray-800 disabled:opacity-50"
              >
                <Trash2 className="w-4 h-4 text-rose-500" />
                <span>تنظيف الذاكرة التالفة وإصلاح</span>
              </button>
            </div>

            <p className="text-[11px] text-gray-400 text-center">
              كافة مستنداتك وملاحظاتك الدراسية السليمة محفوظة بأمان ولن يتم حذفها.
            </p>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
