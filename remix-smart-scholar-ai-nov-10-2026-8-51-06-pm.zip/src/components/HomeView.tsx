import React, { useState, useEffect } from 'react';
import {
  BookOpen,
  MessageSquare,
  Sparkles,
  ArrowLeft,
  FlaskConical,
  Compass,
  GitFork,
  ChevronDown,
  ChevronUp,
  Layers,
  Calculator,
  Timer,
  Zap,
  FileQuestion,
  Award,
  Newspaper,
  CheckCircle2,
  Calendar,
  X,
  FileText
} from 'lucide-react';
import {
  Notebook,
  Source,
  SourceChunk,
  ChatSession,
  Flashcard,
  FocusSession,
  TodoItem,
  NoteItem,
} from '../types';
import { AppLogo } from './AppLogo';

interface HomeViewProps {
  currentNotebook: Notebook;
  sources: Source[];
  chunks: SourceChunk[];
  chatSession?: ChatSession;
  flashcards: Flashcard[];
  focusSessions: FocusSession[];
  todos?: TodoItem[];
  allNotes?: NoteItem[];
  allFlashcards?: Flashcard[];
  notebooks?: Notebook[];
  onToggleTodo?: (id: string) => void;
  onAddTodo?: (text: string, due?: string) => void;
  showTodayTasks?: boolean;
  onToggleShowTodayTasks?: (show: boolean) => void;
  onNavigateTab: (tab: string) => void;
  onAskAboutSource?: (source: Source) => void;
  onSendPromptToChat?: (prompt: string) => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  currentNotebook,
  sources,
  chunks,
  flashcards,
  focusSessions,
  allNotes = [],
  allFlashcards = [],
  notebooks = [],
  onNavigateTab,
}) => {
  const [showExtraTools, setShowExtraTools] = useState(false);
  const [digestDismissed, setDigestDismissed] = useState(false);

  // Daily Digest: track last login timestamp
  const [lastLoginTimestamp, setLastLoginTimestamp] = useState<number>(() => {
    try {
      const stored = localStorage.getItem('smart_teacher_last_login');
      if (stored) return Number(stored);
    } catch (e) {}
    return Date.now() - 24 * 60 * 60 * 1000;
  });

  const handleMarkDigestRead = () => {
    const now = Date.now();
    setLastLoginTimestamp(now);
    try {
      localStorage.setItem('smart_teacher_last_login', String(now));
    } catch (e) {}
    setDigestDismissed(true);
  };

  const effectiveAllNotes = allNotes.length > 0 ? allNotes : [];
  const effectiveAllCards = allFlashcards.length > 0 ? allFlashcards : flashcards;

  const newNotesSinceLogin = effectiveAllNotes.filter(
    (n) => (n.created || 0) > lastLoginTimestamp
  );
  const newCardsSinceLogin = effectiveAllCards.filter(
    (c) => ((c as any).createdAt || c.lastReviewed || 0) > lastLoginTimestamp || (c.level === 1 && (c.nextReview || 0) <= Date.now())
  );

  const displayedNotes = newNotesSinceLogin.length > 0
    ? newNotesSinceLogin
    : effectiveAllNotes.slice(0, 3);

  const displayedCardsCount = newCardsSinceLogin.length > 0
    ? newCardsSinceLogin.length
    : effectiveAllCards.length;

  const totalFocusMins = focusSessions.reduce((acc, s) => acc + (s.durationMins || 0), 0);

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-12 animate-in fade-in duration-200">

      {/* 1. Welcoming Hero Banner */}
      <section
        aria-label="لوحة الدفتر الدراسي"
        className="bg-gradient-to-br from-teal-900 via-teal-800 to-emerald-800 text-white rounded-3xl p-6 sm:p-7 shadow-md relative overflow-hidden border border-teal-600/30"
      >
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-5">
          <div className="flex items-center gap-3.5">
            <AppLogo size="lg" className="shrink-0 drop-shadow-sm" />
            <div className="space-y-1.5">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-[11px] font-extrabold px-2.5 py-0.5 rounded-full bg-white/15 text-teal-100 backdrop-blur-md">
                  دفتر التعلم: {currentNotebook.name}
                </span>
                <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-emerald-400/20 text-emerald-200">
                  {currentNotebook.subject || 'عام'}
                </span>
              </div>
              <h1 className="text-lg sm:text-xl font-black tracking-tight">
                منصة المعلم الذكي للدراسة والبحث
              </h1>
              <p className="text-xs text-teal-100/90 max-w-lg leading-relaxed">
                بيئة تعليمية رصينة لشرح المناهج خطوة بخطوة، حل المعادلات والمسائل، وهيكلة الخرائط الذهنية التفاعلية.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 2. Organized Rectangular Section Cards (Non-duplicated, Global-App Grid Architecture) */}
      <section className="space-y-3.5">
        <div className="flex items-center justify-between px-1">
          <h2 className="text-xs font-black text-slate-800 dark:text-slate-200 uppercase tracking-wider flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-teal-600"></span>
            <span>الأقسام ومساحات العمل المستقلة</span>
          </h2>
          <span className="text-[11px] text-slate-400">واجهات عمل مستقلة وسلسة</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {/* Card 1: Question Bank & Universal Encyclopedia */}
          <div
            onClick={() => onNavigateTab('question_bank')}
            className="p-3.5 sm:p-4 rounded-2xl bg-white dark:bg-[#14201c] border border-slate-200/90 dark:border-[#22352f] hover:border-teal-500 hover:shadow-md transition-all cursor-pointer group flex items-center justify-between gap-3 active:scale-[0.99]"
          >
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-10 h-10 rounded-xl bg-teal-50 dark:bg-teal-950/80 text-teal-700 dark:text-teal-300 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform shadow-2xs">
                <FileQuestion className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <h3 className="font-extrabold text-xs sm:text-sm text-slate-900 dark:text-slate-100 group-hover:text-teal-600 transition-colors truncate">
                    بنك الأسئلة والموسوعة
                  </h3>
                  <span className="text-[9px] font-bold px-1.5 py-0.2 rounded-md bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border border-emerald-200/50 dark:border-emerald-800/50 shrink-0">
                    وزاري + طبي + موسوعة
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate mt-0.5">
                  امتحانات مؤتمتة، بلكات سريرية، وموسوعة شاملة
                </p>
              </div>
            </div>
            <ArrowLeft className="w-4 h-4 text-slate-300 dark:text-slate-600 group-hover:text-teal-600 group-hover:-translate-x-1 transition-all shrink-0" />
          </div>

          {/* Card 2: Study Studio & Spaced Repetition */}
          <div
            onClick={() => onNavigateTab('studio')}
            className="p-3.5 sm:p-4 rounded-2xl bg-white dark:bg-[#14201c] border border-slate-200/90 dark:border-[#22352f] hover:border-teal-500 hover:shadow-md transition-all cursor-pointer group flex items-center justify-between gap-3 active:scale-[0.99]"
          >
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform shadow-2xs">
                <Sparkles className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <h3 className="font-extrabold text-xs sm:text-sm text-slate-900 dark:text-slate-100 group-hover:text-teal-600 transition-colors truncate">
                    استوديو المذاكرة والبطاقات
                  </h3>
                  <span className="text-[9px] font-bold px-1.5 py-0.2 rounded-md bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border border-emerald-200/50 dark:border-emerald-800/50 shrink-0">
                    ملخصات
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate mt-0.5">
                  بطاقات التكرار المتباعد، اختبارات سريعة، وملاحظات
                </p>
              </div>
            </div>
            <ArrowLeft className="w-4 h-4 text-slate-300 dark:text-slate-600 group-hover:text-teal-600 group-hover:-translate-x-1 transition-all shrink-0" />
          </div>

          {/* Card 3: 3D Science Lab */}
          <div
            onClick={() => onNavigateTab('science')}
            className="p-3.5 sm:p-4 rounded-2xl bg-white dark:bg-[#14201c] border border-slate-200/90 dark:border-[#22352f] hover:border-teal-500 hover:shadow-md transition-all cursor-pointer group flex items-center justify-between gap-3 active:scale-[0.99]"
          >
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-10 h-10 rounded-xl bg-cyan-50 dark:bg-cyan-950/80 text-cyan-700 dark:text-cyan-300 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform shadow-2xs">
                <FlaskConical className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <h3 className="font-extrabold text-xs sm:text-sm text-slate-900 dark:text-slate-100 group-hover:text-teal-600 transition-colors truncate">
                    المختبر العلمي 3D
                  </h3>
                  <span className="text-[9px] font-bold px-1.5 py-0.2 rounded-md bg-cyan-50 dark:bg-cyan-950 text-cyan-700 dark:text-cyan-300 border border-cyan-200/50 dark:border-cyan-800/50 shrink-0">
                    معمل تفاعلي
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate mt-0.5">
                  تجارب محاكاة فيزيائية، كيميائية، وأحياء وراثية
                </p>
              </div>
            </div>
            <ArrowLeft className="w-4 h-4 text-slate-300 dark:text-slate-600 group-hover:text-teal-600 group-hover:-translate-x-1 transition-all shrink-0" />
          </div>

          {/* Card 4: Dual Mind Map */}
          <div
            onClick={() => onNavigateTab('mindmap')}
            className="p-3.5 sm:p-4 rounded-2xl bg-white dark:bg-[#14201c] border border-slate-200/90 dark:border-[#22352f] hover:border-teal-500 hover:shadow-md transition-all cursor-pointer group flex items-center justify-between gap-3 active:scale-[0.99]"
          >
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-950/80 text-indigo-700 dark:text-indigo-300 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform shadow-2xs">
                <GitFork className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <h3 className="font-extrabold text-xs sm:text-sm text-slate-900 dark:text-slate-100 group-hover:text-teal-600 transition-colors truncate">
                    الخريطة الذهنية (2D/3D)
                  </h3>
                  <span className="text-[9px] font-bold px-1.5 py-0.2 rounded-md bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 border border-indigo-200/50 dark:border-indigo-800/50 shrink-0">
                    تفاعلية
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate mt-0.5">
                  تصور هرمي وتشعيبي لربط مفاهيم المقرر
                </p>
              </div>
            </div>
            <ArrowLeft className="w-4 h-4 text-slate-300 dark:text-slate-600 group-hover:text-teal-600 group-hover:-translate-x-1 transition-all shrink-0" />
          </div>

          {/* Card 5: Achievements Dashboard */}
          <div
            onClick={() => onNavigateTab('achievements')}
            className="p-3.5 sm:p-4 rounded-2xl bg-white dark:bg-[#14201c] border border-slate-200/90 dark:border-[#22352f] hover:border-teal-500 hover:shadow-md transition-all cursor-pointer group flex items-center justify-between gap-3 active:scale-[0.99]"
          >
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-10 h-10 rounded-xl bg-amber-50 dark:bg-amber-950/80 text-amber-700 dark:text-amber-300 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform shadow-2xs">
                <Award className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <h3 className="font-extrabold text-xs sm:text-sm text-slate-900 dark:text-slate-100 group-hover:text-teal-600 transition-colors truncate">
                    لوحة إنجازاتي (D3)
                  </h3>
                  <span className="text-[9px] font-bold px-1.5 py-0.2 rounded-md bg-amber-50 dark:bg-amber-950 text-amber-700 dark:text-amber-300 border border-amber-200/50 dark:border-amber-800/50 shrink-0">
                    إحصائيات
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate mt-0.5">
                  ساعات المذاكرة، المصادر، ومنحنى الإتقان
                </p>
              </div>
            </div>
            <ArrowLeft className="w-4 h-4 text-slate-300 dark:text-slate-600 group-hover:text-teal-600 group-hover:-translate-x-1 transition-all shrink-0" />
          </div>

          {/* Card 6: Focus Timer & Calculator */}
          <div
            onClick={() => onNavigateTab('tools')}
            className="p-3.5 sm:p-4 rounded-2xl bg-white dark:bg-[#14201c] border border-slate-200/90 dark:border-[#22352f] hover:border-teal-500 hover:shadow-md transition-all cursor-pointer group flex items-center justify-between gap-3 active:scale-[0.99]"
          >
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-10 h-10 rounded-xl bg-amber-50 dark:bg-amber-950/80 text-amber-700 dark:text-amber-300 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform shadow-2xs">
                <Calculator className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <h3 className="font-extrabold text-xs sm:text-sm text-slate-900 dark:text-slate-100 group-hover:text-teal-600 transition-colors truncate">
                    مؤقت التركيز والحاسبة
                  </h3>
                  <span className="text-[9px] font-bold px-1.5 py-0.2 rounded-md bg-amber-50 dark:bg-amber-950 text-amber-700 dark:text-amber-300 border border-amber-200/50 dark:border-amber-800/50 shrink-0">
                    بومودورو
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate mt-0.5">
                  حاسبة معادلات علمية ومؤقت تركيز منظم
                </p>
              </div>
            </div>
            <ArrowLeft className="w-4 h-4 text-slate-300 dark:text-slate-600 group-hover:text-teal-600 group-hover:-translate-x-1 transition-all shrink-0" />
          </div>

          {/* Card 9: Export Center */}
          <div
            onClick={() => onNavigateTab('export')}
            className="p-3.5 sm:p-4 rounded-2xl bg-white dark:bg-[#14201c] border border-slate-200/90 dark:border-[#22352f] hover:border-teal-500 hover:shadow-md transition-all cursor-pointer group flex items-center justify-between gap-3 active:scale-[0.99]"
          >
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-10 h-10 rounded-xl bg-purple-50 dark:bg-purple-950/80 text-purple-700 dark:text-purple-300 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform shadow-2xs">
                <Layers className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <h3 className="font-extrabold text-xs sm:text-sm text-slate-900 dark:text-slate-100 group-hover:text-teal-600 transition-colors truncate">
                    مركز التصدير و PDF
                  </h3>
                  <span className="text-[9px] font-bold px-1.5 py-0.2 rounded-md bg-purple-50 dark:bg-purple-950 text-purple-700 dark:text-purple-300 border border-purple-200/50 dark:border-purple-800/50 shrink-0">
                    Obsidian & Notion
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate mt-0.5">
                  طباعة A4 وتصدير Markdown بالمراجع والمعادلات
                </p>
              </div>
            </div>
            <ArrowLeft className="w-4 h-4 text-slate-300 dark:text-slate-600 group-hover:text-teal-600 group-hover:-translate-x-1 transition-all shrink-0" />
          </div>
        </div>
      </section>
    </div>
  );
};
