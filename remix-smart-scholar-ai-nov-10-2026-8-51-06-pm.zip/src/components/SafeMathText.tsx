import React, { useMemo } from 'react';
import { SafeBlockMath, SafeInlineMath, preprocessEducationalText, convertCeToStandardLatex } from './EducationalContent';

interface SafeMathTextProps {
  text?: string;
  content?: string;
  className?: string;
  block?: boolean;
}

/**
 * Normalizes double/triple backslashes before LaTeX keywords (e.g. \\lim -> \lim, \\frac -> \frac)
 * to resolve string serialization and escaping artifacts in databases.
 */
export function normalizeLatexEscapes(input: string): string {
  if (!input) return '';
  let str = input;

  // 1. Immediately convert and wrap any \ce{...} expressions into $...$ inline math
  str = str.replace(/\\?ce\{([^{}]+)\}/g, (_m, inner) => {
    const cleanChem = convertCeToStandardLatex(inner);
    return `$${cleanChem}$`;
  });

  // 2. Wrap bracketed ion concentrations into $...$
  str = str.replace(/(?:\\left)?\[\s*(?:\\?ce\{)?H3O\+\}?\s*(?:\\right)?\]/g, '$\\left[\\text{H}_3\\text{O}^+\\right]$');
  str = str.replace(/(?:\\left)?\[\s*(?:\\?ce\{)?OH-\}?\s*(?:\\right)?\]/g, '$\\left[\\text{OH}^-\\right]$');
  str = str.replace(/(?:\\left)?\[\s*(?:\\?ce\{)?H\+\}?\s*(?:\\right)?\]/g, '$\\left[\\text{H}^+\\right]$');
  str = str.replace(/(?:\\left)?\[\s*\\text\{H\}_3\\text\{O\}\^\+\s*(?:\\right)?\]/g, '$\\left[\\text{H}_3\\text{O}^+\\right]$');

  // 3. Convert multiple backslashes before LaTeX keywords to a single backslash
  str = str.replace(
    /\\{2,}(lim|to|frac|dfrac|tfrac|sqrt|int|iint|iiint|sum|prod|sin|cos|tan|cot|sec|csc|arcsin|arccos|arctan|log|ln|exp|det|vec|hat|bar|dot|ddot|tilde|mathbf|mathit|mathrm|mathbb|mathcal|text|pm|times|div|cdot|rightarrow|leftarrow|Rightarrow|Leftarrow|Leftrightarrow|iff|approx|neq|le|ge|leq|geq|in|notin|subset|subseteq|cup|cap|Delta|delta|theta|alpha|beta|gamma|lambda|mu|pi|sigma|phi|omega|Omega|infty|partial|nabla|degree|circ|left|right|begin|end|quad|qquad|ce)\b/g,
    '\\$1'
  );

  // 4. Unescape escaped subscripts and superscripts (e.g. \\_ to _, \\^ to ^)
  str = str.replace(/\\{2,}([_\^])/g, '$1');

  // 5. Clean up triple dollar signs if accidentally concatenated ($$$ -> $$)
  str = str.replace(/\${3,}/g, '$$');

  return str;
}

/**
 * Intelligent LaTeX math detector:
 * Scans text that is NOT enclosed in $...$ or $$...$$,
 * detects raw mathematical formulas (such as \lim_{x \to 0} \frac{\sin(5x)}{\tan(2x)} or \frac{5}{2}),
 * and wraps them into $...$ so KaTeX renders them visually 100%.
 */
export function autoWrapRawLatex(text: string): string {
  if (!text) return '';

  let normalized = typeof text === 'string' ? text : String(text || '');

  // 0. Convert LaTeX delimiters \[ ... \] and \( ... \) to $$ and $ immediately
  normalized = normalized.replace(/\\\[([\s\S]*?)\\\]/g, (_m, inner) => `\n\n$$\n${inner.trim()}\n$$\n\n`);
  normalized = normalized.replace(/\\\(([\s\S]*?)\\\)/g, (_m, inner) => `$${inner.trim()}$`);

  normalized = normalizeLatexEscapes(normalized);

  // If the whole string is already wrapped in $$...$$ or $...$, return normalized
  const trimmed = normalized.trim();
  if (/^\$\$[\s\S]+\$\$$/.test(trimmed) || /^\$[^\$]+\$$/.test(trimmed)) {
    return normalized;
  }

  // 1. Temporarily replace already delimited $$...$$ and $...$ with placeholders
  const preservedBlocks: string[] = [];
  let temp = normalized.replace(/(\$\$[\s\S]*?\$\$|\$[^\$]+?\$)/g, (match) => {
    preservedBlocks.push(match);
    return `___PRESERVED_MATH_${preservedBlocks.length - 1}___`;
  });

  // 2. Detect raw LaTeX formulas in the remaining text (excluding Arabic letters)
  // Matches commands starting with \lim, \frac, \sqrt, \int, \sum, \sin, \cos, \tan, \text, \rightleftharpoons, etc.
  const rawLatexRegex = /(\\(?:lim|frac|dfrac|tfrac|sqrt|int|iint|sum|prod|sin|cos|tan|cot|sec|csc|log|ln|Delta|theta|alpha|beta|gamma|lambda|pi|sigma|omega|Omega|infty|partial|nabla|approx|neq|pm|times|cdot|div|to|ce|text|rightleftharpoons|leftarrow|rightarrow)\b(?:\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}|\[[^\[\]]*\]|\([^\(\)]*\)|[a-zA-Z0-9_\^\+\-\*\/\=\<\>\s\\\.](?<![\u0600-\u06FF]))*(?:\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}|[a-zA-Z0-9_\^\+\-\*\/\=]))/g;

  temp = temp.replace(rawLatexRegex, (match) => {
    if (match.includes('___PRESERVED_MATH_')) return match;
    const cleanMatch = match.trim();
    if (!cleanMatch) return match;
    return `$${cleanMatch}$`;
  });

  // Explicitly wrap any remaining raw \ce{...} expressions into $...$
  temp = temp.replace(/\\?ce\{([^}]+)\}/g, (_m, inner) => `$${convertCeToStandardLatex(inner)}$`);

  // Explicitly wrap bracketed concentrations e.g. [\text{H}_3\text{O}^+] = 1.0 \times 10^{-4} M or [H3O+] = 1.0 \times 10^{-4} M
  temp = temp.replace(/(?<![\$a-zA-Z0-9])((?:\\left)?\[\s*(?:\\text\{[^{}]+\}|[A-Za-z0-9\+\-]+)\s*(?:\\right)?\]\s*=\s*[0-9]+(?:\.[0-9]+)?\s*\\times\s*10\^\{?-?[0-9]+\}?\s*(?:M|\\text\{M\})?)(?![\$a-zA-Z0-9])/g, '$$$1$$');

  // Wrap scientific exponential notation like 1.0 \times 10^{-4} or 10^{-4}
  temp = temp.replace(/(?<![\$a-zA-Z0-9])([0-9]+(?:\.[0-9]+)?\s*\\times\s*10\^\{?-?[0-9]+\}?)(?![\$a-zA-Z0-9])/g, '$$$1$$');
  temp = temp.replace(/(?<![\$a-zA-Z0-9])(10\^\{?-?[0-9]+\}?)(?![\$a-zA-Z0-9])/g, '$$$1$$');

  // Wrap Kc = ..., pH = ..., pOH = ...
  temp = temp.replace(/(?<![\$a-zA-Z0-9])(K_c\s*=\s*[0-9]+(?:\.[0-9]+)?)(?![\$a-zA-Z0-9])/g, '$$$1$$');
  temp = temp.replace(/(?<![\$a-zA-Z0-9])((?:\\text\{)?pH\}?\s*=\s*[0-9]+(?:\.[0-9]+)?)(?![\$a-zA-Z0-9])/g, '$$$1$$');

  // Wrap algebraic equations with functions and operators (e.g. f(x) = ax^2 + bx + c, y = mx + b, E = mc^2)
  temp = temp.replace(
    /(?<![\$a-zA-Z0-9_\\])([a-zA-Z](?:\([a-zA-Z0-9, ]+\))?\s*=\s*[a-zA-Z0-9_\^+\-*/()\\ ]{2,}[a-zA-Z0-9)])(?![\$a-zA-Z0-9_])/g,
    (match) => {
      if (match.includes('___PRESERVED_MATH_') || match.includes('http') || match.includes('//') || match.length > 80) return match;
      if (/[\^+\-*/\\]|f\(x\)|g\(x\)|y\s*=|E\s*=|F\s*=|v\s*=|a\s*=|P\s*=|V\s*=|x\s*=/.test(match)) {
        return `$${match.trim()}$`;
      }
      return match;
    }
  );

  // Wrap isolated exponential variables e.g. x^2, v^2, t^2, r^3
  temp = temp.replace(/(?<![\$a-zA-Z0-9_\\])([a-zA-Z]\^[0-9a-zA-Z\-]+)(?![\$a-zA-Z0-9_])/g, '$$$1$$');

  // 3. Restore preserved blocks
  temp = temp.replace(/___PRESERVED_MATH_(\d+)___/g, (_, index) => {
    return preservedBlocks[parseInt(index, 10)] || '';
  });

  // Ensure no duplicate $$ wrappers like $$...$$ inside $...$
  temp = temp.replace(/\${3,}/g, '$$');
  return temp;
}

/**
 * Universal Academic Math & Science Text Renderer
 * Safely extracts and renders inline $...$ and display $$...$$ formulas with KaTeX,
 * while automatically detecting raw un-delimited LaTeX and rendering standard Arabic text,
 * equations, and chemical symbols without any unparsed artifacts or raw backslashes.
 */
export const SafeMathText: React.FC<SafeMathTextProps> = ({
  text,
  content: propContent,
  className = '',
  block = false,
}) => {
  const rawText = typeof text === 'string' ? text : typeof propContent === 'string' ? propContent : '';
  const parts = useMemo(() => {
    if (!rawText) return [];

    // 1. Preprocess text to ensure KaTeX Arabic compatibility and clean formula delimiters
    let prepared = preprocessEducationalText(rawText);

    // 2. Normalize LaTeX escapes and un-delimited formulas
    prepared = autoWrapRawLatex(prepared);

    // 3. Regex to match $$display math$$ or $inline math$ (including multiline formulas)
    const tokenRegex = /(\$\$[\s\S]*?\$\$|\$[^\$]+?\$)/g;
    const tokens = [];
    let lastIndex = 0;
    let match: RegExpExecArray | null;

    while ((match = tokenRegex.exec(prepared)) !== null) {
      if (match.index > lastIndex) {
        tokens.push({
          type: 'text',
          content: prepared.slice(lastIndex, match.index),
        });
      }

      const rawMatch = match[0];
      if (rawMatch.startsWith('$$') && rawMatch.endsWith('$$')) {
        tokens.push({
          type: 'display_math',
          content: rawMatch.slice(2, -2).trim(),
        });
      } else if (rawMatch.startsWith('$') && rawMatch.endsWith('$')) {
        tokens.push({
          type: 'inline_math',
          content: rawMatch.slice(1, -1).trim(),
        });
      }

      lastIndex = tokenRegex.lastIndex;
    }

    if (lastIndex < prepared.length) {
      tokens.push({
        type: 'text',
        content: prepared.slice(lastIndex),
      });
    }

    return tokens;
  }, [rawText]);

  if (!rawText) return null;

  const content = (
    <>
      {parts.map((part, index) => {
        if (part.type === 'display_math') {
          return block ? <SafeBlockMath key={index} math={part.content} /> : <SafeInlineMath key={index} math={part.content} />;
        }
        if (part.type === 'inline_math') {
          return <SafeInlineMath key={index} math={part.content} />;
        }
        // Regular text
        return <span key={index}>{part.content}</span>;
      })}
    </>
  );

  if (block) {
    return <div className={`leading-relaxed ${className}`}>{content}</div>;
  }

  return <span className={`leading-relaxed ${className}`}>{content}</span>;
};

