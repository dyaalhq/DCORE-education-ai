import React, { useState } from 'react';
import { Menu, Search, Moon, Sun, BookOpen, X, Cloud, CheckCircle2, User, Clock, Flame, Mail, Sparkles, MoreVertical, Globe, Check, Mic } from 'lucide-react';
import { Notebook, UserProfile } from '../types';
import { PWAInstallButton } from './PWAInstallButton';
import { AppLogo } from './AppLogo';
import { SupportedLanguage, SUPPORTED_LANGUAGES, t } from '../lib/i18n';

interface HeaderProps {
  onToggleSidebar: () => void;
  currentTab: string;
  currentNotebook: Notebook;
  onGlobalSearch: (query: string) => void;
  isDark: boolean;
  onToggleTheme: () => void;
  aiConnected: boolean;
  onBack?: () => void;
  canGoBack?: boolean;
  userProfile?: UserProfile | null;
  onOpenAuthModal?: () => void;
  onOpenSupportModal?: () => void;
  isSyncing?: boolean;
  isDeepFocusActive?: boolean;
  onToggleDeepFocus?: () => void;
  currentLang?: SupportedLanguage;
  onChangeLang?: (lang: SupportedLanguage) => void;
  onOpenAcademicRefModal?: () => void;
  onOpenVoiceMemo?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onToggleSidebar,
  currentTab,
  currentNotebook,
  onGlobalSearch,
  isDark,
  onToggleTheme,
  aiConnected,
  onBack,
  canGoBack,
  userProfile,
  onOpenAuthModal,
  onOpenSupportModal,
  isSyncing,
  isDeepFocusActive,
  onToggleDeepFocus,
  currentLang = 'ar',
  onChangeLang,
  onOpenAcademicRefModal,
  onOpenVoiceMemo,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [showSearchModal, setShowSearchModal] = useState(false);
  const [showMoreMenu, setShowMoreMenu] = useState(false);
  const [showLangMenu, setShowLangMenu] = useState(false);

  const tabTitles: Record<string, string> = {
    home: t('nav.home', currentLang, 'الرئيسية'),
    chat: t('nav.chat', currentLang, 'المعلم الذكي AI'),
    sources: t('nav.sources', currentLang, 'المصادر والكتب'),
    studio: t('nav.studio', currentLang, 'استوديو المذاكرة'),
    mindmap: t('nav.mindmap', currentLang, 'الخريطة الذهنية (2D/3D)'),
    tools: t('nav.tools', currentLang, 'مؤقت التركيز والحاسبة'),
    export: t('nav.export', currentLang, 'مركز التصدير و PDF'),
    achievements: 'لوحة إنجازاتي',
    question_bank: 'بنك الأسئلة والموسوعة',
    science: t('nav.science', currentLang, 'المختبر العلمي 3D'),
    settings: t('nav.account', currentLang, 'حسابي والمزامنة'),
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      onGlobalSearch(searchQuery.trim());
      setShowSearchModal(false);
    }
  };

  return (
    <header className="h-16 bg-white/85 dark:bg-[#121b18]/85 backdrop-blur-md border-b border-[#e2e8e5] dark:border-[#22352f] px-3 sm:px-4 lg:px-6 flex items-center justify-between sticky top-0 z-30">
      {/* Brand & Tab Navigation */}
      <div className="flex items-center gap-2 sm:gap-3 shrink-0">
        {/* Permanent 3-Bars Hamburger Menu Icon - Never changes into a back arrow */}
        <button
          onClick={onToggleSidebar}
          className="p-2 rounded-xl text-[#596762] dark:text-[#9ab3ab] hover:bg-[#f6f8f7] dark:hover:bg-[#1a2723] hover:text-[#0f766e] dark:hover:text-[#2dd4bf] transition-colors cursor-pointer"
          aria-label="فتح القائمة الرئيسية"
          title="القائمة الرئيسية"
        >
          <Menu className="w-5 h-5" />
        </button>


        <div className="flex items-center gap-2.5">
          <AppLogo size="sm" showText={false} />
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm sm:text-base font-extrabold text-[#17201e] dark:text-[#eef7f4] truncate max-w-[130px] sm:max-w-none">
                {tabTitles[currentTab] || 'المعلم الذكي'}
              </h2>
              <span className="hidden sm:inline-flex items-center gap-1 text-[11px] font-semibold bg-[#e6f4f1] dark:bg-[#132e29] text-[#0f766e] dark:text-[#2dd4bf] px-2.5 py-0.5 rounded-full truncate max-w-[140px]">
                <BookOpen className="w-3 h-3 shrink-0" />
                <span className="truncate">{currentNotebook.name}</span>
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Global Search Bar on Desktop */}
      <div className="hidden md:flex flex-1 max-w-md mx-4 lg:mx-8">
        <form onSubmit={handleSearchSubmit} className="w-full relative">
          <input
            type="text"
            placeholder="ابحث في الدروس، القوانين، والمحادثات..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-4 pr-10 py-1.5 text-xs bg-[#f6f8f7] dark:bg-[#1a2723] border border-[#e2e8e5] dark:border-[#22352f] rounded-full text-[#17201e] dark:text-[#eef7f4] focus:outline-none focus:border-[#0f766e] dark:focus:border-[#2dd4bf] transition-all"
          />
          <Search className="w-4 h-4 text-[#596762] dark:text-[#9ab3ab] absolute right-3.5 top-2.5" />
        </form>
      </div>

      {/* Action Controls - Decluttered, Mobile-First & Sleek */}
      <div className="flex items-center gap-1 sm:gap-2 shrink-0">
        {/* Mobile Search Button */}
        <button
          onClick={() => setShowSearchModal(true)}
          className="md:hidden p-2 rounded-xl text-[#596762] hover:bg-[#f6f8f7] dark:hover:bg-[#1a2723] transition-colors cursor-pointer"
          aria-label="البحث"
        >
          <Search className="w-4 h-4" />
        </button>

        {/* Theme Switcher */}
        <button
          onClick={onToggleTheme}
          className="p-2 rounded-xl text-[#596762] hover:bg-[#f6f8f7] dark:hover:bg-[#1a2723] transition-colors cursor-pointer"
          aria-label="تبديل المظهر"
          title={isDark ? 'الوضع النهاري' : 'الوضع الليلي'}
        >
          {isDark ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
        </button>

        {/* Omni Academic Reference Modal Button */}
        {onOpenAcademicRefModal && (
          <button
            onClick={onOpenAcademicRefModal}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-full bg-teal-50 dark:bg-teal-950/50 border border-teal-200/80 dark:border-teal-800/60 hover:border-teal-500 text-teal-800 dark:text-teal-200 text-xs font-bold transition-all shadow-2xs cursor-pointer active:scale-95"
            title="فتح المرجع الأكاديمي الشامل والموسوعة العلمية"
          >
            <BookOpen className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400 shrink-0" />
            <span className="hidden sm:inline">المرجع الأكاديمي</span>
          </button>
        )}

        {/* Voice Note Recording Button (Speech-to-Text & Memo) */}
        {onOpenVoiceMemo && (
          <button
            onClick={onOpenVoiceMemo}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-full bg-gradient-to-r from-teal-500/15 via-emerald-500/15 to-teal-500/15 hover:from-teal-500/25 hover:to-emerald-500/25 border border-teal-500/30 text-teal-800 dark:text-teal-200 text-xs font-bold transition-all shadow-2xs cursor-pointer active:scale-95"
            title="تسجيل ملاحظة صوتية وتفريغها عبر Gemini (Speech-to-Text) وحفظها كـ MemoItem"
          >
            <Mic className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400 shrink-0 animate-pulse" />
            <span className="hidden md:inline">ملاحظة صوتية</span>
          </button>
        )}

        {/* Direct Google Profile / Sign-In Button */}
        {onOpenAuthModal && (
          userProfile ? (
            <button
              onClick={onOpenAuthModal}
              className="flex items-center gap-2 p-1 sm:px-2.5 sm:py-1 rounded-full bg-teal-50 dark:bg-teal-950/50 border border-teal-200/80 dark:border-teal-800/60 hover:border-teal-500 transition-all cursor-pointer shadow-2xs"
              title={`حساب Google: ${userProfile.displayName} (${userProfile.email})`}
            >
              {userProfile.photoURL ? (
                <img
                  src={userProfile.photoURL}
                  alt={userProfile.displayName}
                  className="w-6 h-6 rounded-full object-cover border border-teal-600 shrink-0"
                />
              ) : (
                <div className="w-6 h-6 rounded-full bg-teal-700 text-white font-bold text-[10px] flex items-center justify-center shrink-0">
                  {userProfile.displayName.charAt(0)}
                </div>
              )}
              <span className="hidden sm:inline text-xs font-bold text-teal-800 dark:text-teal-200 truncate max-w-[100px]">
                {userProfile.displayName.split(' ')[0]}
              </span>
              <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
            </button>
          ) : (
            <button
              onClick={onOpenAuthModal}
              className="flex items-center gap-1.5 px-2.5 py-1.5 sm:px-3 sm:py-1.5 rounded-full bg-slate-900 dark:bg-teal-700 hover:bg-slate-800 dark:hover:bg-teal-600 text-white text-xs font-bold transition-all shadow-xs cursor-pointer active:scale-95"
              title="تسجيل الدخول بحساب Google"
            >
              <svg className="w-3.5 h-3.5 bg-white rounded-full p-0.5 shrink-0" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
              </svg>
              <span className="hidden xs:inline sm:inline">دخول Google</span>
            </button>
          )
        )}

        {/* Instant Multi-Language Switcher */}
        <div className="relative">
          <button
            onClick={() => { setShowLangMenu(!showLangMenu); setShowMoreMenu(false); }}
            className="p-1.5 sm:px-2 sm:py-1 rounded-xl text-[#596762] dark:text-[#9ab3ab] hover:bg-[#f6f8f7] dark:hover:bg-[#1a2723] hover:text-[#0f766e] dark:hover:text-[#2dd4bf] transition-colors cursor-pointer flex items-center gap-1 text-xs font-bold border border-transparent hover:border-slate-200 dark:hover:border-[#22352f]"
            aria-label="تغيير لغة التطبيق"
            title="تغيير لغة التطبيق الفورية"
          >
            <Globe className="w-4 h-4 text-teal-600 dark:text-teal-400" />
            <span className="text-[11px] uppercase font-mono hidden sm:inline">{currentLang}</span>
          </button>

          {showLangMenu && (
            <div 
              className="absolute left-0 mt-2 w-48 rounded-2xl bg-white dark:bg-[#15231e] border border-slate-200 dark:border-[#22352f] shadow-xl p-1.5 z-50 space-y-1 animate-in fade-in zoom-in-95 duration-100"
              onClick={() => setShowLangMenu(false)}
            >
              <div className="px-2.5 py-1 text-[10px] font-bold text-slate-400 border-b border-slate-100 dark:border-[#1e2f29] uppercase tracking-wider">
                اختر لغة الواجهة
              </div>
              {SUPPORTED_LANGUAGES.map((lang) => {
                const isSelected = currentLang === lang.code;
                return (
                  <button
                    key={lang.code}
                    type="button"
                    onClick={() => onChangeLang?.(lang.code)}
                    className={`w-full text-right px-2.5 py-1.5 rounded-xl text-xs font-bold flex items-center justify-between transition-colors cursor-pointer ${
                      isSelected
                        ? 'bg-teal-50 dark:bg-teal-950/60 text-teal-800 dark:text-teal-200'
                        : 'text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-[#1a2d26]'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-base">{lang.flag}</span>
                      <span>{lang.nativeName}</span>
                    </div>
                    {isSelected && <Check className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />}
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Minimal More Options Dropdown */}
        <div className="relative">
          <button
            onClick={() => { setShowMoreMenu(!showMoreMenu); setShowLangMenu(false); }}
            className="p-2 rounded-xl text-[#596762] hover:bg-[#f6f8f7] dark:hover:bg-[#1a2723] transition-colors cursor-pointer"
            aria-label="المزيد من الأدوات"
            title="أدوات إضافية"
          >
            <MoreVertical className="w-4 h-4" />
          </button>

          {showMoreMenu && (
            <div 
              className="absolute left-0 mt-2 w-56 rounded-2xl bg-white dark:bg-[#15231e] border border-slate-200 dark:border-[#22352f] shadow-xl p-2 z-50 space-y-1 animate-in fade-in slide-in-from-top-2 duration-150"
              onClick={() => setShowMoreMenu(false)}
            >
              {/* Deep Focus Pomodoro Mode */}
              {onToggleDeepFocus && (
                <button
                  onClick={onToggleDeepFocus}
                  className={`w-full text-right px-3 py-2 rounded-xl text-xs font-bold flex items-center justify-between transition-colors cursor-pointer ${
                    isDeepFocusActive 
                      ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300' 
                      : 'text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-[#1a2d26]'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-teal-600" />
                    <span>مؤقت التركيز (Pomodoro)</span>
                  </div>
                  {isDeepFocusActive && <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />}
                </button>
              )}

              {/* PWA Install */}
              <div className="px-1 py-1">
                <PWAInstallButton variant="header" />
              </div>

              {/* Omni Academic Reference */}
              {onOpenAcademicRefModal && (
                <button
                  type="button"
                  onClick={() => {
                    onOpenAcademicRefModal();
                    setShowMoreMenu(false);
                  }}
                  className="w-full text-right px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-2 text-teal-800 dark:text-teal-200 hover:bg-teal-50 dark:hover:bg-teal-950/40 transition-colors cursor-pointer"
                >
                  <BookOpen className="w-4 h-4 text-teal-600 dark:text-teal-400" />
                  <span>المرجع والمكتبة الموسوعية</span>
                </button>
              )}

              {/* Contact Developer & In-App Support Modal */}
              <button
                type="button"
                onClick={() => {
                  if (onOpenSupportModal) {
                    onOpenSupportModal();
                  }
                }}
                className="w-full text-right px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-2 text-teal-800 dark:text-teal-200 hover:bg-teal-50 dark:hover:bg-teal-950/40 transition-colors cursor-pointer"
              >
                <Mail className="w-4 h-4 text-teal-600 dark:text-teal-400" />
                <span>التواصل مع الدعم الفني</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Mobile Search Modal */}
      {showSearchModal && (
        <div className="fixed inset-0 z-50 p-4 bg-black/40 backdrop-blur-sm flex items-start justify-center pt-20 md:hidden">
          <div className="bg-white dark:bg-[#14201c] w-full max-w-sm rounded-2xl p-4 shadow-2xl border border-[#e2e8e5] dark:border-[#22352f]">
            <div className="flex items-center justify-between mb-3">
              <span className="font-bold text-sm text-[#17201e] dark:text-[#eef7f4]">
                البحث العام في الدفتر
              </span>
              <button
                onClick={() => setShowSearchModal(false)}
                className="text-gray-400 p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <form onSubmit={handleSearchSubmit} className="space-y-3">
              <input
                type="text"
                placeholder="اكتب كلمة البحث..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full px-3 py-2 border border-[#e2e8e5] dark:border-[#22352f] rounded-xl bg-[#f6f8f7] dark:bg-[#1a2723] text-sm text-[#17201e] dark:text-[#eef7f4] focus:outline-none focus:border-[#0f766e]"
                autoFocus
              />
              <button
                type="submit"
                className="w-full py-2 bg-[#0f766e] text-white rounded-xl text-sm font-bold"
              >
                بحث
              </button>
            </form>
          </div>
        </div>
      )}
    </header>
  );
};
