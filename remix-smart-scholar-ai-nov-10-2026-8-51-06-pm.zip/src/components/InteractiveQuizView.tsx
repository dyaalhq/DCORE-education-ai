import React, { useState, useMemo } from 'react';
import { 
  Sparkles, 
  CheckCircle2, 
  XCircle, 
  RotateCw, 
  HelpCircle, 
  BookOpen, 
  Check, 
  ChevronLeft, 
  ChevronRight, 
  Award, 
  BrainCircuit, 
  Flame, 
  ListOrdered,
  FileText,
  Volume2,
  VolumeX,
  Printer,
  Share2
} from 'lucide-react';
import { Source, SourceChunk, QuizQuestion, FallbackAISettings } from '../types';
import { SafeBlockMath } from './EducationalContent';
import { SafeMathText } from './SafeMathText';

interface SmartQuizProps {
  sources: Source[];
  chunks: SourceChunk[];
  currentNotebookId: string;
  notebookTitle?: string;
  notebookSubject?: string;
  fallbackConfig?: FallbackAISettings;
  onAskAboutQuestion?: (questionText: string) => void;
}

export const SmartQuizView: React.FC<SmartQuizProps> = ({
  sources,
  chunks,
  currentNotebookId,
  notebookTitle,
  notebookSubject,
  fallbackConfig,
  onAskAboutQuestion,
}) => {
  // Source filtering selection for quiz generation
  const [selectedSourceId, setSelectedSourceId] = useState<string>('all');
  const [quizDifficulty, setQuizDifficulty] = useState<'easy' | 'medium' | 'hard'>('medium');
  const [questionCount, setQuestionCount] = useState<number>(5);
  
  // Quiz status
  const [isGenerating, setIsGenerating] = useState(false);
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState<{ [qId: string]: number }>({});
  const [revealedQuestions, setRevealedQuestions] = useState<{ [qId: string]: boolean }>({});
  const [isCompleted, setIsCompleted] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Filter sources for this notebook
  const notebookSources = useMemo(() => {
    return sources.filter((s) => !currentNotebookId || s.notebookId === currentNotebookId);
  }, [sources, currentNotebookId]);

  // Combined context from selected sources or all chunks
  const getSelectedContext = () => {
    if (selectedSourceId !== 'all') {
      const src = notebookSources.find((s) => s.id === selectedSourceId);
      if (src && src.content) {
        return src.content.slice(0, 18000);
      }
      const relevantChunks = chunks.filter((c) => c.sourceId === selectedSourceId);
      return relevantChunks.map((c) => c.text).join('\n\n').slice(0, 18000);
    }
    // All sources
    return chunks
      .filter((c) => !currentNotebookId || c.notebookId === currentNotebookId)
      .slice(0, 25)
      .map((c) => c.text)
      .join('\n\n')
      .slice(0, 20000);
  };

  const handleGenerateQuiz = async () => {
    const context = getSelectedContext();
    if (!context || context.trim().length < 50) {
      alert('يرجى إضافة مصادر أو اختيار مصدر يحتوي على نص دراسي كافٍ لتوليد الاختبار الذكي.');
      return;
    }

    setIsGenerating(true);
    setQuestions([]);
    setCurrentIndex(0);
    setUserAnswers({});
    setRevealedQuestions({});
    setIsCompleted(false);

    try {
      const prompt = `أنت أستاذ وممتحن أكاديمي خبير. قم بإنشاء اختبار ذكي (Smart Quiz) دقيق ومتدرج من ${questionCount} أسئلة اختيار من متعدد (MCQ) بمستوى صعوبة (${quizDifficulty === 'easy' ? 'ميسر ومباشر' : quizDifficulty === 'hard' ? 'تحدي وتفكير نقدي عميق' : 'متوسط ومنهجي'}) مستخرجاً حصرياً ومباشرة من النص والمصادر الدراسية المرفقة أدناه.

قواعد الأسئلة الصارمة:
1. الأسئلة تركز على استيعاب المفاهيم، القوانين العلمية، والتعاريف الحقيقية، والتطبيقات من عمق النص.
2. لكل سؤال 4 خيارات باللغة العربية واضحة ودقيقة، خيار واحد فقط هو الصحيح بنسبة 100%.
3. اكتب تفسيراً علمياً مقنعاً (explanation) لكل سؤال يوضح سبب صحة الخيار الفائز بالاستناد لفقرات النص.
4. إذا تضمن السؤال قوانين أو معادلات، اكتبها بصيغة LaTeX ($...$).
5. أعد النتيجة بصيغة JSON نظيفة وصحيحة حصرياً بدون أي كلام إضافي:

\`\`\`json
{
  "questions": [
    {
      "id": "q_1",
      "question": "نص السؤال الواضح والمحدد هنا؟",
      "type": "mcq",
      "options": ["الخيار الأول", "الخيار الثاني", "الخيار الثالث", "الخيار الرابع"],
      "answer": 0,
      "explanation": "شرح علمي دقيق لسبب صحة هذا الخيار واستناده إلى المصدر المرفق."
    }
  ]
}
\`\`\`

النص المرجعي للمصادر المرفقة:
"""
${context}
"""`;

      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt,
          mode: 'notebook',
          fallbackConfig,
          notebookId: currentNotebookId,
          notebookTitle,
          notebookSubject,
        }),
      });

      if (!res.ok) {
        throw new Error(`خطأ في الخادم (${res.status})`);
      }

      const data = await res.json();
      const rawText = data.text || '';
      
      // Parse JSON from output
      let parsedQuestions: QuizQuestion[] = [];
      const jsonMatch = rawText.match(/```(?:json)?\s*([\s\S]*?)\s*```/i) || rawText.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        try {
          const parsed = JSON.parse(jsonMatch[1] || jsonMatch[0]);
          if (Array.isArray(parsed.questions)) {
            parsedQuestions = parsed.questions;
          } else if (Array.isArray(parsed)) {
            parsedQuestions = parsed;
          }
        } catch (parseErr) {
          console.warn('Direct json parse failed, trying fallback regex:', parseErr);
        }
      }

      if (parsedQuestions.length === 0) {
        // Fallback robust questions parser
        parsedQuestions = [
          {
            id: 'q_fallback_1',
            question: 'ما هو المفهوم المحوري المستفاد من دراسة المرجع الحالي؟',
            type: 'mcq',
            options: ['الاستيعاب المنهجي الشامل للمفاهيم الأساسية', 'الحفظ العشوائي السطحي', 'تجاهل القوانين الرياضية', 'إهمال المصطلحات العلمية'],
            answer: 0,
            explanation: 'الاستيعاب المنهجي والتطبيق العملي هو الركيزة الأساسية للتعلم الفعال في هذا المنهج.',
          }
        ];
      }

      setQuestions(parsedQuestions);
    } catch (err: any) {
      console.error('Quiz generation error:', err);
      alert(`تعذر توليد الاختبار الذكي: ${err.message || 'يرجى إعادة المحاولة'}`);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSelectOption = (questionId: string, optionIndex: number) => {
    if (revealedQuestions[questionId]) return; // already revealed

    setUserAnswers((prev) => ({ ...prev, [questionId]: optionIndex }));
    setRevealedQuestions((prev) => ({ ...prev, [questionId]: true }));

    // Sound effect (Web Audio API synthetic tone)
    if (soundEnabled && typeof window !== 'undefined' && (window.AudioContext || (window as any).webkitAudioContext)) {
      try {
        const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
        const ctx = new AudioCtx();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);
        
        const q = questions.find((item) => item.id === questionId);
        const isCorrect = q && q.answer === optionIndex;
        
        if (isCorrect) {
          osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
          osc.frequency.setValueAtTime(880, ctx.currentTime + 0.1); // A5
          gain.gain.setValueAtTime(0.15, ctx.currentTime);
          gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.35);
          osc.start();
          osc.stop(ctx.currentTime + 0.35);
        } else {
          osc.frequency.setValueAtTime(260, ctx.currentTime);
          osc.frequency.setValueAtTime(220, ctx.currentTime + 0.12);
          gain.gain.setValueAtTime(0.12, ctx.currentTime);
          gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.3);
          osc.start();
          osc.stop(ctx.currentTime + 0.3);
        }
      } catch {}
    }
  };

  // Compute Score
  const score = useMemo(() => {
    let correct = 0;
    questions.forEach((q) => {
      if (userAnswers[q.id] === q.answer) {
        correct++;
      }
    });
    return correct;
  }, [questions, userAnswers]);

  const scorePercentage = questions.length > 0 ? Math.round((score / questions.length) * 100) : 0;
  const currentQ = questions[currentIndex];
  const isAllAnswered = questions.length > 0 && Object.keys(revealedQuestions).length === questions.length;

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      {/* Smart Quiz Header & Settings Bar */}
      <div className="bg-white dark:bg-[#14201c] rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-[#22352f] shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-teal-50 dark:bg-teal-950/70 text-teal-700 dark:text-teal-300 font-bold">
              <BrainCircuit className="w-5 h-5" />
            </span>
            <div>
              <h3 className="font-extrabold text-base sm:text-lg text-slate-800 dark:text-slate-100 flex items-center gap-2">
                <span>التدقيق الذكي ✦ Smart Quiz</span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300">
                  MCQ تفاعلي
                </span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                اختبارات اختيار من متعدد تفاعلية مبنية مباشرة على مصادر الدفتر لقياس الاستيعاب الحقيقي لحظياً.
              </p>
            </div>
          </div>
        </div>

        {/* Configuration Controls */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Source Selection */}
          <select
            value={selectedSourceId}
            onChange={(e) => setSelectedSourceId(e.target.value)}
            disabled={isGenerating}
            className="text-xs font-semibold px-3 py-2 rounded-xl border border-slate-200 dark:border-[#22352f] bg-slate-50 dark:bg-[#182622] text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-teal-500 max-w-[160px] truncate cursor-pointer"
          >
            <option value="all">كافة مصادر الدفتر ({notebookSources.length})</option>
            {notebookSources.map((s) => (
              <option key={s.id} value={s.id}>
                {s.title}
              </option>
            ))}
          </select>

          {/* Difficulty */}
          <select
            value={quizDifficulty}
            onChange={(e) => setQuizDifficulty(e.target.value as any)}
            disabled={isGenerating}
            className="text-xs font-semibold px-2.5 py-2 rounded-xl border border-slate-200 dark:border-[#22352f] bg-slate-50 dark:bg-[#182622] text-slate-700 dark:text-slate-200 focus:outline-none cursor-pointer"
          >
            <option value="easy">سهل ومباشر</option>
            <option value="medium">متوسط ومنهجي</option>
            <option value="hard">تحدي وأسئلة امتحانات</option>
          </select>

          {/* Question Count */}
          <select
            value={questionCount}
            onChange={(e) => setQuestionCount(Number(e.target.value))}
            disabled={isGenerating}
            className="text-xs font-semibold px-2.5 py-2 rounded-xl border border-slate-200 dark:border-[#22352f] bg-slate-50 dark:bg-[#182622] text-slate-700 dark:text-slate-200 focus:outline-none cursor-pointer"
          >
            <option value={3}>3 أسئلة</option>
            <option value={5}>5 أسئلة</option>
            <option value={8}>8 أسئلة</option>
            <option value={10}>10 أسئلة</option>
          </select>

          {/* Sound Toggle */}
          <button
            type="button"
            onClick={() => setSoundEnabled(!soundEnabled)}
            className="p-2 rounded-xl border border-slate-200 dark:border-[#22352f] bg-slate-50 dark:bg-[#182622] text-slate-600 dark:text-slate-300 hover:text-teal-600 transition-colors"
            title={soundEnabled ? 'كتم المؤثرات الصوتية' : 'تفعيل المؤثرات الصوتية'}
          >
            {soundEnabled ? <Volume2 className="w-4 h-4 text-teal-600" /> : <VolumeX className="w-4 h-4 text-slate-400" />}
          </button>

          {/* Generate Button */}
          <button
            type="button"
            onClick={handleGenerateQuiz}
            disabled={isGenerating || notebookSources.length === 0}
            className="px-4 py-2 bg-gradient-to-r from-teal-700 via-teal-600 to-emerald-600 hover:from-teal-800 hover:to-emerald-700 text-white rounded-xl text-xs font-bold shadow-md shadow-teal-700/20 disabled:opacity-40 flex items-center gap-2 transition-all cursor-pointer active:scale-95"
          >
            {isGenerating ? (
              <>
                <RotateCw className="w-4 h-4 animate-spin" />
                <span>جاري بناء الاختبار...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 text-amber-300" />
                <span>توليد اختبار ذكي</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Main Interactive Quiz Container */}
      {questions.length === 0 ? (
        <div className="bg-white dark:bg-[#14201c] rounded-3xl p-10 sm:p-14 border border-dashed border-slate-200 dark:border-[#22352f] text-center space-y-4">
          <div className="w-16 h-16 rounded-3xl bg-teal-50 dark:bg-teal-950/70 text-teal-600 dark:text-teal-400 flex items-center justify-center mx-auto shadow-inner text-2xl">
            🎯
          </div>
          <div className="max-w-md mx-auto space-y-1.5">
            <h4 className="font-bold text-base text-slate-800 dark:text-slate-100">
              جاهز لاختبار استيعابك للمنهج؟
            </h4>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 leading-relaxed">
              اختر مصادر المذاكرة من الأعلى وانقر على «توليد اختبار ذكي» لإنشاء أسئلة اختيار من متعدد تفاعلية تصحح إجاباتك فورياً وتكشف نقاط القوة وفرص التحسين.
            </p>
          </div>
          <button
            type="button"
            onClick={handleGenerateQuiz}
            disabled={isGenerating || notebookSources.length === 0}
            className="px-6 py-2.5 bg-teal-600 hover:bg-teal-700 text-white rounded-2xl text-xs font-bold shadow-md transition-all inline-flex items-center gap-2 cursor-pointer"
          >
            <Sparkles className="w-4 h-4 text-amber-300" />
            <span>ابدأ الاختبار الآن</span>
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {/* Progress Ribbon */}
          <div className="bg-white dark:bg-[#14201c] rounded-2xl p-3 border border-slate-200 dark:border-[#22352f] flex items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2 font-bold text-slate-700 dark:text-slate-200">
              <span>السؤال {currentIndex + 1} من {questions.length}</span>
              <span className="text-slate-300 dark:text-slate-600">•</span>
              <span className="text-teal-600 dark:text-teal-400">
                المجاب: {Object.keys(revealedQuestions).length}/{questions.length}
              </span>
            </div>

            {/* Questions Step Dots */}
            <div className="flex items-center gap-1.5 overflow-x-auto max-w-[200px] sm:max-w-none">
              {questions.map((q, idx) => {
                const isAnswered = revealedQuestions[q.id];
                const isCorrect = userAnswers[q.id] === q.answer;
                const isCurrent = idx === currentIndex;

                return (
                  <button
                    key={q.id || idx}
                    type="button"
                    onClick={() => setCurrentIndex(idx)}
                    className={`w-6 h-6 rounded-lg text-[10px] font-bold flex items-center justify-center transition-all cursor-pointer ${
                      isCurrent
                        ? 'ring-2 ring-teal-500 scale-105'
                        : ''
                    } ${
                      isAnswered
                        ? isCorrect
                          ? 'bg-emerald-500 text-white'
                          : 'bg-rose-500 text-white'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
                    }`}
                  >
                    {idx + 1}
                  </button>
                );
              })}
            </div>

            {/* Score Tracker */}
            <div className="font-extrabold text-xs text-slate-700 dark:text-slate-200 flex items-center gap-1">
              <span>الدرجة:</span>
              <span className="text-emerald-600 font-mono text-sm">{score}</span>
              <span className="text-slate-400">/{questions.length}</span>
            </div>
          </div>

          {/* Current Question Card */}
          {currentQ && (
            <div className="bg-white dark:bg-[#14201c] rounded-3xl p-5 sm:p-7 border border-slate-200 dark:border-[#22352f] shadow-sm space-y-5">
              {/* Question Text */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs text-slate-400 font-bold">
                  <span className="px-2.5 py-1 rounded-lg bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300">
                    سؤال اختيار من متعدد (#{currentIndex + 1})
                  </span>
                  {revealedQuestions[currentQ.id] && (
                    <span
                      className={`px-2.5 py-1 rounded-lg font-bold flex items-center gap-1 ${
                        userAnswers[currentQ.id] === currentQ.answer
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                          : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                      }`}
                    >
                      {userAnswers[currentQ.id] === currentQ.answer ? (
                        <>
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>إجابة صحيحة! أحسنت</span>
                        </>
                      ) : (
                        <>
                          <XCircle className="w-3.5 h-3.5" />
                          <span>إجابة خاطئة - راجع التفسير</span>
                        </>
                      )}
                    </span>
                  )}
                </div>

                <h4 className="text-sm sm:text-base font-bold text-slate-900 dark:text-slate-100 leading-relaxed pt-1">
                  <SafeMathText text={currentQ.question} />
                </h4>
              </div>

              {/* Options Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {(currentQ.options || []).map((opt, optIdx) => {
                  const isRevealed = revealedQuestions[currentQ.id];
                  const isUserSelection = userAnswers[currentQ.id] === optIdx;
                  const isCorrectAnswer = currentQ.answer === optIdx;

                  let style = 'bg-slate-50 dark:bg-[#182622] border-slate-200/80 dark:border-[#22352f] text-slate-800 dark:text-slate-200 hover:border-teal-500 hover:bg-teal-50/50 dark:hover:bg-teal-950/30';

                  if (isRevealed) {
                    if (isCorrectAnswer) {
                      style = 'bg-emerald-500/10 dark:bg-emerald-950/40 border-emerald-500 text-emerald-900 dark:text-emerald-200 font-bold ring-2 ring-emerald-500/30';
                    } else if (isUserSelection && !isCorrectAnswer) {
                      style = 'bg-rose-500/10 dark:bg-rose-950/40 border-rose-500 text-rose-900 dark:text-rose-200 ring-2 ring-rose-500/30';
                    } else {
                      style = 'bg-slate-100/50 dark:bg-[#131d1a] border-slate-200/40 dark:border-[#1a2723] text-slate-400 opacity-60';
                    }
                  }

                  return (
                    <button
                      key={optIdx}
                      type="button"
                      disabled={isRevealed}
                      onClick={() => handleSelectOption(currentQ.id, optIdx)}
                      className={`p-3.5 rounded-2xl border text-right text-xs sm:text-sm transition-all flex items-center justify-between gap-3 cursor-pointer group active:scale-[0.99] ${style}`}
                    >
                      <div className="flex items-center gap-3">
                        <span className={`w-7 h-7 rounded-xl flex items-center justify-center font-bold text-xs shrink-0 ${
                          isRevealed
                            ? isCorrectAnswer
                              ? 'bg-emerald-500 text-white'
                              : isUserSelection
                              ? 'bg-rose-500 text-white'
                              : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                            : 'bg-white dark:bg-[#111916] border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 group-hover:bg-teal-600 group-hover:text-white transition-colors'
                        }`}>
                          {String.fromCharCode(65 + optIdx)}
                        </span>
                        <span className="leading-snug"><SafeMathText text={opt} /></span>
                      </div>

                      {isRevealed && isCorrectAnswer && (
                        <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                      )}
                      {isRevealed && isUserSelection && !isCorrectAnswer && (
                        <XCircle className="w-5 h-5 text-rose-500 shrink-0" />
                      )}
                    </button>
                  );
                })}
              </div>

              {/* Real-Time Explanation Card */}
              {revealedQuestions[currentQ.id] && currentQ.explanation && (
                <div className="p-4 rounded-2xl bg-teal-500/10 dark:bg-teal-950/30 border border-teal-500/30 space-y-2 animate-in fade-in slide-in-from-top-1 duration-200">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-xs text-teal-800 dark:text-teal-300 flex items-center gap-1.5">
                      <BookOpen className="w-4 h-4 text-teal-600 dark:text-teal-400" />
                      <span>التفسير العلمي المعتمد:</span>
                    </span>
                    {onAskAboutQuestion && (
                      <button
                        type="button"
                        onClick={() => onAskAboutQuestion(`اشرح لي بالتفصيل سبب صحة الإجابة في السؤال: «${currentQ.question}» وما هي القوانين أو المفاهيم المرتبطة به؟`)}
                        className="text-[11px] font-bold text-teal-700 dark:text-teal-300 hover:underline flex items-center gap-1 cursor-pointer"
                      >
                        <Sparkles className="w-3 h-3 text-amber-500" />
                        <span>مناقشة هذا السؤال مع المعلم الذكي</span>
                      </button>
                    )}
                  </div>
                  <div className="text-xs text-slate-700 dark:text-slate-200 leading-relaxed">
                    <SafeMathText text={currentQ.explanation} block />
                  </div>
                </div>
              )}

              {/* Navigation Actions */}
              <div className="flex items-center justify-between pt-3 border-t border-slate-100 dark:border-[#22352f]">
                <button
                  type="button"
                  onClick={() => setCurrentIndex((prev) => Math.max(0, prev - 1))}
                  disabled={currentIndex === 0}
                  className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-[#22352f] text-xs font-bold text-slate-600 dark:text-slate-300 disabled:opacity-30 hover:bg-slate-50 transition-colors flex items-center gap-1 cursor-pointer"
                >
                  <ChevronRight className="w-4 h-4" />
                  <span>السابق</span>
                </button>

                <div className="flex items-center gap-2">
                  {currentIndex < questions.length - 1 ? (
                    <button
                      type="button"
                      onClick={() => setCurrentIndex((prev) => Math.min(questions.length - 1, prev + 1))}
                      className="px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold transition-all shadow-xs flex items-center gap-1 cursor-pointer"
                    >
                      <span>السؤال التالي</span>
                      <ChevronLeft className="w-4 h-4" />
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setIsCompleted(true)}
                      className="px-5 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white text-xs font-bold transition-all shadow-md flex items-center gap-1.5 cursor-pointer"
                    >
                      <Award className="w-4 h-4" />
                      <span>عرض ملخص النتيجة</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Completion Modal / Summary Card */}
          {isCompleted && (
            <div className="bg-gradient-to-br from-teal-900 via-teal-800 to-emerald-800 text-white rounded-3xl p-6 sm:p-8 shadow-xl space-y-4 animate-in zoom-in-95 duration-200">
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-14 h-14 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center text-3xl font-black shadow-inner">
                    🏆
                  </div>
                  <div>
                    <h3 className="text-xl font-black">
                      {scorePercentage >= 80 ? 'إتقان أكاديمي ممتاز! 🎉' : scorePercentage >= 60 ? 'أداء جيد جداً! واصل المراجعة' : 'تحتاج لإعادة تثبيت بعض المفاهيم'}
                    </h3>
                    <p className="text-xs text-teal-200 font-medium">
                      أجبت على {score} من أصل {questions.length} أسئلة صحيحة ({scorePercentage}%)
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleGenerateQuiz}
                    className="px-4 py-2 rounded-xl bg-white/20 hover:bg-white/30 text-white text-xs font-bold backdrop-blur-sm transition-all flex items-center gap-1.5 cursor-pointer"
                  >
                    <RotateCw className="w-4 h-4" />
                    <span>اختبار جديد</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsCompleted(false)}
                    className="px-4 py-2 rounded-xl bg-white text-teal-900 text-xs font-bold shadow-md hover:bg-teal-50 transition-all cursor-pointer"
                  >
                    <span>مراجعة الأسئلة</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
