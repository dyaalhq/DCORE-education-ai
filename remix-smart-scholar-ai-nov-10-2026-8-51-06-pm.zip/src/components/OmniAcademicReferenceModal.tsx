import React, { useState, useMemo } from 'react';
import {
  X,
  Search,
  BookOpen,
  Volume2,
  VolumeX,
  Pause,
  Play,
  Copy,
  Check,
  Share2,
  FileText,
  MessageSquare,
  Sparkles,
  Printer,
  ChevronRight,
  Clock,
  Layers,
  GraduationCap,
  ExternalLink,
  Tag,
  Maximize2,
  Minimize2,
} from 'lucide-react';
import { COMPREHENSIVE_ENCYCLOPEDIA_ARTICLES } from '../lib/encyclopediaData';
import { EncyclopediaArticle } from '../lib/offlineDatabase';
import { SafeMathText } from './SafeMathText';
import { useTextToSpeech } from '../lib/TextToSpeechService';

interface OmniAcademicReferenceModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveAsNote?: (title: string, content: string) => void;
  onAskAi?: (prompt: string) => void;
}

export const OmniAcademicReferenceModal: React.FC<OmniAcademicReferenceModalProps> = ({
  isOpen,
  onClose,
  onSaveAsNote,
  onAskAi,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('الكل');
  const [selectedArticleId, setSelectedArticleId] = useState<string>(
    COMPREHENSIVE_ENCYCLOPEDIA_ARTICLES[0]?.id || ''
  );
  const [copiedFormula, setCopiedFormula] = useState(false);
  const [copiedArticle, setCopiedArticle] = useState(false);
  const [noteSaved, setNoteSaved] = useState(false);
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [showMobileDetail, setShowMobileDetail] = useState(false);

  const tts = useTextToSpeech();

  // Categories list with counts
  const categories = useMemo(() => {
    const map = new Map<string, number>();
    map.set('الكل', COMPREHENSIVE_ENCYCLOPEDIA_ARTICLES.length);
    for (const art of COMPREHENSIVE_ENCYCLOPEDIA_ARTICLES) {
      const cat = art.category || 'عام';
      map.set(cat, (map.get(cat) || 0) + 1);
    }
    return Array.from(map.entries()).map(([name, count]) => ({ name, count }));
  }, []);

  // Filtered articles
  const filteredArticles = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return COMPREHENSIVE_ENCYCLOPEDIA_ARTICLES.filter((art) => {
      const matchesCat = selectedCategory === 'الكل' || art.category === selectedCategory;
      if (!matchesCat) return false;
      if (!q) return true;

      const titleMatch = art.title.toLowerCase().includes(q);
      const summaryMatch = art.summary.toLowerCase().includes(q);
      const tagsMatch = art.tags?.some((t) => t.toLowerCase().includes(q));
      const formulaMatch = art.formulaLatex?.toLowerCase().includes(q);
      const contentMatch = art.markdownContent.toLowerCase().includes(q);

      return titleMatch || summaryMatch || tagsMatch || formulaMatch || contentMatch;
    });
  }, [searchQuery, selectedCategory]);

  // Current active article
  const currentArticle: EncyclopediaArticle | undefined = useMemo(() => {
    return (
      COMPREHENSIVE_ENCYCLOPEDIA_ARTICLES.find((a) => a.id === selectedArticleId) ||
      filteredArticles[0] ||
      COMPREHENSIVE_ENCYCLOPEDIA_ARTICLES[0]
    );
  }, [selectedArticleId, filteredArticles]);

  if (!isOpen) return null;

  const handleCopyFormula = (latex: string) => {
    navigator.clipboard.writeText(latex);
    setCopiedFormula(true);
    setTimeout(() => setCopiedFormula(false), 2000);
  };

  const handleCopyArticle = (article: EncyclopediaArticle) => {
    const fullText = `# ${article.title}\nالتصنيف: ${article.category} - ${article.subCategory}\n\n${article.summary}\n\n${article.markdownContent}`;
    navigator.clipboard.writeText(fullText);
    setCopiedArticle(true);
    setTimeout(() => setCopiedArticle(false), 2000);
  };

  const handleSaveToNotebook = (article: EncyclopediaArticle) => {
    if (onSaveAsNote) {
      const noteBody = `## ${article.title}\n**التصنيف:** ${article.category} (${article.subCategory})\n\n${article.summary}\n\n${article.formulaLatex ? `### الصيغة الرياضية / القانون الأساسي:\n$$${article.formulaLatex}$$\n\n` : ''}${article.markdownContent}\n\n**المراجع:**\n${article.references.map((r) => `- ${r}`).join('\n')}`;
      onSaveAsNote(article.title, noteBody);
      setNoteSaved(true);
      setTimeout(() => setNoteSaved(false), 2500);
    }
  };

  const handleAskInChat = (article: EncyclopediaArticle) => {
    if (onAskAi) {
      const prompt = `أريد مناقشة هذا المرجع الأكاديمي الموسوعي بشكل معمق ومفصل:\n\n**الموضوع:** ${article.title}\n**التصنيف:** ${article.category} - ${article.subCategory}\n**القوانين الأساسية:** ${article.formulaLatex || 'لا يوجد'}\n**ملخص المرجع:** ${article.summary}\n\nيرجى شرح المفاهيم العميقة، والتطبيقات الواقعية، والمسائل التحليلية المرتبطة به بدقة.`;
      onAskAi(prompt);
      onClose();
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const toggleTts = () => {
    if (!currentArticle) return;
    if (tts.isPlaying && !tts.isPaused) {
      tts.pause();
    } else if (tts.isPaused) {
      tts.resume();
    } else {
      const textToSpeak = `${currentArticle.title}. ${currentArticle.summary}. المفاهيم الأساسية: ${currentArticle.keyConcepts.join('. ')}. ${currentArticle.markdownContent.replace(/[#*$`]/g, '')}`;
      tts.speak(textToSpeak, { title: currentArticle.title, speed: 0.95 });
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/70 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className={`bg-white dark:bg-[#111c18] border border-slate-200 dark:border-[#20362f] rounded-2xl shadow-2xl flex flex-col overflow-hidden transition-all duration-200 ${
          isFullScreen ? 'w-full h-full rounded-none' : 'w-full max-w-6xl h-[92vh]'
        }`}
        dir="rtl"
      >
        {/* Header */}
        <div className="px-4 py-3 sm:px-6 sm:py-4 bg-slate-50 dark:bg-[#162520] border-b border-slate-200 dark:border-[#20362f] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-teal-600/10 dark:bg-teal-500/20 text-teal-600 dark:text-teal-400 flex items-center justify-center shrink-0 border border-teal-500/30">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black text-slate-900 dark:text-slate-100">
                  المكتبة والمرجع الأكاديمي الشامل
                </h2>
                <span className="text-[10px] font-bold bg-teal-100 dark:bg-teal-950 text-teal-800 dark:text-teal-300 px-2 py-0.5 rounded-full border border-teal-300 dark:border-teal-800">
                  {COMPREHENSIVE_ENCYCLOPEDIA_ARTICLES.length} مرجعاً تخصصياً
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 hidden sm:block">
                موسوعة أكاديمية موثقة ومعادلات رياضية وفيزيائية وطبية مصاغة بدقة KaTeX القياسية
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2">
            <button
              onClick={() => setIsFullScreen(!isFullScreen)}
              className="p-2 rounded-xl text-slate-500 hover:bg-slate-200 dark:hover:bg-[#1d312a] transition-colors hidden sm:inline-flex cursor-pointer"
              title={isFullScreen ? 'تصغير' : 'ملء الشاشة'}
            >
              {isFullScreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-500 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/30 transition-colors cursor-pointer"
              aria-label="إغلاق"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="flex-1 flex overflow-hidden min-h-0">
          {/* Right Panel: Articles List & Search */}
          <div
            className={`w-full md:w-80 lg:w-96 border-l border-slate-200 dark:border-[#20362f] bg-slate-50/60 dark:bg-[#131f1a] flex flex-col shrink-0 ${
              showMobileDetail ? 'hidden md:flex' : 'flex'
            }`}
          >
            {/* Search Input */}
            <div className="p-3 border-b border-slate-200 dark:border-[#20362f] space-y-2">
              <div className="relative">
                <input
                  type="text"
                  placeholder="ابحث في العلوم، القوانين، والمفاهيم..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-3 pr-9 py-2 text-xs bg-white dark:bg-[#182923] border border-slate-200 dark:border-[#274037] rounded-xl text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-teal-500 transition-colors"
                />
                <Search className="w-4 h-4 text-slate-400 absolute right-3 top-2.5" />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute left-2.5 top-2.5 text-slate-400 hover:text-slate-600 text-xs"
                  >
                    ×
                  </button>
                )}
              </div>

              {/* Category Pills Slider */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar text-xs">
                {categories.map((cat) => (
                  <button
                    key={cat.name}
                    onClick={() => setSelectedCategory(cat.name)}
                    className={`px-2.5 py-1 rounded-lg font-bold text-[11px] whitespace-nowrap transition-all cursor-pointer ${
                      selectedCategory === cat.name
                        ? 'bg-teal-600 text-white shadow-xs'
                        : 'bg-white dark:bg-[#182923] text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-[#20362e] border border-slate-200 dark:border-[#274037]'
                    }`}
                  >
                    <span>{cat.name}</span>
                    <span className="mr-1 opacity-75 text-[10px]">({cat.count})</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Articles List */}
            <div className="flex-1 overflow-y-auto p-2 space-y-1.5">
              {filteredArticles.length === 0 ? (
                <div className="p-8 text-center text-slate-400 text-xs">
                  لا توجد مراجع تطابق بحثك حالياً
                </div>
              ) : (
                filteredArticles.map((art) => {
                  const isSelected = art.id === currentArticle?.id;
                  return (
                    <button
                      key={art.id}
                      onClick={() => {
                        setSelectedArticleId(art.id);
                        setShowMobileDetail(true);
                      }}
                      className={`w-full text-right p-3 rounded-xl transition-all cursor-pointer border ${
                        isSelected
                          ? 'bg-white dark:bg-[#192b24] border-teal-500 shadow-md ring-2 ring-teal-500/20'
                          : 'bg-white/80 dark:bg-[#15231e] border-slate-200/80 dark:border-[#20362f] hover:border-slate-300 dark:hover:border-[#2a453c]'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-1 mb-1">
                        <span className="text-[10px] font-bold text-teal-700 dark:text-teal-300 bg-teal-50 dark:bg-teal-950/60 px-2 py-0.5 rounded-md">
                          {art.category}
                        </span>
                        <div className="flex items-center gap-1 text-[10px] text-slate-400 font-mono">
                          <Clock className="w-3 h-3" />
                          <span>{art.readingTimeMinutes} د</span>
                        </div>
                      </div>
                      <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100 line-clamp-1">
                        {art.title}
                      </h4>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-2 mt-1 leading-relaxed">
                        {art.summary}
                      </p>
                      {art.formulaLatex && (
                        <div className="mt-1.5 pt-1 border-t border-slate-100 dark:border-[#1d2f28] flex items-center justify-between">
                          <span className="text-[9px] font-mono text-teal-600 dark:text-teal-400 font-bold truncate max-w-[200px]">
                            {art.formulaLatex.slice(0, 35)}...
                          </span>
                          <span className="text-[9px] text-slate-400 font-semibold">صيغة KaTeX</span>
                        </div>
                      )}
                    </button>
                  );
                })
              )}
            </div>
          </div>

          {/* Left Panel: Active Article Reader & High-Yield Visuals */}
          <div
            className={`flex-1 bg-white dark:bg-[#111c18] flex flex-col overflow-y-auto ${
              !showMobileDetail ? 'hidden md:flex' : 'flex'
            }`}
          >
            {currentArticle ? (
              <div className="p-4 sm:p-6 lg:p-8 max-w-4xl mx-auto w-full space-y-6">
                {/* Mobile Back Button */}
                <div className="md:hidden flex items-center justify-between pb-3 border-b border-slate-200 dark:border-[#20362f]">
                  <button
                    onClick={() => setShowMobileDetail(false)}
                    className="flex items-center gap-1 text-xs font-bold text-teal-600 dark:text-teal-400 cursor-pointer"
                  >
                    <ChevronRight className="w-4 h-4" />
                    <span>العودة إلى قائمة المراجع</span>
                  </button>
                  <span className="text-[11px] font-bold text-slate-400">
                    {currentArticle.category}
                  </span>
                </div>

                {/* Article Header Card */}
                <div className="p-5 sm:p-6 rounded-2xl bg-gradient-to-br from-teal-500/10 via-emerald-500/5 to-transparent border border-teal-500/20">
                  <div className="flex flex-wrap items-center gap-2 mb-2">
                    <span className="px-2.5 py-0.5 rounded-full text-[11px] font-black bg-teal-600 text-white shadow-xs">
                      {currentArticle.category}
                    </span>
                    <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-white dark:bg-[#192b24] text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-[#274037]">
                      {currentArticle.subCategory}
                    </span>
                    <span className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1 font-mono">
                      <Clock className="w-3.5 h-3.5" />
                      <span>زمن القراءة: {currentArticle.readingTimeMinutes} دقائق</span>
                    </span>
                  </div>

                  <h1 className="text-xl sm:text-2xl lg:text-3xl font-black text-slate-900 dark:text-slate-100 tracking-tight leading-snug">
                    {currentArticle.title}
                  </h1>

                  <p className="mt-3 text-sm text-slate-600 dark:text-slate-300 leading-relaxed font-normal">
                    {currentArticle.summary}
                  </p>

                  {/* High-Impact Actions Bar */}
                  <div className="mt-5 pt-4 border-t border-teal-500/20 flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      {/* TTS Button */}
                      <button
                        onClick={toggleTts}
                        className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-xs ${
                          tts.isPlaying && !tts.isPaused
                            ? 'bg-amber-500 text-white animate-pulse'
                            : 'bg-teal-600 text-white hover:bg-teal-700'
                        }`}
                        title="استماع صوتي للمرجع عبر الذكاء الاصطناعي والصوت الاصطناعي"
                      >
                        {tts.isPlaying && !tts.isPaused ? (
                          <>
                            <Pause className="w-3.5 h-3.5" />
                            <span>إيقاف مؤقت للقراءة</span>
                          </>
                        ) : (
                          <>
                            <Play className="w-3.5 h-3.5" />
                            <span>استماع صوتي للمرجع</span>
                          </>
                        )}
                      </button>

                      {/* Save to Notebook Button */}
                      {onSaveAsNote && (
                        <button
                          onClick={() => handleSaveToNotebook(currentArticle)}
                          className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 border transition-all cursor-pointer ${
                            noteSaved
                              ? 'bg-emerald-50 dark:bg-emerald-950 border-emerald-500 text-emerald-700 dark:text-emerald-300'
                              : 'bg-white dark:bg-[#192b24] border-slate-200 dark:border-[#274037] text-slate-700 dark:text-slate-200 hover:border-teal-500'
                          }`}
                        >
                          {noteSaved ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <FileText className="w-3.5 h-3.5 text-teal-600" />}
                          <span>{noteSaved ? 'تم الحفظ في الدفتر ✓' : 'حفظ كتدوينة في الدفتر'}</span>
                        </button>
                      )}

                      {/* Ask AI in Chat */}
                      {onAskAi && (
                        <button
                          onClick={() => handleAskInChat(currentArticle)}
                          className="px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 bg-gradient-to-r from-teal-600 to-emerald-600 text-white hover:opacity-95 shadow-xs transition-all cursor-pointer"
                        >
                          <MessageSquare className="w-3.5 h-3.5" />
                          <span>ناقش مع المعلم الذكي</span>
                        </button>
                      )}
                    </div>

                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => handleCopyArticle(currentArticle)}
                        className="p-2 rounded-xl text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-[#1a2c25] transition-colors cursor-pointer"
                        title="نسخ نص المرجع كاملاً"
                      >
                        {copiedArticle ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
                      </button>
                      <button
                        onClick={handlePrint}
                        className="p-2 rounded-xl text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-[#1a2c25] transition-colors cursor-pointer"
                        title="طباعة هذا المرجع الأكاديمي"
                      >
                        <Printer className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>

                {/* Key Concepts Box */}
                {currentArticle.keyConcepts && currentArticle.keyConcepts.length > 0 && (
                  <div className="p-4 sm:p-5 rounded-2xl bg-amber-50/70 dark:bg-amber-950/20 border border-amber-200/80 dark:border-amber-800/40">
                    <h3 className="text-xs font-black text-amber-900 dark:text-amber-200 uppercase tracking-wider mb-2.5 flex items-center gap-1.5">
                      <Sparkles className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                      <span>المفاهيم والركائز الأساسية (High-Yield Concepts)</span>
                    </h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-amber-950 dark:text-amber-100">
                      {currentArticle.keyConcepts.map((concept, i) => (
                        <div key={i} className="flex items-start gap-2 bg-white/60 dark:bg-[#192b24]/60 p-2.5 rounded-xl border border-amber-100 dark:border-amber-900/30">
                          <Check className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                          <span className="leading-relaxed">{concept}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Mathematical / Scientific Formula Showcase Card */}
                {currentArticle.formulaLatex && (
                  <div className="p-5 rounded-2xl bg-slate-900 text-white border border-slate-800 shadow-xl relative overflow-hidden group">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-teal-500/10 rounded-full blur-2xl pointer-events-none" />
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <GraduationCap className="w-4 h-4 text-teal-400" />
                        <span className="text-xs font-bold text-slate-300">
                          الصيغة والقانون الرياضي / الفيزيائي الأساسي (KaTeX Clean Math)
                        </span>
                      </div>
                      <button
                        onClick={() => handleCopyFormula(currentArticle.formulaLatex!)}
                        className="flex items-center gap-1 text-[11px] font-bold text-teal-300 bg-teal-950/80 hover:bg-teal-900 px-2.5 py-1 rounded-lg border border-teal-800 transition-colors cursor-pointer"
                      >
                        {copiedFormula ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>{copiedFormula ? 'تم النسخ!' : 'نسخ صيغة LaTeX'}</span>
                      </button>
                    </div>

                    <div className="py-4 px-3 bg-black/40 rounded-xl border border-slate-800 text-center overflow-x-auto text-emerald-300 font-mono">
                      <SafeMathText text={`$$${currentArticle.formulaLatex}$$`} />
                    </div>
                  </div>
                )}

                {/* Full Article Detailed Markdown Body with Safe KaTeX */}
                <div className="prose dark:prose-invert max-w-none text-slate-800 dark:text-slate-200 leading-relaxed text-sm">
                  <SafeMathText text={currentArticle.markdownContent} />
                </div>

                {/* Academic References & Citations */}
                {currentArticle.references && currentArticle.references.length > 0 && (
                  <div className="pt-6 border-t border-slate-200 dark:border-[#20362f]">
                    <h4 className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>المراجع الأكاديمية والمصادر المعتمدة</span>
                    </h4>
                    <ul className="space-y-1 text-xs text-slate-600 dark:text-slate-400 font-mono">
                      {currentArticle.references.map((ref, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <span className="text-teal-600 dark:text-teal-400">[{idx + 1}]</span>
                          <span>{ref}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Tags Footer */}
                {currentArticle.tags && (
                  <div className="flex flex-wrap items-center gap-1.5 pt-4 pb-8">
                    <Tag className="w-3.5 h-3.5 text-slate-400" />
                    {currentArticle.tags.map((t, idx) => (
                      <span
                        key={idx}
                        className="text-[10px] font-bold bg-slate-100 dark:bg-[#1a2c25] text-slate-600 dark:text-slate-300 px-2 py-0.5 rounded-md"
                      >
                        #{t}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            ) : (
              <div className="flex-1 flex items-center justify-center p-8 text-slate-400 text-sm">
                اختر مرجعاً من القائمة الجانبية لقراءته والاطلاع عليه
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
