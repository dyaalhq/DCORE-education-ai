import React, { useState, useEffect } from 'react';
import { 
  X, 
  Cloud, 
  CloudCheck, 
  RefreshCw, 
  LogOut, 
  CheckCircle2, 
  AlertCircle,
  Database,
  Shield,
  Smartphone,
  Laptop,
  UserPlus,
  Trash2,
  Users
} from 'lucide-react';
import { UserProfile } from '../types';
import { 
  getSavedGoogleAccounts, 
  removeSavedGoogleAccount, 
  SavedGoogleAccount 
} from '../lib/cloudAuth';

interface StudentAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  userProfile: UserProfile | null;
  onSignIn: (name?: string, email?: string) => Promise<void>;
  onSignOut: () => void;
  onSyncNow: () => Promise<void>;
  onRestoreFromCloud: () => Promise<void>;
  isSyncing: boolean;
  lastSyncAt?: number;
}

export const StudentAuthModal: React.FC<StudentAuthModalProps> = ({
  isOpen,
  onClose,
  userProfile,
  onSignIn,
  onSignOut,
  onSyncNow,
  onRestoreFromCloud,
  isSyncing,
  lastSyncAt,
}) => {
  const [customName, setCustomName] = useState('');
  const [customEmail, setCustomEmail] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [syncNotice, setSyncNotice] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [savedAccounts, setSavedAccounts] = useState<SavedGoogleAccount[]>([]);
  const [showAddForm, setShowAddForm] = useState(false);

  useEffect(() => {
    if (isOpen) {
      const accounts = getSavedGoogleAccounts();
      setSavedAccounts(accounts);
      if (accounts.length === 0) {
        setShowAddForm(true);
      } else {
        setShowAddForm(false);
      }
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleAccountSelect = async (account: SavedGoogleAccount) => {
    setIsSubmitting(true);
    setErrorMessage(null);
    try {
      await onSignIn(account.displayName, account.email);
      setSyncNotice(`تم تسجيل الدخول بنجاح بحساب ${account.email}`);
      setTimeout(() => setSyncNotice(null), 3000);
    } catch (err: any) {
      setErrorMessage(err?.message || 'تعذر تسجيل الدخول بالحساب المحدد.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleGoogleSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!customEmail.trim()) {
      setErrorMessage('يرجى إدخال بريد Google (Gmail)');
      return;
    }
    setIsSubmitting(true);
    setErrorMessage(null);
    try {
      await onSignIn(customName.trim() || undefined, customEmail.trim());
      setSyncNotice('تم تسجيل الدخول بنجاح وتفعيل المزامنة السحابية.');
      setSavedAccounts(getSavedGoogleAccounts());
      setTimeout(() => setSyncNotice(null), 3000);
    } catch (err: any) {
      setErrorMessage(err?.message || 'تعذر تسجيل الدخول.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleRemoveAccount = (e: React.MouseEvent, email: string) => {
    e.stopPropagation();
    const updated = removeSavedGoogleAccount(email);
    setSavedAccounts(updated);
    if (updated.length === 0) {
      setShowAddForm(true);
    }
  };

  const handleManualSync = async () => {
    setIsSubmitting(true);
    setErrorMessage(null);
    try {
      await onSyncNow();
      setSyncNotice('تمت المزامنة السحابية بنجاح وحفظ أحدث نسخة.');
      setTimeout(() => setSyncNotice(null), 3000);
    } catch (err: any) {
      setErrorMessage('فشلت المزامنة، يرجى التحقق من اتصال الشبكة.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleManualRestore = async () => {
    if (!confirm('هل تريد استبدال الحالة الحالية بآخر نسخة محفوظة في السحابة بحسابك؟')) {
      return;
    }
    setIsSubmitting(true);
    setErrorMessage(null);
    try {
      await onRestoreFromCloud();
      setSyncNotice('تمت استعادة كافة البيانات السحابية بنجاح.');
      setTimeout(() => setSyncNotice(null), 3000);
    } catch (err: any) {
      setErrorMessage('تعذر استعادة البيانات من السحابة.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white dark:bg-[#14201c] w-full max-w-md rounded-3xl shadow-2xl border border-[#e2e8e5] dark:border-[#22352f] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-[#e2e8e5] dark:border-[#22352f] bg-gradient-to-r from-teal-500/10 via-transparent to-transparent">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#0f766e] text-white flex items-center justify-center shadow-md shadow-teal-500/20">
              <Cloud className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-[#17201e] dark:text-[#eef7f4]">
                حساب Google والمزامنة السحابية
              </h3>
              <p className="text-xs text-[#596762] dark:text-[#9ab3ab]">
                حفظ دفاتر المذاكرة والملفات واسترجاعها من أي جهاز
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-gray-400 hover:text-gray-600 hover:bg-gray-100 dark:hover:bg-[#1a2723] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5">
          {userProfile ? (
            /* Signed In State */
            <div className="space-y-4">
              <div className="flex items-center gap-4 p-4 rounded-2xl bg-[#f6f8f7] dark:bg-[#1a2723] border border-[#e2e8e5] dark:border-[#22352f]">
                {userProfile.photoURL ? (
                  <img
                    src={userProfile.photoURL}
                    alt={userProfile.displayName}
                    className="w-14 h-14 rounded-2xl object-cover border-2 border-[#0f766e] shadow-sm shrink-0"
                  />
                ) : (
                  <div className="w-14 h-14 rounded-2xl bg-[#0f766e] text-white flex items-center justify-center font-bold text-xl shadow-sm shrink-0">
                    {userProfile.displayName.charAt(0)}
                  </div>
                )}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <h4 className="font-bold text-sm text-[#17201e] dark:text-[#eef7f4] truncate">
                      {userProfile.displayName}
                    </h4>
                    <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300">
                      <CheckCircle2 className="w-3 h-3" />
                      متصل سحابياً
                    </span>
                  </div>
                  <p className="text-xs text-[#596762] dark:text-[#9ab3ab] truncate mt-0.5 font-mono">
                    {userProfile.email}
                  </p>
                  <p className="text-[10px] text-teal-600 dark:text-teal-400 mt-1 flex items-center gap-1">
                    <Database className="w-3 h-3" />
                    {lastSyncAt
                      ? `آخر مزامنة: ${new Date(lastSyncAt).toLocaleTimeString('ar-SA')}`
                      : 'المزامنة السحابية التلقائية نشطة'}
                  </p>
                </div>
              </div>

              {/* Sync Features Info */}
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="p-3 rounded-xl bg-teal-50/50 dark:bg-teal-950/20 border border-teal-200/50 dark:border-teal-800/50 flex items-center gap-2">
                  <Laptop className="w-4 h-4 text-[#0f766e] shrink-0" />
                  <span className="text-[#17201e] dark:text-[#eef7f4] text-[11px] font-medium">مزامنة الكمبيوتر والمتصفح</span>
                </div>
                <div className="p-3 rounded-xl bg-teal-50/50 dark:bg-teal-950/20 border border-teal-200/50 dark:border-teal-800/50 flex items-center gap-2">
                  <Smartphone className="w-4 h-4 text-[#0f766e] shrink-0" />
                  <span className="text-[#17201e] dark:text-[#eef7f4] text-[11px] font-medium">مزامنة الهاتف والأجهزة اللوحية</span>
                </div>
              </div>

              {/* Actions */}
              <div className="space-y-2 pt-2">
                <button
                  type="button"
                  onClick={handleManualSync}
                  disabled={isSyncing || isSubmitting}
                  className="w-full py-2.5 px-4 bg-[#0f766e] text-white rounded-xl text-xs font-bold shadow-md hover:bg-[#115e59] transition-all flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
                >
                  <RefreshCw className={`w-4 h-4 ${isSyncing || isSubmitting ? 'animate-spin' : ''}`} />
                  <span>{isSyncing ? 'جاري المزامنة...' : 'مزامنة كافة الأعمال سحابياً الآن'}</span>
                </button>

                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={handleManualRestore}
                    disabled={isSubmitting}
                    className="flex-1 py-2 px-3 bg-white dark:bg-[#1a2723] border border-[#e2e8e5] dark:border-[#22352f] text-[#17201e] dark:text-[#eef7f4] rounded-xl text-xs font-medium hover:bg-gray-50 dark:hover:bg-[#1f2f2a] transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Cloud className="w-3.5 h-3.5 text-teal-600" />
                    <span>استعادة من السحابة</span>
                  </button>

                  <button
                    type="button"
                    onClick={onSignOut}
                    className="py-2 px-3 text-red-600 hover:bg-red-50 dark:hover:bg-red-950/30 rounded-xl text-xs font-medium transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>تسجيل الخروج</span>
                  </button>
                </div>
              </div>
            </div>
          ) : (
            /* Multi-Account Chooser & Google Sign-In */
            <div className="space-y-4">
              <div className="text-center space-y-1.5 py-1">
                <div className="w-14 h-14 mx-auto rounded-2xl bg-teal-50 dark:bg-teal-950/40 text-[#0f766e] dark:text-[#2dd4bf] flex items-center justify-center border border-teal-200 dark:border-teal-800 shadow-xs">
                  <Shield className="w-7 h-7" />
                </div>
                <h4 className="font-extrabold text-base text-[#17201e] dark:text-[#eef7f4]">
                  تسجيل الدخول بحساب Google
                </h4>
                <p className="text-xs text-[#596762] dark:text-[#9ab3ab] max-w-xs mx-auto leading-relaxed">
                  سجل دخولك بحسابك لحفظ ومزامنة كافة دفاتر المذاكرة والملفات في السحابة الخاصة بك.
                </p>
              </div>

              {/* Saved accounts list on this device */}
              {savedAccounts.length > 0 && !showAddForm && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between px-1">
                    <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                      <Users className="w-3.5 h-3.5 text-teal-600" />
                      <span>اختر حساب Google للمتابعة:</span>
                    </span>
                    <button
                      type="button"
                      onClick={() => setShowAddForm(true)}
                      className="text-[11px] font-bold text-teal-700 dark:text-teal-400 hover:underline flex items-center gap-1 cursor-pointer"
                    >
                      <UserPlus className="w-3 h-3" />
                      <span>إضافة حساب آخر</span>
                    </button>
                  </div>

                  <div className="space-y-2 max-h-56 overflow-y-auto pr-0.5">
                    {savedAccounts.map((acc) => (
                      <div
                        key={acc.email}
                        onClick={() => handleAccountSelect(acc)}
                        className="group flex items-center justify-between p-3 rounded-2xl bg-white dark:bg-[#1a2723] hover:bg-teal-50/50 dark:hover:bg-teal-950/30 border border-slate-200 dark:border-[#22352f] hover:border-teal-400 dark:hover:border-teal-600 shadow-xs transition-all cursor-pointer"
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          {acc.photoURL ? (
                            <img
                              src={acc.photoURL}
                              alt={acc.displayName}
                              className="w-10 h-10 rounded-xl object-cover shrink-0 border border-teal-500/30"
                            />
                          ) : (
                            <div className="w-10 h-10 rounded-xl bg-teal-700 text-white font-bold flex items-center justify-center text-sm shadow-xs shrink-0">
                              {acc.displayName.slice(0, 2)}
                            </div>
                          )}
                          <div className="text-right min-w-0">
                            <div className="text-xs font-bold text-slate-800 dark:text-slate-100 truncate">
                              {acc.displayName}
                            </div>
                            <div className="text-[11px] text-slate-500 dark:text-slate-400 font-mono truncate">
                              {acc.email}
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            type="button"
                            title="إزالة الحساب من هذا الجهاز"
                            onClick={(e) => handleRemoveAccount(e, acc.email)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30 transition-colors opacity-70 group-hover:opacity-100"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Add New / Custom Google Account Form */}
              {(showAddForm || savedAccounts.length === 0) && (
                <div className="space-y-3">
                  {savedAccounts.length > 0 && (
                    <div className="flex items-center justify-between px-1">
                      <span className="text-[11px] font-bold text-slate-600 dark:text-slate-300">
                        تسجيل الدخول بحساب Google جديد:
                      </span>
                      <button
                        type="button"
                        onClick={() => setShowAddForm(false)}
                        className="text-[11px] text-teal-600 hover:underline cursor-pointer"
                      >
                        العودة للحسابات السابقة
                      </button>
                    </div>
                  )}

                  <form onSubmit={handleGoogleSubmit} className="space-y-3">
                    <div>
                      <label className="block text-[11px] font-bold text-[#596762] dark:text-[#9ab3ab] mb-1">
                        الاسم أو اللقب
                      </label>
                      <input
                        type="text"
                        value={customName}
                        onChange={(e) => setCustomName(e.target.value)}
                        placeholder="اسمك الكامل"
                        className="w-full px-3.5 py-2.5 border border-[#e2e8e5] dark:border-[#22352f] rounded-xl bg-[#f6f8f7] dark:bg-[#1a2723] text-xs text-[#17201e] dark:text-[#eef7f4] focus:outline-none focus:border-teal-600 transition-colors"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-[#596762] dark:text-[#9ab3ab] mb-1">
                        بريد Google (Gmail)
                      </label>
                      <input
                        type="email"
                        required
                        value={customEmail}
                        onChange={(e) => setCustomEmail(e.target.value)}
                        placeholder="username@gmail.com"
                        className="w-full px-3.5 py-2.5 border border-[#e2e8e5] dark:border-[#22352f] rounded-xl bg-[#f6f8f7] dark:bg-[#1a2723] text-xs text-[#17201e] dark:text-[#eef7f4] focus:outline-none focus:border-teal-600 font-mono transition-colors"
                      />
                    </div>

                    <button
                      type="submit"
                      disabled={isSubmitting || !customEmail.trim()}
                      className="w-full py-3 bg-teal-700 hover:bg-teal-800 text-white rounded-xl text-xs font-bold shadow-md shadow-teal-700/20 transition-all flex items-center justify-center gap-2.5 cursor-pointer disabled:opacity-50"
                    >
                      <svg className="w-4 h-4 shrink-0 bg-white rounded-full p-0.5" viewBox="0 0 24 24">
                        <path
                          fill="#4285F4"
                          d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                        />
                        <path
                          fill="#34A853"
                          d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                        />
                        <path
                          fill="#FBBC05"
                          d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                        />
                        <path
                          fill="#EA4335"
                          d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                        />
                      </svg>
                      <span>{isSubmitting ? 'جاري الاتصال السحابي...' : 'تسجيل الدخول ومزامنة البيانات'}</span>
                    </button>
                  </form>
                </div>
              )}
            </div>
          )}

          {/* Feedback & Error Alerts */}
          {errorMessage && (
            <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 text-rose-800 dark:text-rose-200 border border-rose-200 dark:border-rose-800 text-xs font-semibold flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
              <span>{errorMessage}</span>
            </div>
          )}

          {syncNotice && (
            <div className="p-3 rounded-xl bg-teal-50 dark:bg-teal-950/40 text-teal-800 dark:text-teal-200 border border-teal-200 dark:border-teal-800 text-xs font-semibold flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-teal-600" />
              <span>{syncNotice}</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
