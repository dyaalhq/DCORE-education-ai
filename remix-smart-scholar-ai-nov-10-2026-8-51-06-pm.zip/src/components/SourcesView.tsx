import React, { useState, useEffect, useRef, useMemo } from 'react';
import { 
  Upload, 
  Globe, 
  Search, 
  FileText, 
  Trash2, 
  ExternalLink, 
  CheckSquare, 
  Square, 
  Eye, 
  MessageSquare, 
  Plus, 
  AlertCircle, 
  Loader2, 
  FileCode, 
  BookOpen,
  Sparkles,
  Layers,
  Edit2,
  Check,
  X,
  Clock,
  HardDrive,
  Hash,
  ChevronDown,
  ChevronUp,
  Filter,
  Highlighter,
  Bookmark,
  ArrowRight,
  Download,
  Zap,
  GraduationCap,
  Landmark,
  Heart,
  Volume2,
  Scissors,
  Share2
} from 'lucide-react';
import { Source, SourceChunk, SourceAnnotation, InitialIndexingReport } from '../types';
import { extractTextFromPDF, extractTextFromImage, chunkText } from '../lib/pdfExtractor';
import { parsePDFWithOCR } from '../lib/pdfParser';
import { cleanAndReshapePdfText } from '../lib/arabicReshaper';
import { storeFileBlob } from '../lib/storage';
import { extractPdfDeepLink } from '../lib/deepLinkResolver';
import { generateInitialIndexingReport } from '../lib/indexingReporter';
import { PDFPreviewAnnotator } from './PDFPreviewAnnotator';
import { AccessibleReaderView } from './AccessibleReaderView';
import { EducationalContent } from './EducationalContent';
import { SourceIntelligenceModal } from './SourceIntelligenceModal';
import { SourceInAppPreviewModal } from './SourceInAppPreviewModal';
import { QuickPreviewModal } from './QuickPreviewModal';
import { SourcePreviewModal } from './SourcePreviewModal';
import { WikipediaSearchModal } from './WikipediaSearchModal';
import { WebArticleClipperModal } from './WebArticleClipperModal';
import { exportSourceToPdf } from '../lib/sourcePdfExporter';
import { speakText } from '../lib/TextToSpeechService';
import { SourceCard, SearchResultItem } from './SourceCard';
import { vectorStore, IndexProgress } from '../lib/vectorStore';
import {
  YEMENI_CURRICULUM_AND_KNOWLEDGE_BANKS,
  createCurriculumSource,
  CurriculumSubject,
} from '../lib/yemeniCurriculumBank';

import { CitationExplorer } from './CitationExplorer';

interface SourcesViewProps {
  sources: Source[];
  chunks: SourceChunk[];
  currentNotebookId: string;
  onAddSource: (source: Source, chunks: SourceChunk[]) => void;
  onDeleteSource: (sourceId: string) => void;
  onRenameSource?: (sourceId: string, newTitle: string) => void;
  onDeleteMultipleSources?: (sourceIds: string[]) => void;
  selectedSourceIds: string[];
  onToggleSelectSource: (sourceId: string) => void;
  onSelectAllSources: () => void;
  onClearSelectedSources: () => void;
  onAskAboutSource: (source: Source) => void;
  onUpdateSourceAnnotations?: (sourceId: string, annotations: SourceAnnotation[]) => void;
  onAskAboutQuote?: (quote: string, pageNumber: number) => void;
  onExportToNote?: (title: string, content: string) => void;
  onUpdateSource?: (source: Source, chunks?: SourceChunk[]) => void;
  notebookName?: string;
  favoriteSourceIds?: string[];
  onToggleFavoriteSource?: (sourceId: string) => void;
}

export const SourcesView: React.FC<SourcesViewProps> = ({
  sources,
  chunks,
  currentNotebookId,
  onAddSource,
  onDeleteSource,
  onRenameSource,
  onDeleteMultipleSources,
  selectedSourceIds,
  onToggleSelectSource,
  onSelectAllSources,
  onClearSelectedSources,
  onAskAboutSource,
  onUpdateSourceAnnotations,
  onAskAboutQuote,
  onExportToNote,
  onUpdateSource,
  notebookName,
  favoriteSourceIds = [],
  onToggleFavoriteSource,
}) => {
  const [activeTab, setActiveTab] = useState<'upload' | 'curriculum_bank' | 'wikipedia' | 'url' | 'search' | 'paste' | 'citations'>('upload');
  const [urlInput, setUrlInput] = useState('');
  const [urlTitle, setUrlTitle] = useState('');
  const [pasteTitle, setPasteTitle] = useState('');
  const [pasteContent, setPasteContent] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [searchMode, setSearchMode] = useState<'curriculum' | 'general'>('curriculum');
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [searchAnswer, setSearchAnswer] = useState('');
  const [selectedSearchUris, setSelectedSearchUris] = useState<string[]>([]);
  const [searchCategoryFilter, setSearchCategoryFilter] = useState<
    'all' | 'curriculum' | 'notes' | 'solutions' | 'book' | 'wikipedia' | 'academic' | 'web'
  >('all');
  const [previewingSearchItem, setPreviewingSearchItem] = useState<any | null>(null);
  const [previewItemLoading, setPreviewItemLoading] = useState(false);
  const [previewItemContent, setPreviewItemContent] = useState('');

  // Wikipedia State
  const [wikiSearchQuery, setWikiSearchQuery] = useState('');
  const [wikiLang, setWikiLang] = useState<'ar' | 'en'>('ar');
  const [wikiResults, setWikiResults] = useState<any[]>([]);
  const [wikiLoading, setWikiLoading] = useState(false);
  const [wikiImportingTitle, setWikiImportingTitle] = useState<string | null>(null);

  // Yemeni Curriculum & Universal Knowledge Bank State
  const [curriculumTrackFilter, setCurriculumTrackFilter] = useState<'all' | 'علمي' | 'أدبي' | 'معارف عامة'>('all');
  const [selectedCurriculumSubject, setSelectedCurriculumSubject] = useState<CurriculumSubject | null>(null);
  
  const [isLoading, setIsLoading] = useState(false);
  const [statusMessage, setStatusMessage] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  
  // Preview & Reader
  const [quickPreviewSource, setQuickPreviewSource] = useState<Source | null>(null);
  const [inAppPreviewSource, setInAppPreviewSource] = useState<Source | null>(null);
  const [selectedPreviewSource, setSelectedPreviewSource] = useState<Source | null>(null);
  const [accessibleReaderSource, setAccessibleReaderSource] = useState<Source | null>(null);
  const [previewTab, setPreviewTab] = useState<'text' | 'html'>('text');
  const [isReaderWideMode, setIsReaderWideMode] = useState<boolean>(false);
  const [intelligenceModalSource, setIntelligenceModalSource] = useState<Source | null>(null);
  const [activeIndexingReport, setActiveIndexingReport] = useState<InitialIndexingReport | null>(null);
  
  // Real-time Dynamic Vector Store Indexing Progress (Web Worker)
  const [indexingProgress, setIndexingProgress] = useState<IndexProgress | null>(() => vectorStore.getActiveProgress());

  useEffect(() => {
    const unsubscribe = vectorStore.subscribeProgress((progress: IndexProgress | null) => {
      setIndexingProgress(progress ? { ...progress } : null);
    });
    return unsubscribe;
  }, []);

  useEffect(() => {
    if (selectedPreviewSource) {
      setTimeout(() => {
        document.getElementById('active-source-reader-container')?.scrollIntoView({
          behavior: 'smooth',
          block: 'start',
        });
      }, 100);
    }
  }, [selectedPreviewSource?.id]);
  
  // Search inside reader
  const [sourceSearchTerm, setSourceSearchTerm] = useState('');
  const [activeMatchIndex, setActiveMatchIndex] = useState(0);

  // Search/Filter in sources list
  const [listFilterQuery, setListFilterQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<'all' | 'favorite' | 'pdf' | 'html' | 'image' | 'text' | 'audio' | 'wikipedia'>('all');

  // Preview & Wikipedia Modals
  const [previewModalSource, setPreviewModalSource] = useState<Source | null>(null);
  const [isWikiModalOpen, setIsWikiModalOpen] = useState<boolean>(false);
  const [isClipperModalOpen, setIsClipperModalOpen] = useState<boolean>(false);

  // Renaming state
  const [editingSourceId, setEditingSourceId] = useState<string | null>(null);
  const [editingTitle, setEditingTitle] = useState('');

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Sync annotations changes to parent & local preview
  const handleUpdateAnnotations = (sourceId: string, annotations: SourceAnnotation[]) => {
    if (onUpdateSourceAnnotations) {
      onUpdateSourceAnnotations(sourceId, annotations);
    }
    if (selectedPreviewSource && selectedPreviewSource.id === sourceId) {
      setSelectedPreviewSource((prev) => (prev ? { ...prev, annotations, updatedAt: Date.now() } : null));
    }
  };

  // Helper format file size
  const formatSize = (bytes: number) => {
    if (!bytes) return '0 B';
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  // Helper format upload date
  const formatDate = (ts: number) => {
    if (!ts) return '';
    return new Date(ts).toLocaleDateString('ar-EG', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  // Helper format source badge & theme
  const getSourceFormatBadge = (src: Source) => {
    if (src.type.includes('pdf') || (src.pages && src.pages.length > 1)) {
      return {
        label: 'مستند PDF',
        color: 'bg-rose-50 dark:bg-rose-950/70 text-rose-700 dark:text-rose-300 border-rose-200 dark:border-rose-800/80',
        icon: <BookOpen className="w-3 h-3 text-rose-600 dark:text-rose-400" />
      };
    }
    if (src.type.includes('image') || /\.(png|jpe?g|webp|bmp)$/i.test(src.title)) {
      return {
        label: 'صورة OCR',
        color: 'bg-cyan-50 dark:bg-cyan-950/70 text-cyan-700 dark:text-cyan-300 border-cyan-200 dark:border-cyan-800/80',
        icon: <Eye className="w-3 h-3 text-cyan-600 dark:text-cyan-400" />
      };
    }
    if (src.type.includes('audio') || /\.(mp3|wav|m4a|ogg|aac|webm)$/i.test(src.title)) {
      return {
        label: 'تسجيل صوتي Whisper',
        color: 'bg-emerald-50 dark:bg-emerald-950/70 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800/80',
        icon: <Volume2 className="w-3 h-3 text-emerald-600 dark:text-emerald-400" />
      };
    }
    if (src.type === 'wikipedia' || src.title.includes('ويكيبيديا') || src.uri?.includes('wikipedia')) {
      return {
        label: 'موسوعة ويكيبيديا',
        color: 'bg-teal-50 dark:bg-teal-950/70 text-teal-700 dark:text-teal-300 border-teal-200 dark:border-teal-800/80',
        icon: <Globe className="w-3 h-3 text-teal-600 dark:text-teal-400" />
      };
    }
    if (src.type.includes('html') || src.title.endsWith('.html') || src.title.endsWith('.htm')) {
      return {
        label: 'مقال / صفحة ويب',
        color: 'bg-amber-50 dark:bg-amber-950/70 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800/80',
        icon: <FileCode className="w-3 h-3 text-amber-600 dark:text-amber-400" />
      };
    }
    if (src.title.endsWith('.docx') || src.type.includes('word')) {
      return {
        label: 'مستند Word',
        color: 'bg-blue-50 dark:bg-blue-950/70 text-blue-700 dark:text-blue-300 border-blue-200 dark:border-blue-800/80',
        icon: <FileText className="w-3 h-3 text-blue-600 dark:text-blue-400" />
      };
    }
    return {
      label: 'نص TXT / MD',
      color: 'bg-slate-50 dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800',
      icon: <FileText className="w-3 h-3 text-slate-500 dark:text-slate-400" />
    };
  };

  // File Upload Handler (PDF, HTML, TXT, MD, CSV, JSON)
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    setIsLoading(true);
    setErrorMsg('');

    for (const file of files) {
      try {
        setStatusMessage(`جاري قراءة الملف: ${file.name}...`);
        const sourceId = `src_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
        let textContent = '';
        let rawHtml: string | undefined = undefined;
        let headings: string[] = [];
        let pageCount: number | undefined = undefined;
        let pages: Array<{ pageNumber: number; text: string }> | undefined = undefined;

        if (file.type === 'application/pdf' || file.name.endsWith('.pdf')) {
          setStatusMessage(`جاري استخراج وفك ضغط صفحات PDF: ${file.name}...`);
          try {
            const pdfResult = await extractTextFromPDF(file, (p) => {
              setStatusMessage(`${p.status} (${file.name})`);
            });
            textContent = pdfResult.fullText;
            pageCount = pdfResult.totalPages;
            pages = pdfResult.pages;
            if (pdfResult.ocrApplied) {
              setStatusMessage(`تم تطبيق المعالجة البصرية OCR بنجاح على صفحات «${file.name}»`);
            }
          } catch (browserPdfErr: any) {
            console.warn('Browser PDF extraction issue, falling back to local server extractor:', browserPdfErr);
            setStatusMessage(`جاري التفكيك السحابي فائق السرعة لملف الـ PDF: ${file.name}...`);
            const base64Data = await new Promise<string>((resolve, reject) => {
              const reader = new FileReader();
              reader.onload = () => {
                const res = (reader.result as string) || '';
                const base64 = res.split(',')[1] || '';
                resolve(base64);
              };
              reader.onerror = reject;
              reader.readAsDataURL(file);
            });

            const srvRes = await fetch('/api/extract-pdf', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ dataBase64: base64Data, fileName: file.name }),
            });

            const srvData = await srvRes.json();
            if (!srvRes.ok || !srvData.success) {
              throw new Error(srvData.error || 'تعذر استخراج محتوى ملف الـ PDF');
            }
            textContent = srvData.text || '';
            pageCount = srvData.totalPages || 1;
            pages = srvData.pages || [{ pageNumber: 1, text: textContent }];
          }
        } else if (file.type.startsWith('image/') || /\.(png|jpe?g|webp|bmp)$/i.test(file.name)) {
          setStatusMessage(`جاري استخراج النصوص بالمعالجة البصرية OCR: ${file.name}...`);
          const imgResult = await extractTextFromImage(file, (p) => {
            setStatusMessage(`${p.status} (${file.name})`);
          });
          textContent = imgResult.fullText;
          pageCount = 1;
          pages = imgResult.pages;
        } else if (file.type.startsWith('audio/') || /\.(mp3|wav|m4a|ogg|aac|webm|flac|amr|wma)$/i.test(file.name)) {
          setStatusMessage(`جاري تفريغ الصوت وتحويله إلى نص (Whisper / Speech-to-Text): ${file.name}...`);
          
          // Convert audio file to Base64
          const arrayBuffer = await file.arrayBuffer();
          const bytes = new Uint8Array(arrayBuffer);
          let binary = '';
          const len = bytes.byteLength;
          for (let i = 0; i < len; i += 32768) {
            binary += String.fromCharCode.apply(null, Array.from(bytes.subarray(i, Math.min(i + 32768, len))));
          }
          const base64Audio = btoa(binary);

          const transcribeRes = await fetch('/api/transcribe-audio', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              audioBase64: base64Audio,
              mimeType: file.type || 'audio/mp3',
              fileName: file.name,
            }),
          });

          if (!transcribeRes.ok) {
            const errData = await transcribeRes.json().catch(() => ({}));
            throw new Error(errData.error || `خطأ خادم التفريغ الصوتي (${transcribeRes.status})`);
          }

          const transcribeData = await transcribeRes.json();
          textContent = `# 🎙️ تفريغ صوتي للمحاضرة: ${file.name}\n\n${transcribeData.text}`;
          headings.push(`تفريغ صوتي: ${file.name}`);
          pageCount = 1;
          pages = [{ pageNumber: 1, text: textContent }];
          setStatusMessage(`تم استخراج نصوص التسجيل الصوتي «${file.name}» بنجاح!`);
        } else if (file.name.endsWith('.docx') || file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
          setStatusMessage(`جاري قراءة مستند Word: ${file.name}...`);
          const arrayBuffer = await file.arrayBuffer();
          const mammothModule = await import('mammoth');
          const mammoth = (mammothModule as any).default || mammothModule;
          const docxResult = await mammoth.extractRawText({ arrayBuffer });
          textContent = docxResult.value || '';
          pageCount = 1;
          pages = [{ pageNumber: 1, text: textContent }];
        } else if (file.type === 'text/html' || file.name.endsWith('.html') || file.name.endsWith('.htm')) {
          setStatusMessage(`جاري قراءة وتنسيق HTML: ${file.name}...`);
          rawHtml = await file.text();
          const parser = new DOMParser();
          const doc = parser.parseFromString(rawHtml, 'text/html');
          
          doc.querySelectorAll('h1, h2, h3, h4').forEach((h) => {
            const headingText = h.textContent?.trim();
            if (headingText) headings.push(headingText);
          });

          doc.querySelectorAll('script, style, noscript, iframe').forEach((el) => el.remove());
          textContent = (doc.body?.innerText || rawHtml).replace(/\n\s*\n+/g, '\n\n').trim();
        } else {
          // Plain text / Markdown / JSON / CSV / .doc fallback
          textContent = await file.text();
          if (/\.(md|markdown|txt)$/i.test(file.name)) {
            headings = Array.from(textContent.matchAll(/^#{1,4}\s+(.+)$/gm), (match) => match[1].trim());
          }
        }

        // Normalize extracted content once before indexing, previews, reports, and AI retrieval.
        textContent = cleanAndReshapePdfText(textContent);
        if (pages?.length) {
          pages = pages.map((page) => ({
            ...page,
            text: cleanAndReshapePdfText(page.text),
          }));
        }

        // Store file Blob in IndexedDB
        await storeFileBlob(sourceId, file, { name: file.name, type: file.type, notebookId: currentNotebookId });

        // Generate chunks only from the canonical cleaned text.
        const generatedChunks = chunkText(textContent, sourceId, file.name, currentNotebookId);

        const newSource: Source = {
          id: sourceId,
          notebookId: currentNotebookId,
          title: file.name,
          type: file.type || 'text/plain',
          size: file.size,
          status: 'Ready',
          content: textContent,
          rawHtml,
          headings,
          pageCount,
          pages,
          annotations: [],
          wordCount: textContent.split(/\s+/).filter(Boolean).length,
          lineCount: textContent.split('\n').length,
          createdAt: Date.now(),
          updatedAt: Date.now(),
          localFileId: sourceId,
        };

        const indexingReport = generateInitialIndexingReport(
          file.name,
          textContent,
          headings,
          pageCount
        );
        newSource.indexingReport = indexingReport;
        setActiveIndexingReport(indexingReport);

        onAddSource(newSource, generatedChunks);
      } catch (err: any) {
        console.error('File upload error:', err);
        setErrorMsg(`فشل معالجة الملف «${file.name}»: ${err.message || err}`);
      }
    }

    setIsLoading(false);
    setStatusMessage('');
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  // Fetch URL Handler (True Binary PDF Fetching & Real Multi-Page Parsing)
  const handleFetchUrl = async (e: React.FormEvent) => {
    e.preventDefault();
    const rawUrl = urlInput.trim();
    if (!rawUrl) return;

    setIsLoading(true);
    setStatusMessage('جاري تنزيل ملف الـ PDF الثنائي من الخادم...');
    setErrorMsg('');

    const sourceId = `src_url_${Date.now()}`;
    const initialTitle = urlTitle.trim() || decodeURIComponent(rawUrl.split('/').filter(Boolean).pop()?.replace(/[-_.]+/g, ' ') || 'كتاب دراسي');
    const isLikelyPdf = /\.pdf($|[?#])/i.test(rawUrl) || /archive\.org\/download|drive\.google/i.test(rawUrl);

    try {
      // 1. True Binary Fetching via Proxy Route
      let buffer: ArrayBuffer | null = null;
      let contentType = '';

      try {
        const proxyUrl = `/api/proxy?url=${encodeURIComponent(rawUrl)}`;
        const pRes = await fetch(proxyUrl);
        if (pRes.ok) {
          contentType = pRes.headers.get('content-type') || '';
          buffer = await pRes.arrayBuffer();
        }
      } catch (proxyErr) {
        console.warn('Backend proxy fetch failed:', proxyErr);
      }

      if (!buffer || buffer.byteLength < 500) {
        try {
          const fallbackProxy = `https://corsproxy.io/?${encodeURIComponent(rawUrl)}`;
          const fRes = await fetch(fallbackProxy);
          if (fRes.ok) {
            contentType = fRes.headers.get('content-type') || '';
            buffer = await fRes.arrayBuffer();
          }
        } catch (fErr) {
          console.warn('Fallback proxy failed:', fErr);
        }
      }

      // Check %PDF magic bytes
      let isPdfBinary = buffer && buffer.byteLength >= 5 &&
        new Uint8Array(buffer.slice(0, 5)).reduce((acc, b) => acc + String.fromCharCode(b), '').startsWith('%PDF');

      // 2. Deep Link Resolver: If buffer is HTML, scan DOM tree for direct PDF download links
      if (buffer && !isPdfBinary) {
        setStatusMessage('فحص شجرة DOM للبحث عن رابط تحميل PDF المباشر...');
        const html = new TextDecoder('utf-8').decode(buffer);
        const directPdfLink = extractPdfDeepLink(html, rawUrl);
        if (directPdfLink) {
          setStatusMessage('تم العثور على رابط الـ PDF المباشر! جاري تنزيل الملف الثنائي...');
          try {
            const dlRes = await fetch(`/api/proxy?url=${encodeURIComponent(directPdfLink)}`);
            if (dlRes.ok) {
              const dlBuf = await dlRes.arrayBuffer();
              const dlIsPdf = dlBuf.byteLength >= 5 &&
                new Uint8Array(dlBuf.slice(0, 5)).reduce((acc, b) => acc + String.fromCharCode(b), '').startsWith('%PDF');
              if (dlIsPdf) {
                buffer = dlBuf;
                isPdfBinary = true;
              }
            }
          } catch (dlErr) {
            console.warn('Deep link proxy download failed in handleFetchUrl:', dlErr);
          }
        }
      }

      // 3. If binary PDF is ready (%PDF), unpack all real pages via PDF.js & OCR
      if (buffer && isPdfBinary) {
        setStatusMessage('جاري تفكيك وقراءة كامل صفحات الكتاب عبر PDF.js و OCR العربي...');
        const parsed = await parsePDFWithOCR(buffer, (p) => {
          setStatusMessage(p.status);
        });

        if (!parsed.pages || parsed.pages.length === 0 || !parsed.fullText.trim()) {
          throw new Error('الصفحة لا تحتوي على ملف كتاب PDF مباشر، يرجى رفع الملف من جهازك');
        }

        if (parsed.totalPages <= 1 || parsed.pages.length <= 1) {
          throw new Error('الصفحة لا تحتوي على ملف كتاب PDF مباشر، يرجى رفع الملف من جهازك');
        }

        // Store the real binary blob in IndexedDB for the PDF reader
        const pdfBlob = new Blob([buffer], { type: 'application/pdf' });
        await storeFileBlob(sourceId, pdfBlob);

        // Chunk real pages into RAG
        const realChunks = chunkText(parsed.fullText, sourceId, initialTitle, currentNotebookId, 750, 75);

        const newSource: Source = {
          id: sourceId,
          notebookId: currentNotebookId,
          title: initialTitle,
          uri: rawUrl,
          type: 'application/pdf',
          size: buffer.byteLength,
          status: 'Ready',
          content: parsed.fullText,
          wordCount: parsed.fullText.split(/\s+/).filter(Boolean).length,
          lineCount: parsed.fullText.split('\n').length,
          pageCount: parsed.totalPages,
          pages: parsed.pages,
          createdAt: Date.now(),
          updatedAt: Date.now(),
        };

        const indexingReport = generateInitialIndexingReport(
          initialTitle,
          parsed.fullText,
          parsed.pages?.map((p) => `صفحة ${p.pageNumber}`),
          parsed.totalPages
        );
        newSource.indexingReport = indexingReport;
        setActiveIndexingReport(indexingReport);

        onAddSource(newSource, realChunks);
        setUrlInput('');
        setUrlTitle('');
        setStatusMessage(`✓ تم استيراد وقراءة الكتاب كاملاً بنجاح (${parsed.totalPages} صفحة، ${realChunks.length} مقطع مفهرس في RAG)!`);
        setTimeout(() => setStatusMessage(''), 3500);
        return;
      }

      // 4. Server-side deep crawler via /api/fetch-url
      setStatusMessage('جاري فحص وتدقيق محتوى الرابط عبر المستكشف المتقدم...');
      const res = await fetch('/api/fetch-url', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: rawUrl }),
      });

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        throw new Error(errJson.error || 'الصفحة لا تحتوي على ملف كتاب PDF مباشر، يرجى رفع الملف من جهازك');
      }

      const data = await res.json();
      if (data.success === false) {
        throw new Error(data.error || 'الصفحة لا تحتوي على ملف كتاب PDF مباشر، يرجى رفع الملف من جهازك');
      }

      // Backend discovered and downloaded the original PDF binary
      if (data.type === 'pdf' || data.dataBase64) {
        setStatusMessage('تم استخراج وتنزيل ملف الـ PDF الأصلي بنجاح! جاري تفكيك وحفظ صفحاته...');
        let arrayBuf: ArrayBuffer;
        if (data.dataBase64) {
          const binaryString = atob(data.dataBase64);
          const bytes = new Uint8Array(binaryString.length);
          for (let i = 0; i < binaryString.length; i++) {
            bytes[i] = binaryString.charCodeAt(i);
          }
          arrayBuf = bytes.buffer;
          const pdfBlob = new Blob([bytes], { type: 'application/pdf' });
          await storeFileBlob(sourceId, pdfBlob);
        } else {
          arrayBuf = new ArrayBuffer(0);
        }

        let parsedPages = Array.isArray(data.pages) && data.pages.length > 0 ? data.pages : [];
        let fullBookText = data.content || data.text || '';
        let totalPageCount = data.pageCount || parsedPages.length;

        // If server provided fewer than 2 pages or missing pages, re-parse directly on client via PDF.js & OCR
        if (arrayBuf.byteLength > 1000 && (parsedPages.length <= 1 || !fullBookText.trim())) {
          try {
            setStatusMessage('جاري استخراج وتفكيك كافة صفحات الكتاب عبر محرك PDF.js...');
            const clientParsed = await parsePDFWithOCR(arrayBuf, (p) => {
              setStatusMessage(p.status);
            });
            if (clientParsed.pages && clientParsed.pages.length > 0 && clientParsed.fullText.trim()) {
              parsedPages = clientParsed.pages;
              fullBookText = clientParsed.fullText;
              totalPageCount = clientParsed.totalPages;
            }
          } catch (cErr) {
            console.warn('Client PDF.js parsing fallback:', cErr);
          }
        }

        if (totalPageCount < 1 || !fullBookText.trim()) {
          throw new Error('تعذر قراءة نصوص مقروءة من هذا الملف. يرجى التأكد من الرابط أو رفعه يدوياً.');
        }

        if (arrayBuf.byteLength > 0) {
          try {
            const pdfBlob = new Blob([arrayBuf], { type: 'application/pdf' });
            await storeFileBlob(sourceId, pdfBlob, {
              name: data.title || initialTitle,
              type: 'application/pdf',
              notebookId: currentNotebookId,
            });
          } catch (blobErr) {
            console.warn('Could not store fetched PDF blob:', blobErr);
          }
        }

        const realChunks = chunkText(fullBookText, sourceId, data.title || initialTitle, currentNotebookId, 750, 75);

        const newSource: Source = {
          id: sourceId,
          notebookId: currentNotebookId,
          title: data.title || initialTitle,
          uri: data.url || rawUrl,
          type: 'application/pdf',
          size: data.size || arrayBuf.byteLength || fullBookText.length,
          status: 'Ready',
          content: fullBookText,
          wordCount: data.wordCount || fullBookText.split(/\s+/).filter(Boolean).length,
          lineCount: data.lineCount || fullBookText.split('\n').length,
          pageCount: Math.max(1, totalPageCount),
          pages: parsedPages,
          createdAt: Date.now(),
          updatedAt: Date.now(),
          localFileId: sourceId,
        };

        const indexingReport = generateInitialIndexingReport(
          data.title || initialTitle,
          fullBookText,
          parsedPages.map((p: any) => `صفحة ${p.pageNumber}`),
          Math.max(1, totalPageCount)
        );
        newSource.indexingReport = indexingReport;
        setActiveIndexingReport(indexingReport);

        onAddSource(newSource, realChunks);
        setUrlInput('');
        setUrlTitle('');
        setStatusMessage(
          `✓ تم استيراد وقراءة الكتاب كاملاً بنجاح (${newSource.pageCount} صفحة، ${realChunks.length} مقطع مفهرس في RAG)!`
        );
        setTimeout(() => setStatusMessage(''), 3500);
        return;
      }

      // 5. Intelligent Web Page & Article Source Support (صفحات الويب والمقالات التعليمية والمناهج)
      if (data.type === 'web' || (data.content && data.content.trim().length >= 40)) {
        setStatusMessage('جاري تحليل وفهرسة مقال وصفحة الويب دلالياً...');
        const webText = data.content || data.text || '';
        const realChunks = chunkText(webText, sourceId, data.title || initialTitle, currentNotebookId, 750, 75);

        const newSource: Source = {
          id: sourceId,
          notebookId: currentNotebookId,
          title: data.title || initialTitle,
          uri: data.url || rawUrl,
          type: 'text/html',
          size: data.size || webText.length,
          status: 'Ready',
          content: webText,
          wordCount: data.wordCount || webText.split(/\s+/).filter(Boolean).length,
          lineCount: data.lineCount || webText.split('\n').length,
          pageCount: 1,
          createdAt: Date.now(),
          updatedAt: Date.now(),
        };

        const indexingReport = generateInitialIndexingReport(
          data.title || initialTitle,
          webText,
          ['صفحة الويب التعليمية'],
          1
        );
        newSource.indexingReport = indexingReport;
        setActiveIndexingReport(indexingReport);

        onAddSource(newSource, realChunks);
        setUrlInput('');
        setUrlTitle('');
        setStatusMessage(
          `✓ تم جلب وفهرسة محتوى صفحة الويب بنجاح (${newSource.wordCount} كلمة، ${realChunks.length} مقطع مفهرس في RAG)!`
        );
        setTimeout(() => setStatusMessage(''), 3500);
        return;
      }

      throw new Error('تعذر استخراج محتوى نصي مقروء من هذا الرابط. يرجى تزويد رابط مباشر لملف PDF أو مقال ويب متاح.');
    } catch (err: any) {
      setErrorMsg(err.message || 'تعذر جلب وفهرسة الرابط. يرجى التأكد من صحة العنوان أو رفع الملف من جهازك');
    } finally {
      setIsLoading(false);
    }
  };

  // Direct Text Paste Handler
  const handlePasteSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pasteContent.trim()) return;

    const sourceId = `src_paste_${Date.now()}`;
    const title = pasteTitle.trim() || `نص ملصق (${new Date().toLocaleTimeString('ar', { hour: '2-digit', minute: '2-digit' })})`;
    const content = pasteContent.trim();
    const generatedChunks = chunkText(content, sourceId, title, currentNotebookId);

    const newSource: Source = {
      id: sourceId,
      notebookId: currentNotebookId,
      title,
      type: 'text/plain',
      size: new Blob([content]).size,
      status: 'Ready',
      content,
      wordCount: content.split(/\s+/).filter(Boolean).length,
      lineCount: content.split('\n').length,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };

    onAddSource(newSource, generatedChunks);
    setPasteTitle('');
    setPasteContent('');
  };

  // Smart Web Search via Multi-Source Academic Engine & Gemini Grounding
  const handleWebSearch = async (e?: React.FormEvent, customQuery?: string, customMode?: 'curriculum' | 'general') => {
    if (e) e.preventDefault();
    const q = (customQuery !== undefined ? customQuery : searchQuery).trim();
    const mode = customMode || searchMode;
    if (!q) return;

    if (customQuery) setSearchQuery(customQuery);
    setIsLoading(true);
    setStatusMessage(
      mode === 'curriculum'
        ? 'جاري البحث الحصري عن الكتب والمناهج المدرسية وملفات الـ PDF مع التحقق الدلالي الصارم (>= 70%)...'
        : 'جاري استكشاف الموسوعات وقواعد المعرفة الأكاديمية...'
    );
    setErrorMsg('');
    setSearchAnswer('');
    setSearchResults([]);
    setSelectedSearchUris([]);

    try {
      const res = await fetch('/api/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: q, mode }),
      });

      if (!res.ok) throw new Error('تعذر إكمال البحث الذكي.');

      const data = await res.json();
      setSearchAnswer(data.answer || data.text || '');
      setSearchResults(data.sources || []);
    } catch (err: any) {
      setErrorMsg(err.message || 'حدث خطأ أثناء استكشاف المصادر');
    } finally {
      setIsLoading(false);
      setStatusMessage('');
    }
  };

  // Import Search Result into Notebook (True Binary PDF Fetching, Full Multi-Page Extraction, Zero Synthetic Stubs)
  const handleImportSearchResult = async (result: SearchResultItem) => {
    const sourceId = result.id || `src_pdf_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    const isLikelyPdf = result.category === 'book' || /\.pdf($|[?#])/i.test(result.uri) || /archive\.org\/download|drive\.google/i.test(result.uri);

    setIsLoading(true);
    setStatusMessage(`جاري تنزيل ملف الـ PDF الأصلي لـ «${result.title}» عبر البروكسي...`);
    setErrorMsg('');

    try {
      // 1. Fetch binary ArrayBuffer via Backend Proxy
      let buffer: ArrayBuffer | null = null;
      let contentType = '';

      try {
        const proxyUrl = `/api/proxy?url=${encodeURIComponent(result.uri)}`;
        const pRes = await fetch(proxyUrl);
        if (pRes.ok) {
          contentType = pRes.headers.get('content-type') || '';
          buffer = await pRes.arrayBuffer();
        }
      } catch (proxyErr) {
        console.warn('Backend proxy fetch failed:', proxyErr);
      }

      // Fallback proxy if needed
      if (!buffer || buffer.byteLength < 500) {
        try {
          const fallbackProxy = `https://corsproxy.io/?${encodeURIComponent(result.uri)}`;
          const fRes = await fetch(fallbackProxy);
          if (fRes.ok) {
            contentType = fRes.headers.get('content-type') || '';
            buffer = await fRes.arrayBuffer();
          }
        } catch (fErr) {
          console.warn('Fallback proxy failed:', fErr);
        }
      }

      // Check %PDF magic bytes
      let isPdfBinary = buffer && buffer.byteLength >= 5 &&
        new Uint8Array(buffer.slice(0, 5)).reduce((acc, b) => acc + String.fromCharCode(b), '').startsWith('%PDF');

      // 2. Deep Link Resolver: If buffer is HTML, scan DOM tree for direct PDF download links
      if (buffer && !isPdfBinary) {
        setStatusMessage('فحص شجرة DOM للبحث عن رابط تحميل PDF المباشر...');
        const html = new TextDecoder('utf-8').decode(buffer);
        const directPdfLink = extractPdfDeepLink(html, result.uri);
        if (directPdfLink) {
          setStatusMessage('تم العثور على رابط الـ PDF المباشر! جاري تنزيل الملف الثنائي...');
          try {
            const dlRes = await fetch(`/api/proxy?url=${encodeURIComponent(directPdfLink)}`);
            if (dlRes.ok) {
              const dlBuf = await dlRes.arrayBuffer();
              const dlIsPdf = dlBuf.byteLength >= 5 &&
                new Uint8Array(dlBuf.slice(0, 5)).reduce((acc, b) => acc + String.fromCharCode(b), '').startsWith('%PDF');
              if (dlIsPdf) {
                buffer = dlBuf;
                isPdfBinary = true;
              }
            }
          } catch (dlErr) {
            console.warn('Deep link proxy download failed in handleImportSearchResult:', dlErr);
          }
        }
      }

      // 3. If binary PDF is ready (%PDF), unpack all real pages via PDF.js & OCR
      if (buffer && isPdfBinary) {
        setStatusMessage(`جاري تفكيك وقراءة كافة صفحات الكتاب عبر PDF.js و OCR العربي...`);
        const parsed = await parsePDFWithOCR(buffer, (p) => {
          setStatusMessage(p.status);
        });

        if (!parsed.pages || parsed.pages.length === 0 || !parsed.fullText.trim()) {
          throw new Error('الصفحة لا تحتوي على ملف كتاب PDF مباشر، يرجى رفع الملف من جهازك');
        }

        if (parsed.totalPages <= 1 || parsed.pages.length <= 1) {
          throw new Error('الصفحة لا تحتوي على ملف كتاب PDF مباشر، يرجى رفع الملف من جهازك');
        }

        // Store real PDF binary in IndexedDB
        const pdfBlob = new Blob([buffer], { type: 'application/pdf' });
        await storeFileBlob(sourceId, pdfBlob);

        // Chunk real multi-page text
        const realChunks = chunkText(parsed.fullText, sourceId, result.title, currentNotebookId, 750, 75);

        const newSource: Source = {
          id: sourceId,
          notebookId: currentNotebookId,
          title: result.title,
          uri: result.uri,
          type: 'application/pdf',
          size: buffer.byteLength,
          status: 'Ready',
          content: parsed.fullText,
          wordCount: parsed.fullText.split(/\s+/).filter(Boolean).length,
          lineCount: parsed.fullText.split('\n').length,
          pageCount: parsed.totalPages,
          pages: parsed.pages,
          createdAt: Date.now(),
          updatedAt: Date.now(),
        };

        const indexingReport = generateInitialIndexingReport(
          result.title,
          parsed.fullText,
          parsed.pages?.map((p) => `صفحة ${p.pageNumber}`),
          parsed.totalPages
        );
        newSource.indexingReport = indexingReport;
        setActiveIndexingReport(indexingReport);

        onAddSource(newSource, realChunks);
        setStatusMessage(`✓ تم استيراد وقراءة الكتاب كاملاً بنجاح (${parsed.totalPages} صفحة، ${realChunks.length} مقطع مفهرس في RAG)!`);
        setTimeout(() => setStatusMessage(''), 3500);
        return;
      }

      // 4. Fallback deep crawler via backend /api/fetch-url
      setStatusMessage('فحص وتنزيل الكتاب عبر المستكشف المتقدم...');
      const res = await fetch('/api/fetch-url', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: result.uri }),
      });

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        throw new Error(errJson.error || 'الصفحة لا تحتوي على ملف كتاب PDF مباشر، يرجى رفع الملف من جهازك');
      }

      const data = await res.json();
      if (data.success === false) {
        throw new Error(data.error || 'الصفحة لا تحتوي على ملف كتاب PDF مباشر، يرجى رفع الملف من جهازك');
      }

      // A) Backend resolved and extracted a real binary PDF
      if (data.type === 'pdf' || data.dataBase64) {
        setStatusMessage('فهرسة وتخزين صفحات الكتاب في دفترك...');
        let arrayBuf: ArrayBuffer;
        if (data.dataBase64) {
          const binaryString = atob(data.dataBase64);
          const bytes = new Uint8Array(binaryString.length);
          for (let i = 0; i < binaryString.length; i++) {
            bytes[i] = binaryString.charCodeAt(i);
          }
          arrayBuf = bytes.buffer;
          const pdfBlob = new Blob([bytes], { type: 'application/pdf' });
          await storeFileBlob(sourceId, pdfBlob);
        } else {
          arrayBuf = new ArrayBuffer(0);
        }

        let parsedPages = Array.isArray(data.pages) && data.pages.length > 0 ? data.pages : [];
        let fullBookText = data.content || data.text || '';
        let totalPageCount = data.pageCount || parsedPages.length;

        // If server provided fewer than 2 pages or missing pages, re-parse directly on client via PDF.js & OCR
        if (arrayBuf.byteLength > 1000 && (parsedPages.length <= 1 || !fullBookText.trim())) {
          try {
            setStatusMessage('جاري استخراج وتفكيك كافة صفحات الكتاب عبر محرك PDF.js...');
            const clientParsed = await parsePDFWithOCR(arrayBuf, (p) => {
              setStatusMessage(p.status);
            });
            if (clientParsed.pages && clientParsed.pages.length > 0 && clientParsed.fullText.trim()) {
              parsedPages = clientParsed.pages;
              fullBookText = clientParsed.fullText;
              totalPageCount = clientParsed.totalPages;
            }
          } catch (cErr) {
            console.warn('Client PDF.js parsing fallback:', cErr);
          }
        }

        if (totalPageCount < 1 || !fullBookText.trim()) {
          throw new Error('تعذر قراءة نصوص مقروءة من هذا الملف. يرجى التأكد من الرابط أو رفعه يدوياً.');
        }

        const realChunks = chunkText(fullBookText, sourceId, result.title, currentNotebookId, 750, 75);

        const newSource: Source = {
          id: sourceId,
          notebookId: currentNotebookId,
          title: data.title || result.title,
          uri: result.uri,
          type: 'application/pdf',
          size: data.size || arrayBuf.byteLength || fullBookText.length,
          status: 'Ready',
          content: fullBookText,
          wordCount: data.wordCount || fullBookText.split(/\s+/).filter(Boolean).length,
          lineCount: data.lineCount || fullBookText.split('\n').length,
          pageCount: Math.max(1, totalPageCount),
          pages: parsedPages,
          createdAt: Date.now(),
          updatedAt: Date.now(),
        };

        const indexingReport = generateInitialIndexingReport(
          data.title || result.title,
          fullBookText,
          parsedPages.map((p: any) => `صفحة ${p.pageNumber}`),
          Math.max(1, totalPageCount)
        );
        newSource.indexingReport = indexingReport;
        setActiveIndexingReport(indexingReport);

        onAddSource(newSource, realChunks);
        setStatusMessage(`✓ تم استيراد وقراءة الكتاب كاملاً بنجاح (${newSource.pageCount} صفحة، ${realChunks.length} مقطع مفهرس في RAG)!`);
        setTimeout(() => setStatusMessage(''), 3500);
        return;
      }

      // B) Web Page & Educational Article Source Support
      const webText = data.content || data.text || result.cleanContent || result.snippet || '';
      if (data.type === 'web' || webText.trim().length >= 40) {
        setStatusMessage('فهرسة مقال ومحتوى الويب في دفترك...');
        const realChunks = chunkText(webText, sourceId, result.title, currentNotebookId, 750, 75);

        const newSource: Source = {
          id: sourceId,
          notebookId: currentNotebookId,
          title: data.title || result.title,
          uri: result.uri,
          type: 'text/html',
          size: data.size || webText.length,
          status: 'Ready',
          content: webText,
          wordCount: data.wordCount || webText.split(/\s+/).filter(Boolean).length,
          lineCount: data.lineCount || webText.split('\n').length,
          pageCount: 1,
          createdAt: Date.now(),
          updatedAt: Date.now(),
        };

        const indexingReport = generateInitialIndexingReport(
          data.title || result.title,
          webText,
          ['مقال ويب أكاديمي مفهرس'],
          1
        );
        newSource.indexingReport = indexingReport;
        setActiveIndexingReport(indexingReport);

        onAddSource(newSource, realChunks);
        setStatusMessage(`✓ تم استيراد وفهرسة محتوى المصدر بنجاح (${newSource.wordCount} كلمة، ${realChunks.length} مقطع في RAG)!`);
        setTimeout(() => setStatusMessage(''), 3500);
        return;
      }

      throw new Error('تعذر استخراج محتوى نصي مقروء من هذا المصدر. يرجى تجربة مصدر آخر أو رفعه يدوياً.');
    } catch (err: any) {
      console.warn('Import error:', err);
      setErrorMsg(err.message || 'تعذر استيراد المصدر. يرجى التأكد من الرابط أو المحاولة مجدداً');
    } finally {
      setIsLoading(false);
    }
  };

  // Batch import multiple selected search results sequentially with true parsing
  const handleBatchImportSearchResults = async () => {
    if (selectedSearchUris.length === 0) return;
    const toImport = searchResults.filter((r) => selectedSearchUris.includes(r.uri));
    setSelectedSearchUris([]);

    for (let i = 0; i < toImport.length; i++) {
      await handleImportSearchResult(toImport[i]);
    }
  };

  // Export search results as structured JSON (titles, links, summaries, and data blocks)
  const handleExportSearchResultsJson = async () => {
    if (searchResults.length === 0) return;
    try {
      const res = await fetch('/api/search/export', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: searchQuery,
          mode: searchMode,
          download: false,
        }),
      });

      let exportData: any;
      if (res.ok) {
        exportData = await res.json();
      } else {
        // Fallback to client-side structured JSON format
        exportData = {
          exportedAt: new Date().toISOString(),
          engine: 'Advanced Web Indexing & Analysis Engine (NotebookLM Style)',
          query: searchQuery,
          totalResults: searchResults.length,
          results: searchResults.map((r) => ({
            id: r.id,
            title: r.title,
            url: r.uri,
            domain: r.domain,
            category: r.category,
            summary: r.summary || r.snippet,
            executiveSummary: r.executiveSummary || r.snippet?.slice(0, 180),
            keyTopics: r.keyTopics || [],
            relevanceScore: r.relevanceScore,
            dataBlocks: r.dataBlocks || [],
          })),
        };
      }

      const jsonStr = JSON.stringify(exportData, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      const safeQ = (searchQuery || 'results').replace(/[^\w\u0600-\u06FF]/g, '_').slice(0, 30);
      a.download = `search-export-${safeQ}-${Date.now()}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Export error:', err);
    }
  };

  // Wikipedia Search Handler
  const handleWikipediaSearch = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!wikiSearchQuery.trim()) return;
    setWikiLoading(true);
    setErrorMsg('');
    try {
      const res = await fetch(`/api/wikipedia/search?query=${encodeURIComponent(wikiSearchQuery.trim())}&lang=${wikiLang}`);
      if (res.ok) {
        const data = await res.json();
        setWikiResults(data.results || []);
        if (!data.results || data.results.length === 0) {
          setErrorMsg('لم يتم العثور على مقالات ويكيبيديا تطابق استعلام البحث.');
        }
      }
    } catch (err: any) {
      console.warn('Wikipedia search error:', err);
      setErrorMsg('تعذر الاتصال بموسوعة ويكيبيديا حالياً.');
    } finally {
      setWikiLoading(false);
    }
  };

  // Import Wikipedia Article as fully parsed, chunked Source in Notebook
  const handleImportWikipediaArticle = async (item: { title: string; uri: string }) => {
    setWikiImportingTitle(item.title);
    setIsLoading(true);
    setStatusMessage(`جاري استيراد وتفكيك مقال «${item.title}» من ويكيبيديا...`);
    try {
      const res = await fetch(`/api/wikipedia/article?title=${encodeURIComponent(item.title)}&lang=${wikiLang}`);
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.content) {
          const sourceId = `wiki_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
          const fullTitle = `[موسوعة ويكيبيديا] ${data.title}`;
          const realChunks = chunkText(data.content, sourceId, fullTitle, currentNotebookId, 750, 75);
          const newSource: Source = {
            id: sourceId,
            notebookId: currentNotebookId,
            title: fullTitle,
            uri: data.uri,
            type: 'text/html',
            size: data.content.length,
            status: 'Ready',
            content: data.content,
            wordCount: data.wordCount,
            lineCount: data.content.split('\n').length,
            pageCount: data.pageCount || 1,
            pages: data.pages || [{ pageNumber: 1, text: data.content }],
            createdAt: Date.now(),
            updatedAt: Date.now(),
          };
          const report = generateInitialIndexingReport(
            fullTitle,
            data.content,
            ['موسوعة ويكيبيديا العلمية العالمية المعتمدة'],
            data.pageCount || 1
          );
          newSource.indexingReport = report;
          onAddSource(newSource, realChunks);
          setStatusMessage(`✓ تم إضافة مقال ويكيبيديا «${data.title}» إلى دفترك بنجاح!`);
          setTimeout(() => setStatusMessage(''), 3500);
        } else {
          throw new Error(data.error || 'تعذر استخراج محتوى المقال');
        }
      } else {
        throw new Error('فشل جلب المقال من ويكيبيديا');
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'فشل استيراد المقال');
    } finally {
      setWikiImportingTitle(null);
      setIsLoading(false);
    }
  };

  // Import Yemeni Curriculum Subject Unit into Notebook
  const handleImportCurriculumSubjectUnit = (subject: CurriculumSubject, unitIndex: number) => {
    const { source, chunks: newChunks } = createCurriculumSource(subject, unitIndex, currentNotebookId);
    const rep = generateInitialIndexingReport(
      source.title,
      source.content,
      subject.units[unitIndex]?.topics || ['المنهج اليمني المعتمد'],
      source.pageCount
    );
    source.indexingReport = rep;
    onAddSource(source, newChunks);
    setStatusMessage(`✓ تم استيراد «${source.title}» بالكامل إلى دفترك وهو جاهز للمذاكرة والاستجواب!`);
    setTimeout(() => setStatusMessage(''), 3500);
  };

  // Quick Article Preview Modal Handler - Previews directly in-app
  const handleOpenSearchPreview = async (item: any) => {
    // If the item is already added to sources, open full in-app preview directly
    const existing = sources.find((s) => s.uri === item.uri || s.title === item.title);
    if (existing) {
      setInAppPreviewSource(existing);
      return;
    }

    setPreviewingSearchItem(item);
    setPreviewItemContent(item.snippet || '');
    setPreviewItemLoading(true);

    try {
      const res = await fetch('/api/fetch-url', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: item.uri }),
      });
      if (res.ok) {
        const data = await res.json();
        const content = data.content || data.text || item.snippet || '';
        setPreviewItemContent(content);
        if (data.type === 'pdf' || data.dataBase64) {
          // Can create synthetic source for rich preview modal
          const pseudoSource: Source = {
            id: `preview-${Date.now()}`,
            notebookId: currentNotebookId,
            title: data.title || item.title,
            uri: item.uri,
            type: 'application/pdf',
            size: data.size || content.length,
            status: 'Ready',
            content,
            pageCount: data.pageCount || 1,
            pages: data.pages || [{ pageNumber: 1, text: content }],
            createdAt: Date.now(),
            updatedAt: Date.now(),
          };
          setInAppPreviewSource(pseudoSource);
          setPreviewingSearchItem(null);
        }
      }
    } catch (e) {
      console.warn('Failed to fetch full preview text:', e);
    } finally {
      setPreviewItemLoading(false);
    }
  };

  // Renaming Handler
  const startRenaming = (source: Source) => {
    setEditingSourceId(source.id);
    setEditingTitle(source.title);
  };

  const saveRenaming = (sourceId: string) => {
    if (editingTitle.trim() && onRenameSource) {
      onRenameSource(sourceId, editingTitle.trim());
      if (selectedPreviewSource?.id === sourceId) {
        setSelectedPreviewSource({ ...selectedPreviewSource, title: editingTitle.trim() });
      }
    }
    setEditingSourceId(null);
  };

  // Bulk Delete Handler
  const handleBulkDelete = () => {
    if (selectedSourceIds.length === 0) return;
    if (confirm(`هل أنت متأكد من حذف ${selectedSourceIds.length} مصادر محددة من هذا الدفتر؟`)) {
      if (onDeleteMultipleSources) {
        onDeleteMultipleSources(selectedSourceIds);
      } else {
        selectedSourceIds.forEach((id) => onDeleteSource(id));
      }
      if (selectedPreviewSource && selectedSourceIds.includes(selectedPreviewSource.id)) {
        setSelectedPreviewSource(null);
      }
    }
  };

  // Filtered sources for display
  const filteredSources = useMemo(() => {
    return sources.filter((s) => {
      const matchesText = !listFilterQuery.trim() || 
        s.title.toLowerCase().includes(listFilterQuery.toLowerCase()) ||
        s.content.toLowerCase().includes(listFilterQuery.toLowerCase());
      
      const isFav = favoriteSourceIds.includes(s.id) || !!s.favorite;
      const isPdf = s.type.includes('pdf') || (s.pages && s.pages.length > 1);
      const isImage = s.type.includes('image') || /\.(png|jpe?g|webp|bmp)$/i.test(s.title);
      const isAudio = s.type.includes('audio') || /\.(mp3|wav|m4a|ogg|aac|webm)$/i.test(s.title);
      const isHtml = s.type.includes('html') || s.title.endsWith('.html') || s.title.endsWith('.htm');
      const isWiki = s.type === 'wikipedia' || s.title.includes('ويكيبيديا') || s.uri?.includes('wikipedia');
      const isText = s.type === 'text/plain' || s.title.endsWith('.txt') || s.title.endsWith('.md');

      const matchesType = 
        typeFilter === 'all' ? true :
        typeFilter === 'favorite' ? isFav :
        typeFilter === 'pdf' ? isPdf :
        typeFilter === 'image' ? isImage :
        typeFilter === 'audio' ? isAudio :
        typeFilter === 'html' ? isHtml :
        typeFilter === 'wikipedia' ? isWiki :
        typeFilter === 'text' ? isText :
        true;

      return matchesText && matchesType;
    });
  }, [sources, listFilterQuery, typeFilter, favoriteSourceIds]);

  // Search inside currently previewed source
  const searchMatchesInSource = useMemo(() => {
    if (!selectedPreviewSource || !sourceSearchTerm.trim()) return [];
    const text = selectedPreviewSource.content;
    const term = sourceSearchTerm.toLowerCase();
    const indices: number[] = [];
    let pos = text.toLowerCase().indexOf(term);
    while (pos !== -1) {
      indices.push(pos);
      pos = text.toLowerCase().indexOf(term, pos + 1);
    }
    return indices;
  }, [selectedPreviewSource, sourceSearchTerm]);

  return (
    <div className="space-y-6">
      {/* Sources Management Header & Add Panel */}
      <div className="bg-white dark:bg-[#14201c] rounded-2xl border border-[#e2e8e5] dark:border-[#22352f] p-5 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#e2e8e5] dark:border-[#22352f] pb-4">
          <div>
            <h2 className="font-bold text-base text-[#17201e] dark:text-[#eef7f4] flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-[#0f766e] dark:text-[#2dd4bf]" />
              <span>نظام إدارة المصادر والمراجع التعليمية</span>
            </h2>
            <p className="text-xs text-[#596762] dark:text-[#9ab3ab] mt-0.5">
              أضف ملفات الكتب ومواقع الويب ليقوم المعلم الذكي بفهرستها واسترجاعها بدقة عبر RAG.
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs">
            <span className="font-bold text-[#596762] dark:text-[#9ab3ab]">
              إجمالي المصادر: <b className="text-[#0f766e] dark:text-[#2dd4bf]">{sources.length}</b>
            </span>
            <span>•</span>
            <span className="font-bold text-[#596762] dark:text-[#9ab3ab]">
              المقاطع المفهرسة: <b className="text-[#0f766e] dark:text-[#2dd4bf]">{chunks.length}</b>
            </span>
          </div>
        </div>

        {/* Ingestion Tabs */}
        {/* Clean Responsive Ingestion Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1 mt-3 -mx-1 px-1 touch-pan-x">
          <button
            onClick={() => setActiveTab('upload')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shrink-0 cursor-pointer ${
              activeTab === 'upload'
                ? 'bg-[#0f766e] text-white shadow-xs'
                : 'bg-[#f6f8f7] dark:bg-[#1a2723] text-[#596762] dark:text-[#9ab3ab] hover:text-[#0f766e]'
            }`}
          >
            <Upload className="w-3.5 h-3.5" />
            <span>رفع ملف (PDF / Word)</span>
          </button>

          <button
            onClick={() => setActiveTab('curriculum_bank')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shrink-0 cursor-pointer ${
              activeTab === 'curriculum_bank'
                ? 'bg-[#0f766e] text-white shadow-xs'
                : 'bg-[#f6f8f7] dark:bg-[#1a2723] text-[#596762] dark:text-[#9ab3ab] hover:text-[#0f766e]'
            }`}
          >
            <GraduationCap className="w-3.5 h-3.5 text-amber-500" />
            <span>المنهج اليمني وبنك المعارف</span>
            <span className="text-[9px] px-1 py-0.2 rounded-full bg-amber-500/20 text-amber-600 dark:text-amber-300 font-bold">
              معتمد
            </span>
          </button>

          <button
            onClick={() => setActiveTab('wikipedia')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shrink-0 cursor-pointer ${
              activeTab === 'wikipedia'
                ? 'bg-[#0f766e] text-white shadow-xs'
                : 'bg-[#f6f8f7] dark:bg-[#1a2723] text-[#596762] dark:text-[#9ab3ab] hover:text-[#0f766e]'
            }`}
          >
            <Globe className="w-3.5 h-3.5 text-teal-500" />
            <span>موسوعة ويكيبيديا العالمية</span>
          </button>

          <button
            onClick={() => setActiveTab('search')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shrink-0 cursor-pointer ${
              activeTab === 'search'
                ? 'bg-[#0f766e] text-white shadow-xs'
                : 'bg-[#f6f8f7] dark:bg-[#1a2723] text-[#596762] dark:text-[#9ab3ab] hover:text-[#0f766e]'
            }`}
          >
            <Search className="w-3.5 h-3.5" />
            <span>بحث الويب وتلجرام</span>
          </button>

          <button
            onClick={() => setActiveTab('url')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shrink-0 cursor-pointer ${
              activeTab === 'url'
                ? 'bg-[#0f766e] text-white shadow-xs'
                : 'bg-[#f6f8f7] dark:bg-[#1a2723] text-[#596762] dark:text-[#9ab3ab] hover:text-[#0f766e]'
            }`}
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span>رابط ويب مباشر</span>
          </button>

          <button
            type="button"
            onClick={() => setIsClipperModalOpen(true)}
            className="px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shrink-0 cursor-pointer bg-gradient-to-r from-teal-500/15 via-emerald-500/15 to-teal-500/15 hover:from-teal-500/25 hover:to-emerald-500/25 text-teal-800 dark:text-teal-300 border border-teal-500/30 shadow-2xs active:scale-95"
            title="أداة استيراد مقال ويب مع تقليم الإعلانات والشوائب وحفظه في المصادر"
          >
            <Scissors className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
            <span>تقليم واستيراد مقال ويب ✂️</span>
          </button>

          <button
            onClick={() => setActiveTab('paste')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shrink-0 cursor-pointer ${
              activeTab === 'paste'
                ? 'bg-[#0f766e] text-white shadow-xs'
                : 'bg-[#f6f8f7] dark:bg-[#1a2723] text-[#596762] dark:text-[#9ab3ab] hover:text-[#0f766e]'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>لصق نص</span>
          </button>

          <button
            onClick={() => setActiveTab('citations')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shrink-0 cursor-pointer ${
              activeTab === 'citations'
                ? 'bg-[#0f766e] text-white shadow-xs'
                : 'bg-[#f6f8f7] dark:bg-[#1a2723] text-[#596762] dark:text-[#9ab3ab] hover:text-[#0f766e]'
            }`}
          >
            <Share2 className="w-3.5 h-3.5 text-amber-500" />
            <span>مستكشف الاستشهادات (Citation Explorer)</span>
          </button>
        </div>

        {/* Dynamic Real-time Background Indexing Progress Bar (Web Worker) */}
        {indexingProgress && (
          <div className="mt-4 bg-gradient-to-r from-teal-500/10 via-emerald-500/10 to-teal-500/10 dark:from-teal-950/40 dark:via-emerald-950/40 dark:to-teal-950/40 border border-teal-500/30 dark:border-teal-400/30 rounded-2xl p-4 shadow-sm animate-in fade-in duration-200 space-y-2.5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-teal-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                  <Loader2 className="w-4 h-4 animate-spin" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-100">
                      {indexingProgress.status}
                    </h4>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-teal-600 text-white font-bold font-mono">
                      {indexingProgress.percent}%
                    </span>
                  </div>
                  <span className="text-[10px] text-teal-700 dark:text-teal-300 font-medium flex items-center gap-1 mt-0.5">
                    <Zap className="w-3 h-3 text-amber-500" />
                    <span>معالجة خلفية متعددة المسارات (Web Worker) - تضمن عدم توقف واجهة المستخدم</span>
                  </span>
                </div>
              </div>
              <div className="text-xs font-mono font-bold text-teal-800 dark:text-teal-200 bg-white/60 dark:bg-black/20 px-3 py-1 rounded-xl border border-teal-500/20">
                {indexingProgress.processed} / {indexingProgress.total} مقطع
              </div>
            </div>

            {/* Dynamic Animated Progress Bar */}
            <div className="w-full bg-slate-200 dark:bg-[#1a2924] h-2.5 rounded-full overflow-hidden p-0.5 relative">
              <div
                className="h-full bg-gradient-to-r from-teal-500 via-emerald-400 to-teal-400 rounded-full transition-all duration-300 relative shadow-xs"
                style={{ width: `${Math.max(4, indexingProgress.percent)}%` }}
              >
                <div className="absolute inset-0 bg-white/25 animate-pulse" />
              </div>
            </div>
          </div>
        )}

        {/* Ingestion Tab Contents */}
        <div className="mt-4">
          {activeTab === 'upload' && (
            <div
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-[#b8cbc5] dark:border-[#2b423b] hover:border-[#0f766e] dark:hover:border-[#2dd4bf] rounded-2xl p-6 sm:p-8 text-center cursor-pointer bg-[#f8fbfa] dark:bg-[#14201c]/60 transition-all hover:bg-white dark:hover:bg-[#14201c]"
            >
              <input
                ref={fileInputRef}
                id="fileUpload"
                type="file"
                multiple
                accept="application/pdf,.pdf,.doc,.docx,.txt,.html,audio/*,image/*"
                onChange={handleFileUpload}
                className="hidden"
              />
              <div className="flex flex-wrap items-center justify-center gap-2 mb-3">
                <span className="px-2.5 py-1 rounded-full bg-rose-100 dark:bg-rose-950/80 text-rose-800 dark:text-rose-300 text-[11px] font-bold flex items-center gap-1">
                  <BookOpen className="w-3 h-3" />
                  كتب وملازم PDF (رقمية وممسوحة OCR)
                </span>
                <span className="px-2.5 py-1 rounded-full bg-cyan-100 dark:bg-cyan-950/80 text-cyan-800 dark:text-cyan-300 text-[11px] font-bold flex items-center gap-1">
                  <Eye className="w-3 h-3" />
                  صور وملازم OCR (PNG, JPG, WEBP)
                </span>
                <span className="px-2.5 py-1 rounded-full bg-amber-100 dark:bg-amber-950/80 text-amber-800 dark:text-amber-300 text-[11px] font-bold flex items-center gap-1">
                  <FileCode className="w-3 h-3" />
                  صفحات HTML
                </span>
                <span className="px-2.5 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-[11px] font-bold flex items-center gap-1">
                  <FileText className="w-3 h-3" />
                  نصوص TXT ومستندات Word
                </span>
                <span className="px-2.5 py-1 rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300 text-[11px] font-bold flex items-center gap-1">
                  <Volume2 className="w-3 h-3" />
                  تسجيلات صوتية (تفريغ Whisper)
                </span>
              </div>
              <div className="w-12 h-12 rounded-2xl bg-[#e6f4f1] dark:bg-[#132e29] text-[#0f766e] dark:text-[#2dd4bf] flex items-center justify-center mx-auto mb-3 shadow-sm">
                <Upload className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-sm text-[#17201e] dark:text-[#eef7f4] mb-1.5">
                اضغط لاختيار أو إسقاط ملفات المصادر (PDF، صور OCR، نصوص TXT، ملفات HTML، تسجيلات صوتية)
              </h3>
              <p className="text-xs text-[#596762] dark:text-[#9ab3ab] max-w-xl mx-auto leading-relaxed">
                ⚡ نظام إدارة المصادر المتقدم: يتم استخراج المحتوى تلقائياً وفهرسته دلالياً وتقطيعه سياقياً (RAG Chunking) ليتمكن المعلم الذكي والبحث من استرجاع المعلومات بدقة استشهاد 100% بدون أي تشتت.
              </p>
            </div>
          )}

          {/* Yemeni National Curriculum & Universal Knowledge Banks Tab */}
          {activeTab === 'curriculum_bank' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-500/10 via-teal-500/10 to-amber-500/10 dark:from-amber-950/40 dark:via-teal-950/40 dark:to-amber-950/40 border border-amber-300/60 dark:border-amber-800/60 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-10 h-10 rounded-xl bg-amber-500 text-white flex items-center justify-center shrink-0 shadow-sm">
                    <GraduationCap className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-extrabold text-sm text-[#17201e] dark:text-[#eef7f4] flex items-center gap-1.5">
                      <span>المنهج اليمني كاملاً وبنوك المعارف الأكاديمية العالمية</span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 font-bold">
                        طبعة وزارية معتمدة
                      </span>
                    </h3>
                    <p className="text-xs text-[#596762] dark:text-[#9ab3ab] mt-0.5">
                      اختر أي مادة أو وحدة دراسية لإضافتها بضغطة زر واحدة إلى دفترك ومحاورة الذكاء الاصطناعي بدقة استشهاد 100%.
                    </p>
                  </div>
                </div>

                {/* Track Selector */}
                <div className="flex items-center gap-1.5 flex-wrap">
                  {[
                    { id: 'all', label: 'الكل' },
                    { id: 'علمي', label: '🔬 علمي (3 ثانوي)' },
                    { id: 'أدبي', label: '📜 أدبي (3 ثانوي)' },
                    { id: 'معارف عامة', label: '🌐 بنوك المعارف العالمية' },
                  ].map((track) => (
                    <button
                      key={track.id}
                      type="button"
                      onClick={() => setCurriculumTrackFilter(track.id as any)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                        curriculumTrackFilter === track.id
                          ? 'bg-[#0f766e] text-white shadow-xs'
                          : 'bg-white dark:bg-[#1a2723] text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
                      }`}
                    >
                      {track.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Curriculum Cards Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {YEMENI_CURRICULUM_AND_KNOWLEDGE_BANKS.filter(
                  (subj) => curriculumTrackFilter === 'all' || subj.track === curriculumTrackFilter
                ).map((subj) => (
                  <div
                    key={subj.id}
                    className="p-4 rounded-2xl bg-white dark:bg-[#162420] border border-gray-200 dark:border-gray-800/80 shadow-xs flex flex-col justify-between gap-3 hover:border-teal-500 transition-colors"
                  >
                    <div className="space-y-2">
                      <div className="flex items-center justify-between gap-2">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-teal-50 text-teal-700 dark:bg-teal-950/60 dark:text-teal-300">
                          {subj.stage} • {subj.country}
                        </span>
                        <span className="text-[10px] text-gray-400 font-bold">
                          {subj.units.length} وحدات دراسية
                        </span>
                      </div>

                      <h4 className="font-extrabold text-sm text-[#17201e] dark:text-[#eef7f4] leading-snug">
                        {subj.name}
                      </h4>
                      <p className="text-xs text-gray-500 dark:text-gray-400 line-clamp-2 leading-relaxed">
                        {subj.description}
                      </p>

                      {/* Units Breakdown */}
                      <div className="space-y-2 pt-2 border-t border-gray-100 dark:border-gray-800">
                        {subj.units.map((u, uIdx) => {
                          const unitTitle = `[${subj.country}] ${subj.name} - ${u.title}`;
                          const isAlreadyInNotebook = sources.some((s) => s.title === unitTitle);

                          return (
                            <div
                              key={u.unitNumber}
                              className="p-2.5 rounded-xl bg-gray-50/70 dark:bg-[#1a2b25]/70 border border-gray-200/60 dark:border-gray-800/60 flex items-center justify-between gap-2"
                            >
                              <div className="min-w-0 flex-1">
                                <h5 className="font-bold text-xs text-[#0f766e] dark:text-[#2dd4bf] truncate">
                                  {u.title}
                                </h5>
                                <div className="flex items-center gap-2 text-[10px] text-gray-500 dark:text-gray-400 mt-0.5">
                                  <span>{u.topics.length} موضوعات</span>
                                  {u.lawsAndFormulas && u.lawsAndFormulas.length > 0 && (
                                    <span>• {u.lawsAndFormulas.length} قوانين معتمدة</span>
                                  )}
                                  {u.sampleQuestions && u.sampleQuestions.length > 0 && (
                                    <span>• {u.sampleQuestions.length} أسئلة وزارية</span>
                                  )}
                                </div>
                              </div>

                              {isAlreadyInNotebook ? (
                                <span className="px-2.5 py-1 rounded-lg bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300 text-[11px] font-bold shrink-0 flex items-center gap-1">
                                  <Check className="w-3 h-3 text-emerald-600" />
                                  <span>مضاف</span>
                                </span>
                              ) : (
                                <button
                                  type="button"
                                  onClick={() => handleImportCurriculumSubjectUnit(subj, uIdx)}
                                  className="px-2.5 py-1 rounded-lg bg-[#0f766e] hover:bg-[#115e59] text-white text-[11px] font-bold shrink-0 flex items-center gap-1 cursor-pointer transition-colors shadow-2xs"
                                >
                                  <Plus className="w-3 h-3" />
                                  <span>إضافة للدفتر</span>
                                </button>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Multilingual Wikipedia Knowledge Integration Tab */}
          {activeTab === 'wikipedia' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-teal-50/70 dark:bg-[#15231f] border border-teal-200/70 dark:border-teal-900/50 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-10 h-10 rounded-xl bg-teal-600 text-white flex items-center justify-center shrink-0 shadow-sm">
                    <Globe className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-extrabold text-sm text-[#17201e] dark:text-[#eef7f4] flex items-center gap-1.5">
                      <span>موسوعة ويكيبيديا العلمية العالمية المفتوحة</span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-teal-100 text-teal-800 dark:bg-teal-900 dark:text-teal-200 font-bold">
                        مرجع شامل مباشر
                      </span>
                    </h3>
                    <p className="text-xs text-[#596762] dark:text-[#9ab3ab] mt-0.5">
                      ابحث في ويكيبيديا العربية أو العالمية، واستورد المقالات الكاملة المفككة كفصول دراسية إلى دفترك بضغطة زر.
                    </p>
                  </div>
                </div>

                {/* Language Switcher */}
                <div className="flex items-center gap-1 p-1 bg-white dark:bg-[#1a2723] rounded-xl border border-teal-200/60 dark:border-teal-900/60">
                  <button
                    type="button"
                    onClick={() => setWikiLang('ar')}
                    className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      wikiLang === 'ar'
                        ? 'bg-[#0f766e] text-white shadow-xs'
                        : 'text-gray-600 dark:text-gray-300 hover:text-gray-900'
                    }`}
                  >
                    العربية (ar)
                  </button>
                  <button
                    type="button"
                    onClick={() => setWikiLang('en')}
                    className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      wikiLang === 'en'
                        ? 'bg-[#0f766e] text-white shadow-xs'
                        : 'text-gray-600 dark:text-gray-300 hover:text-gray-900'
                    }`}
                  >
                    English (en)
                  </button>
                </div>
              </div>

              {/* Wikipedia Search Bar */}
              <form onSubmit={handleWikipediaSearch} className="flex gap-2">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
                  <input
                    type="text"
                    required
                    placeholder={
                      wikiLang === 'ar'
                        ? 'ابحث عن أي مفهوم علمي، نظرية، قانون، أو موضوع في ويكيبيديا العربية...'
                        : 'Search scientific topics, theorems, and encyclopedic concepts on Wikipedia...'
                    }
                    value={wikiSearchQuery}
                    onChange={(e) => setWikiSearchQuery(e.target.value)}
                    className="w-full pr-10 pl-3 py-2.5 border border-[#e2e8e5] dark:border-[#22352f] rounded-xl bg-white dark:bg-[#1a2723] text-sm text-[#17201e] dark:text-[#eef7f4] focus:outline-none focus:border-[#0f766e]"
                  />
                </div>
                <button
                  type="submit"
                  disabled={wikiLoading || !wikiSearchQuery.trim()}
                  className="px-5 py-2.5 bg-[#0f766e] text-white rounded-xl text-xs font-bold hover:bg-[#115e59] disabled:opacity-50 flex items-center gap-2 whitespace-nowrap shadow-xs cursor-pointer"
                >
                  {wikiLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
                  <span>بحث في ويكيبيديا</span>
                </button>
              </form>

              {/* Suggested Wikipedia Topics */}
              <div className="flex flex-wrap items-center gap-1.5 text-xs">
                <span className="text-gray-500 dark:text-gray-400 font-medium">اقتراحات موسوعية:</span>
                {[
                  'النظرية النسبية',
                  'قوانين نيوتن في الحركة',
                  'الحمض النووي ريبوزي منقوص الأكسجين',
                  'الذكاء الاصطناعي',
                  'تاريخ اليمن القديم',
                  'الدوائر الكهربائية',
                  'ابن الهيثم',
                  'أبو بكر الرازي',
                ].map((topic) => (
                  <button
                    key={topic}
                    type="button"
                    onClick={() => {
                      setWikiSearchQuery(topic);
                      setTimeout(() => {
                        fetch(`/api/wikipedia/search?query=${encodeURIComponent(topic)}&lang=${wikiLang}`)
                          .then((r) => r.json())
                          .then((d) => setWikiResults(d.results || []));
                      }, 50);
                    }}
                    className="px-2.5 py-1 rounded-lg bg-gray-100 dark:bg-gray-800 hover:bg-teal-50 hover:text-teal-700 dark:hover:bg-teal-950/60 dark:hover:text-teal-300 text-gray-700 dark:text-gray-300 text-[11px] cursor-pointer transition-colors"
                  >
                    {topic}
                  </button>
                ))}
              </div>

              {/* Wikipedia Search Results List */}
              {wikiResults.length > 0 && (
                <div className="space-y-3 pt-2">
                  <div className="flex items-center justify-between text-xs text-gray-500 font-bold pb-1 border-b border-gray-100 dark:border-gray-800">
                    <span>نتائج موسوعة ويكيبيديا ({wikiResults.length}):</span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {wikiResults.map((item) => {
                      const isAdded = sources.some(
                        (s) => s.title === `[موسوعة ويكيبيديا] ${item.title}` || s.uri === item.uri
                      );
                      const isImporting = wikiImportingTitle === item.title;

                      return (
                        <div
                          key={item.pageid || item.title}
                          className="p-3.5 bg-white dark:bg-[#162420] border border-gray-200 dark:border-gray-800 rounded-2xl flex flex-col justify-between gap-3 shadow-xs hover:border-[#0f766e] transition-colors"
                        >
                          <div className="space-y-1.5">
                            <div className="flex items-center justify-between gap-2">
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-teal-50 text-teal-700 dark:bg-teal-950/60 dark:text-teal-300">
                                📗 مقال موسوعي
                              </span>
                              <a
                                href={item.uri}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-gray-400 hover:text-teal-600 flex items-center gap-0.5 text-[11px]"
                                title="عرض في ويكيبيديا"
                              >
                                <ExternalLink className="w-3 h-3" />
                              </a>
                            </div>

                            <h4 className="font-extrabold text-xs text-[#17201e] dark:text-[#eef7f4]">
                              {item.title}
                            </h4>

                            <p className="text-xs text-gray-600 dark:text-gray-400 line-clamp-3 leading-relaxed">
                              {item.snippet}
                            </p>
                          </div>

                          <div className="pt-2 border-t border-gray-100 dark:border-gray-800 flex items-center justify-between gap-2 text-[11px]">
                            <span className="text-gray-400 font-mono text-[10px]">
                              {item.wordcount ? `${item.wordcount} كلمة` : item.domain}
                            </span>

                            {isImporting ? (
                              <span className="px-3 py-1 rounded-xl bg-teal-50 text-[#0f766e] font-bold flex items-center gap-1.5">
                                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                                <span>جاري الاستيراد...</span>
                              </span>
                            ) : isAdded ? (
                              <span className="px-3 py-1 rounded-xl bg-emerald-50 text-emerald-700 dark:bg-emerald-950/70 dark:text-emerald-300 font-bold flex items-center gap-1">
                                <Check className="w-3.5 h-3.5" />
                                <span>✓ مضاف لدفترك</span>
                              </span>
                            ) : (
                              <button
                                type="button"
                                onClick={() => handleImportWikipediaArticle(item)}
                                className="px-3 py-1 bg-[#0f766e] text-white rounded-xl font-bold hover:bg-[#115e59] flex items-center gap-1 cursor-pointer transition-colors shadow-2xs"
                              >
                                <Plus className="w-3.5 h-3.5" />
                                <span>إضافة المقال للدفتر</span>
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          )}

          {activeTab === 'url' && (
            <form onSubmit={handleFetchUrl} className="space-y-3">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div className="md:col-span-2">
                  <label className="block text-xs font-bold text-[#596762] dark:text-[#9ab3ab] mb-1">
                    رابط الصفحة أو المستند *
                  </label>
                  <input
                    type="url"
                    required
                    placeholder="https://example.com/article أو رابط كتاب"
                    value={urlInput}
                    onChange={(e) => setUrlInput(e.target.value)}
                    className="w-full px-3 py-2 border border-[#e2e8e5] dark:border-[#22352f] rounded-xl bg-[#f6f8f7] dark:bg-[#1a2723] text-sm text-[#17201e] dark:text-[#eef7f4] focus:outline-none focus:border-[#0f766e]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-[#596762] dark:text-[#9ab3ab] mb-1">
                    عنوان مخصص للمصدر (اختياري)
                  </label>
                  <input
                    type="text"
                    placeholder="مثال: مقال قوانين الحركة"
                    value={urlTitle}
                    onChange={(e) => setUrlTitle(e.target.value)}
                    className="w-full px-3 py-2 border border-[#e2e8e5] dark:border-[#22352f] rounded-xl bg-[#f6f8f7] dark:bg-[#1a2723] text-sm text-[#17201e] dark:text-[#eef7f4] focus:outline-none focus:border-[#0f766e]"
                  />
                </div>
              </div>
              <button
                type="submit"
                disabled={isLoading}
                className="px-5 py-2 bg-[#0f766e] text-white rounded-xl text-xs font-bold hover:bg-[#115e59] flex items-center gap-2"
              >
                {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Globe className="w-4 h-4" />}
                <span>جلب وفهرسة الرابط</span>
              </button>
            </form>
          )}

          {activeTab === 'search' && (
            <div className="space-y-4">
              {/* Search Mode Selector (Requirement 4: مناهج وكتب PDF vs ويب وموسوعات) */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 p-3 rounded-2xl bg-teal-50/70 dark:bg-[#15231f] border border-teal-200/70 dark:border-teal-900/50">
                <div className="flex items-center gap-1.5 p-1 bg-white dark:bg-[#1a2723] rounded-xl shadow-xs border border-teal-100 dark:border-teal-900/60 w-fit">
                  <button
                    type="button"
                    onClick={() => {
                      setSearchMode('curriculum');
                      if (searchQuery.trim()) handleWebSearch(undefined, undefined, 'curriculum');
                    }}
                    className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      searchMode === 'curriculum'
                        ? 'bg-[#0f766e] text-white shadow-xs'
                        : 'text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white'
                    }`}
                  >
                    <BookOpen className="w-3.5 h-3.5" />
                    <span>مناهج وكتب PDF</span>
                    <span className={`text-[10px] px-1.5 py-0.2 rounded font-normal ${
                      searchMode === 'curriculum' ? 'bg-white/20 text-white' : 'bg-gray-100 dark:bg-gray-800 text-gray-500'
                    }`}>
                      حصري
                    </span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setSearchMode('general');
                      if (searchQuery.trim()) handleWebSearch(undefined, undefined, 'general');
                    }}
                    className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      searchMode === 'general'
                        ? 'bg-[#0f766e] text-white shadow-xs'
                        : 'text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white'
                    }`}
                  >
                    <Globe className="w-3.5 h-3.5" />
                    <span>ويب وموسوعات</span>
                  </button>
                </div>

                <div className="text-[11px] text-teal-800 dark:text-teal-300 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400 shrink-0" />
                  <span>
                    {searchMode === 'curriculum'
                      ? 'بحث منهجي مقيد حصرياً بملفات الكتب والمذكرات (filetype:pdf) بتطابق دلالي صارم (≥ 70%).'
                      : 'بحث معرفي عام في الموسوعات الرقمية والأبحاث والمقالات العلمية الموثقة.'}
                  </span>
                </div>
              </div>

              {/* Search Form */}
              <form onSubmit={(e) => handleWebSearch(e)} className="space-y-3">
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <Search className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
                    <input
                      type="text"
                      required
                      placeholder={
                        searchMode === 'curriculum'
                          ? 'ابحث عن اسم المنهج، الكتاب، أو الملزمة (بحث PDF حصري بالمذكرات والمناهج)...'
                          : 'ابحث في الموسوعات الرقمية والأبحاث والمواقع المعرفية...'
                      }
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full pr-10 pl-9 py-2.5 border border-[#e2e8e5] dark:border-[#22352f] rounded-xl bg-[#f6f8f7] dark:bg-[#1a2723] text-sm text-[#17201e] dark:text-[#eef7f4] focus:outline-none focus:border-[#0f766e]"
                    />
                    {searchQuery && (
                      <button
                        type="button"
                        onClick={() => setSearchQuery('')}
                        className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 p-1"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                  <button
                    type="submit"
                    disabled={isLoading || !searchQuery.trim()}
                    className="px-5 py-2.5 bg-[#0f766e] text-white rounded-xl text-xs font-bold hover:bg-[#115e59] disabled:opacity-50 flex items-center gap-2 whitespace-nowrap shadow-sm shadow-[#0f766e]/20"
                  >
                    {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                    <span>{searchMode === 'curriculum' ? 'بحث مناهج وكتب PDF' : 'استكشاف المصادر المعرفية'}</span>
                  </button>
                </div>

                {/* Suggested Topics Chips */}
                <div className="flex flex-wrap items-center gap-1.5 text-xs">
                  <span className="text-gray-500 dark:text-gray-400 font-medium">
                    {searchMode === 'curriculum' ? 'اقتراحات مناهج وكتب PDF:' : 'اقتراحات معرفية:'}
                  </span>
                  {(searchMode === 'curriculum'
                    ? [
                        'كتاب الرياضيات الصف الثالث الثانوي المنهج السعودي',
                        'ملزمة كيمياء أول ثانوي الفصل الثاني',
                        'ملخص أحياء توجيهي الأردن',
                        'كتاب الفيزياء الصف الأول الثانوي',
                        'كتاب العلوم الصف السادس المنهج المصري',
                        'ملزمة قواعد اللغة العربية الصف السادس الإعدادي',
                      ]
                    : [
                        'الذكاء الاصطناعي وتطبيقاته المعاصرة',
                        'تاريخ الحضارة الإسلامية وتطور العلوم',
                        'مبادئ علم الوراثة والهندسة الجينية',
                        'فلسفة العلم ونظرية المعرفة',
                        'أصول النحو العربي وتطوره عبر العصور',
                      ]
                  ).map((topic) => (
                    <button
                      key={topic}
                      type="button"
                      onClick={() => handleWebSearch(undefined, topic)}
                      className="px-2.5 py-1 rounded-lg bg-gray-100 dark:bg-gray-800/80 hover:bg-teal-50 hover:text-teal-700 dark:hover:bg-teal-950/50 dark:hover:text-teal-300 text-gray-700 dark:text-gray-300 text-[11px] transition-colors cursor-pointer"
                    >
                      {topic}
                    </button>
                  ))}
                </div>
              </form>

              {/* Synthesized Overview (NotebookLM Style) */}
              {searchAnswer && (
                <div className="p-4 bg-[#f8fbfa] dark:bg-[#1a2723] border border-teal-200/60 dark:border-teal-900/60 rounded-2xl text-xs text-[#17201e] dark:text-[#eef7f4] leading-relaxed whitespace-pre-wrap shadow-sm">
                  <div className="font-bold text-[#0f766e] dark:text-[#2dd4bf] mb-2 flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <Sparkles className="w-4 h-4" />
                      <span className="text-sm">النظرة المعرفية والتوليف التمهيدي (NotebookLM Overview)</span>
                    </div>
                    <span className="text-[10px] px-2 py-0.5 rounded-md bg-teal-100 dark:bg-teal-900 text-teal-800 dark:text-teal-200">
                      قواعد المناهج والمعرفة الموثقة
                    </span>
                  </div>
                  <EducationalContent content={searchAnswer} />
                </div>
              )}

              {/* Search Results & Categories Filter */}
              {searchResults.length > 0 && (
                <div className="space-y-3 pt-2">
                  {/* Category Filter and Batch Action Bar */}
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-gray-100 dark:border-gray-800 pb-2">
                    <div className="flex flex-wrap items-center gap-1.5">
                      {[
                        { id: 'all', label: 'جميع المصادر', count: searchResults.length },
                        {
                          id: 'curriculum',
                          label: '📚 كتب ومناهج دراسية',
                          count: searchResults.filter((r) => r.category === 'curriculum').length,
                        },
                        {
                          id: 'notes',
                          label: '📝 ملازم ومذكرات',
                          count: searchResults.filter((r) => r.category === 'notes').length,
                        },
                        {
                          id: 'solutions',
                          label: '💡 حلول وبنوك أسئلة',
                          count: searchResults.filter((r) => r.category === 'solutions').length,
                        },
                        {
                          id: 'book',
                          label: '📖 كتب رقمية',
                          count: searchResults.filter((r) => r.category === 'book').length,
                        },
                        {
                          id: 'wikipedia',
                          label: 'الموسوعات (Wikipedia)',
                          count: searchResults.filter((r) => r.category === 'wikipedia' || r.domain?.includes('wikipedia')).length,
                        },
                        {
                          id: 'academic',
                          label: 'أبحاث ودوريات',
                          count: searchResults.filter((r) => r.category === 'academic' || r.category === 'journal' || r.domain?.includes('arxiv') || r.domain?.includes('doi.org')).length,
                        },
                        {
                          id: 'web',
                          label: 'مواقع الويب',
                          count: searchResults.filter((r) => r.category === 'web' || (!r.category && !r.domain?.includes('wikipedia'))).length,
                        },
                      ]
                        .filter((tab) => tab.count > 0 || tab.id === 'all')
                        .map((tab) => (
                          <button
                            key={tab.id}
                            type="button"
                            onClick={() => setSearchCategoryFilter(tab.id as any)}
                            className={`px-3 py-1 rounded-xl text-xs font-bold transition-colors ${
                              searchCategoryFilter === tab.id
                                ? 'bg-[#0f766e] text-white'
                                : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
                            }`}
                          >
                            {tab.label} ({tab.count})
                          </button>
                        ))}
                    </div>

                    {/* Multi-select controls */}
                    <div className="flex items-center gap-2 text-xs">
                      <button
                        type="button"
                        onClick={() => {
                          const filtered = searchResults.filter((r) => {
                            if (searchCategoryFilter === 'all') return true;
                            if (searchCategoryFilter === 'curriculum') return r.category === 'curriculum';
                            if (searchCategoryFilter === 'notes') return r.category === 'notes';
                            if (searchCategoryFilter === 'solutions') return r.category === 'solutions';
                            if (searchCategoryFilter === 'book') return r.category === 'book';
                            if (searchCategoryFilter === 'wikipedia') return r.category === 'wikipedia' || r.domain?.includes('wikipedia');
                            if (searchCategoryFilter === 'academic') return r.category === 'academic' || r.category === 'journal' || r.domain?.includes('arxiv') || r.domain?.includes('doi.org');
                            return r.category === 'web';
                          });
                          if (selectedSearchUris.length === filtered.length) {
                            setSelectedSearchUris([]);
                          } else {
                            setSelectedSearchUris(filtered.map((r) => r.uri));
                          }
                        }}
                        className="text-[#0f766e] dark:text-[#2dd4bf] hover:underline font-medium"
                      >
                        {selectedSearchUris.length > 0 ? 'إلغاء التحديد' : 'تحديد الكل للدفتر'}
                      </button>

                      {selectedSearchUris.length > 0 && (
                        <button
                          type="button"
                          onClick={handleBatchImportSearchResults}
                          disabled={isLoading}
                          className="px-3 py-1.5 bg-[#0f766e] text-white rounded-xl text-xs font-bold hover:bg-[#115e59] flex items-center gap-1.5 shadow-sm shadow-[#0f766e]/20"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          <span>إضافة المحدد ({selectedSearchUris.length}) إلى الدفتر</span>
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={handleExportSearchResultsJson}
                        className="px-2.5 py-1 bg-gray-100 dark:bg-gray-800 hover:bg-emerald-50 hover:text-emerald-700 dark:hover:bg-emerald-950/60 dark:hover:text-emerald-300 text-gray-700 dark:text-gray-300 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors border border-gray-200 dark:border-gray-700 cursor-pointer shadow-2xs"
                        title="تصدير النتائج بصيغة JSON منظمة تشمل العناوين والروابط وملخصات المحتوى والكتل المعرفية"
                      >
                        <Download className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                        <span>تصدير النتائج كـ JSON</span>
                      </button>
                    </div>
                  </div>

                  {/* Sources Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {searchResults
                      .filter((res) => {
                        if (searchCategoryFilter === 'all') return true;
                        if (searchCategoryFilter === 'curriculum') return res.category === 'curriculum';
                        if (searchCategoryFilter === 'notes') return res.category === 'notes';
                        if (searchCategoryFilter === 'solutions') return res.category === 'solutions';
                        if (searchCategoryFilter === 'book') return res.category === 'book';
                        if (searchCategoryFilter === 'wikipedia') return res.category === 'wikipedia' || res.domain?.includes('wikipedia');
                        if (searchCategoryFilter === 'academic') return res.category === 'academic' || res.category === 'journal' || res.domain?.includes('arxiv') || res.domain?.includes('doi.org');
                        return res.category === 'web';
                      })
                      .map((res, i) => {
                        const isAdded = sources.some(
                          (s) =>
                            (s.id && res.id && s.id === res.id) ||
                            (s.uri && res.uri && (s.uri === res.uri || s.uri.replace(/\/+$/, '') === res.uri.replace(/\/+$/, ''))) ||
                            (s.title && res.title && s.title.trim().toLowerCase() === res.title.trim().toLowerCase())
                        );
                        const isSelected = selectedSearchUris.includes(res.uri);

                        return (
                          <SourceCard
                            key={res.id || res.uri || i}
                            item={res}
                            currentNotebookId={currentNotebookId}
                            isAlreadyAdded={isAdded}
                            isSelected={isSelected}
                            onToggleSelect={(uri) => {
                              if (isSelected) {
                                setSelectedSearchUris(selectedSearchUris.filter((u) => u !== uri));
                              } else {
                                setSelectedSearchUris([...selectedSearchUris, uri]);
                              }
                            }}
                            onPreview={handleOpenSearchPreview}
                            onAddSource={onAddSource}
                            onUpdateSource={onUpdateSource}
                            onTriggerUpload={() => {
                              setActiveTab('upload');
                              setErrorMsg('');
                              setTimeout(() => fileInputRef.current?.click(), 100);
                            }}
                          />
                        );
                      })}
                  </div>
                </div>
              )}
            </div>
          )}

          {activeTab === 'paste' && (
            <form onSubmit={handlePasteSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-[#596762] dark:text-[#9ab3ab] mb-1">
                  عنوان النص
                </label>
                <input
                  type="text"
                  placeholder="مثال: ملخص الفصل الأول"
                  value={pasteTitle}
                  onChange={(e) => setPasteTitle(e.target.value)}
                  className="w-full px-3 py-2 border border-[#e2e8e5] dark:border-[#22352f] rounded-xl bg-[#f6f8f7] dark:bg-[#1a2723] text-sm text-[#17201e] dark:text-[#eef7f4] focus:outline-none focus:border-[#0f766e]"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-[#596762] dark:text-[#9ab3ab] mb-1">
                  محتوى النص *
                </label>
                <textarea
                  rows={5}
                  required
                  placeholder="الصق أي مقال أو ملخص دراسي هنا ليتم تقسيمه وفهرسته..."
                  value={pasteContent}
                  onChange={(e) => setPasteContent(e.target.value)}
                  className="w-full px-3 py-2 border border-[#e2e8e5] dark:border-[#22352f] rounded-xl bg-[#f6f8f7] dark:bg-[#1a2723] text-sm text-[#17201e] dark:text-[#eef7f4] focus:outline-none focus:border-[#0f766e] resize-vertical"
                />
              </div>
              <button
                type="submit"
                className="px-5 py-2 bg-[#0f766e] text-white rounded-xl text-xs font-bold hover:bg-[#115e59]"
              >
                إضافة وفهرسة للنظام
              </button>
            </form>
          )}

          {activeTab === 'citations' && (
            <div className="pt-2">
              <CitationExplorer
                sources={sources}
                chunks={chunks}
                onAskAboutChunk={(text, page) => {
                  if (onAskAboutQuote) onAskAboutQuote(text, page);
                }}
                onPreviewSource={(src) => {
                  setSelectedPreviewSource(src);
                }}
                onExportToNote={onExportToNote}
              />
            </div>
          )}
        </div>

        {/* Loading / Error alerts */}
        {isLoading && statusMessage && (
          <div className="mt-3 p-3 bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-800 rounded-xl text-xs text-teal-800 dark:text-teal-200 flex items-center gap-2">
            <Loader2 className="w-4 h-4 animate-spin text-teal-600" />
            <span>{statusMessage}</span>
          </div>
        )}

        {errorMsg && (
          <div className="mt-3 p-3 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800 rounded-xl text-xs text-red-700 dark:text-red-300 space-y-2">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-500 shrink-0" />
              <span>{errorMsg}</span>
            </div>
            {(errorMsg.includes("رفع") || errorMsg.includes("جهازك") || errorMsg.includes("هاتفك")) && (
              <button
                type="button"
                onClick={() => {
                  setActiveTab('upload');
                  setErrorMsg('');
                  setTimeout(() => fileInputRef.current?.click(), 100);
                }}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#0f766e] hover:bg-[#115e59] text-white font-bold text-xs transition-colors shadow-sm cursor-pointer"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>📁 التبديل لرفع ملف الكتاب من هاتفك الآن</span>
              </button>
            )}
          </div>
        )}

        {/* Initial Indexing Output (Structured Report) */}
        {activeIndexingReport && (
          <div className="mt-4 p-5 bg-gradient-to-br from-emerald-50/90 via-teal-50/70 to-white dark:from-[#132e29]/80 dark:via-[#1a2723] dark:to-[#14201c] border-2 border-emerald-300 dark:border-emerald-700/80 rounded-2xl shadow-md text-xs space-y-3 relative animate-fadeIn">
            <div className="flex items-center justify-between border-b border-emerald-200/80 dark:border-emerald-800/60 pb-2.5">
              <div className="flex items-center gap-2">
                <span className="p-1.5 rounded-lg bg-[#0f766e] text-white shadow-xs">
                  <Sparkles className="w-4 h-4" />
                </span>
                <span className="font-extrabold text-sm text-[#0f766e] dark:text-[#2dd4bf]">
                  تقرير الفهرسة الأولي (Initial Indexing Output)
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-1 rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300 font-bold text-[11px] flex items-center gap-1.5 border border-emerald-300 dark:border-emerald-700">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  حالة الفهرسة: {activeIndexingReport.indexingStatus}
                </span>
                <button
                  type="button"
                  onClick={() => setActiveIndexingReport(null)}
                  className="p-1 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 rounded-lg cursor-pointer"
                  title="إغلاق التقرير"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-1">
              <div className="space-y-2.5">
                <div>
                  <span className="font-bold text-[#596762] dark:text-[#9ab3ab] block text-[11px] mb-0.5">
                    العنوان الرئيسي:
                  </span>
                  <h4 className="font-extrabold text-sm text-[#17201e] dark:text-[#eef7f4]">
                    {activeIndexingReport.title}
                  </h4>
                </div>
                <div>
                  <span className="font-bold text-[#596762] dark:text-[#9ab3ab] block text-[11px] mb-1">
                    الملخص التنفيذي:
                  </span>
                  <p className="text-xs text-[#17201e] dark:text-[#eef7f4] leading-relaxed bg-white/80 dark:bg-[#14201c]/80 p-3 rounded-xl border border-emerald-100 dark:border-emerald-900/40 shadow-2xs">
                    {activeIndexingReport.executiveSummary}
                  </p>
                </div>
              </div>

              <div>
                <span className="font-bold text-[#596762] dark:text-[#9ab3ab] block text-[11px] mb-1.5">
                  خريطة المفاهيم (Key Topics):
                </span>
                <ul className="space-y-1.5 bg-white/80 dark:bg-[#14201c]/80 p-3 rounded-xl border border-emerald-100 dark:border-emerald-900/40 shadow-2xs">
                  {activeIndexingReport.keyTopics.map((topic, idx) => (
                    <li key={idx} className="flex items-center gap-2 text-xs text-[#17201e] dark:text-[#eef7f4]">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#0f766e] dark:bg-[#2dd4bf] shrink-0" />
                      <span>{topic}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="pt-2 flex flex-wrap items-center justify-between gap-2 border-t border-emerald-100 dark:border-emerald-800/40">
              <span className="text-[11px] text-[#596762] dark:text-[#9ab3ab]">
                🔒 تم ربط كتل البيانات دلالياً بالصفحات والفقرات لضمان توثيق الاسترجاع والموثوقية التامة.
              </span>
              <button
                type="button"
                onClick={() => {
                  const src = sources.find((s) => s.title === activeIndexingReport.title);
                  if (src) {
                    onAskAboutSource(src);
                  }
                }}
                className="px-3.5 py-1.5 rounded-xl bg-[#0f766e] hover:bg-[#115e59] text-white font-bold text-xs flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>💬 بدء الاستجواب الدقيق في المحادثة</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Dynamic Real-time Background Indexing Progress Bar (Web Worker) */}
      {indexingProgress && (
        <div className="bg-gradient-to-r from-teal-500/10 via-emerald-500/10 to-teal-500/10 dark:from-teal-950/40 dark:via-emerald-950/40 dark:to-teal-950/40 border border-teal-500/30 dark:border-teal-400/30 rounded-2xl p-4 shadow-sm animate-in fade-in duration-200 space-y-2.5">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-teal-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                <Loader2 className="w-4 h-4 animate-spin" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h4 className="text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-100">
                    {indexingProgress.status}
                  </h4>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-teal-600 text-white font-bold font-mono">
                    {indexingProgress.percent}%
                  </span>
                </div>
                <span className="text-[10px] text-teal-700 dark:text-teal-300 font-medium flex items-center gap-1 mt-0.5">
                  <Zap className="w-3 h-3 text-amber-500" />
                  <span>معالجة خلفية متعددة المسارات (Web Worker) - تضمن عدم توقف واجهة المستخدم</span>
                </span>
              </div>
            </div>
            <div className="text-xs font-mono font-bold text-teal-800 dark:text-teal-200 bg-white/60 dark:bg-black/20 px-3 py-1 rounded-xl border border-teal-500/20">
              {indexingProgress.processed} / {indexingProgress.total} مقطع
            </div>
          </div>

          {/* Dynamic Animated Progress Bar */}
          <div className="w-full bg-slate-200 dark:bg-[#1a2924] h-2.5 rounded-full overflow-hidden p-0.5 relative">
            <div
              className="h-full bg-gradient-to-r from-teal-500 via-emerald-400 to-teal-400 rounded-full transition-all duration-300 relative shadow-xs"
              style={{ width: `${Math.max(4, indexingProgress.percent)}%` }}
            >
              <div className="absolute inset-0 bg-white/25 animate-pulse" />
            </div>
          </div>
        </div>
      )}

      {/* Multi-Source Selection & Batch Actions Toolbar */}
      <div className="bg-white dark:bg-[#14201c] rounded-2xl border border-[#e2e8e5] dark:border-[#22352f] p-4 shadow-sm flex flex-wrap items-center justify-between gap-3">
        {/* Active RAG Selection Indicator */}
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-[#0f766e] dark:bg-[#2dd4bf]" />
          <span className="text-xs font-bold text-[#17201e] dark:text-[#eef7f4]">
            مصادر الذكاء الاصطناعي النشطة:
          </span>
          {selectedSourceIds.length > 0 ? (
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-[#e6f4f1] text-[#0f766e] dark:bg-[#132e29] dark:text-[#2dd4bf] font-bold">
              تم تحديد {selectedSourceIds.length} من أصل {sources.length} مصادر (سيركز RAG عليها)
            </span>
          ) : (
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300 font-bold">
              جميع المصادر نشطة تلقائيًا ({sources.length})
            </span>
          )}
        </div>

        {/* Action Buttons & Filter */}
        <div className="flex flex-wrap items-center gap-2 text-xs">
          <button
            onClick={onSelectAllSources}
            className="px-3 py-1.5 rounded-xl border border-[#e2e8e5] dark:border-[#22352f] hover:bg-gray-50 dark:hover:bg-gray-800 font-bold"
          >
            تحديد الكل
          </button>
          <button
            onClick={onClearSelectedSources}
            className="px-3 py-1.5 rounded-xl border border-[#e2e8e5] dark:border-[#22352f] hover:bg-gray-50 dark:hover:bg-gray-800 font-bold"
          >
            إلغاء التحديد
          </button>
          {selectedSourceIds.length > 0 && (
            <button
              onClick={handleBulkDelete}
              className="px-3 py-1.5 rounded-xl bg-red-50 text-red-600 dark:bg-red-950/40 dark:text-red-300 border border-red-200 dark:border-red-900 hover:bg-red-100 font-bold flex items-center gap-1 cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>حذف المحدد ({selectedSourceIds.length})</span>
            </button>
          )}

          {/* Direct Wikipedia Encyclopedia Search Button */}
          <button
            type="button"
            onClick={() => setIsWikiModalOpen(true)}
            className="px-3.5 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold flex items-center gap-1.5 shadow-sm transition-all cursor-pointer mr-auto"
            title="البحث واستيراد مقالات من موسوعة ويكيبيديا العالمية مباشرة"
          >
            <Globe className="w-3.5 h-3.5" />
            <span>بحث موسوعي في ويكيبيديا 🌐</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar for Source List */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2 flex-1 max-w-md">
          <div className="relative w-full">
            <Search className="w-4 h-4 text-gray-400 absolute right-3 top-2.5" />
            <input
              type="text"
              placeholder="تصفية المصادر بالاسم أو المحتوى..."
              value={listFilterQuery}
              onChange={(e) => setListFilterQuery(e.target.value)}
              className="w-full pr-9 pl-3 py-2 border border-[#e2e8e5] dark:border-[#22352f] rounded-xl bg-white dark:bg-[#14201c] text-xs text-[#17201e] dark:text-[#eef7f4]"
            />
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-1.5 bg-white dark:bg-[#14201c] p-1 rounded-xl border border-[#e2e8e5] dark:border-[#22352f] text-xs">
          <Filter className="w-3.5 h-3.5 text-gray-400 ml-1" />
          <button
            onClick={() => setTypeFilter('all')}
            className={`px-2.5 py-1 rounded-lg font-bold transition-colors cursor-pointer ${typeFilter === 'all' ? 'bg-[#0f766e] text-white shadow-xs' : 'text-gray-500 hover:text-gray-700 dark:hover:text-gray-300'}`}
          >
            الكل ({sources.length})
          </button>
          <button
            onClick={() => setTypeFilter('favorite')}
            className={`px-2.5 py-1 rounded-lg font-bold flex items-center gap-1 transition-colors cursor-pointer ${
              typeFilter === 'favorite'
                ? 'bg-rose-600 text-white shadow-xs'
                : 'text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40'
            }`}
          >
            <Heart className={`w-3.5 h-3.5 ${typeFilter === 'favorite' ? 'fill-current' : ''}`} />
            <span>المفضلة ({sources.filter((s) => favoriteSourceIds.includes(s.id) || !!s.favorite).length})</span>
          </button>
          <button
            onClick={() => setTypeFilter('pdf')}
            className={`px-2.5 py-1 rounded-lg font-bold transition-colors cursor-pointer ${typeFilter === 'pdf' ? 'bg-[#0f766e] text-white shadow-xs' : 'text-gray-500 hover:text-gray-700'}`}
          >
            PDF ({sources.filter((s) => s.type.includes('pdf') || (s.pages && s.pages.length > 1)).length})
          </button>
          <button
            onClick={() => setTypeFilter('image')}
            className={`px-2.5 py-1 rounded-lg font-bold transition-colors cursor-pointer ${typeFilter === 'image' ? 'bg-[#0f766e] text-white shadow-xs' : 'text-gray-500 hover:text-gray-700'}`}
          >
            صور OCR ({sources.filter((s) => s.type.includes('image') || /\.(png|jpe?g|webp|bmp)$/i.test(s.title)).length})
          </button>
          <button
            onClick={() => setTypeFilter('html')}
            className={`px-2.5 py-1 rounded-lg font-bold transition-colors cursor-pointer ${typeFilter === 'html' ? 'bg-[#0f766e] text-white shadow-xs' : 'text-gray-500 hover:text-gray-700'}`}
          >
            HTML / ويب ({sources.filter((s) => s.type.includes('html') || s.title.endsWith('.html') || s.title.endsWith('.htm')).length})
          </button>
          <button
            onClick={() => setTypeFilter('text')}
            className={`px-2.5 py-1 rounded-lg font-bold transition-colors cursor-pointer ${typeFilter === 'text' ? 'bg-[#0f766e] text-white shadow-xs' : 'text-gray-500 hover:text-gray-700'}`}
          >
            نصوص TXT ({sources.filter((s) => s.type === 'text/plain' || s.title.endsWith('.txt') || s.title.endsWith('.md')).length})
          </button>
          <button
            onClick={() => setTypeFilter('audio')}
            className={`px-2.5 py-1 rounded-lg font-bold transition-colors cursor-pointer ${typeFilter === 'audio' ? 'bg-[#0f766e] text-white shadow-xs' : 'text-gray-500 hover:text-gray-700'}`}
          >
            صوتيات ({sources.filter((s) => s.type.includes('audio') || /\.(mp3|wav|m4a|ogg|aac|webm)$/i.test(s.title)).length})
          </button>
          <button
            onClick={() => setTypeFilter('wikipedia')}
            className={`px-2.5 py-1 rounded-lg font-bold transition-colors cursor-pointer ${typeFilter === 'wikipedia' ? 'bg-[#0f766e] text-white shadow-xs' : 'text-gray-500 hover:text-gray-700'}`}
          >
            ويكيبيديا 🌐 ({sources.filter((s) => s.type === 'wikipedia' || s.title.includes('ويكيبيديا') || s.uri?.includes('wikipedia')).length})
          </button>
        </div>
      </div>

      {/* Sources Grid & Document Reader Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        {/* Sources List Column (hidden when in wide reader mode or on mobile) */}
        <div className={selectedPreviewSource ? (isReaderWideMode ? 'hidden' : 'hidden lg:block lg:col-span-5 space-y-3') : 'col-span-12 grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3'}>
          {filteredSources.length === 0 ? (
            <div className="col-span-full bg-white dark:bg-[#14201c] rounded-2xl p-10 border border-dashed border-[#e2e8e5] dark:border-[#22352f] text-center">
              <div className="w-12 h-12 rounded-2xl bg-[#e6f4f1] dark:bg-[#132e29] text-[#0f766e] dark:text-[#2dd4bf] flex items-center justify-center mx-auto mb-3">
                <FileText className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-sm text-[#17201e] dark:text-[#eef7f4] mb-1">
                {sources.length === 0 ? 'لا توجد مصادر مضافة بعد' : 'لا توجد مصادر تطابق الفلتر'}
              </h3>
              <p className="text-xs text-[#596762] dark:text-[#9ab3ab] max-w-sm mx-auto">
                {sources.length === 0
                  ? 'أضف أول مصدر من الأعلى (كتاب PDF، رابط، أو نص) لتبدأ المحادثة والتحليل.'
                  : 'جرب البحث باسم آخر أو إزالة التصفية.'}
              </p>
            </div>
          ) : (
            filteredSources.map((src) => {
              const isSelectedForAI = selectedSourceIds.includes(src.id);
              const isBeingPreviewed = selectedPreviewSource?.id === src.id;
              const sourceChunks = chunks.filter((c) => c.sourceId === src.id);
              const isEditing = editingSourceId === src.id;
              const isFavorite = favoriteSourceIds.includes(src.id) || !!src.favorite;

              return (
                <div
                  key={src.id}
                  className={`bg-white dark:bg-[#14201c] rounded-xl border p-4 transition-all shadow-sm flex flex-col justify-between gap-3 ${
                    isBeingPreviewed
                      ? 'border-[#0f766e] dark:border-[#2dd4bf] ring-2 ring-[#0f766e]/20'
                      : 'border-[#e2e8e5] dark:border-[#22352f]'
                  }`}
                >
                  <div>
                    {/* Top Row: Multi-select Checkbox + Heart Favorite + Title + Delete button */}
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          onClick={() => onToggleSelectSource(src.id)}
                          className="mt-0.5 text-[#0f766e] dark:text-[#2dd4bf] shrink-0 cursor-pointer"
                          title={isSelectedForAI ? 'إلغاء التحديد للذكاء الاصطناعي' : 'تحديد للذكاء الاصطناعي'}
                        >
                          {isSelectedForAI ? (
                            <CheckSquare className="w-4 h-4 text-[#0f766e] dark:text-[#2dd4bf]" />
                          ) : (
                            <Square className="w-4 h-4 text-gray-400 hover:text-gray-600" />
                          )}
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            if (onToggleFavoriteSource) {
                              onToggleFavoriteSource(src.id);
                            } else {
                              src.favorite = !src.favorite;
                            }
                          }}
                          className={`p-1 rounded-lg transition-colors cursor-pointer shrink-0 ${
                            isFavorite
                              ? 'text-rose-600 bg-rose-50 dark:bg-rose-950/40'
                              : 'text-slate-300 dark:text-slate-600 hover:text-rose-500'
                          }`}
                          title={isFavorite ? 'إزالة من المفضلة' : 'إضافة إلى المراجع المفضلة'}
                        >
                          <Heart className={`w-4 h-4 ${isFavorite ? 'fill-current text-rose-600' : ''}`} />
                        </button>
                      </div>

                      <div className="flex-1 min-w-0 pr-1">
                        {isEditing ? (
                          <div className="flex items-center gap-1">
                            <input
                              type="text"
                              value={editingTitle}
                              onChange={(e) => setEditingTitle(e.target.value)}
                              className="w-full px-2 py-1 text-xs border border-[#0f766e] rounded-lg bg-[#f6f8f7] dark:bg-[#1a2723] text-[#17201e] dark:text-[#eef7f4]"
                              autoFocus
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') saveRenaming(src.id);
                                if (e.key === 'Escape') setEditingSourceId(null);
                              }}
                            />
                            <button
                              onClick={() => saveRenaming(src.id)}
                              className="p-1 text-emerald-600 hover:bg-emerald-50 rounded"
                            >
                              <Check className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => setEditingSourceId(null)}
                              className="p-1 text-gray-400 hover:bg-gray-100 rounded"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ) : (
                          <div className="flex items-center gap-1 group">
                            <h4 
                              onClick={() => setPreviewModalSource(src)}
                              className="font-bold text-xs text-[#17201e] dark:text-[#eef7f4] truncate cursor-pointer hover:text-teal-600 dark:hover:text-teal-400 transition-colors"
                              title="اضغط لفتح المعاينة السريعة (500 حرف)"
                            >
                              {src.title}
                            </h4>
                            <button
                              onClick={() => startRenaming(src)}
                              className="opacity-0 group-hover:opacity-100 transition-opacity text-gray-400 hover:text-[#0f766e] p-0.5"
                              title="تعديل اسم المصدر"
                            >
                              <Edit2 className="w-3 h-3" />
                            </button>
                          </div>
                        )}
                      </div>

                      <button
                        onClick={() => {
                          if (confirm(`هل أنت متأكد من حذف المصدر «${src.title}»؟`)) {
                            onDeleteSource(src.id);
                            if (selectedPreviewSource?.id === src.id) setSelectedPreviewSource(null);
                          }
                        }}
                        className="text-gray-400 hover:text-red-500 p-1 shrink-0"
                        title="حذف المصدر"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    {/* Metadata Badges (Type, Size, Date, Pages, Chunks, Status) */}
                    {(() => {
                      const badge = getSourceFormatBadge(src);
                      return (
                        <div className="flex flex-wrap items-center gap-1.5 text-[10px] text-[#596762] dark:text-[#9ab3ab] mt-1.5">
                          <span className={`px-2 py-0.5 rounded-md font-bold border flex items-center gap-1 ${badge.color}`}>
                            {badge.icon}
                            <span>{badge.label}</span>
                          </span>

                          {(src.pageCount || (src.pages && src.pages.length) || 0) > 0 ? (
                            <span className="bg-emerald-50 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800/60 px-1.5 py-0.5 rounded font-bold flex items-center gap-1">
                              <BookOpen className="w-3 h-3 text-emerald-600 dark:text-emerald-400" />
                              {src.pageCount || src.pages?.length} صفحة
                            </span>
                          ) : (src.wordCount || 0) > 0 ? (
                            <span className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 px-1.5 py-0.5 rounded font-bold">
                              {src.wordCount?.toLocaleString()} كلمة
                            </span>
                          ) : null}

                          <span className="bg-teal-50 dark:bg-teal-950/50 text-teal-800 dark:text-teal-300 border border-teal-200/60 dark:border-teal-800/60 px-1.5 py-0.5 rounded font-bold flex items-center gap-1" title="مقاطع الفهرسة الدلالية لـ RAG">
                            <Layers className="w-3 h-3 text-teal-600 dark:text-teal-400" />
                            <span>{sourceChunks.length} مقطع RAG</span>
                          </span>

                          <span className="bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 px-1.5 py-0.5 rounded font-mono font-medium flex items-center gap-1">
                            <HardDrive className="w-3 h-3 text-gray-400" />
                            <span>{formatSize(src.size)}</span>
                          </span>

                          <span className="text-[10px] text-gray-400 dark:text-gray-500 flex items-center gap-1 font-mono">
                            <Clock className="w-3 h-3 text-gray-400" />
                            <span>{formatDate(src.createdAt)}</span>
                          </span>

                          {src.annotations && src.annotations.length > 0 && (
                            <span className="bg-amber-100 text-amber-800 dark:bg-amber-950/50 dark:text-amber-300 px-1.5 py-0.5 rounded font-bold flex items-center gap-1">
                              <Highlighter className="w-3 h-3" />
                              {src.annotations.length} تظليل
                            </span>
                          )}
                        </div>
                      );
                    })()}

                    {/* Processing Status Indicator */}
                    <div className="mt-2 flex items-center gap-1 text-[10px]">
                      {src.status === 'Uploading' ? (
                        <span className="text-teal-600 flex items-center gap-1">
                          <Loader2 className="w-3 h-3 animate-spin" />
                          جاري رفع الملف...
                        </span>
                      ) : src.status === 'Processing' ? (
                        <span className="text-amber-600 flex items-center gap-1">
                          <Loader2 className="w-3 h-3 animate-spin" />
                          قيد المعالجة والتقطيع...
                        </span>
                      ) : src.status === 'Failed' ? (
                        <span className="text-red-600 flex items-center gap-1" title={src.errorMessage}>
                          <AlertCircle className="w-3 h-3" />
                          {src.errorMessage || 'تعذرت المعالجة'}
                        </span>
                      ) : src.status === 'Unsupported' ? (
                        <span className="text-amber-700 dark:text-amber-400 flex items-center gap-1" title={src.errorMessage}>
                          <AlertCircle className="w-3 h-3" />
                          {src.errorMessage || 'صيغة غير مدعومة'}
                        </span>
                      ) : (
                        <span className="text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                          مفهرس وجاهز للاسترجاع (RAG Ready)
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Smart Responsive Task Grid (Guaranteed zero-overflow container bounds) */}
                  <div className="w-full min-w-0 max-w-full overflow-hidden box-border pt-3 border-t border-[#e2e8e5] dark:border-[#22352f] space-y-1.5">
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 w-full min-w-0">
                      {/* 1. Preview Document */}
                      <button
                        type="button"
                        onClick={() => setInAppPreviewSource(src)}
                        className="px-2 py-1.5 rounded-xl bg-teal-50 dark:bg-teal-950/60 hover:bg-teal-600 hover:text-white text-teal-800 dark:text-teal-200 text-[11px] font-bold flex items-center justify-center gap-1 transition-colors border border-teal-200/60 dark:border-teal-800/60 cursor-pointer shadow-2xs truncate min-w-0 group"
                        title="معاينة المستند كما هو داخل التطبيق"
                      >
                        <Eye className="w-3.5 h-3.5 shrink-0 text-teal-600 dark:text-teal-400 group-hover:text-white" />
                        <span className="truncate">معاينة كما هي</span>
                      </button>

                      {/* 2. Highlights & Annotations */}
                      <button
                        type="button"
                        onClick={() => {
                          if (isBeingPreviewed) {
                            setSelectedPreviewSource(null);
                          } else {
                            setSelectedPreviewSource(src);
                            setPreviewTab('text');
                          }
                          setSourceSearchTerm('');
                        }}
                        className={`px-2 py-1.5 rounded-xl text-[11px] font-bold flex items-center justify-center gap-1 transition-colors border cursor-pointer shadow-2xs truncate min-w-0 ${
                          isBeingPreviewed
                            ? 'bg-amber-500 text-white border-amber-600'
                            : 'bg-amber-50 dark:bg-amber-950/50 text-amber-800 dark:text-amber-200 border-amber-200/70 dark:border-amber-800/70 hover:bg-amber-100'
                        }`}
                        title="لوحة التظليل التفاعلية وإضافة الملاحظات مع حفظ الإحداثيات"
                      >
                        <Highlighter className="w-3.5 h-3.5 shrink-0 text-amber-600 dark:text-amber-400" />
                        <span className="truncate">تظليل ({src.annotations?.length || 0})</span>
                      </button>

                      {/* 3. Deep AI Extraction & Breakdown */}
                      <button
                        type="button"
                        onClick={() => setIntelligenceModalSource(src)}
                        className="px-2 py-1.5 rounded-xl bg-gradient-to-r from-teal-50 to-emerald-50 dark:from-teal-950/70 dark:to-emerald-950/70 text-[#0f766e] dark:text-[#2dd4bf] hover:from-[#0f766e] hover:to-[#0f766e] hover:text-white text-[11px] font-bold flex items-center justify-center gap-1 transition-all border border-teal-300 dark:border-teal-700/80 cursor-pointer shadow-xs truncate min-w-0 group"
                        title="استخراج وتحليل ذكي فوري للمفاهيم والقوانين والتعريفات والأسئلة عبر الذكاء الاصطناعي"
                      >
                        <Sparkles className="w-3.5 h-3.5 shrink-0 text-[#0f766e] dark:text-[#2dd4bf] group-hover:text-white animate-pulse" />
                        <span className="truncate">استخراج وتحليل ⚡</span>
                      </button>

                      {/* 4. Distraction-Free Reader Mode */}
                      <button
                        type="button"
                        onClick={() => setAccessibleReaderSource(src)}
                        className="px-2 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800/70 text-slate-700 dark:text-slate-300 hover:bg-slate-200 text-[11px] font-bold flex items-center justify-center gap-1 transition-colors border border-slate-200 dark:border-slate-700 cursor-pointer shadow-2xs truncate min-w-0"
                        title="فتح وضع القارئ المريح الخالي من التشتت"
                      >
                        <BookOpen className="w-3.5 h-3.5 shrink-0 text-slate-500 dark:text-slate-400" />
                        <span className="truncate">وضع القارئ</span>
                      </button>

                      {/* 5. Indexing Report */}
                      <button
                        type="button"
                        onClick={() => {
                          const rep = src.indexingReport || generateInitialIndexingReport(
                            src.title,
                            src.content,
                            src.headings,
                            src.pageCount
                          );
                          setActiveIndexingReport(rep);
                          window.scrollTo({ top: 180, behavior: 'smooth' });
                        }}
                        className="px-2 py-1.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 text-emerald-800 dark:text-emerald-200 hover:bg-emerald-100 text-[11px] font-bold flex items-center justify-center gap-1 transition-colors border border-emerald-200/70 dark:border-emerald-800/70 cursor-pointer shadow-2xs truncate min-w-0"
                        title="عرض تقرير الفهرسة الأولي والملخص التنفيذي"
                      >
                        <FileText className="w-3.5 h-3.5 shrink-0 text-emerald-600 dark:text-emerald-400" />
                        <span className="truncate">تقرير الفهرسة</span>
                      </button>

                      {/* 6. Quick Preview 500 chars */}
                      <button
                        type="button"
                        onClick={() => setPreviewModalSource(src)}
                        className="px-2 py-1.5 rounded-xl bg-teal-50/80 dark:bg-teal-950/40 text-teal-800 dark:text-teal-200 hover:bg-teal-100 text-[11px] font-bold flex items-center justify-center gap-1 transition-colors border border-teal-200 dark:border-teal-800 cursor-pointer shadow-2xs truncate min-w-0"
                        title="معاينة أول 500 حرف من محتوى المرجع"
                      >
                        <Eye className="w-3.5 h-3.5 shrink-0 text-teal-600 dark:text-teal-400" />
                        <span className="truncate">معاينة (500 حرف)</span>
                      </button>

                      {/* 7. Export as PDF */}
                      <button
                        type="button"
                        onClick={() => {
                          try {
                            exportSourceToPdf(src, notebookName);
                          } catch {
                            alert('حدث خطأ أثناء تصدير ملف PDF.');
                          }
                        }}
                        className="px-2 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 hover:bg-slate-200 text-[11px] font-bold flex items-center justify-center gap-1 transition-colors border border-slate-200 dark:border-slate-700 cursor-pointer shadow-2xs truncate min-w-0"
                        title="تصدير المرجع كملف PDF قابل للتنزيل"
                      >
                        <Download className="w-3.5 h-3.5 shrink-0 text-rose-500" />
                        <span className="truncate">تصدير PDF</span>
                      </button>

                      {/* 8. Text To Speech */}
                      <button
                        type="button"
                        onClick={() => speakText(src.content, { title: `قراءة مرجع: ${src.title}` })}
                        className="px-2 py-1.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-200 hover:bg-emerald-100 text-[11px] font-bold flex items-center justify-center gap-1 transition-colors border border-emerald-200 dark:border-emerald-800 cursor-pointer shadow-2xs truncate min-w-0"
                        title="قراءة صوتية ذكية لكامل المرجع"
                      >
                        <Volume2 className="w-3.5 h-3.5 shrink-0 text-emerald-600 dark:text-emerald-400" />
                        <span className="truncate">قراءة صوتية</span>
                      </button>

                      {/* 9. Ask in Chat */}
                      <button
                        type="button"
                        onClick={() => onAskAboutSource(src)}
                        className="px-2 py-1.5 rounded-xl bg-[#0f766e] text-white hover:bg-[#115e59] text-[11px] font-bold flex items-center justify-center gap-1 transition-colors cursor-pointer shadow-xs truncate min-w-0"
                        title="بدء استجواب هذا المصدر في المحادثة الذكية"
                      >
                        <MessageSquare className="w-3.5 h-3.5 shrink-0" />
                        <span className="truncate">اسأل بالدردشة</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Source Reader Column with Interactive PDF Preview & Highlighting */}
        {selectedPreviewSource && (
          <div
            id="active-source-reader-container"
            className={`${isReaderWideMode ? 'col-span-12 h-[90vh]' : 'col-span-12 lg:col-span-7 h-[85vh]'} flex flex-col transition-all duration-300`}
          >
            {/* Mobile Return to Sources List */}
            <div className="lg:hidden mb-3">
              <button
                type="button"
                onClick={() => setSelectedPreviewSource(null)}
                className="w-full py-2.5 px-4 bg-[#0f766e] text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-xs cursor-pointer active:scale-98 transition-transform"
              >
                <ArrowRight className="w-4 h-4" />
                <span>العودة إلى قائمة مصادر الدفتر ({sources.length})</span>
              </button>
            </div>
            {previewTab === 'html' && selectedPreviewSource.rawHtml ? (
              <div className="bg-white dark:bg-[#14201c] rounded-2xl border border-[#e2e8e5] dark:border-[#22352f] p-4 shadow-sm flex flex-col h-full">
                <div className="flex flex-wrap items-center justify-between pb-3 border-b border-[#e2e8e5] dark:border-[#22352f] mb-3 gap-2">
                  <div className="flex items-center gap-2 truncate">
                    <span className="bg-[#0f766e] text-white text-[10px] font-bold px-2 py-0.5 rounded">HTML</span>
                    <h3 className="font-bold text-sm text-[#17201e] dark:text-[#eef7f4] truncate">
                      {selectedPreviewSource.title}
                    </h3>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setAccessibleReaderSource(selectedPreviewSource)}
                      className="px-2.5 py-1 bg-teal-600 hover:bg-teal-700 text-white rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer shadow-xs"
                      title="فتح في وضع القارئ المريح والتباين العالي (Reader View)"
                    >
                      <BookOpen className="w-3.5 h-3.5" />
                      <span>وضع القارئ</span>
                    </button>
                    <button
                      onClick={() => onAskAboutSource(selectedPreviewSource)}
                      className="px-2.5 py-1 bg-[#e6f4f1] dark:bg-[#132e29] text-[#0f766e] dark:text-[#2dd4bf] hover:bg-[#0f766e] hover:text-white transition-colors text-xs font-bold rounded-lg flex items-center gap-1 cursor-pointer"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>اسأل المعلم الذكي</span>
                    </button>
                    <button
                      onClick={() => setIsReaderWideMode(!isReaderWideMode)}
                      className="px-2.5 py-1 border border-[#e2e8e5] dark:border-[#22352f] text-xs font-semibold rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors cursor-pointer"
                      title={isReaderWideMode ? 'تصغير العرض' : 'عرض كامل للشاشة'}
                    >
                      {isReaderWideMode ? 'عرض عادي' : 'عرض واسع'}
                    </button>
                    <button
                      onClick={() => setPreviewTab('text')}
                      className="px-2.5 py-1 bg-amber-50 dark:bg-amber-950/40 text-amber-800 dark:text-amber-300 text-xs font-bold rounded-lg hover:bg-amber-100 transition-colors cursor-pointer"
                    >
                      عارض التظليلات
                    </button>
                    <button
                      onClick={() => setSelectedPreviewSource(null)}
                      className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 p-1 rounded-lg cursor-pointer"
                      aria-label="إغلاق المعاينة"
                    >
                      ✕
                    </button>
                  </div>
                </div>
                <div className="flex-1 overflow-hidden rounded-xl border border-gray-100 dark:border-gray-800 bg-white">
                  <iframe
                    title="HTML Source Interactive Preview"
                    sandbox="allow-scripts allow-same-origin"
                    srcDoc={selectedPreviewSource.rawHtml}
                    className="w-full h-full border-0 bg-white"
                  />
                </div>
              </div>
            ) : (
              <PDFPreviewAnnotator
                source={sources.find((s) => s.id === selectedPreviewSource.id) || selectedPreviewSource}
                chunks={chunks}
                onUpdateAnnotations={handleUpdateAnnotations}
                onAskAboutQuote={onAskAboutQuote}
                onExportToNote={onExportToNote}
                onClose={() => setSelectedPreviewSource(null)}
                onOpenReaderView={() => setAccessibleReaderSource(selectedPreviewSource)}
                isWideMode={isReaderWideMode}
                onToggleWideMode={() => setIsReaderWideMode(!isReaderWideMode)}
              />
            )}
          </div>
        )}
      </div>

      {/* Quick Search Result Reader / Preview Modal */}
      {previewingSearchItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs">
          <div className="bg-white dark:bg-[#14201c] rounded-2xl border border-[#e2e8e5] dark:border-[#22352f] shadow-2xl w-full max-w-2xl max-h-[85vh] flex flex-col overflow-hidden">
            <div className="p-4 border-b border-[#e2e8e5] dark:border-[#22352f] flex items-center justify-between gap-3 bg-gray-50/50 dark:bg-gray-800/30">
              <div className="flex-1 truncate">
                <span className="text-[10px] font-bold text-[#0f766e] dark:text-[#2dd4bf] uppercase font-mono block">
                  {previewingSearchItem.category || previewingSearchItem.domain || 'معاينة المصدر'}
                </span>
                <h3 className="font-bold text-sm text-[#17201e] dark:text-[#eef7f4] truncate">
                  {previewingSearchItem.title}
                </h3>
              </div>
              <button
                onClick={() => setPreviewingSearchItem(null)}
                className="p-1 rounded-lg text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 flex-1 overflow-y-auto space-y-3">
              {previewItemLoading && !previewItemContent ? (
                <div className="py-12 text-center text-xs text-gray-400 flex flex-col items-center gap-2">
                  <Loader2 className="w-6 h-6 animate-spin text-[#0f766e]" />
                  <span>جاري جلب النص الكامل للمصدر...</span>
                </div>
              ) : (
                <div className="prose dark:prose-invert max-w-none text-xs leading-relaxed text-[#17201e] dark:text-[#eef7f4] whitespace-pre-wrap">
                  {previewItemContent || previewingSearchItem.snippet || 'لا يوجد محتوى معاينة متاح.'}
                </div>
              )}
            </div>

            <div className="p-3 border-t border-[#e2e8e5] dark:border-[#22352f] flex items-center justify-between gap-2 bg-gray-50/50 dark:bg-gray-800/30">
              <a
                href={previewingSearchItem.uri}
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs text-gray-500 hover:text-teal-600 flex items-center gap-1"
              >
                <span>فتح الرابط الأصلي</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setPreviewingSearchItem(null)}
                  className="px-3 py-1.5 rounded-xl border border-gray-200 dark:border-gray-700 text-xs font-bold text-gray-600 dark:text-gray-300"
                >
                  إغلاق
                </button>
                <button
                  type="button"
                  onClick={() => {
                    handleImportSearchResult(previewingSearchItem);
                    setPreviewingSearchItem(null);
                  }}
                  disabled={isLoading}
                  className="px-4 py-1.5 bg-[#0f766e] text-white rounded-xl text-xs font-bold hover:bg-[#115e59] flex items-center gap-1.5 shadow-sm"
                >
                  <Plus className="w-4 h-4" />
                  <span>إضافة إلى الدفتر الآن</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Smart Extraction & Source Intelligence Modal */}
      {intelligenceModalSource && (
        <SourceIntelligenceModal
          source={intelligenceModalSource}
          onClose={() => setIntelligenceModalSource(null)}
          onExportToNote={onExportToNote}
          onAskInChat={(prompt) => {
            onAskAboutSource({
              ...intelligenceModalSource,
              title: `${intelligenceModalSource.title}: سؤال محدد`,
              content: prompt,
            });
            setIntelligenceModalSource(null);
          }}
        />
      )}

      {/* Accessible Distraction-Free High-Contrast Reader View */}
      {accessibleReaderSource && (
        <AccessibleReaderView
          source={accessibleReaderSource}
          chunks={chunks}
          onClose={() => setAccessibleReaderSource(null)}
          onAskAboutQuote={onAskAboutQuote}
          onExportToNote={onExportToNote}
        />
      )}

      {/* Comprehensive In-App Source Preview Modal (Original PDF, Web, & Reader) */}
      {inAppPreviewSource && (
        <SourceInAppPreviewModal
          source={inAppPreviewSource}
          onClose={() => setInAppPreviewSource(null)}
          onAskAboutSource={onAskAboutSource}
          onAskAboutQuote={onAskAboutQuote}
          onExportToNote={onExportToNote}
          onUpdateAnnotations={handleUpdateAnnotations}
        />
      )}

      {/* 500-Character Source Preview Modal */}
      {previewModalSource && (
        <SourcePreviewModal
          source={previewModalSource}
          isOpen={!!previewModalSource}
          onClose={() => setPreviewModalSource(null)}
          onOpenFullReader={(s) => setInAppPreviewSource(s)}
          isFavorite={favoriteSourceIds.includes(previewModalSource.id) || !!previewModalSource.favorite}
          onToggleFavorite={(id) => onToggleFavoriteSource ? onToggleFavoriteSource(id) : undefined}
          notebookName={notebookName}
        />
      )}

      {/* Wikipedia Encyclopedia Search Modal */}
      <WikipediaSearchModal
        isOpen={isWikiModalOpen}
        onClose={() => setIsWikiModalOpen(false)}
        onAddSource={onAddSource}
        notebookId={currentNotebookId}
        notebookName={notebookName}
      />

      {/* Web Article Clipper Modal with Boilerplate Pruning */}
      <WebArticleClipperModal
        isOpen={isClipperModalOpen}
        onClose={() => setIsClipperModalOpen(false)}
        currentNotebookId={currentNotebookId}
        onAddSource={onAddSource}
      />
    </div>
  );
};
