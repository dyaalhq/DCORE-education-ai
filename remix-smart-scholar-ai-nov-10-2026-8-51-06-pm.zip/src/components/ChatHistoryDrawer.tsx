import React, { useState, useMemo } from 'react';
import { 
  History, 
  MessageSquare, 
  Plus, 
  Search, 
  Edit3, 
  Trash2, 
  Check, 
  X, 
  Clock, 
  Calendar, 
  ChevronLeft, 
  FileDown, 
  Sparkles,
  AlertCircle
} from 'lucide-react';
import { ChatSession } from '../types';

interface ChatHistoryDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  sessions: ChatSession[];
  currentSessionId: string;
  onSelectSession: (id: string) => void;
  onNewSession: () => void;
  onDeleteSession: (id: string) => void;
  onRenameSession?: (id: string, newTitle: string) => void;
  onExportSessionPdf?: (session: ChatSession) => void;
}

export const ChatHistoryDrawer: React.FC<ChatHistoryDrawerProps> = ({
  isOpen,
  onClose,
  sessions,
  currentSessionId,
  onSelectSession,
  onNewSession,
  onDeleteSession,
  onRenameSession,
  onExportSessionPdf,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [editingSessionId, setEditingSessionId] = useState<string | null>(null);
  const [editTitleInput, setEditTitleInput] = useState('');
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  // Filtered sessions based on search query
  const filteredSessions = useMemo(() => {
    if (!searchQuery.trim()) return sessions;
    const q = searchQuery.toLowerCase().trim();
    return sessions.filter((s) => {
      const matchTitle = s.title.toLowerCase().includes(q);
      const matchMessages = s.messages.some((m) => m.text.toLowerCase().includes(q));
      return matchTitle || matchMessages;
    });
  }, [sessions, searchQuery]);

  // Group sessions by temporal categories like world-class platforms
  const groupedSessions = useMemo(() => {
    const now = Date.now();
    const oneDay = 24 * 60 * 60 * 1000;
    const startOfToday = new Date().setHours(0, 0, 0, 0);
    const startOfYesterday = startOfToday - oneDay;
    const startOfLast7Days = startOfToday - 7 * oneDay;
    const startOfLast30Days = startOfToday - 30 * oneDay;

    const groups: {
      today: ChatSession[];
      yesterday: ChatSession[];
      last7Days: ChatSession[];
      last30Days: ChatSession[];
      older: ChatSession[];
    } = {
      today: [],
      yesterday: [],
      last7Days: [],
      last30Days: [],
      older: [],
    };

    filteredSessions.forEach((session) => {
      const timestamp = session.updated || session.created || now;
      if (timestamp >= startOfToday) {
        groups.today.push(session);
      } else if (timestamp >= startOfYesterday) {
        groups.yesterday.push(session);
      } else if (timestamp >= startOfLast7Days) {
        groups.last7Days.push(session);
      } else if (timestamp >= startOfLast30Days) {
        groups.last30Days.push(session);
      } else {
        groups.older.push(session);
      }
    });

    return [
      { key: 'today', label: 'اليوم', items: groups.today },
      { key: 'yesterday', label: 'الأمس', items: groups.yesterday },
      { key: 'last7Days', label: 'آخر 7 أيام', items: groups.last7Days },
      { key: 'last30Days', label: 'آخر 30 يوماً', items: groups.last30Days },
      { key: 'older', label: 'سابقاً', items: groups.older },
    ].filter((g) => g.items.length > 0);
  }, [filteredSessions]);

  const handleStartRename = (e: React.MouseEvent, s: ChatSession) => {
    e.stopPropagation();
    setEditingSessionId(s.id);
    setEditTitleInput(s.title);
  };

  const handleSaveRename = (e: React.MouseEvent | React.FormEvent, sessionId: string) => {
    e.stopPropagation();
    e.preventDefault();
    if (editTitleInput.trim() && onRenameSession) {
      onRenameSession(sessionId, editTitleInput.trim());
    }
    setEditingSessionId(null);
  };

  const handleCancelRename = (e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingSessionId(null);
  };

  const handleDeleteClick = (e: React.MouseEvent, sessionId: string) => {
    e.stopPropagation();
    setConfirmDeleteId(sessionId);
  };

  const handleConfirmDelete = (e: React.MouseEvent, sessionId: string) => {
    e.stopPropagation();
    onDeleteSession(sessionId);
    setConfirmDeleteId(null);
  };

  const handleCancelDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    setConfirmDeleteId(null);
  };

  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-xs animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div 
        className="w-full sm:w-96 md:w-[420px] max-w-full h-full bg-white dark:bg-[#0f1715] border-r sm:border-r-0 sm:border-l border-slate-200 dark:border-[#1e342b] shadow-2xl flex flex-col animate-in slide-in-from-right duration-250 select-text"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 border-b border-slate-200 dark:border-[#1e342b] bg-slate-50/70 dark:bg-[#121f1a]/80 backdrop-blur-md flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-teal-600 text-white flex items-center justify-center shadow-sm">
              <History className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-sm sm:text-base text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
                <span>سجل المحادثات الذكية</span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-teal-100 dark:bg-teal-950 text-teal-800 dark:text-teal-300 font-bold">
                  {sessions.length}
                </span>
              </h3>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                جلسات المذاكرة والاستفسار الأكاديمي المحفوظة
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-200/50 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            title="إغلاق السجل"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action Bar: New Chat & Search Input */}
        <div className="p-3.5 space-y-2.5 border-b border-slate-200/80 dark:border-[#1e342b] shrink-0 bg-white dark:bg-[#0f1715]">
          <button
            type="button"
            onClick={() => {
              onNewSession();
              onClose();
            }}
            className="w-full py-2.5 px-4 bg-gradient-to-r from-teal-700 via-teal-600 to-emerald-600 hover:from-teal-800 hover:to-emerald-700 text-white rounded-xl text-xs font-black flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer active:scale-[0.99]"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span>بدء محادثة جديدة (+ New Chat)</span>
          </button>

          <div className="relative">
            <input
              type="text"
              placeholder="البحث في سجل المحادثات والرسائل..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-9 py-2 text-xs bg-slate-50 dark:bg-[#14201c] border border-slate-200 dark:border-[#22352f] rounded-xl text-slate-800 dark:text-slate-100 focus:outline-none focus:border-teal-600 dark:focus:border-teal-400 placeholder:text-slate-400"
            />
            <Search className="w-4 h-4 text-slate-400 absolute right-3 top-2.5" />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute left-2.5 top-2.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Sessions List grouped by date */}
        <div className="flex-1 overflow-y-auto p-3.5 space-y-5">
          {sessions.length === 0 ? (
            <div className="h-64 flex flex-col items-center justify-center text-center p-6 space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-teal-50 dark:bg-teal-950/50 text-teal-600 flex items-center justify-center">
                <MessageSquare className="w-6 h-6" />
              </div>
              <p className="text-xs font-bold text-slate-600 dark:text-slate-300">
                لا توجد محادثات سابقة محفوظة بعد
              </p>
              <p className="text-[11px] text-slate-400 max-w-xs leading-relaxed">
                ابدأ محادثتك الأولى وسيقوم النظام بحفظ كافة الأسئلة والشروحات تلقائياً للرجوع إليها في أي وقت.
              </p>
            </div>
          ) : filteredSessions.length === 0 ? (
            <div className="h-48 flex flex-col items-center justify-center text-center p-6 space-y-2">
              <AlertCircle className="w-8 h-8 text-amber-500" />
              <p className="text-xs font-bold text-slate-600 dark:text-slate-300">
                لا توجد محادثة تطابق «{searchQuery}»
              </p>
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="text-xs text-teal-600 font-bold hover:underline cursor-pointer"
              >
                مسح كلمة البحث
              </button>
            </div>
          ) : (
            groupedSessions.map((group) => (
              <div key={group.key} className="space-y-2">
                <div className="flex items-center gap-2 px-1">
                  <span className="text-[11px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                    {group.label}
                  </span>
                  <div className="h-px flex-1 bg-slate-100 dark:bg-[#1a2924]" />
                </div>

                <div className="space-y-1.5">
                  {group.items.map((s) => {
                    const isActive = s.id === currentSessionId;
                    const isEditing = editingSessionId === s.id;
                    const isDeleting = confirmDeleteId === s.id;
                    const lastMsg = s.messages.length > 0 ? s.messages[s.messages.length - 1] : null;
                    const dateFormatted = new Date(s.updated || s.created).toLocaleDateString('ar', {
                      month: 'short',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    });

                    return (
                      <div
                        key={s.id}
                        onClick={() => {
                          if (!isEditing && !isDeleting) {
                            onSelectSession(s.id);
                            onClose();
                          }
                        }}
                        className={`group relative p-3 rounded-2xl border transition-all cursor-pointer ${
                          isActive
                            ? 'bg-teal-50/80 dark:bg-teal-950/40 border-teal-500/80 shadow-xs ring-1 ring-teal-500/30'
                            : 'bg-white dark:bg-[#131f1b] border-slate-200/90 dark:border-[#20322b] hover:border-teal-400 hover:shadow-xs'
                        }`}
                      >
                        {isDeleting ? (
                          <div className="p-1 space-y-2 text-right">
                            <p className="text-xs font-bold text-rose-700 dark:text-rose-400 flex items-center gap-1.5">
                              <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                              <span>هل أنت متأكد من حذف هذه المحادثة؟</span>
                            </p>
                            <div className="flex items-center gap-2 justify-end">
                              <button
                                type="button"
                                onClick={(e) => handleCancelDelete(e)}
                                className="px-2.5 py-1 text-[11px] font-bold rounded-lg bg-slate-100 dark:bg-[#1c2c26] text-slate-600 dark:text-slate-300 hover:bg-slate-200 cursor-pointer"
                              >
                                إلغاء
                              </button>
                              <button
                                type="button"
                                onClick={(e) => handleConfirmDelete(e, s.id)}
                                className="px-3 py-1 text-[11px] font-bold rounded-lg bg-rose-600 hover:bg-rose-700 text-white cursor-pointer shadow-2xs"
                              >
                                نعم، احذف
                              </button>
                            </div>
                          </div>
                        ) : isEditing ? (
                          <form onSubmit={(e) => handleSaveRename(e, s.id)} className="space-y-2">
                            <input
                              type="text"
                              value={editTitleInput}
                              onChange={(e) => setEditTitleInput(e.target.value)}
                              autoFocus
                              className="w-full text-xs font-bold px-2.5 py-1.5 bg-white dark:bg-[#1a2823] border border-teal-500 rounded-lg text-slate-800 dark:text-slate-100 focus:outline-none"
                            />
                            <div className="flex items-center gap-1.5 justify-end">
                              <button
                                type="button"
                                onClick={handleCancelRename}
                                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 cursor-pointer"
                              >
                                <X className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="submit"
                                onClick={(e) => handleSaveRename(e, s.id)}
                                className="px-2.5 py-1 rounded-lg bg-teal-600 text-white text-[11px] font-bold flex items-center gap-1 cursor-pointer"
                              >
                                <Check className="w-3 h-3" />
                                <span>حفظ</span>
                              </button>
                            </div>
                          </form>
                        ) : (
                          <>
                            <div className="flex items-start justify-between gap-2">
                              <div className="flex items-center gap-2 min-w-0 flex-1">
                                <span className={`w-2 h-2 rounded-full shrink-0 ${isActive ? 'bg-teal-600 animate-pulse' : 'bg-slate-300 dark:bg-slate-600'}`} />
                                <h4 className="text-xs font-bold text-slate-800 dark:text-slate-100 truncate">
                                  {s.title}
                                </h4>
                              </div>

                              {/* Hover Action Buttons */}
                              <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                {onRenameSession && (
                                  <button
                                    type="button"
                                    onClick={(e) => handleStartRename(e, s)}
                                    className="p-1 rounded-md text-slate-400 hover:text-teal-600 hover:bg-slate-100 dark:hover:bg-[#1a2823] cursor-pointer"
                                    title="إعادة تسمية"
                                  >
                                    <Edit3 className="w-3.5 h-3.5" />
                                  </button>
                                )}
                                {onExportSessionPdf && s.messages.length > 0 && (
                                  <button
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      onExportSessionPdf(s);
                                    }}
                                    className="p-1 rounded-md text-slate-400 hover:text-teal-600 hover:bg-slate-100 dark:hover:bg-[#1a2823] cursor-pointer"
                                    title="تصدير PDF"
                                  >
                                    <FileDown className="w-3.5 h-3.5" />
                                  </button>
                                )}
                                <button
                                  type="button"
                                  onClick={(e) => handleDeleteClick(e, s.id)}
                                  className="p-1 rounded-md text-slate-400 hover:text-rose-600 hover:bg-slate-100 dark:hover:bg-[#1a2823] cursor-pointer"
                                  title="حذف المحادثة"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>

                            {/* Message Preview Snippet */}
                            {lastMsg && (
                              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 line-clamp-1 leading-snug">
                                <span className="font-semibold text-slate-600 dark:text-slate-300">
                                  {lastMsg.role === 'user' ? 'أنت: ' : 'المعلم: '}
                                </span>
                                {lastMsg.text}
                              </p>
                            )}

                            {/* Meta footer: Message Count and Timestamp */}
                            <div className="flex items-center justify-between text-[10px] text-slate-400 dark:text-slate-500 mt-2 pt-1 border-t border-slate-100 dark:border-[#1a2823]">
                              <span className="flex items-center gap-1 font-mono">
                                <Clock className="w-3 h-3" />
                                {dateFormatted}
                              </span>
                              <span className="px-1.5 py-0.5 rounded-md bg-slate-100 dark:bg-[#1b2b25] text-slate-600 dark:text-slate-300 font-bold">
                                {s.messages.length} {s.messages.length === 1 ? 'رسالة' : 'رسائل'}
                              </span>
                            </div>
                          </>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer Statistics */}
        <div className="p-3 border-t border-slate-200 dark:border-[#1e342b] bg-slate-50/50 dark:bg-[#111c18] text-[11px] text-slate-500 dark:text-slate-400 flex items-center justify-between shrink-0">
          <span>إجمالي المحادثات: <strong className="text-teal-700 dark:text-teal-400">{sessions.length}</strong></span>
          <span>إجمالي الرسائل: <strong className="text-teal-700 dark:text-teal-400">{sessions.reduce((acc, s) => acc + s.messages.length, 0)}</strong></span>
        </div>
      </div>
    </div>
  );
};
