import React, { useState, useMemo } from 'react';
import {
  Share2,
  BookOpen,
  Layers,
  Sparkles,
  ExternalLink,
  Search,
  Copy,
  Check,
  Eye,
  FileText,
  TrendingUp,
  Award,
  ArrowRight,
  Hash,
  Link2
} from 'lucide-react';
import { Source, SourceChunk } from '../types';

interface CitationExplorerProps {
  sources: Source[];
  chunks: SourceChunk[];
  onAskAboutChunk?: (text: string, pageNumber: number) => void;
  onPreviewSource?: (source: Source) => void;
  onExportToNote?: (title: string, content: string) => void;
}

interface CitationConnection {
  sourceAId: string;
  sourceBId: string;
  sourceATitle: string;
  sourceBTitle: string;
  sharedKeywords: string[];
  connectionStrength: number;
}

interface HighlyCitedChunk {
  chunk: SourceChunk;
  citationScore: number;
  referencingSourcesCount: number;
  keyConcepts: string[];
}

export const CitationExplorer: React.FC<CitationExplorerProps> = ({
  sources,
  chunks,
  onAskAboutChunk,
  onPreviewSource,
  onExportToNote,
}) => {
  const [selectedSourceId, setSelectedSourceId] = useState<string>('all');
  const [copiedChunkId, setCopiedChunkId] = useState<string | null>(null);
  const [searchFilter, setSearchFilter] = useState('');

  // 1. Analyze and extract keywords and build citation connections between sources
  const { connections, highlyCitedChunks, globalKeywords } = useMemo(() => {
    if (sources.length === 0 || chunks.length === 0) {
      return { connections: [], highlyCitedChunks: [], globalKeywords: [] };
    }

    // Extract key conceptual tokens per source
    const stopWords = new Set([
      'في', 'من', 'على', 'إلى', 'عن', 'مع', 'هذا', 'هذه', 'ذلك', 'تلك', 'التي', 'الذي', 'الذين',
      'كان', 'كانت', 'يكون', 'أن', 'إن', 'ما', 'لا', 'لم', 'لن', 'ثم', 'أو', 'أم', 'كل', 'بعض',
      'غير', 'بين', 'عند', 'حيث', 'كيف', 'ماذا', 'لماذا', 'وهو', 'وهي', 'وقد', 'فقد', 'كما',
      'the', 'and', 'for', 'that', 'this', 'with', 'from', 'are', 'was', 'were'
    ]);

    const sourceKeywordMap = new Map<string, Set<string>>();
    const keywordGlobalFrequency = new Map<string, number>();

    sources.forEach((src) => {
      const tokens = (src.content || '')
        .toLowerCase()
        .replace(/[^\w\u0600-\u06FF\s]/g, ' ')
        .split(/\s+/)
        .filter((w) => w.length >= 3 && !stopWords.has(w));

      const uniqueTokens = new Set(tokens);
      sourceKeywordMap.set(src.id, uniqueTokens);

      uniqueTokens.forEach((tok) => {
        keywordGlobalFrequency.set(tok, (keywordGlobalFrequency.get(tok) || 0) + 1);
      });
    });

    // 2. Discover pairwise Cross-Source Citation Connections
    const conns: CitationConnection[] = [];
    for (let i = 0; i < sources.length; i++) {
      for (let j = i + 1; j < sources.length; j++) {
        const sA = sources[i];
        const sB = sources[j];
        const keysA = sourceKeywordMap.get(sA.id) || new Set();
        const keysB = sourceKeywordMap.get(sB.id) || new Set();

        const shared: string[] = [];
        keysA.forEach((k) => {
          if (keysB.has(k) && (keywordGlobalFrequency.get(k) || 0) < sources.length * 0.9) {
            shared.push(k);
          }
        });

        // Check if one source mentions the other source title
        const mentionsTitle =
          sA.content.toLowerCase().includes(sB.title.toLowerCase().slice(0, 15)) ||
          sB.content.toLowerCase().includes(sA.title.toLowerCase().slice(0, 15));

        const strength = shared.length + (mentionsTitle ? 5 : 0);
        if (strength > 0) {
          conns.push({
            sourceAId: sA.id,
            sourceBId: sB.id,
            sourceATitle: sA.title,
            sourceBTitle: sB.title,
            sharedKeywords: shared.slice(0, 6),
            connectionStrength: strength,
          });
        }
      }
    }

    // Sort connections by strength
    conns.sort((a, b) => b.connectionStrength - a.connectionStrength);

    // 3. Compute Highly Cited Chunks (Chunks referenced or sharing core terminology with multiple sources)
    const scoredChunks: HighlyCitedChunk[] = chunks.map((chunk) => {
      const chunkTokens = (chunk.text || '')
        .toLowerCase()
        .replace(/[^\w\u0600-\u06FF\s]/g, ' ')
        .split(/\s+/)
        .filter((w) => w.length >= 3 && !stopWords.has(w));

      const chunkUniqueTokens = new Set(chunkTokens);
      let referencingSourcesCount = 0;
      let sharedTokenSum = 0;
      const keyConcepts: string[] = [];

      sources.forEach((otherSrc) => {
        if (otherSrc.id === chunk.sourceId) return;
        const otherTokens = sourceKeywordMap.get(otherSrc.id);
        if (!otherTokens) return;

        let overlap = 0;
        chunkUniqueTokens.forEach((t) => {
          if (otherTokens.has(t)) {
            overlap++;
            if (!keyConcepts.includes(t) && keyConcepts.length < 4) {
              keyConcepts.push(t);
            }
          }
        });

        if (overlap >= 2) {
          referencingSourcesCount++;
          sharedTokenSum += overlap;
        }
      });

      // Factor in definition indicators & formulas
      const hasDefinition = /هو|هي|تُعرف|يُعرّف|القانون|المعادلة|definition|theorem/i.test(chunk.text);
      const hasFormula = /\$|\\frac|=|\\sum/i.test(chunk.text);
      const definitionBonus = (hasDefinition ? 4 : 0) + (hasFormula ? 5 : 0);

      const citationScore = sharedTokenSum * 2 + referencingSourcesCount * 5 + definitionBonus;

      return {
        chunk,
        citationScore,
        referencingSourcesCount,
        keyConcepts,
      };
    });

    // Sort by citation score descending
    scoredChunks.sort((a, b) => b.citationScore - a.citationScore);

    const topKeywords = Array.from(keywordGlobalFrequency.entries())
      .filter(([_, count]) => count >= 2)
      .sort((a, b) => b[1] - a[1])
      .map(([k]) => k)
      .slice(0, 15);

    return {
      connections: conns,
      highlyCitedChunks: scoredChunks.slice(0, 12),
      globalKeywords: topKeywords,
    };
  }, [sources, chunks]);

  // Filtered Highly Cited Chunks
  const filteredChunks = useMemo(() => {
    return highlyCitedChunks.filter((item) => {
      const matchesSource = selectedSourceId === 'all' || item.chunk.sourceId === selectedSourceId;
      const matchesSearch = !searchFilter.trim() ||
        item.chunk.text.toLowerCase().includes(searchFilter.toLowerCase()) ||
        item.chunk.sourceTitle.toLowerCase().includes(searchFilter.toLowerCase()) ||
        item.keyConcepts.some((k) => k.toLowerCase().includes(searchFilter.toLowerCase()));
      return matchesSource && matchesSearch;
    });
  }, [highlyCitedChunks, selectedSourceId, searchFilter]);

  const handleCopyCitation = (item: HighlyCitedChunk) => {
    const citationText = `«${item.chunk.text.trim()}»\n— المصدر: ${item.chunk.sourceTitle} (صفحة ${item.chunk.pageNumber || 1}) [شبكة الاستشهادات الأكاديمية D.CORE]`;
    navigator.clipboard.writeText(citationText);
    setCopiedChunkId(item.chunk.id);
    setTimeout(() => setCopiedChunkId(null), 2000);
  };

  if (sources.length < 2) {
    return (
      <div className="bg-white dark:bg-[#14201c] rounded-2xl p-8 border border-dashed border-[#e2e8e5] dark:border-[#22352f] text-center space-y-3">
        <div className="w-12 h-12 rounded-2xl bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center mx-auto shadow-xs">
          <Share2 className="w-6 h-6" />
        </div>
        <h3 className="font-bold text-sm text-[#17201e] dark:text-[#eef7f4]">
          مستكشف الاستشهادات والروابط المعرفية (Citation Explorer)
        </h3>
        <p className="text-xs text-[#596762] dark:text-[#9ab3ab] max-w-md mx-auto leading-relaxed">
          يتطلب بناء شبكة الاستشهادات والروابط المعرفية إضافة مصدرين على الأقل في هذا الدفتر. أضف كتباً أو ملازم أو مقالات لتقوم الخوارزمية باكتشاف الروابط والتقاطعات المعرفية تلقائياً.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-teal-900 via-[#0f766e] to-teal-800 rounded-3xl p-5 sm:p-6 text-white shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1.5">
          <div className="flex items-center gap-2">
            <span className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center text-amber-300">
              <Share2 className="w-4 h-4" />
            </span>
            <span className="text-[11px] font-bold uppercase tracking-wider text-teal-200">
              Cross-Source Citation & Knowledge Graph
            </span>
          </div>
          <h2 className="text-lg sm:text-xl font-black">
            مستكشف الاستشهادات والروابط المعرفية المتبادلة
          </h2>
          <p className="text-xs text-teal-100 max-w-2xl leading-relaxed">
            يحلل هذا النظام المتقدم تقاطعات المفاهيم والروابط الاستشهادية بين مراجعك المختلفة، ويحدد الفقرات الأكثر تأثيراً واعتماداً لتسهيل البحث العلمي والتوثيق الأكاديمي.
          </p>
        </div>

        {/* Global Stats */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="px-3.5 py-2 rounded-2xl bg-white/10 backdrop-blur-xs border border-white/15 text-center">
            <span className="text-lg font-black block font-mono">{connections.length}</span>
            <span className="text-[10px] text-teal-200">روابط مشتركة</span>
          </div>
          <div className="px-3.5 py-2 rounded-2xl bg-white/10 backdrop-blur-xs border border-white/15 text-center">
            <span className="text-lg font-black block font-mono text-amber-300">{highlyCitedChunks.length}</span>
            <span className="text-[10px] text-teal-200">فقرات عالية الاستشهاد</span>
          </div>
        </div>
      </div>

      {/* Cross-Source Reference Network Matrix */}
      <div className="bg-white dark:bg-[#14201c] rounded-2xl border border-[#e2e8e5] dark:border-[#22352f] p-5 space-y-4 shadow-xs">
        <div className="flex items-center justify-between pb-3 border-b border-[#e2e8e5] dark:border-[#22352f]">
          <div className="flex items-center gap-2">
            <Link2 className="w-4 h-4 text-teal-600 dark:text-teal-400" />
            <h3 className="font-bold text-sm text-[#17201e] dark:text-[#eef7f4]">
              شبكة الروابط الاستشهادية المتقاطعة بين المصادر ({connections.length})
            </h3>
          </div>
          <span className="text-[11px] text-[#596762] dark:text-[#9ab3ab] font-medium">
            روابط دلالية ومفاهيم مشتركة
          </span>
        </div>

        {/* Connection Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {connections.map((conn, idx) => (
            <div
              key={`${conn.sourceAId}_${conn.sourceBId}_${idx}`}
              className="p-3.5 rounded-xl bg-[#f8fbfa] dark:bg-[#1a2723] border border-[#e2e8e5] dark:border-[#22352f] hover:border-teal-500 transition-all space-y-2.5 shadow-2xs group"
            >
              <div className="flex items-center justify-between text-[11px] font-bold">
                <span className="text-teal-800 dark:text-teal-300 truncate max-w-[45%]" title={conn.sourceATitle}>
                  {conn.sourceATitle}
                </span>
                <span className="px-1.5 py-0.5 rounded-full bg-teal-100 dark:bg-teal-900/60 text-teal-700 dark:text-teal-300 text-[10px] font-mono">
                  ↔ قوة {conn.connectionStrength}
                </span>
                <span className="text-teal-800 dark:text-teal-300 truncate max-w-[45%]" title={conn.sourceBTitle}>
                  {conn.sourceBTitle}
                </span>
              </div>

              {conn.sharedKeywords.length > 0 && (
                <div className="flex flex-wrap items-center gap-1">
                  {conn.sharedKeywords.map((kw) => (
                    <span
                      key={kw}
                      className="text-[9px] px-1.5 py-0.5 rounded bg-white dark:bg-[#14201c] border border-gray-200 dark:border-gray-800 text-gray-600 dark:text-gray-300 font-medium"
                    >
                      #{kw}
                    </span>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Highly Cited Chunks Section */}
      <div className="bg-white dark:bg-[#14201c] rounded-2xl border border-[#e2e8e5] dark:border-[#22352f] p-5 space-y-4 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#e2e8e5] dark:border-[#22352f]">
          <div className="flex items-center gap-2">
            <Award className="w-4 h-4 text-amber-500" />
            <h3 className="font-bold text-sm text-[#17201e] dark:text-[#eef7f4]">
              الفقرات الأكثر استشهاداً وتأثيراً في أبحاث الدفتر (Highly Cited Chunks)
            </h3>
          </div>

          {/* Filters & Source Filter */}
          <div className="flex items-center gap-2 flex-wrap">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-gray-400 absolute right-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchFilter}
                onChange={(e) => setSearchFilter(e.target.value)}
                placeholder="بحث في الاستشهادات..."
                className="pr-8 pl-3 py-1 text-xs rounded-xl bg-[#f8fbfa] dark:bg-[#1a2723] border border-gray-200 dark:border-gray-800 text-[#17201e] dark:text-[#eef7f4] outline-none"
              />
            </div>

            <div className="flex items-center gap-1 text-xs">
              <span className="text-gray-500">المصدر:</span>
              <select
                value={selectedSourceId}
                onChange={(e) => setSelectedSourceId(e.target.value)}
                className="px-2 py-1 text-xs rounded-xl bg-[#f8fbfa] dark:bg-[#1a2723] border border-gray-200 dark:border-gray-800 text-[#17201e] dark:text-[#eef7f4] outline-none font-bold"
              >
                <option value="all">كافة المصادر</option>
                {sources.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.title}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Highly Cited Chunks List */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredChunks.map((item) => (
            <div
              key={item.chunk.id}
              className="p-4 rounded-2xl bg-[#f8fbfa] dark:bg-[#1a2723] border border-teal-500/30 hover:border-teal-500 transition-all flex flex-col justify-between space-y-3 shadow-2xs group"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5">
                    <span className="px-2 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 font-bold text-[10px] flex items-center gap-1 border border-amber-300/60 dark:border-amber-800/60">
                      <TrendingUp className="w-3 h-3 text-amber-600" />
                      <span>مرتبة استشهاد: {item.citationScore}</span>
                    </span>
                    <span className="text-[10px] text-gray-500">
                      مستشهد به في {item.referencingSourcesCount} مراجع أخرى
                    </span>
                  </div>

                  <span className="text-[10px] font-mono text-teal-700 dark:text-teal-300 font-bold">
                    صـ {item.chunk.pageNumber || 1}
                  </span>
                </div>

                <h4 className="font-bold text-xs text-[#17201e] dark:text-[#eef7f4] flex items-center gap-1 text-teal-700 dark:text-teal-300">
                  <BookOpen className="w-3.5 h-3.5" />
                  <span>{item.chunk.sourceTitle}</span>
                </h4>

                <p className="text-xs text-[#2e3e38] dark:text-[#d3e5df] line-clamp-4 leading-relaxed font-serif bg-white/70 dark:bg-black/20 p-2.5 rounded-xl border border-gray-200/50 dark:border-gray-800/50">
                  {item.chunk.text}
                </p>

                {item.keyConcepts.length > 0 && (
                  <div className="flex flex-wrap items-center gap-1 pt-1">
                    {item.keyConcepts.map((concept) => (
                      <span
                        key={concept}
                        className="text-[9px] px-1.5 py-0.2 rounded bg-teal-50 dark:bg-teal-950 text-teal-700 dark:text-teal-300 font-bold"
                      >
                        {concept}
                      </span>
                    ))}
                  </div>
                )}
              </div>

              {/* Action Toolbar */}
              <div className="flex items-center justify-between pt-2 border-t border-gray-200/60 dark:border-gray-800/60 text-xs font-bold text-teal-700 dark:text-teal-400">
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => handleCopyCitation(item)}
                    className="p-1 rounded-lg hover:bg-white dark:hover:bg-black/40 text-gray-600 dark:text-gray-300 transition-colors flex items-center gap-1 cursor-pointer text-[11px]"
                    title="نسخ الاستشهاد الأكاديمي مع المرجع"
                  >
                    {copiedChunkId === item.chunk.id ? (
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                    <span>{copiedChunkId === item.chunk.id ? 'تم النسخ' : 'نسخ الاستشهاد'}</span>
                  </button>

                  {onExportToNote && (
                    <button
                      type="button"
                      onClick={() => onExportToNote(`استشهاد: ${item.chunk.sourceTitle}`, item.chunk.text)}
                      className="p-1 rounded-lg hover:bg-white dark:hover:bg-black/40 text-gray-600 dark:text-gray-300 transition-colors flex items-center gap-1 cursor-pointer text-[11px]"
                      title="حفظ الاستشهاد في تدوينات الدفتر"
                    >
                      <FileText className="w-3.5 h-3.5" />
                      <span>حفظ كتدوينة</span>
                    </button>
                  )}
                </div>

                {onAskAboutChunk && (
                  <button
                    type="button"
                    onClick={() => onAskAboutChunk(item.chunk.text, item.chunk.pageNumber || 1)}
                    className="px-2 py-1 rounded-lg bg-teal-600 text-white hover:bg-teal-700 transition-colors flex items-center gap-1 text-[11px] cursor-pointer"
                  >
                    <Sparkles className="w-3 h-3 text-amber-300" />
                    <span>تحليل بالذكاء الاصطناعي</span>
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
