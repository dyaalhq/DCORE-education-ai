import React, { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';
import rehypeRaw from 'rehype-raw';
import { InlineMath, BlockMath } from 'react-katex';
import { Copy, Check, Sigma } from 'lucide-react';
import { Citation } from '../types';
import { InteractiveChatQuiz } from './InteractiveChatQuiz';
import { ChatEmbeddedMindMap } from './ChatEmbeddedMindMap';

interface EducationalContentProps {
  content: string;
  className?: string;
  isStreaming?: boolean;
  citations?: Citation[];
  onCitationClick?: (citation: Citation) => void;
}

/**
 * Converts chemical notation (e.g. \ce{N2(g) + 3H2(g) <=> 2NH3(g)} or \ce{H3O+})
 * into standard KaTeX-compatible expressions with \text{...}, \rightleftharpoons, and subscripts.
 */
export function convertCeToStandardLatex(expr: string): string {
  if (!expr) return '';
  let str = expr;

  // 1. Handle bracketed ions e.g. [ \ce{H3O+} ] or [\ce{H3O+}] or [ \ce{H+} ]
  str = str.replace(/\[\s*(?:\\?ce\{)?H3O\+\}?\s*\]/g, '\\left[\\text{H}_3\\text{O}^+\\right]');
  str = str.replace(/\[\s*(?:\\?ce\{)?H\+\}?\s*\]/g, '\\left[\\text{H}^+\\right]');
  str = str.replace(/\[\s*(?:\\?ce\{)?OH-\}?\s*\]/g, '\\left[\\text{OH}^-\\right]');

  // 2. Transform \ce{...} or ce{...} directly into clean KaTeX without wrapping in $
  str = str.replace(/\\?ce\{([^{}]+)\}/g, (_m, inner) => {
    let chem = inner;
    chem = chem.replace(/<=>|⇌/g, ' \\rightleftharpoons ');
    chem = chem.replace(/<->/g, ' \\leftrightarrow ');
    chem = chem.replace(/->|→/g, ' \\rightarrow ');
    chem = chem.replace(/\+\s*(?:Heat|heat|حرارة)/gi, '+ \\text{حرارة}');
    chem = chem.replace(/\bH3O\+/g, '\\text{H}_3\\text{O}^+');
    chem = chem.replace(/\bH\+/g, '\\text{H}^+');
    chem = chem.replace(/\bOH-/g, '\\text{OH}^-');
    chem = chem.replace(/\bN2\(g\)/g, '\\text{N}_{2(g)}');
    chem = chem.replace(/\b3H2\(g\)/g, '3\\text{H}_{2(g)}');
    chem = chem.replace(/\bH2\(g\)/g, '\\text{H}_{2(g)}');
    chem = chem.replace(/\b2NH3\(g\)/g, '2\\text{NH}_{3(g)}');
    chem = chem.replace(/\bNH3\(g\)/g, '\\text{NH}_{3(g)}');
    chem = chem.replace(/\bNH3\b/g, '\\text{NH}_3');
    chem = chem.replace(/\bN2\b/g, '\\text{N}_2');
    chem = chem.replace(/\bH2\b/g, '\\text{H}_2');
    chem = chem.replace(/\bHCl\b/g, '\\text{HCl}');
    chem = chem.replace(/\bNaCl\b/g, '\\text{NaCl}');
    chem = chem.replace(/\bH2O\b/g, '\\text{H}_2\\text{O}');
    chem = chem.replace(/\bCO2\b/g, '\\text{CO}_2');
    chem = chem.replace(/\bO2\b/g, '\\text{O}_2');
    chem = chem.replace(/\bCH3COOH\b/g, '\\text{CH}_3\\text{COOH}');
    chem = chem.replace(/\bCH3COONa\b/g, '\\text{CH}_3\\text{COONa}');
    chem = chem.replace(/\bCH3CH2OH\b/g, '\\text{CH}_3\\text{CH}_2\\text{OH}');
    chem = chem.replace(/\bZn\^\{?2\+?\}?\/Zn\b/g, '\\text{Zn}^{2+}/\\text{Zn}');
    chem = chem.replace(/\bAg\^\{?\+?\}?\/Ag\b/g, '\\text{Ag}^+/\\text{Ag}');
    return chem.trim();
  });

  // Standalone equilibrium & reaction arrows
  str = str.replace(/<=>|⇌/g, ' \\rightleftharpoons ');
  str = str.replace(/<->/g, ' \\leftrightarrow ');
  str = str.replace(/->|→/g, ' \\rightarrow ');

  return str;
}

/**
 * Normalizes mathematical characters and wraps any unwrapped Arabic letters or words in \text{...}
 * so KaTeX never crashes or throws parse errors when encountering Arabic variables or symbols.
 */
export function ensureKatexArabicWrapped(math: string): string {
  if (!math) return '';

  let m = math.trim();

  // Strip outer delimiters ($ ... $ or $$ ... $$) because KaTeX InlineMath/BlockMath expect pure formula content
  while ((m.startsWith('$$') && m.endsWith('$$') && m.length >= 4) || (m.startsWith('$') && m.endsWith('$') && m.length >= 2)) {
    if (m.startsWith('$$') && m.endsWith('$$')) {
      m = m.slice(2, -2).trim();
    } else if (m.startsWith('$') && m.endsWith('$')) {
      m = m.slice(1, -1).trim();
    }
  }

  // Convert chemical formulas \ce{...} to native KaTeX
  m = convertCeToStandardLatex(m);

  // Strip all unescaped dollar signs from inside KaTeX formulas
  m = m.replace(/(?<!\\)\$/g, '').trim();

  // 0. Normalize double/triple backslashes before LaTeX keywords (\\lim -> \lim, \\frac -> \frac)
  m = m.replace(
    /\\{2,}(lim|to|frac|dfrac|tfrac|sqrt|int|iint|iiint|sum|prod|sin|cos|tan|cot|sec|csc|arcsin|arccos|arctan|log|ln|exp|det|vec|hat|bar|dot|ddot|tilde|mathbf|mathit|mathrm|mathbb|mathcal|text|pm|times|div|cdot|rightarrow|leftarrow|Rightarrow|Leftarrow|Leftrightarrow|iff|approx|neq|le|ge|leq|geq|in|notin|subset|subseteq|cup|cap|Delta|delta|theta|alpha|beta|gamma|lambda|mu|pi|sigma|phi|omega|Omega|infty|partial|nabla|degree|circ|left|right|begin|end|quad|qquad|rightleftharpoons)\b/g,
    '\\$1'
  );
  m = m.replace(/\\{2,}([_\^])/g, '$1');

  // Convert Eastern Arabic / Persian digits to standard ASCII digits in math
  m = m.replace(/[٠-٩]/g, (d) => '٠١٢٣٤٥٦٧٨٩'.indexOf(d).toString());

  // 1. Remove non-printable / corrupt unicode artifacts
  m = m
    .replace(/[\uFFFD\u0000-\u0008\u000B\u000C\u000E-\u001F\uFEFF]/g, '')
    .replace(/[÷]/g, ' \\div ')
    .replace(/[×]/g, ' \\times ')
    .replace(/[±]/g, ' \\pm ')
    .replace(/[°]/g, '^\\circ ')
    .replace(/[∆Δ]/g, '\\Delta ')
    .replace(/[²]/g, '^2')
    .replace(/[³]/g, '^3')
    .replace(/[√]/g, '\\sqrt')
    .replace(/[∞]/g, '\\infty')
    .replace(/[≠]/g, '\\neq')
    .replace(/[≤]/g, '\\le')
    .replace(/[≥]/g, '\\ge')
    .replace(/[≈]/g, '\\approx')
    .replace(/[∑]/g, '\\sum ')
    .replace(/[∏]/g, '\\prod ')
    .replace(/[∫]/g, '\\int ')
    .replace(/[∂]/g, '\\partial ')
    .replace(/[∇]/g, '\\nabla ');

  // Common Greek letters
  m = m
    .replace(/α/g, '\\alpha ')
    .replace(/β/g, '\\beta ')
    .replace(/γ/g, '\\gamma ')
    .replace(/θ/g, '\\theta ')
    .replace(/λ/g, '\\lambda ')
    .replace(/μ/g, '\\mu ')
    .replace(/π/g, '\\pi ')
    .replace(/σ/g, '\\sigma ')
    .replace(/ω/g, '\\omega ')
    .replace(/Ω/g, '\\Omega ')
    .replace(/φ/g, '\\phi ')
    .replace(/ε/g, '\\epsilon ');

  // Arabic trigonometric & math abbreviations inside math mode
  m = m
    .replace(/(?<![a-zA-Z\\])جا(?![a-zA-Z])/g, '\\sin ')
    .replace(/(?<![a-zA-Z\\])جتا(?![a-zA-Z])/g, '\\cos ')
    .replace(/(?<![a-zA-Z\\])ظا(?![a-zA-Z])/g, '\\tan ')
    .replace(/(?<![a-zA-Z\\])ظتا(?![a-zA-Z])/g, '\\cot ')
    .replace(/(?<![a-zA-Z\\])قا(?![a-zA-Z])/g, '\\sec ')
    .replace(/(?<![a-zA-Z\\])قتا(?![a-zA-Z])/g, '\\csc ')
    .replace(/(?<![a-zA-Z\\])لو(?![a-zA-Z])/g, '\\log ')
    .replace(/(?<![a-zA-Z\\])(?:نها|نهـا)(?![a-zA-Z])/g, '\\lim ');

  // 2. Escape percentage signs that are not already escaped so KaTeX doesn't treat them as comments
  m = m.replace(/(?<!\\)%/g, '\\%');

  // Protect stray hashes
  m = m.replace(/(?<!\\)#/g, '\\#');

  // Protect stray ampersands outside of \begin{...} ... \end{...}
  if (!/\\begin\{(?:aligned|matrix|pmatrix|bmatrix|cases|gather|equation)/.test(m)) {
    m = m.replace(/(?<!\\)&/g, '\\&');
  }

  // 3. Handle Arabic subscripts and superscripts specifically (e.g. ع_1, ع_2, ط_ح, ط_و, ك_ت, د_0)
  m = m.replace(/_([\u0600-\u06FF0-9]+)/g, '_{\\text{$1}}');
  m = m.replace(/\^([\u0600-\u06FF0-9]+)/g, '^{\\text{$1}}');

  // 4. Wrap any Arabic characters or words that are NOT already enclosed in \text{...}
  m = m.replace(/(\\text\{[^{}]*\})|([\u0600-\u06FF]+(?:\s+[\u0600-\u06FF]+)*)/g, (match, textBlock, arabicText) => {
    if (textBlock) return textBlock;
    if (arabicText) {
      return `\\text{${arabicText.trim()}}`;
    }
    return match;
  });

  // 5. Clean up any accidental nested \text{\text{...}} from multi-passes
  m = m.replace(/\\text\{\\text\{([^{}]+)\}\}/g, '\\text{$1}');

  // 6. Balance unmatched \left and \right delimiters
  const leftMatches = m.match(/\\left\b/g) || [];
  const rightMatches = m.match(/\\right\b/g) || [];
  if (leftMatches.length > rightMatches.length) {
    const diff = leftMatches.length - rightMatches.length;
    for (let i = 0; i < diff; i++) {
      m += ' \\right.';
    }
  }

  // 7. Balance unclosed curly braces { ... }
  let openBraces = 0;
  let closeBraces = 0;
  for (let i = 0; i < m.length; i++) {
    if (m[i] === '{' && (i === 0 || m[i - 1] !== '\\')) openBraces++;
    if (m[i] === '}' && (i === 0 || m[i - 1] !== '\\')) closeBraces++;
  }
  if (openBraces > closeBraces) {
    m += '}'.repeat(openBraces - closeBraces);
  }

  return m;
}

/**
 * Safe Block Math Renderer using react-katex with error fallback & Copy LaTeX tool
 */
export const SafeBlockMath: React.FC<{ math: string; className?: string }> = ({ math, className = '' }) => {
  const [copied, setCopied] = useState(false);
  const cleanMath = React.useMemo(() => ensureKatexArabicWrapped(math), [math]);

  const handleCopy = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(cleanMath);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div dir="ltr" className={`group relative my-2.5 w-full max-w-full min-w-0 overflow-x-auto text-center py-2 px-3 rounded-xl bg-teal-500/5 dark:bg-teal-400/5 border border-teal-500/20 dark:border-teal-400/20 shadow-xs hover:border-teal-500/40 transition-colors ${className}`}>
      <div className="absolute top-1.5 left-2 opacity-0 group-hover:opacity-100 transition-opacity no-print">
        <button
          type="button"
          onClick={handleCopy}
          className="px-2 py-0.5 rounded-md text-[10px] font-mono font-bold bg-white/90 dark:bg-slate-800/90 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-800 shadow-2xs hover:bg-teal-600 hover:text-white transition-all cursor-pointer flex items-center gap-1"
          title="نسخ كود LaTeX"
        >
          {copied ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
          <span>{copied ? 'تم النسخ' : 'LaTeX'}</span>
        </button>
      </div>
      <BlockMath
        math={cleanMath}
        errorColor="#ef4444"
        renderError={() => (
          <span className="text-teal-700 dark:text-teal-300 font-serif text-sm font-bold block dir-rtl text-center py-1">
            {math}
          </span>
        )}
      />
    </div>
  );
};

/**
 * Safe Inline Math Renderer using react-katex with error fallback
 * Cleanly integrated into sentence flow without bulky boxes or awkward borders.
 */
export const SafeInlineMath: React.FC<{ math: string; className?: string }> = ({ math, className = '' }) => {
  const cleanMath = React.useMemo(() => {
    let m = ensureKatexArabicWrapped(math);
    // If formula contains \lim, \int, or \sum and doesn't already have \displaystyle, prepend \displaystyle
    if (/(?:\\lim|\\int|\\sum|\\prod)\b/.test(m) && !m.includes('\\displaystyle')) {
      m = `\\displaystyle ${m}`;
    }
    return m;
  }, [math]);

  const hasArabic = React.useMemo(() => /[\u0600-\u06FF]/.test(cleanMath), [cleanMath]);

  return (
    <span
      dir={hasArabic ? 'rtl' : 'ltr'}
      className={`inline-block mx-0.5 font-normal text-teal-900 dark:text-teal-100 align-baseline leading-normal ${className}`}
      style={{ unicodeBidi: 'isolate' }}
    >
      <InlineMath
        math={cleanMath}
        errorColor="#ef4444"
        renderError={() => (
          <span className="text-teal-700 dark:text-teal-300 font-serif text-xs font-bold px-0.5" dir="rtl">{math}</span>
        )}
      />
    </span>
  );
};

/**
 * Normalizes mathematical, chemical, and curriculum notation output by AI:
 * - Converts LaTeX brackets \[ ... \] and \( ... \) to $$ and $.
 * - Detects and wraps complex matrix, aligned, cases blocks in $$.
 * - Sanitizes asterisks (*) to \cdot / \times inside formulas to prevent markdown italics.
 * - Wraps bare Arabic variables in \text{...} so KaTeX renders them pristinely.
 * - Protects square brackets ([...]) in chemical complexes/concentrations to prevent markdown link collisions.
 * - Formats chemical equilibrium equations, reaction arrows, and ionic notation cleanly.
 * - Supports Arabic curriculum laws (e.g., ع = ف / ز, ق = ك * جـ, ش = ق * ف).
 */
export function preprocessEducationalText(rawText: string): string {
  if (!rawText) return '';

  let text = rawText;

  // 1. Convert display math \[ ... \] to $$ ... $$
  text = text.replace(/\\\[([\s\S]*?)\\\]/g, (_match, eq) => `\n\n$$\n${eq.trim()}\n$$\n\n`);

  // 2. Convert inline math \( ... \) to $ ... $
  text = text.replace(/\\\(([\s\S]*?)\\\)/g, (_match, eq) => `$${eq.trim()}$`);

  // 3. Convert multi-line LaTeX environments (\begin{aligned}, \begin{cases}, \begin{matrix}, etc.)
  text = text.replace(
    /(?<!\$\$)\s*(\\begin\{(?:aligned|matrix|pmatrix|bmatrix|vmatrix|cases|gather|equation)\*?\}[\s\S]*?\\end\{(?:aligned|matrix|pmatrix|bmatrix|vmatrix|cases|gather|equation)\*?\})\s*(?!\$\$)/g,
    '\n\n$$\n$1\n$$\n\n'
  );

  // 4. Convert \ce{...} chemical equations if used outside math blocks into standard LaTeX
  text = text.replace(/\\ce\{([^}]+)\}/g, (_match, inner) => `$${convertCeToStandardLatex(inner)}$`);

  // 5. Sanitize asterisks (*) and wrap Arabic in existing $$ ... $$ display math blocks
  text = text.replace(/\$\$([\s\S]*?)\$\$/g, (_match, mathContent) => {
    let sanitizedMath = mathContent
      .replace(/([0-9a-zA-Z\)\}])\s*\*\s*([0-9a-zA-Z\(\{])/g, '$1 \\cdot $2')
      .replace(/(?<=\s)\*(?=\s)/g, '\\cdot ')
      .replace(/\\times\s*\*/g, '\\times');
    sanitizedMath = ensureKatexArabicWrapped(sanitizedMath);
    return `\n\n$$\n${sanitizedMath.trim()}\n$$\n\n`;
  });

  // 6. Sanitize asterisks (*) and wrap Arabic in existing $ ... $ inline math blocks
  text = text.replace(/(?<!\$)\$([^\$\n]+)\$(?!\$)/g, (_match, mathContent) => {
    let sanitizedMath = mathContent
      .replace(/([0-9a-zA-Z\)\}])\s*\*\s*([0-9a-zA-Z\(\{])/g, '$1 \\cdot $2')
      .replace(/(?<=\s)\*(?=\s)/g, '\\cdot ');
    sanitizedMath = ensureKatexArabicWrapped(sanitizedMath);
    return `$${sanitizedMath}$`;
  });

  // 7. Detect chemical equilibrium and concentration brackets outside math blocks
  // e.g. [H+], [OH-], [H3O+], [Ca2+], [Cl-], [Fe(CN)6]4-, [Cu(NH3)4]2+, [A], [B], [C]
  // and equilibrium formulas like Kc = [C]^c [D]^d / [A]^a [B]^b, Kw = [H+][OH-]
  text = text.replace(
    /(?:K[capw]|pH|pOH)\s*=\s*[^.\n]+/g,
    (match) => {
      if (match.includes('$')) return match;
      const clean = match
        .replace(/\[\s*H\+\s*\]/g, '\\left[\\text{H}^+\\right]')
        .replace(/\[\s*OH-\s*\]/g, '\\left[\\text{OH}^-\\right]')
        .replace(/\[\s*H3O\+\s*\]/g, '\\left[\\text{H}_3\\text{O}^+\\right]')
        .replace(/\s*\*\s*/g, ' \\times ')
        .replace(/10\^(-?[0-9]+)/g, '10^{$1}');
      return `$${clean}$`;
    }
  );

  // Wrap isolated chemical concentration brackets so Markdown doesn't confuse with links
  text = text.replace(
    /(?<![\$\[])(\[(?:H\+|OH-|H3O\+|Ca2\+|Cl-|Na\+|K\+|SO4\^?2?-?|NO3-?|Fe\(CN\)6|Cu\(NH3\)4|[A-D])\](?:\^\{?[0-9\+\-]+?\}?)?)(?![\$\]\(\[])/gi,
    (_match, formula) => {
      const cleanFormula = formula
        .replace(/\[H\+\]/g, '\\left[\\text{H}^+\\right]')
        .replace(/\[OH-\]/g, '\\left[\\text{OH}^-\\right]')
        .replace(/\[H3O\+\]/g, '\\left[\\text{H}_3\\text{O}^+\\right]');
      return `$${cleanFormula}$`;
    }
  );

  // 8. Detect scientific notation multiplication e.g., 3 * 10^8 or 6.022 * 10^23 or 1.6 * 10^-19
  text = text.replace(
    /(?<![\$\w])([0-9]+(?:\.[0-9]+)?)\s*\*\s*10\^([+-]?[0-9]+)(?![\$\w])/g,
    (_match, coefficient, exponent) => `$${coefficient} \\times 10^{${exponent}}$`
  );

  // 9. Detect standalone chemical reactions with arrows (->, -->, →, <=>, ⇌, \rightleftharpoons)
  text = text.replace(
    /(?:^|\n)([ \t]*(?:[-*•]\s*(?:\*\*[^*]+\*\*:\s*)?)?)(([0-9]*\s*[A-Z][a-z]?[0-9]*(?:_\{?[0-9a-z]+\}?)?(?:\([a-z]+\))?(?:\s*[\+]\s*[0-9]*\s*[A-Z][a-z]?[0-9]*(?:_\{?[0-9a-z]+\}?)?(?:\([a-z]+\))?)*)\s*(?:->|-->|→|<=>|⇌|\\rightleftharpoons)\s*([0-9]*\s*[A-Z][a-z]?[0-9]*(?:_\{?[0-9a-z]+\}?)?(?:\([a-z]+\))?(?:\s*[\+]\s*[0-9]*\s*[A-Z][a-z]?[0-9]*(?:_\{?[0-9a-z]+\}?)?(?:\([a-z]+\))?)*))(?=\n|$)/g,
    (_match, prefix, _full, react, prod) => {
      const cleanPrefix = prefix || '';
      const r = react.trim();
      const p = prod.trim();
      return `\n${cleanPrefix}\n$$\\ce{${r} -> ${p}}$$\n`;
    }
  );

  // 10. Detect common Arabic curriculum laws and equations and convert directly to pristine LaTeX
  // e.g. ع = ف / ز or ق = ك * جـ or ش = ق * ف or ط ح = 0.5 * ك * ع^2
  text = text.replace(
    /(?:^|\n)([ \t]*(?:[-*•]\s*)?)(ع\s*=\s*ف\s*[\/÷]\s*ز|جـ\s*=\s*\(?\s*ع[₂2]\s*-\s*ع[₁1]\s*\)?\s*[\/÷]\s*ز|ق\s*=\s*ك\s*[\*×]\s*جـ|ش\s*=\s*ق\s*[\*×]\s*ف|ط\s*ح\s*=\s*(?:½|0\.5)\s*[\*×]\s*ك\s*[\*×]\s*ع(?:\^2|²)|ط\s*و\s*=\s*ك\s*[\*×]\s*جـ\s*[\*×]\s*ف|جـ\s*=\s*م\s*[\*×]\s*ت|ت\s*=\s*ش\s*[\/÷]\s*ز|ض\s*=\s*ق\s*[\/÷]\s*س|ث\s*=\s*ك\s*[\/÷]\s*ح|ك_ت\s*=\s*ك\s*[\*×]\s*ع)(?=\n|$)/g,
    (_match, prefix, law) => {
      let latexLaw = '';
      if (/ع\s*=\s*ف/i.test(law)) {
        latexLaw = '\\text{قانون السرعة: } \\text{ع} = \\frac{\\text{ف}}{\\text{ز}} \\quad \\Longleftrightarrow \\quad v = \\frac{d}{t}';
      } else if (/جـ\s*=\s*\(?\s*ع/i.test(law)) {
        latexLaw = '\\text{قانون العجلة (التسارع): } \\text{جـ} = \\frac{\\text{ع}_2 - \\text{ع}_1}{\\text{ز}} \\quad \\Longleftrightarrow \\quad a = \\frac{\\Delta v}{\\Delta t}';
      } else if (/ق\s*=\s*ك/i.test(law)) {
        latexLaw = '\\text{قانون نيوتن الثاني: } \\text{ق} = \\text{ك} \\cdot \\text{جـ} \\quad \\Longleftrightarrow \\quad F = m \\cdot a';
      } else if (/ش\s*=\s*ق/i.test(law)) {
        latexLaw = '\\text{قانون الشغل: } \\text{ش} = \\text{ق} \\cdot \\text{ف} \\quad \\Longleftrightarrow \\quad W = F \\cdot d';
      } else if (/ط\s*ح/i.test(law)) {
        latexLaw = '\\text{طاقة الحركة: } \\text{ط}_{\\text{ح}} = \\frac{1}{2} \\text{ك} \\cdot \\text{ع}^2 \\quad \\Longleftrightarrow \\quad KE = \\frac{1}{2} m v^2';
      } else if (/ط\s*و/i.test(law)) {
        latexLaw = '\\text{طاقة الوضع (الجاذبية): } \\text{ط}_{\\text{و}} = \\text{ك} \\cdot \\text{جـ} \\cdot \\text{ف} \\quad \\Longleftrightarrow \\quad PE = m \\cdot g \\cdot h';
      } else if (/جـ\s*=\s*م/i.test(law)) {
        latexLaw = '\\text{قانون أوم (الجهد): } \\text{جـ} = \\text{م} \\cdot \\text{ت} \\quad \\Longleftrightarrow \\quad V = I \\cdot R';
      } else if (/ت\s*=\s*ش/i.test(law)) {
        latexLaw = '\\text{شدة التيار: } \\text{ت} = \\frac{\\text{ش}}{\\text{ز}} \\quad \\Longleftrightarrow \\quad I = \\frac{Q}{t}';
      } else if (/ض\s*=\s*ق/i.test(law)) {
        latexLaw = '\\text{الضغط: } \\text{ض} = \\frac{\\text{ق}}{\\text{س}} \\quad \\Longleftrightarrow \\quad P = \\frac{F}{A}';
      } else if (/ث\s*=\s*ك/i.test(law)) {
        latexLaw = '\\text{الكثافة: } \\text{ث} = \\frac{\\text{ك}}{\\text{ح}} \\quad \\Longleftrightarrow \\quad \\rho = \\frac{m}{V}';
      } else {
        const formattedLaw = law.replace(/\*/g, ' \\cdot ').replace(/\//g, ' \\div ');
        latexLaw = `\\text{${formattedLaw.trim()}}`;
      }
      return `\n${prefix || ''}\n$$${latexLaw}$$\n`;
    }
  );

  // 11. Wrap complete un-delimited LaTeX fragments so commands never leak into visible text.
  text = text.replace(
    /(?<![\$\\])((?:\\(?:lim|frac|dfrac|tfrac|sqrt|int|iint|sum|prod|sin|cos|tan|cot|sec|csc|log|ln|Delta|theta|alpha|beta|gamma|lambda|pi|sigma|omega|Omega|infty|partial|nabla|approx|neq|pm|times|div|cdot|to|ce)\b(?:\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}|\[[^\[\]]*\]|\([^\(\)]*\)|[a-zA-Z0-9_\^\+\-\*\/\=\<\>\s\\\.])*(?:\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}|[a-zA-Z0-9_\^\+\-\*\/\=])))/g,
    (_match, fragment) => {
      const trimmed = fragment.trim();
      return trimmed ? `$${trimmed}$` : fragment;
    }
  );

  // 12. Detect common physics and math formulas with multiplication asterisks in text
  // e.g., F = m * a, E = m * c^2, a^2 + b^2 = c^2, v = v_0 + a * t, P * V = n * R * T, Q = m * c * \Delta T
  text = text.replace(
    /(?:^|\n)([ \t]*(?:[-*•]\s*(?:\*\*[^*]+\*\*:\s*)?)?)([A-Za-z_][A-Za-z0-9_]*\s*=\s*(?:[0-9a-zA-Z\(\)\/\+\-\^\._]+(?:\s*[\*\+\-\/\^]\s*[0-9a-zA-Z\(\)\/\+\-\^\._]+)+))(?=\n|$)/g,
    (_match, prefix, equation) => {
      const cleanEq = equation
        .replace(/\s*\*\s*/g, ' \\cdot ')
        .replace(/([0-9]+)\/([0-9]+)/g, '\\frac{$1}{$2}');
      return `\n${prefix || ''}\n$$${cleanEq.trim()}$$\n`;
    }
  );

  // 13. Consolidate adjacent $...$ expressions: safely using function replacer to prevent $$ literal bug
  text = text.replace(/\$\s*\$/g, '');
  text = text.replace(/\$([^\$\n]+)\$\s*\$([^\$\n]+)\$/g, (_match, p1, p2) => `$${p1} ${p2}$`);

  // 14. Final KaTeX integrity pass: sanitize all $$ and $ blocks ensuring all Arabic and symbols are pristinely wrapped
  text = text.replace(/\$\$([\s\S]*?)\$\$/g, (_match, mathBlock) => {
    return `\n\n$$\n${ensureKatexArabicWrapped(mathBlock.trim())}\n$$\n\n`;
  });

  text = text.replace(/(?<!\$)\$([^\$\n]+)\$(?!\$)/g, (_match, inlineMath) => {
    return `$${ensureKatexArabicWrapped(inlineMath.trim())}$`;
  });

  return text;
}

export const EducationalContent: React.FC<EducationalContentProps> = ({
  content,
  className = '',
  isStreaming = false,
  citations,
  onCitationClick,
}) => {
  let processed = preprocessEducationalText(content);

  // If citations exist and onCitationClick is provided, link in-text [1], [2], [مصدر 1]
  if (citations && citations.length > 0 && onCitationClick) {
    // Replace [1], [2], etc. (only when 1 <= n <= citations.length)
    processed = processed.replace(/\[(\d+)\]/g, (match, num) => {
      const idx = parseInt(num, 10);
      if (idx >= 1 && idx <= citations.length) {
        return `[✦ مرجع ${idx}](#citation-ref-${idx})`;
      }
      return match;
    });

    // Replace [مصدر 1], [مرجع 1]
    processed = processed.replace(/\[(?:مصدر|مرجع)\s*(\d+)\]/g, (match, num) => {
      const idx = parseInt(num, 10);
      if (idx >= 1 && idx <= citations.length) {
        return `[✦ مرجع ${idx}](#citation-ref-${idx})`;
      }
      return match;
    });
  }

  return (
    <div className={`educational-markdown leading-relaxed text-sm w-full max-w-full overflow-hidden break-words min-w-0 ${className}`} dir="rtl">
      <ReactMarkdown
        remarkPlugins={[remarkGfm, remarkMath]}
        rehypePlugins={[rehypeRaw, [rehypeKatex, { throwOnError: false, strict: 'ignore' }]]}
        components={{
          a: ({ href, children }) => {
            if (href?.startsWith('#citation-ref-')) {
              const idx = parseInt(href.replace('#citation-ref-', ''), 10) - 1;
              const cite = citations && citations[idx];
              return (
                <button
                  type="button"
                  onClick={(e) => {
                    e.preventDefault();
                    if (cite && onCitationClick) onCitationClick(cite);
                  }}
                  className="inline-flex items-center gap-0.5 px-1.5 py-0.5 mx-0.5 rounded-md bg-teal-50 dark:bg-teal-950/70 text-[#0f766e] dark:text-[#2dd4bf] border border-teal-200 dark:border-teal-800 text-[11px] font-bold hover:bg-[#0f766e] hover:text-white transition-all cursor-pointer shadow-2xs group"
                  title={cite ? `انقر للانتقال المباشر وتظليل وتكبير المصدر: ${cite.sourceTitle} (ص ${cite.pageNumber || 1})` : 'عرض المرجع'}
                >
                  <span className="font-mono">{children}</span>
                </button>
              );
            }
            return (
              <a
                href={href}
                target="_blank"
                rel="noopener noreferrer"
                className="text-teal-600 dark:text-teal-400 font-bold underline hover:text-teal-700 transition-colors"
              >
                {children}
              </a>
            );
          },
          h1: ({ children }) => (
            <h1 className="text-lg sm:text-xl font-black text-gray-900 dark:text-white mt-4 mb-2 pb-1.5 border-b border-gray-200 dark:border-gray-800 flex items-center gap-2">
              <span className="w-1.5 h-5 bg-teal-600 rounded-full inline-block"></span>
              {children}
            </h1>
          ),
          h2: ({ children }) => (
            <h2 className="text-base sm:text-lg font-bold text-gray-900 dark:text-white mt-3.5 mb-2 flex items-center gap-2">
              <span className="w-1 h-4 bg-emerald-600 rounded-full inline-block"></span>
              {children}
            </h2>
          ),
          h3: ({ children }) => (
            <h3 className="text-sm sm:text-base font-bold text-teal-800 dark:text-teal-300 mt-3 mb-1.5">
              {children}
            </h3>
          ),
          h4: ({ children }) => (
            <h4 className="text-xs sm:text-sm font-bold text-gray-800 dark:text-gray-200 mt-2.5 mb-1">
              {children}
            </h4>
          ),
          p: ({ children }) => (
            <p className="my-1.5 leading-relaxed text-gray-800 dark:text-gray-200 text-xs sm:text-sm">
              {children}
            </p>
          ),
          ul: ({ children }) => (
            <ul className="my-2 space-y-1.5 pr-5 list-disc text-gray-800 dark:text-gray-200 text-xs sm:text-sm marker:text-teal-600">
              {children}
            </ul>
          ),
          ol: ({ children }) => (
            <ol className="my-2 space-y-1.5 pr-5 list-decimal text-gray-800 dark:text-gray-200 text-xs sm:text-sm marker:text-teal-600 font-semibold">
              {children}
            </ol>
          ),
          li: ({ children }) => (
            <li className="leading-relaxed font-normal">
              {children}
            </li>
          ),
          strong: ({ children }) => (
            <strong className="font-bold text-teal-900 dark:text-teal-200 bg-teal-50/70 dark:bg-teal-950/40 px-1 py-0.5 rounded">
              {children}
            </strong>
          ),
          blockquote: ({ children }) => (
            <blockquote className="my-2.5 p-3 rounded-xl bg-teal-50/60 dark:bg-teal-950/30 border-r-4 border-teal-600 text-gray-800 dark:text-gray-200 text-xs sm:text-sm shadow-xs">
              {children}
            </blockquote>
          ),
          table: ({ children }) => (
            <div className="table-responsive overflow-x-auto max-w-full my-3.5 rounded-2xl border border-slate-200/90 dark:border-[#223930] bg-white/95 dark:bg-[#15231e] shadow-xs" style={{ WebkitOverflowScrolling: 'touch' }}>
              <table className="w-max min-w-[680px] text-right text-xs sm:text-sm border-collapse">
                {children}
              </table>
            </div>
          ),
          thead: ({ children }) => (
            <thead className="bg-slate-50 dark:bg-[#1a2c25] text-slate-800 dark:text-slate-100 font-bold border-b border-slate-200 dark:border-[#223930]">
              {children}
            </thead>
          ),
          tbody: ({ children }) => (
            <tbody className="divide-y divide-slate-100 dark:divide-[#1e342b]/60 bg-transparent">
              {children}
            </tbody>
          ),
          tr: ({ children }) => (
            <tr className="hover:bg-slate-50/60 dark:hover:bg-teal-950/20 transition-colors">
              {children}
            </tr>
          ),
          th: ({ children }) => (
            <th className="min-w-[130px] p-3 font-bold text-teal-800 dark:text-teal-300 select-none whitespace-normal break-keep">
              {children}
            </th>
          ),
          td: ({ children }) => (
            <td className="min-w-[130px] p-3 text-slate-700 dark:text-slate-200 whitespace-normal break-keep">
              {children}
            </td>
          ),
          code: ({ children, className: codeClass }) => {
            const isInline = !codeClass;
            const language = (codeClass?.replace('language-', '') || '').toLowerCase().trim();

            // Handle math and LaTeX code blocks with react-katex BlockMath
            if (language === 'math' || language === 'latex' || language === 'katex') {
              const mathString = String(children).replace(/\n$/, '').trim();
              return <SafeBlockMath math={mathString} />;
            }

            // Handle Interactive Quizzes in Chat
            if (language === 'quiz' || language === 'interactive-quiz' || language === 'mcq') {
              try {
                const raw = String(children).trim();
                const parsed = JSON.parse(raw);
                if (parsed && parsed.question && Array.isArray(parsed.options)) {
                  return (
                    <InteractiveChatQuiz
                      question={parsed.question}
                      options={parsed.options}
                      correctIndex={typeof parsed.correctIndex === 'number' ? parsed.correctIndex : 0}
                      explanation={parsed.explanation}
                    />
                  );
                }
              } catch (err) {
                // fall through if JSON parse fails
              }
            }

            // Handle Interactive Embedded Mind Maps in Chat
            if (language === 'mindmap' || language === 'brainstorm' || language === 'map') {
              try {
                const raw = String(children).trim();
                const parsed = JSON.parse(raw);
                if (parsed && (parsed.title || parsed.children)) {
                  return <ChatEmbeddedMindMap data={parsed} title={parsed.title} />;
                }
              } catch (err) {
                // fall through if JSON parse fails
              }
            }

            if (isInline) {
              return (
                <code className="px-1.5 py-0.5 mx-0.5 rounded-lg bg-teal-50/80 dark:bg-[#1a2c25] font-mono text-xs font-semibold text-teal-700 dark:text-teal-300 border border-teal-200/70 dark:border-teal-800/60 dir-ltr inline-block">
                  {children}
                </code>
              );
            }
            return (
              <div className="my-3.5 w-full max-w-full rounded-2xl overflow-hidden border border-slate-700/60 dark:border-[#223930] bg-[#0d1520] shadow-md text-left dir-ltr">
                <div className="flex items-center justify-between px-4 py-2 bg-[#172233] border-b border-slate-800 text-[11px] text-slate-300 font-mono select-none">
                  <span className="font-bold text-teal-400">{language || 'code'}</span>
                  <span className="text-[10px] text-slate-400">كود برمجي</span>
                </div>
                <pre className="p-4 font-mono text-xs overflow-x-auto max-w-full text-emerald-300 leading-relaxed">
                  <code>{children}</code>
                </pre>
              </div>
            );
          },
          pre: ({ children }) => (
            <div className="w-full max-w-full overflow-x-auto min-w-0 my-2 rounded-2xl">
              {children}
            </div>
          ),
          img: ({ src, alt }) => {
            if (!src) return null;
            return (
              <figure className="my-3 flex flex-col items-center group">
                <div className="overflow-hidden rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm max-w-full bg-white dark:bg-[#121c19]">
                  <img
                    src={src}
                    alt={alt || 'صورة توضيحية'}
                    className="max-h-80 w-auto max-w-full object-contain mx-auto transition-transform group-hover:scale-[1.01]"
                    loading="lazy"
                  />
                </div>
                {alt && alt !== 'صورة' && alt !== 'image' && (
                  <figcaption className="mt-1.5 text-center text-[11px] text-gray-500 dark:text-gray-400 font-medium">
                    {alt}
                  </figcaption>
                )}
              </figure>
            );
          },
          hr: () => (
            <hr className="my-3 border-gray-200 dark:border-gray-800" />
          ),
        }}
      >
        {processed}
      </ReactMarkdown>

      {isStreaming && (
        <span className="inline-block w-2 h-4 bg-teal-600 dark:bg-teal-400 animate-pulse mr-1 rounded-xs align-middle" />
      )}
    </div>
  );
};
