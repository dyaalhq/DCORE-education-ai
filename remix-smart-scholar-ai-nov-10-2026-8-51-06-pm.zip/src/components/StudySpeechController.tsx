import React, { useState } from 'react';
import { 
  Volume2, 
  Pause, 
  Play, 
  Square, 
  Gauge,
  SkipBack,
  SkipForward,
  AlertCircle,
  X,
  ChevronDown,
  UserCheck
} from 'lucide-react';
import { useTextToSpeech } from '../lib/TextToSpeechService';

export const StudySpeechController: React.FC = () => {
  const {
    isPlaying,
    isPaused,
    speed,
    currentTitle,
    totalChunks,
    currentChunkIndex,
    currentChunkText,
    progressPercent,
    availableVoices,
    selectedVoiceUri,
    errorMessage,
    pause,
    resume,
    stop,
    setSpeed,
    setVoice,
    nextChunk,
    prevChunk,
  } = useTextToSpeech();

  const [isSpeedMenuOpen, setIsSpeedMenuOpen] = useState(false);
  const [isVoiceMenuOpen, setIsVoiceMenuOpen] = useState(false);

  if (!isPlaying && !isPaused) {
    return null;
  }

  const speedOptions = [0.5, 0.75, 1.0, 1.25, 1.5, 2.0];
  const arabicVoices = availableVoices.filter((v) => v.isArabic);
  const otherVoices = availableVoices.filter((v) => !v.isArabic);

  return (
    <div 
      className="fixed bottom-4 left-4 right-4 sm:left-auto sm:right-6 sm:w-[420px] z-50 animate-in fade-in slide-in-from-bottom-4 duration-300"
      dir="rtl"
    >
      <div className="bg-white/95 dark:bg-[#15231f]/95 backdrop-blur-md rounded-2xl shadow-2xl border-2 border-teal-600/35 dark:border-teal-500/35 p-3.5 text-slate-800 dark:text-slate-100 shadow-teal-950/15">
        
        {/* Error notification if any */}
        {errorMessage && (
          <div className="mb-2 px-2.5 py-1.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-700 dark:text-amber-300 text-xs flex items-center justify-between gap-2">
            <div className="flex items-center gap-1.5 min-w-0">
              <AlertCircle className="w-3.5 h-3.5 shrink-0" />
              <span className="truncate">{errorMessage}</span>
            </div>
            <button
              type="button"
              onClick={nextChunk}
              className="text-[10px] font-bold underline hover:text-amber-800 shrink-0 cursor-pointer"
            >
              تخطي للمقطع التالي
            </button>
          </div>
        )}

        {/* Header row: Icon, Title, and Dismiss */}
        <div className="flex items-center justify-between gap-3 mb-2.5">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-teal-600 text-white flex items-center justify-center shrink-0 shadow-sm relative">
              <Volume2 className={`w-4 h-4 ${isPlaying && !isPaused ? 'animate-pulse' : ''}`} />
              {isPlaying && !isPaused && (
                <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-400 rounded-full animate-ping" />
              )}
            </div>
            <div className="min-w-0">
              <div className="text-xs font-black truncate leading-tight text-teal-900 dark:text-teal-200">
                {currentTitle || 'القراءة الصوتية بالذكاء الاصطناعي'}
              </div>
              <div className="text-[10px] text-slate-500 dark:text-slate-400 flex items-center gap-1.5 mt-0.5">
                <span>المقطع {currentChunkIndex + 1} من {totalChunks || 1}</span>
                <span>•</span>
                <span className="font-bold text-teal-600 dark:text-teal-400">{speed}x</span>
                {totalChunks > 0 && (
                  <>
                    <span>•</span>
                    <span>{progressPercent}%</span>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* Quick Close Button */}
          <button
            type="button"
            onClick={stop}
            className="w-7 h-7 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center transition cursor-pointer shrink-0"
            title="إغلاق القراءة الصوتية"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Current reading text excerpt */}
        {currentChunkText && (
          <div className="mb-2.5 px-2.5 py-1.5 rounded-xl bg-teal-50/60 dark:bg-teal-950/40 border border-teal-100/80 dark:border-teal-900/40 text-[11px] text-teal-950 dark:text-teal-100 line-clamp-2 leading-relaxed font-medium">
            "{currentChunkText}"
          </div>
        )}

        {/* Action Controls Toolbar */}
        <div className="flex items-center justify-between gap-2">
          {/* Audio Chunks navigation & Play/Pause */}
          <div className="flex items-center gap-1.5">
            {/* Prev chunk */}
            <button
              type="button"
              onClick={prevChunk}
              disabled={currentChunkIndex <= 0}
              className="w-7 h-7 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 disabled:opacity-40 disabled:pointer-events-none flex items-center justify-center transition cursor-pointer"
              title="المقطع السابق"
            >
              <SkipForward className="w-3.5 h-3.5" />
            </button>

            {/* Play / Pause Button */}
            {isPaused ? (
              <button
                type="button"
                onClick={resume}
                className="w-9 h-9 rounded-xl bg-teal-600 hover:bg-teal-700 text-white flex items-center justify-center transition shadow-sm cursor-pointer"
                title="استئناف القراءة"
              >
                <Play className="w-4 h-4 fill-current ml-0.5" />
              </button>
            ) : (
              <button
                type="button"
                onClick={pause}
                className="w-9 h-9 rounded-xl bg-amber-500 hover:bg-amber-600 text-white flex items-center justify-center transition shadow-sm cursor-pointer"
                title="إيقاف مؤقت"
              >
                <Pause className="w-4 h-4 fill-current" />
              </button>
            )}

            {/* Next chunk */}
            <button
              type="button"
              onClick={nextChunk}
              disabled={currentChunkIndex >= totalChunks - 1}
              className="w-7 h-7 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 disabled:opacity-40 disabled:pointer-events-none flex items-center justify-center transition cursor-pointer"
              title="المقطع التالي"
            >
              <SkipBack className="w-3.5 h-3.5" />
            </button>

            {/* Stop Button */}
            <button
              type="button"
              onClick={stop}
              className="w-7 h-7 rounded-lg bg-slate-100 hover:bg-rose-50 dark:bg-slate-800 dark:hover:bg-rose-950/40 text-slate-600 hover:text-rose-600 dark:text-slate-300 dark:hover:text-rose-300 flex items-center justify-center transition cursor-pointer"
              title="إيقاف نهائي"
            >
              <Square className="w-3 h-3 fill-current" />
            </button>
          </div>

          {/* Menus: Speed and Voices */}
          <div className="flex items-center gap-1.5">
            {/* Voice Selector */}
            {availableVoices.length > 0 && (
              <div className="relative">
                <button
                  type="button"
                  onClick={() => {
                    setIsVoiceMenuOpen(!isVoiceMenuOpen);
                    setIsSpeedMenuOpen(false);
                  }}
                  className="px-2 py-1 rounded-lg text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 hover:bg-slate-200 dark:hover:bg-slate-700 transition flex items-center gap-1 cursor-pointer"
                  title="تغيير صوت القارئ"
                >
                  <UserCheck className="w-3 h-3 text-teal-600 dark:text-teal-400" />
                  <span className="hidden xs:inline">الصوت</span>
                  <ChevronDown className="w-2.5 h-2.5" />
                </button>

                {isVoiceMenuOpen && (
                  <div className="absolute bottom-full mb-1.5 left-0 w-52 max-h-56 overflow-y-auto bg-white dark:bg-[#1a2723] rounded-xl shadow-xl border border-teal-100 dark:border-teal-800/60 p-1.5 z-50 text-right">
                    <div className="text-[10px] font-bold text-teal-700 dark:text-teal-300 px-2 py-1">
                      الأصوات المتاحة ({availableVoices.length})
                    </div>
                    {arabicVoices.map((v) => (
                      <button
                        key={v.uri}
                        type="button"
                        onClick={() => {
                          setVoice(v.uri);
                          setIsVoiceMenuOpen(false);
                        }}
                        className={`w-full text-right px-2 py-1.5 rounded-lg text-[10px] font-medium transition cursor-pointer truncate flex items-center justify-between ${
                          selectedVoiceUri === v.uri
                            ? 'bg-teal-600 text-white font-bold'
                            : 'hover:bg-teal-50 dark:hover:bg-[#22352f] text-slate-700 dark:text-slate-200'
                        }`}
                      >
                        <span className="truncate">{v.name}</span>
                        <span className="text-[9px] opacity-75 shrink-0 mr-1">عربي</span>
                      </button>
                    ))}
                    {otherVoices.slice(0, 4).map((v) => (
                      <button
                        key={v.uri}
                        type="button"
                        onClick={() => {
                          setVoice(v.uri);
                          setIsVoiceMenuOpen(false);
                        }}
                        className={`w-full text-right px-2 py-1.5 rounded-lg text-[10px] font-medium transition cursor-pointer truncate ${
                          selectedVoiceUri === v.uri
                            ? 'bg-teal-600 text-white font-bold'
                            : 'hover:bg-teal-50 dark:hover:bg-[#22352f] text-slate-700 dark:text-slate-200'
                        }`}
                      >
                        <span className="truncate">{v.name} ({v.lang})</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Speed Selector */}
            <div className="relative">
              <button
                type="button"
                onClick={() => {
                  setIsSpeedMenuOpen(!isSpeedMenuOpen);
                  setIsVoiceMenuOpen(false);
                }}
                className="px-2 py-1 rounded-lg text-[10px] font-black bg-teal-50 dark:bg-teal-950/80 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-800/80 hover:bg-teal-100 dark:hover:bg-teal-900 transition flex items-center gap-1 cursor-pointer"
                title="تغيير سرعة القراءة"
              >
                <Gauge className="w-3 h-3" />
                <span>{speed}x</span>
              </button>

              {isSpeedMenuOpen && (
                <div className="absolute bottom-full mb-1.5 left-0 bg-white dark:bg-[#1a2723] rounded-xl shadow-xl border border-teal-100 dark:border-teal-800/60 p-1 flex gap-1 z-50">
                  {speedOptions.map((rate) => (
                    <button
                      key={rate}
                      type="button"
                      onClick={() => {
                        setSpeed(rate);
                        setIsSpeedMenuOpen(false);
                      }}
                      className={`px-2 py-1 rounded-lg text-[10px] font-bold transition cursor-pointer ${
                        speed === rate
                          ? 'bg-teal-600 text-white shadow-xs'
                          : 'hover:bg-teal-50 dark:hover:bg-[#22352f] text-slate-700 dark:text-slate-200'
                      }`}
                    >
                      {rate}x
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Progress bar */}
        <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-1.5 overflow-hidden mt-2.5">
          <div
            className="bg-gradient-to-r from-teal-500 to-emerald-500 h-1.5 rounded-full transition-all duration-300"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>
    </div>
  );
};
