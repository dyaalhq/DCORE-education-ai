import React from 'react';

interface AppLogoProps {
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  className?: string;
  useImage?: boolean;
}

export const AppLogo: React.FC<AppLogoProps> = ({
  size = 'md',
  showText = false,
  className = '',
}) => {
  const sizeMap = {
    xs: { box: 32, text: 'text-xs', sub: 'text-[9px]' },
    sm: { box: 38, text: 'text-sm', sub: 'text-[10px]' },
    md: { box: 44, text: 'text-base', sub: 'text-[11px]' },
    lg: { box: 56, text: 'text-lg', sub: 'text-xs' },
    xl: { box: 76, text: 'text-2xl', sub: 'text-sm' },
  };

  const { box, text, sub } = sizeMap[size] || sizeMap.md;

  return (
    <div className={`inline-flex items-center gap-3 select-none ${className}`}>
      {/* Imperial Wisdom Crest & Futuristic Neural Hologram */}
      <div 
        className="relative shrink-0 flex items-center justify-center rounded-2xl overflow-hidden shadow-xl shadow-teal-950/20 group transition-transform duration-300 hover:scale-105"
        style={{ width: box, height: box }}
      >
        {/* Ambient Backlight Deep Obsidian & Emerald Teal Prism Gradient */}
        <div className="absolute inset-0 bg-gradient-to-br from-[#021b16] via-[#093e38] to-[#04241e] transition-all duration-700 group-hover:scale-110" />
        
        {/* Dual Luxury Gold Geometric Border & Prism Ring */}
        <div className="absolute inset-0 rounded-2xl border-2 border-amber-300/80 dark:border-amber-400/80 ring-1 ring-inset ring-teal-300/40" />

        {/* Diagonal Dynamic Sheen */}
        <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/25 to-transparent pointer-events-none transform -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
        

        {/* Master Vector Artwork */}
        <svg
          viewBox="0 0 100 100"
          className="relative z-10 w-[84%] h-[84%] drop-shadow-[0_2px_5px_rgba(0,0,0,0.5)]"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            {/* 24K Royal Gold Gradient */}
            <linearGradient id="imperialGold" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#fffbeb" />
              <stop offset="25%" stopColor="#fef08a" />
              <stop offset="50%" stopColor="#f59e0b" />
              <stop offset="75%" stopColor="#d97706" />
              <stop offset="100%" stopColor="#b45309" />
            </linearGradient>

            {/* Glowing Pages Gradient */}
            <linearGradient id="celestialPages" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#ffffff" />
              <stop offset="60%" stopColor="#e6fffa" />
              <stop offset="100%" stopColor="#99f6e4" />
            </linearGradient>

            {/* Emerald Gem Core Gradient */}
            <linearGradient id="emeraldCore" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#34d399" />
              <stop offset="100%" stopColor="#059669" />
            </linearGradient>

            <filter id="royalGlow" x="-30%" y="-30%" width="160%" height="160%">
              <feGaussianBlur stdDeviation="2.5" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>

          {/* Outer Astrolabe Knowledge Orbit */}
          <circle cx="50" cy="50" r="44" stroke="url(#imperialGold)" strokeWidth="1.2" strokeDasharray="3 5" opacity="0.45" />
          <circle cx="50" cy="50" r="39" stroke="url(#imperialGold)" strokeWidth="0.8" opacity="0.3" />

          {/* Majestic Open Wings Book (Symmetrical Wisdom Wing Architecture) */}
          {/* Left Leaf / Wing */}
          <path
            d="M 50 73 C 37 66 22 67 12 75 C 11.2 75.4 10.5 74.8 10.5 73.8 L 10.5 35 C 22 28 37 29 50 35 Z"
            fill="url(#celestialPages)"
            opacity="0.96"
          />
          {/* Left Page Layer 2 */}
          <path
            d="M 48 69 C 38 64 25 65 16 71 L 16 38 C 26 33 38 34 48 38 Z"
            fill="#ffffff"
            opacity="0.5"
          />

          {/* Right Leaf / Wing */}
          <path
            d="M 50 73 C 63 66 78 67 88 75 C 88.8 75.4 89.5 74.8 89.5 73.8 L 89.5 35 C 78 28 63 29 50 35 Z"
            fill="url(#celestialPages)"
            opacity="0.96"
          />
          {/* Right Page Layer 2 */}
          <path
            d="M 52 69 C 62 64 75 65 84 71 L 84 38 C 74 33 62 34 52 38 Z"
            fill="#ffffff"
            opacity="0.5"
          />

          {/* Center Golden Spine Keel */}
          <path
            d="M 48 34 L 50 74 L 52 34 Z"
            fill="url(#imperialGold)"
          />

          {/* Laurel Knowledge Wreath Arc below */}
          <path
            d="M 20 80 C 33 85 67 85 80 80"
            stroke="url(#imperialGold)"
            strokeWidth="2.5"
            strokeLinecap="round"
          />

          {/* Central Heart Jewel / Diamond (The Core of Intelligence) */}
          <polygon
            points="50,47 55,53 50,59 45,53"
            fill="url(#imperialGold)"
            filter="url(#royalGlow)"
          />

          {/* Northern Guiding Star / Academic Crown on Top */}
          <g filter="url(#royalGlow)">
            {/* 8-point Stellar Compass */}
            <path
              d="M 50 9 L 53 19 L 63 22 L 53 25 L 50 35 L 47 25 L 37 22 L 47 19 Z"
              fill="url(#imperialGold)"
            />
          </g>

          {/* Radiant Satellite Stars */}
          <circle cx="26" cy="22" r="1.8" fill="#fef08a" />
          <circle cx="74" cy="22" r="1.8" fill="#fef08a" />
          <circle cx="50" cy="88" r="1.5" fill="#fef08a" />
        </svg>
      </div>

      {/* Brand Typography */}
      {showText && (
        <div className="flex flex-col text-right">
          <div className={`font-black tracking-tight text-[#17201e] dark:text-[#eef7f4] leading-tight flex items-center gap-2 ${text}`}>
            <span>المعلم الذكي</span>
            <span className="w-2 h-2 rounded-full bg-amber-400 shadow-[0_0_8px_#f59e0b] animate-pulse" />
          </div>
          <span className={`text-[#0f766e] dark:text-[#2dd4bf] font-bold leading-none mt-1 ${sub}`}>
            منصة المذاكرة والأبحاث الأكاديمية العالمية
          </span>
        </div>
      )}
    </div>
  );
};
