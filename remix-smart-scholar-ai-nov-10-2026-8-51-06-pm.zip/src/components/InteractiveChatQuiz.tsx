import React, { useState } from 'react';
import { 
  CheckCircle2, 
  XCircle, 
  HelpCircle, 
  RotateCcw, 
  Sparkles, 
  Award,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { SafeInlineMath } from './EducationalContent';
import { SafeMathText } from './SafeMathText';

export interface InteractiveChatQuizProps {
  question: string;
  options: string[];
  correctIndex: number;
  explanation?: string;
  questionNumber?: number;
  onCheckAnswer?: (isCorrect: boolean, selectedIndex: number) => void;
}

export const InteractiveChatQuiz: React.FC<InteractiveChatQuizProps> = ({
  question,
  options,
  correctIndex,
  explanation,
  questionNumber,
  onCheckAnswer,
}) => {
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const isAnswered = selectedIndex !== null;
  const isCorrect = isAnswered && selectedIndex === correctIndex;

  const handleSelectOption = (idx: number) => {
    if (isAnswered) return;
    setSelectedIndex(idx);
    setShowExplanation(true);
    if (onCheckAnswer) {
      onCheckAnswer(idx === correctIndex, idx);
    }
  };

  const handleReset = (e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedIndex(null);
    setShowExplanation(false);
  };

  const arabicLetters = ['أ', 'ب', 'ج', 'د', 'هـ', 'و'];

  return (
    <div 
      className="my-3.5 w-full max-w-full rounded-2xl border border-teal-500/25 dark:border-teal-500/20 bg-gradient-to-b from-teal-50/70 via-white to-teal-50/40 dark:from-[#13221d] dark:via-[#0e1915] dark:to-[#13221d] p-3.5 sm:p-4.5 shadow-sm overflow-hidden text-right select-none isolate relative transition-all"
      dir="rtl"
    >
      {/* Top Header Badge */}
      <div className="flex items-center justify-between pb-2.5 mb-2.5 border-b border-teal-500/20 dark:border-teal-500/15">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-lg bg-teal-600/15 dark:bg-teal-400/15 text-teal-700 dark:text-teal-300 flex items-center justify-center">
            <HelpCircle className="w-3.5 h-3.5" />
          </div>
          <span className="text-xs font-black text-teal-800 dark:text-teal-300">
            {questionNumber ? `سؤال تفاعلي #${questionNumber}` : 'سؤال تقييم تفاعلي مباشر'}
          </span>
          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-teal-100/80 dark:bg-teal-900/40 text-teal-700 dark:text-teal-300">
            اختيار من متعدد
          </span>
        </div>

        {isAnswered && (
          <button
            type="button"
            onClick={handleReset}
            className="text-[11px] font-bold text-slate-500 dark:text-slate-400 hover:text-teal-600 dark:hover:text-teal-300 flex items-center gap-1 transition-colors cursor-pointer"
            title="إعادة المحاولة"
          >
            <RotateCcw className="w-3 h-3" />
            <span>إعادة الحل</span>
          </button>
        )}
      </div>

      {/* Question Text */}
      <div className="text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-100 mb-3 leading-relaxed">
        <SafeMathText text={question} />
      </div>

      {/* Clickable Options List */}
      <div className="space-y-2">
        {options.map((opt, idx) => {
          const letter = arabicLetters[idx] || `${idx + 1}`;
          const isThisSelected = selectedIndex === idx;
          const isThisCorrect = idx === correctIndex;

          let btnClass = 'bg-white/80 dark:bg-[#162520] border-slate-200/90 dark:border-[#223930] text-slate-700 dark:text-slate-200 hover:border-teal-500 hover:bg-teal-50/50 dark:hover:bg-teal-950/40';
          let letterClass = 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300';
          let icon = null;

          if (isAnswered) {
            if (isThisCorrect) {
              btnClass = 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-500 dark:border-emerald-500/60 text-emerald-900 dark:text-emerald-200 font-bold shadow-xs';
              letterClass = 'bg-emerald-600 text-white';
              icon = <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />;
            } else if (isThisSelected) {
              btnClass = 'bg-rose-50 dark:bg-rose-950/40 border-rose-500 dark:border-rose-500/60 text-rose-900 dark:text-rose-200 font-bold shadow-xs';
              letterClass = 'bg-rose-600 text-white';
              icon = <XCircle className="w-4 h-4 text-rose-600 dark:text-rose-400 shrink-0" />;
            } else {
              btnClass = 'opacity-60 bg-white/40 dark:bg-[#162520]/40 border-slate-200/50 dark:border-[#223930]/50 text-slate-500 dark:text-slate-400';
            }
          }

          return (
            <button
              key={idx}
              type="button"
              disabled={isAnswered}
              onClick={() => handleSelectOption(idx)}
              className={`w-full p-2.5 sm:p-3 rounded-xl border text-right text-xs sm:text-sm flex items-center justify-between gap-2.5 transition-all cursor-pointer ${btnClass}`}
            >
              <div className="flex items-center gap-2.5 flex-1 min-w-0">
                <span className={`w-6 h-6 rounded-lg text-xs font-black flex items-center justify-center shrink-0 transition-colors ${letterClass}`}>
                  {letter}
                </span>
                <span className="flex-1 break-words leading-relaxed"><SafeMathText text={opt} /></span>
              </div>
              {icon}
            </button>
          );
        })}
      </div>

      {/* Immediate Result & Explanation Banner */}
      {isAnswered && (
        <div className={`mt-3 p-3 rounded-xl border transition-all animate-in fade-in slide-in-from-top-1 duration-200 ${
          isCorrect 
            ? 'bg-emerald-50/90 dark:bg-emerald-950/40 border-emerald-300 dark:border-emerald-800/60 text-emerald-900 dark:text-emerald-200' 
            : 'bg-amber-50/90 dark:bg-amber-950/40 border-amber-300 dark:border-amber-800/60 text-amber-900 dark:text-amber-200'
        }`}>
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 font-black text-xs sm:text-sm">
              {isCorrect ? (
                <>
                  <Award className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                  <span>إجابة صحيحة وممتازة! أحسنت 🎉</span>
                </>
              ) : (
                <>
                  <XCircle className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                  <span>إجابة غير صحيحة. الخيار الصواب هو: «<SafeMathText text={options[correctIndex]} />» 💡</span>
                </>
              )}
            </div>

            {explanation && (
              <button
                type="button"
                onClick={() => setShowExplanation(!showExplanation)}
                className="text-[11px] font-bold underline flex items-center gap-0.5 cursor-pointer text-slate-700 dark:text-slate-200"
              >
                <span>{showExplanation ? 'إخفاء الشرح' : 'عرض الشرح'}</span>
                {showExplanation ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
              </button>
            )}
          </div>

          {explanation && showExplanation && (
            <div className="mt-2 pt-2 border-t border-black/10 dark:border-white/10 text-xs leading-relaxed text-slate-700 dark:text-slate-200">
              <strong className="block text-[11px] text-slate-500 dark:text-slate-400 mb-0.5">التفسير الأكاديمي:</strong>
              <SafeMathText text={explanation} block />
            </div>
          )}
        </div>
      )}
    </div>
  );
};
