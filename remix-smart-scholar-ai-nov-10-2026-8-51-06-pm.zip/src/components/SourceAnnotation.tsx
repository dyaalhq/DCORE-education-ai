import React, { useState } from 'react';
import {
  Highlighter,
  MessageSquare,
  Sparkles,
  Trash2,
  Copy,
  Check,
  ExternalLink,
  Target,
  FileText,
  MapPin,
  ChevronDown,
  ChevronUp,
  Share2,
} from 'lucide-react';
import { SourceAnnotation, HighlightColor, AnnotationRect } from '../types';

interface SourceAnnotationCardProps {
  annotation: SourceAnnotation;
  sourceTitle?: string;
  isActive?: boolean;
  onJumpTo?: (annotation: SourceAnnotation) => void;
  onAskAbout?: (annotation: SourceAnnotation) => void;
  onDelete?: (id: string) => void;
  onUpdateColor?: (id: string, color: HighlightColor) => void;
  onUpdateNote?: (id: string, note: string) => void;
  onExportToNote?: (annotation: SourceAnnotation) => void;
}

const COLOR_CONFIGS: Record<
  HighlightColor,
  {
    bg: string;
    border: string;
    text: string;
    dot: string;
    label: string;
    overlay: string;
    ring: string;
  }
> = {
  yellow: {
    bg: 'bg-amber-50 dark:bg-amber-950/40',
    border: 'border-amber-200 dark:border-amber-800/60',
    text: 'text-amber-900 dark:text-amber-200',
    dot: 'bg-amber-400',
    label: 'أصفر (مفاهيم أساسية)',
    overlay: 'bg-amber-300/35 border-amber-400/80',
    ring: 'ring-amber-400',
  },
  green: {
    bg: 'bg-emerald-50 dark:bg-emerald-950/40',
    border: 'border-emerald-200 dark:border-emerald-800/60',
    text: 'text-emerald-900 dark:text-emerald-200',
    dot: 'bg-emerald-500',
    label: 'أخضر (قوانين ونتائج)',
    overlay: 'bg-emerald-400/30 border-emerald-500/80',
    ring: 'ring-emerald-400',
  },
  blue: {
    bg: 'bg-sky-50 dark:bg-sky-950/40',
    border: 'border-sky-200 dark:border-sky-800/60',
    text: 'text-sky-900 dark:text-sky-200',
    dot: 'bg-sky-500',
    label: 'أزرق (أمثلة وشواهد)',
    overlay: 'bg-sky-400/30 border-sky-500/80',
    ring: 'ring-sky-400',
  },
  purple: {
    bg: 'bg-purple-50 dark:bg-purple-950/40',
    border: 'border-purple-200 dark:border-purple-800/60',
    text: 'text-purple-900 dark:text-purple-200',
    dot: 'bg-purple-500',
    label: 'بنفسجي (أسئلة واختبارات)',
    overlay: 'bg-purple-400/30 border-purple-500/80',
    ring: 'ring-purple-400',
  },
  rose: {
    bg: 'bg-rose-50 dark:bg-rose-950/40',
    border: 'border-rose-200 dark:border-rose-800/60',
    text: 'text-rose-900 dark:text-rose-200',
    dot: 'bg-rose-500',
    label: 'وردي (ملاحظات حرجة)',
    overlay: 'bg-rose-400/30 border-rose-500/80',
    ring: 'ring-rose-400',
  },
};

/**
 * Visual Annotation Card with exact coordinates, database chunk linking, and two-way navigation
 */
export const SourceAnnotationCard: React.FC<SourceAnnotationCardProps> = ({
  annotation,
  sourceTitle,
  isActive = false,
  onJumpTo,
  onAskAbout,
  onDelete,
  onUpdateColor,
  onUpdateNote,
  onExportToNote,
}) => {
  const [isEditingNote, setIsEditingNote] = useState(false);
  const [noteDraft, setNoteDraft] = useState(annotation.note || '');
  const [copied, setCopied] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);

  const colorCfg = COLOR_CONFIGS[annotation.color] || COLOR_CONFIGS.yellow;

  const handleCopyText = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(annotation.selectedText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSaveNote = () => {
    if (onUpdateNote) {
      onUpdateNote(annotation.id, noteDraft.trim());
    }
    setIsEditingNote(false);
  };

  // Format coordinates summary
  const coordSummary = annotation.boundingRect
    ? `X: ${Math.round(annotation.boundingRect.x * 100)}% • Y: ${Math.round(
        annotation.boundingRect.y * 100
      )}%`
    : annotation.rects && annotation.rects.length > 0
    ? `X: ${Math.round(annotation.rects[0].x * 100)}% • Y: ${Math.round(
        annotation.rects[0].y * 100
      )}%`
    : null;

  return (
    <div
      className={`group relative rounded-2xl border p-3.5 transition-all text-right shadow-2xs w-full min-w-0 max-w-full overflow-hidden box-border ${
        colorCfg.bg
      } ${colorCfg.border} ${
        isActive ? `ring-2 ${colorCfg.ring} shadow-md scale-[1.01]` : 'hover:shadow-xs'
      }`}
      dir="rtl"
    >
      {/* Top Header: Page, Coordinate pill, and Quick Actions */}
      <div className="flex items-center justify-between gap-2 mb-2 min-w-0 max-w-full">
        <div className="flex items-center gap-1.5 flex-wrap min-w-0">
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-black bg-white dark:bg-[#121c19] border border-black/10 dark:border-white/10 text-gray-800 dark:text-gray-200 shadow-2xs">
            <Highlighter className="w-3 h-3 text-teal-600 dark:text-teal-400" />
            <span>الصفحة {annotation.pageNumber}</span>
          </span>

          {coordSummary && (
            <span
              className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md text-[9px] font-mono text-gray-500 dark:text-gray-400 bg-white/70 dark:bg-[#121c19]/70 border border-black/5 dark:border-white/5 truncate max-w-[120px]"
              title="إحداثيات التظليل في صفحة PDF"
            >
              <MapPin className="w-2.5 h-2.5 text-teal-500 shrink-0" />
              <span className="truncate">{coordSummary}</span>
            </span>
          )}

          {annotation.chunkId && (
            <span
              className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md text-[9px] font-bold text-emerald-800 dark:text-emerald-300 bg-emerald-100/60 dark:bg-emerald-950/60"
              title={`مرتبط بفقرة قاعدة البيانات: ${annotation.chunkId}`}
            >
              <FileText className="w-2.5 h-2.5" />
              <span>فقرة موثقة</span>
            </span>
          )}
        </div>

        {/* Action icons */}
        <div className="flex items-center gap-1 shrink-0">
          {onJumpTo && (
            <button
              type="button"
              onClick={() => onJumpTo(annotation)}
              className="p-1.5 rounded-lg text-teal-700 dark:text-teal-300 hover:bg-white dark:hover:bg-[#162520] transition-colors cursor-pointer"
              title="انتقال بؤري مباشر إلى موقع التظليل في المستند"
            >
              <Target className="w-3.5 h-3.5" />
            </button>
          )}

          {onAskAbout && (
            <button
              type="button"
              onClick={() => onAskAbout(annotation)}
              className="p-1.5 rounded-lg text-[#0f766e] dark:text-[#2dd4bf] hover:bg-white dark:hover:bg-[#162520] transition-colors cursor-pointer"
              title="مناقشة واستفسار عن هذا الاقتباس في المحادثة الذكية"
            >
              <MessageSquare className="w-3.5 h-3.5" />
            </button>
          )}

          <button
            type="button"
            onClick={handleCopyText}
            className="p-1.5 rounded-lg text-gray-500 hover:text-gray-800 dark:hover:text-gray-200 hover:bg-white dark:hover:bg-[#162520] transition-colors cursor-pointer"
            title="نسخ النص المظلل"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
          </button>

          {onDelete && (
            <button
              type="button"
              onClick={() => onDelete(annotation.id)}
              className="p-1.5 rounded-lg text-rose-500 hover:text-rose-700 hover:bg-white dark:hover:bg-[#162520] transition-colors cursor-pointer"
              title="حذف هذا التظليل"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Selected Highlighted Text Quote */}
      <blockquote className="text-xs sm:text-[13px] leading-relaxed font-medium text-gray-800 dark:text-gray-100 border-r-2 border-teal-500 pr-2 my-1.5 italic whitespace-pre-wrap select-text break-words min-w-0 max-w-full overflow-hidden">
        «{annotation.selectedText}»
      </blockquote>

      {/* Attached Note / Commentary */}
      {annotation.note && !isEditingNote && (
        <div className="mt-2 p-2 rounded-xl bg-white/80 dark:bg-[#101916]/80 border border-black/5 dark:border-white/5 text-xs text-gray-700 dark:text-gray-300 min-w-0 max-w-full overflow-hidden">
          <div className="flex items-center justify-between pb-1 mb-1 border-b border-gray-100 dark:border-gray-800">
            <span className="text-[10px] font-bold text-teal-700 dark:text-teal-400 flex items-center gap-1">
              <Sparkles className="w-3 h-3" />
              ملاحظة دراسية شخصية:
            </span>
            <button
              type="button"
              onClick={() => setIsEditingNote(true)}
              className="text-[10px] text-gray-400 hover:text-teal-600 cursor-pointer"
            >
              تعديل
            </button>
          </div>
          <p className="leading-normal break-words min-w-0 max-w-full overflow-hidden">{annotation.note}</p>
        </div>
      )}

      {/* Note Editing Form */}
      {isEditingNote && (
        <div className="mt-2 space-y-1.5">
          <textarea
            value={noteDraft}
            onChange={(e) => setNoteDraft(e.target.value)}
            placeholder="اكتب ملاحظتك على هذا التظليل..."
            rows={2}
            className="w-full p-2 text-xs border border-gray-200 dark:border-gray-700 rounded-xl bg-white dark:bg-[#121c19] text-gray-900 dark:text-white focus:outline-none focus:border-teal-600"
          />
          <div className="flex items-center justify-end gap-1.5">
            <button
              type="button"
              onClick={() => setIsEditingNote(false)}
              className="px-2 py-1 text-[11px] rounded-lg text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800 cursor-pointer"
            >
              إلغاء
            </button>
            <button
              type="button"
              onClick={handleSaveNote}
              className="px-2.5 py-1 text-[11px] font-bold rounded-lg bg-teal-600 hover:bg-teal-700 text-white cursor-pointer"
            >
              حفظ
            </button>
          </div>
        </div>
      )}

      {/* Color Palette Switcher */}
      {onUpdateColor && (
        <div className="mt-2.5 pt-2 border-t border-black/5 dark:border-white/5 flex items-center justify-between">
          <div className="flex items-center gap-1">
            <span className="text-[10px] text-gray-500 dark:text-gray-400 font-medium">اللون:</span>
            {(['yellow', 'green', 'blue', 'purple', 'rose'] as HighlightColor[]).map((c) => (
              <button
                key={c}
                type="button"
                onClick={() => onUpdateColor(annotation.id, c)}
                className={`w-4 h-4 rounded-full transition-transform cursor-pointer ${
                  COLOR_CONFIGS[c].dot
                } ${annotation.color === c ? 'scale-125 ring-2 ring-teal-500 ring-offset-1' : 'opacity-70 hover:opacity-100 hover:scale-110'}`}
                title={COLOR_CONFIGS[c].label}
              />
            ))}
          </div>

          <div className="flex items-center gap-1.5">
            {onExportToNote && (
              <button
                type="button"
                onClick={() => onExportToNote(annotation)}
                className="text-[10px] font-bold text-teal-700 dark:text-teal-300 hover:underline flex items-center gap-1 cursor-pointer"
              >
                <span>تصدير لملاحظة</span>
                <Share2 className="w-2.5 h-2.5" />
              </button>
            )}

            {onJumpTo && (
              <button
                type="button"
                onClick={() => onJumpTo(annotation)}
                className="text-[10px] font-bold text-[#0f766e] dark:text-[#2dd4bf] hover:underline flex items-center gap-0.5 cursor-pointer"
              >
                <span>انتقال للتظليل</span>
                <ExternalLink className="w-2.5 h-2.5" />
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

/**
 * Coordinate Overlay for PDF.js Pages & Canvases
 * Renders precise highlight polygons/boxes based on stored normalized coordinates
 */
interface SourceAnnotationOverlayProps {
  annotations: SourceAnnotation[];
  pageNumber: number;
  activeAnnotationId?: string | null;
  onSelectAnnotation?: (ann: SourceAnnotation) => void;
  onAskAboutAnnotation?: (ann: SourceAnnotation) => void;
}

export const SourceAnnotationOverlay: React.FC<SourceAnnotationOverlayProps> = ({
  annotations,
  pageNumber,
  activeAnnotationId,
  onSelectAnnotation,
  onAskAboutAnnotation,
}) => {
  const pageAnnotations = annotations.filter((a) => a.pageNumber === pageNumber);
  if (pageAnnotations.length === 0) return null;

  return (
    <div className="absolute inset-0 pointer-events-none z-10 overflow-hidden" aria-hidden="true">
      {pageAnnotations.map((ann) => {
        const colorCfg = COLOR_CONFIGS[ann.color] || COLOR_CONFIGS.yellow;
        const isActive = activeAnnotationId === ann.id;

        // Prefer multiple rects if available, fallback to single boundingRect
        const rectsToRender = ann.rects && ann.rects.length > 0 ? ann.rects : ann.boundingRect ? [ann.boundingRect] : [];

        if (rectsToRender.length === 0) return null;

        return (
          <React.Fragment key={`ann-overlay-${ann.id}`}>
            {rectsToRender.map((r, rIdx) => {
              // Normalized coordinates are 0..1
              const style: React.CSSProperties = {
                position: 'absolute',
                left: `${r.x * 100}%`,
                top: `${r.y * 100}%`,
                width: `${r.width * 100}%`,
                height: `${r.height * 100}%`,
              };

              return (
                <div
                  key={`rect-${ann.id}-${rIdx}`}
                  style={style}
                  onClick={(e) => {
                    e.stopPropagation();
                    if (onSelectAnnotation) onSelectAnnotation(ann);
                  }}
                  className={`pointer-events-auto rounded-xs border transition-all cursor-pointer ${
                    colorCfg.overlay
                  } ${
                    isActive
                      ? 'ring-2 ring-teal-500 shadow-md animate-pulse'
                      : 'hover:brightness-110 hover:shadow-2xs'
                  }`}
                  title={`تظليل ص ${ann.pageNumber}: «${ann.selectedText.slice(0, 60)}...»`}
                />
              );
            })}
          </React.Fragment>
        );
      })}
    </div>
  );
};

/**
 * Compact Navigation Badge for Chat & Citations
 */
interface SourceAnnotationBadgeProps {
  annotation?: SourceAnnotation;
  pageNumber?: number | null;
  sourceTitle?: string;
  chunkId?: string;
  onClick?: () => void;
}

export const SourceAnnotationBadge: React.FC<SourceAnnotationBadgeProps> = ({
  annotation,
  pageNumber,
  sourceTitle,
  chunkId,
  onClick,
}) => {
  return (
    <button
      type="button"
      onClick={onClick}
      className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-xs font-bold bg-teal-50 dark:bg-teal-950/50 hover:bg-teal-100 dark:hover:bg-teal-900/50 text-teal-800 dark:text-teal-200 border border-teal-200 dark:border-teal-800/60 shadow-2xs transition-all cursor-pointer group"
      title="انتقال مباشر إلى التظليل والفقرة الموثقة في مستند PDF"
    >
      <Target className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400 group-hover:scale-110 transition-transform" />
      <span>انتقال إلى التظليل {pageNumber ? `[ص ${pageNumber}]` : ''}</span>
      <ExternalLink className="w-2.5 h-2.5 opacity-60 group-hover:opacity-100" />
    </button>
  );
};
