import React, { useState, useEffect } from 'react';
import { 
  User, 
  Sparkles, 
  Database, 
  Trash2, 
  CheckCircle2, 
  Cloud, 
  Moon, 
  Sun, 
  Download, 
  Check, 
  Award, 
  Eye, 
  EyeOff, 
  Zap, 
  Server, 
  Loader2, 
  Mail, 
  Copy, 
  Shield, 
  Globe, 
  LogOut, 
  RefreshCw, 
  CheckCheck,
  ChevronLeft,
  ChevronRight,
  ArrowRight,
  ArrowLeft,
  Key
} from 'lucide-react';
import { AppState } from '../lib/storage';
import { PWAInstallButton } from './PWAInstallButton';
import { 
  SUPPORTED_LANGUAGES, 
  SupportedLanguage, 
  getStoredLanguage, 
  setStoredLanguage, 
  t 
} from '../lib/i18n';
import { UserProfile } from '../types';
import { 
  getSavedGoogleAccounts, 
  removeSavedGoogleAccount, 
  SavedGoogleAccount 
} from '../lib/cloudAuth';

export interface AccountViewProps {
  state: AppState;
  onUpdateSettings: (newSettings: AppState['settings']) => void;
  onClearAllData: () => void;
  userProfile?: UserProfile | null;
  onSignIn?: (name?: string, email?: string) => Promise<void>;
  onSignOut?: () => void;
  onSyncNow?: () => Promise<void>;
  onRestoreFromCloud?: () => Promise<void>;
  isSyncing?: boolean;
  lastSyncAt?: number;
  onOpenSupportModal?: () => void;
  onChangeLanguage?: (lang: SupportedLanguage) => void;
}

export type AccountSection = 'hub' | 'profile' | 'data' | 'appearance' | 'ai' | 'about';

export const AccountView: React.FC<AccountViewProps> = ({
  state,
  onUpdateSettings,
  onClearAllData,
  userProfile,
  onSignIn,
  onSignOut,
  onSyncNow,
  onRestoreFromCloud,
  isSyncing = false,
  lastSyncAt,
  onOpenSupportModal,
  onChangeLanguage,
}) => {
  const [activeSection, setActiveSection] = useState<AccountSection>('hub');
  
  // Profile edit state
  const [studentName, setStudentName] = useState(userProfile?.displayName || state.settings.userName || '');
  const [studentEmail, setStudentEmail] = useState(userProfile?.email || '');
  const [isSigningIn, setIsSigningIn] = useState(false);
  const [authNotice, setAuthNotice] = useState<string | null>(null);
  const [savedAccounts, setSavedAccounts] = useState<SavedGoogleAccount[]>([]);

  useEffect(() => {
    setSavedAccounts(getSavedGoogleAccounts());
  }, [userProfile]);

  // Appearance & Language state
  const [currentLang, setCurrentLang] = useState<SupportedLanguage>(getStoredLanguage());
  const [theme, setTheme] = useState<'light' | 'dark'>(state.settings.theme || 'light');
  const [academicLevel, setAcademicLevel] = useState<string>(
    localStorage.getItem('almoallim_academic_level') || 'university'
  );
  const [learningStyle, setLearningStyle] = useState<string>(
    localStorage.getItem('almoallim_learning_style') || 'detailed'
  );
  const [sound, setSound] = useState(state.settings.sound || 'chime');
  const [savedSettingsToast, setSavedSettingsToast] = useState(false);
  const [isConfirmClearOpen, setIsConfirmClearOpen] = useState(false);
  const [copiedEmail, setCopiedEmail] = useState(false);

  // AI Provider State
  const fallbackSettings = state.settings.fallbackAI || {
    enabled: true,
    activeProvider: 'auto',
    providerName: 'OpenAI / Groq / OpenRouter',
    apiKey: '',
    baseUrl: 'https://api.openai.com/v1',
    model: 'gpt-4o-mini',
    geminiApiKey: '',
    geminiModel: 'gemini-3.8-flash',
  };

  const [activeProvider, setActiveProvider] = useState<'auto' | 'gemini' | 'fallback'>(
    fallbackSettings.activeProvider || 'auto'
  );
  const [geminiApiKey, setGeminiApiKey] = useState<string>(fallbackSettings.geminiApiKey || '');
  const [geminiModel, setGeminiModel] = useState<string>(fallbackSettings.geminiModel || 'gemini-3.8-flash');
  const [fallbackApiKey, setFallbackApiKey] = useState<string>(fallbackSettings.apiKey || '');
  const [fallbackBaseUrl, setFallbackBaseUrl] = useState<string>(
    fallbackSettings.baseUrl || 'https://api.openai.com/v1'
  );
  const [fallbackModel, setFallbackModel] = useState<string>(fallbackSettings.model || 'gpt-4o-mini');
  const [showGeminiKey, setShowGeminiKey] = useState(false);
  const [showFallbackKey, setShowFallbackKey] = useState(false);
  const [testingTarget, setTestingTarget] = useState<'gemini' | 'fallback' | null>(null);
  const [testResult, setTestResult] = useState<{
    success: boolean;
    provider: string;
    message: string;
    sample?: string;
  } | null>(null);

  const supportEmail = 'dyaalhqsbyqa10@gmail.com';

  const handleLanguageChange = (lang: SupportedLanguage) => {
    setCurrentLang(lang);
    setStoredLanguage(lang);
    if (onChangeLanguage) {
      onChangeLanguage(lang);
    }
    setSavedSettingsToast(true);
    setTimeout(() => setSavedSettingsToast(false), 2500);
  };

  const handleThemeChange = (newTheme: 'light' | 'dark') => {
    setTheme(newTheme);
    onUpdateSettings({ ...state.settings, theme: newTheme });
  };

  const handleSaveProfileAndSettings = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    localStorage.setItem('almoallim_academic_level', academicLevel);
    localStorage.setItem('almoallim_learning_style', learningStyle);

    onUpdateSettings({
      ...state.settings,
      userName: studentName.trim() || state.settings.userName,
      theme,
      sound,
      fallbackAI: {
        ...fallbackSettings,
        activeProvider,
        geminiApiKey: geminiApiKey.trim(),
        geminiModel,
        apiKey: fallbackApiKey.trim(),
        baseUrl: fallbackBaseUrl.trim(),
        model: fallbackModel.trim(),
      },
    });

    setSavedSettingsToast(true);
    setTimeout(() => setSavedSettingsToast(false), 3000);
  };

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!onSignIn) return;
    setIsSigningIn(true);
    setAuthNotice(null);
    try {
      await onSignIn(studentName || undefined, studentEmail || undefined);
      setAuthNotice(t('action.copied', currentLang, 'تم تسجيل الدخول وتفعيل المزامنة السحابية بنجاح!'));
      setTimeout(() => setAuthNotice(null), 3500);
    } catch (err: any) {
      setAuthNotice(`تعذر تسجيل الدخول: ${err.message || err}`);
    } finally {
      setIsSigningIn(false);
    }
  };

  const handleTestProvider = async (target: 'gemini' | 'fallback') => {
    setTestingTarget(target);
    setTestResult(null);
    try {
      const res = await fetch('/api/test-provider', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          provider: target,
          apiKey: target === 'gemini' ? geminiApiKey.trim() : fallbackApiKey.trim(),
          baseUrl: fallbackBaseUrl.trim(),
          model: target === 'gemini' ? geminiModel : fallbackModel.trim(),
        }),
      });
      const data = await res.json();
      setTestResult({
        success: data.success,
        provider: data.provider || target,
        message: data.message || (data.success ? 'تم الاتصال بالمزود بنجاح!' : 'فشل الاتصال بالمزود'),
        sample: data.sampleText,
      });
    } catch (e: any) {
      setTestResult({
        success: false,
        provider: target,
        message: e.message || 'خطأ في الاتصال بالخادم المحلي',
      });
    } finally {
      setTestingTarget(null);
    }
  };

  const handleExportBackup = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(state, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `almoallim_backup_${new Date().toISOString().slice(0, 10)}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const sectionsMeta = [
    {
      id: 'profile' as const,
      title: t('account.tab.profile', currentLang, 'الملف الشخصي والمصادقة'),
      description: 'بيانات الطالب، الحسابات المحفوظة، وتسجيل الدخول بـ Google والمزامنة السحابية',
      icon: User,
      color: 'from-teal-600 to-emerald-600',
      badge: userProfile ? 'متصل بـ Google' : 'حساب محلي',
      badgeClass: userProfile ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300' : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300'
    },
    {
      id: 'data' as const,
      title: t('account.tab.data', currentLang, 'البيانات والمزامنة السحابية'),
      description: 'النسخ الاحتياطي الكامل، تحميل التطبيق كملف منفرد HTML، وإدارة المحتوى وتصفيره',
      icon: Database,
      color: 'from-cyan-600 to-teal-600',
      badge: `${state.notebooks.length} دفاتر • ${state.sources.length} مصادر`,
      badgeClass: 'bg-teal-100 text-teal-800 dark:bg-teal-950 dark:text-teal-300'
    },
    {
      id: 'appearance' as const,
      title: t('account.tab.appearance', currentLang, 'اللغة والمظهر والتعلم'),
      description: 'تغيير لغة التطبيق الفورية كاملة (عربي/إنجليزي)، الوضع الليلي/النهاري، والمستوى الأكاديمي',
      icon: Globe,
      color: 'from-indigo-600 to-blue-600',
      badge: `${currentLang.toUpperCase()} • ${theme === 'dark' ? 'الوضع الليلي' : 'الوضع النهاري'}`,
      badgeClass: 'bg-indigo-100 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-300'
    },
    {
      id: 'ai' as const,
      title: t('account.tab.ai', currentLang, 'تفضيلات الذكاء الاصطناعي'),
      description: 'التناوب الذكي التلقائي لمفاتيح Gemini الرسمية، وإمكانية إضافة مفاتيح ونماذج مخصصة',
      icon: Sparkles,
      color: 'from-purple-600 to-pink-600',
      badge: activeProvider === 'auto' ? 'تناوب تلقائي نشط' : activeProvider,
      badgeClass: 'bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300'
    },
    {
      id: 'about' as const,
      title: t('account.tab.about', currentLang, 'عن المنصة وتواصل مع المطور'),
      description: 'معلومات فريق D.CORE الذكي، البريد المباشر للمطور، وإرسال الملاحظات من داخل التطبيق',
      icon: Award,
      color: 'from-amber-600 to-orange-600',
      badge: 'دعم فني مباشر',
      badgeClass: 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
    },
  ];

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12 animate-in fade-in duration-200">
      {/* If in Hub Mode: Show Clean Category Cards Grid */}
      {activeSection === 'hub' ? (
        <div className="space-y-6">
          {/* Top Header Card */}
          <section className="bg-white dark:bg-[#14201c] rounded-3xl border border-slate-200/80 dark:border-[#22352f] p-5 sm:p-6 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-teal-700 to-emerald-600 text-white flex items-center justify-center font-black text-2xl shadow-md shadow-teal-700/20 shrink-0">
                {userProfile?.displayName ? userProfile.displayName.charAt(0) : '✦'}
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h1 className="text-lg sm:text-xl font-black text-slate-900 dark:text-slate-100">
                    {t('account.title', currentLang, 'حسابي وإعدادات المنصة')}
                  </h1>
                  {userProfile ? (
                    <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/70 text-emerald-800 dark:text-emerald-300 text-[10px] font-bold border border-emerald-300/60 dark:border-emerald-800/60 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                      <span>{userProfile.displayName}</span>
                    </span>
                  ) : (
                    <span className="px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-[#1a2924] text-slate-600 dark:text-slate-300 text-[10px] font-bold">
                      حساب محلي
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  اختر من البطاقات أدناه للانتقال المباشر إلى القسم المراد بوضوح وتنظيم كامل.
                </p>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="flex items-center gap-2 self-start sm:self-center shrink-0">
              {onSyncNow && userProfile && (
                <button
                  type="button"
                  onClick={onSyncNow}
                  disabled={isSyncing}
                  className="px-3.5 py-2 rounded-xl bg-teal-50 dark:bg-teal-950/50 hover:bg-teal-100 dark:hover:bg-teal-900/40 text-teal-800 dark:text-teal-300 border border-teal-200 dark:border-teal-800 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-2xs"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin text-teal-600' : ''}`} />
                  <span>{isSyncing ? 'مزامنة...' : 'مزامنة السحابة'}</span>
                </button>
              )}

              <a
                href="/al-muallem-al-dhaki-complete.html"
                download="al-muallem-al-dhaki-complete.html"
                className="px-3.5 py-2 rounded-xl bg-teal-700 hover:bg-teal-800 text-white text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
                title="تحميل ملف HTML المتكامل للتشغيل المباشر دون إنترنت"
              >
                <Download className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">تحميل Single-File HTML</span>
              </a>
            </div>
          </section>

          {/* Section Category Rectangular Cards (Non-stacked, click navigates to independent sub-view) */}
          <section className="space-y-3">
            <div className="flex items-center justify-between px-1">
              <h2 className="text-xs font-black text-slate-700 dark:text-slate-300 uppercase tracking-wider flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-teal-600"></span>
                <span>أقسام الإعدادات والتحكم المستقلة</span>
              </h2>
              <span className="text-[11px] text-slate-400">انقر على أي قسم لفتحه</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              {sectionsMeta.map((sec) => {
                const Icon = sec.icon;
                return (
                  <div
                    key={sec.id}
                    onClick={() => setActiveSection(sec.id)}
                    className="p-4 sm:p-5 rounded-2xl bg-white dark:bg-[#14201c] border border-slate-200/90 dark:border-[#22352f] hover:border-teal-500 dark:hover:border-teal-400 hover:shadow-md transition-all cursor-pointer group flex items-center justify-between gap-4 active:scale-[0.99]"
                  >
                    <div className="flex items-center gap-3.5 min-w-0">
                      <div className={`w-12 h-12 rounded-xl bg-gradient-to-tr ${sec.color} text-white flex items-center justify-center shrink-0 shadow-md group-hover:scale-105 transition-transform`}>
                        <Icon className="w-6 h-6" />
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <h3 className="font-extrabold text-sm sm:text-base text-slate-900 dark:text-slate-100 group-hover:text-teal-600 dark:group-hover:text-teal-400 transition-colors truncate">
                            {sec.title}
                          </h3>
                        </div>
                        <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-1 mt-0.5">
                          {sec.description}
                        </p>
                        <div className="mt-2">
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${sec.badgeClass}`}>
                            {sec.badge}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="p-2 rounded-xl bg-slate-50 dark:bg-[#1a2723] text-slate-400 group-hover:text-teal-600 dark:group-hover:text-teal-400 group-hover:bg-teal-50 dark:group-hover:bg-teal-950/60 transition-all shrink-0">
                      <ArrowLeft className="w-5 h-5 rtl:rotate-0 ltr:rotate-180" />
                    </div>
                  </div>
                );
              })}
            </div>
          </section>

          {/* Quick PWA & Storage badge */}
          <div className="p-4 rounded-3xl bg-slate-50/70 dark:bg-[#121c18] border border-slate-200/60 dark:border-[#1d2d27] flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-right">
            <div className="text-xs text-slate-600 dark:text-slate-300 font-semibold">
              <span>الإصدار الأكاديمي 2026 • تشفير وحماية IndexedDB • إمكانية العمل بدون إنترنت</span>
            </div>
            <PWAInstallButton variant="sidebar" />
          </div>
        </div>
      ) : (
        /* DEDICATED INDEPENDENT SUB-VIEW FOR THE SELECTED CATEGORY */
        <div className="space-y-6">
          {/* Top Return Bar Inside The Sub-View */}
          <div className="bg-white dark:bg-[#14201c] rounded-2xl border border-slate-200/80 dark:border-[#22352f] p-4 flex items-center justify-between shadow-2xs">
            <button
              type="button"
              onClick={() => setActiveSection('hub')}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-teal-50 hover:bg-teal-100 dark:bg-teal-950/60 dark:hover:bg-teal-900/60 text-teal-800 dark:text-teal-200 text-xs font-black transition cursor-pointer border border-teal-200 dark:border-teal-800"
            >
              <ArrowRight className="w-4 h-4 rtl:rotate-0 ltr:rotate-180" />
              <span>‹ العودة لقائمة الإعدادات الرئيسية</span>
            </button>

            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-500 dark:text-slate-400">
                {sectionsMeta.find((s) => s.id === activeSection)?.title}
              </span>
            </div>
          </div>

          {/* SUB-VIEW 1: Profile & Google Auth */}
          {activeSection === 'profile' && (
            <div className="bg-white dark:bg-[#14201c] rounded-3xl border border-slate-200/80 dark:border-[#22352f] p-6 sm:p-7 space-y-6 shadow-xs animate-in fade-in duration-150">
              <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
                <div>
                  <h3 className="text-base font-black text-slate-800 dark:text-slate-100">
                    {t('account.tab.profile', currentLang, 'الملف الشخصي والمصادقة')}
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    إدارة بيانات حساب الطالب، تسجيل الدخول، وحفظ المجلدات سحابياً.
                  </p>
                </div>
                <div className="w-10 h-10 rounded-2xl bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 flex items-center justify-center font-black">
                  <User className="w-5 h-5" />
                </div>
              </div>

              {authNotice && (
                <div className="p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300/80 dark:border-emerald-800 text-xs text-emerald-800 dark:text-emerald-200 flex items-center gap-2 animate-in fade-in">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>{authNotice}</span>
                </div>
              )}

              {userProfile ? (
                /* Authenticated User Status */
                <div className="space-y-4">
                  <div className="p-4 rounded-2xl bg-slate-50 dark:bg-[#172420] border border-slate-200/70 dark:border-[#20342d] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="flex items-center gap-3.5">
                      {userProfile.photoURL ? (
                        <img
                          src={userProfile.photoURL}
                          alt={userProfile.displayName}
                          className="w-14 h-14 rounded-2xl object-cover border-2 border-teal-600 shadow-sm"
                        />
                      ) : (
                        <div className="w-14 h-14 rounded-2xl bg-teal-700 text-white font-black text-2xl flex items-center justify-center shadow-xs">
                          {userProfile.displayName.charAt(0)}
                        </div>
                      )}
                      <div>
                        <h4 className="font-extrabold text-sm text-slate-900 dark:text-slate-100">
                          {userProfile.displayName}
                        </h4>
                        <p className="text-xs text-slate-500 font-mono mt-0.5">
                          {userProfile.email || 'حساب مفعل'}
                        </p>
                        <div className="flex items-center gap-2 mt-1.5 text-[11px] text-teal-700 dark:text-teal-400">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>المزامنة السحابية نشطة وتعمل تلقائياً</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      {onSignOut && (
                        <button
                          type="button"
                          onClick={onSignOut}
                          className="px-4 py-2 rounded-xl bg-rose-50 dark:bg-rose-950/50 hover:bg-rose-100 dark:hover:bg-rose-900/60 text-rose-700 dark:text-rose-300 border border-rose-200/80 dark:border-rose-900/80 text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5"
                        >
                          <LogOut className="w-3.5 h-3.5" />
                          <span>{t('action.signOut', currentLang, 'تسجيل الخروج')}</span>
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Cloud status metrics */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                    <div className="p-3.5 rounded-2xl bg-teal-50/50 dark:bg-teal-950/20 border border-teal-200/60 dark:border-teal-800/40 text-xs space-y-1">
                      <span className="font-bold text-teal-800 dark:text-teal-200 flex items-center gap-1.5">
                        <Cloud className="w-4 h-4 text-teal-600" />
                        <span>حالة النسخ الاحتياطي السحابي</span>
                      </span>
                      <p className="text-slate-500 dark:text-slate-400 text-[11px]">
                        آخر مزامنة: {lastSyncAt ? new Date(lastSyncAt).toLocaleString('ar-SA') : 'منذ قليل'}
                      </p>
                    </div>

                    <div className="p-3.5 rounded-2xl bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-200/60 dark:border-emerald-800/40 text-xs space-y-1">
                      <span className="font-bold text-emerald-800 dark:text-emerald-200 flex items-center gap-1.5">
                        <Shield className="w-4 h-4 text-emerald-600" />
                        <span>حماية البيانات</span>
                      </span>
                      <p className="text-slate-500 dark:text-slate-400 text-[11px]">
                        تشفير عالي الأمان لجميع المستندات والملاحظات
                      </p>
                    </div>
                  </div>
                </div>
              ) : (
                /* Dynamic Google Login / Account Selector */
                <div className="space-y-4">
                  {/* Saved accounts on this device */}
                  {savedAccounts.length > 0 && (
                    <div className="p-4 rounded-2xl bg-teal-50/60 dark:bg-teal-950/30 border border-teal-500/30 dark:border-teal-500/20 shadow-xs space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-teal-800 dark:text-teal-300 flex items-center gap-1.5">
                          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                          <span>اختر أحد حسابات Google المحفوظة على هذا الجهاز:</span>
                        </span>
                        <span className="text-[10px] text-slate-500 dark:text-slate-400 font-mono">
                          Google Identity
                        </span>
                      </div>

                      <div className="space-y-2">
                        {savedAccounts.map((acc) => (
                          <div
                            key={acc.email}
                            onClick={() => {
                              setStudentName(acc.displayName);
                              setStudentEmail(acc.email);
                              if (onSignIn) onSignIn(acc.displayName, acc.email);
                            }}
                            className="flex items-center justify-between p-3 rounded-xl bg-white dark:bg-[#14201c] hover:bg-teal-50/60 dark:hover:bg-[#1a2d26] border border-slate-200/80 dark:border-[#22352f] hover:border-teal-500/50 transition cursor-pointer group"
                          >
                            <div className="flex items-center gap-3 min-w-0">
                              {acc.photoURL ? (
                                <img
                                  src={acc.photoURL}
                                  alt={acc.displayName}
                                  className="w-10 h-10 rounded-xl object-cover shrink-0 border border-teal-500/30"
                                />
                              ) : (
                                <div className="w-10 h-10 rounded-xl bg-teal-700 text-white font-bold flex items-center justify-center text-sm shadow-xs shrink-0">
                                  {acc.displayName.slice(0, 2)}
                                </div>
                              )}
                              <div className="text-right min-w-0">
                                <div className="text-xs font-bold text-slate-800 dark:text-slate-100 truncate">
                                  {acc.displayName}
                                </div>
                                <div className="text-[11px] text-slate-500 dark:text-slate-400 font-mono truncate">
                                  {acc.email}
                                </div>
                              </div>
                            </div>

                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                const updated = removeSavedGoogleAccount(acc.email);
                                setSavedAccounts(updated);
                              }}
                              title="إزالة الحساب من هذا الجهاز"
                              className="p-1.5 text-slate-400 hover:text-red-500 rounded-lg hover:bg-red-50 dark:hover:bg-red-950/30 transition opacity-60 group-hover:opacity-100"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Sign-in / Add Account Form */}
                  <form onSubmit={handleLoginSubmit} className="p-4 rounded-2xl bg-white dark:bg-[#16231f] border border-slate-200/80 dark:border-[#22352f] shadow-xs space-y-3">
                    <div className="flex items-center gap-2 mb-1">
                      <div className="w-6 h-6 rounded-lg bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-400 flex items-center justify-center">
                        <User className="w-3.5 h-3.5" />
                      </div>
                      <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                        {savedAccounts.length > 0 ? 'أو تسجيل الدخول بحساب Google آخر:' : 'تسجيل الدخول بحساب Google (Gmail):'}
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                          اسم الطالب أو الباحث
                        </label>
                        <input
                          type="text"
                          value={studentName}
                          onChange={(e) => setStudentName(e.target.value)}
                          placeholder="الاسم الكامل"
                          className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-[#243932] bg-slate-50/60 dark:bg-[#121c18] text-xs font-medium text-slate-900 dark:text-slate-100 focus:outline-none focus:border-teal-600 transition"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                          بريد Google (Gmail) *
                        </label>
                        <input
                          type="email"
                          required
                          value={studentEmail}
                          onChange={(e) => setStudentEmail(e.target.value)}
                          placeholder="username@gmail.com"
                          className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-[#243932] bg-slate-50/60 dark:bg-[#121c18] text-xs font-medium text-slate-900 dark:text-slate-100 focus:outline-none focus:border-teal-600 font-mono transition"
                        />
                      </div>
                    </div>

                    <div className="flex items-center justify-end gap-2 pt-2">
                      <button
                        type="submit"
                        disabled={isSigningIn || !studentEmail.trim()}
                        className="w-full sm:w-auto px-6 py-2.5 bg-teal-700 hover:bg-teal-800 disabled:opacity-50 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2.5 cursor-pointer transition shadow-sm"
                      >
                        <svg className="w-4 h-4 shrink-0 bg-white rounded-full p-0.5" viewBox="0 0 24 24">
                          <path
                            fill="#4285F4"
                            d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                          />
                          <path
                            fill="#34A853"
                            d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                          />
                          <path
                            fill="#FBBC05"
                            d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                          />
                          <path
                            fill="#EA4335"
                            d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                          />
                        </svg>
                        <span>{isSigningIn ? 'جاري الاتصال السحابي...' : 'تسجيل الدخول بحساب Google ومزامنة البيانات'}</span>
                      </button>
                    </div>
                  </form>
                </div>
              )}
            </div>
          )}

          {/* SUB-VIEW 2: Data & Cloud Sync */}
          {activeSection === 'data' && (
            <div className="bg-white dark:bg-[#14201c] rounded-3xl border border-slate-200/80 dark:border-[#22352f] p-6 sm:p-7 space-y-6 shadow-xs animate-in fade-in duration-150">
              <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
                <div>
                  <h3 className="text-base font-black text-slate-800 dark:text-slate-100">
                    {t('account.tab.data', currentLang, 'البيانات والمزامنة السحابية')}
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    إحصائيات المحتوى، النسخ الاحتياطي، تنزيل ملف التطبيق كملف واحد، واستعادة البيانات.
                  </p>
                </div>
                <div className="w-10 h-10 rounded-2xl bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 flex items-center justify-center font-black">
                  <Database className="w-5 h-5" />
                </div>
              </div>

              {/* Data Metrics Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-[#16231f] border border-slate-200/70 dark:border-[#20332c] text-center">
                  <div className="text-xl font-black text-teal-700 dark:text-teal-300">
                    {state.notebooks.length}
                  </div>
                  <div className="text-[11px] text-slate-500 font-medium mt-0.5">دفاتر دراسية</div>
                </div>

                <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-[#16231f] border border-slate-200/70 dark:border-[#20332c] text-center">
                  <div className="text-xl font-black text-teal-700 dark:text-teal-300">
                    {state.sources.length}
                  </div>
                  <div className="text-[11px] text-slate-500 font-medium mt-0.5">مصادر ومناهج</div>
                </div>

                <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-[#16231f] border border-slate-200/70 dark:border-[#20332c] text-center">
                  <div className="text-xl font-black text-teal-700 dark:text-teal-300">
                    {state.chatSessions.length}
                  </div>
                  <div className="text-[11px] text-slate-500 font-medium mt-0.5">محادثات محفوظة</div>
                </div>

                <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-[#16231f] border border-slate-200/70 dark:border-[#20332c] text-center">
                  <div className="text-xl font-black text-teal-700 dark:text-teal-300">
                    {(state.notes?.length || 0) + (state.flashcards?.length || 0)}
                  </div>
                  <div className="text-[11px] text-slate-500 font-medium mt-0.5">ملخصات وبطاقات</div>
                </div>
              </div>

              {/* Standalone Single-File HTML Download Card */}
              <div className="p-5 rounded-3xl bg-gradient-to-r from-teal-50 via-emerald-50 to-teal-50 dark:from-teal-950/40 dark:via-emerald-950/30 dark:to-teal-950/40 border border-teal-200/80 dark:border-teal-800/60 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-2xs">
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="text-xs sm:text-sm font-black text-teal-900 dark:text-teal-200">
                      {t('account.singleFileHtml', currentLang, 'ملف التطبيق المتكامل كملف واحد (Single-File HTML)')}
                    </h4>
                    <span className="px-2 py-0.5 rounded-full bg-teal-600 text-white text-[10px] font-bold">
                      تشغيل مباشر 100%
                    </span>
                  </div>
                  <p className="text-[11px] text-teal-800/80 dark:text-teal-300/80 mt-1 max-w-xl leading-relaxed">
                    {t('account.singleFileDesc', currentLang, 'نسخة مجمعة كاملة لكل ملفات الكود والواجهات والخطوط في ملف HTML واحد يعمل بضغطة زر على أي جهاز أو متصفح بدون إنترنت.')}
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <a
                    href="/al-muallem-al-dhaki-complete.html"
                    download="al-muallem-al-dhaki-complete.html"
                    className="px-4 py-2.5 bg-teal-700 hover:bg-teal-800 text-white rounded-2xl text-xs font-bold flex items-center gap-2 cursor-pointer transition shadow-xs active:scale-95"
                  >
                    <Download className="w-4 h-4" />
                    <span>تنزيل ملف HTML المتكامل</span>
                  </a>
                </div>
              </div>

              {/* Backup & Restore Tools */}
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-[#16231f] border border-slate-200/70 dark:border-[#20332c] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200">
                    تصدير نسخة احتياطية كاملة (JSON)
                  </h4>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    احفظ كافة دفاتر المذاكرة وملاحظاتك ومصادرك في ملف آمن على جهازك.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={handleExportBackup}
                  className="px-4 py-2 bg-white dark:bg-[#121c18] hover:bg-slate-100 dark:hover:bg-[#182622] text-slate-700 dark:text-slate-200 rounded-xl text-xs font-bold flex items-center gap-2 cursor-pointer transition shadow-2xs border border-slate-200 dark:border-[#22352f]"
                >
                  <Download className="w-4 h-4 text-teal-600" />
                  <span>تنزيل ملف النسخة الاحتياطية</span>
                </button>
              </div>

              {/* Danger Zone: Clear Data */}
              <div className="p-4 rounded-2xl bg-rose-50/70 dark:bg-rose-950/30 border border-rose-200/80 dark:border-rose-900/60 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h4 className="text-xs font-black text-rose-800 dark:text-rose-200">
                    منطقة العمليات الحساسة (تصفير البيانات)
                  </h4>
                  <p className="text-[11px] text-rose-700/80 dark:text-rose-300/80 mt-0.5">
                    حذف كافة الدفاتر والمصادر المحلية واستعادة الحالة الأولية للمنصة.
                  </p>
                </div>

                {!isConfirmClearOpen ? (
                  <button
                    type="button"
                    onClick={() => setIsConfirmClearOpen(true)}
                    className="px-3.5 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold cursor-pointer transition shadow-xs self-start sm:self-auto"
                  >
                    تصفير البيانات
                  </button>
                ) : (
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        onClearAllData();
                        setIsConfirmClearOpen(false);
                      }}
                      className="px-3.5 py-2 bg-rose-700 hover:bg-rose-800 text-white rounded-xl text-xs font-black cursor-pointer"
                    >
                      تأكيد الحذف نهائياً
                    </button>
                    <button
                      type="button"
                      onClick={() => setIsConfirmClearOpen(false)}
                      className="px-3 py-2 bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-bold cursor-pointer"
                    >
                      إلغاء
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* SUB-VIEW 3: Language, Theme & Learning */}
          {activeSection === 'appearance' && (
            <div className="bg-white dark:bg-[#14201c] rounded-3xl border border-slate-200/80 dark:border-[#22352f] p-6 sm:p-7 space-y-6 shadow-xs animate-in fade-in duration-150">
              <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
                <div>
                  <h3 className="text-base font-black text-slate-800 dark:text-slate-100">
                    {t('account.tab.appearance', currentLang, 'اللغة والمظهر والتعلم')}
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    تخصيص لغة الواجهة الفورية (i18n)، نمط الألوان، والمستوى الأكاديمي.
                  </p>
                </div>
                <div className="w-10 h-10 rounded-2xl bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 flex items-center justify-center font-black">
                  <Globe className="w-5 h-5" />
                </div>
              </div>

              {savedSettingsToast && (
                <div className="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 text-xs text-emerald-800 dark:text-emerald-200 flex items-center gap-2 animate-in fade-in">
                  <CheckCheck className="w-4 h-4 text-emerald-600" />
                  <span>تم تطبيق التفضيلات بنجاح!</span>
                </div>
              )}

              {/* 1. Instant Multi-Language Switcher */}
              <div className="space-y-3">
                <div>
                  <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200">
                    {t('account.language', currentLang, 'لغة واجهة التطبيق')}
                  </h4>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    {t('account.languageDesc', currentLang, 'اختر اللغة المفضلة لعرض كافة قوائم وأدوات التطبيق فوراً وبدقة RTL/LTR.')}
                  </p>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                  {SUPPORTED_LANGUAGES.map((lang) => {
                    const isSelected = currentLang === lang.code;
                    return (
                      <button
                        key={lang.code}
                        type="button"
                        onClick={() => handleLanguageChange(lang.code)}
                        className={`p-3 rounded-2xl border text-right transition-all flex items-center justify-between cursor-pointer ${
                          isSelected
                            ? 'border-teal-600 bg-teal-50/80 dark:bg-teal-950/50 text-teal-900 dark:text-teal-200 shadow-xs font-bold'
                            : 'border-slate-200/80 dark:border-[#22352f] bg-slate-50/50 dark:bg-[#16231f] text-slate-700 dark:text-slate-300 hover:border-teal-400'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <span className="text-lg">{lang.flag}</span>
                          <div>
                            <div className="text-xs font-bold">{lang.nativeName}</div>
                            <div className="text-[10px] text-slate-400">{lang.name} ({lang.dir.toUpperCase()})</div>
                          </div>
                        </div>
                        {isSelected && <Check className="w-4 h-4 text-teal-600" />}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* 2. Theme Selection */}
              <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-3">
                <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200">
                  {t('account.themeTitle', currentLang, 'مظهر الواجهة والألوان')}
                </h4>
                <div className="grid grid-cols-2 gap-3 max-w-md">
                  <button
                    type="button"
                    onClick={() => handleThemeChange('light')}
                    className={`p-3.5 rounded-2xl border flex items-center gap-2.5 transition-all cursor-pointer ${
                      theme === 'light'
                        ? 'border-teal-600 bg-teal-50/60 dark:bg-teal-950/40 text-teal-900 dark:text-teal-200 shadow-2xs font-bold'
                        : 'border-slate-200 dark:border-[#22352f] text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <Sun className="w-4 h-4 text-amber-500" />
                    <span className="text-xs font-bold">{t('action.themeLight', currentLang, 'الوضع النهاري')}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleThemeChange('dark')}
                    className={`p-3.5 rounded-2xl border flex items-center gap-2.5 transition-all cursor-pointer ${
                      theme === 'dark'
                        ? 'border-teal-600 bg-teal-50/60 dark:bg-teal-950/40 text-teal-900 dark:text-teal-200 shadow-2xs font-bold'
                        : 'border-slate-200 dark:border-[#22352f] text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <Moon className="w-4 h-4 text-teal-400" />
                    <span className="text-xs font-bold">{t('action.themeDark', currentLang, 'الوضع الليلي')}</span>
                  </button>
                </div>
              </div>

              {/* 3. Academic Level & Learning Style */}
              <div className="pt-4 border-t border-slate-100 dark:border-slate-800 grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    {t('account.academicLevel', currentLang, 'المستوى الدراسي')}
                  </label>
                  <select
                    value={academicLevel}
                    onChange={(e) => setAcademicLevel(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-xs rounded-2xl border border-slate-200 dark:border-[#22352f] bg-slate-50/60 dark:bg-[#121c18] text-slate-800 dark:text-slate-100 focus:outline-none focus:border-teal-600"
                  >
                    <option value="university">جامعي وبحث علمي متقدم</option>
                    <option value="secondary">المرحلة الثانوية والبكالوريا</option>
                    <option value="intermediate">المرحلة المتوسطة / الإعدادية</option>
                    <option value="self_learner">باحث مستقل / تعلم ذاتي</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    {t('account.learningStyle', currentLang, 'أسلوب الشرح وتفضيل الاستيعاب')}
                  </label>
                  <select
                    value={learningStyle}
                    onChange={(e) => setLearningStyle(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-xs rounded-2xl border border-slate-200 dark:border-[#22352f] bg-slate-50/60 dark:bg-[#121c18] text-slate-800 dark:text-slate-100 focus:outline-none focus:border-teal-600"
                  >
                    <option value="detailed">أكاديمي عميق ومفصل مع كافة القوانين والأمثلة</option>
                    <option value="concise">ملخصات سريعة ونقاط مكثفة للامتحان</option>
                    <option value="problem_solving">التركيز على المسائل وحلول التمارين خطوة بخطوة</option>
                  </select>
                </div>
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="button"
                  onClick={handleSaveProfileAndSettings}
                  className="px-6 py-2.5 bg-teal-700 hover:bg-teal-800 text-white rounded-2xl text-xs font-bold transition shadow-xs cursor-pointer"
                >
                  {t('action.save', currentLang, 'حفظ وتطبيق التغييرات')}
                </button>
              </div>
            </div>
          )}

          {/* SUB-VIEW 4: AI Preferences */}
          {activeSection === 'ai' && (
            <div className="bg-white dark:bg-[#14201c] rounded-3xl border border-slate-200/80 dark:border-[#22352f] p-6 sm:p-7 space-y-6 shadow-xs animate-in fade-in duration-150">
              <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
                <div>
                  <h3 className="text-base font-black text-slate-800 dark:text-slate-100">
                    {t('account.tab.ai', currentLang, 'محرك الذكاء الاصطناعي')}
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    نظام التناوب الذكي لمفاتيح Google Gemini وخيارات النماذج البديلة.
                  </p>
                </div>
                <div className="w-10 h-10 rounded-2xl bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 flex items-center justify-center font-black">
                  <Sparkles className="w-5 h-5" />
                </div>
              </div>

              {/* Server Key Rotation Badge */}
              <div className="p-4 rounded-2xl bg-emerald-50/60 dark:bg-emerald-950/30 border border-emerald-300/60 dark:border-emerald-800/60 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                    <span className="font-extrabold text-xs text-emerald-900 dark:text-emerald-200">
                      محرك Google Gemini الرسمي متصل ونشط
                    </span>
                  </div>
                  <span className="text-[10px] px-2 py-0.5 rounded-md bg-emerald-200/60 dark:bg-emerald-900/60 text-emerald-900 dark:text-emerald-200 font-bold font-mono">
                    3 مفاتيح بنظام التناوب
                  </span>
                </div>
                <p className="text-[11px] text-emerald-800/80 dark:text-emerald-300/80 leading-relaxed">
                  تم دمج وتأمين مفاتيح الذكاء الاصطناعي الرسمية الثلاثة بنظام التناوب الذكي وتفادي الحصص تلقائياً بواسطة فريق D.CORE. يعمل التطبيق بكامل طاقته العلمية فوراً.
                </p>
              </div>

              {/* Mode Selection: Auto / Custom Gemini / Fallback */}
              <div className="space-y-3">
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                  وضع عمل الذكاء الاصطناعي
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  <button
                    type="button"
                    onClick={() => setActiveProvider('auto')}
                    className={`p-3 rounded-2xl border text-right transition cursor-pointer ${
                      activeProvider === 'auto'
                        ? 'border-teal-600 bg-teal-50/60 dark:bg-teal-950/40 text-teal-900 dark:text-teal-200 shadow-2xs font-bold'
                        : 'border-slate-200 dark:border-[#22352f] text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <div className="text-xs font-bold mb-1">تلقائي فائق السرعة</div>
                    <p className="text-[10px] text-slate-500 leading-snug">تناوب سحابي ذكي ومجاني 100%</p>
                  </button>

                  <button
                    type="button"
                    onClick={() => setActiveProvider('gemini')}
                    className={`p-3 rounded-2xl border text-right transition cursor-pointer ${
                      activeProvider === 'gemini'
                        ? 'border-teal-600 bg-teal-50/60 dark:bg-teal-950/40 text-teal-900 dark:text-teal-200 shadow-2xs font-bold'
                        : 'border-slate-200 dark:border-[#22352f] text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <div className="text-xs font-bold mb-1">مفتاح Gemini مخصص</div>
                    <p className="text-[10px] text-slate-500 leading-snug">استخدام مفتاح Google الخاص بك</p>
                  </button>

                  <button
                    type="button"
                    onClick={() => setActiveProvider('fallback')}
                    className={`p-3 rounded-2xl border text-right transition cursor-pointer ${
                      activeProvider === 'fallback'
                        ? 'border-teal-600 bg-teal-50/60 dark:bg-teal-950/40 text-teal-900 dark:text-teal-200 shadow-2xs font-bold'
                        : 'border-slate-200 dark:border-[#22352f] text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <div className="text-xs font-bold mb-1">مزود بديل (Groq / OpenAI)</div>
                    <p className="text-[10px] text-slate-500 leading-snug">متوافق مع DeepSeek أو Llama</p>
                  </button>
                </div>
              </div>

              {/* Custom Gemini input */}
              {activeProvider === 'gemini' && (
                <div className="p-4 rounded-2xl bg-slate-50 dark:bg-[#16231f] border border-slate-200 dark:border-[#22352f] space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-teal-800 dark:text-teal-300">
                      إعدادات مفتاح Google Gemini
                    </span>
                    <button
                      type="button"
                      onClick={() => handleTestProvider('gemini')}
                      disabled={testingTarget === 'gemini'}
                      className="px-3 py-1 bg-teal-600 hover:bg-teal-700 text-white rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer"
                    >
                      {testingTarget === 'gemini' ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Zap className="w-3.5 h-3.5" />}
                      <span>فحص المفتاح</span>
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-bold text-slate-500 mb-1">مفتاح API Key</label>
                      <div className="relative">
                        <input
                          type={showGeminiKey ? 'text' : 'password'}
                          placeholder="AIzaSy..."
                          value={geminiApiKey}
                          onChange={(e) => setGeminiApiKey(e.target.value)}
                          className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#121b18] focus:outline-none focus:border-teal-600 pl-8 font-mono"
                        />
                        <button
                          type="button"
                          onClick={() => setShowGeminiKey(!showGeminiKey)}
                          className="absolute left-2.5 top-2.5 text-slate-400 hover:text-slate-600"
                        >
                          {showGeminiKey ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-slate-500 mb-1">النموذج المحدد</label>
                      <select
                        value={geminiModel}
                        onChange={(e) => setGeminiModel(e.target.value)}
                        className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#121b18] focus:outline-none focus:border-teal-600"
                      >
                        <option value="gemini-3.8-flash">gemini-3.8-flash (الأسرع والأدق علمياً)</option>
                        <option value="gemini-flash-latest">gemini-flash-latest</option>
                        <option value="gemini-3.1-flash-lite">gemini-3.1-flash-lite (اقتصادي)</option>
                      </select>
                    </div>
                  </div>
                </div>
              )}

              {/* Provider test result */}
              {testResult && (
                <div
                  className={`p-3.5 rounded-2xl border text-xs leading-relaxed flex items-center gap-2 ${
                    testResult.success
                      ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-300 text-emerald-800 dark:text-emerald-200'
                      : 'bg-rose-50 dark:bg-rose-950/60 border-rose-300 text-rose-800 dark:text-rose-200'
                  }`}
                >
                  {testResult.success ? <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" /> : <Server className="w-4 h-4 text-rose-600 shrink-0" />}
                  <div>
                    <strong>{testResult.message}</strong>
                    {testResult.sample && <p className="text-[11px] opacity-80 mt-0.5 font-mono">{testResult.sample}</p>}
                  </div>
                </div>
              )}

              <div className="flex justify-end pt-2">
                <button
                  type="button"
                  onClick={handleSaveProfileAndSettings}
                  className="px-6 py-2.5 bg-teal-700 hover:bg-teal-800 text-white rounded-2xl text-xs font-bold transition shadow-xs cursor-pointer"
                >
                  حفظ تفضيلات الذكاء الاصطناعي
                </button>
              </div>
            </div>
          )}

          {/* SUB-VIEW 5: About & Developer */}
          {activeSection === 'about' && (
            <div className="bg-white dark:bg-[#14201c] rounded-3xl border border-slate-200/80 dark:border-[#22352f] p-6 sm:p-7 space-y-6 shadow-xs animate-in fade-in duration-150">
              <div className="flex items-center gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-500 via-amber-600 to-teal-700 text-white flex items-center justify-center shadow-lg shadow-amber-600/20 shrink-0">
                  <Mail className="w-7 h-7" />
                </div>
                <div>
                  <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950 text-amber-900 dark:text-amber-200 text-[10px] font-black border border-amber-300 dark:border-amber-800 mb-1">
                    <span>قناة الاتصال المباشرة بالمطور</span>
                  </div>
                  <h3 className="text-lg font-black text-slate-900 dark:text-slate-100">
                    تواصل مباشر مع مطور «المعلم الذكي»
                  </h3>
                  <p className="text-xs text-slate-600 dark:text-slate-300 mt-0.5">
                    نسعد باستقبال كافة اقتراحاتكم، ملاحظاتكم، طلبات الميزات الجديدة، وتقارير التحسين.
                  </p>
                </div>
              </div>

              {/* Developer Attribution Card */}
              <div className="p-5 rounded-2xl bg-slate-50 dark:bg-[#16231f] border border-slate-200/80 dark:border-[#22352f] space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-[11px] font-bold text-slate-400">فريق التصميم والتطوير:</span>
                    <h4 className="text-base font-black text-teal-800 dark:text-teal-300">
                      فريق D.CORE الذكي
                    </h4>
                    <p className="text-xs text-slate-700 dark:text-slate-300 font-semibold mt-0.5">
                      منصة المعلم الذكي للدراسة والبحث العلمي المتقدم
                    </p>
                  </div>
                  <Award className="w-8 h-8 text-amber-500 shrink-0" />
                </div>
              </div>

              {/* Email Contact Card */}
              <div className="bg-slate-50 dark:bg-[#16231f] rounded-2xl p-5 border border-slate-200/80 dark:border-[#22352f] shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="space-y-1">
                  <span className="text-[11px] font-bold text-slate-400">البريد الإلكتروني للدعم الفني والتواصل:</span>
                  <div className="text-sm sm:text-base font-black text-teal-800 dark:text-teal-300 font-mono tracking-wide flex items-center gap-2">
                    <span>{supportEmail}</span>
                    {copiedEmail && (
                      <span className="text-[11px] font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-950 px-2 py-0.5 rounded-md">
                        ✓ تم النسخ
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      navigator.clipboard.writeText(supportEmail);
                      setCopiedEmail(true);
                      setTimeout(() => setCopiedEmail(false), 2500);
                    }}
                    className="px-4 py-2 bg-white dark:bg-[#121c18] hover:bg-slate-100 dark:hover:bg-[#182622] text-slate-700 dark:text-slate-200 rounded-xl text-xs font-bold border border-slate-200 dark:border-slate-800 flex items-center gap-1.5 transition cursor-pointer"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>نسخ البريد</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => onOpenSupportModal?.()}
                    className="px-4 py-2 bg-teal-700 hover:bg-teal-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition shadow-xs cursor-pointer"
                  >
                    <Mail className="w-3.5 h-3.5" />
                    <span>إرسال رسالة من داخل التطبيق</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
