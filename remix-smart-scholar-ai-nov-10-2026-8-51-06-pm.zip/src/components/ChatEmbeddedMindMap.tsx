import React, { useState } from 'react';
import { 
  GitFork, 
  ZoomIn, 
  ZoomOut, 
  RotateCcw, 
  Maximize2, 
  X,
  Sparkles,
  ChevronRight,
  ChevronDown
} from 'lucide-react';

export interface MindMapTreeNode {
  title: string;
  notes?: string;
  badge?: string;
  children?: MindMapTreeNode[];
}

export interface ChatEmbeddedMindMapProps {
  data: MindMapTreeNode;
  title?: string;
}

export const ChatEmbeddedMindMap: React.FC<ChatEmbeddedMindMapProps> = ({
  data,
  title,
}) => {
  const [zoomLevel, setZoomLevel] = useState(1);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [collapsedNodes, setCollapsedNodes] = useState<{ [key: string]: boolean }>({});

  const toggleCollapse = (nodeKey: string) => {
    setCollapsedNodes((prev) => ({ ...prev, [nodeKey]: !prev[nodeKey] }));
  };

  const handleZoomIn = (e: React.MouseEvent) => {
    e.stopPropagation();
    setZoomLevel((prev) => Math.min(1.8, prev + 0.15));
  };

  const handleZoomOut = (e: React.MouseEvent) => {
    e.stopPropagation();
    setZoomLevel((prev) => Math.max(0.65, prev - 0.15));
  };

  const handleResetZoom = (e: React.MouseEvent) => {
    e.stopPropagation();
    setZoomLevel(1);
  };

  // Render tree hierarchy visually
  const renderNodeHierarchy = (node: MindMapTreeNode, pathKey: string, level: number = 0) => {
    const hasChildren = node.children && node.children.length > 0;
    const isCollapsed = collapsedNodes[pathKey];

    const levelColors = [
      'border-teal-500 bg-teal-50/90 dark:bg-teal-950/60 text-teal-950 dark:text-teal-100 shadow-teal-500/10',
      'border-emerald-500 bg-emerald-50/90 dark:bg-emerald-950/50 text-emerald-950 dark:text-emerald-100 shadow-emerald-500/10',
      'border-cyan-500 bg-cyan-50/90 dark:bg-cyan-950/50 text-cyan-950 dark:text-cyan-100 shadow-cyan-500/10',
      'border-slate-400 bg-slate-50/90 dark:bg-slate-900/60 text-slate-800 dark:text-slate-200',
    ];
    const colorClass = levelColors[Math.min(level, levelColors.length - 1)];

    return (
      <div key={pathKey} className="flex flex-col relative my-1 text-right">
        {/* Node card */}
        <div
          onClick={() => hasChildren && toggleCollapse(pathKey)}
          className={`flex items-start gap-2 p-2 sm:p-2.5 rounded-xl border text-xs leading-relaxed transition-all select-none ${
            hasChildren ? 'cursor-pointer hover:scale-[1.01]' : ''
          } ${colorClass} max-w-full shadow-2xs`}
        >
          {hasChildren && (
            <button
              type="button"
              className="p-0.5 rounded-md text-teal-600 dark:text-teal-400 hover:bg-black/5 dark:hover:bg-white/5 mt-0.5 shrink-0"
              aria-label="طي أو توسيع الفرع"
            >
              {isCollapsed ? <ChevronRight className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </button>
          )}

          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className={`font-bold ${level === 0 ? 'text-sm text-teal-800 dark:text-teal-200' : 'text-xs'}`}>
                {node.title}
              </span>
              {node.badge && (
                <span className="text-[10px] px-1.5 py-0.2 rounded-md bg-white/70 dark:bg-black/40 font-mono text-teal-700 dark:text-teal-300">
                  {node.badge}
                </span>
              )}
            </div>
            {node.notes && (
              <p className="text-[11px] text-slate-600 dark:text-slate-300 mt-0.5 leading-normal">
                {node.notes}
              </p>
            )}
          </div>
        </div>

        {/* Children branch with connecting visual line */}
        {hasChildren && !isCollapsed && (
          <div className="pr-4 sm:pr-6 border-r-2 border-teal-500/25 dark:border-teal-500/20 mr-3 my-1 space-y-1">
            {node.children!.map((child, idx) =>
              renderNodeHierarchy(child, `${pathKey}-${idx}`, level + 1)
            )}
          </div>
        )}
      </div>
    );
  };

  return (
    <>
      <div 
        className="my-3.5 w-full max-w-full rounded-2xl border border-teal-500/30 dark:border-teal-500/20 bg-slate-50/90 dark:bg-[#0f1916] overflow-hidden shadow-xs relative isolate text-right"
        dir="rtl"
      >
        {/* Header toolbar */}
        <div className="px-3.5 py-2.5 bg-white/80 dark:bg-[#14231e] border-b border-teal-500/15 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-teal-600 text-white flex items-center justify-center shrink-0">
              <GitFork className="w-3.5 h-3.5" />
            </div>
            <div>
              <span className="text-xs font-bold text-slate-800 dark:text-slate-100">
                {title || data.title || 'خريطة المفاهيم الذهنية'}
              </span>
              <span className="text-[10px] text-teal-600 dark:text-teal-400 mr-2 font-mono">
                [مخطط هيكلي تفاعلي]
              </span>
            </div>
          </div>

          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={handleZoomIn}
              className="p-1 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors"
              title="تكبير"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={handleZoomOut}
              className="p-1 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors"
              title="تصغير"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={handleResetZoom}
              className="p-1 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors"
              title="إعادة الضبط"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => setIsModalOpen(true)}
              className="p-1 rounded-lg text-teal-600 dark:text-teal-400 hover:bg-teal-50 dark:hover:bg-teal-950/50 transition-colors"
              title="عرض بكامل الشاشة"
            >
              <Maximize2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Scalable Container - Strictly contained inside bubble */}
        <div 
          className="p-3 sm:p-4 overflow-x-auto max-w-full max-h-[380px] overflow-y-auto"
          style={{ transformOrigin: 'top right' }}
        >
          <div style={{ zoom: zoomLevel }}>
            {renderNodeHierarchy(data, 'root', 0)}
          </div>
        </div>
      </div>

      {/* Fullscreen Modal View */}
      {isModalOpen && (
        <div 
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200"
          dir="rtl"
        >
          <div className="bg-white dark:bg-[#121c19] w-full max-w-4xl max-h-[90vh] rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col overflow-hidden">
            <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <GitFork className="w-5 h-5 text-teal-600" />
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  {title || data.title || 'خريطة المفاهيم والروابط'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 rounded-xl text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-4 sm:p-6 overflow-y-auto flex-1">
              {renderNodeHierarchy(data, 'modal-root', 0)}
            </div>
          </div>
        </div>
      )}
    </>
  );
};
