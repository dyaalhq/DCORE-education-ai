import React, { useState, useMemo, useEffect } from 'react';
import {
  BookOpen,
  Search,
  Sparkles,
  Volume2,
  VolumeX,
  FileText,
  Printer,
  ChevronLeft,
  ChevronRight,
  Clock,
  Tag,
  Share2,
  ExternalLink,
  Layers,
  Compass,
  CheckCircle,
  ArrowRight,
  Shuffle,
  PlusCircle,
  SlidersHorizontal,
  Bookmark,
  BookmarkCheck,
  Globe2,
  Hash,
  ListTree,
  ZoomIn,
  ZoomOut,
  Send
} from 'lucide-react';
import { EncyclopediaArticle, offlineDb } from '../lib/offlineDatabase';
import {
  COMPREHENSIVE_ENCYCLOPEDIA_ARTICLES,
  searchEncyclopediaOffline,
  createDynamicWikipediaArticle
} from '../lib/encyclopediaData';
import { SafeMathText } from './SafeMathText';
import { speakText, stopSpeaking } from '../lib/studySpeechEngine';
import { AcademicPrintModal } from './AcademicPrintModal';
import { extractStructuredSummary, StructuredSummary } from '../lib/academicFormatter';
import { knowledgeResolver } from '../lib/knowledgeResolver';

interface EncyclopedicReaderProps {
  onSaveAsNote?: (title: string, content: string) => void;
  onAskAiAboutTopic?: (topicTitle: string, context: string) => void;
}

export const EncyclopedicReader: React.FC<EncyclopedicReaderProps> = ({
  onSaveAsNote,
  onAskAiAboutTopic,
}) => {
  const [allArticles, setAllArticles] = useState<EncyclopediaArticle[]>(COMPREHENSIVE_ENCYCLOPEDIA_ARTICLES);
  const [selectedArticle, setSelectedArticle] = useState<EncyclopediaArticle | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('الكل');
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [savedNoteSuccess, setSavedNoteSuccess] = useState(false);
  const [fontSizeLevel, setFontSizeLevel] = useState<number>(1); // 0: sm, 1: base, 2: lg, 3: xl

  // New Article Modal State
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [newArticlePrompt, setNewArticlePrompt] = useState('');
  const [isGeneratingArticle, setIsGeneratingArticle] = useState(false);
  const [generationToast, setGenerationToast] = useState('');

  // Academic Print Modal state
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);
  const [printSummary, setPrintSummary] = useState<StructuredSummary | null>(null);

  // Load any user-generated or cached encyclopedia articles from IndexedDB
  useEffect(() => {
    let isMounted = true;
    (async () => {
      try {
        const dbArticles = await offlineDb.encyclopedia.toArray();
        if (isMounted && dbArticles && dbArticles.length > 0) {
          // Merge avoiding ID collisions
          setAllArticles((prev) => {
            const existingIds = new Set(prev.map((a) => a.id));
            const fresh = dbArticles.filter((a) => !existingIds.has(a.id));
            return [...prev, ...fresh];
          });
        }
      } catch (err) {
        console.warn('Could not read cached encyclopedia articles from IndexedDB:', err);
      }
    })();
    return () => { isMounted = false; };
  }, []);

  // Compute Categories with article counts
  const categoriesWithCounts = useMemo(() => {
    const counts: Record<string, number> = { 'الكل': allArticles.length };
    allArticles.forEach((a) => {
      counts[a.category] = (counts[a.category] || 0) + 1;
    });
    return counts;
  }, [allArticles]);

  const categoryList = useMemo(() => {
    return Object.keys(categoriesWithCounts);
  }, [categoriesWithCounts]);

  // Filtered Articles
  const filteredArticles = useMemo(() => {
    let list = allArticles;
    if (searchQuery.trim()) {
      const q = searchQuery.trim().toLowerCase();
      list = list.filter((a) => (
        a.title.toLowerCase().includes(q) ||
        a.summary.toLowerCase().includes(q) ||
        a.category.toLowerCase().includes(q) ||
        a.markdownContent.toLowerCase().includes(q) ||
        a.keyConcepts.some((k) => k.toLowerCase().includes(q)) ||
        a.tags.some((t) => t.toLowerCase().includes(q))
      ));
    }
    if (selectedCategory !== 'الكل') {
      list = list.filter((a) => a.category === selectedCategory);
    }
    return list;
  }, [allArticles, searchQuery, selectedCategory]);

  // Extract Table of Contents from selected article markdown
  const articleSections = useMemo(() => {
    if (!selectedArticle) return [];
    const lines = selectedArticle.markdownContent.split('\n');
    const sections: { id: string; title: string; level: number }[] = [];

    lines.forEach((line) => {
      const h3Match = line.match(/^###\s+(.+)$/);
      const h4Match = line.match(/^####\s+(.+)$/);
      if (h3Match) {
        const cleanTitle = h3Match[1].replace(/[*_`]/g, '').trim();
        sections.push({
          id: cleanTitle.replace(/\s+/g, '-'),
          title: cleanTitle,
          level: 3,
        });
      } else if (h4Match) {
        const cleanTitle = h4Match[1].replace(/[*_`]/g, '').trim();
        sections.push({
          id: cleanTitle.replace(/\s+/g, '-'),
          title: cleanTitle,
          level: 4,
        });
      }
    });

    return sections;
  }, [selectedArticle]);

  // Related Articles (same or neighboring categories)
  const relatedArticles = useMemo(() => {
    if (!selectedArticle) return [];
    return allArticles
      .filter((a) => a.id !== selectedArticle.id && (a.category === selectedArticle.category || a.tags.some((t) => selectedArticle.tags.includes(t))))
      .slice(0, 3);
  }, [selectedArticle, allArticles]);

  // Open Random Article (like Wikipedia Random Page)
  const handleRandomArticle = () => {
    if (allArticles.length === 0) return;
    const randomIndex = Math.floor(Math.random() * allArticles.length);
    setSelectedArticle(allArticles[randomIndex]);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Audio Speech Synthesis for Article
  const handleToggleSpeech = () => {
    if (!selectedArticle) return;

    if (isSpeaking) {
      stopSpeaking();
      setIsSpeaking(false);
    } else {
      const textToRead = `${selectedArticle.title}. ${selectedArticle.summary}. المفاهيم الأساسية: ${selectedArticle.keyConcepts.join('، ')}.`;
      speakText(textToRead, {
        title: selectedArticle.title,
        speed: 1.0,
        onStart: () => setIsSpeaking(true),
        onEnd: () => setIsSpeaking(false),
        onError: () => setIsSpeaking(false),
      });
    }
  };

  const handleSaveToNote = () => {
    if (!selectedArticle || !onSaveAsNote) return;
    const noteTitle = `موسوعة ويكيبيديا: ${selectedArticle.title}`;
    const noteContent = `
# ${selectedArticle.title}
**المجال:** ${selectedArticle.category} — ${selectedArticle.subCategory || ''}
**الملخص التوثيقي:** ${selectedArticle.summary}

${selectedArticle.formulaLatex ? `### القانون الرياضي الحاكم:\n$$${selectedArticle.formulaLatex}$$\n` : ''}

### المفاهيم الجوهرية (Key Concepts):
${selectedArticle.keyConcepts.map((k) => `- ${k}`).join('\n')}

---
${selectedArticle.markdownContent}

### المراجع والمصادر الأكاديمية:
${selectedArticle.references.map((r) => `- ${r}`).join('\n')}
`.trim();

    onSaveAsNote(noteTitle, noteContent);
    setSavedNoteSuccess(true);
    setTimeout(() => setSavedNoteSuccess(false), 2500);
  };

  const handleOpenPrintModal = () => {
    if (!selectedArticle) return;
    const summary = extractStructuredSummary(
      selectedArticle.markdownContent,
      selectedArticle.title,
      selectedArticle.category
    );
    summary.documentTitle = selectedArticle.title;
    setPrintSummary(summary);
    setIsPrintModalOpen(true);
  };

  // Instant Academic Term Resolution using Gemini Knowledge Resolver with local persistence
  const handleInstantResolve = async (termToResolve: string) => {
    const query = termToResolve.trim();
    if (!query) return;

    setIsGeneratingArticle(true);
    setGenerationToast(`جارٍ تحضير المرجع الأكاديمي لـ «${query}»...`);

    try {
      const article = await knowledgeResolver.resolve(query, {
        categoryHint: selectedCategory !== 'الكل' ? selectedCategory : undefined,
        onStatusUpdate: (msg) => setGenerationToast(msg),
      });

      setAllArticles((prev) => {
        const filtered = prev.filter((a) => a.id !== article.id);
        return [article, ...filtered];
      });
      setSelectedArticle(article);
      setIsCreateModalOpen(false);
      setNewArticlePrompt('');
      setGenerationToast('');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (err: any) {
      console.warn('Knowledge Resolver fallback:', err);
      // Fallback: Generate local synthesis
      const localArticle = createDynamicWikipediaArticle(
        query,
        selectedCategory !== 'الكل' ? selectedCategory : 'الموسوعة المعرفية العامة'
      );
      try {
        await offlineDb.encyclopedia.put(localArticle);
      } catch (dbErr) {
        console.warn('Could not save to Dexie:', dbErr);
      }
      setAllArticles((prev) => [localArticle, ...prev.filter((a) => a.id !== localArticle.id)]);
      setSelectedArticle(localArticle);
      setIsCreateModalOpen(false);
      setNewArticlePrompt('');
      setGenerationToast('');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } finally {
      setIsGeneratingArticle(false);
    }
  };

  // Generate / Expand Wikipedia Article Form Submit
  const handleGenerateWikipediaArticle = async (e: React.FormEvent) => {
    e.preventDefault();
    await handleInstantResolve(newArticlePrompt);
  };

  const fontSizeClasses = [
    'text-xs leading-relaxed',
    'text-sm leading-relaxed',
    'text-base leading-relaxed',
    'text-lg leading-relaxed'
  ];

  return (
    <div className="space-y-5 pb-28" dir="rtl">
      {/* ========================================================= */}
      {/* 1. COMPACT WIKIPEDIA HERO HEADER */}
      {/* ========================================================= */}
      <div className="bg-gradient-to-l from-slate-950 via-teal-950 to-emerald-950 text-white rounded-2xl sm:rounded-3xl p-4 sm:p-6 shadow-md border border-teal-500/30 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-64 h-64 bg-teal-500/10 rounded-full blur-3xl -translate-x-16 -translate-y-16 pointer-events-none" />
        <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-3.5">
          <div className="space-y-1.5 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-2.5 py-0.5 rounded-full bg-white/10 backdrop-blur-md text-teal-200 text-[11px] font-bold border border-white/15">
              <Globe2 className="w-3.5 h-3.5 text-teal-300" />
              <span>الموسوعة الحرة الأكاديمية (Gemini Knowledge Resolver)</span>
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            </div>
            <h1 className="text-xl sm:text-2xl lg:text-3xl font-black tracking-tight text-white flex items-center gap-2.5">
              <BookOpen className="w-6 h-6 sm:w-8 sm:h-8 text-teal-300" />
              <span>الموسوعة العلمية وويكيبيديا الأكاديمية</span>
            </h1>
            <p className="text-xs text-teal-100/90 leading-relaxed line-clamp-2 sm:line-clamp-none">
              المرجع المعرفي الموثق: آلاف المفاهيم والمقالات الأكاديمية في كافة التخصصات والعلوم مع دعم LaTeX وصناديق المعلومات والمراجع المعتمدة (تعمل 100% بدون نت).
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={handleRandomArticle}
              className="px-3 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold border border-white/20 flex items-center gap-1.5 cursor-pointer shadow-xs transition-all active:scale-95"
              title="عرض مقالة عشوائية من الموسوعة"
            >
              <Shuffle className="w-3.5 h-3.5 text-amber-300" />
              <span>عشوائية 🎲</span>
            </button>

            <button
              type="button"
              onClick={() => setIsCreateModalOpen(true)}
              className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-600 hover:to-emerald-600 text-slate-950 text-xs font-black flex items-center gap-1.5 cursor-pointer shadow-md transition-all active:scale-95"
              title="إنشاء أو طلب مقالة جديدة بالذكاء الاصطناعي"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              <span>توثيق مصطلح ⚡</span>
            </button>
          </div>
        </div>
      </div>

      {/* ========================================================= */}
      {/* 2. ARTICLE READER VIEW OR WIKIPEDIA DIRECTORY GRID */}
      {/* ========================================================= */}
      {selectedArticle ? (
        <div className="bg-white dark:bg-[#121c19] rounded-3xl border border-slate-200 dark:border-[#22352f] shadow-sm overflow-hidden animate-in fade-in duration-200">
          {/* Top Article Toolbar */}
          <div className="p-4 sm:p-5 bg-slate-50 dark:bg-[#152320] border-b border-slate-200 dark:border-[#22352f] flex flex-wrap items-center justify-between gap-3 sticky top-0 z-20 backdrop-blur-md">
            <button
              type="button"
              onClick={() => {
                if (isSpeaking) window.speechSynthesis.cancel();
                setIsSpeaking(false);
                setSelectedArticle(null);
              }}
              className="px-4 py-2 rounded-xl bg-white dark:bg-[#1a2925] border border-slate-200 dark:border-[#22352f] text-slate-700 dark:text-slate-200 text-xs font-bold hover:bg-slate-100 dark:hover:bg-[#223631] flex items-center gap-2 cursor-pointer shadow-xs transition-colors"
            >
              <ArrowRight className="w-4 h-4 text-teal-600" />
              <span>العودة لدليل مقالات ويكيبيديا</span>
            </button>

            <div className="flex flex-wrap items-center gap-2">
              {/* Font Size Adjuster */}
              <div className="flex items-center gap-1 bg-white dark:bg-[#1a2925] p-1 rounded-xl border border-slate-200 dark:border-[#22352f] text-xs">
                <button
                  type="button"
                  onClick={() => setFontSizeLevel((prev) => Math.max(0, prev - 1))}
                  disabled={fontSizeLevel === 0}
                  className="px-2 py-1 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 disabled:opacity-40 cursor-pointer"
                  title="تصغير الخط"
                >
                  <ZoomOut className="w-3.5 h-3.5" />
                </button>
                <span className="text-[11px] font-bold px-1 font-mono">A</span>
                <button
                  type="button"
                  onClick={() => setFontSizeLevel((prev) => Math.min(3, prev + 1))}
                  disabled={fontSizeLevel === 3}
                  className="px-2 py-1 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 disabled:opacity-40 cursor-pointer"
                  title="تكبير الخط"
                >
                  <ZoomIn className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Text-to-Speech */}
              <button
                type="button"
                onClick={handleToggleSpeech}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer border ${
                  isSpeaking
                    ? 'bg-amber-500 text-white border-amber-600 animate-pulse'
                    : 'bg-white dark:bg-[#1a2925] text-slate-700 dark:text-slate-200 border-slate-200 dark:border-[#22352f] hover:bg-slate-100'
                }`}
                title="قراءة صوتية للملخص والمفاهيم"
              >
                {isSpeaking ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-teal-600" />}
                <span>{isSpeaking ? 'إيقاف' : 'استماع صوتي'}</span>
              </button>

              {/* Save to Student Notes */}
              <button
                type="button"
                onClick={handleSaveToNote}
                className="px-3 py-1.5 rounded-xl bg-white dark:bg-[#1a2925] border border-slate-200 dark:border-[#22352f] text-teal-700 dark:text-teal-300 text-xs font-bold hover:bg-teal-50 flex items-center gap-1.5 cursor-pointer shadow-xs"
              >
                <FileText className="w-4 h-4" />
                <span>{savedNoteSuccess ? 'تم الحفظ في الدفتر' : 'حفظ في الدفتر'}</span>
              </button>

              {/* Print Summary */}
              <button
                type="button"
                onClick={handleOpenPrintModal}
                className="px-3 py-1.5 rounded-xl bg-teal-700 hover:bg-teal-800 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs"
              >
                <Printer className="w-4 h-4" />
                <span>تصدير و PDF</span>
              </button>

              {/* AI Discussion */}
              {onAskAiAboutTopic && (
                <button
                  type="button"
                  onClick={() => onAskAiAboutTopic(selectedArticle.title, selectedArticle.summary)}
                  className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-teal-600 to-emerald-600 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs hover:opacity-95"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>سؤال المعلم AI</span>
                </button>
              )}
            </div>
          </div>

          {/* Article Layout (2 Columns on large screens: Content + Wikipedia Infobox) */}
          <div className="p-5 sm:p-8 max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Main Content (8 Columns) */}
            <div className="lg:col-span-8 space-y-6">
              {/* Breadcrumb & Header */}
              <div className="space-y-2 border-b border-slate-200 dark:border-[#22352f] pb-5">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="px-3 py-1 rounded-full bg-teal-100 dark:bg-teal-950 text-teal-800 dark:text-teal-300 text-xs font-bold">
                    {selectedArticle.category}
                  </span>
                  {selectedArticle.subCategory && (
                    <span className="text-xs text-slate-500 dark:text-slate-400">
                      • {selectedArticle.subCategory}
                    </span>
                  )}
                  <span className="text-xs text-slate-400 font-mono flex items-center gap-1 mr-auto">
                    <Clock className="w-3.5 h-3.5" />
                    <span>{selectedArticle.readingTimeMinutes} دقائق قراءة</span>
                  </span>
                </div>

                <h1 className="text-2xl sm:text-4xl font-black text-slate-900 dark:text-slate-100 leading-snug">
                  {selectedArticle.title}
                </h1>

                <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 leading-relaxed font-medium">
                  {selectedArticle.summary}
                </p>
              </div>

              {/* Quick Table of Contents (فهرس المحتويات) */}
              {articleSections.length > 0 && (
                <div className="p-4 rounded-2xl bg-slate-50 dark:bg-[#152320] border border-slate-200 dark:border-[#22352f] space-y-2">
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-800 dark:text-slate-200">
                    <ListTree className="w-4 h-4 text-teal-600" />
                    <span>فهرس المحتويات السريع:</span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 text-xs">
                    {articleSections.map((sec, idx) => (
                      <a
                        key={idx}
                        href={`#${sec.id}`}
                        className="text-teal-700 dark:text-teal-300 hover:underline flex items-center gap-1.5 truncate py-0.5"
                      >
                        <span className="font-mono text-slate-400 text-[10px]">{idx + 1}.</span>
                        <span className="truncate">{sec.title}</span>
                      </a>
                    ))}
                  </div>
                </div>
              )}

              {/* Markdown Article Content with KaTeX */}
              <div className={`prose dark:prose-invert max-w-none text-slate-800 dark:text-slate-200 space-y-5 ${fontSizeClasses[fontSizeLevel]}`}>
                <SafeMathText content={selectedArticle.markdownContent} />
              </div>

              {/* References & Citations */}
              {selectedArticle.references && selectedArticle.references.length > 0 && (
                <div className="pt-6 border-t border-slate-200 dark:border-[#22352f] space-y-3">
                  <h4 className="text-xs font-black text-slate-700 dark:text-slate-300 uppercase tracking-wider flex items-center gap-2">
                    <Hash className="w-4 h-4 text-teal-600" />
                    <span>المراجع والمصادر العلمية الموثقة (References):</span>
                  </h4>
                  <ul className="text-xs text-slate-600 dark:text-slate-400 space-y-1.5 list-decimal list-inside pr-1">
                    {selectedArticle.references.map((ref, idx) => (
                      <li key={idx} dir="ltr" className="text-left font-mono text-[11px] bg-slate-50 dark:bg-[#152320] p-2 rounded-lg border border-slate-100 dark:border-[#1e322b]">
                        {ref}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Related Articles (مقالات ذات صلة) */}
              {relatedArticles.length > 0 && (
                <div className="pt-6 border-t border-slate-200 dark:border-[#22352f] space-y-3">
                  <h4 className="text-xs font-black text-slate-700 dark:text-slate-300 uppercase tracking-wider flex items-center gap-2">
                    <Globe2 className="w-4 h-4 text-teal-600" />
                    <span>مقالات ويكيبيديا ذات صلة (Related Articles):</span>
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    {relatedArticles.map((rel) => (
                      <button
                        key={rel.id}
                        type="button"
                        onClick={() => {
                          setSelectedArticle(rel);
                          window.scrollTo({ top: 0, behavior: 'smooth' });
                        }}
                        className="p-3 rounded-2xl bg-slate-50 dark:bg-[#152320] border border-slate-200 dark:border-[#22352f] hover:border-teal-500 text-right transition-all cursor-pointer group"
                      >
                        <span className="text-[10px] font-bold text-teal-700 dark:text-teal-400 block mb-1">
                          {rel.category}
                        </span>
                        <h5 className="text-xs font-bold text-slate-900 dark:text-slate-100 group-hover:text-teal-600 line-clamp-2">
                          {rel.title}
                        </h5>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Sidebar Wikipedia Infobox (4 Columns) */}
            <div className="lg:col-span-4 space-y-4">
              <div className="p-5 rounded-3xl bg-slate-50 dark:bg-[#152320] border-2 border-teal-500/30 shadow-md space-y-4 sticky top-20">
                {/* Infobox Header */}
                <div className="text-center pb-3 border-b border-slate-200 dark:border-[#22352f]">
                  <span className="text-[11px] font-mono px-2.5 py-0.5 rounded-full bg-teal-100 dark:bg-teal-950 text-teal-800 dark:text-teal-300 font-bold">
                    صندوق معلومات ويكيبيديا
                  </span>
                  <h3 className="text-base font-black text-slate-900 dark:text-slate-100 mt-2">
                    {selectedArticle.title}
                  </h3>
                </div>

                {/* Formula Block if applicable */}
                {selectedArticle.formulaLatex && (
                  <div className="p-3.5 rounded-2xl bg-white dark:bg-[#1a2925] border border-teal-200 dark:border-teal-900 text-center space-y-1">
                    <span className="text-[11px] font-bold text-teal-800 dark:text-teal-300 block">
                      القانون الحاكم (Mathematical Formula):
                    </span>
                    <div className="text-sm font-bold text-slate-900 dark:text-slate-100">
                      <SafeMathText content={`$$${selectedArticle.formulaLatex}$$`} />
                    </div>
                  </div>
                )}

                {/* Metadata Fields */}
                <div className="text-xs space-y-2.5 divide-y divide-slate-200/60 dark:divide-[#22352f]/60">
                  <div className="flex items-center justify-between pt-1">
                    <span className="text-slate-500 font-bold">المجال:</span>
                    <span className="font-bold text-slate-800 dark:text-slate-200">{selectedArticle.category}</span>
                  </div>
                  {selectedArticle.subCategory && (
                    <div className="flex items-center justify-between pt-2">
                      <span className="text-slate-500 font-bold">التخصص:</span>
                      <span className="font-bold text-slate-800 dark:text-slate-200">{selectedArticle.subCategory}</span>
                    </div>
                  )}
                  <div className="flex items-center justify-between pt-2">
                    <span className="text-slate-500 font-bold">زمن القراءة:</span>
                    <span className="font-bold text-slate-800 dark:text-slate-200">{selectedArticle.readingTimeMinutes} دقيقة</span>
                  </div>
                  <div className="flex items-center justify-between pt-2">
                    <span className="text-slate-500 font-bold">التوثيق:</span>
                    <span className="font-bold text-emerald-600 dark:text-emerald-400">معتمد أكاديمياً (2026)</span>
                  </div>
                </div>

                {/* Key Concepts List */}
                <div className="space-y-2 pt-2 border-t border-slate-200 dark:border-[#22352f]">
                  <div className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                    <Compass className="w-3.5 h-3.5 text-teal-600" />
                    <span>المفاهيم الجوهرية (Key Concepts):</span>
                  </div>
                  <ul className="space-y-1.5 text-xs text-slate-600 dark:text-slate-400">
                    {selectedArticle.keyConcepts.map((k, idx) => (
                      <li key={idx} className="flex items-start gap-1.5 bg-white dark:bg-[#1a2925] p-2 rounded-xl border border-slate-200/70 dark:border-[#22352f]">
                        <span className="w-1.5 h-1.5 rounded-full bg-teal-500 shrink-0 mt-1.5" />
                        <span className="leading-snug">{k}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Tags */}
                <div className="flex flex-wrap gap-1 pt-2">
                  {selectedArticle.tags.map((tag) => (
                    <span key={tag} className="text-[10px] px-2 py-0.5 rounded-md bg-white dark:bg-[#1a2925] text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-[#22352f]">
                      #{tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* ========================================================= */
        /* 3. WIKIPEDIA DIRECTORY & ARTICLE SEARCH GRID */
        /* ========================================================= */
        <div className="space-y-6">
          {/* Search and Category Filter Toolbar */}
          <div className="bg-white dark:bg-[#121c19] p-4 sm:p-5 rounded-2xl sm:rounded-3xl border border-slate-200 dark:border-[#22352f] shadow-sm space-y-3.5">
            <div className="relative">
              <input
                type="text"
                placeholder="ابحث في الموسوعة (مثال: أينشتاين، سد مأرب، كريسبر، كوانتا، تفاضل، ترانسفورمرز، STEMI)..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && searchQuery.trim() && filteredArticles.length === 0) {
                    handleInstantResolve(searchQuery);
                  }
                }}
                className="w-full pl-4 pr-11 py-2.5 sm:py-3 text-sm rounded-xl sm:rounded-2xl bg-slate-50 dark:bg-[#182723] border border-slate-200 dark:border-[#22352f] text-slate-800 dark:text-slate-100 focus:outline-none focus:border-teal-600 shadow-inner"
              />
              <Search className="w-5 h-5 text-slate-400 absolute right-3.5 top-3 sm:top-3.5" />
            </div>

            {/* Quick Knowledge Resolver Trigger & Live Status */}
            {searchQuery.trim().length > 1 && (
              <div className="flex flex-wrap items-center justify-between gap-2 p-2.5 rounded-xl bg-teal-50 dark:bg-teal-950/40 border border-teal-200/60 dark:border-teal-900/60 text-xs">
                <span className="text-teal-900 dark:text-teal-200 font-medium">
                  هل تبحث عن توثيق دقيق لمصطلح «<strong className="font-bold">{searchQuery}</strong>»؟
                </span>
                <button
                  type="button"
                  disabled={isGeneratingArticle}
                  onClick={() => handleInstantResolve(searchQuery)}
                  className="px-3 py-1.5 rounded-lg bg-teal-700 hover:bg-teal-800 text-white font-bold flex items-center gap-1.5 transition-all shadow-xs cursor-pointer disabled:opacity-50"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-spin" />
                  <span>حلل ووثق بالموسوعة ⚡</span>
                </button>
              </div>
            )}

            {isGeneratingArticle && generationToast && (
              <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-300/50 text-amber-900 dark:text-amber-200 text-xs font-bold flex items-center gap-2 animate-pulse">
                <Sparkles className="w-4 h-4 text-amber-600 animate-spin shrink-0" />
                <span>{generationToast}</span>
              </div>
            )}

            {/* Category Chips with Counts */}
            <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-thin">
              {categoryList.map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1.5 sm:px-3.5 sm:py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer flex items-center gap-1.5 border ${
                    selectedCategory === cat
                      ? 'bg-teal-700 border-teal-800 text-white shadow-xs'
                      : 'bg-slate-100 dark:bg-[#1a2723] border-slate-200/80 dark:border-[#22352f] text-slate-700 dark:text-slate-300 hover:bg-slate-200'
                  }`}
                >
                  <span>{cat}</span>
                  <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                    selectedCategory === cat ? 'bg-white/20 text-white' : 'bg-slate-200 dark:bg-[#23352f] text-slate-500 dark:text-slate-400'
                  }`}>
                    {categoriesWithCounts[cat] || 0}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Directory Summary Bar */}
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 px-2 font-medium">
            <span>تم العثور على {filteredArticles.length} مقالة موسوعية محكمة</span>
            <span>تصنيف: {selectedCategory}</span>
          </div>

          {/* Articles Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5">
            {filteredArticles.map((article) => (
              <div
                key={article.id}
                onClick={() => {
                  setSelectedArticle(article);
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="p-5 sm:p-6 rounded-2xl sm:rounded-3xl bg-white dark:bg-[#121c19] border-2 border-slate-200/80 dark:border-[#22352f] hover:border-teal-500 dark:hover:border-teal-600 transition-all shadow-xs hover:shadow-lg cursor-pointer flex flex-col justify-between group"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-lg bg-teal-50 dark:bg-teal-950 text-teal-800 dark:text-teal-300 border border-teal-200/50 dark:border-teal-800/40">
                      {article.category}
                    </span>
                    <span className="text-[11px] text-slate-400 font-mono flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" />
                      <span>{article.readingTimeMinutes} د</span>
                    </span>
                  </div>

                  <h3 className="text-base sm:text-lg font-black text-slate-900 dark:text-slate-100 group-hover:text-teal-600 dark:group-hover:text-teal-400 transition-colors line-clamp-2 leading-snug">
                    {article.title}
                  </h3>

                  <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-3 leading-relaxed">
                    {article.summary}
                  </p>

                  {article.formulaLatex && (
                    <div className="p-2 rounded-xl bg-slate-50 dark:bg-[#1a2925] border border-slate-200/60 dark:border-[#22352f] text-center text-xs text-teal-800 dark:text-teal-300 overflow-x-auto">
                      <SafeMathText content={`$${article.formulaLatex}$`} />
                    </div>
                  )}
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 dark:border-[#1e322b] flex items-center justify-between text-xs font-black text-teal-700 dark:text-teal-400">
                  <span>قراءة المقالة وصندوق المعلومات</span>
                  <ChevronLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
                </div>
              </div>
            ))}
          </div>

          {filteredArticles.length === 0 && (
            <div className="text-center py-12 sm:py-16 bg-white dark:bg-[#121c19] rounded-2xl sm:rounded-3xl border border-slate-200 dark:border-[#22352f] p-6 sm:p-8 space-y-4">
              <BookOpen className="w-12 h-12 text-slate-300 mx-auto" />
              <h3 className="font-bold text-base text-slate-800 dark:text-slate-200">
                لم يتم العثور على مقالات تطابق بحثك «{searchQuery}»
              </h3>
              <p className="text-xs text-slate-500 max-w-md mx-auto leading-relaxed">
                اضغط على الزر أدناه لحل وتوثيق مقالة موسوعية محكمة فورية لهذا المفهوم بالذكاء الاصطناعي (Gemini Knowledge Resolver) وحفظها محلياً في جهازك 100%.
              </p>
              <button
                type="button"
                disabled={isGeneratingArticle}
                onClick={() => handleInstantResolve(searchQuery)}
                className="px-6 py-3 rounded-2xl bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 text-white text-xs font-black transition-all shadow-md cursor-pointer disabled:opacity-50 flex items-center gap-2 mx-auto"
              >
                <Sparkles className="w-4 h-4 text-amber-300" />
                <span>حلل ووثق «{searchQuery}» فوراً بالموسوعة ⚡</span>
              </button>
            </div>
          )}
        </div>
      )}

      {/* ========================================================= */}
      {/* 4. MODAL: CREATE / EXPAND WIKIPEDIA ARTICLE */}
      {/* ========================================================= */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white dark:bg-[#121c19] border border-slate-200 dark:border-[#22352f] rounded-3xl max-w-lg w-full p-6 space-y-5 shadow-2xl relative">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-[#22352f]">
              <div className="flex items-center gap-2">
                <Globe2 className="w-5 h-5 text-teal-600" />
                <h3 className="font-black text-base text-slate-900 dark:text-slate-100">
                  إنشاء مقالة ويكيبيديا أكاديمية جديدة
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsCreateModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              اكتب اسم المفهوم العلمي أو التاريخي أو الطبي أو اللغوي الذي تريد توليد مقالة موسوعية كاملة له بصيغة ويكيبيديا المعتمدة مع صندوق المعلومات والمعادلات والمراجع:
            </p>

            <form onSubmit={handleGenerateWikipediaArticle} className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1.5">
                  عنوان الموضوع أو المفهوم:
                </label>
                <input
                  type="text"
                  required
                  placeholder="مثال: نظرية الأوتار الفائقة، خوارزمية ديكسترا، حمض الفوليك، معركة القادسية..."
                  value={newArticlePrompt}
                  onChange={(e) => setNewArticlePrompt(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm rounded-xl bg-slate-50 dark:bg-[#1a2925] border border-slate-200 dark:border-[#22352f] text-slate-900 dark:text-slate-100 outline-none focus:border-teal-500"
                />
              </div>

              {generationToast && (
                <div className="p-3 rounded-xl bg-teal-50 dark:bg-teal-950/60 border border-teal-300/40 text-teal-800 dark:text-teal-200 text-xs font-bold flex items-center gap-2 animate-in fade-in">
                  <Sparkles className="w-4 h-4 text-teal-600 animate-spin" />
                  <span>{generationToast}</span>
                </div>
              )}

              <div className="flex items-center justify-end gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  disabled={isGeneratingArticle}
                  className="px-4 py-2.5 rounded-xl bg-slate-100 dark:bg-[#1a2925] text-slate-700 dark:text-slate-300 text-xs font-bold cursor-pointer hover:bg-slate-200"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={isGeneratingArticle}
                  className="px-5 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-black shadow-md cursor-pointer disabled:opacity-50 flex items-center gap-1.5"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>{isGeneratingArticle ? 'جارٍ التحرير...' : 'تحرير وتوثيق المقالة'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Academic Print Report Modal */}
      {isPrintModalOpen && printSummary && (
        <AcademicPrintModal
          isOpen={isPrintModalOpen}
          onClose={() => setIsPrintModalOpen(false)}
          summary={printSummary}
        />
      )}
    </div>
  );
};
