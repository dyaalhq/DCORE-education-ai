import React, { useState } from 'react';
import {
  Check,
  Plus,
  Eye,
  ExternalLink,
  Clock,
  CheckSquare,
  Square,
  Loader2,
  AlertCircle,
  Upload
} from 'lucide-react';
import { Source, SourceChunk } from '../types';
import { chunkText } from '../lib/pdfExtractor';
import { parsePDFWithOCR } from '../lib/pdfParser';
import { cleanAndReshapePdfText } from '../lib/arabicReshaper';
import { storeFileBlob } from '../lib/storage';
import { extractPdfDeepLink } from '../lib/deepLinkResolver';

export interface SearchResultItem {
  id?: string;
  title: string;
  uri: string;
  domain?: string;
  category?: string;
  snippet?: string;
  cleanContent?: string;
  subject?: string;
  grade?: string;
  country?: string;
  author?: string;
  date?: string;
  relevanceScore?: number;
}

interface SourceCardProps {
  item: SearchResultItem;
  currentNotebookId: string;
  isAlreadyAdded: boolean;
  isSelected?: boolean;
  onToggleSelect?: (uri: string) => void;
  onPreview?: (item: SearchResultItem) => void;
  onAddSource: (source: Source, chunks: SourceChunk[]) => void;
  onUpdateSource?: (source: Source, chunks?: SourceChunk[]) => void;
  onTriggerUpload?: () => void;
}

export const SourceCard: React.FC<SourceCardProps> = ({
  item,
  currentNotebookId,
  isAlreadyAdded,
  isSelected = false,
  onToggleSelect,
  onPreview,
  onAddSource,
  onUpdateSource,
  onTriggerUpload,
}) => {
  const [isOptimisticallyAdded, setIsOptimisticallyAdded] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadStatus, setDownloadStatus] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string>('');

  const isAdded = isAlreadyAdded || isOptimisticallyAdded;

  const isCurriculum = item.category === 'curriculum';
  const isNotes = item.category === 'notes';
  const isSolutions = item.category === 'solutions';
  const isBook = item.category === 'book';
  const isWiki = item.category === 'wikipedia' || item.domain?.includes('wikipedia');
  const isAcademic = item.category === 'academic' || item.domain?.includes('arxiv');
  const isJournal = item.category === 'journal' || item.domain?.includes('doi.org');

  const handleAddClick = async (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    if (isAdded || isDownloading) return;

    setIsDownloading(true);
    setErrorMessage('');
    setDownloadStatus('جاري جلب الملف الثنائي عبر البروكسي...');

    const sourceId = item.id || `src_pdf_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    const isLikelyPdf = item.category === 'book' || /\.pdf($|[?#])/i.test(item.uri) || /archive\.org\/download|drive\.google/i.test(item.uri);

    try {
      // 1. True Binary Fetching via Proxy Route (ArrayBuffer)
      let buffer: ArrayBuffer | null = null;
      let contentType = '';

      // Try local server proxy endpoint first
      try {
        const proxyUrl = `/api/proxy?url=${encodeURIComponent(item.uri)}`;
        const pRes = await fetch(proxyUrl);
        if (pRes.ok) {
          contentType = pRes.headers.get('content-type') || '';
          buffer = await pRes.arrayBuffer();
        }
      } catch (err) {
        console.warn('Backend proxy fetch failed, trying fallback proxy:', err);
      }

      // Try fallback proxy if needed
      if (!buffer || buffer.byteLength < 500) {
        try {
          const fallbackProxy = `https://corsproxy.io/?${encodeURIComponent(item.uri)}`;
          const fRes = await fetch(fallbackProxy);
          if (fRes.ok) {
            contentType = fRes.headers.get('content-type') || '';
            buffer = await fRes.arrayBuffer();
          }
        } catch (err) {
          console.warn('Fallback proxy failed:', err);
        }
      }

      // 2. Deep Link Resolver: If buffer is HTML, scan DOM tree for direct PDF download links
      let isPdfBinary = buffer && buffer.byteLength >= 5 &&
        new Uint8Array(buffer.slice(0, 5)).reduce((acc, b) => acc + String.fromCharCode(b), '').startsWith('%PDF');

      if (buffer && !isPdfBinary) {
        setDownloadStatus('فحص شجرة DOM للبحث عن رابط تحميل PDF...');
        const html = new TextDecoder('utf-8').decode(buffer);
        const directPdfLink = extractPdfDeepLink(html, item.uri);
        if (directPdfLink) {
          setDownloadStatus('تم العثور على رابط الـ PDF المباشر! جاري تنزيل الملف الثنائي...');
          try {
            const dlRes = await fetch(`/api/proxy?url=${encodeURIComponent(directPdfLink)}`);
            if (dlRes.ok) {
              const dlBuf = await dlRes.arrayBuffer();
              const dlIsPdf = dlBuf.byteLength >= 5 &&
                new Uint8Array(dlBuf.slice(0, 5)).reduce((acc, b) => acc + String.fromCharCode(b), '').startsWith('%PDF');
              if (dlIsPdf) {
                buffer = dlBuf;
                isPdfBinary = true;
              }
            }
          } catch (dlErr) {
            console.warn('Deep link proxy download failed:', dlErr);
          }
        }
      }

      // 3. If binary PDF is ready (%PDF), parse and extract all real pages via PDF.js & OCR
      if (buffer && isPdfBinary) {
        setDownloadStatus('تفكيك كامل صفحات الكتاب عبر PDF.js...');

        const parsed = await parsePDFWithOCR(buffer, (prog) => {
          setDownloadStatus(prog.status);
        });

        if (!parsed.pages || parsed.pages.length === 0 || !parsed.fullText.trim()) {
          throw new Error('الصفحة لا تحتوي على ملف كتاب PDF مباشر، يرجى رفع الملف من جهازك');
        }

        if (parsed.totalPages <= 0 || (!parsed.pages?.length && !parsed.fullText?.trim())) {
          throw new Error('الصفحة لا تحتوي على ملف كتاب PDF مباشر، يرجى رفع الملف من جهازك');
        }

        // Store the real binary blob in IndexedDB for the PDF reader
        const pdfBlob = new Blob([buffer], { type: 'application/pdf' });
        await storeFileBlob(sourceId, pdfBlob);

        // Chunk real pages into Vector Store / RAG
        const realChunks = chunkText(parsed.fullText, sourceId, item.title, currentNotebookId, 750, 75);

        const newSource: Source = {
          id: sourceId,
          notebookId: currentNotebookId,
          title: item.title,
          uri: item.uri,
          type: 'application/pdf',
          size: buffer.byteLength,
          status: 'Ready',
          content: parsed.fullText,
          wordCount: parsed.fullText.split(/\s+/).filter(Boolean).length,
          lineCount: parsed.fullText.split('\n').length,
          pageCount: parsed.totalPages,
          pages: parsed.pages,
          createdAt: Date.now(),
          updatedAt: Date.now(),
        };

        // Add to parent store with real multi-page count
        onAddSource(newSource, realChunks);
        setIsOptimisticallyAdded(true);
        return;
      }

      // 4. Fallback deep crawler via backend /api/fetch-url
      setDownloadStatus('فحص وتنزيل الكتاب عبر المستكشف المتقدم...');
      const res = await fetch('/api/fetch-url', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: item.uri }),
      });

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        throw new Error(errJson.error || 'الصفحة لا تحتوي على ملف كتاب PDF مباشر، يرجى رفع الملف من جهازك');
      }

      const data = await res.json();
      if (data.success === false) {
        throw new Error(data.error || 'الصفحة لا تحتوي على ملف كتاب PDF مباشر، يرجى رفع الملف من جهازك');
      }

      // If backend resolved and extracted a real binary PDF
      if (data.type === 'pdf' || data.dataBase64) {
        setDownloadStatus('فهرسة صفحات الكتاب المستخرج...');
        let arrayBuf: ArrayBuffer;
        if (data.dataBase64) {
          const binaryString = atob(data.dataBase64);
          const bytes = new Uint8Array(binaryString.length);
          for (let i = 0; i < binaryString.length; i++) {
            bytes[i] = binaryString.charCodeAt(i);
          }
          arrayBuf = bytes.buffer;
          const pdfBlob = new Blob([bytes], { type: 'application/pdf' });
          await storeFileBlob(sourceId, pdfBlob);
        } else {
          arrayBuf = new ArrayBuffer(0);
        }

        let parsedPages = Array.isArray(data.pages) && data.pages.length > 0 ? data.pages : [];
        let fullBookText = data.content || data.text || '';
        let totalPageCount = data.pageCount || parsedPages.length;

        // If server provided fewer than 2 pages or missing pages, re-parse directly on client via PDF.js & OCR
        if (arrayBuf.byteLength > 1000 && (parsedPages.length <= 1 || !fullBookText.trim())) {
          try {
            setDownloadStatus('جاري استخراج وتفكيك كافة صفحات الكتاب عبر محرك PDF.js...');
            const clientParsed = await parsePDFWithOCR(arrayBuf, (p) => {
              setDownloadStatus(p.status);
            });
            if (clientParsed.pages && clientParsed.pages.length > 0 && clientParsed.fullText.trim()) {
              parsedPages = clientParsed.pages;
              fullBookText = clientParsed.fullText;
              totalPageCount = clientParsed.totalPages;
            }
          } catch (cErr) {
            console.warn('Client PDF.js parsing fallback in SourceCard:', cErr);
          }
        }

        if (totalPageCount <= 0 && !fullBookText.trim()) {
          throw new Error('الصفحة لا تحتوي على محتوى نصي متاح، يرجى رفع الملف من جهازك');
        }

        const realChunks = chunkText(fullBookText || item.title, sourceId, item.title, currentNotebookId, 750, 75);

        const newSource: Source = {
          id: sourceId,
          notebookId: currentNotebookId,
          title: data.title || item.title,
          uri: item.uri,
          type: 'application/pdf',
          size: data.size || arrayBuf.byteLength || fullBookText.length,
          status: 'Ready',
          content: fullBookText,
          wordCount: data.wordCount || fullBookText.split(/\s+/).filter(Boolean).length,
          lineCount: data.lineCount || fullBookText.split('\n').length,
          pageCount: Math.max(1, totalPageCount),
          pages: parsedPages.length > 0 ? parsedPages : [{ pageNumber: 1, text: fullBookText }],
          createdAt: Date.now(),
          updatedAt: Date.now(),
        };

        onAddSource(newSource, realChunks);
        setIsOptimisticallyAdded(true);
        return;
      }

      // If backend returned web content or articles
      if (data.type === 'web' && (data.content || data.text)) {
        const textContent = data.content || data.text;
        const realChunks = chunkText(textContent, sourceId, item.title, currentNotebookId, 750, 75);
        const newSource: Source = {
          id: sourceId,
          notebookId: currentNotebookId,
          title: data.title || item.title,
          uri: item.uri,
          type: 'text/html',
          size: textContent.length,
          status: 'Ready',
          content: textContent,
          wordCount: textContent.split(/\s+/).filter(Boolean).length,
          lineCount: textContent.split('\n').length,
          pageCount: 1,
          pages: [{ pageNumber: 1, text: textContent }],
          createdAt: Date.now(),
          updatedAt: Date.now(),
        };

        onAddSource(newSource, realChunks);
        setIsOptimisticallyAdded(true);
        return;
      }

      throw new Error('تعذر العثور على محتوى قابل للفهرسة في هذا الرابط، يرجى تزويد رابط مباشر أو رفع الملف من جهازك');
    } catch (err: any) {
      console.warn('PDF addition error:', err);
      setErrorMessage(err.message || 'الصفحة لا تحتوي على ملف كتاب PDF مباشر، يرجى رفع الملف من جهازك');
    } finally {
      setIsDownloading(false);
      setDownloadStatus('');
    }
  };

  return (
    <div
      className={`p-3.5 bg-white dark:bg-[#14201c] border rounded-2xl flex flex-col justify-between gap-3 transition-all ${
        isSelected
          ? 'border-[#0f766e] dark:border-[#2dd4bf] ring-1 ring-[#0f766e] dark:ring-[#2dd4bf] shadow-sm'
          : 'border-[#e2e8e5] dark:border-[#22352f] hover:border-[#b8cbc5] dark:hover:border-[#355249]'
      }`}
    >
      <div className="space-y-2">
        {/* Header Badges */}
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-1.5 flex-wrap">
            {onToggleSelect && (
              <button
                type="button"
                onClick={() => onToggleSelect(item.uri)}
                className="text-gray-400 hover:text-teal-600 focus:outline-none"
              >
                {isSelected ? (
                  <CheckSquare className="w-4 h-4 text-[#0f766e] dark:text-[#2dd4bf]" />
                ) : (
                  <Square className="w-4 h-4 text-gray-400" />
                )}
              </button>
            )}

            {isCurriculum ? (
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-50 text-indigo-700 dark:bg-indigo-950/50 dark:text-indigo-300">
                📚 كتاب مدرسي معتمد
              </span>
            ) : isNotes ? (
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-300">
                📝 ملزمة ومذكرة دراسية
              </span>
            ) : isSolutions ? (
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-50 text-amber-700 dark:bg-amber-950/50 dark:text-amber-300">
                💡 حلول ونماذج امتحانات
              </span>
            ) : isBook ? (
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-50 text-purple-700 dark:bg-purple-950/50 dark:text-purple-300">
                📖 كتاب رقمي موثق
              </span>
            ) : isWiki ? (
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-teal-50 text-teal-700 dark:bg-teal-950/50 dark:text-teal-300">
                📗 موسوعة ويكيبيديا
              </span>
            ) : isAcademic ? (
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-50 text-blue-700 dark:bg-blue-950/50 dark:text-blue-300">
                📘 بحث علمي arXiv
              </span>
            ) : isJournal ? (
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-50 text-rose-700 dark:bg-rose-950/50 dark:text-rose-300">
                📙 دورية محكمة DOI
              </span>
            ) : (
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300">
                🌐 مصدر دراسي موثق
              </span>
            )}

            <span className="text-[10px] text-gray-400 font-mono" dir="ltr">
              {item.domain || 'web'}
            </span>

            {item.relevanceScore !== undefined && item.relevanceScore > 0 && (
              <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                item.relevanceScore >= 85
                  ? 'bg-emerald-50 text-emerald-700 border-emerald-300 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-800'
                  : 'bg-teal-50 text-teal-700 border-teal-300 dark:bg-teal-950/60 dark:text-teal-300 dark:border-teal-800'
              }`}>
                تطابق {item.relevanceScore}%
              </span>
            )}
          </div>

          {item.date && (
            <span className="text-[10px] text-gray-400 flex items-center gap-1">
              <Clock className="w-3 h-3" />
              {item.date}
            </span>
          )}
        </div>

        {/* Title */}
        <h4 className="font-bold text-xs text-[#17201e] dark:text-[#eef7f4] leading-snug line-clamp-2">
          {item.title}
        </h4>

        {/* Grade, Subject, Country Meta Badges */}
        {(item.subject || item.grade || item.country) && (
          <div className="flex flex-wrap items-center gap-1">
            {item.subject && (
              <span className="px-1.5 py-0.5 rounded bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 text-[10px] font-semibold">
                {item.subject}
              </span>
            )}
            {item.grade && (
              <span className="px-1.5 py-0.5 rounded bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 text-[10px] font-semibold">
                {item.grade}
              </span>
            )}
            {item.country && (
              <span className="px-1.5 py-0.5 rounded bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 text-[10px] font-semibold">
                {item.country}
              </span>
            )}
          </div>
        )}

        {/* Author */}
        {item.author && (
          <div className="text-[11px] text-gray-500 dark:text-gray-400 italic">
            المصدر: {item.author}
          </div>
        )}

        {/* Snippet */}
        {item.snippet && (
          <p className="text-xs text-[#596762] dark:text-[#9ab3ab] line-clamp-3 leading-relaxed">
            {item.snippet}
          </p>
        )}
      </div>

      {/* Actions Bar */}
      <div className="pt-2 border-t border-gray-100 dark:border-gray-800/80 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          {onPreview && (
            <button
              type="button"
              onClick={() => onPreview(item)}
              className="px-2 py-1 rounded-lg bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 hover:bg-teal-600 hover:text-white text-[11px] font-bold flex items-center gap-1 cursor-pointer transition-colors shadow-2xs"
              title="معاينة محتوى المصدر كما هو داخل التطبيق"
            >
              <Eye className="w-3.5 h-3.5" />
              <span>معاينة كما هي</span>
            </button>
          )}
          <a
            href={item.uri}
            target="_blank"
            rel="noopener noreferrer"
            className="text-[11px] text-gray-400 hover:text-teal-600 dark:hover:text-teal-300 flex items-center gap-0.5"
            title="زيارة الرابط الأصلي"
          >
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>

        {/* Button State */}
        {isDownloading ? (
          <span className="px-3 py-1 rounded-xl bg-teal-50 dark:bg-teal-950/60 text-[#0f766e] dark:text-[#2dd4bf] text-[11px] font-bold flex items-center gap-1.5 transition-all">
            <Loader2 className="w-3.5 h-3.5 animate-spin text-[#0f766e] dark:text-[#2dd4bf]" />
            <span>{downloadStatus || 'جاري التنزيل...'}</span>
          </span>
        ) : isAdded ? (
          <span className="px-3 py-1 rounded-xl bg-emerald-50 text-emerald-700 dark:bg-emerald-950/70 dark:text-emerald-300 ring-1 ring-emerald-500/30 text-[11px] font-bold flex items-center gap-1.5 transition-all shadow-xs">
            <Check className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 stroke-[2.5]" />
            <span>✓ مضاف لدفترك</span>
          </span>
        ) : (
          <button
            type="button"
            onClick={handleAddClick}
            className="px-3 py-1 bg-[#0f766e] text-white rounded-xl text-[11px] font-bold hover:bg-[#115e59] flex items-center gap-1 shadow-xs cursor-pointer active:scale-95 transition-all"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>إضافة إلى الدفتر</span>
          </button>
        )}
      </div>

      {errorMessage && (
        <div className="mt-1 p-2 rounded-xl bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-900 text-red-700 dark:text-red-300 text-[11px] space-y-1.5">
          <div className="flex items-start gap-1.5">
            <AlertCircle className="w-3.5 h-3.5 text-red-500 shrink-0 mt-0.5" />
            <span>{errorMessage}</span>
          </div>
          {onTriggerUpload && (errorMessage.includes('رفع') || errorMessage.includes('جهازك')) && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onTriggerUpload();
              }}
              className="w-full mt-1 px-2.5 py-1.5 rounded-lg bg-[#0f766e] hover:bg-[#115e59] text-white text-[11px] font-bold flex items-center justify-center gap-1.5 shadow-xs transition-colors cursor-pointer"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>📁 التبديل لرفع ملف الكتاب من هاتفك الآن</span>
            </button>
          )}
        </div>
      )}
    </div>
  );
};
