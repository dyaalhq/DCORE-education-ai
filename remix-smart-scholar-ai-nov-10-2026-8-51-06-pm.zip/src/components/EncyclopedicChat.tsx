import React, { useState, useRef, useEffect } from 'react';
import {
  Send,
  Sparkles,
  Bot,
  User,
  Copy,
  Check,
  RotateCcw,
  Volume2,
  VolumeX,
  Layers,
  Zap,
  Globe2,
  Mic,
  MicOff,
  ArrowRight,
  HelpCircle,
  Lightbulb,
  Compass,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { SafeMathText } from './SafeMathText';
import { EducationalContent } from './EducationalContent';
import { BankQuestion } from '../lib/questionBankData';
import { answerEncyclopedicQuery } from '../lib/encyclopedicKnowledgeEngine';
import { speakText, stopSpeaking } from '../lib/studySpeechEngine';

interface EncyclopedicMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  formulaOrRule?: string;
  sourceContext?: string;
  keyTakeaway?: string;
  relatedQuestions?: BankQuestion[];
  suggestedFollowUps?: string[];
  timestamp: number;
  isOffline?: boolean;
}

interface EncyclopedicChatProps {
  onExportToNote?: (title: string, content: string) => void;
  onSelectRelatedQuestion?: (question: BankQuestion) => void;
}

const POPULAR_TOPICS = [
  {
    icon: '📜',
    label: 'الربا وفقه المعاملات المالية',
    category: 'العلوم الشرعية',
    prompt: 'ما هو الربا في الشريعة الإسلامية وأحكامه وأقسامه وحديث الأصناف الستة والعلة الاقتصادية لتحريمه؟'
  },
  {
    icon: '⚡',
    label: 'قانون أوم والدوائر الكهربائية',
    category: 'الفيزياء التطبيقية',
    prompt: 'اشرح قانون أوم والعوامل المؤثرة في المقاومة وتوصيل المقاومات توالٍ وتوازٍ مع المعادلات الرياضية.'
  },
  {
    icon: '🌌',
    label: 'النسبية وأفق حدث الثقوب السوداء',
    category: 'الفيزياء والكونيات',
    prompt: 'ما هو أفق الحدث ونصف قطر شفارتزشيلد في فيزياء الثقوب السوداء والنسبية العامة مع المعادلات؟'
  },
  {
    icon: '🧬',
    label: 'الحمض النووي وتقنية CRISPR',
    category: 'الطب والعلوم الحيوية',
    prompt: 'اشرح بنية الحمض النووي DNA وآلية عمل مقص كريسبر كاس9 (CRISPR-Cas9) في التعديل الجيني.'
  },
  {
    icon: '🏛️',
    label: 'سد مأرب وحضارة سبأ',
    category: 'تاريخ اليمن والحضارات',
    prompt: 'ما هي معالم الهندسة المائية والريية لسد مأرب التاريخي في حضارة سبأ ونقوش المسند الأثرية؟'
  },
  {
    icon: '📐',
    label: 'مبرهنة فيرما الأخيرة وتاريخها',
    category: 'الرياضيات العليا',
    prompt: 'اشرح مبرهنة فيرما الأخيرة في نظرية الأعداد وكيف تم إثباتها رياضياً على يد أندرو وايلز.'
  },
  {
    icon: '💻',
    label: 'معمارية Transformer والانتباه',
    category: 'علوم الحاسوب والذكاء',
    prompt: 'كيف تعمل آلية الانتباه الذاتي Self-Attention في معمارية Transformer لنماذج اللغة الكبيرة؟'
  },
  {
    icon: '📖',
    label: 'قواعد النحو والإعراب',
    category: 'اللغة العربية واللسانيات',
    prompt: 'اشرح قواعد الإعراب وعلاماته الأصلية والفرعية والفرق بين الجملة الاسمية والفعلية مع الأمثلة.'
  },
];

export const EncyclopedicChat: React.FC<EncyclopedicChatProps> = ({
  onExportToNote,
}) => {
  const [messages, setMessages] = useState<EncyclopedicMessage[]>(() => {
    try {
      const saved = localStorage.getItem('encyclopedic_chat_history');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.warn('Error reading chat history from localStorage:', e);
    }
    return [
      {
        id: 'welcome',
        role: 'assistant',
        content: `مرحباً بك في **المحرك الموسوعي الأكاديمي الشامل**!\n\nأنا مرجعك المعرفي المعتمد للإجابة الدقيقة والمفصلة عن أي تساؤل علمي أو فقهي أو رياضي أو تاريخي أو طبي.\n\nتفضل بكتابة أي سؤال مباشرة، أو اختر من المواضيع المقترحة للبدء فوراً.`,
        timestamp: Date.now(),
        keyTakeaway: 'المحرك الموسوعي جاهز للإجابة الفورية والشرح المفصل مع القوانين والمراجع المعتمدة.',
        isOffline: false,
        suggestedFollowUps: [
          'ما هو الربا في الشريعة الإسلامية وأقسامه؟',
          'اشرح قانون أوم وتوصيل المقاومات في الفيزياء.',
          'كيف يعمل التعديل الجيني بتقنية CRISPR-Cas9؟'
        ],
      },
    ];
  });

  // Save messages to localStorage on change
  useEffect(() => {
    try {
      localStorage.setItem('encyclopedic_chat_history', JSON.stringify(messages.slice(-50)));
    } catch (e) {
      console.warn('Error saving chat history to localStorage:', e);
    }
  }, [messages]);

  const [inputPrompt, setInputPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [useOnlineEngine, setUseOnlineEngine] = useState(true);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [speakingId, setSpeakingId] = useState<string | null>(null);
  const [speechRate, setSpeechRate] = useState<number>(1.0);
  const [academicDepth, setAcademicDepth] = useState<'comprehensive' | 'concise' | 'research'>('comprehensive');
  const [isListening, setIsListening] = useState(false);
  const [showSuggestionsDrawer, setShowSuggestionsDrawer] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const recognitionRef = useRef<any>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  // Voice Speech Recognition Setup (Web Speech API)
  const toggleSpeechRecognition = () => {
    if (isListening) {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      setIsListening(false);
      return;
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert('ميزة التعرف الصوتي غير مدعومة في متصفحك الحالي. يرجى استخدام متصفح حديث مثل Chrome أو Edge.');
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.lang = 'ar-SA';
      recognition.continuous = false;
      recognition.interimResults = false;

      recognition.onstart = () => {
        setIsListening(true);
      };

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        if (transcript) {
          setInputPrompt((prev) => (prev ? `${prev} ${transcript}` : transcript));
        }
      };

      recognition.onerror = (event: any) => {
        console.warn('Speech recognition error:', event.error);
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
      recognition.start();
    } catch (err) {
      console.warn('Speech recognition initialization error:', err);
      setIsListening(false);
    }
  };

  const handleSendMessage = async (textToSend?: string) => {
    const query = (textToSend || inputPrompt).trim();
    if (!query || isLoading) return;

    setInputPrompt('');
    setShowSuggestionsDrawer(false);

    const userMsg: EncyclopedicMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: query,
      timestamp: Date.now(),
    };

    setMessages((prev) => [...prev, userMsg]);
    setIsLoading(true);

    // Multi-turn context memory: pass history of conversation
    const conversationHistory = messages
      .filter((m) => m.id !== 'welcome')
      .slice(-8)
      .map((m) => ({
        role: m.role === 'user' ? 'user' : 'model',
        parts: [{ text: m.content }],
      }));

    // Depth-specific academic instruction
    let depthInstruction = '';
    if (academicDepth === 'comprehensive') {
      depthInstruction = `نمط الشرح: شامل وأكاديمي متكامل. اذكر التعريف العلمي، الآلية خطوة بخطوة، القوانين الرياضية بصيغة LaTeX داخل $$...$$، والتطبيقات الواقعية.`;
    } else if (academicDepth === 'research') {
      depthInstruction = `نمط الشرح: بحثي متقدم. ركّز على البراهين الرياضية، المعادلات، المراجع المعتمدة، والتحليل المنهجي.`;
    } else {
      depthInstruction = `نمط الشرح: موجز امتحاني مركز. قدّم نقاط مكثفة وقوانين جاهزة للحل مع أمثلة سريعة دون حشو.`;
    }

    // Direct Identity & Designer Response with normalized Arabic matching
    const normalizeArabic = (str: string) =>
      (str || '')
        .replace(/[\u064B-\u065F\u0670\u0640]/g, '')
        .replace(/[أإآ]/g, 'ا')
        .replace(/[ة]/g, 'ه')
        .replace(/[ى]/g, 'ي')
        .toLowerCase()
        .trim();

    const normQuery = normalizeArabic(query);
    const isIdentityInquiry =
      /من\s*(هو\s*)?(مصمم|مطور|مبرمج|صانع|مبتكر|صاحب|انشا|خلق|مالك)\s*(هذا\s*)?(التطبيق|البرنامج|المنصه|النظام)/i.test(normQuery) ||
      /من\s*(صمم|طور|برمج|صنع|ابتكر|انشا|عمل|سوي)\s*(هذا\s*)?(التطبيق|البرنامج|المنصه|النظام)/i.test(normQuery) ||
      /من\s*(صممك|طورك|برمجك|صنعك|ابتكرك|انشاك|سواك)/i.test(normQuery) ||
      /من\s*انت\s*(؟|\?)?$/i.test(normQuery) ||
      /من\s*هو\s*(المهندس\s*)?ضياء\s*الحق/i.test(normQuery) ||
      /ضياء\s*الحق\s*سبيقاء/i.test(normQuery) ||
      /فريق\s*d\.?core/i.test(normQuery) ||
      normQuery.includes('d.core') ||
      normQuery.includes('dcore') ||
      ((normQuery.includes('مصمم') || normQuery.includes('مطور') || normQuery.includes('مبرمج')) &&
       (normQuery.includes('تطبيق') || normQuery.includes('برنامج') || normQuery.includes('منصه') || normQuery.includes('النظام')));

    if (isIdentityInquiry) {
      const identityText = `تم ابتكار وتصميم وتطوير وبرمجة منصة وتطبيق **«المعلم الذكي للدراسة والبحث العلمي وبنك الأسئلة والموسوعة الأكاديمية»** بالكامل بواسطة:

🎓 **المصمم والمهندس والمبتكر: ضياء الحق سبيقاء (Diaa Al-Haq Sabiqaa)**
🏛️ **بالتعاون والإشراف الأكاديمي والتقني الكامل مع: «فريق D.CORE الأكاديمي»**

---

### 🌟 نبذة عن المنصة والمهندس المصمم وفريق العمل:
- **المصمم والمهندس المبتكر:** **ضياء الحق سبيقاء**، صاحب الرؤية الهندسية والمصمم المعماري للمنصة، قاد عمليات التصميم والتطوير البرمجي لإنشاء هذه المنظومة الأكاديمية المتقدمة لخدمة الطلاب والباحثين في اليمن والعالم العربي.
- **فريق D.CORE الأكاديمي:** الفريق العلمي والتقني المساند الذي تولى تدقيق ومواءمة المناهج الدراسية، وبناء قواعد البيانات الأكاديمية المستقلة، وأتمتة نماذج الامتحانات الوزارية والطبية.
- **الركائز الأساسية للتطبيق:**
  1. **المنهج اليمني المؤتمت 100%:** بنك أسئلة وزارية دقيقة للصف الثالث الثانوي (علمي وأدبي) والصف التاسع الأساسي مع تصحيح فوري وشروحات نموذجية وقوانين رياضية وفيزيائية معتمدة بصيغ LaTeX.
  2. **البنك الطبي السريري:** تغطية بلكات الطب السريري ونظام USMLE مع سيناريوهات تشخيصية ثنائية اللغة وشروحات فارماكولوجية وفيزيولوجية.
  3. **الموسوعة العلمية والأكاديمية:** محرك معرفي وموسوعي ضخم يعمل أوفلاين وأونلاين لتوثيق المفاهيم في شتى العلوم والحضارات.
  4. **محرك الذكاء الاصطناعي الأكاديمي (D.CORE Engine):** إجابات فورية رصينة ومباشرة تركز على العمق العلمي وحل القوانين خطوة بخطوة دون أي حشو.

هذا المشروع صُمم ونُفذ باحترافية كاملة برئاسة المهندس **ضياء الحق سبيقاء** و**فريق D.CORE الأكاديمي**.`;

      const aiMsg: EncyclopedicMessage = {
        id: `ai-${Date.now()}`,
        role: 'assistant',
        content: identityText,
        timestamp: Date.now(),
        isOffline: false,
        sourceContext: 'فريق التطوير والهندسة الأكاديمية (D.CORE)',
        keyTakeaway: 'تم تصميم وتطوير المنصة بواسطة المهندس ضياء الحق سبيقاء وفريق D.CORE الأكاديمي.',
        suggestedFollowUps: [
          'ما هي مميزات بنك الامتحانات الوزارية المؤتمتة؟',
          'كيف يمكنني التدرب على نماذج ثالث ثانوي علمي وأدبي؟',
          'ما هي بلكات البنك الطبي السريري المتاحة؟',
        ],
      };
      setMessages((prev) => [...prev, aiMsg]);
      setIsLoading(false);
      return;
    }

    // Try online AI first if enabled, with generous 60s timeout
    if (useOnlineEngine) {
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 60000); // 60s budget

        const response = await fetch('/api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            prompt: query,
            mode: 'general',
            model: 'gemini-3.8-flash',
            maxOutputTokens: 6144,
            conversationHistory,
            systemInstruction: `أنت المحرك الموسوعي الأكاديمي الشامل في منصة المعلم الذكي للدراسة والبحث العلمي المتقدم (D.CORE Schooler AI).
هوية المنصة والمصمم (إلزامية وصارمة):
تم ابتكار وتصميم وتطوير وبرمجة هذا التطبيق ومنصة المعلم الذكي بالكامل بواسطة المبتكر والمصمم والمهندس: «ضياء الحق سبيقاء» (Diaa Al-Haq Sabiqaa) بالتعاون مع «فريق D.CORE الأكاديمي».
إذا سألك المستخدم في أي وقت: من صمم هذا التطبيق؟ من طور هذا التطبيق؟ من أنت؟ من صاحب التطبيق أو مبرمجه؟ فأجب بفخر واعتزاز وبوضوح تام ومباشر بأن هذا التطبيق والمنصة من تصميم وابتكار وهندسة: ضياء الحق سبيقاء وفريق D.CORE الأكاديمي، ولا تنسب تطوير أو تصميم المنصة لأي شركة أو طرف آخر.

المهمة: أجب على استفسار المستخدم كأفضل مرجع موسوعي أكاديمي عربي وعالمي، بدقة علمية متناهية وتنظيم احترافي فائق دون أي مقدمات إنشائية أو حشو.
${depthInstruction}

القواعد الأكاديمية الصارمة:
1. ابدأ مباشرة في صلب الموضوع دون أي ترحيبات أو مقدمات مستهلكة.
2. اكتب كافة القوانين والمعادلات بصيغة LaTeX القياسية داخل $$...$$ (للمعادلات المستقلة) أو $...$ (للمعادلات المضمنة).
3. في الشريعة والفقه: بيّن الأحكام بأدلتها من القرآن والسنة مع أقوال المذاهب بدقة وضبط.
4. في الفيزياء والرياضيات: بيّن القوانين الرياضية وفسّر دلالات كل رمز ووحدة قياس.
5. في الطب والعلوم: وضّح الفسيولوجيا المرضية وأحدث التوجيهات الإكلينيكية المعتمدة.
6. في التاريخ والحضارات (حضارة سبأ، سد مأرب، التاريخ اليمني والعالمي): استند إلى الأدلة والوقائع الموثقة.
7. اختم الإجابة بـ 3 أسئلة مقترحة للتوسع المعرفي بصيغة:
[FOLLOWUP]: سؤال التوسع الأول؟
[FOLLOWUP]: سؤال التوسع الثاني؟
[FOLLOWUP]: سؤال التوسع الثالث؟`,
          }),
          signal: controller.signal,
        });

        clearTimeout(timeoutId);

        if (response.ok) {
          const data = await response.json();
          if (data && data.text) {
            const rawText = data.text;
            const followUps: string[] = [];
            const cleanText = rawText.replace(/\[FOLLOWUP\]:\s*(.*)/g, (_match: string, p1: string) => {
              if (p1 && p1.trim()) followUps.push(p1.trim());
              return '';
            }).trim();

            const aiMsg: EncyclopedicMessage = {
              id: `ai-${Date.now()}`,
              role: 'assistant',
              content: cleanText || rawText,
              timestamp: Date.now(),
              isOffline: false,
              sourceContext: 'المحرك الأكاديمي الموسوعي (D.CORE Engine)',
              keyTakeaway: 'تم التوثيق والتحليل عبر المحرك الموسوعي الأكاديمي لمنصة المعلم الذكي.',
              suggestedFollowUps: followUps.length > 0 ? followUps : [
                `ما هي التطبيقات العملية المباشرة لهذا الموضوع؟`,
                `كيف يرتبط هذا المفهوم بالقوانين الكبرى في هذا المجال؟`,
                `هل هناك مسائل أو تمارين أكاديمية تطبيقية شائعة حوله؟`
              ],
            };
            setMessages((prev) => [...prev, aiMsg]);
            setIsLoading(false);
            return;
          }
        }
      } catch (e) {
        console.warn('Online encyclopedic AI fetch failed or timed out, seamlessly falling back to autonomous local engine:', e);
      }
    }

    // Local Autonomous Comprehensive Knowledge Engine Fallback
    const offlineSolution = answerEncyclopedicQuery(query);

    const offlineMsg: EncyclopedicMessage = {
      id: `ai-${Date.now()}`,
      role: 'assistant',
      content: offlineSolution.detailedContent,
      formulaOrRule: offlineSolution.formulaOrRule,
      keyTakeaway: offlineSolution.keyTakeaway,
      sourceContext: offlineSolution.sourceContext || offlineSolution.title,
      timestamp: Date.now(),
      isOffline: true,
      suggestedFollowUps: [
        `كيف يتم تطبيق قانون أو مفهوم «${query}» في المسائل العملية؟`,
        `ما هي أهم الضوابط والشروط المعرفية المرتبطة به؟`,
        `ما هي المسائل الأكاديمية الشائعة في الامتحانات حول هذا الموضوع؟`
      ],
    };

    setMessages((prev) => [...prev, offlineMsg]);
    setIsLoading(false);
  };

  const handleCopy = (msg: EncyclopedicMessage) => {
    navigator.clipboard.writeText(msg.content);
    setCopiedId(msg.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleSpeak = (msg: EncyclopedicMessage) => {
    if (speakingId === msg.id) {
      stopSpeaking();
      setSpeakingId(null);
      return;
    }

    speakText(msg.content, {
      title: 'إجابة المحرك الموسوعي',
      speed: speechRate,
      onStart: () => setSpeakingId(msg.id),
      onEnd: () => setSpeakingId(null),
      onError: () => setSpeakingId(null),
    });
  };

  const handleClearChat = () => {
    setMessages([
      {
        id: 'welcome-reset',
        role: 'assistant',
        content: `تم بدء جلسة معرفية جديدة.\n\nتفضل بطرح أي سؤال علمي أو فقهي أو رياضي وسأجيبك فوراً بدقة عالية وتنظيم احترافي.`,
        timestamp: Date.now(),
        isOffline: false,
        suggestedFollowUps: [
          'ما هو الربا في الشريعة الإسلامية وأقسامه؟',
          'اشرح قانون أوم وتوصيل المقاومات في الفيزياء.',
          'ما هي مراحل دورة كريبس في التنفس الخلوي؟'
        ],
      },
    ]);
  };

  const isFreshSession = messages.length <= 1;

  return (
    <div
      className="flex flex-col bg-white dark:bg-[#111916] border border-[#e2e8e5] dark:border-[#22352f] shadow-lg rounded-2xl h-full w-full min-h-0 flex-1 overflow-hidden transition-all"
    >
      {/* Refined World-Class Top Header */}
      <div className="px-4 py-3 bg-[#131d1a] text-white flex items-center justify-between gap-3 border-b border-[#23352f] shrink-0">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-9 h-9 rounded-xl bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 flex items-center justify-center font-bold shrink-0">
            <Globe2 className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <h2 className="font-bold text-sm sm:text-base text-white truncate">
                المحرك الموسوعي والمعرفي الشامل
              </h2>
              <span className="hidden sm:inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-medium shrink-0">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                قاعدة بيانات موسوعية
              </span>
            </div>
            <p className="text-[11px] text-gray-400 truncate hidden xs:block">
              شرح أكاديمي دقيق وموثق لكافة العلوم والمعارف والقوانين
            </p>
          </div>
        </div>

        {/* Minimalist Controls Toolbar */}
        <div className="flex items-center gap-1.5 shrink-0">
          {/* Depth Selector */}
          <div className="hidden md:flex items-center bg-white/5 p-0.5 rounded-lg border border-white/10 text-[11px] font-medium">
            <button
              type="button"
              onClick={() => setAcademicDepth('comprehensive')}
              className={`px-2.5 py-1 rounded-md transition-all cursor-pointer ${
                academicDepth === 'comprehensive'
                  ? 'bg-emerald-600 text-white font-bold shadow-xs'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              شامل
            </button>
            <button
              type="button"
              onClick={() => setAcademicDepth('research')}
              className={`px-2.5 py-1 rounded-md transition-all cursor-pointer ${
                academicDepth === 'research'
                  ? 'bg-emerald-600 text-white font-bold shadow-xs'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              بحثي
            </button>
            <button
              type="button"
              onClick={() => setAcademicDepth('concise')}
              className={`px-2.5 py-1 rounded-md transition-all cursor-pointer ${
                academicDepth === 'concise'
                  ? 'bg-emerald-600 text-white font-bold shadow-xs'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              موجز
            </button>
          </div>

          {/* Voice Speed Toggle */}
          <button
            type="button"
            onClick={() => {
              const rates = [0.8, 1.0, 1.25];
              const nextIndex = (rates.indexOf(speechRate) + 1) % rates.length;
              setSpeechRate(rates[nextIndex]);
            }}
            className="px-2 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-gray-300 text-xs font-mono font-medium transition-all cursor-pointer border border-white/10"
            title="سرعة القراءة الصوتية"
          >
            {speechRate}x 🔊
          </button>

          {/* Online/Offline Toggle */}
          <button
            type="button"
            onClick={() => setUseOnlineEngine(!useOnlineEngine)}
            className={`px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all cursor-pointer flex items-center gap-1.5 border ${
              useOnlineEngine
                ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-300'
                : 'bg-amber-500/15 border-amber-500/30 text-amber-300'
            }`}
            title={useOnlineEngine ? 'المحرك الذكي السحابي نشط' : 'الوضع الأوفلاين السريع نشط'}
          >
            {useOnlineEngine ? <Sparkles className="w-3.5 h-3.5" /> : <Zap className="w-3.5 h-3.5" />}
            <span className="hidden sm:inline">{useOnlineEngine ? 'سحابي' : 'محلي'}</span>
          </button>

          {/* New Session Button */}
          <button
            type="button"
            onClick={handleClearChat}
            className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white transition-colors cursor-pointer border border-white/10"
            title="بدء جلسة جديدة"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Optional Suggestions Drawer (Collapsible) */}
      {showSuggestionsDrawer && (
        <div className="p-3 bg-[#f3f7f5] dark:bg-[#14221d] border-b border-[#e2e8e5] dark:border-[#22352f] shrink-0 animate-in fade-in">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-gray-700 dark:text-gray-300 flex items-center gap-1.5">
              <Compass className="w-3.5 h-3.5 text-emerald-600" />
              <span>مواضيع مقترحة للاستكشاف الأكاديمي السريع:</span>
            </span>
            <button
              type="button"
              onClick={() => setShowSuggestionsDrawer(false)}
              className="text-xs text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 cursor-pointer"
            >
              إغلاق ✕
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2">
            {POPULAR_TOPICS.map((topic, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handleSendMessage(topic.prompt)}
                className="p-2.5 rounded-xl bg-white dark:bg-[#192b24] hover:border-emerald-500 border border-[#e2e8e5] dark:border-[#243831] text-right transition-all cursor-pointer group text-xs shadow-2xs active:scale-98"
              >
                <div className="flex items-center gap-1.5 text-emerald-700 dark:text-emerald-400 font-bold mb-1">
                  <span>{topic.icon}</span>
                  <span className="truncate">{topic.label}</span>
                </div>
                <div className="text-[10px] text-gray-500 dark:text-gray-400 line-clamp-1">
                  {topic.category}
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Messages Stream Area */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
        {messages.map((msg) => {
          const isUser = msg.role === 'user';

          return (
            <div
              key={msg.id}
              className={`flex gap-3 max-w-4xl ${isUser ? 'mr-auto flex-row-reverse' : 'ml-auto'}`}
            >
              {/* Clean Minimalist Avatar */}
              <div
                className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 shadow-2xs text-xs font-bold ${
                  isUser
                    ? 'bg-emerald-600 text-white'
                    : 'bg-[#1e2e28] text-emerald-400 border border-emerald-500/20'
                }`}
              >
                {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
              </div>

              {/* Message Bubble Container */}
              <div
                className={`p-4 sm:p-5 rounded-2xl border space-y-3 min-w-0 max-w-[90%] sm:max-w-[85%] leading-relaxed ${
                  isUser
                    ? 'bg-emerald-600 text-white border-emerald-700 shadow-sm rounded-tr-xs'
                    : 'bg-[#f8faf9] dark:bg-[#15231e] border-[#e2e8e5] dark:border-[#22352f] text-[#17201e] dark:text-[#eef7f4] shadow-xs rounded-tl-xs'
                }`}
              >
                {/* Assistant Source Metadata Badge */}
                {!isUser && msg.id !== 'welcome' && (
                  <div className="flex items-center justify-between gap-2 border-b border-gray-200/60 dark:border-gray-800 pb-2 text-[11px]">
                    <span className="font-semibold text-emerald-700 dark:text-emerald-400 flex items-center gap-1.5 truncate">
                      <Sparkles className="w-3.5 h-3.5 shrink-0" />
                      <span className="truncate">{msg.sourceContext || 'المرجع الموسوعي المعتمد'}</span>
                    </span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 font-medium shrink-0 border border-emerald-200/50 dark:border-emerald-800/40">
                      {msg.isOffline ? 'قاعدة بيانات محلية' : 'D.CORE Engine'}
                    </span>
                  </div>
                )}

                {/* Formatted Text with Markdown and KaTeX Equations */}
                <div className={`text-xs sm:text-sm leading-relaxed ${isUser ? 'text-white' : ''}`}>
                  {isUser ? (
                    <p className="whitespace-pre-wrap">{msg.content}</p>
                  ) : (
                    <EducationalContent
                      content={msg.content}
                      className="prose dark:prose-invert max-w-none text-xs sm:text-sm leading-relaxed"
                    />
                  )}
                </div>

                {/* Formula Highlight Box (Only rendered if formula exists and is mathematically relevant) */}
                {msg.formulaOrRule && msg.formulaOrRule.trim().length > 0 && (
                  <div className="p-3 rounded-xl bg-white dark:bg-[#0f1915] border border-emerald-200 dark:border-emerald-900/60 font-mono text-xs text-emerald-950 dark:text-emerald-200 shadow-2xs">
                    <span className="font-bold text-emerald-800 dark:text-emerald-400 block mb-1 text-[11px]">
                      📐 القاعدة أو المعادلة الحاكمة:
                    </span>
                    <SafeMathText text={`$$${msg.formulaOrRule}$$`} block />
                  </div>
                )}

                {/* Key Takeaway Note */}
                {msg.keyTakeaway && (
                  <div className="p-2.5 rounded-lg bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200/60 dark:border-emerald-900/40 text-[11px] text-emerald-900 dark:text-emerald-200 flex items-start gap-2">
                    <Check className="w-3.5 h-3.5 text-emerald-600 mt-0.5 shrink-0" />
                    <span>{msg.keyTakeaway}</span>
                  </div>
                )}

                {/* Follow-up Question Chips */}
                {!isUser && msg.suggestedFollowUps && msg.suggestedFollowUps.length > 0 && (
                  <div className="pt-2 border-t border-gray-200/60 dark:border-gray-800 space-y-2">
                    <span className="text-[11px] font-semibold text-gray-500 dark:text-gray-400 flex items-center gap-1">
                      <HelpCircle className="w-3.5 h-3.5 text-emerald-600" />
                      <span>توسّع في الموضوع:</span>
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {msg.suggestedFollowUps.map((fu, fIdx) => (
                        <button
                          key={fIdx}
                          type="button"
                          onClick={() => handleSendMessage(fu)}
                          className="px-2.5 py-1 rounded-lg bg-white dark:bg-[#1a2b25] hover:bg-emerald-50 dark:hover:bg-emerald-950/60 text-emerald-900 dark:text-emerald-200 border border-[#e2e8e5] dark:border-[#263c34] text-[11px] font-medium text-right transition-all cursor-pointer active:scale-95 flex items-center gap-1"
                        >
                          <ArrowRight className="w-3 h-3 text-emerald-600 rtl:rotate-0 ltr:rotate-180 shrink-0" />
                          <span>{fu}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Bottom Action Toolbar */}
                {!isUser && (
                  <div className="flex items-center justify-between pt-2 border-t border-gray-200/50 dark:border-gray-800 text-[11px] text-gray-400">
                    <span className="font-mono text-[10px]">
                      {new Date(msg.timestamp).toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' })}
                    </span>

                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => handleCopy(msg)}
                        className="p-1.5 rounded-md hover:text-gray-700 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors cursor-pointer"
                        title="نسخ الشرح"
                      >
                        {copiedId === msg.id ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>

                      <button
                        type="button"
                        onClick={() => handleSpeak(msg)}
                        className={`p-1.5 rounded-md transition-colors cursor-pointer ${
                          speakingId === msg.id
                            ? 'text-emerald-600 bg-emerald-50 dark:bg-emerald-950'
                            : 'hover:text-gray-700 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800'
                        }`}
                        title={speakingId === msg.id ? 'إيقاف القراءة' : `استماع للشرح (${speechRate}x)`}
                      >
                        {speakingId === msg.id ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
                      </button>

                      {onExportToNote && (
                        <button
                          type="button"
                          onClick={() => onExportToNote('ملخص موسوعي', msg.content)}
                          className="p-1.5 rounded-md hover:text-gray-700 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors cursor-pointer"
                          title="حفظ في ملاحظات الدفتر"
                        >
                          <Layers className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>
          );
        })}

        {/* Fresh Session Welcome Suggestion Grid (Rendered cleanly inside message stream) */}
        {isFreshSession && (
          <div className="max-w-3xl mx-auto pt-2 pb-4 space-y-3 animate-in fade-in">
            <div className="flex items-center gap-1.5 text-xs font-bold text-gray-500 dark:text-gray-400 px-1">
              <Lightbulb className="w-4 h-4 text-amber-500" />
              <span>استفسارات نموذجية يمكنك البدء بها فوراً:</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {POPULAR_TOPICS.slice(0, 4).map((topic, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => handleSendMessage(topic.prompt)}
                  className="p-3 rounded-xl bg-white dark:bg-[#14221d] hover:border-emerald-500 dark:hover:border-emerald-600 border border-[#e2e8e5] dark:border-[#243831] text-right transition-all cursor-pointer group shadow-2xs hover:shadow-xs active:scale-98"
                >
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-base">{topic.icon}</span>
                    <span className="font-bold text-xs text-[#17201e] dark:text-white group-hover:text-emerald-600 dark:group-hover:text-emerald-400">
                      {topic.label}
                    </span>
                  </div>
                  <p className="text-[11px] text-gray-500 dark:text-gray-400 line-clamp-1">
                    {topic.prompt}
                  </p>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Loading Typing Indicator */}
        {isLoading && (
          <div className="flex gap-3 items-center text-xs text-emerald-700 dark:text-emerald-400 animate-in fade-in">
            <div className="w-8 h-8 rounded-xl bg-[#1e2e28] text-emerald-400 flex items-center justify-center animate-pulse">
              <Bot className="w-4 h-4" />
            </div>
            <div className="p-3.5 rounded-xl bg-[#f8faf9] dark:bg-[#15231e] border border-emerald-300/40 dark:border-emerald-800/40 flex items-center gap-2 shadow-xs">
              <Sparkles className="w-4 h-4 animate-spin text-emerald-500" />
              <span className="font-medium text-xs">جارٍ إعداد الشرح الموسوعي والتوثيق الأكاديمي المعتمد...</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Form Bar */}
      <div className="p-3 sm:p-4 bg-[#f8faf9] dark:bg-[#131d19] border-t border-[#e2e8e5] dark:border-[#22352f] shrink-0">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="flex gap-2 items-center"
        >
          {/* Toggle Suggestions Drawer Button */}
          <button
            type="button"
            onClick={() => setShowSuggestionsDrawer(!showSuggestionsDrawer)}
            className={`p-2.5 rounded-xl border transition-all cursor-pointer shrink-0 ${
              showSuggestionsDrawer
                ? 'bg-emerald-600 text-white border-emerald-700'
                : 'bg-white dark:bg-[#192621] border-[#d8e2dd] dark:border-[#263c34] text-gray-600 dark:text-gray-300 hover:text-emerald-600'
            }`}
            title="اقتراحات الأسئلة والمواضيع"
          >
            <Lightbulb className="w-4 h-4" />
          </button>

          {/* Voice Input Button */}
          <button
            type="button"
            onClick={toggleSpeechRecognition}
            className={`p-2.5 rounded-xl border transition-all cursor-pointer shrink-0 ${
              isListening
                ? 'bg-red-500 border-red-600 text-white animate-pulse'
                : 'bg-white dark:bg-[#192621] border-[#d8e2dd] dark:border-[#263c34] text-gray-600 dark:text-gray-300 hover:text-emerald-600'
            }`}
            title={isListening ? 'جارٍ الاستماع... انقر للإيقاف' : 'إملاء صوتي باللغة العربية'}
          >
            {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
          </button>

          {/* Input Text Box */}
          <div className="relative flex-1">
            <input
              type="text"
              value={inputPrompt}
              onChange={(e) => setInputPrompt(e.target.value)}
              placeholder={
                isListening
                  ? 'جارٍ الاستماع لصوتك... تحدّث الآن'
                  : 'اطرح أي سؤال موسوعي أو علمي (مثال: ما هو الربا في الشريعة، قانون أوم، سد مأرب...)'
              }
              className="w-full bg-white dark:bg-[#192621] border border-[#d8e2dd] dark:border-[#263c34] rounded-xl px-4 py-2.5 text-xs sm:text-sm text-[#17201e] dark:text-[#eef7f4] placeholder:text-gray-400 outline-none focus:ring-2 focus:ring-emerald-500/40 focus:border-emerald-500 transition-all"
            />
          </div>

          {/* Send Button */}
          <button
            type="submit"
            disabled={isLoading || !inputPrompt.trim()}
            className="px-4 sm:px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-40 text-white font-bold text-xs sm:text-sm flex items-center gap-1.5 transition-all shadow-xs active:scale-95 cursor-pointer shrink-0"
          >
            {isLoading ? <Sparkles className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4 rtl:rotate-180" />}
            <span className="hidden sm:inline">إرسال</span>
          </button>
        </form>
      </div>
    </div>
  );
};
