import React, { useState } from 'react';
import {
  X,
  Maximize2,
  Minimize2,
  FileText,
  BookOpen,
  MessageSquare,
  Copy,
  Check,
  Search,
  Eye,
  Layers,
  Sparkles,
} from 'lucide-react';
import { Source, SourceChunk } from '../types';
import { PDFPreviewAnnotator } from './PDFPreviewAnnotator';

interface QuickPreviewModalProps {
  source: Source;
  chunks?: SourceChunk[];
  onClose: () => void;
  onAskAboutSource?: (source: Source) => void;
  onAskAboutQuote?: (quote: string, pageNumber: number) => void;
  onExportToNote?: (title: string, content: string) => void;
}

export const QuickPreviewModal: React.FC<QuickPreviewModalProps> = ({
  source,
  chunks = [],
  onClose,
  onAskAboutSource,
  onAskAboutQuote,
  onExportToNote,
}) => {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'pdfjs' | 'text'>(() => {
    const isPdf =
      source.type === 'application/pdf' ||
      source.title?.toLowerCase().endsWith('.pdf') ||
      (source.pages && source.pages.length > 1);
    return isPdf ? 'pdfjs' : 'text';
  });
  const [searchQuery, setSearchQuery] = useState('');

  const isPdf =
    source.type === 'application/pdf' ||
    source.title?.toLowerCase().endsWith('.pdf') ||
    (source.pages && source.pages.length > 1);

  const handleCopyText = () => {
    const textToCopy = source.content || '';
    if (!textToCopy) return;
    navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200"
    >
      <div
        className={`bg-white dark:bg-[#121c18] rounded-2xl sm:rounded-3xl border border-slate-200 dark:border-[#22352f] shadow-2xl flex flex-col overflow-hidden transition-all duration-300 ${
          isFullscreen ? 'w-full h-full rounded-none' : 'w-full max-w-5xl h-[90vh]'
        }`}
      >
        {/* Header Bar */}
        <div className="px-4 py-3 bg-white dark:bg-[#15231e] border-b border-slate-200 dark:border-[#22352f] flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8 h-8 rounded-xl bg-teal-50 dark:bg-teal-950/70 text-teal-600 dark:text-teal-400 flex items-center justify-center shrink-0">
              <Eye className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-teal-100 text-teal-800 dark:bg-teal-950 dark:text-teal-300 shrink-0 font-mono uppercase">
                  {isPdf ? 'PDF.JS Viewer' : 'نص المصدر'}
                </span>
                <h3
                  className="font-bold text-xs sm:text-sm text-slate-800 dark:text-slate-100 truncate"
                  title={source.title}
                >
                  {source.title}
                </h3>
              </div>
              <div className="text-[10px] text-slate-400 dark:text-slate-400 flex items-center gap-2 mt-0.5">
                <span>{source.pageCount ? `${source.pageCount} صفحة` : 'مستند معرفي'}</span>
                <span>•</span>
                <span>{source.wordCount ? `${source.wordCount.toLocaleString()} كلمة` : ''}</span>
              </div>
            </div>
          </div>

          {/* Quick Header Controls */}
          <div className="flex items-center gap-1.5 shrink-0">
            {isPdf && (
              <div className="flex items-center bg-slate-100 dark:bg-[#1a2924] p-0.5 rounded-xl text-xs font-semibold">
                <button
                  type="button"
                  onClick={() => setActiveTab('pdfjs')}
                  className={`px-2.5 py-1 rounded-lg transition-colors cursor-pointer ${
                    activeTab === 'pdfjs'
                      ? 'bg-teal-600 text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-300 hover:text-teal-600'
                  }`}
                >
                  عارض PDF
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('text')}
                  className={`px-2.5 py-1 rounded-lg transition-colors cursor-pointer ${
                    activeTab === 'text'
                      ? 'bg-teal-600 text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-300 hover:text-teal-600'
                  }`}
                >
                  النص المستخرج
                </button>
              </div>
            )}

            {onAskAboutSource && (
              <button
                type="button"
                onClick={() => {
                  onAskAboutSource(source);
                  onClose();
                }}
                className="px-2.5 py-1.5 bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 hover:bg-teal-600 hover:text-white rounded-xl text-xs font-bold transition-colors hidden sm:flex items-center gap-1.5 cursor-pointer shadow-xs"
                title="طرح سؤال حول هذا المصدر في المحادثة"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>اسأل عنه</span>
              </button>
            )}

            <button
              type="button"
              onClick={handleCopyText}
              className="p-1.5 rounded-xl text-slate-500 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-[#1c2c26] transition-colors cursor-pointer"
              title={copied ? 'تم النسخ!' : 'نسخ نص المصدر'}
            >
              {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
            </button>

            <button
              type="button"
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="p-1.5 rounded-xl text-slate-500 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-[#1c2c26] transition-colors cursor-pointer hidden sm:block"
              title={isFullscreen ? 'تصغير' : 'ملء الشاشة'}
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>

            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-xl text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/40 transition-colors cursor-pointer"
              title="إغلاق المعاينة السريعة"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-hidden relative bg-slate-50 dark:bg-[#101915]">
          {activeTab === 'pdfjs' && isPdf ? (
            <div className="w-full h-full">
              <PDFPreviewAnnotator
                source={source}
                chunks={chunks}
                onClose={onClose}
                onAskAboutQuote={onAskAboutQuote}
                onExportToNote={onExportToNote}
                isWideMode={true}
              />
            </div>
          ) : (
            <div className="w-full h-full flex flex-col">
              {/* Text Search in Quick Preview */}
              <div className="px-4 py-2 bg-white dark:bg-[#14221d] border-b border-slate-200 dark:border-[#22352f] flex items-center justify-between gap-3 text-xs">
                <div className="relative flex-1 max-w-sm">
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="بحث في محتوى المصدر..."
                    className="w-full pl-3 pr-8 py-1 rounded-lg border border-slate-200 dark:border-[#22352f] bg-slate-50 dark:bg-[#1a2924] text-slate-800 dark:text-slate-100 text-xs focus:outline-none focus:border-teal-600"
                  />
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-2" />
                </div>

                <div className="text-[11px] text-slate-400">
                  {source.pages && source.pages.length > 0
                    ? `${source.pages.length} صفحات مستخرجة بالكامل`
                    : `${source.content?.length || 0} حرف`}
                </div>
              </div>

              {/* Scrollable Text View */}
              <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
                {source.pages && source.pages.length > 0 ? (
                  source.pages.map((p) => {
                    const matchesSearch =
                      !searchQuery.trim() ||
                      p.text.toLowerCase().includes(searchQuery.toLowerCase().trim());
                    if (!matchesSearch) return null;

                    return (
                      <div
                        key={p.pageNumber}
                        className="p-4 rounded-2xl bg-white dark:bg-[#14221d] border border-slate-200 dark:border-[#22352f] shadow-2xs space-y-2"
                      >
                        <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-[#1d2f28]">
                          <span className="text-[11px] font-bold text-teal-700 dark:text-teal-300 flex items-center gap-1">
                            <BookOpen className="w-3.5 h-3.5" />
                            <span>صفحة {p.pageNumber}</span>
                          </span>
                          {onAskAboutQuote && (
                            <button
                              type="button"
                              onClick={() => {
                                onAskAboutQuote(p.text.slice(0, 300), p.pageNumber);
                                onClose();
                              }}
                              className="text-[10px] text-slate-500 hover:text-teal-600 font-semibold cursor-pointer"
                            >
                              اسأل عن هذه الصفحة
                            </button>
                          )}
                        </div>
                        <p className="text-xs sm:text-sm leading-relaxed text-slate-800 dark:text-slate-200 whitespace-pre-wrap select-text font-serif">
                          {p.text}
                        </p>
                      </div>
                    );
                  })
                ) : (
                  <div className="p-4 sm:p-6 rounded-2xl bg-white dark:bg-[#14221d] border border-slate-200 dark:border-[#22352f] shadow-2xs">
                    <p className="text-xs sm:text-sm leading-relaxed text-slate-800 dark:text-slate-200 whitespace-pre-wrap select-text font-serif">
                      {source.content || 'لا يوجد محتوى نصي مستخرج لهذا المصدر.'}
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
