import React, { useState, useRef } from 'react';
import { 
  Download, 
  Printer, 
  FileText, 
  Settings, 
  Upload, 
  Check, 
  Layers, 
  Sparkles, 
  BookOpen, 
  Eye,
  PenTool,
  Copy,
  FilePlus2,
  ListOrdered,
  Lightbulb,
  Sigma,
  AlertTriangle,
  FileCheck,
  Table,
  BookMarked,
  FileDown
} from 'lucide-react';
import { Notebook, Source, ChatSession, Flashcard, NoteItem } from '../types';
import { InteractiveMindMap } from './InteractiveMindMap';

interface ExportViewProps {
  currentNotebook: Notebook;
  sources: Source[];
  chatSession: ChatSession;
  flashcards: Flashcard[];
  notes: NoteItem[];
  onExportAllData: () => void;
  onImportData: (data: any) => void;
}

export const ExportView: React.FC<ExportViewProps> = ({
  currentNotebook,
  sources,
  chatSession,
  flashcards,
  notes,
  onExportAllData,
  onImportData,
}) => {
  const [docType, setDocType] = useState<'custom_summary' | 'study_guide' | 'mindmap' | 'chat_log' | 'flashcards' | 'sources_summary' | 'markdown_preview'>('custom_summary');
  const [docTitle, setDocTitle] = useState(`ملخص دراسي خاص - ${currentNotebook.name}`);
  const [fontSize, setFontSize] = useState<'sm' | 'md' | 'lg'>('md');
  const [colorTheme, setColorTheme] = useState<'teal' | 'navy' | 'classic'>('teal');
  const [printMode, setPrintMode] = useState<'colored' | 'print_friendly'>('colored');
  const [orientation, setOrientation] = useState<'portrait' | 'landscape'>('portrait');
  const [includeCitations, setIncludeCitations] = useState(true);
  const [authorName, setAuthorName] = useState('الطالب الباحث');
  const [customSubject, setCustomSubject] = useState(currentNotebook.subject || 'عام');
  const [copiedMd, setCopiedMd] = useState(false);
  const [customContent, setCustomContent] = useState<string>(
    `# 📌 ملخص الدرس والمفاهيم الرئيسية\n\nأدخل هنا أي معلومات أو ملخصات خاصة تريد طباعتها كملف PDF...\n\n> 💡 **تعريف أساسي**: هذا المفهوم يعبر عن حجر الأساس في فهم الموضوع وتطبيقاته.\n\n> 📐 **قانون**: $ E = mc^2 $ أو المعادلة المحورية للموضوع.\n\n## 💡 الأفكار والمحاور الأساسية:\n- النقطة الأولى: شرح المفهوم الرئيسي وأهميته.\n- النقطة الثانية: القوانين أو القواعد المتبعة.\n- النقطة الثالثة: استنتاجات وتطبيقات عملية.\n\n> ⚠️ **ملاحظة هامة**: يجب مراجعة التعريفات الدقيقة والتمييز بين الحالات الخاصة.\n\n> 📝 **مثال محلول**: المسألة الأولى: احسب القيمة وفق المعطيات -> الحل: تطبيق القانون مباشرة.\n`
  );

  const printAreaRef = useRef<HTMLDivElement>(null);
  const restoreFileInputRef = useRef<HTMLInputElement>(null);

  const generateStructuredMarkdown = () => {
    const today = new Date().toISOString().split('T')[0];
    
    // Frontmatter with academic metadata
    let md = `---
title: "${currentNotebook.name.replace(/"/g, '\\"')}"
subject: "${(customSubject || currentNotebook.subject || 'عام').replace(/"/g, '\\"')}"
author: "${(authorName || 'الطالب الباحث').replace(/"/g, '\\"')}"
date: "${today}"
tags:
  - academic-study
  - smart-teacher
  - ${(currentNotebook.subject || 'study').toLowerCase().replace(/\\s+/g, '-')}
sources_count: ${sources.length}
flashcards_count: ${flashcards.length}
notes_count: ${notes.length}
generator: "منصة المعلم الذكي للدراسة والبحث"
format: obsidian-notion-academic-vault
---

# 📚 ${currentNotebook.name}

> [!ABSTRACT] نبذة عن الملف والموضوع
> ${currentNotebook.description || 'ملف دراسي تحليلي شامل مولد ومصدر عبر منصة المعلم الذكي للدراسة والبحث الأكاديمي.'}
> **المادة:** ${customSubject || currentNotebook.subject || 'عام'} | **المُعد:** ${authorName} | **تاريخ التصدير:** ${today}

---

## 🎯 1. المراجع والمصادر الأكاديمية المفهرسة (Academic Citations)

> [!NOTE] مصادر المعرفة المعتمدة
> استند هذا الملف الدراسي إلى فحص وتحليل المصادر الموثقة أدناه مع دقة التوثيق والاقتباس:

${sources.map((s, idx) => `### [${idx + 1}] ${s.title}
- **نوع المصدر:** \`${s.type}\`
- **حجم البيانات:** ${Math.round(s.size / 1024)} KB ${s.pageCount ? `• **عدد الصفحات:** ${s.pageCount}` : ''} • **الكلمات:** ${s.wordCount || 0}
${s.summary ? `> **ملخص تحليلي:** ${s.summary}\n` : ''}
`).join('\n')}

---

## 📐 2. القوانين والمعادلات الرياضية والعلمية (Mathematical & Scientific Models)

> [!IMPORTANT] المعادلات والقوانين المركزية
> تمت صياغة المعادلات بصيغة LaTeX الأكاديمية القياسية المتوافقة 100% مع مفسر MathJax في Obsidian ومحرر KaTeX في Notion:

$$
\\begin{aligned}
E &= mc^2 \\\\[6pt]
F &= m \\cdot a \\\\[6pt]
\\Delta G &= \\Delta H - T\\Delta S
\\end{aligned}
$$

> [!TIP] تنبيه منهجي للتطبيق
> تأكد دائماً من مطابقة وحدات القياس للنظام الدولي للوحدات (SI Units) قبل التعويض الرياضي المباشر.

---

## 💡 3. الملخص والملاحظات الأكاديمية (Study Notes & Core Insights)

${notes.length > 0 ? notes.map((n, i) => `### 📌 ${i + 1}. ${n.title}
*المادة:* **${n.subject || 'عام'}** ${n.goal ? `| *الهدف التعليمي:* ${n.goal}` : ''}
${n.tags && n.tags.length > 0 ? `*الوسوم:* ${n.tags.map(t => `#${t}`).join(' ')}\n` : ''}

${n.text}

---
`).join('\n') : customContent}

---

## 💬 4. أبرز الإجابات المعرفية الموثقة (AI Knowledge Q&A)

${chatSession.messages.filter(m => m.role === 'ai').slice(-4).map((m, idx) => {
  const userMsg = chatSession.messages.filter(msg => msg.role === 'user')[idx];
  return `> [!QUESTION] استفسار منهجي رقم ${idx + 1}
${userMsg ? userMsg.text : 'سؤال أكاديمي متعلق بالموضوع'}

> [!SUCCESS] الإجابة النموذجية الموثقة:
${m.text}
${m.citations && m.citations.length > 0 ? `\n*المراجع المستشهد بها:* ${m.citations.map(c => `[${c.sourceTitle}${c.pageNumber ? ` ص ${c.pageNumber}` : ''}]`).join(', ')}` : ''}`;
}).join('\n\n')}

---

## 🗂️ 5. بطاقات التذكر النشط والمراجعة المتباعدة (Flashcards Vault)

| # | المفهوم أو السؤال (Front) | الإجابة والشرح النموذجي (Back) | مستوى الإتقان | الحالة |
| :-: | :-- | :-- | :-: | :-: |
${flashcards.map((f, i) => `| ${i + 1} | ${f.front.replace(/\|/g, '\\|').replace(/\n/g, ' ')} | ${f.back.replace(/\|/g, '\\|').replace(/\n/g, ' ')} | Lvl ${f.level} | ${f.mistake ? '⚠️ يحتاج تثبيت' : '✅ متقن'} |`).join('\n')}

---
*تم التصدير بنجاح عبر منصة «المعلم الذكي» — وثيقة أكاديمية جاهزة للربط الفوري في أنظمة إدارة المعرفة Obsidian و Notion.*
`;
    return md;
  };

  const handleExportMarkdownObsidianNotion = () => {
    const md = generateStructuredMarkdown();
    const blob = new Blob([md], { type: 'text/markdown;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    const safeTitle = (currentNotebook.name || 'study_notes').replace(/[/\\?%*:|"<> ]/g, '_');
    a.download = `${safeTitle}_Obsidian_Notion.md`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    // Also copy to clipboard for instant pasting
    if (navigator?.clipboard?.writeText) {
      navigator.clipboard.writeText(md).then(() => {
        setCopiedMd(true);
        setTimeout(() => setCopiedMd(false), 3500);
      }).catch(() => {});
    }
  };

  const insertSnippet = (snippet: string) => {
    setCustomContent((prev) => prev + '\n\n' + snippet + '\n');
  };

  // Print as PDF via native browser engine (supports Arabic RTL typography, vector graphics, A4)
  const handlePrint = () => {
    window.print();
  };

  const handleApplyTemplate = (type: 'summary' | 'exam' | 'cheat_sheet') => {
    if (type === 'summary') {
      setCustomContent(
`# 📚 ملخص شامل: ${currentNotebook.name}

## 1. الأهداف التعليمية
- فهم الأسس النظرية للموضوع.
- تطبيق القواعد على المسائل التوضيحية.

## 2. المفاهيم والمصطلحات الأساسية
- **المصطلح الأول**: التعريف الشامل والدقيق.
- **المصطلح الثاني**: الاستخدام والخصائص المميزة.

## 3. خطوات الحل والقوانين
1. تحديد المعطيات والمطلوب بدقة.
2. تطبيق المعادلة أو القانون المناسب.
3. التحقق من النتيجة وتفسيرها علمياً.

## 4. خلاصة سريعة
ملخص مركز وموجز يمكن مراجعته في 5 دقائق قبل الامتحان.`
      );
    } else if (type === 'exam') {
      setCustomContent(
`# 📝 مراجعة ليلة الاختبار: ${currentNotebook.name}

## 🎯 النقاط الأكثر تكراراً في الامتحانات
- الأسئلة المقالية الشائعة وكيفية صياغة الإجابة النموذجية.
- الفروقات والمقارنات الجوهرية بين المفاهيم.

## ⚠️ الأخطاء الشائعة لتجنبها
- الخلط بين التعريفات المتشابهة.
- إهمال كتابة وحدات القياس أو خطوات الحل.

## 🔑 كبسولة الحفظ السريع
ملاحظات سريعة ومعادلات أساسية للتذكر الفوري.`
      );
    } else if (type === 'cheat_sheet') {
      setCustomContent(
`# ⚡ ورقة القوانين والمعادلات السريعة (Cheat Sheet)

## الجداول والمقارنات
| المفهوم | القاعدة | مثال توضيحي |
| :--- | :--- | :--- |
| المبدأ الأول | القانون الرياضي 1 | تطبيق مباشر |
| المبدأ الثاني | القانون الرياضي 2 | تطبيق فرعي |

## ملاحظات إضافية
سجل هنا أي تنبيهات أو أسئلة متوقعة.`
      );
    }
  };

  const handleImportFromNote = (note: NoteItem) => {
    setDocTitle(note.title);
    setCustomSubject(note.subject);
    setCustomContent(`# ${note.title}\n\n**الهدف**: ${note.goal}\n\n${note.text}`);
  };

  const handleRestoreFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (parsed.notebooks && Array.isArray(parsed.notebooks)) {
          if (confirm('هل تريد استعادة هذه البيانات واستبدال المحتوى الحالي؟')) {
            onImportData(parsed);
            alert('تمت استعادة البيانات بنجاح.');
          }
        } else {
          alert('ملف النسخة الاحتياطية غير صالح.');
        }
      } catch (err) {
        alert('حدث خطأ في قراءة ملف النسخة الاحتياطية.');
      }
    };
    reader.readAsText(file);
  };

  // Helper renderer for custom markdown-like text with specialized rich study callout boxes
  const renderCustomContent = (text: string) => {
    const lines = text.split('\n');
    const isPrintFriendly = printMode === 'print_friendly';

    const renderedElements: React.ReactNode[] = [];
    let tableBuffer: string[] = [];

    const flushTable = (key: number) => {
      if (tableBuffer.length === 0) return null;
      const rows = tableBuffer.map((r) =>
        r
          .split('|')
          .map((c) => c.trim())
          .filter((_, idx, arr) => idx > 0 && idx < arr.length - 1)
      );
      tableBuffer = [];

      const header = rows[0];
      const dataRows = rows.slice(2);

      return (
        <div key={`table-${key}`} className="my-4 overflow-x-auto print-break-inside-avoid">
          <table className={`w-full border-collapse text-xs ${isPrintFriendly ? 'border border-black' : 'border border-gray-300'}`}>
            {header && (
              <thead>
                <tr className={isPrintFriendly ? 'bg-gray-200 text-black border-b border-black font-bold' : 'bg-teal-50 text-teal-950 border-b border-teal-200 font-bold'}>
                  {header.map((col, colIdx) => (
                    <th key={colIdx} className="p-2.5 text-right border border-inherit">
                      {col}
                    </th>
                  ))}
                </tr>
              </thead>
            )}
            <tbody>
              {dataRows.map((row, rIdx) => (
                <tr key={rIdx} className={rIdx % 2 === 0 ? 'bg-white' : isPrintFriendly ? 'bg-gray-50' : 'bg-teal-50/20'}>
                  {row.map((cell, cIdx) => (
                    <td key={cIdx} className="p-2 border border-inherit text-gray-800">
                      {cell}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      );
    };

    lines.forEach((line, idx) => {
      const trimmed = line.trim();

      if (trimmed.startsWith('|') && trimmed.endsWith('|')) {
        tableBuffer.push(trimmed);
        return;
      } else if (tableBuffer.length > 0) {
        renderedElements.push(flushTable(idx));
      }

      if (!trimmed) {
        renderedElements.push(<div key={idx} className="h-2" />);
        return;
      }

      // Definition Box
      if (trimmed.startsWith('> 💡') || trimmed.startsWith('> تعريف')) {
        renderedElements.push(
          <div
            key={idx}
            className={`p-3.5 my-2.5 rounded-xl border-r-4 print-break-inside-avoid ${
              isPrintFriendly
                ? 'bg-gray-50 border-black border text-black'
                : 'bg-teal-50/80 border-[#0f766e] text-teal-950 shadow-xs'
            }`}
          >
            <div className="flex items-center gap-1.5 font-bold text-xs mb-1">
              <Lightbulb className="w-3.5 h-3.5" />
              <span>مفهوم وتعريف محوري</span>
            </div>
            <div className="text-xs leading-relaxed">
              {trimmed.replace(/^>\s*(💡\s*)?(تعريف\s*(أساسي)?\s*:?)?/, '')}
            </div>
          </div>
        );
        return;
      }

      // Law / Formula Box
      if (trimmed.startsWith('> 📐') || trimmed.startsWith('> قانون')) {
        renderedElements.push(
          <div
            key={idx}
            className={`p-3.5 my-2.5 rounded-xl border-r-4 print-break-inside-avoid ${
              isPrintFriendly
                ? 'bg-gray-50 border-black border text-black font-mono'
                : 'bg-blue-50/80 border-blue-600 text-blue-950 font-mono shadow-xs'
            }`}
          >
            <div className="flex items-center gap-1.5 font-bold text-xs mb-1 font-sans">
              <Sigma className="w-3.5 h-3.5" />
              <span>قانون وقاعدة رياضية</span>
            </div>
            <div className="text-xs leading-relaxed font-bold">
              {trimmed.replace(/^>\s*(📐\s*)?(قانون\s*(أساسي)?\s*:?)?/, '')}
            </div>
          </div>
        );
        return;
      }

      // Warning / Exam Alert Box
      if (trimmed.startsWith('> ⚠️') || trimmed.startsWith('> تنبيه') || trimmed.startsWith('> تحذير')) {
        renderedElements.push(
          <div
            key={idx}
            className={`p-3.5 my-2.5 rounded-xl border-r-4 print-break-inside-avoid ${
              isPrintFriendly
                ? 'bg-gray-50 border-black border text-black'
                : 'bg-amber-50/80 border-amber-600 text-amber-950 shadow-xs'
            }`}
          >
            <div className="flex items-center gap-1.5 font-bold text-xs mb-1">
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>تنبيه هام للاختبار</span>
            </div>
            <div className="text-xs leading-relaxed">
              {trimmed.replace(/^>\s*(⚠️\s*)?(تنبيه|تحذير)?\s*:?/, '')}
            </div>
          </div>
        );
        return;
      }

      // Solved Example Box
      if (trimmed.startsWith('> 📝') || trimmed.startsWith('> مثال')) {
        renderedElements.push(
          <div
            key={idx}
            className={`p-3.5 my-2.5 rounded-xl border-r-4 print-break-inside-avoid ${
              isPrintFriendly
                ? 'bg-gray-50 border-black border text-black'
                : 'bg-emerald-50/80 border-emerald-600 text-emerald-950 shadow-xs'
            }`}
          >
            <div className="flex items-center gap-1.5 font-bold text-xs mb-1">
              <FileCheck className="w-3.5 h-3.5" />
              <span>تطبيق ومثال نموذجي</span>
            </div>
            <div className="text-xs leading-relaxed">
              {trimmed.replace(/^>\s*(📝\s*)?(مثال(\s*محلول)?\s*:?)?/, '')}
            </div>
          </div>
        );
        return;
      }

      // Generic Blockquote
      if (trimmed.startsWith('> ')) {
        renderedElements.push(
          <blockquote
            key={idx}
            className={`p-3 my-2 border-r-3 text-xs italic ${
              isPrintFriendly ? 'bg-gray-50 border-gray-400 text-gray-800' : 'bg-gray-50 border-[#0f766e] text-gray-700'
            }`}
          >
            {trimmed.replace('> ', '')}
          </blockquote>
        );
        return;
      }

      if (trimmed.startsWith('# ')) {
        renderedElements.push(
          <h1 key={idx} className="text-xl sm:text-2xl font-black text-gray-900 border-b pb-2 mb-3 mt-4 print-break-inside-avoid">
            {trimmed.replace('# ', '')}
          </h1>
        );
        return;
      }

      if (trimmed.startsWith('## ')) {
        renderedElements.push(
          <h2 key={idx} className="text-lg font-bold text-gray-800 border-b pb-1 mb-2 mt-3 print-break-inside-avoid">
            {trimmed.replace('## ', '')}
          </h2>
        );
        return;
      }

      if (trimmed.startsWith('### ')) {
        renderedElements.push(
          <h3 key={idx} className="text-base font-bold text-gray-800 mb-1 mt-2 print-break-inside-avoid">
            {trimmed.replace('### ', '')}
          </h3>
        );
        return;
      }

      if (trimmed.startsWith('- ') || trimmed.startsWith('* ')) {
        renderedElements.push(
          <li key={idx} className="list-disc list-inside text-gray-700 leading-relaxed pr-2">
            {trimmed.replace(/^[-*]\s+/, '')}
          </li>
        );
        return;
      }

      if (/^\d+\.\s+/.test(trimmed)) {
        renderedElements.push(
          <li key={idx} className="list-decimal list-inside text-gray-700 leading-relaxed pr-2">
            {trimmed.replace(/^\d+\.\s+/, '')}
          </li>
        );
        return;
      }

      renderedElements.push(
        <p key={idx} className="text-gray-700 leading-relaxed">
          {line}
        </p>
      );
    });

    if (tableBuffer.length > 0) {
      renderedElements.push(flushTable(999999));
    }

    return <div className="space-y-2">{renderedElements}</div>;
  };

  return (
    <div className="space-y-6">
      {/* Print Page Setup Style */}
      <style>{`
        @media print {
          @page {
            size: A4 ${orientation};
            margin: 12mm;
          }
          body {
            background: #ffffff !important;
            color: #000000 !important;
          }
          .no-print {
            display: none !important;
          }
          #printable-document {
            border: none !important;
            box-shadow: none !important;
            padding: 0 !important;
            margin: 0 !important;
            max-width: 100% !important;
            width: 100% !important;
          }
          .print-break-inside-avoid {
            break-inside: avoid !important;
            page-break-inside: avoid !important;
          }
        }
      `}</style>

      {/* Header & Controls */}
      <div className="bg-white dark:bg-[#14201c] rounded-2xl border border-[#e2e8e5] dark:border-[#22352f] p-5 shadow-sm no-print">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
          <div>
            <h2 className="text-lg font-bold text-[#17201e] dark:text-[#eef7f4] flex items-center gap-2">
              <Layers className="w-5 h-5 text-[#0f766e] dark:text-[#2dd4bf]" />
              <span>مركز التصدير وطباعة PDF وإضافة الملخصات الخاصة</span>
            </h2>
            <p className="text-xs text-[#596762] dark:text-[#9ab3ab] mt-1">
              خصّص ملخصاتك، أضف صناديق القوانين والتعريفات، واختر بين الطباعة الملونة الاحترافية أو الطباعة الاقتصادية الموفرة للحبر.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleExportMarkdownObsidianNotion}
              className="px-4 py-2.5 bg-gradient-to-r from-purple-700 to-indigo-700 hover:from-purple-800 hover:to-indigo-800 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-md shadow-purple-900/20 transition-all cursor-pointer group"
              title="تصدير ملف Markdown (.md) متقدم مع واجهة Frontmatter والمعادلات الرياضية $$...$$ والمراجع جاهز للاستيراد في Obsidian و Notion"
            >
              <FileDown className="w-4 h-4 group-hover:-translate-y-0.5 transition-transform" />
              <span>{copiedMd ? 'تم النسخ والتحميل! 🎉' : 'تصدير Obsidian / Notion (.md)'}</span>
            </button>

            <button
              onClick={handlePrint}
              className="px-4 py-2.5 bg-[#0f766e] text-white rounded-xl text-xs font-bold hover:bg-[#115e59] flex items-center gap-2 shadow-md shadow-[#0f766e]/20 transition-all cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>طباعة / حفظ PDF</span>
            </button>

            <button
              onClick={onExportAllData}
              className="px-3.5 py-2 border border-[#e2e8e5] dark:border-[#22352f] text-[#596762] dark:text-[#9ab3ab] rounded-xl text-xs font-bold hover:bg-gray-50 dark:hover:bg-gray-800 flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span>JSON</span>
            </button>

            <button
              onClick={() => restoreFileInputRef.current?.click()}
              className="px-3.5 py-2 border border-[#e2e8e5] dark:border-[#22352f] text-[#596762] dark:text-[#9ab3ab] rounded-xl text-xs font-bold hover:bg-gray-50 dark:hover:bg-gray-800 flex items-center gap-1.5"
            >
              <Upload className="w-4 h-4" />
              <span>استعادة</span>
            </button>
            <input
              ref={restoreFileInputRef}
              type="file"
              accept=".json"
              onChange={handleRestoreFile}
              className="hidden"
            />
          </div>
        </div>

        {/* Template & Style Controls */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-3 border-t border-[#e2e8e5] dark:border-[#22352f]">
          <div>
            <label className="block text-[11px] font-bold text-[#596762] dark:text-[#9ab3ab] mb-1">
              نوع المستند المطلوب طباعته
            </label>
            <select
              value={docType}
              onChange={(e: any) => {
                setDocType(e.target.value);
                if (e.target.value === 'custom_summary') {
                  setDocTitle(`ملخص دراسي خاص - ${currentNotebook.name}`);
                } else if (e.target.value === 'study_guide') {
                  setDocTitle(`دليل دراسة - ${currentNotebook.name}`);
                } else if (e.target.value === 'mindmap') {
                  setDocTitle(`خريطة ذهنية مطبوعة - ${currentNotebook.name}`);
                }
              }}
              className="w-full px-3 py-2 bg-[#f6f8f7] dark:bg-[#1a2723] border border-[#e2e8e5] dark:border-[#22352f] rounded-xl text-xs font-bold"
            >
              <option value="custom_summary">✍️ ملخص ومعلومات خاصة بي (نص مخصص)</option>
              <option value="markdown_preview">💎 وثيقة Markdown المهيكلة لـ Obsidian و Notion</option>
              <option value="study_guide">📚 دليل المذاكرة الشامل</option>
              <option value="mindmap">🗺️ الخريطة الذهنية البصرية</option>
              <option value="chat_log">💬 سجل المحادثة المعرفية</option>
              <option value="flashcards">🗂️ قائمة بطاقات الاسترجاع</option>
              <option value="sources_summary">📄 ملخص المصادر المضافة</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-[#596762] dark:text-[#9ab3ab] mb-1">
              نمط الطباعة واستهلاك الحبر
            </label>
            <select
              value={printMode}
              onChange={(e: any) => setPrintMode(e.target.value)}
              className="w-full px-3 py-2 bg-[#f6f8f7] dark:bg-[#1a2723] border border-[#e2e8e5] dark:border-[#22352f] rounded-xl text-xs font-bold"
            >
              <option value="colored">🎨 PDF ملون احترافي (Full Color)</option>
              <option value="print_friendly">🖨️ PDF اقتصادي للطابعة (Print-Friendly Ink-Saver)</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-[#596762] dark:text-[#9ab3ab] mb-1">
              اتجاه الصفحة (A4)
            </label>
            <select
              value={orientation}
              onChange={(e: any) => setOrientation(e.target.value)}
              className="w-full px-3 py-2 bg-[#f6f8f7] dark:bg-[#1a2723] border border-[#e2e8e5] dark:border-[#22352f] rounded-xl text-xs font-bold"
            >
              <option value="portrait">عمودي (Portrait - المناسب للنصوص)</option>
              <option value="landscape">أفقي (Landscape - مناسب للجداول والخرائط)</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-[#596762] dark:text-[#9ab3ab] mb-1">
              حجم الخط أثناء الطباعة
            </label>
            <select
              value={fontSize}
              onChange={(e: any) => setFontSize(e.target.value)}
              className="w-full px-3 py-2 bg-[#f6f8f7] dark:bg-[#1a2723] border border-[#e2e8e5] dark:border-[#22352f] rounded-xl text-xs font-bold"
            >
              <option value="sm">صغير (مكثف ومناسب للصفحات الطويلة)</option>
              <option value="md">متوسط (افتراضي متوازن)</option>
              <option value="lg">كبير (مريح وواضح جداً)</option>
            </select>
          </div>
        </div>

        {/* Custom Summary Input Section (When custom_summary is active) */}
        {docType === 'custom_summary' && (
          <div className="mt-4 pt-4 border-t border-[#e2e8e5] dark:border-[#22352f] space-y-3 bg-[#f8fbfa] dark:bg-[#121b18] p-4 rounded-xl">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="text-xs font-bold text-[#17201e] dark:text-[#eef7f4] flex items-center gap-1.5">
                <PenTool className="w-3.5 h-3.5 text-[#0f766e] dark:text-[#2dd4bf]" />
                محرر الملخص والمعلومات الخاصة بك:
              </span>

              {/* Quick Template and Import buttons */}
              <div className="flex flex-wrap items-center gap-1.5 text-xs">
                <button
                  type="button"
                  onClick={() => handleApplyTemplate('summary')}
                  className="px-2.5 py-1 bg-white dark:bg-[#1c2b26] border border-[#e2e8e5] dark:border-[#22352f] rounded-lg text-[#0f766e] dark:text-[#2dd4bf] font-bold hover:bg-teal-50"
                >
                  ملخص شامل
                </button>
                <button
                  type="button"
                  onClick={() => handleApplyTemplate('exam')}
                  className="px-2.5 py-1 bg-white dark:bg-[#1c2b26] border border-[#e2e8e5] dark:border-[#22352f] rounded-lg text-amber-700 dark:text-amber-300 font-bold hover:bg-amber-50"
                >
                  مراجعة اختبار
                </button>
                <button
                  type="button"
                  onClick={() => handleApplyTemplate('cheat_sheet')}
                  className="px-2.5 py-1 bg-white dark:bg-[#1c2b26] border border-[#e2e8e5] dark:border-[#22352f] rounded-lg text-blue-700 dark:text-blue-300 font-bold hover:bg-blue-50"
                >
                  ورقة قوانين
                </button>

                {notes && notes.length > 0 && (
                  <select
                    onChange={(e) => {
                      const selected = notes.find((n) => n.id === e.target.value);
                      if (selected) handleImportFromNote(selected);
                    }}
                    defaultValue=""
                    className="px-2 py-1 bg-white dark:bg-[#1c2b26] border border-[#e2e8e5] dark:border-[#22352f] rounded-lg text-xs font-bold text-[#17201e] dark:text-[#eef7f4]"
                  >
                    <option value="" disabled>استيراد من ملاحظاتي ({notes.length})...</option>
                    {notes.map((n) => (
                      <option key={n.id} value={n.id}>
                        {n.title}
                      </option>
                    ))}
                  </select>
                )}
              </div>
            </div>

            {/* Quick Box Insertion Toolbar */}
            <div className="flex flex-wrap items-center gap-1.5 p-2 bg-white dark:bg-[#15231f] rounded-lg border border-[#e2e8e5] dark:border-[#22352f]">
              <span className="text-[11px] font-bold text-[#596762] dark:text-[#9ab3ab] pl-1">
                إدراج سريع:
              </span>
              <button
                type="button"
                onClick={() => insertSnippet('> 💡 **تعريف**: اكتب المصطلح والتعريف العلمي هنا.')}
                className="px-2 py-1 bg-teal-50 dark:bg-teal-950/60 text-[#0f766e] dark:text-[#2dd4bf] rounded text-[11px] font-bold hover:opacity-80 flex items-center gap-1 cursor-pointer"
              >
                <Lightbulb className="w-3 h-3" />
                <span>+ صندوق تعريف</span>
              </button>
              <button
                type="button"
                onClick={() => insertSnippet('> 📐 **قانون**: اكتب المعادلة الرياضية أو القانون هنا.')}
                className="px-2 py-1 bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 rounded text-[11px] font-bold hover:opacity-80 flex items-center gap-1 cursor-pointer"
              >
                <Sigma className="w-3 h-3" />
                <span>+ قانون رياضي</span>
              </button>
              <button
                type="button"
                onClick={() => insertSnippet('> ⚠️ **ملاحظة هامة**: تنبيه أو خطأ شائع يجب الانتباه له.')}
                className="px-2 py-1 bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 rounded text-[11px] font-bold hover:opacity-80 flex items-center gap-1 cursor-pointer"
              >
                <AlertTriangle className="w-3 h-3" />
                <span>+ تنبيه هام</span>
              </button>
              <button
                type="button"
                onClick={() => insertSnippet('> 📝 **مثال محلول**: المسألة والتطبيق العملي وخطوات الوصول للنتيجة.')}
                className="px-2 py-1 bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 rounded text-[11px] font-bold hover:opacity-80 flex items-center gap-1 cursor-pointer"
              >
                <FileCheck className="w-3 h-3" />
                <span>+ مثال محلول</span>
              </button>
              <button
                type="button"
                onClick={() => insertSnippet('| وجه المقارنة | العنصر الأول | العنصر الثاني |\n| :--- | :--- | :--- |\n| التعريف الأساسي | ... | ... |\n| التطبيق العملي | ... | ... |')}
                className="px-2 py-1 bg-purple-50 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 rounded text-[11px] font-bold hover:opacity-80 flex items-center gap-1 cursor-pointer"
              >
                <Table className="w-3 h-3" />
                <span>+ جدول مقارنة</span>
              </button>
            </div>

            <textarea
              rows={8}
              value={customContent}
              onChange={(e) => setCustomContent(e.target.value)}
              placeholder="اكتب أو الصق هنا ملخصك أو ملاحظاتك أو أي نص أو معلومات ترغب بطباعتها كـ PDF..."
              className="w-full p-3 bg-white dark:bg-[#182622] border border-[#e2e8e5] dark:border-[#22352f] rounded-xl text-xs font-mono text-[#17201e] dark:text-[#eef7f4] focus:outline-none focus:ring-2 focus:ring-[#0f766e] leading-relaxed"
            />

            <div className="flex flex-wrap items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-2">
                <label className="text-[11px] font-bold text-[#596762] dark:text-[#9ab3ab]">اسم المعد / الطالب:</label>
                <input
                  type="text"
                  value={authorName}
                  onChange={(e) => setAuthorName(e.target.value)}
                  className="px-2.5 py-1 bg-white dark:bg-[#1c2b26] border border-[#e2e8e5] dark:border-[#22352f] rounded-lg text-xs font-bold"
                />
              </div>

              <div className="flex items-center gap-2">
                <label className="text-[11px] font-bold text-[#596762] dark:text-[#9ab3ab]">المادة / التصنيف:</label>
                <input
                  type="text"
                  value={customSubject}
                  onChange={(e) => setCustomSubject(e.target.value)}
                  className="px-2.5 py-1 bg-white dark:bg-[#1c2b26] border border-[#e2e8e5] dark:border-[#22352f] rounded-lg text-xs font-bold"
                />
              </div>

              <div className="text-[11px] text-[#596762] dark:text-[#9ab3ab]">
                {customContent.split(/\s+/).filter(Boolean).length} كلمة • {customContent.split('\n').length} سطر
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Live Document Preview Frame (What you see is what prints!) */}
      <div className="bg-gray-100 dark:bg-[#0c1311] p-4 lg:p-8 rounded-2xl border border-[#e2e8e5] dark:border-[#22352f] flex flex-col items-center">
        <div className={`w-full ${orientation === 'landscape' ? 'max-w-[1000px]' : 'max-w-[800px]'} flex items-center justify-between mb-3 text-xs text-[#596762] dark:text-[#9ab3ab] no-print`}>
          <span className="font-bold flex items-center gap-1">
            <Eye className="w-3.5 h-3.5 text-[#0f766e] dark:text-[#2dd4bf]" />
            معاينة المستند الحي (بالمقاييس الطباعية A4 - {orientation === 'landscape' ? 'أفقي' : 'عمودي'}):
          </span>
          <button
            onClick={handlePrint}
            className="text-[#0f766e] dark:text-[#2dd4bf] font-bold hover:underline flex items-center gap-1 cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            طباعة المستند الآن
          </button>
        </div>

        <div
          ref={printAreaRef}
          id="printable-document"
          className={`w-full ${
            orientation === 'landscape' ? 'max-w-[1000px]' : 'max-w-[800px]'
          } bg-white text-gray-900 shadow-xl rounded-2xl p-8 sm:p-12 border border-gray-200 print:border-none print:shadow-none print:p-0 print:m-0 print:w-full ${
            fontSize === 'sm' ? 'text-xs' : fontSize === 'lg' ? 'text-base' : 'text-sm'
          }`}
          dir="rtl"
        >
          {/* Document Header */}
          <div
            className={`pb-4 mb-6 border-b-2 ${
              printMode === 'print_friendly'
                ? 'border-black'
                : colorTheme === 'teal'
                ? 'border-[#0f766e]'
                : colorTheme === 'navy'
                ? 'border-blue-900'
                : 'border-gray-800'
            } flex items-start justify-between`}
          >
            <div>
              <h1
                className={`text-xl sm:text-2xl font-black ${
                  printMode === 'print_friendly'
                    ? 'text-black'
                    : colorTheme === 'teal'
                    ? 'text-[#0f766e]'
                    : colorTheme === 'navy'
                    ? 'text-blue-900'
                    : 'text-gray-900'
                }`}
              >
                {docTitle}
              </h1>
              <div className="text-xs text-gray-500 mt-1 flex flex-wrap items-center gap-2">
                <span>دفتر: {currentNotebook.name}</span>
                <span>•</span>
                <span>المادة: {docType === 'custom_summary' ? customSubject : currentNotebook.subject}</span>
                {authorName && (
                  <>
                    <span>•</span>
                    <span>إعداد: {authorName}</span>
                  </>
                )}
                <span>•</span>
                <span>تاريخ الطباعة: {new Date().toLocaleDateString('ar')}</span>
              </div>
            </div>

            <div className="text-right">
              <span className="text-[11px] font-bold text-gray-400">منصة المعلم الذكي</span>
            </div>
          </div>

          {/* Document Content based on docType */}
          {docType === 'custom_summary' && (
            <div className="space-y-4">
              {renderCustomContent(customContent || 'لم تتم كتابة أي نص بعد. يمكنك كتابة ملخصك في المربع أعلاه.')}
            </div>
          )}

          {docType === 'mindmap' && (
            <div className="space-y-4 print-break-inside-avoid">
              <div className="text-xs text-gray-500 mb-2">
                مخطط هيكلي وتشعيبي شامل لموضوعات الدفتر
              </div>
              <InteractiveMindMap readOnly />
            </div>
          )}

          {docType === 'study_guide' && (
            <div className="space-y-6 leading-relaxed">
              <section className="print-break-inside-avoid">
                <h2 className="font-bold text-base text-gray-800 border-b pb-1 mb-2">
                  1. نظرة عامة على مصادر الدراسة
                </h2>
                <p className="text-gray-700">
                  يحتوي هذا الدفتر على {sources.length} من المصادر والوثائق المفهرسة التي تم تحليلها واستخراج مفاهيمها الأساسية.
                </p>
                <ul className="list-disc list-inside mt-2 space-y-1 text-gray-600">
                  {sources.map((s) => (
                    <li key={s.id}>
                      <b>{s.title}</b> ({s.wordCount} كلمة {s.pageCount ? `• ${s.pageCount} صفحة` : ''})
                    </li>
                  ))}
                </ul>
              </section>

              <section className="print-break-inside-avoid">
                <h2 className="font-bold text-base text-gray-800 border-b pb-1 mb-2">
                  2. ملخص المفاهيم والأسئلة الشائعة
                </h2>
                <div className="space-y-3">
                  {chatSession.messages
                    .filter((m) => m.role === 'ai')
                    .slice(-3)
                    .map((m, i) => (
                      <div key={i} className="p-3 bg-gray-50 rounded-xl border border-gray-200">
                        <div className="whitespace-pre-wrap">{m.text}</div>
                      </div>
                    ))}
                </div>
              </section>
            </div>
          )}

          {docType === 'chat_log' && (
            <div className="space-y-4">
              {chatSession.messages.map((m, idx) => (
                <div key={idx} className="space-y-1 print-break-inside-avoid">
                  <div className="font-bold text-xs text-gray-500">
                    {m.role === 'user' ? '👤 سؤال المتعلم:' : '✦ إجابة المعلم الذكي:'}
                  </div>
                  <div
                    className={`p-3 rounded-xl border ${
                      m.role === 'user'
                        ? 'bg-gray-100 border-gray-300 font-semibold'
                        : 'bg-white border-gray-200 whitespace-pre-wrap'
                    }`}
                  >
                    {m.text}
                  </div>
                </div>
              ))}
            </div>
          )}

          {docType === 'flashcards' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {flashcards.map((c, idx) => (
                <div key={idx} className="p-3 rounded-xl border border-gray-200 bg-gray-50 space-y-2 print-break-inside-avoid">
                  <div className="text-[11px] font-bold text-gray-500">بطاقة {idx + 1}</div>
                  <div className="font-bold text-gray-900">{c.front}</div>
                  <div className="pt-2 border-t border-gray-200 text-gray-700 text-xs">
                    {c.back}
                  </div>
                </div>
              ))}
            </div>
          )}

          {docType === 'sources_summary' && (
            <div className="space-y-4">
              {sources.map((s) => (
                <div key={s.id} className="p-4 rounded-xl border border-gray-200 bg-gray-50 print-break-inside-avoid">
                  <h3 className="font-bold text-base text-gray-900">{s.title}</h3>
                  <div className="text-xs text-gray-500 mb-2">
                    النوع: {s.type} • الحجم: {Math.round(s.size / 1024)} KB • الكلمات: {s.wordCount}
                  </div>
                  <p className="text-gray-700 whitespace-pre-wrap text-xs line-clamp-6">
                    {s.content.slice(0, 500)}...
                  </p>
                </div>
              ))}
            </div>
          )}

          {docType === 'markdown_preview' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 bg-purple-50 rounded-xl border border-purple-200 text-purple-900 text-xs">
                <div className="flex items-center gap-2">
                  <span className="font-bold">✨ كود Markdown المهيكل (Obsidian & Notion Vault):</span>
                  <span className="text-[11px] text-purple-700">متوافق 100% مع YAML Frontmatter والمراجع الأكاديمية وصيغ LaTeX $$...$$</span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleExportMarkdownObsidianNotion}
                    className="px-3 py-1 bg-purple-700 hover:bg-purple-800 text-white rounded-lg font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>تحميل .md</span>
                  </button>
                </div>
              </div>
              <pre className="p-4 bg-slate-900 text-emerald-300 rounded-2xl text-xs font-mono leading-relaxed overflow-x-auto text-left max-h-[600px] select-all border border-slate-800" dir="ltr">
                {generateStructuredMarkdown()}
              </pre>
            </div>
          )}

          {/* Document Footer */}
          <div className="mt-10 pt-4 border-t border-gray-200 flex items-center justify-between text-[11px] text-gray-400">
            <span>تم التوليد عبر تطبيق «المعلم الذكي»</span>
            <span>وثيقة تعليمية معتمدة للطباعة</span>
          </div>
        </div>
      </div>
    </div>
  );
};
