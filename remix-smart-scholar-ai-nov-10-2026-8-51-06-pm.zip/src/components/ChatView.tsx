import React, { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import { 
  BookOpen, 
  Globe, 
  Sparkles, 
  Printer, 
  ArrowDown, 
  ArrowRight,
  FileText,
  FileDown,
  GitFork,
  Download,
  Loader2,
  MoreVertical,
  Plus,
  Cpu,
  Key,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  Settings,
  ShieldCheck,
  X,
  History
} from 'lucide-react';
import { 
  ChatSession, 
  Source, 
  SourceChunk, 
  AIMode, 
  Citation, 
  FallbackAISettings, 
  SourceAnnotation 
} from '../types';
import { getApiUrl, DEFAULT_CLOUD_BACKEND, isStandaloneApp } from '../lib/apiConfig';
import { solveAcademicallyOffline } from '../lib/autonomousSolver';
import { callDirectGeminiWithKeyRotation } from '../lib/clientGeminiService';
import { searchChunks, formatContext, isComprehensiveQuery, getComprehensiveChunks } from '../lib/retrieval';
import { retrieveEnhancedRAGContext, isComprehensiveBookQuery } from '../lib/ragService';
import { vectorStore } from '../lib/vectorStore';
import { EducationalContent } from './EducationalContent';
import { AcademicPrintModal } from './AcademicPrintModal';
import { PDFPreviewAnnotator } from './PDFPreviewAnnotator';
import { resolveSourceTarget, ResolvedSourceTarget } from '../lib/sourceLinker';
import { 
  extractStructuredSummary, 
  StructuredSummary,
  conversationHistoryToStructuredSummary,
  generateIntelligentAcademicSummary,
  generateIntelligentConversationSummary,
  exportConversationThreadToPdf
} from '../lib/academicFormatter';
import { ChatMessageItem } from './ChatMessageItem';
import { ChatInputArea } from './ChatInputArea';
import { ChatHistoryDrawer } from './ChatHistoryDrawer';
import { isAppIdentityInquiry, getAppIdentityResponse } from '../lib/identityAttribution';

interface ChatViewProps {
  session: ChatSession;
  allSessions: ChatSession[];
  onSelectSession: (id: string) => void;
  onNewSession: () => void;
  onDeleteSession: (id: string) => void;
  onRenameSession?: (id: string, newTitle: string) => void;
  sources: Source[];
  chunks: SourceChunk[];
  selectedSourceIds: string[];
  onUpdateSessionSources?: (sessionId: string, sourceIds: string[]) => void;
  currentNotebookId?: string;
  notebookTitle?: string;
  notebookSubject?: string;
  aiMode: AIMode;
  onChangeAIMode: (mode: AIMode) => void;
  fallbackConfig?: FallbackAISettings;
  onSendMessage: (
    userMsg: string, 
    aiResponse: string, 
    citations?: Citation[], 
    grounding?: any,
    providerInfo?: any,
    suggestedNextPrompt?: string,
    suggestedNextUnit?: string
  ) => void;
  onDeleteMessage: (msgId: string) => void;
  onRateMessage?: (msgId: string, feedback: 'like' | 'dislike' | null) => void;
  viewportHeight?: number | null;
  onNavigateToStudio?: () => void;
  onNavigateHome?: () => void;
  onUpdateSourceAnnotations?: (sourceId: string, annotations: SourceAnnotation[]) => void;
  onAskAboutQuote?: (quote: string, pageNumber: number) => void;
  onExportToNote?: (title: string, content: string) => void;
  onGenerateMindMapFromText?: (text: string) => void;
  onGenerateMindMapFromConversation?: (messages: ChatSession['messages']) => void;
  onAddUserMessage?: (text: string) => string;
  onAddAiResponse?: (
    aiResponse: string, 
    citations?: Citation[], 
    grounding?: any,
    providerInfo?: any,
    suggestedNextPrompt?: string,
    suggestedNextUnit?: string
  ) => void;
  prefilledPrompt?: string;
  onClearPrefilledPrompt?: () => void;
}

export const ChatView: React.FC<ChatViewProps> = ({
  session,
  allSessions,
  onSelectSession,
  onNewSession,
  onDeleteSession,
  onRenameSession,
  sources,
  chunks,
  selectedSourceIds,
  onUpdateSessionSources,
  currentNotebookId,
  notebookTitle,
  notebookSubject,
  aiMode,
  onChangeAIMode,
  fallbackConfig,
  onSendMessage,
  onDeleteMessage,
  onRateMessage,
  viewportHeight,
  onNavigateHome,
  onUpdateSourceAnnotations,
  onAskAboutQuote,
  onExportToNote,
  onGenerateMindMapFromText,
  onGenerateMindMapFromConversation,
  onAddUserMessage,
  onAddAiResponse,
  prefilledPrompt,
  onClearPrefilledPrompt,
}) => {
  // Generation & Streaming States
  const [isGenerating, setIsGenerating] = useState(false);
  const [pendingUserPrompt, setPendingUserPrompt] = useState<string | null>(null);
  const [streamedText, setStreamedText] = useState('');
  const [activeCitations, setActiveCitations] = useState<Citation[]>([]);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [previewCitation, setPreviewCitation] = useState<Citation | null>(null);
  const [activeSourceLinkTarget, setActiveSourceLinkTarget] = useState<ResolvedSourceTarget | null>(null);
  const [printSummaryData, setPrintSummaryData] = useState<StructuredSummary | null>(null);
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);
  const [isPrintModalLoading, setIsPrintModalLoading] = useState(false);
  const [savedNoteMsgId, setSavedNoteMsgId] = useState<string | null>(null);
  const [isSearchGroundingEnabled, setIsSearchGroundingEnabled] = useState<boolean>(false);
  const [localFeedback, setLocalFeedback] = useState<Record<string, 'like' | 'dislike' | null>>({});
  const [isHeaderMenuOpen, setIsHeaderMenuOpen] = useState(false);
  const [isExportingThreadPdf, setIsExportingThreadPdf] = useState(false);
  const [exportSuccessToast, setExportSuccessToast] = useState(false);
  const [isHistoryDrawerOpen, setIsHistoryDrawerOpen] = useState(false);
  const [isSessionSourcesModalOpen, setIsSessionSourcesModalOpen] = useState(false);
  const [showStarterSuggestions, setShowStarterSuggestions] = useState(false);
  const headerMenuRef = useRef<HTMLDivElement>(null);

  // AI Connection & Engine Settings
  const [showAiSettingsModal, setShowAiSettingsModal] = useState(false);
  const [standaloneApiKey, setStandaloneApiKey] = useState(() => {
    try {
      return localStorage.getItem('standalone_gemini_key') || '';
    } catch {
      return '';
    }
  });
  const [customBackendUrl, setCustomBackendUrl] = useState(() => {
    try {
      return localStorage.getItem('standalone_backend_url') || '';
    } catch {
      return '';
    }
  });
  const [serverHealthStatus, setServerHealthStatus] = useState<'idle' | 'checking' | 'connected' | 'error'>('idle');
  const [serverHealthMsg, setServerHealthMsg] = useState('');
  const [savedSettingsToast, setSavedSettingsToast] = useState(false);

  // Mobile Keyboard & Visual Viewport Handling
  const [visualViewportHeight, setVisualViewportHeight] = useState<number | null>(null);
  const [showScrollBottomBtn, setShowScrollBottomBtn] = useState(false);

  // Provider tracking
  const [currentProviderMeta, setCurrentProviderMeta] = useState<{
    activeProvider: string;
    modelUsed: string;
    fallbackUsed: boolean;
    fallbackReason?: string;
  } | null>(null);

  const abortControllerRef = useRef<AbortController | null>(null);
  const chatBottomRef = useRef<HTMLDivElement>(null);
  const messagesScrollRef = useRef<HTMLDivElement>(null);

  // Test Server Connection
  const checkConnectionStatus = useCallback(async (customKey?: string, customUrl?: string) => {
    setServerHealthStatus('checking');
    setServerHealthMsg('جاري فحص حالة الاتصال بالخادم...');
    try {
      const targetUrl = customUrl ? customUrl.trim().replace(/\/+$/, '') : getApiUrl('/api/health');
      const res = await fetch(targetUrl.includes('/api/health') ? targetUrl : `${targetUrl}/api/health`, {
        signal: AbortSignal.timeout(5000),
      });
      if (res.ok) {
        const data = await res.json().catch(() => ({}));
        setServerHealthStatus('connected');
        setServerHealthMsg(`✓ متصل بنجاح بسحابة المعلم الذكي! (${data.model || 'Gemini 3.8 Flash'})`);
        return true;
      }
    } catch {
      // Check if user provided direct Google Gemini key
      const keyToTest = (customKey !== undefined ? customKey : standaloneApiKey).trim();
      if (keyToTest.startsWith('AIza')) {
        for (const dm of ['gemini-3.8-flash', 'gemini-3.5-flash-lite', 'gemini-3.1-flash-lite']) {
          try {
            const directRes = await fetch(
              `https://generativelanguage.googleapis.com/v1beta/models/${dm}:generateContent?key=${keyToTest}`,
              {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                signal: AbortSignal.timeout(5000),
                body: JSON.stringify({ contents: [{ parts: [{ text: 'ping' }] }] }),
              }
            );
            if (directRes.ok) {
              setServerHealthStatus('connected');
              setServerHealthMsg(`✓ متصل بنجاح عبر مفتاح Google Gemini المباشر! (${dm})`);
              return true;
            }
          } catch {}
        }
      }
      // Autonomous built-in educational engine is always available and 100% active
      setServerHealthStatus('connected');
      setServerHealthMsg('✓ محرك المعلم الذكي الأكاديمي جاهز ونشط بنسبة 100%!');
      return true;
    }
    return false;
  }, [standaloneApiKey]);

  // Proactive Gemini channel warm-up and connection check on mount
  useEffect(() => {
    fetch(getApiUrl('/api/warmup')).catch(() => {});
    checkConnectionStatus();
  }, [checkConnectionStatus]);

  // Close mobile header menu on outside click
  useEffect(() => {
    if (!isHeaderMenuOpen) return;
    const handleClickOutside = (e: MouseEvent) => {
      if (headerMenuRef.current && !headerMenuRef.current.contains(e.target as Node)) {
        setIsHeaderMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isHeaderMenuOpen]);

  // Window Visual Viewport API for Mobile Keyboards (resize only, never on scroll!)
  useEffect(() => {
    if (typeof window === 'undefined') return;

    const handleViewportChange = () => {
      if (window.visualViewport) {
        setVisualViewportHeight(window.visualViewport.height);
      }
    };

    if (window.visualViewport) {
      window.visualViewport.addEventListener('resize', handleViewportChange);
      handleViewportChange();
    }

    return () => {
      if (window.visualViewport) {
        window.visualViewport.removeEventListener('resize', handleViewportChange);
      }
    };
  }, []);

  // Scroll detection to toggle the "Scroll to Bottom" floating button
  const handleScroll = useCallback(() => {
    if (!messagesScrollRef.current) return;
    const { scrollTop, scrollHeight, clientHeight } = messagesScrollRef.current;
    const distanceFromBottom = scrollHeight - (scrollTop + clientHeight);
    setShowScrollBottomBtn(distanceFromBottom > 160);
  }, []);

  // Scroll to bottom helper
  const scrollToBottom = useCallback((smooth = true) => {
    if (chatBottomRef.current) {
      chatBottomRef.current.scrollIntoView({ behavior: smooth ? 'smooth' : 'auto' });
    }
  }, []);

  // Auto-scroll when messages update or text is streaming
  useEffect(() => {
    if (!messagesScrollRef.current) {
      scrollToBottom();
      return;
    }
    const { scrollTop, scrollHeight, clientHeight } = messagesScrollRef.current;
    const isNearBottom = scrollHeight - (scrollTop + clientHeight) < 220;
    if (isNearBottom || isGenerating) {
      scrollToBottom(false);
    }
  }, [session.messages, streamedText, isGenerating, scrollToBottom]);

  // Memoized Action Callbacks to avoid re-rendering message items
  const handleCopy = useCallback((text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  }, []);

  const handleFeedback = useCallback((msgId: string, type: 'like' | 'dislike') => {
    setLocalFeedback((prev) => {
      const current = prev[msgId];
      const next = current === type ? null : type;
      onRateMessage?.(msgId, next);
      return { ...prev, [msgId]: next };
    });
  }, [onRateMessage]);

  const handleDelete = useCallback((msgId: string) => {
    onDeleteMessage(msgId);
  }, [onDeleteMessage]);

  const handleOpenSourceLinker = useCallback((citation: Citation) => {
    const target = resolveSourceTarget(citation, sources);
    if (target) {
      setActiveSourceLinkTarget(target);
    } else {
      setPreviewCitation(citation);
    }
  }, [sources]);

  const handleExportMessagePdf = useCallback(async (text: string) => {
    setIsPrintModalOpen(true);
    setIsPrintModalLoading(true);
    setPrintSummaryData(null);
    try {
      const summary = await generateIntelligentAcademicSummary(
        text,
        session.title || 'شرح وملخص دراسي منظم',
        notebookSubject || 'المنهج الدراسي'
      );
      setPrintSummaryData(summary);
    } catch (e) {
      console.error('Failed to generate summary:', e);
      const fallback = extractStructuredSummary(text, session.title, notebookSubject);
      setPrintSummaryData(fallback);
    } finally {
      setIsPrintModalLoading(false);
    }
  }, [session.title, notebookSubject]);

  const handleExportFullConversationPdf = useCallback(async () => {
    if (!session.messages || session.messages.length === 0) {
      alert('لا توجد رسائل في هذه المحادثة لتصديرها.');
      return;
    }
    setIsPrintModalOpen(true);
    setIsPrintModalLoading(true);
    setPrintSummaryData(null);
    try {
      const summary = await generateIntelligentConversationSummary(
        session.messages,
        session.title || 'جلسة المذاكرة والاستفسار الأكاديمي',
        notebookTitle || 'دفتر المذاكرة الذكي',
        notebookSubject || 'مراجعة المنهج الأكاديمي'
      );
      setPrintSummaryData(summary);
    } catch (e) {
      console.error('Failed to generate full conversation summary:', e);
      const fallback = conversationHistoryToStructuredSummary(
        session.messages,
        session.title,
        notebookTitle,
        notebookSubject
      );
      setPrintSummaryData(fallback);
    } finally {
      setIsPrintModalLoading(false);
    }
  }, [session.messages, session.title, notebookTitle, notebookSubject]);

  const handleExportDirectConversationPdf = useCallback(async () => {
    if (!session.messages || session.messages.length === 0) {
      alert('لا توجد رسائل في هذه المحادثة لتصديرها.');
      return;
    }
    setIsExportingThreadPdf(true);
    try {
      const cleanFileName = `محادثة_${(session.title || 'تقرير_دراسي').replace(/[^\w\u0600-\u06FF]/g, '_').slice(0, 30)}_${Date.now()}.pdf`;
      await exportConversationThreadToPdf(
        session,
        notebookTitle || 'دفتر المذاكرة الذكي',
        notebookSubject || 'المنهج الدراسي',
        cleanFileName
      );
      setExportSuccessToast(true);
      setTimeout(() => setExportSuccessToast(false), 3500);
    } catch (err: any) {
      console.error('Direct PDF export error, falling back to print modal:', err);
      handleExportFullConversationPdf();
    } finally {
      setIsExportingThreadPdf(false);
    }
  }, [session, notebookTitle, notebookSubject, handleExportFullConversationPdf]);

  const handleExportSpecificSessionPdf = useCallback(async (targetSession: ChatSession) => {
    if (!targetSession.messages || targetSession.messages.length === 0) {
      alert('لا توجد رسائل في هذه المحادثة لتصديرها.');
      return;
    }
    setIsExportingThreadPdf(true);
    try {
      const cleanFileName = `محادثة_${(targetSession.title || 'تقرير_دراسي').replace(/[^\w\u0600-\u06FF]/g, '_').slice(0, 30)}_${Date.now()}.pdf`;
      await exportConversationThreadToPdf(
        targetSession,
        notebookTitle || 'دفتر المذاكرة الذكي',
        notebookSubject || 'المنهج الدراسي',
        cleanFileName
      );
      setExportSuccessToast(true);
      setTimeout(() => setExportSuccessToast(false), 3500);
    } catch (err: any) {
      console.error('Direct PDF export error for session:', err);
    } finally {
      setIsExportingThreadPdf(false);
    }
  }, [notebookTitle, notebookSubject]);

  const handleExportMessageToNote = useCallback((msgText: string, msgId: string) => {
    if (!onExportToNote) return;
    const firstLine = msgText.split('\n')[0].replace(/^#+\s*/, '').slice(0, 50) || 'شرح وتلخيص تعليمي';
    onExportToNote(`تدوينة: ${firstLine}`, msgText);
    setSavedNoteMsgId(msgId);
    setTimeout(() => setSavedNoteMsgId(null), 2500);
  }, [onExportToNote]);

  const handleToggleSearchGrounding = useCallback(() => {
    setIsSearchGroundingEnabled((prev) => !prev);
  }, []);

  const activeSessionSourceIds = useMemo(() => {
    return Array.isArray(session.sourceIds) ? session.sourceIds : selectedSourceIds;
  }, [session.sourceIds, selectedSourceIds]);

  const handleToggleSessionSource = (sourceId: string) => {
    const current = Array.isArray(session.sourceIds) ? session.sourceIds : selectedSourceIds;
    const next = current.includes(sourceId)
      ? current.filter((id) => id !== sourceId)
      : [...current, sourceId];
    if (onUpdateSessionSources) {
      onUpdateSessionSources(session.id, next);
    }
  };

  const handleSelectAllSessionSources = () => {
    const allIds = sources.map((s) => s.id);
    if (onUpdateSessionSources) {
      onUpdateSessionSources(session.id, allIds);
    }
  };

  const handleClearAllSessionSources = () => {
    if (onUpdateSessionSources) {
      onUpdateSessionSources(session.id, []);
    }
  };

  // Main Send Handler - Invoked from ChatInputArea with pure text
  const handleSend = useCallback(async (promptText: string) => {
    const promptToSend = promptText.trim();
    if (!promptToSend || isGenerating) return;

    // Show user message immediately in chat feed
    setPendingUserPrompt(promptToSend);
    if (onAddUserMessage) {
      onAddUserMessage(promptToSend);
    }

    // Direct Identity & Designer Response
    if (isAppIdentityInquiry(promptToSend)) {
      const identityText = getAppIdentityResponse();
      setIsGenerating(false);
      setPendingUserPrompt(null);
      setStreamedText('');
      if (onAddAiResponse) {
        onAddAiResponse(identityText, [], undefined, {
          activeProvider: 'gemini',
          modelUsed: 'D.CORE Academic Core',
          fallbackUsed: false,
        });
      } else {
        onSendMessage(promptToSend, identityText, [], undefined, {
          activeProvider: 'gemini',
          modelUsed: 'D.CORE Academic Core',
          fallbackUsed: false,
        });
      }
      return;
    }

    setIsGenerating(true);
    setStreamedText('');
    setActiveCitations([]);
    setCurrentProviderMeta(null);

    // Instant smooth scroll down so user sees their question right away
    setTimeout(() => {
      if (chatBottomRef.current) {
        chatBottomRef.current.scrollIntoView({ behavior: 'smooth' });
      }
    }, 40);

    const controller = new AbortController();
    abortControllerRef.current = controller;
    const requestTimeout = setTimeout(() => {
      controller.abort();
    }, 90000);

    // Scoped chunks for RAG with strict session isolation
    const notebookScopedChunks = currentNotebookId
      ? chunks.filter((c) => !c.notebookId || c.notebookId === currentNotebookId)
      : chunks;

    // Strict Isolated Source Context for this specific session
    const activeSessionSourceIds = Array.isArray(session.sourceIds)
      ? session.sourceIds
      : selectedSourceIds;

    const eligibleChunks = activeSessionSourceIds.length > 0
      ? notebookScopedChunks.filter((c) => activeSessionSourceIds.includes(c.sourceId))
      : [];

    let systemInstruction = '';
    const dynamicIntentRules = `
🏛️ هوية المنصة والمصمم والمطور (Platform & Designer Identity):
تم ابتكار وتصميم وهندسة وبرمجة منصة «المعلم الذكي للدراسة والبحث العلمي» (Smart Scholar AI) بالكامل بواسطة المهندس والمصمم: «ضياء الحق سبيقاء» (Diaa Al-Haq Sabiqaa) بالتعاون مع «فريق D.CORE الأكاديمي». إذا سألك المستخدم عمن صمم أو طور التطبيق أو من يقف وراءه، أجب دائماً باعتزاز ووضوح تام بأن المصمم والمهندس هو ضياء الحق سبيقاء وفريق D.CORE الأكاديمي، ولا تنسب التطبيق لأي شركة أخرى.

🎯 الدخول المباشر في صلب الموضوع (Direct to the Point with Zero Fluff):
- يُحظر تماماً وبشكل قاطع كتابة مقدمات إنشائية، ترحيبات مطولة، أو كلام جانبي غير مفيد (مثل: "أهلاً بك، يسعدني الإجابة، بناءً على سؤالك، بالتأكيد...").
- ابدأ فوراً وبشكل مباشر من أول كلمة في تفكيك وشرح المفاهيم العلمية بأعلى درجات العمق والشمول والتفصيل المنطقي والأكاديمي.

🎯 التكيف التام مع رغبة وأمر المستخدم (Dynamic Depth & Adaptive Intent):
- إذا طلب المستخدم التلخيص (مثل: لخص، ملخص، أوجز، النقاط الرئيسية، الخلاصة): قدّم ملخصاً مركزاً ودقيقاً ومحكماً لأهم النقاط والقوانين دون إسهاب زائد، مع التركيز على جوهر الدرس وخلاصته الامتحانية.
- إذا طلب المستخدم الشرح المفصل، التوسع، الاسترسال، أو شرح كتاب كامل / وحدة دراسية كاملة (مثل: اشرح بالتفصيل، توسع، شرح كامل، كتاب كامل، بالتفصيل الممل، كل الأبواب): يُحظر تماماً وبشكل قاطع الاختصار أو الاكتفاء بالنبذ أو الملخصات السريعة؛ يجب شرح كل باب، وكل فصل، وكل فكرة، وكل قانون، وكل مثال تطبيقي بتفصيل أكاديمي عميق ومستوفٍ من الألف إلى الياء، وتفكيك كافة النقاط خطوة بخطوة مهما طالت الرسالة وبدون أي بتر أو إنقاص للمحتوى.
- إذا سأل المستخدم عن نقطة أو مسألة أو مفهوم بعينه: اشرح تلك النقطة بجميع تفاصيلها الدقيقة وخلفياتها العلمية وقوانينها واستنتاجاتها وحلولها النموذجية دون إهمال أي جزئية دقيقة.

🎯 دعم الأسئلة التفاعلية والخرائط الذهنية المدمجة (Interactive Quizzes & Mind Maps):
- عندما يطلب الطالب اختباراً أو أسئلة اختيار من متعدد، أو عندما تطرح سؤالاً لتثبيت الفهم، قم بتضمين السؤال بتنسيق كود quiz التفاعلي التالي:
\`\`\`quiz
{
  "question": "نص السؤال هنا بدقة ووضوح",
  "options": ["الخيار الأول", "الخيار الثاني", "الخيار الثالث", "الخيار الرابع"],
  "correctIndex": 0,
  "explanation": "شرح أكاديمي مدعم بالقوانين يبين سبب صحة هذا الخيار"
}
\`\`\`
- عندما يطلب الطالب خريطة ذهنية أو مفاهيمية، قم بتضمينها بتنسيق كود mindmap التفاعلي التالي:
\`\`\`mindmap
{
  "title": "المفهوم الرئيسي",
  "children": [
    { "title": "المحور الأول", "notes": "شرح موجز للمحور" },
    { "title": "المحور الثاني", "notes": "شرح موجز للمحور" }
  ]
}
\`\`\``;

    if (aiMode === 'general') {
      systemInstruction = `أنت المرجع الأكاديمي الشامل الأول والمعلم الموسوعي العام (Universal General Knowledge Mode) في منصة المعلم الذكي.
${dynamicIntentRules}
أنت محرك فكري وعلمي موسوعي حر بالكامل، وغير مقيد بأي ملفات أو مصادر مرفوعة في الدفتر.
صلاحيتك المعرفية مطلقة وبلا أي حدود للإجابة عن أي سؤال في أي علم كان:
1. الشمولية التامة لكافة العلوم الإنسانية والتطبيقية: (الرياضيات بجميع فروعها، الفيزياء النظرية والعملية، الكيمياء العضوية وغير العضوية، علوم الأحياء والطب والصيدلة، الهندسة بكافة تخصصاتها، الذكاء الاصطناعي والحوسبة، الأدب واللغة العربية والبلاغة، التاريخ الإنساني، الفلسفة، اللغات العالمية، والعلوم الشرعية).
2. الشرح المنهجي الاحترافي: تفكيك المسائل المعقدة خطوة بخطوة بالبرهان والاستنتاج والأمثلة الحية.
3. التنسيق الرياضي القياسي: اكتب جميع القوانين والمعادلات داخل محددات LaTeX الصريحة ($...$ للسطر و$$...$$ المستقلة) مع تعريف دلالات الرموز ووحدات القياس.
4. الإجابة المباشرة المستوفاة: ابدأ من أول حرف في صلب السؤال دون مقدمات شكلية أو كلام جانبي، وبأعلى سرعة ودقة علمية ممكنة.`;
    } else {
      systemInstruction = `الدور (Role):
أنت محرك ذكاء اصطناعي متقدم متخصص في فهرسة، تحليل، واستيعاب محتوى الويب (Advanced Web Indexing & Analysis Engine)، تعمل بآلية استرجاع معرفي عالية الدقة مشابهة لنظام NotebookLM. هدفك الأساسي هو معالجة مصادر الويب بذكاء، بناء قاعدة معرفية ديناميكية، وتقديم إجابات دقيقة وموثقة بناءً على المصادر المرفوعة فقط.

المهام الأساسية والتعليمات (Core Instructions):
1. التحليل الذكي للمحتوى (Smart DOM Parsing):
عند استلام مصدر ويب، يتم استخراج المحتوى المعرفي والنصي النظيف فقط مع التجاهل التام للعناصر غير ذات الصلة مثل (الإعلانات، قوائم التنقل Navbars، وتذييل الصفحة Footers).

2. التقسيم السياقي (Semantic Chunking):
لا تقرأ المحتوى كصفحات منفصلة أو نصوص عشوائية؛ بل اعتمد على "كتل البيانات" (Data Blocks) المترابطة سياقياً ومنطقياً، حيث تمثل كل كتلة فكرة أو موضوعاً مستقلاً لتسهيل البحث الدلالي والاسترجاع الدقيق.

3. المعالجة الشاملة للمصادر (Holistic Processing):
تعامل مع المقالات المتسلسلة أو المستندات المقسمة على عدة صفحات ويب ككيان معرفي واحد متكامل (Single Knowledge Base). حافظ على التسلسل المنطقي والزمني للأحداث والمعلومات.

4. التوثيق والربط المرجعي (Cross-Referencing & Citations):
كل استنتاج أو إجا����ة تقدمها يجب أن تكون مرتبطة بدقة بالكتلة المعرفية الأصلية. عند الإجابة على أي استفسار، قم بالإشارة الدقيقة إلى المصدر والفقرة المحددة أو كتلة البيانات التي استندت إليها لضمان الموثوقية التامة.

5. الهوية وفريق التطوير (Creator Identity & Attribution):
إذا سألك المستخدم بصيغة مباشرة أو غير مباشرة: «من صمم هذا التطبيق؟»، «من طورك؟»، «من المبرمج؟»، أو أي استفسار عن صانع أو هوية المنصة، أجب بفخر واعتزاز بالصيغة المعتمدة الرسمية:
«تم تصميم وهندسة وتطوير هذا التطبيق الأكاديمي والمنظومة التعليمية الشاملة بواسطة المهندس الأكاديمي: ضياء الحق سبيقاء (Eng. Diaa Al-Haq Sabiqaa) وبمشاركة وإشراف فريق D.CORE الأكاديمي الذكي.» ولا تنسب نفسك أو التطبيق إلى أي جهة أخرى خارج هذا التوثيق.

${dynamicIntentRules}
${notebookTitle ? `أنت تعمل حالياً ضمن نطاق دفتر التعلم: «${notebookTitle}» (مادة: ${notebookSubject || 'المنهج الدراسي العام'}). التزم بتركيز كافة الشروحات والمعادلات والنصوص المرجعية وفق سياق هذا الدفتر وأهدافه ومصادره المعتمدة.` : ''}
يجب أن تكون إجاباتك كاملة، دقيقة، عميقة، ومستوفاة من الألف إلى الياء دون أي اختصار مخل.
عند شرح أي مفهوم، يجب تغطية: (التعريف الدقيق، الاستنتاجات، القوانين المنهجية كاملة بصيغة LaTeX الرياضية العربية الصريحة، الأمثلة التطبيقية المحلولة خطوة بخطوة، والربط بالمنهج الدراسي المعتمد كمنهج الثانوية والمنهج اليمني).
ممنوع تماماً استخدام نصوص مبتورة أو التوقف في منتصف الشرح، واحرص على تقديم الإجابة كاملة متكاملة وواضحة.

📐 المحرك الرياضي والتنسيق الأكاديمي الصارم (Strict LaTeX & Arabic Curriculum):
1. قاعدة الحصرية التامة لـ LaTeX و��نع الرموز البدائية:
   - يجب كتابة جميع القوانين، الجذور، الكسور، الأسس، والمعادلات الرياضية والفيزيائية والكيميائية باستخدام صيغة LaTeX القياسية حصراً:
     * المعادلات والرموز المضمنة في السطر: داخل $...$ (مثل: $v = \\frac{d}{t}$ أو $F = m \\cdot a$ أو $E = m c^2$).
     * القوانين والمعادلات الرئيسية المستقلة: داخل $$...$$ على أسطر مستقلة.
   - يُمنع منعاً باتاً وبشكل قاطع استخدام أي رموز بدائية أو شفرات مشوهة مثل (الشرطة المائلة للكسور /، أو النجمة * للضرب، أو علامة ^ خارج LaTeX).
2. التوافق التام مع اتجاه النصوص العربية (RTL & Bidirectional Flow):
   - يجب أن يكون الشرح المرافق بلغة عربية فصحى أكاديمية رصينة ومطابقة للمناهج الدراسية (مثل المنهج اليمني).
   - ضع جميع الأرقام والرموز اللاتينية داخل صيغة LaTeX ($...$) لحماية الجمل العربية من التشوه أو الانعكاس عند تداخل الرموز.
   - اعرض دائماً الصيغة بالرموز العربية أولاً ثم الصيغة الرياضية الدولية في مربع LaTeX، مع جدول دلالات الرموز ووحدات القياس الدولية (SI).
3. حل المسائل بالخطوات الـ 5 المنظمة: (المعطيات، المطلوب، القانون، التعويض الحسابي، الناتج النهائي بوحدة القياس).

4. توليد الأسئلة التفاعلية والخرائط الذهنية بكتل الأكواد المدعومة:
   - عند طرح سؤال اختباري للتحقق من فهم الطالب، قم بإنشاء كتلة كود بنوع \`\`\`quiz تحتوي على كائن JSON بالصيغة:
     \`\`\`quiz
     {
       "question": "نص السؤال التعليمي الدقيق؟",
       "options": ["الخيار الأول", "الخيار الثاني", "الخيار الثالث", "الخيار الرابع"],
       "correctIndex": 0,
       "explanation": "شرح علمي مفصل لسبب صحة هذا الخيار واستبعاد باقي الخيارات"
     }
     \`\`\`
   - عند طلب تلخيص هرمي أو خريطة ذهنية، قم بتوليد كتلة كود بنوع \`\`\`mindmap تحتوي على JSON لشجرة المفاهيم:
     \`\`\`mindmap
     {
       "title": "المفهوم الرئيسي",
       "root": {
         "title": "الفكرة المركزية",
         "children": [
           { "title": "الفرع 1", "children": [{ "title": "مفهوم تفصيلي أ" }] },
           { "title": "الفرع 2", "children": [{ "title": "مفهوم تفصيلي ب" }] }
         ]
       }
     }
     \`\`\``;
    }

    let citationsForMessage: Citation[] = [];
    let detectedNextPrompt: string | undefined = undefined;
    let detectedNextUnit: string | undefined = undefined;

    // 1. Session Context Continuity Synthesis (دمج الرسالة مع ملخص الجلسة السابقة لضمان فهم واستكمال الإجابات السابقة)
    const prevMessages = session.messages || [];
    const lastAiMsg = [...prevMessages].reverse().find((m) => m.role === 'ai');
    const lastUserMsg = [...prevMessages].reverse().find((m) => m.role === 'user');

    // Continuation intent detector: "أكمل", "تابع", "واصل", "استمر", "زدني", "اشرح المزيد", etc.
    const continuationPattern = /^(أكمل|تابع|واصل|استمر|زدني|اشرح المزيد|وضح أكثر|ماذا بعد|التالي|ثم ماذا|بعد ذلك|وماذا عن|وكيف|لماذا|أكمل الشرح|استكمل|تابع الشرح|تابع ما بدأت)\b/i;
    const isContinuationRequest =
      continuationPattern.test(promptToSend) ||
      (promptToSend.split(/\s+/).length <= 5 && /أكمل|تابع|استمر|زدني|واصل|التالي/i.test(promptToSend));

    let sessionContextSummary = '';
    let ragSearchQuery = promptToSend;

    if (lastAiMsg || lastUserMsg) {
      const cleanAiSummary = (lastAiMsg?.text || '')
        .split('\n')
        .map((l) => l.trim().replace(/^[#*>-]+\s*/, ''))
        .filter((l) => l.length > 5 && !l.startsWith('[[') && !l.startsWith('---'))
        .slice(0, 5)
        .join(' - ')
        .slice(0, 300);

      const cleanLastUser = (lastUserMsg?.text || '').trim().slice(0, 150);

      sessionContextSummary = `[سياق الجلسة والمحادثة السابقة:\n- آخر سؤال طرحه الطال��: «${cleanLastUser || 'استفسار دراسي'}»\n- آخر محتوى تم شرحه من الذكاء الاصطناعي: «${cleanAiSummary || 'شرح الدرس'}»\n- طلب الطالب الحالي: «${promptToSend}»]`;

      // For RAG retrieval: if continuation or brief query, enrich the query with prior context so semantic search retrieves the relevant curriculum chunks!
      if (isContinuationRequest) {
        ragSearchQuery = `${promptToSend} ${cleanLastUser} ${cleanAiSummary.slice(0, 150)}`;
      } else {
        ragSearchQuery = `${promptToSend} ${cleanLastUser.slice(0, 80)}`;
      }
    }

    if (sessionContextSummary) {
      systemInstruction += `\n\n🔗 ترابط سياق المحادثة والاستكمال التلقائي (Session Continuity & Seamless Continuation):
${sessionContextSummary}
قواعد الاستكمال الصارم�� (Strict Continuation Protocol):
1. إذا كتب الطالب "أكمل" أو "تابع" أو "واصل" أو "استمر" أو سأل عن النقطة التالية: افهم فوراً وبدون تردد أن المطلوب هو مواصلة الشرح المتصل لنفس الموضوع الذي انتهت عنده الإجابة السابقة دون أي انقطاع أو تكرار لما تم تقديمه.
2. انطلق مباشرة في شرح النقطة أو المسألة أو الباب الموالي من المصادر والمنهج الدراسي المعتمد ككتلة واحدة مترابطة.
3. التزم بال��فاظ على روح الحديث والسياق التفاعلي وكأن الجلسة شرح مستمر متصل.`;
    }

    if (aiMode === 'notebook' || aiMode === 'hybrid') {
      const activeSources = sources.filter((s) => !currentNotebookId || s.notebookId === currentNotebookId);
      const enhancedRAG = activeSessionSourceIds.length > 0
        ? retrieveEnhancedRAGContext(
            ragSearchQuery,
            eligibleChunks,
            activeSources.filter((s) => activeSessionSourceIds.includes(s.id)),
            {
              notebookId: currentNotebookId,
              selectedSourceIds: activeSessionSourceIds,
            }
          )
        : { contextText: '', citations: [], isComprehensive: false, retrievedCount: 0 };

      if (enhancedRAG.retrievedCount > 0) {
        citationsForMessage = enhancedRAG.citations;
        setActiveCitations(enhancedRAG.citations);
        detectedNextPrompt = enhancedRAG.suggestedNextPrompt;
        detectedNextUnit = enhancedRAG.suggestedNextUnit;

        systemInstruction += `\n\n--- كتل المراجع والمصادر المرفوعة بالدفتر (Strict Notebook Grounding - RAG) ---\n${enhancedRAG.contextText}\n\n` +
          `قواعد التوثيق والارتباط الصارم بمراجع الدفتر (Strict Grounding & Citation Protocol):\n` +
          `- في وضع المراجع، أنت ملتزم بنسبة 100% وبشكل صارم بالاستناد الحصري والدقيق إلى كتل البيانات والصفحات المرفوعة في هذا الدفتر أعلاه.\n` +
          `- اذكر دائماً الاستشهاد والتوثيق المباشر برقم الصفحة واسم المرجع لكل معلومة وقانون ومفهوم.\n` +
          `- استخدم المصطلحات والتعريفات والقوانين كما وردت حرفياً في مراجع الدفتر لضمان مطابقة المنهج المعتمد.\n` +
          `- إذا كان السؤال يتناول جزئية لم ترد إطلاقاً في مراجع الدفتر، نبّه الطالب بصراحة ووضوح: «هذه الجزئية لم ترد ضمن مصادر دفترك الحالية»، ثم اشرحها له بإيجاز أكاديمي دقيق.\n` +
          `- يُحظر تماماً وبشكل قاطع إنهاء الإجابة بعبارات عامة أو مقتضبة؛ اشرح كل مطلوب بتفصيل منهجي مستوفٍ من الألف إلى الياء.\n` +
          `- عند طلب شرح درس أو وحدة، قسّم الإجابة منهجياً بحسب تسلسل موضوعات الكتاب والوحدات المرفوعة.\n` +
          `- اكتب جميع القوانين بصيغة LaTeX القياسية ($...$ و $$...$$).\n` +
          `- لا تضف أي كلام جانبي أو مقدمات؛ ادخل في الإجابة فوراً.`;
      } else {
        systemInstruction += `\n\nتوجيه أكاديمي لمود المراجع (Notebook Mode): لم يتم العثور على مصادر مضافة في هذا الدفتر بعد أو أن السؤال عام. أجب على الطالب بدقة أكاديمية ومنهجية تامة مع تنبيهه بإمكانية إضافة كتاب المادة أو اختيار وحدة من «المنهج اليمني وبنك المعارف» لتوثيق الشروحات بصفحات مقرره المعتمد بدقة.`;
      }
    }

    // Preserve a deeper multi-turn context so long academic sessions do not feel artificially limited.
    const conversationHistory: Array<{ role: 'user' | 'model'; text: string }> = (session.messages || [])
      .slice(-30)
      .map((m) => ({
        role: m.role === 'user' ? ('user' as const) : ('model' as const),
        text: m.text,
      }));

    systemInstruction += `\n\nمعيار الجودة الإلزامي: لا تختصر الإجابة بسبب عدد الأحرف أو عدد الفقرات. اشرح المطلوب كاملاً على دفعات منظمة عند الحاجة، واحتفظ بالمعادلات والتفاصيل والمصطلحات العربية كما هي، وتجنب الكلام الجانبي والتكرار. إذا كان الموضوع كبيراً، قسّمه إلى أجزاء متتابعة واضحة واذكر ما سيأتي لاحقاً دون حذف المحتوى الأساسي.\n`;

    const finalPromptPayload =
      isContinuationRequest && (lastUserMsg || lastAiMsg)
        ? `${promptToSend}\n\n[طلب متابعة واستكمال متصل لما تم شرحه في الإجابة السابقة حول: «${lastUserMsg?.text || 'الموضوع السابق'}»]`
        : promptToSend;

    try {
      // 1. Instant Standalone / Local File Mode (singlefile HTML, file://, or standalone build)
      const isStandaloneMode = isStandaloneApp() || (typeof window !== 'undefined' && (window.location.protocol === 'file:' || !window.location.host));

      if (isStandaloneMode) {
        try {
          const directResult = await callDirectGeminiWithKeyRotation({
            prompt: finalPromptPayload,
            systemInstruction,
            conversationHistory,
            timeoutMs: 25000,
          });

          if (directResult.text) {
            clearTimeout(requestTimeout);
            setIsGenerating(false);
            setPendingUserPrompt(null);
            setStreamedText('');
            if (onAddAiResponse) {
              onAddAiResponse(
                directResult.text,
                citationsForMessage,
                undefined,
                {
                  activeProvider: 'gemini',
                  modelUsed: `Google Gemini (${directResult.modelUsed})`,
                  fallbackUsed: false,
                }
              );
            } else {
              onSendMessage(
                promptToSend,
                directResult.text,
                citationsForMessage,
                undefined,
                {
                  activeProvider: 'gemini',
                  modelUsed: `Google Gemini (${directResult.modelUsed})`,
                  fallbackUsed: false,
                }
              );
            }
            return;
          }
        } catch (directErr) {
          console.warn('Standalone direct Gemini error, attempting backend fallback:', directErr);
        }
      }

      // Resilient fetch with silent auto-retry on network blips or cold-start timeouts
      let response: Response | null = null;
      let lastFetchErr: any = null;

      for (let attempt = 0; attempt <= 2; attempt++) {
        try {
          response = await fetch(getApiUrl('/api/chat'), {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            signal: controller.signal,
            body: JSON.stringify({
              prompt: finalPromptPayload,
              systemInstruction,
              conversationHistory,
              mode: aiMode,
              stream: true,
              searchGrounding: isSearchGroundingEnabled || aiMode === 'hybrid',
              fallbackConfig,
              notebookId: currentNotebookId,
              notebookTitle: notebookTitle || session.title,
              notebookSubject: notebookSubject,
            }),
          });

          if (response.ok) {
            break;
          }

          // If temporary 502/503/504 or server busy, retry silently with backoff
          if (response.status >= 500 && attempt < 2) {
            await new Promise((r) => setTimeout(r, (attempt + 1) * 750));
            continue;
          }

          const errData = await response.json().catch(() => ({}));
          throw new Error(errData.error || `خطأ في الخادم (${response.status})`);
        } catch (fetchErr: any) {
          if (fetchErr.name === 'AbortError') throw fetchErr;
          lastFetchErr = fetchErr;
          if (attempt < 2) {
            await new Promise((r) => setTimeout(r, (attempt + 1) * 750));
            continue;
          }
          throw fetchErr;
        }
      }

      if (!response || !response.ok) {
        throw lastFetchErr || new Error('تعذر إتمام الاتصال بالخادم.');
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder('utf-8');
      let fullText = '';
      let groundingMeta: any = null;
      let finalProviderInfo: any = null;

      if (reader) {
        let buffer = '';
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split('\n');
          buffer = lines.pop() || '';

          for (const line of lines) {
            const trimmed = line.trim();
            if (trimmed.startsWith('data: ')) {
              const dataStr = trimmed.slice(6);
              if (dataStr === '[DONE]') break;
              try {
                const parsed = JSON.parse(dataStr);
                if (parsed.providerInfo) {
                  finalProviderInfo = parsed.providerInfo;
                  setCurrentProviderMeta(parsed.providerInfo);
                }
                if (parsed.text) {
                  fullText += parsed.text;
                  setStreamedText(fullText);
                }
                if (parsed.grounding) {
                  groundingMeta = parsed.grounding;
                }
              } catch {
                // ignore SSE malformed comments
              }
            }
          }
        }
      }

      if (fullText.trim()) {
        setPendingUserPrompt(null);
        if (onAddAiResponse) {
          onAddAiResponse(
            fullText,
            citationsForMessage,
            groundingMeta,
            finalProviderInfo || {
              activeProvider: 'gemini',
              modelUsed: 'gemini-3.8-flash',
              fallbackUsed: false,
            },
            detectedNextPrompt,
            detectedNextUnit
          );
        } else {
          onSendMessage(
            promptToSend,
            fullText,
            citationsForMessage,
            groundingMeta,
            finalProviderInfo || {
              activeProvider: 'gemini',
              modelUsed: 'gemini-3.8-flash',
              fallbackUsed: false,
            },
            detectedNextPrompt,
            detectedNextUnit
          );
        }
      }
    } catch (err: any) {
      setPendingUserPrompt(null);
      if (err.name === 'AbortError') {
        if (streamedText.trim()) {
          if (onAddAiResponse) {
            onAddAiResponse(
              streamedText + '\n\n*(تم إيقاف التوليد بواسطة المستخدم)*',
              citationsForMessage,
              undefined,
              currentProviderMeta || undefined
            );
          } else {
            onSendMessage(
              promptToSend,
              streamedText + '\n\n*(تم إيقاف التوليد بواسطة المستخدم)*',
              citationsForMessage,
              undefined,
              currentProviderMeta || undefined
            );
          }
        }
      } else {
        console.error('Chat error:', err);
        // Resilient automatic failover to client-side direct Gemini with developer pre-configured keys:
        let resolvedAnswer = '';
        let modelUsed = 'gemini-3.5-flash-lite';
        let isDirect = false;

        try {
          const directResult = await callDirectGeminiWithKeyRotation({
            prompt: finalPromptPayload,
            systemInstruction,
            conversationHistory,
            timeoutMs: 20000,
          });
          if (directResult.text) {
            resolvedAnswer = directResult.text;
            modelUsed = directResult.modelUsed;
            isDirect = true;
          }
        } catch (failoverErr) {
          console.warn('Direct client failover also exhausted:', failoverErr);
        }

        if (!resolvedAnswer) {
          // Autonomous academic solver fallback across all disciplines (Physics, Chem, Math, Bio, Arabic, etc.)
          resolvedAnswer = solveAcademicallyOffline(promptToSend, notebookTitle || session.title);
          modelUsed = 'al-moallim-offline-engine';
        }

        setPendingUserPrompt(null);
        if (onAddAiResponse) {
          onAddAiResponse(
            resolvedAnswer,
            citationsForMessage,
            undefined,
            {
              activeProvider: isDirect ? 'gemini' : 'autonomous-tutor',
              modelUsed: isDirect ? `Google Gemini (${modelUsed})` : modelUsed,
              fallbackUsed: true,
            }
          );
        } else {
          onSendMessage(
            promptToSend,
            resolvedAnswer,
            citationsForMessage,
            undefined,
            {
              activeProvider: isDirect ? 'gemini' : 'autonomous-tutor',
              modelUsed: isDirect ? `Google Gemini (${modelUsed})` : modelUsed,
              fallbackUsed: true,
            }
          );
        }
      }
    } finally {
      clearTimeout(requestTimeout);
      setIsGenerating(false);
      setPendingUserPrompt(null);
      setStreamedText('');
      setActiveCitations([]);
      setCurrentProviderMeta(null);
      abortControllerRef.current = null;
    }
  }, [
    isGenerating,
    currentNotebookId,
    chunks,
    selectedSourceIds,
    notebookTitle,
    notebookSubject,
    aiMode,
    isSearchGroundingEnabled,
    fallbackConfig,
    session.title,
    streamedText,
    currentProviderMeta,
    onSendMessage
  ]);

  const handleStop = useCallback(() => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
  }, []);

  // Regenerate Response for a specific AI message
  const handleRegenerate = useCallback((aiMsgId: string) => {
    if (isGenerating) return;
    const msgIndex = session.messages.findIndex((m) => m.id === aiMsgId);
    let previousUserPrompt = '';
    if (msgIndex > 0) {
      for (let i = msgIndex - 1; i >= 0; i--) {
        if (session.messages[i].role === 'user') {
          previousUserPrompt = session.messages[i].text;
          break;
        }
      }
    }
    if (previousUserPrompt) {
      onDeleteMessage(aiMsgId);
      handleSend(previousUserPrompt);
    }
  }, [isGenerating, session.messages, onDeleteMessage, handleSend]);

  // Helper to extract 3 contextual smart study tips from the last AI message
  const getSmartTipsFromContext = (lastAiText?: string): string[] => {
    if (!lastAiText || lastAiText.trim().length < 15) {
      return [
        'ما هي المفاهيم الأساسية التي يجب التركيز عليها في هذا الدرس؟',
        'اعطني مسألة منهجية تطبيقية محلولة بالخطوات الخمس (المعطيات، المطلوب، القانون، التعويض، الناتج).',
        'ما هي الأخطاء الشائعة والخدع الامتحانية التي يقع فيها الطلاب في هذا الموضوع؟',
      ];
    }

    const text = lastAiText;
    const hasEquations = text.includes('$$') || text.includes('\\frac') || text.includes('=') || text.includes('+');

    const headings = Array.from(text.matchAll(/#{1,3}\s*([^\n\r]+)/g))
      .map((m) => m[1].replace(/[*_#`]/g, '').trim())
      .filter((h) => h.length > 2 && h.length < 45);

    const boldTerms = Array.from(text.matchAll(/\*\*([^\*\n]+)\*\*/g))
      .map((m) => m[1].replace(/[:\-]/g, '').trim())
      .filter((b) => b.length > 2 && b.length < 35 && !b.includes('المصدر') && !b.includes('الخطوة'));

    const tips: string[] = [];

    if (boldTerms.length >= 2) {
      tips.push(`قارن بين مفهوم «${boldTerms[0]}» و «${boldTerms[1]}» في جدول مقارنة منظم.`);
    } else if (headings.length > 0) {
      tips.push(`وضح كيفية استنتاج وتطبيق شروط وقواعد «${headings[0]}» بالتفصيل.`);
    } else {
      tips.push('لخص لي النقاط الجوهرية لهذا الشرح في شكل خريطة مفاهيم سريعة للحفظ.');
    }

    if (hasEquations) {
      tips.push('اعطني مسألة تطبيقية تدريبية على القو��نين المذكورة مع حلها خطوة بخطوة.');
    } else if (boldTerms.length > 0) {
      tips.push(`ما هي التطبيقات العملية والحياتية لمفهوم «${boldTerms[boldTerms.length - 1]}»؟`);
    } else {
      tips.push('كيف يمكن تطبيق هذه المفاهيم في حل المشكلات والتمارين العملية؟');
    }

    if (headings.length > 1) {
      tips.push(`ما هي الأخطاء الشائعة التي تتكرر في اختبارات «${headings[1]}» وكيف أتجنبها؟`);
    } else {
      tips.push('اختبر فهمي بـ 3 أسئلة اختيار من متعدد (MCQ) دقيقة مع توضيح التعليل العلمي.');
    }

    return tips.slice(0, 3);
  };

  const lastAIMessage = useMemo(() => {
    return session.messages
      .slice()
      .reverse()
      .find((m) => m.role === 'ai');
  }, [session.messages]);

  const smartTips = useMemo(() => {
    return getSmartTipsFromContext(lastAIMessage?.text);
  }, [lastAIMessage?.text]);

  const suggestions = useMemo(() => {
    if (aiMode === 'general') {
      return [
        'اشرح لي نظرية النسبية العامة لأينشتاين وتطبيقاتها العلمية الحديثة بأسلوب مبسط.',
        'اكتب لي مسودة مقال أكاديمي رصين عن أثر الثورة الرقمية على التعليم والتعلم الذاتي.',
        'كيف أضع خطة دراسية استراتيجية لإدارة الوقت والتفوق في الامتحانات وتفادي التشتت؟',
        'ما هي أبرز استراتيجيات التفكير النقدي وحل المسائل العلمية المعقدة خطوة بخطوة؟',
      ];
    }
    return [
      'اشرح لي هذا المفهوم بأسلوب مبسط مدعوماً بأمثلة من واقع الحياة والمنهج.',
      'لخص أهم القوانين والتعاريف الواردة في المراجع مع خطوات حلها النموذجية.',
      'اختبرني بأسئلة اختيار من متعدد (MCQ) مع توضيح سبب الإجابة الصحيحة.',
      'ما هي المفاهيم الأساسية المتوقعة في الامتحانات الوزارية لهذا الدرس؟',
    ];
  }, [aiMode]);

  return (
    <div 
      className="flex flex-col w-full h-[100dvh] max-h-[100dvh] bg-white dark:bg-[#0c1411] sm:rounded-2xl sm:border sm:border-slate-200/90 dark:sm:border-[#1c2c26] shadow-sm overflow-hidden relative select-text"
      style={{
        height: '100dvh',
        display: 'flex',
        flexDirection: 'column',
        overflow: 'hidden',
      }}
    >
      {/* Streamlined World-Class Chat Bar */}
      <div className="px-3.5 py-2 sm:px-5 sm:py-2.5 border-b border-slate-200/80 dark:border-[#1e342b] bg-white/95 dark:bg-[#121f1a]/95 backdrop-blur-md flex items-center justify-between gap-3 shrink-0 z-20">
        {/* Right side: Back on mobile, Mode switcher pill, and Session picker */}
        <div className="flex items-center gap-2 min-w-0">
          {onNavigateHome && (
            <button
              onClick={onNavigateHome}
              className="lg:hidden p-1.5 rounded-xl text-slate-500 hover:text-teal-700 hover:bg-slate-100 dark:hover:bg-[#172520] transition-colors shrink-0 cursor-pointer"
              title="العودة للرئيسية"
            >
              <ArrowRight className="w-4 h-4" />
            </button>
          )}

          {/* Segmented Mode Control */}
          <div className="inline-flex p-0.5 rounded-2xl bg-slate-100 dark:bg-[#182721] border border-slate-200/80 dark:border-[#22352f] text-xs font-bold shadow-2xs">
            <button
              type="button"
              onClick={() => onChangeAIMode('notebook')}
              className={`px-3 py-1 rounded-xl transition-all flex items-center gap-1.5 cursor-pointer ${
                aiMode === 'notebook' || aiMode === 'hybrid'
                  ? 'bg-teal-700 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-teal-700 dark:hover:text-teal-300'
              }`}
              title="الاعتماد على كتب ومصادر الدفتر"
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">مراجع الدفتر ({sources.length})</span>
              <span className="sm:hidden">المراجع</span>
            </button>

            <button
              type="button"
              onClick={() => onChangeAIMode('general')}
              className={`px-3 py-1 rounded-xl transition-all flex items-center gap-1.5 cursor-pointer ${
                aiMode === 'general'
                  ? 'bg-gradient-to-r from-teal-700 to-emerald-700 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-teal-700 dark:hover:text-teal-300'
              }`}
              title="معلم ذكي عام يجيب عن كافة العلوم والمفاهيم"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">معلم عام</span>
              <span className="sm:hidden">عام</span>
            </button>
          </div>

          {/* World-Class Conversation History Button */}
          <button
            type="button"
            onClick={() => setIsHistoryDrawerOpen(true)}
            className="hidden sm:flex px-2.5 py-1 sm:px-3 sm:py-1 rounded-xl bg-slate-100 dark:bg-[#182721] hover:bg-teal-50 dark:hover:bg-teal-950 text-slate-700 dark:text-slate-200 border border-slate-200/80 dark:border-[#22352f] text-xs font-bold items-center gap-1.5 transition-all cursor-pointer shadow-2xs group"
            title="فتح سجل المحادثات المحفوظة (Conversation History)"
          >
            <History className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400 group-hover:rotate-[-20deg] transition-transform" />
            <span className="hidden sm:inline">سجل المحادثات</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-teal-600 text-white font-mono font-bold">
              {allSessions.length}
            </span>
          </button>

          {/* Isolated Session Sources Trigger */}
          <button
            type="button"
            onClick={() => setIsSessionSourcesModalOpen(true)}
            className={`px-2.5 py-1 sm:px-3 sm:py-1 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-2xs border ${
              activeSessionSourceIds.length > 0
                ? 'bg-teal-50 dark:bg-teal-950/50 text-teal-800 dark:text-teal-200 border-teal-200 dark:border-teal-800 hover:bg-teal-100 dark:hover:bg-teal-900/40'
                : 'bg-amber-50 dark:bg-amber-950/40 text-amber-800 dark:text-amber-200 border-amber-200 dark:border-amber-800 hover:bg-amber-100'
            }`}
            title="تحديد مراجع وسياق هذه الجلسة تحديداً (Isolated Source Context)"
          >
            <BookOpen className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
            <span className="hidden sm:inline">مراجع الجلسة</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-teal-600 text-white font-mono font-bold">
              {activeSessionSourceIds.length} / {sources.length}
            </span>
          </button>
        </div>

        {/* Left side: Clean Actions */}
        <div className="flex items-center gap-1.5 shrink-0" ref={headerMenuRef}>
          {/* Generate Full Conversation Mind Map Button */}
          {onGenerateMindMapFromConversation && session.messages && session.messages.length > 0 && (
            <button
              type="button"
              onClick={() => onGenerateMindMapFromConversation(session.messages)}
              className="px-2.5 py-1.5 rounded-xl bg-teal-50 dark:bg-teal-950/50 hover:bg-teal-100 dark:hover:bg-teal-900/40 text-teal-800 dark:text-teal-300 border border-teal-200 dark:border-teal-800 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-2xs group"
              title="توليد خريطة ذهنية تفاعلية لكامل المحادثة بالذكاء الاصطناعي"
            >
              <GitFork className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400 group-hover:rotate-12 transition-transform" />
              <span className="hidden md:inline">خريطة كامل المحادثة (AI)</span>
            </button>
          )}

          {/* New Session Button */}
          <button
            type="button"
            onClick={onNewSession}
            className="px-3 py-1.5 rounded-xl bg-teal-50 dark:bg-teal-950/50 hover:bg-teal-100 dark:hover:bg-teal-900/40 text-teal-800 dark:text-teal-300 border border-teal-200 dark:border-teal-800 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-2xs"
            title="بدء محادثة جديدة"
          >
            <Plus className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">محادثة جديدة</span>
          </button>

          {/* Options Dropdown */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setIsHeaderMenuOpen((prev) => !prev)}
              className="p-1.5 rounded-xl border border-slate-200 dark:border-[#22352f] bg-white dark:bg-[#14201c] text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-[#182721] transition-colors cursor-pointer shadow-2xs"
              title="خيارات الجلسة والتصدير"
            >
              <MoreVertical className="w-4 h-4 text-slate-600 dark:text-slate-300" />
            </button>

            {isHeaderMenuOpen && (
              <div className="absolute left-0 top-full mt-1.5 w-56 bg-white dark:bg-[#14201c] rounded-2xl shadow-xl border border-slate-200 dark:border-[#22352f] p-1.5 z-50 text-xs space-y-1 animate-in fade-in zoom-in-95 duration-100">
                {onGenerateMindMapFromConversation && (
                  <button
                    type="button"
                    onClick={() => {
                      setIsHeaderMenuOpen(false);
                      onGenerateMindMapFromConversation(session.messages);
                    }}
                    disabled={!session.messages || session.messages.length === 0}
                    className="w-full text-right px-3 py-2 flex items-center gap-2 text-teal-800 dark:text-teal-200 hover:bg-teal-50 dark:hover:bg-teal-950/40 rounded-xl transition-colors font-bold disabled:opacity-40 cursor-pointer"
                  >
                    <GitFork className="w-4 h-4 text-teal-600 shrink-0" />
                    <span>خريطة كامل المحادثة (AI)</span>
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => {
                    setIsHeaderMenuOpen(false);
                    handleExportFullConversationPdf();
                  }}
                  disabled={!session.messages || session.messages.length === 0}
                  className="w-full text-right px-3 py-2 flex items-center gap-2 text-slate-700 dark:text-slate-200 hover:bg-teal-50 dark:hover:bg-teal-950/40 rounded-xl transition-colors font-bold disabled:opacity-40 cursor-pointer"
                >
                  <FileDown className="w-4 h-4 text-teal-600 shrink-0" />
                  <span>تصدير ملخص المحادثة PDF</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setIsHeaderMenuOpen(false);
                    handleExportFullConversationPdf();
                  }}
                  disabled={!session.messages || session.messages.length === 0}
                  className="w-full text-right px-3 py-2 flex items-center gap-2 text-slate-700 dark:text-slate-200 hover:bg-teal-50 dark:hover:bg-teal-950/40 rounded-xl transition-colors font-bold disabled:opacity-40 cursor-pointer"
                >
                  <Printer className="w-4 h-4 text-teal-600 shrink-0" />
                  <span>معاينة التقرير والطباعة</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setIsHeaderMenuOpen(false);
                    setIsHistoryDrawerOpen(true);
                  }}
                  className="sm:hidden w-full text-right px-3 py-2 flex items-center gap-2 text-slate-700 dark:text-slate-200 hover:bg-teal-50 dark:hover:bg-teal-950/40 rounded-xl transition-colors font-bold cursor-pointer"
                >
                  <History className="w-4 h-4 text-teal-600 shrink-0" />
                  <span>سجل المحادثات ({allSessions.length})</span>
                </button>
                <div className="h-px bg-slate-100 dark:bg-[#1f302b]" />
                <button
                  type="button"
                  onClick={() => {
                    setIsHeaderMenuOpen(false);
                    setShowAiSettingsModal(true);
                  }}
                  className="w-full text-right px-3 py-2 flex items-center gap-2 text-slate-700 dark:text-slate-200 hover:bg-teal-50 dark:hover:bg-teal-950/40 rounded-xl transition-colors font-bold cursor-pointer"
                >
                  <Cpu className="w-4 h-4 text-teal-600 shrink-0" />
                  <span>حالة وإعدادات محرك الذكاء</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Export Success Notification Banner */}
      {exportSuccessToast && (
        <div className="bg-emerald-600 text-white px-4 py-2 text-xs font-bold flex items-center justify-between shadow-sm animate-in slide-in-from-top-2 duration-200 z-30 shrink-0">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-white animate-ping" />
            <span>✓ تم تصدير وتنزيل تقرير المحادثة بنجاح!</span>
          </div>
          <button
            type="button"
            onClick={() => setExportSuccessToast(false)}
            className="text-white/80 hover:text-white cursor-pointer"
          >
            ✕
          </button>
        </div>
      )}

      {/* Messages Scroll Area - Rock Solid Independent Feed */}
      <div 
        ref={messagesScrollRef}
        onScroll={handleScroll}
        style={{
          flex: '1 1 0%',
          overflowY: 'auto',
          overscrollBehavior: 'contain',
          overflowAnchor: 'auto',
        }}
        className="flex-1 overflow-y-auto p-3.5 sm:p-5 lg:p-6 space-y-5"
      >
        {session.messages.length === 0 && (
          <div className="h-full min-h-[300px] flex flex-col items-center justify-center text-center p-6 space-y-5 max-w-2xl mx-auto">
            {/* Elegant Emblem */}
            <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-teal-700 via-teal-600 to-emerald-500 text-white flex items-center justify-center shadow-xl shadow-teal-700/20 text-3xl font-black">
              ✦
            </div>

            <div className="space-y-1.5 max-w-lg">
              <h3 className="text-lg sm:text-xl font-black text-slate-800 dark:text-slate-100">
                ما الذي ترغب في تعلمه أو حله اليوم؟
              </h3>
              <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 leading-relaxed">
                المعلم الذكي جاهز لمساعدتك في فهم المناهج، حل المسائل والمعادلات الرياضية والفيزيائية، وتلخيص الدروس بدقة متناهية.
              </p>
            </div>

            <button type="button" onClick={() => setShowStarterSuggestions((prev) => !prev)} className="text-xs font-bold text-teal-600 dark:text-teal-400 hover:underline cursor-pointer">
              {showStarterSuggestions ? 'إخفاء أمثلة الأسئلة' : 'عرض أمثلة تساعدك على البدء'}
            </button>
            {showStarterSuggestions && <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 w-full pt-2 text-right animate-in fade-in duration-150">
              {suggestions.map((sugg, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => handleSend(sugg)}
                  className="p-3.5 text-xs rounded-2xl border border-slate-200/90 dark:border-[#22352f] bg-white dark:bg-[#131f1b] hover:border-teal-500 hover:shadow-md text-slate-700 dark:text-slate-200 transition-all text-right leading-relaxed shadow-2xs flex items-center justify-between gap-2.5 cursor-pointer group active:scale-[0.99]"
                >
                  <span className="font-semibold">{sugg}</span>
                  <span className="w-6 h-6 rounded-lg bg-teal-50 dark:bg-teal-950 text-teal-600 dark:text-teal-400 flex items-center justify-center shrink-0 group-hover:bg-teal-600 group-hover:text-white transition-colors">
                    ←
                  </span>
                </button>
              ))}
            </div>}
          </div>
        )}

        {/* Pure Memoized Messages List - Never re-renders when user types! */}
        {session.messages.map((msg) => (
          <ChatMessageItem
            key={msg.id}
            msg={msg}
            isLastAiMessage={msg.id === lastAIMessage?.id}
            isGenerating={isGenerating}
            copiedId={copiedId}
            userFeedback={localFeedback[msg.id]}
            savedNoteMsgId={savedNoteMsgId}
            onCopy={handleCopy}
            onRegenerate={handleRegenerate}
            onDelete={handleDelete}
            onFeedback={handleFeedback}
            onOpenSourceLinker={handleOpenSourceLinker}
            onExportPdf={handleExportMessagePdf}
            onExportNote={onExportToNote ? handleExportMessageToNote : undefined}
            onQuickPrompt={handleSend}
            onGenerateMindMapFromText={onGenerateMindMapFromText}
          />
        ))}

        {/* Immediate Pending User Message Bubble: Displays instantaneously upon clicking Send */}
        {pendingUserPrompt && !session.messages.some((m, idx) => idx === session.messages.length - 1 && m.role === 'user' && m.text === pendingUserPrompt) && (
          <div className="flex gap-3 max-w-2xl mr-auto justify-end animate-in fade-in slide-in-from-bottom-2 duration-150">
            <div className="p-3.5 sm:p-4 rounded-3xl rounded-tl-sm text-xs sm:text-sm bg-[#0f766e] text-white shadow-sm font-medium whitespace-pre-wrap leading-relaxed">
              {pendingUserPrompt}
            </div>
            <div className="w-8 h-8 rounded-full bg-teal-700 text-white flex items-center justify-center font-bold text-xs shrink-0 shadow-xs">
              أنت
            </div>
          </div>
        )}

        {/* Live Streaming & Enhanced Thinking State Indicator */}
        {isGenerating && (
          <div className="flex gap-3 max-w-4xl ml-auto animate-in fade-in duration-200">
            <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-2xl bg-gradient-to-tr from-teal-600 via-teal-500 to-emerald-400 text-white flex items-center justify-center font-black text-xs shrink-0 animate-pulse shadow-md shadow-teal-500/20">
              ✦
            </div>
            <div className="p-4 sm:p-5 rounded-3xl rounded-tr-sm text-xs sm:text-sm leading-relaxed bg-white dark:bg-[#131f1b] text-slate-800 dark:text-[#eef7f4] border border-slate-200/90 dark:border-[#22352f] flex-1 shadow-[0_4px_20px_rgba(0,0,0,0.04)]">
              {streamedText ? (
                <EducationalContent content={streamedText} isStreaming={true} />
              ) : (
                <div className="flex items-center gap-3 text-teal-700 dark:text-teal-300 text-xs py-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-teal-500 animate-ping shrink-0" />
                  <div className="space-y-0.5 min-w-0">
                    <span className="font-bold text-slate-800 dark:text-slate-100 block">
                      المعلم الذكي يحلل السؤال ويسترجع مقاطع المنهج...
                    </span>
                    <span className="text-[11px] text-teal-600 dark:text-teal-400 block font-medium">
                      جاري التدقيق الأكاديمي وصياغة القوانين والمعادلات بدقة عالية ✦
                    </span>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        <div ref={chatBottomRef} className="h-2" />
      </div>

      {/* Floating Scroll to Bottom Button */}
      {showScrollBottomBtn && (
        <button
          type="button"
          onClick={() => scrollToBottom(true)}
          className="absolute bottom-28 left-6 z-20 p-2.5 rounded-full bg-white dark:bg-[#182622] text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-[#253932] shadow-xl hover:bg-slate-50 dark:hover:bg-[#1f312c] transition-all flex items-center gap-1.5 text-xs font-bold animate-in fade-in slide-in-from-bottom-2 duration-150 cursor-pointer"
          title="النزول لأسفل المحادثة"
        >
          <ArrowDown className="w-4 h-4 text-teal-600 dark:text-teal-400" />
          <span className="hidden sm:inline">أحدث الرسائل</span>
        </button>
      )}

      {/* Fully Isolated Input Area with zero re-rendering on keystrokes */}
      <ChatInputArea
        isGenerating={isGenerating}
        onSendMessage={handleSend}
        onStop={handleStop}
        aiMode={aiMode}
        notebookTitle={notebookTitle}
        sourcesCount={sources.length}
        selectedSourcesCount={activeSessionSourceIds.length}
        isSearchGroundingEnabled={isSearchGroundingEnabled}
        onToggleSearchGrounding={handleToggleSearchGrounding}
        smartTips={smartTips}
        hasLastAiMessage={!!lastAIMessage}
        prefilledPrompt={prefilledPrompt}
        onClearPrefilledPrompt={onClearPrefilledPrompt}
      />

      {/* RAG Citation Preview Modal */}
      {previewCitation && (
        <div className="fixed inset-0 z-50 p-4 bg-black/60 backdrop-blur-sm flex items-center justify-center animate-in fade-in duration-150">
          <div className="bg-white dark:bg-[#14201c] w-full max-w-lg rounded-3xl p-5 sm:p-6 shadow-2xl border border-slate-200 dark:border-[#22352f]">
            <div className="flex items-center justify-between mb-3 border-b border-slate-100 dark:border-[#22352f] pb-3">
              <div>
                <h3 className="font-bold text-sm text-slate-800 dark:text-slate-100">
                  {previewCitation.sourceTitle}
                </h3>
                <div className="flex items-center gap-2 mt-1">
                  {previewCitation.pageNumber && (
                    <span className="text-xs text-teal-600 dark:text-teal-400 font-bold">
                      الصفحة رقم {previewCitation.pageNumber}
                    </span>
                  )}
                  {previewCitation.section && (
                    <span className="text-[11px] text-slate-500 dark:text-slate-400">
                      • {previewCitation.section}
                    </span>
                  )}
                </div>
              </div>
              <button
                onClick={() => setPreviewCitation(null)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1.5 rounded-xl hover:bg-slate-100 dark:hover:bg-[#1a2b25] cursor-pointer"
                title="إغلاق"
              >
                ✕
              </button>
            </div>

            <div className="p-3.5 bg-slate-50 dark:bg-[#101a16] rounded-2xl text-xs text-slate-800 dark:text-slate-100 leading-relaxed max-h-60 overflow-y-auto border border-slate-200/50 dark:border-slate-800/50">
              <div className="text-[11px] text-teal-600 dark:text-teal-400 mb-1.5 font-bold flex items-center gap-1">
                <FileText className="w-3.5 h-3.5" />
                <span>النص المسترجع من المرجع:</span>
              </div>
              <p className="whitespace-pre-wrap">{previewCitation.quote}</p>
            </div>

            <button
              type="button"
              onClick={() => {
                const cite = previewCitation;
                setPreviewCitation(null);
                handleOpenSourceLinker(cite);
              }}
              className="w-full mt-3.5 py-2.5 px-3 bg-gradient-to-r from-teal-600 to-teal-700 hover:from-teal-700 hover:to-teal-800 text-white rounded-2xl text-xs font-bold flex items-center justify-center gap-2 shadow-md transition-all cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>فتح وتظليل وتكبير في قارئ PDF المباشر (Source Linker)</span>
            </button>
          </div>
        </div>
      )}

      {/* Source Linker Full PDF Annotator Modal */}
      {activeSourceLinkTarget && (
        <div className="fixed inset-0 z-50 p-2 sm:p-4 bg-black/60 backdrop-blur-sm flex items-center justify-center animate-in fade-in duration-150">
          <div className="bg-white dark:bg-[#14201c] w-full max-w-5xl h-[92vh] rounded-3xl shadow-2xl border border-slate-200 dark:border-[#22352f] flex flex-col overflow-hidden">
            <PDFPreviewAnnotator
              source={activeSourceLinkTarget.source}
              chunks={chunks}
              initialPage={activeSourceLinkTarget.pageNumber}
              highlightText={activeSourceLinkTarget.highlightText}
              targetAnnotationId={activeSourceLinkTarget.targetAnnotationId}
              initialZoom={activeSourceLinkTarget.zoomScale}
              onUpdateAnnotations={onUpdateSourceAnnotations}
              onAskAboutQuote={onAskAboutQuote}
              onExportToNote={onExportToNote}
              onClose={() => setActiveSourceLinkTarget(null)}
            />
          </div>
        </div>
      )}

      {/* Academic Print & PDF Export Modal */}
      {printSummaryData && (
        <AcademicPrintModal
          isOpen={isPrintModalOpen}
          onClose={() => setIsPrintModalOpen(false)}
          summary={printSummaryData}
        />
      )}

      {/* AI Connection & Engine Settings Modal */}
      {showAiSettingsModal && (
        <div className="fixed inset-0 z-50 p-4 bg-black/60 backdrop-blur-sm flex items-center justify-center animate-in fade-in duration-150">
          <div className="bg-white dark:bg-[#14201c] w-full max-w-lg rounded-3xl p-5 sm:p-6 shadow-2xl border border-slate-200 dark:border-[#22352f] space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-[#22352f] pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-teal-100 dark:bg-teal-950/80 text-teal-700 dark:text-teal-300 flex items-center justify-center">
                  <Cpu className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-slate-800 dark:text-slate-100">
                    إعدادات وحالة محرك الذكاء الاصطناعي
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    تأكيد اتصال السحابة، المفتاح المباشر، أو المحرك المحلي
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowAiSettingsModal(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1.5 rounded-xl hover:bg-slate-100 dark:hover:bg-[#1a2b25] cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Connection Status Box */}
            <div className={`p-3.5 rounded-2xl border transition-all text-xs space-y-2 ${
              serverHealthStatus === 'connected'
                ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200'
                : serverHealthStatus === 'checking'
                ? 'bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-800 text-amber-900 dark:text-amber-200'
                : 'bg-slate-50 dark:bg-[#121c18] border-slate-200 dark:border-[#22352f] text-slate-700 dark:text-slate-300'
            }`}>
              <div className="flex items-center justify-between">
                <span className="font-bold flex items-center gap-1.5">
                  <span className={`w-2 h-2 rounded-full ${serverHealthStatus === 'connected' ? 'bg-emerald-500 animate-pulse' : serverHealthStatus === 'checking' ? 'bg-amber-500 animate-spin' : 'bg-slate-400'}`} />
                  حالة المحرك الحالي:
                </span>
                <button
                  type="button"
                  onClick={() => checkConnectionStatus(standaloneApiKey, customBackendUrl)}
                  className="px-2.5 py-1 rounded-xl bg-white dark:bg-[#182622] border border-slate-200 dark:border-[#22352f] text-[11px] font-bold hover:bg-slate-50 dark:hover:bg-[#1f312c] transition-all flex items-center gap-1 cursor-pointer"
                >
                  <RefreshCw className={`w-3 h-3 ${serverHealthStatus === 'checking' ? 'animate-spin' : ''}`} />
                  <span>فحص الاتصال الآن</span>
                </button>
              </div>
              <div className="text-[11px] leading-relaxed font-semibold">
                {serverHealthMsg || 'المحرك جاهز للعمل.'}
              </div>
            </div>

            {/* Preconfigured Automated D.CORE Gemini AI Keys Information */}
            <div className="p-4 rounded-2xl bg-teal-50/70 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-800 text-xs text-slate-800 dark:text-slate-100 space-y-2.5">
              <div className="font-extrabold text-teal-800 dark:text-teal-300 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span>مفاتيح الذكاء الاصطناعي الرسمية (Google Gemini) متصلة تلقائياً</span>
              </div>
              <p className="text-[11px] leading-relaxed text-slate-600 dark:text-slate-300">
                تم دمج وربط مفاتيح ��لذكاء الاصطناعي الرسمية بنظام التناوب الذكي وتفادي الحصص تلقائياً بواسطة <b>فريق D.CORE الذكي</b>. يعمل التطبيق بكامل طاقته الذكية فوراً دون أي تدخل يدوي منك.
              </p>
              <div className="flex flex-wrap items-center gap-2 pt-1 text-[10px] font-mono text-emerald-800 dark:text-emerald-300 font-bold">
                <span className="px-2 py-0.5 rounded-md bg-emerald-100 dark:bg-emerald-950/80 border border-emerald-300/60 dark:border-emerald-800/60">
                  3 مفاتيح نشطة
                </span>
                <span className="px-2 py-0.5 rounded-md bg-teal-100 dark:bg-teal-950/80 border border-teal-300/60 dark:border-teal-800/60">
                  نموذج gemini-3.5-flash-lite فائق السرعة
                </span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center justify-end pt-2 border-t border-slate-100 dark:border-[#22352f]">
              <button
                type="button"
                onClick={() => setShowAiSettingsModal(false)}
                className="py-2.5 px-6 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold transition-all cursor-pointer shadow-xs"
              >
                حسناً، فهمت
              </button>
            </div>
          </div>
        </div>
      )}

      {/* World-Class Conversation History Drawer */}
      <ChatHistoryDrawer
        isOpen={isHistoryDrawerOpen}
        onClose={() => setIsHistoryDrawerOpen(false)}
        sessions={allSessions}
        currentSessionId={session.id}
        onSelectSession={onSelectSession}
        onNewSession={onNewSession}
        onDeleteSession={onDeleteSession}
        onRenameSession={onRenameSession}
        onExportSessionPdf={handleExportSpecificSessionPdf}
      />

      {/* Isolated Session Sources Modal */}
      {isSessionSourcesModalOpen && (
        <div 
          className="fixed inset-0 z-50 p-4 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center animate-in fade-in duration-200"
          dir="rtl"
        >
          <div 
            className="bg-white dark:bg-[#14201c] w-full max-w-lg rounded-3xl p-5 shadow-2xl border border-teal-100 dark:border-[#22352f] flex flex-col max-h-[85vh] animate-in zoom-in-95 duration-150"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-[#22352f]">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-teal-600/10 text-teal-700 dark:text-teal-300 flex items-center justify-center font-bold">
                  <BookOpen className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-black text-sm text-slate-800 dark:text-slate-100">
                    مراجع وسياق الجلسة (Isolated Source Context)
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                    اختر المراجع الحصرية التي يستند عليها الذكاء الاصطناعي لهذه المحادثة تحديداً لمنع التداخل بين الجلسات.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsSessionSourcesModalOpen(false)}
                className="w-8 h-8 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-[#1a2b25] flex items-center justify-center cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Quick Actions Bar */}
            <div className="py-3 flex items-center justify-between gap-2 border-b border-slate-100 dark:border-[#22352f] text-xs">
              <span className="font-bold text-slate-700 dark:text-slate-300">
                المراجع المحددة: {activeSessionSourceIds.length} من {sources.length}
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleSelectAllSessionSources}
                  className="px-2.5 py-1 rounded-lg text-xs font-bold text-teal-700 dark:text-teal-300 hover:bg-teal-50 dark:hover:bg-teal-950/60 cursor-pointer"
                >
                  تحديد الكل
                </button>
                <button
                  type="button"
                  onClick={handleClearAllSessionSources}
                  className="px-2.5 py-1 rounded-lg text-xs font-bold text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/60 cursor-pointer"
                >
                  إلغاء التحديد
                </button>
              </div>
            </div>

            {/* Sources List */}
            <div className="py-3 overflow-y-auto flex-1 space-y-2">
              {sources.length === 0 ? (
                <div className="py-8 text-center text-slate-400 text-xs">
                  لا توجد مراجع مضافة في هذا الدفتر بعد. أضف كتباً أو روابط من قسم المراجع لتفعيل الاسترجاع الدقيق (RAG).
                </div>
              ) : (
                sources.map((src) => {
                  const isChecked = activeSessionSourceIds.includes(src.id);
                  return (
                    <label
                      key={src.id}
                      className={`flex items-center justify-between p-3 rounded-2xl border transition-all cursor-pointer ${
                        isChecked
                          ? 'bg-teal-50/70 dark:bg-teal-950/40 border-teal-300 dark:border-teal-800 text-teal-900 dark:text-teal-100'
                          : 'bg-slate-50 dark:bg-[#182622] border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 opacity-70 hover:opacity-100'
                      }`}
                    >
                      <div className="flex items-center gap-3 min-w-0 pr-1">
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => handleToggleSessionSource(src.id)}
                          className="w-4 h-4 rounded text-teal-600 focus:ring-teal-500 cursor-pointer"
                        />
                        <div className="min-w-0">
                          <div className="font-bold text-xs truncate">
                            {src.title}
                          </div>
                          <div className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">
                            {src.type} • {src.wordCount || Math.round(src.content.length / 5)} كلمة
                          </div>
                        </div>
                      </div>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-white/80 dark:bg-[#14201c] shrink-0 font-bold">
                        {isChecked ? 'نشط بالجلسة' : 'معطل'}
                      </span>
                    </label>
                  );
                })
              )}
            </div>

            {/* Footer */}
            <div className="pt-3 border-t border-slate-100 dark:border-[#22352f] flex items-center justify-between">
              <span className="text-[10px] text-slate-500 dark:text-slate-400">
                يتم حفظ الاختيارات تلقائياً داخل بيانات الجلسة الحالية لمنع التداخل بين المحادثات.
              </span>
              <button
                type="button"
                onClick={() => setIsSessionSourcesModalOpen(false)}
                className="px-5 py-2 rounded-xl text-xs font-bold bg-teal-600 hover:bg-teal-700 text-white cursor-pointer shadow-xs"
              >
                تم، حفظ السياق
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
