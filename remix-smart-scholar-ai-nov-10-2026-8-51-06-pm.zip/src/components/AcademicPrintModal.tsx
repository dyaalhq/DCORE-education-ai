import React, { useState } from 'react';
import {
  Download,
  Printer,
  X,
  Copy,
  Check,
  BookOpen,
  FileText,
  Sparkles,
  Award,
  Layers,
  Calendar,
} from 'lucide-react';
import {
  StructuredSummary,
  exportToAcademicPdf,
} from '../lib/academicFormatter';
import { EducationalContent } from './EducationalContent';

interface AcademicPrintModalProps {
  isOpen: boolean;
  onClose: () => void;
  summary: StructuredSummary | null;
  isLoading?: boolean;
}

export const AcademicPrintModal: React.FC<AcademicPrintModalProps> = ({
  isOpen,
  onClose,
  summary,
  isLoading = false,
}) => {
  const [isExporting, setIsExporting] = useState(false);
  const [copied, setCopied] = useState(false);
  const [activeViewMode, setActiveViewMode] = useState<'structured' | 'clean_full'>('structured');

  if (!isOpen) return null;

  const handleDirectPrint = () => {
    const docElement = document.getElementById('printable-academic-document');
    if (!docElement) {
      window.print();
      return;
    }

    // Collect all stylesheets and style rules from current page (including Tailwind & KaTeX)
    let stylesHtml = '';
    const styleTags = document.querySelectorAll('style, link[rel="stylesheet"]');
    styleTags.forEach((tag) => {
      stylesHtml += tag.outerHTML + '\n';
    });

    // Create a temporary hidden iframe
    const printIframe = document.createElement('iframe');
    printIframe.setAttribute('id', 'academic-print-frame');
    printIframe.style.position = 'fixed';
    printIframe.style.top = '-9999px';
    printIframe.style.left = '-9999px';
    printIframe.style.width = '0px';
    printIframe.style.height = '0px';
    printIframe.style.border = 'none';
    printIframe.style.visibility = 'hidden';

    document.body.appendChild(printIframe);

    const iframeDoc = printIframe.contentDocument || printIframe.contentWindow?.document;
    if (!iframeDoc) {
      window.print();
      return;
    }

    const documentContent = docElement.innerHTML;

    iframeDoc.open();
    iframeDoc.write(`<!DOCTYPE html>
<html lang="ar" dir="rtl">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>${summary?.notebookName || 'التقرير الأكاديمي'}</title>
    ${stylesHtml}
    <style>
      @page {
        size: A4 portrait;
        margin: 12mm 10mm 14mm 10mm;
      }
      * {
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
        color-adjust: exact !important;
      }
      html, body {
        margin: 0 !important;
        padding: 0 !important;
        background: #ffffff !important;
        color: #1f2937 !important;
        direction: rtl !important;
        font-family: 'Tajawal', 'Cairo', 'Noto Sans Arabic', system-ui, sans-serif !important;
        letter-spacing: 0 !important;
        line-height: 1.85 !important;
        width: 100% !important;
        min-height: 100% !important;
      }
      .academic-report-style {
        box-shadow: none !important;
        border: none !important;
        border-radius: 0 !important;
        padding: 0 4mm !important;
        margin: 0 auto !important;
        max-width: 100% !important;
        width: 100% !important;
        background-color: #ffffff !important;
      }
      .academic-section {
        break-inside: avoid !important;
        page-break-inside: avoid !important;
        border-color: #cbd5e1 !important;
        margin-bottom: 12px !important;
      }
      table, tr, .katex-display {
        break-inside: avoid !important;
        page-break-inside: avoid !important;
      }
      .no-print {
        display: none !important;
      }
    </style>
  </head>
  <body>
    <div class="academic-report-style">
      ${documentContent}
    </div>
  </body>
</html>`);
    iframeDoc.close();

    // Ensure all styles and fonts are applied before triggering print
    setTimeout(() => {
      try {
        const frameWin = printIframe.contentWindow;
        if (frameWin) {
          frameWin.focus();
          frameWin.print();
        }
      } catch (err) {
        console.error('Frame print trigger failed:', err);
        window.print();
      } finally {
        // Clean up temporary iframe after print interaction
        setTimeout(() => {
          if (document.body.contains(printIframe)) {
            document.body.removeChild(printIframe);
          }
        }, 3000);
      }
    }, 350);
  };

  const handleDownloadPdf = async () => {
    if (!summary) return;
    setIsExporting(true);
    try {
      const cleanFileName = `تقرير_دراسي_${(summary.notebookName || 'ملخص').replace(/\s+/g, '_')}_${Date.now()}.pdf`;
      await exportToAcademicPdf('printable-academic-document', cleanFileName);
    } catch (e) {
      console.error('Download error:', e);
      handleDirectPrint();
    } finally {
      setIsExporting(false);
    }
  };

  const handleCopyText = () => {
    if (!summary) return;
    navigator.clipboard.writeText(summary.rawFilteredMarkdown);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/70 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-white dark:bg-[#14201c] rounded-2xl shadow-2xl border border-gray-200 dark:border-gray-800 flex flex-col max-h-[92vh] overflow-hidden">
        {/* Top Control Bar (Hidden in Print) */}
        <div className="no-print p-3 sm:p-4 bg-[#f8fbfa] dark:bg-[#101916] border-b border-[#e2e8e5] dark:border-[#22352f] flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-teal-600 text-white flex items-center justify-center">
              <Award className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-gray-900 dark:text-white">
                معاينة التقرير الأكاديمي والطباعة الفاخرة (PDF)
              </h3>
              <p className="text-[11px] text-gray-500 dark:text-gray-400">
                منسق أكاديمياً بخطوط Serif، ومقسم هرمياً بدون حشو
              </p>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Toggle view mode */}
            <div className="hidden sm:flex items-center bg-gray-200 dark:bg-gray-800 p-0.5 rounded-lg text-xs font-semibold">
              <button
                type="button"
                onClick={() => setActiveViewMode('structured')}
                className={`px-2.5 py-1 rounded-md transition-all ${
                  activeViewMode === 'structured'
                    ? 'bg-white dark:bg-[#14201c] text-teal-700 dark:text-teal-300 shadow-xs font-bold'
                    : 'text-gray-600 dark:text-gray-400'
                }`}
              >
                الأقسام الهرمية
              </button>
              <button
                type="button"
                onClick={() => setActiveViewMode('clean_full')}
                className={`px-2.5 py-1 rounded-md transition-all ${
                  activeViewMode === 'clean_full'
                    ? 'bg-white dark:bg-[#14201c] text-teal-700 dark:text-teal-300 shadow-xs font-bold'
                    : 'text-gray-600 dark:text-gray-400'
                }`}
              >
                النص الكامل المصفى
              </button>
            </div>

            <button
              type="button"
              onClick={handleCopyText}
              className="px-3 py-1.5 rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-100 text-xs font-bold flex items-center gap-1.5 transition-colors"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'تم النسخ!' : 'نسخ'}</span>
            </button>

            <button
              type="button"
              onClick={handleDirectPrint}
              className="px-3 py-1.5 rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-100 text-xs font-bold flex items-center gap-1.5 transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>طباعة مباشرة</span>
            </button>

            <button
              type="button"
              onClick={handleDownloadPdf}
              disabled={isExporting}
              className="px-3.5 py-1.5 rounded-xl bg-teal-700 hover:bg-teal-800 text-white text-xs font-bold shadow-sm flex items-center gap-1.5 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{isExporting ? 'جاري تجهيز PDF...' : 'تحميل PDF أكاديمي (A4)'}</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-xl text-gray-500 hover:bg-gray-200 dark:hover:bg-gray-800 transition-colors"
              title="إغلاق"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Document Preview Scroll Container */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-8 bg-[#eaedeb] dark:bg-[#0c1412]">
          {isLoading || !summary ? (
            <div className="flex flex-col items-center justify-center p-12 sm:p-16 space-y-4 text-center bg-white dark:bg-[#14201c] rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-teal-600 to-emerald-400 text-white flex items-center justify-center shadow-lg shadow-teal-600/20 text-xl font-bold animate-pulse">
                ✦
              </div>
              <div className="max-w-md space-y-1.5">
                <h4 className="text-base sm:text-lg font-bold text-slate-800 dark:text-slate-100">
                  جاري استخلاص المحتوى الحقيقي وصياغة التقرير الأكاديمي...
                </h4>
                <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 leading-relaxed">
                  يقوم محرك التلخيص الأكاديمي بتحليل الشرح والمعادلات لحصر المفاهيم والقواعد والتنبيهات المنهجية بدقة واستبعاد القوالب الجاهزة.
                </p>
              </div>
            </div>
          ) : (
            /* Printable Document Sheet */
            <div
              id="printable-academic-document"
              className="academic-report-style bg-white text-gray-900 shadow-lg mx-auto"
            >
              {/* Document Header */}
              <div className="academic-report-header">
                <div className="flex items-center justify-between gap-4 pb-3 border-b border-gray-200">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-[#0f766e] text-white flex items-center justify-center font-bold font-serif text-lg">
                      ن
                    </div>
                    <div>
                      <span className="text-[11px] font-bold text-[#0f766e] tracking-wide uppercase">
                        تقرير دراسي أكاديمي موثق
                      </span>
                      <h1 className="text-xl sm:text-2xl font-black text-gray-900 academic-serif m-0 p-0 border-none">
                        {summary.documentTitle || summary.notebookName}
                      </h1>
                      {summary.notebookName && summary.documentTitle && summary.notebookName !== summary.documentTitle && (
                        <p className="text-xs text-gray-500 font-sans mt-0.5">
                          ضمن دفتر: {summary.notebookName}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="text-left text-xs text-gray-500 font-sans space-y-1">
                    <div className="flex items-center gap-1 justify-end">
                      <Calendar className="w-3 h-3 text-teal-600" />
                      <span>{summary.dateStr}</span>
                    </div>
                    {summary.subject && (
                      <div className="font-semibold text-teal-800 bg-teal-50 px-2 py-0.5 rounded text-[11px]">
                        {summary.subject}
                      </div>
                    )}
                  </div>
                </div>

                {/* Document Sub-Notice */}
                <div className="pt-2 flex items-center justify-between text-[11px] text-gray-500">
                  <span className="font-medium text-teal-800">مستخلص أكاديمي دقيق مستخرج حصرياً من واقع الشرح والدرس</span>
                  <span className="font-mono text-[10px] text-gray-400">D.CORE Schooler AI Verified Report</span>
                </div>
              </div>

              {/* Document Body */}
              {activeViewMode === 'structured' ? (
                <div className="space-y-6">
                  {/* 1. Main Concepts (المفاهيم والتعاريف) */}
                  {summary.mainConcepts?.content && summary.mainConcepts.content.trim().length > 0 && (
                    <div className="academic-section section-teal">
                      <div className="flex items-center justify-between pb-2 mb-3 border-b border-teal-100">
                        <h2 className="text-base sm:text-lg font-bold text-teal-900 m-0 academic-serif flex items-center gap-2">
                          <span>💡</span>
                          <span>{summary.mainConcepts.title}</span>
                        </h2>
                        <span className="text-[10px] text-teal-700 font-mono hidden sm:inline">
                          {summary.mainConcepts.englishTitle}
                        </span>
                      </div>
                      <EducationalContent content={summary.mainConcepts.content} />
                    </div>
                  )}

                  {/* 2. Key Takeaways (الخلاصات والنقاط الجوهرية) */}
                  {summary.keyTakeaways?.content && summary.keyTakeaways.content.trim().length > 0 && (
                    <div className="academic-section section-navy">
                      <div className="flex items-center justify-between pb-2 mb-3 border-b border-blue-100">
                        <h2 className="text-base sm:text-lg font-bold text-blue-900 m-0 academic-serif flex items-center gap-2">
                          <span>📌</span>
                          <span>{summary.keyTakeaways.title}</span>
                        </h2>
                        <span className="text-[10px] text-blue-700 font-mono hidden sm:inline">
                          {summary.keyTakeaways.englishTitle}
                        </span>
                      </div>
                      <EducationalContent content={summary.keyTakeaways.content} />
                    </div>
                  )}

                  {/* 3. Methodology & Procedures (المنهجية والتط��يقات) */}
                  {summary.methodology?.content && summary.methodology.content.trim().length > 0 && (
                    <div className="academic-section section-emerald">
                      <div className="flex items-center justify-between pb-2 mb-3 border-b border-emerald-100">
                        <h2 className="text-base sm:text-lg font-bold text-emerald-900 m-0 academic-serif flex items-center gap-2">
                          <span>📐</span>
                          <span>{summary.methodology.title}</span>
                        </h2>
                        <span className="text-[10px] text-emerald-700 font-mono hidden sm:inline">
                          {summary.methodology.englishTitle}
                        </span>
                      </div>
                      <EducationalContent content={summary.methodology.content} />
                    </div>
                  )}

                  {/* 4. Detailed Analysis & Formulas (القوانين والتحليل) - استبعاد الحقول الفارغة إذا لم تحتوِ المادة عليها */}
                  {summary.detailedAnalysis?.content &&
                    summary.detailedAnalysis.content.trim().length > 0 &&
                    summary.detailedAnalysis.hasContent !== false && (
                      <div className="academic-section section-teal">
                        <div className="flex items-center justify-between pb-2 mb-3 border-b border-teal-100">
                          <h2 className="text-base sm:text-lg font-bold text-teal-900 m-0 academic-serif flex items-center gap-2">
                            <span>⚖️</span>
                            <span>{summary.detailedAnalysis.title}</span>
                          </h2>
                          <span className="text-[10px] text-teal-700 font-mono hidden sm:inline">
                            {summary.detailedAnalysis.englishTitle}
                          </span>
                        </div>
                        <EducationalContent content={summary.detailedAnalysis.content} />
                      </div>
                    )}

                  {/* 5. Exam Tips & Pitfalls (تنبيهات الامتحانات وملاحظات التركيز الوزارية) */}
                  {summary.examTips?.content &&
                    summary.examTips.content.trim().length > 0 &&
                    summary.examTips.hasContent !== false && (
                      <div className="academic-section section-amber">
                        <div className="flex items-center justify-between pb-2 mb-3 border-b border-amber-100">
                          <h2 className="text-base sm:text-lg font-bold text-amber-900 m-0 academic-serif flex items-center gap-2">
                            <span>⚠️</span>
                            <span>{summary.examTips.title}</span>
                          </h2>
                          <span className="text-[10px] text-amber-700 font-mono hidden sm:inline">
                            {summary.examTips.englishTitle}
                          </span>
                        </div>
                        <EducationalContent content={summary.examTips.content} />
                      </div>
                    )}
                </div>
              ) : (
                <div className="space-y-4">
                  <EducationalContent content={summary.rawFilteredMarkdown} />
                </div>
              )}

              {/* Document Footer */}
              <div className="academic-report-footer">
                <div>
                  <span>Developed by Dhiyaa Al-Haq Subayqaa & The D.CORE Academic Team</span>
                </div>
                <div className="text-center font-mono text-[10px]">
                  <span>تم التطوير بواسطة المهندس ضياء الحق سبيقاء وفريق D.CORE الأكاديمي • {summary.dateStr}</span>
                </div>
                <div>
                  <span>وثيقة مراجعة أكاديمية معتمدة للطباعة (A4)</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
