import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import {
  Highlighter,
  MessageSquare,
  Trash2,
  Edit3,
  Check,
  X,
  ChevronLeft,
  ChevronRight,
  ZoomIn,
  ZoomOut,
  FileText,
  Copy,
  BookOpen,
  Download,
  Search,
  Bookmark,
  Sparkles,
  Layers,
  AlertCircle,
  Maximize2,
  Minimize2,
  Type,
  Sun,
  Moon,
  Compass,
  ArrowRight,
  ExternalLink,
  Share2
} from 'lucide-react';
import { Source, SourceAnnotation, HighlightColor, AnnotationRect, SourceChunk } from '../types';
import { getFileBlob, storeFileBlob } from '../lib/storage';
import {
  normalizeArabic,
  findAnnotationOffsetsInText,
  ensureDocumentPages,
  MatchedRange
} from '../lib/annotationMatcher';
import { findMatchingChunk } from '../lib/documentParser';
import { SourceAnnotationCard, SourceAnnotationOverlay } from './SourceAnnotation';

export type AnnotatorWorkspaceMode = 'doc-only' | 'split' | 'notes-full';

export interface PDFPreviewAnnotatorProps {
  source: Source;
  chunks?: SourceChunk[];
  initialPage?: number;
  highlightText?: string;
  targetAnnotationId?: string;
  initialZoom?: number;
  onUpdateAnnotations?: (sourceId: string, annotations: SourceAnnotation[]) => void;
  onAskAboutQuote?: (quote: string, pageNumber: number) => void;
  onExportToNote?: (title: string, content: string) => void;
  onClose?: () => void;
  onOpenReaderView?: () => void;
  isWideMode?: boolean;
  onToggleWideMode?: () => void;
  initialWorkspaceMode?: AnnotatorWorkspaceMode;
}

export const COLOR_MAP: Record<HighlightColor, {
  name: string;
  bg: string;
  badge: string;
  border: string;
  text: string;
  highlightClass: string;
}> = {
  yellow: {
    name: 'أصفر كلاسيكي',
    bg: '#fef08a',
    badge: 'bg-yellow-100 text-yellow-800 border-yellow-300 dark:bg-yellow-950/40 dark:text-yellow-200',
    border: 'border-yellow-400',
    text: '#854d0e',
    highlightClass: 'bg-yellow-200/90 dark:bg-yellow-400/30 text-yellow-950 dark:text-yellow-100 decoration-yellow-400 shadow-xs ring-1 ring-yellow-400/30',
  },
  green: {
    name: 'أخضر زمردي',
    bg: '#bbf7d0',
    badge: 'bg-emerald-100 text-emerald-800 border-emerald-300 dark:bg-emerald-950/40 dark:text-emerald-200',
    border: 'border-emerald-400',
    text: '#166534',
    highlightClass: 'bg-emerald-200/90 dark:bg-emerald-400/30 text-emerald-950 dark:text-emerald-100 decoration-emerald-400 shadow-xs ring-1 ring-emerald-400/30',
  },
  blue: {
    name: 'أزرق معرفي',
    bg: '#bfdbfe',
    badge: 'bg-sky-100 text-sky-800 border-sky-300 dark:bg-sky-950/40 dark:text-sky-200',
    border: 'border-sky-400',
    text: '#1e40af',
    highlightClass: 'bg-sky-200/90 dark:bg-sky-400/30 text-sky-950 dark:text-sky-100 decoration-sky-400 shadow-xs ring-1 ring-sky-400/30',
  },
  purple: {
    name: 'بنفسجي تحليلي',
    bg: '#e9d5ff',
    badge: 'bg-purple-100 text-purple-800 border-purple-300 dark:bg-purple-950/40 dark:text-purple-200',
    border: 'border-purple-400',
    text: '#6b21a8',
    highlightClass: 'bg-purple-200/90 dark:bg-purple-400/30 text-purple-950 dark:text-purple-100 decoration-purple-400 shadow-xs ring-1 ring-purple-400/30',
  },
  rose: {
    name: 'وردي تنبيهي',
    bg: '#fecdd3',
    badge: 'bg-rose-100 text-rose-800 border-rose-300 dark:bg-rose-950/40 dark:text-rose-200',
    border: 'border-rose-400',
    text: '#9f1239',
    highlightClass: 'bg-rose-200/90 dark:bg-rose-400/30 text-rose-950 dark:text-rose-100 decoration-rose-400 shadow-xs ring-1 ring-rose-400/30',
  },
};

type ReadingTheme = 'paper' | 'sepia' | 'dark' | 'mint' | 'contrast-dark' | 'contrast-light' | 'contrast-yellow';
type ReadingFont = 'font-tajawal' | 'font-amiri' | 'font-cairo';

export const PDFPreviewAnnotator: React.FC<PDFPreviewAnnotatorProps> = ({
  source,
  chunks,
  initialPage,
  highlightText,
  targetAnnotationId,
  initialZoom,
  onUpdateAnnotations,
  onAskAboutQuote,
  onExportToNote,
  onClose,
  onOpenReaderView,
  isWideMode = false,
  onToggleWideMode,
  initialWorkspaceMode,
}) => {
  // 1. Local Annotations state for 0ms optimistic UI and flawless persistence
  const [localAnnotations, setLocalAnnotations] = useState<SourceAnnotation[]>(() => {
    return source.annotations || [];
  });

  // Synchronize when external source changes
  useEffect(() => {
    if (source.annotations) {
      setLocalAnnotations(source.annotations);
    }
  }, [source.annotations, source.id]);

  const syncAnnotations = useCallback((updated: SourceAnnotation[]) => {
    setLocalAnnotations(updated);
    if (onUpdateAnnotations) {
      onUpdateAnnotations(source.id, updated);
    }
  }, [source.id, onUpdateAnnotations]);

  // 2. Structured document pages
  const documentPages = useMemo(() => {
    return ensureDocumentPages(source.content, source.pages);
  }, [source.content, source.pages]);

  const totalPages = Math.max(1, documentPages.length, source.pageCount || 1);

  // 3. Page & View state
  const [currentPage, setCurrentPage] = useState<number>(() => {
    if (initialPage && initialPage > 0) return Math.min(initialPage, totalPages);
    return 1;
  });

  const [viewMode, setViewMode] = useState<'text' | 'canvas'>('text');
  const [layoutMode, setLayoutMode] = useState<'paginated' | 'continuous'>('paginated');
  const [zoomScale, setZoomScale] = useState<number>(() => initialZoom || 1.25);
  const [hasCanvasSupport, setHasCanvasSupport] = useState<boolean>(false);
  const [isPdfLoading, setIsPdfLoading] = useState<boolean>(false);

  // 4. Reading Preferences & Accessibility
  const [readingTheme, setReadingTheme] = useState<ReadingTheme>('paper');
  const [fontSize, setFontSize] = useState<number>(17);
  const [lineHeight, setLineHeight] = useState<'compact' | 'standard' | 'relaxed' | 'accessible'>('standard');
  const [fontFamily, setFontFamily] = useState<ReadingFont>('font-tajawal');

  // 5. In-Document Search State
  const [isSearchOpen, setIsSearchOpen] = useState<boolean>(false);
  const [inDocSearchTerm, setInDocSearchTerm] = useState<string>('');
  const [activeSearchMatchIdx, setActiveSearchMatchIdx] = useState<number>(0);

  // 6. Selection & Highlighting State with Screen-Aware Coordinates
  interface SelectionToolbarPosition {
    top: number;
    left: number;
    width: number;
    placement: 'top' | 'bottom';
  }

  const [selectedText, setSelectedText] = useState<string>('');
  const [toolbarPosition, setToolbarPosition] = useState<SelectionToolbarPosition | null>(null);
  const [selectionOffsets, setSelectionOffsets] = useState<{
    pageNumber: number;
    start?: number;
    end?: number;
    prefix?: string;
    suffix?: string;
    rects?: AnnotationRect[];
    boundingRect?: AnnotationRect;
    chunkId?: string;
    paragraphIndex?: number;
    paragraphText?: string;
  } | null>(null);
  const [activeColor, setActiveColor] = useState<HighlightColor>('yellow');
  const [activeTargetAnnotationId, setActiveTargetAnnotationId] = useState<string | null>(targetAnnotationId || null);
  const [isFlashActive, setIsFlashActive] = useState<boolean>(true);

  // Auto-jump to target annotation if passed from Chat
  useEffect(() => {
    if (targetAnnotationId) {
      setActiveTargetAnnotationId(targetAnnotationId);
      setIsFlashActive(true);
      const target = localAnnotations.find((a) => a.id === targetAnnotationId);
      if (target) {
        jumpToAnnotation(target);
      }
    }
  }, [targetAnnotationId, localAnnotations]);

  // 7. Modals & Popovers
  const [isNoteModalOpen, setIsNoteModalOpen] = useState<boolean>(false);
  const [pendingAnnotation, setPendingAnnotation] = useState<Partial<SourceAnnotation> | null>(null);
  const [noteInputText, setNoteInputText] = useState<string>('');
  
  // Active clicked highlight for quick edit popover
  const [activePopoverHighlight, setActivePopoverHighlight] = useState<{
    annotation: SourceAnnotation;
    position: { x: number; y: number };
  } | null>(null);

  // Workspace Layout Architecture: Document-Only, Split-Workspace (Responsive), or Full Notes Manager
  const [workspaceMode, setWorkspaceMode] = useState<AnnotatorWorkspaceMode>(() => {
    const isSmallScreen = typeof window !== 'undefined' && window.innerWidth < 1024;
    return initialWorkspaceMode || (source.annotations && source.annotations.length > 0 && !isSmallScreen ? 'split' : 'doc-only');
  });
  const showDrawer = workspaceMode !== 'doc-only';
  const setShowDrawer = (show: boolean) => {
    setWorkspaceMode(show ? 'split' : 'doc-only');
  };

  const [drawerColorFilter, setDrawerColorFilter] = useState<HighlightColor | 'all'>('all');
  const [drawerPageFilter, setDrawerPageFilter] = useState<'all' | 'current'>('all');
  const [drawerSearch, setDrawerSearch] = useState<string>('');

  // Auto layout recalculation and resize event trigger
  useEffect(() => {
    const timer = setTimeout(() => {
      window.dispatchEvent(new Event('resize'));
    }, 120);
    return () => clearTimeout(timer);
  }, [workspaceMode]);

  // Jump smoothly to target annotation on target page with spotlight glow
  const jumpToAnnotation = (ann: SourceAnnotation) => {
    const isSmallScreen = typeof window !== 'undefined' && window.innerWidth < 1024;
    if (workspaceMode === 'notes-full' || isSmallScreen) {
      setWorkspaceMode('doc-only');
    }
    setCurrentPage(ann.pageNumber);
    setTimeout(() => {
      const el = document.getElementById(`ann-mark-${ann.id}`);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        el.classList.add('ring-4', 'ring-teal-500', 'scale-105', 'transition-all');
        setTimeout(() => {
          el.classList.remove('ring-4', 'ring-teal-500', 'scale-105');
        }, 1800);
      } else {
        textContainerRef.current?.scrollTo({ top: 0, behavior: 'smooth' });
      }
    }, 150);
  };

  // Toast feedback
  const [toastMessage, setToastMessage] = useState<string>('');
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(''), 2600);
  };

  // Refs
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const textContainerRef = useRef<HTMLDivElement | null>(null);
  const pdfDocRef = useRef<any>(null);

  // Sync initialPage from outside
  useEffect(() => {
    if (initialPage && initialPage > 0) {
      setCurrentPage(Math.min(initialPage, totalPages));
    }
  }, [initialPage, totalPages]);

  // Load PDF Blob if exists (PDF.js)
  useEffect(() => {
    let isCancelled = false;

    async function loadPdf() {
      if (!window.pdfjsLib) {
        setHasCanvasSupport(false);
        setViewMode('text');
        return;
      }

      const fileId = source.localFileId || source.id;
      try {
        let blob = await getFileBlob(fileId);
        if (!blob && source.uri && (source.type === 'application/pdf' || source.uri.toLowerCase().includes('.pdf'))) {
          try {
            const proxyRes = await fetch(`/api/proxy-pdf?url=${encodeURIComponent(source.uri)}`);
            if (proxyRes.ok) {
              blob = await proxyRes.blob();
              await storeFileBlob(fileId, blob);
            }
          } catch (e) {
            console.warn('Could not fetch PDF via proxy:', e);
          }
        }

        if (!blob || isCancelled) {
          setHasCanvasSupport(false);
          return;
        }

        setIsPdfLoading(true);
        const arrayBuffer = await blob.arrayBuffer();
        const loadingTask = window.pdfjsLib.getDocument({
          data: arrayBuffer,
          useSystemFonts: true,
        });

        const doc = await loadingTask.promise;
        if (isCancelled) return;

        pdfDocRef.current = doc;
        setHasCanvasSupport(true);
        setIsPdfLoading(false);
      } catch (err) {
        console.warn('PDF.js canvas could not be initialized:', err);
        if (!isCancelled) {
          setHasCanvasSupport(false);
          setIsPdfLoading(false);
        }
      }
    }

    loadPdf();
    return () => {
      isCancelled = true;
    };
  }, [source.id, source.localFileId]);

  // Render Page on Canvas when in Canvas mode with Canvas API high-precision highlighting
  useEffect(() => {
    if (viewMode !== 'canvas' || !pdfDocRef.current || !canvasRef.current) return;

    let isCurrent = true;
    async function renderPage() {
      try {
        const pageNum = Math.min(Math.max(1, currentPage), pdfDocRef.current.numPages);
        const page = await pdfDocRef.current.getPage(pageNum);
        if (!isCurrent || !canvasRef.current) return;

        const viewport = page.getViewport({ scale: zoomScale * 1.35 });
        const canvas = canvasRef.current;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        canvas.height = viewport.height;
        canvas.width = viewport.width;

        // 1. Render base PDF page
        await page.render({
          canvasContext: ctx,
          viewport,
        }).promise;

        if (!isCurrent) return;

        // 2. High-precision Canvas API highlight rendering
        // Draws directly onto Canvas 2D context using exact pixel bounds matching current zoom
        const pageAnns = localAnnotations.filter((a) => a.pageNumber === pageNum);
        if (pageAnns.length > 0) {
          ctx.save();
          for (const ann of pageAnns) {
            const isTarget = ann.id === activeTargetAnnotationId;
            const rects = ann.rects && ann.rects.length > 0 ? ann.rects : ann.boundingRect ? [ann.boundingRect] : [];

            let fill = 'rgba(254, 240, 138, 0.42)'; // yellow
            if (ann.color === 'green') fill = 'rgba(187, 247, 208, 0.42)';
            else if (ann.color === 'blue') fill = 'rgba(191, 219, 254, 0.42)';
            else if (ann.color === 'purple') fill = 'rgba(233, 213, 255, 0.42)';
            else if (ann.color === 'rose') fill = 'rgba(254, 205, 211, 0.42)';

            ctx.fillStyle = fill;

            for (const r of rects) {
              const rx = r.x * canvas.width;
              const ry = r.y * canvas.height;
              const rw = r.width * canvas.width;
              const rh = r.height * canvas.height;

              ctx.fillRect(rx, ry, rw, rh);

              if (isTarget) {
                // Focus flash border on Canvas
                ctx.strokeStyle = '#0d9488';
                ctx.lineWidth = Math.max(3, 4 * (zoomScale || 1));
                ctx.strokeRect(rx, ry, rw, rh);
              }
            }
          }
          ctx.restore();
        }
      } catch (err) {
        console.warn('Error rendering canvas page:', err);
      }
    }

    renderPage();
    return () => {
      isCurrent = false;
    };
  }, [currentPage, zoomScale, viewMode, localAnnotations, activeTargetAnnotationId]);

  // Auto-scroll to citation target if highlightText or targetAnnotationId is provided with subtle flash glow
  useEffect(() => {
    if (highlightText || targetAnnotationId) {
      setIsFlashActive(true);
      const timer = setTimeout(() => {
        const target =
          document.getElementById('target-citation-quote') ||
          (targetAnnotationId ? document.getElementById(`ann-mark-${targetAnnotationId}`) : null);
        if (target) {
          target.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      }, 350);

      const flashTimer = setTimeout(() => {
        setIsFlashActive(false);
      }, 4000);

      return () => {
        clearTimeout(timer);
        clearTimeout(flashTimer);
      };
    }
  }, [highlightText, targetAnnotationId, currentPage, viewMode]);

  // Current page item
  const currentPageItem = useMemo(() => {
    return documentPages.find((p) => p.pageNumber === currentPage) || documentPages[0] || { pageNumber: 1, text: '' };
  }, [documentPages, currentPage]);

  // In-Document Search Matches
  const searchMatches = useMemo(() => {
    if (!inDocSearchTerm.trim()) return [];
    const term = inDocSearchTerm.trim().toLowerCase();
    const matches: Array<{ pageNumber: number; start: number; length: number; snippet: string }> = [];

    documentPages.forEach((page) => {
      const pageText = page.text;
      const lower = pageText.toLowerCase();
      let pos = lower.indexOf(term);
      while (pos !== -1) {
        const snippetStart = Math.max(0, pos - 25);
        const snippetEnd = Math.min(pageText.length, pos + term.length + 25);
        matches.push({
          pageNumber: page.pageNumber,
          start: pos,
          length: term.length,
          snippet: pageText.slice(snippetStart, snippetEnd),
        });
        pos = lower.indexOf(term, pos + 1);
      }
    });

    return matches;
  }, [documentPages, inDocSearchTerm]);

  const handleNextSearchMatch = () => {
    if (searchMatches.length === 0) return;
    const nextIdx = (activeSearchMatchIdx + 1) % searchMatches.length;
    setActiveSearchMatchIdx(nextIdx);
    const target = searchMatches[nextIdx];
    if (target.pageNumber !== currentPage) {
      setCurrentPage(target.pageNumber);
    }
    setTimeout(() => {
      const el = document.getElementById(`search-match-${nextIdx}`);
      el?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }, 150);
  };

  const handlePrevSearchMatch = () => {
    if (searchMatches.length === 0) return;
    const prevIdx = (activeSearchMatchIdx - 1 + searchMatches.length) % searchMatches.length;
    setActiveSearchMatchIdx(prevIdx);
    const target = searchMatches[prevIdx];
    if (target.pageNumber !== currentPage) {
      setCurrentPage(target.pageNumber);
    }
    setTimeout(() => {
      const el = document.getElementById(`search-match-${prevIdx}`);
      el?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }, 150);
  };

  // Intelligent Screen-Boundary and Layout-Aware Positioning
  const computeToolbarPosition = useCallback((range: Range): SelectionToolbarPosition | null => {
    let rect = range.getBoundingClientRect();
    if (rect.width === 0 && rect.height === 0) {
      const rects = range.getClientRects();
      if (rects.length > 0) {
        rect = rects[0];
      } else {
        return null;
      }
    }

    const viewportWidth = window.innerWidth;
    const viewportHeight = window.innerHeight;
    const isMobile = viewportWidth < 1024;

    // Strict Safe Margins
    const MIN_TOP = 68; // Space below top application & annotator header
    const bottomReserve = isMobile ? 76 : 24; // Never get hidden behind mobile bottom navigation bar (z-40)
    const MAX_BOTTOM = viewportHeight - bottomReserve;

    const toolbarWidth = Math.min(410, viewportWidth - 20);
    const toolbarHeight = 46;

    const spaceAbove = rect.top - MIN_TOP;
    const spaceBelow = MAX_BOTTOM - rect.bottom;

    let top: number;
    let placement: 'top' | 'bottom';

    if (spaceAbove >= toolbarHeight + 10) {
      // Comfortably place above the selection
      top = rect.top - toolbarHeight - 8;
      placement = 'top';
    } else if (spaceBelow >= toolbarHeight + 10) {
      // Not enough room above; place below selection
      top = rect.bottom + 8;
      placement = 'bottom';
    } else {
      // Constrained viewport: clamp safely within visible area without overflowing screen
      if (rect.top > MIN_TOP + 12) {
        top = Math.max(MIN_TOP, rect.top - toolbarHeight - 4);
        placement = 'top';
      } else {
        top = Math.min(MAX_BOTTOM - toolbarHeight, rect.bottom + 4);
        placement = 'bottom';
      }
    }

    // Horizontal centering & screen clamping (Safe for Arabic RTL and LTR)
    const selCenterX = rect.left + rect.width / 2;
    let left = selCenterX - toolbarWidth / 2;
    const MIN_LEFT = 10;
    const MAX_LEFT = viewportWidth - toolbarWidth - 10;
    left = Math.max(MIN_LEFT, Math.min(MAX_LEFT, left));

    return { top, left, width: toolbarWidth, placement };
  }, []);

  // Real-time synchronization of toolbar position during scrolling, resizing, or orientation change
  useEffect(() => {
    const handleUpdatePosition = () => {
      const selection = window.getSelection();
      if (!selection || selection.isCollapsed || selection.rangeCount === 0) {
        return;
      }
      try {
        const range = selection.getRangeAt(0);
        const pos = computeToolbarPosition(range);
        if (pos) {
          setToolbarPosition(pos);
        }
      } catch {
        // ignore if range detached
      }
    };

    window.addEventListener('scroll', handleUpdatePosition, true);
    window.addEventListener('resize', handleUpdatePosition);
    window.addEventListener('orientationchange', handleUpdatePosition);

    return () => {
      window.removeEventListener('scroll', handleUpdatePosition, true);
      window.removeEventListener('resize', handleUpdatePosition);
      window.removeEventListener('orientationchange', handleUpdatePosition);
    };
  }, [computeToolbarPosition]);

  // Robust Text Selection Handler
  const handleTextSelection = useCallback(() => {
    setTimeout(() => {
      const selection = window.getSelection();
      if (!selection || selection.isCollapsed) {
        return;
      }

      const text = selection.toString().trim();
      if (text.length < 2) {
        return;
      }

      setSelectedText(text);

      // Determine page and context if possible
      let pageNum = currentPage;
      let startIdx: number | undefined;
      let endIdx: number | undefined;
      let prefix: string | undefined;
      let suffix: string | undefined;

      try {
        const range = selection.getRangeAt(0);

        // Check if selection happened inside a specific page element and compute normalized coordinates
        let pageEl: HTMLElement | null = null;
        let node: Node | null = range.commonAncestorContainer;
        while (node && node !== document.body) {
          if (node instanceof HTMLElement) {
            if (node.dataset.pageNumber) {
              pageNum = parseInt(node.dataset.pageNumber, 10);
              pageEl = node;
              break;
            }
            if (!pageEl && (node.classList.contains('select-text') || node.getAttribute('role') === 'region')) {
              pageEl = node;
            }
          }
          node = node.parentNode;
        }

        let normalizedRects: AnnotationRect[] | undefined;
        let normalizedBounding: AnnotationRect | undefined;

        if (pageEl) {
          const pRect = pageEl.getBoundingClientRect();
          if (pRect.width > 0 && pRect.height > 0) {
            const rawRects = Array.from(range.getClientRects());
            normalizedRects = rawRects.map((r) => ({
              x: Math.max(0, Math.min(1, (r.left - pRect.left) / pRect.width)),
              y: Math.max(0, Math.min(1, (r.top - pRect.top) / pRect.height)),
              width: Math.max(0, Math.min(1, r.width / pRect.width)),
              height: Math.max(0, Math.min(1, r.height / pRect.height)),
              pageNumber: pageNum,
            }));

            const bRect = range.getBoundingClientRect();
            normalizedBounding = {
              x: Math.max(0, Math.min(1, (bRect.left - pRect.left) / pRect.width)),
              y: Math.max(0, Math.min(1, (bRect.top - pRect.top) / pRect.height)),
              width: Math.max(0, Math.min(1, bRect.width / pRect.width)),
              height: Math.max(0, Math.min(1, bRect.height / pRect.height)),
              pageNumber: pageNum,
            };
          }
        }

        let paragraphIndex: number | undefined;
        let paragraphText: string | undefined;

        // Compute prefix & suffix context from current page
        const targetPage = documentPages.find((p) => p.pageNumber === pageNum) || currentPageItem;
        if (targetPage) {
          const directPos = targetPage.text.indexOf(text);
          if (directPos !== -1) {
            startIdx = directPos;
            endIdx = directPos + text.length;
            prefix = targetPage.text.slice(Math.max(0, directPos - 25), directPos);
            suffix = targetPage.text.slice(endIdx, Math.min(targetPage.text.length, endIdx + 25));
          } else {
            // Intelligent fuzzy alignment using Arabic normalized index mapper
            const matched = findAnnotationOffsetsInText(targetPage.text, {
              id: 'temp_sel',
              sourceId: source.id,
              pageNumber: pageNum,
              selectedText: text,
              color: 'yellow',
              createdAt: 0,
            });
            if (matched) {
              startIdx = matched.start;
              endIdx = matched.end;
              prefix = targetPage.text.slice(Math.max(0, matched.start - 25), matched.start);
              suffix = targetPage.text.slice(matched.end, Math.min(targetPage.text.length, matched.end + 25));
            }
          }

          // Detect containing paragraph
          const paras = targetPage.text.split(/\n\s*\n/);
          const pIdx = paras.findIndex((p) => p.includes(text));
          if (pIdx !== -1) {
            paragraphIndex = pIdx + 1;
            paragraphText = paras[pIdx].slice(0, 200).trim();
          }
        }

        // Match against database chunk
        const matchedChunk = chunks && chunks.length > 0 ? findMatchingChunk(chunks, text, pageNum) : undefined;

        setSelectionOffsets({
          pageNumber: pageNum,
          start: startIdx,
          end: endIdx,
          prefix,
          suffix,
          rects: normalizedRects,
          boundingRect: normalizedBounding,
          chunkId: matchedChunk?.id,
          paragraphIndex,
          paragraphText,
        });

        // Smart coordinates for floating toolbar
        const pos = computeToolbarPosition(range);
        if (pos) {
          setToolbarPosition(pos);
        }
      } catch {
        const fallbackWidth = Math.min(400, window.innerWidth - 20);
        setToolbarPosition({
          top: 140,
          left: (window.innerWidth - fallbackWidth) / 2,
          width: fallbackWidth,
          placement: 'top',
        });
      }
    }, 50);
  }, [currentPage, documentPages, computeToolbarPosition, chunks, source.id, currentPageItem]);

  // Quick Highlight Action (0ms latency, bulletproof)
  const handleQuickHighlight = (color: HighlightColor) => {
    if (!selectedText.trim()) return;

    const targetPage = selectionOffsets?.pageNumber || currentPage;
    const newAnn: SourceAnnotation = {
      id: `ann_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      sourceId: source.id,
      sourceTitle: source.title,
      pageNumber: targetPage,
      selectedText: selectedText.trim(),
      color: color,
      startIndex: selectionOffsets?.start,
      endIndex: selectionOffsets?.end,
      prefix: selectionOffsets?.prefix,
      suffix: selectionOffsets?.suffix,
      createdAt: Date.now(),
      rects: selectionOffsets?.rects,
      boundingRect: selectionOffsets?.boundingRect,
      chunkId: selectionOffsets?.chunkId,
      paragraphIndex: selectionOffsets?.paragraphIndex,
      paragraphText: selectionOffsets?.paragraphText,
    };

    const updated = [newAnn, ...localAnnotations];
    syncAnnotations(updated);
    showToast('تم حفظ التظليل وإحداثياته بنجاح');

    setSelectedText('');
    setToolbarPosition(null);
    setSelectionOffsets(null);
    window.getSelection()?.removeAllRanges();
  };

  // Open Add Note Modal
  const handleOpenAddNote = (color: HighlightColor) => {
    if (!selectedText.trim()) return;

    const targetPage = selectionOffsets?.pageNumber || currentPage;
    setPendingAnnotation({
      id: `ann_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      sourceId: source.id,
      sourceTitle: source.title,
      pageNumber: targetPage,
      selectedText: selectedText.trim(),
      color: color,
      startIndex: selectionOffsets?.start,
      endIndex: selectionOffsets?.end,
      prefix: selectionOffsets?.prefix,
      suffix: selectionOffsets?.suffix,
      createdAt: Date.now(),
      rects: selectionOffsets?.rects,
      boundingRect: selectionOffsets?.boundingRect,
      chunkId: selectionOffsets?.chunkId,
      paragraphIndex: selectionOffsets?.paragraphIndex,
      paragraphText: selectionOffsets?.paragraphText,
    });
    setNoteInputText('');
    setIsNoteModalOpen(true);
    setToolbarPosition(null);
  };

  // Save Note from Modal
  const handleSavePendingNote = () => {
    if (!pendingAnnotation || !pendingAnnotation.selectedText) return;

    const newAnn: SourceAnnotation = {
      id: pendingAnnotation.id || `ann_${Date.now()}`,
      sourceId: source.id,
      sourceTitle: source.title,
      pageNumber: pendingAnnotation.pageNumber || currentPage,
      selectedText: pendingAnnotation.selectedText,
      note: noteInputText.trim() || undefined,
      color: pendingAnnotation.color || activeColor,
      startIndex: pendingAnnotation.startIndex,
      endIndex: pendingAnnotation.endIndex,
      prefix: pendingAnnotation.prefix,
      suffix: pendingAnnotation.suffix,
      createdAt: Date.now(),
      rects: pendingAnnotation.rects,
      boundingRect: pendingAnnotation.boundingRect,
      chunkId: pendingAnnotation.chunkId,
      paragraphIndex: pendingAnnotation.paragraphIndex,
      paragraphText: pendingAnnotation.paragraphText,
    };

    const updated = [newAnn, ...localAnnotations];
    syncAnnotations(updated);
    showToast(newAnn.note ? 'تم حفظ التظليل والتعليق' : 'تم حفظ التظليل');

    setIsNoteModalOpen(false);
    setPendingAnnotation(null);
    setNoteInputText('');
    setSelectedText('');
    setSelectionOffsets(null);
    window.getSelection()?.removeAllRanges();
  };

  const handleUpdateAnnotationNote = (annId: string, note: string) => {
    const updated = localAnnotations.map((a) =>
      a.id === annId ? { ...a, note: note || undefined, updatedAt: Date.now() } : a
    );
    syncAnnotations(updated);
    showToast('تم تحديث الملاحظة الدراسية');
  };

  // Update existing annotation note or color
  const handleUpdateAnnotationColor = (annId: string, color: HighlightColor) => {
    const updated = localAnnotations.map((a) =>
      a.id === annId ? { ...a, color, updatedAt: Date.now() } : a
    );
    syncAnnotations(updated);
    if (activePopoverHighlight?.annotation.id === annId) {
      setActivePopoverHighlight((prev) =>
        prev ? { ...prev, annotation: { ...prev.annotation, color } } : null
      );
    }
  };

  const handleDeleteAnnotation = (annId: string) => {
    const updated = localAnnotations.filter((a) => a.id !== annId);
    syncAnnotations(updated);
    setActivePopoverHighlight(null);
    showToast('تم حذف التظليل');
  };

  // Copy with academic citation
  const handleCopyWithCitation = (textToCopy: string, pageNum: number) => {
    const citation = `«${textToCopy}»\n— [المصدر: ${source.title}، ص ${pageNum}]`;
    navigator.clipboard.writeText(citation);
    showToast('تم نسخ الاقتباس مع التوثيق المرجعي');
    setSelectedText('');
    setToolbarPosition(null);
  };

  // Export quote to student notebook note
  const handleExportQuoteToNotebook = (textToExport: string, pageNum: number) => {
    if (onExportToNote) {
      const noteTitle = `اقتباس: ${textToExport.slice(0, 45)}...`;
      const noteContent = `### توثيق من المصدر: ${source.title} (ص ${pageNum})\n\n> «${textToExport}»\n\n**تاريخ التدوين:** ${new Date().toLocaleDateString('ar-EG')}`;
      onExportToNote(noteTitle, noteContent);
      showToast('تم إنشاء بطاقة ملاحظة جديدة في الدفتر');
      setSelectedText('');
      setToolbarPosition(null);
    }
  };

  // Export all annotations to Markdown
  const handleExportAllMarkdown = () => {
    if (localAnnotations.length === 0) {
      showToast('لا توجد تظليلات في هذا المصدر');
      return;
    }

    let md = `# ملخص تظليلات وملاحظات المصدر: ${source.title}\n\n`;
    md += `*تم الاستخراج من منصة المعلم الذكي — إجمالي التظليلات: ${localAnnotations.length}*\n\n---\n\n`;

    const sorted = [...localAnnotations].sort((a, b) => a.pageNumber - b.pageNumber);
    sorted.forEach((ann, idx) => {
      const colorName = COLOR_MAP[ann.color]?.name || 'تظليل';
      md += `### ${idx + 1}. [صفحة ${ann.pageNumber}] (${colorName})\n`;
      md += `> «${ann.selectedText}»\n\n`;
      if (ann.note) {
        md += `💬 **الملاحظة الشخصية:** ${ann.note}\n\n`;
      }
      md += `---\n\n`;
    });

    navigator.clipboard.writeText(md);
    showToast('تم نسخ ملخص التظليلات كملف دراسي Markdown');
  };

  // Theme styles helper with High Contrast accessibility modes
  const getThemeClasses = () => {
    switch (readingTheme) {
      case 'contrast-dark':
        // High Contrast Pitch Black & White (Low Vision & Eye Strain)
        return {
          wrapper: 'bg-black text-white',
          page: 'bg-black border-2 border-neutral-700 shadow-none',
          topbar: 'bg-neutral-950 border-b border-neutral-700 text-white',
          sidebar: 'bg-neutral-950 border-r border-neutral-700 text-white',
        };
      case 'contrast-light':
        // High Contrast Pure White & Deep Black
        return {
          wrapper: 'bg-white text-black font-semibold',
          page: 'bg-white border-2 border-black shadow-none',
          topbar: 'bg-neutral-100 border-b-2 border-black text-black',
          sidebar: 'bg-neutral-100 border-r-2 border-black text-black',
        };
      case 'contrast-yellow':
        // High Contrast Vivid Yellow on Black (Low Vision / Accessible Standard)
        return {
          wrapper: 'bg-black text-yellow-300 font-bold',
          page: 'bg-black border-2 border-yellow-500 shadow-none',
          topbar: 'bg-neutral-950 border-b border-yellow-700 text-yellow-300',
          sidebar: 'bg-neutral-950 border-r border-yellow-700 text-yellow-300',
        };
      case 'sepia':
        return {
          wrapper: 'bg-[#fcf6e9] dark:bg-[#251e18] text-[#3e2c1c] dark:text-[#f3e5d8]',
          page: 'bg-[#fdfaf3] dark:bg-[#2e261f] border-[#ebdcc4] dark:border-[#45382e] shadow-sm',
          topbar: 'bg-[#f7eedb] dark:bg-[#221b15] border-[#ebdcc4] dark:border-[#45382e]',
          sidebar: 'bg-[#fdfaf3] dark:bg-[#2a221b] border-[#ebdcc4] dark:border-[#45382e]',
        };
      case 'dark':
        return {
          wrapper: 'bg-[#0f1412] text-[#dce7e3]',
          page: 'bg-[#151c19] border-[#22312b] shadow-sm',
          topbar: 'bg-[#131a17] border-[#22312b]',
          sidebar: 'bg-[#151c19] border-[#22312b]',
        };
      case 'mint':
        return {
          wrapper: 'bg-[#f0f7f4] dark:bg-[#111f1b] text-[#1b342e] dark:text-[#d3eae3]',
          page: 'bg-white dark:bg-[#162722] border-[#cfe2db] dark:border-[#263e37] shadow-sm',
          topbar: 'bg-[#e4f1ec] dark:bg-[#14231f] border-[#cfe2db] dark:border-[#263e37]',
          sidebar: 'bg-white dark:bg-[#162722] border-[#cfe2db] dark:border-[#263e37]',
        };
      case 'paper':
      default:
        return {
          wrapper: 'bg-[#f8faf9] dark:bg-[#101715] text-[#1a2622] dark:text-[#eef7f4]',
          page: 'bg-white dark:bg-[#14201c] border-[#e2e8e5] dark:border-[#22352f] shadow-sm',
          topbar: 'bg-white dark:bg-[#14201c] border-[#e2e8e5] dark:border-[#22352f]',
          sidebar: 'bg-white dark:bg-[#14201c] border-[#e2e8e5] dark:border-[#22352f]',
        };
    }
  };

  const themeClasses = getThemeClasses();

  // Line Height multiplier for reading accessibility
  const lineHeightValue = useMemo(() => {
    switch (lineHeight) {
      case 'compact':
        return 1.5;
      case 'standard':
        return 1.9;
      case 'relaxed':
        return 2.3;
      case 'accessible':
        return 2.7;
    }
  }, [lineHeight]);

  // Helper to render page text with interactive highlights and search markers
  const renderInteractivePageText = (page: { pageNumber: number; text: string }) => {
    const rawText = page.text;
    if (!rawText || !rawText.trim()) {
      return (
        <div className="py-12 text-center text-gray-400 italic">
          لا يوجد نص متاح لهذه الصفحة.
        </div>
      );
    }

    // 1. Gather all highlight ranges for this page
    const ranges: MatchedRange[] = [];

    // User Annotations for this page
    const pageAnns = localAnnotations.filter((a) => a.pageNumber === page.pageNumber);
    pageAnns.forEach((ann) => {
      const offsets = findAnnotationOffsetsInText(rawText, ann);
      if (offsets && offsets.start < offsets.end) {
        ranges.push({
          start: offsets.start,
          end: offsets.end,
          annotation: ann,
        });
      }
    });

    // Also check for orphan annotations whose pageNumber was omitted or shifted
    const unplacedAnns = localAnnotations.filter(
      (a) => a.pageNumber !== page.pageNumber && !ranges.some((r) => r.annotation?.id === a.id)
    );
    unplacedAnns.forEach((ann) => {
      if (ann.selectedText && ann.selectedText.length >= 6) {
        const offsets = findAnnotationOffsetsInText(rawText, ann);
        if (offsets && offsets.start < offsets.end) {
          ranges.push({
            start: offsets.start,
            end: offsets.end,
            annotation: ann,
          });
        }
      }
    });

    // Citation Target from AI (Source Linker)
    if (highlightText && page.pageNumber === currentPage) {
      const cleanTarget = highlightText
        .replace(/^["'«“\s\.\…]+/, '')
        .replace(/["'»”\s\.\…]+$/, '')
        .trim();

      if (cleanTarget.length >= 5) {
        const targetOffsets = findAnnotationOffsetsInText(rawText, {
          id: 'citation_target',
          sourceId: source.id,
          pageNumber: page.pageNumber,
          selectedText: cleanTarget,
          color: 'yellow',
          createdAt: 0,
        });

        if (targetOffsets) {
          ranges.push({
            start: targetOffsets.start,
            end: targetOffsets.end,
            isCitationTarget: true,
          });
        }
      }
    }

    // In-Document Search Matches for this page
    if (inDocSearchTerm.trim()) {
      searchMatches.forEach((match, idx) => {
        if (match.pageNumber === page.pageNumber) {
          ranges.push({
            start: match.start,
            end: match.start + match.length,
            isSearchMatch: true,
            searchMatchIndex: idx,
          });
        }
      });
    }

    if (ranges.length === 0) {
      return <span>{rawText}</span>;
    }

    // 2. Sort and segment non-overlapping intervals
    ranges.sort((a, b) => a.start - b.start);

    const elements: React.ReactNode[] = [];
    let lastIndex = 0;

    ranges.forEach((range, idx) => {
      if (range.start < lastIndex) {
        // Skip overlapping slice to prevent malformed tags
        return;
      }

      if (range.start > lastIndex) {
        elements.push(
          <span key={`plain-${page.pageNumber}-${lastIndex}`}>
            {rawText.slice(lastIndex, range.start)}
          </span>
        );
      }

      const sliceText = rawText.slice(range.start, range.end);

      if (range.isCitationTarget) {
        elements.push(
          <mark
            key={`citation-${idx}`}
            id="target-citation-quote"
            className={`font-bold px-2 py-1 rounded-lg border inline mx-0.5 transition-all duration-500 scroll-mt-28 ${
              isFlashActive
                ? 'bg-amber-300 dark:bg-amber-400/50 text-amber-950 dark:text-white border-teal-500 ring-4 ring-teal-400/80 shadow-lg animate-pulse scale-[1.01]'
                : 'bg-amber-200/90 dark:bg-amber-500/30 text-amber-950 dark:text-amber-100 border-amber-400 ring-1 ring-amber-400/40'
            }`}
            title="✦ المرجع المقتبس المعتمد في إجابة المعلم الذكي (وميض التركيز)"
          >
            <span className="inline-flex items-center gap-1 text-[10px] bg-teal-700 text-white font-mono px-1.5 py-0.5 rounded-md ml-1.5 align-middle shadow-2xs font-bold">
              <Sparkles className="w-3 h-3 text-amber-300 inline" />
              <span>اقتباس موثق</span>
            </span>
            {sliceText}
          </mark>
        );
      } else if (range.isSearchMatch) {
        const isCurrentActive = range.searchMatchIndex === activeSearchMatchIdx;
        elements.push(
          <mark
            key={`search-${idx}`}
            id={`search-match-${range.searchMatchIndex}`}
            className={`px-1 py-0.5 rounded-xs transition-colors inline mx-0.5 ${
              isCurrentActive
                ? 'bg-orange-400 text-black font-extrabold ring-2 ring-orange-600 shadow-md'
                : 'bg-yellow-300 dark:bg-yellow-500/50 text-black dark:text-white'
            }`}
          >
            {sliceText}
          </mark>
        );
      } else if (range.annotation) {
        const ann = range.annotation;
        const colorCfg = COLOR_MAP[ann.color] || COLOR_MAP.yellow;
        const isActiveTarget = ann.id === activeTargetAnnotationId;

        elements.push(
          <mark
            key={`ann-${ann.id}-${idx}`}
            id={`ann-mark-${ann.id}`}
            className={`relative px-1.5 py-0.5 rounded-md font-medium transition-all ${colorCfg.highlightClass} ${
              isActiveTarget && isFlashActive
                ? 'ring-4 ring-teal-500 shadow-md animate-pulse scale-[1.01]'
                : ''
            } cursor-pointer inline mx-0.5 group`}
            title={ann.note ? `ملاحظة: ${ann.note}` : 'نص مضلل (انقر للخيارات والتعليق)'}
            onClick={(e) => {
              e.stopPropagation();
              const rect = e.currentTarget.getBoundingClientRect();
              setActivePopoverHighlight({
                annotation: ann,
                position: {
                  x: Math.min(window.innerWidth - 180, Math.max(160, rect.left + rect.width / 2)),
                  y: rect.bottom + 8,
                },
              });
            }}
          >
            {sliceText}
            {ann.note && (
              <span className="inline-flex items-center justify-center mr-1 w-3.5 h-3.5 rounded-full bg-[#0f766e] text-white text-[9px] align-middle shadow-xs">
                💬
              </span>
            )}
          </mark>
        );
      }

      lastIndex = range.end;
    });

    if (lastIndex < rawText.length) {
      elements.push(
        <span key={`plain-end-${page.pageNumber}-${lastIndex}`}>
          {rawText.slice(lastIndex)}
        </span>
      );
    }

    return elements;
  };

  return (
    <div
      className={`flex flex-col h-full rounded-2xl border transition-colors relative shadow-sm overflow-hidden select-text ${themeClasses.wrapper} ${fontFamily}`}
      style={{ fontSize: `${fontSize}px` }}
    >
      {/* Toast Notification */}
      {toastMessage && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-50 bg-[#17201e] text-white dark:bg-[#eef7f4] dark:text-[#17201e] text-xs font-bold px-4 py-2 rounded-full shadow-xl flex items-center gap-2 animate-in fade-in slide-in-from-top-3 duration-200">
          <Check className="w-3.5 h-3.5 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Header Bar */}
      <div className={`px-3 py-2.5 border-b flex flex-wrap items-center justify-between gap-2.5 shrink-0 z-20 ${themeClasses.topbar}`}>
        {/* Source Title & Meta */}
        <div className="flex items-center gap-2.5 truncate max-w-sm sm:max-w-md">
          <div className="w-8 h-8 rounded-xl bg-teal-50 dark:bg-teal-950/60 text-[#0f766e] dark:text-[#2dd4bf] flex items-center justify-center shrink-0 border border-teal-200/60 dark:border-teal-800">
            <BookOpen className="w-4 h-4" />
          </div>
          <div className="truncate">
            <h3 className="font-bold text-xs sm:text-sm truncate">
              {source.title}
            </h3>
            <div className="flex items-center gap-2 text-[11px] opacity-75">
              <span className="font-semibold text-[#0f766e] dark:text-[#2dd4bf]">
                {localAnnotations.length} تظليل وملاحظة
              </span>
              <span>•</span>
              <span>
                {layoutMode === 'paginated'
                  ? `صفحة ${currentPage} من ${totalPages}`
                  : `سرد مستمر (${totalPages} ص)`}
              </span>
            </div>
          </div>
        </div>

        {/* Central Controls: Navigation, Modes, Search */}
        <div className="flex items-center gap-1.5 flex-wrap">
          {/* Page Flip Navigation */}
          {layoutMode === 'paginated' && (
            <div className="flex items-center bg-black/5 dark:bg-white/5 rounded-xl border border-black/10 dark:border-white/10 p-0.5 text-xs">
              <button
                type="button"
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                disabled={currentPage <= 1}
                className="p-1 rounded-lg hover:bg-black/5 dark:hover:bg-white/10 disabled:opacity-30 cursor-pointer"
                title="الصفحة السابقة (السهم الأيمن)"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
              <div className="px-2 font-bold flex items-center gap-1">
                <input
                  type="number"
                  min={1}
                  max={totalPages}
                  value={currentPage}
                  onChange={(e) => {
                    const val = parseInt(e.target.value, 10);
                    if (!isNaN(val)) setCurrentPage(Math.min(totalPages, Math.max(1, val)));
                  }}
                  className="w-9 text-center py-0.5 bg-white dark:bg-black/30 border border-black/10 dark:border-white/10 rounded font-bold text-[#0f766e] dark:text-[#2dd4bf] text-xs"
                />
                <span className="opacity-70">/ {totalPages}</span>
              </div>
              <button
                type="button"
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                disabled={currentPage >= totalPages}
                className="p-1 rounded-lg hover:bg-black/5 dark:hover:bg-white/10 disabled:opacity-30 cursor-pointer"
                title="الصفحة التالية (السهم الأيسر)"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Reading Mode Switch: Text vs Original PDF Canvas */}
          {hasCanvasSupport && (
            <div className="flex bg-black/5 dark:bg-white/5 rounded-xl border border-black/10 dark:border-white/10 p-0.5 text-xs font-bold">
              <button
                type="button"
                onClick={() => setViewMode('text')}
                className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                  viewMode === 'text'
                    ? 'bg-white dark:bg-black/40 text-[#0f766e] dark:text-[#2dd4bf] shadow-xs'
                    : 'opacity-70 hover:opacity-100'
                }`}
              >
                القارئ الذكي
              </button>
              <button
                type="button"
                onClick={() => setViewMode('canvas')}
                className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                  viewMode === 'canvas'
                    ? 'bg-white dark:bg-black/40 text-[#0f766e] dark:text-[#2dd4bf] shadow-xs'
                    : 'opacity-70 hover:opacity-100'
                }`}
              >
                الصفحة الأصلية
              </button>
            </div>
          )}

          {/* Paginated vs Continuous toggle */}
          {viewMode === 'text' && totalPages > 1 && (
            <button
              type="button"
              onClick={() => setLayoutMode(layoutMode === 'paginated' ? 'continuous' : 'paginated')}
              className="hidden md:flex px-2 py-1 bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 rounded-xl text-xs font-bold items-center gap-1 border border-black/10 dark:border-white/10 transition-colors cursor-pointer"
              title={layoutMode === 'paginated' ? 'التبديل إلى سرد القراءة المستمر' : 'التبديل إلى القراءة بالصفحات'}
            >
              <Layers className="w-3.5 h-3.5 text-[#0f766e] dark:text-[#2dd4bf]" />
              <span>{layoutMode === 'paginated' ? 'بالصفحات' : 'سرد مستمر'}</span>
            </button>
          )}

          {/* Search in Document Toggle */}
          <button
            type="button"
            onClick={() => {
              setIsSearchOpen(!isSearchOpen);
              if (!isSearchOpen) setTimeout(() => document.getElementById('in-doc-search-input')?.focus(), 100);
            }}
            className={`p-1.5 rounded-xl border transition-colors cursor-pointer ${
              isSearchOpen || inDocSearchTerm
                ? 'bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-200 border-amber-300 dark:border-amber-700'
                : 'bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 border-black/10 dark:border-white/10'
            }`}
            title="بحث فوري داخل نص المصدر"
          >
            <Search className="w-4 h-4" />
          </button>

          {/* Font Size Adjuster */}
          {viewMode === 'text' && (
            <div className="flex items-center bg-black/5 dark:bg-white/5 rounded-xl border border-black/10 dark:border-white/10 p-0.5 text-xs">
              <button
                type="button"
                onClick={() => setFontSize((s) => Math.max(13, s - 1))}
                className="px-1.5 py-0.5 hover:bg-black/5 dark:hover:bg-white/10 rounded font-bold cursor-pointer"
                title="تصغير حجم الخط"
              >
                A-
              </button>
              <span className="px-1 text-[11px] font-mono opacity-80">{fontSize}</span>
              <button
                type="button"
                onClick={() => setFontSize((s) => Math.min(28, s + 1))}
                className="px-1.5 py-0.5 hover:bg-black/5 dark:hover:bg-white/10 rounded font-bold cursor-pointer"
                title="تكبير حجم الخط"
              >
                A+
              </button>
            </div>
          )}

          {/* Line Height Adjuster for Accessibility */}
          {viewMode === 'text' && (
            <button
              type="button"
              onClick={() => {
                const heights: Array<'compact' | 'standard' | 'relaxed' | 'accessible'> = ['compact', 'standard', 'relaxed', 'accessible'];
                const nextIdx = (heights.indexOf(lineHeight) + 1) % heights.length;
                setLineHeight(heights[nextIdx]);
              }}
              className="hidden sm:flex px-2 py-1 bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 rounded-xl text-xs font-bold items-center gap-1 border border-black/10 dark:border-white/10 transition-colors cursor-pointer"
              title="تعديل تباعد الأسطر (Line Height)"
            >
              <Type className="w-3.5 h-3.5 text-[#0f766e] dark:text-[#2dd4bf]" />
              <span className="text-[11px]">
                {lineHeight === 'compact' ? '1.5x' : lineHeight === 'standard' ? '1.9x' : lineHeight === 'relaxed' ? '2.3x' : '2.7x'}
              </span>
            </button>
          )}

          {/* Theme Palette Selector with High Contrast */}
          <div className="hidden lg:flex items-center bg-black/5 dark:bg-white/5 rounded-xl border border-black/10 dark:border-white/10 p-0.5">
            <button
              type="button"
              onClick={() => setReadingTheme('paper')}
              className={`w-6 h-6 rounded-lg flex items-center justify-center text-[10px] font-bold cursor-pointer transition-transform ${
                readingTheme === 'paper' ? 'bg-white shadow-xs scale-105 border border-gray-300' : 'opacity-70'
              }`}
              title="نمط الورق الأكاديمي"
            >
              📄
            </button>
            <button
              type="button"
              onClick={() => setReadingTheme('sepia')}
              className={`w-6 h-6 rounded-lg flex items-center justify-center text-[10px] font-bold cursor-pointer transition-transform ${
                readingTheme === 'sepia' ? 'bg-[#f5e7ce] shadow-xs scale-105 border border-[#dfc69f]' : 'opacity-70'
              }`}
              title="نمط سيبيا دافئ"
            >
              📜
            </button>
            <button
              type="button"
              onClick={() => setReadingTheme('dark')}
              className={`w-6 h-6 rounded-lg flex items-center justify-center text-[10px] font-bold cursor-pointer transition-transform ${
                readingTheme === 'dark' ? 'bg-[#1b2521] text-white shadow-xs scale-105 border border-gray-700' : 'opacity-70'
              }`}
              title="نمط ليلي مريح"
            >
              🌙
            </button>
            <button
              type="button"
              onClick={() => setReadingTheme('contrast-dark')}
              className={`px-1.5 h-6 rounded-lg flex items-center justify-center text-[9px] font-black cursor-pointer transition-transform ${
                readingTheme === 'contrast-dark' ? 'bg-black text-white ring-2 ring-sky-400 scale-105' : 'bg-black text-neutral-300 border border-neutral-700'
              }`}
              title="تباين عالي (أسود حالك & أبيض)"
            >
              High-C
            </button>
            <button
              type="button"
              onClick={() => setReadingTheme('contrast-yellow')}
              className={`px-1.5 h-6 rounded-lg flex items-center justify-center text-[9px] font-black cursor-pointer transition-transform ${
                readingTheme === 'contrast-yellow' ? 'bg-black text-yellow-300 ring-2 ring-yellow-400 scale-105' : 'bg-black text-yellow-500 border border-yellow-800'
              }`}
              title="تباين عالي أصفر على أسود (ضعف البصر)"
            >
              Yellow
            </button>
          </div>
        </div>

        {/* Right Action Icons: Reader View, Workspace Mode Switcher, Fullscreen, Export, Close */}
        <div className="flex items-center gap-1.5">
          {/* Reader View Direct Button */}
          {onOpenReaderView && (
            <button
              type="button"
              onClick={onOpenReaderView}
              className="px-2.5 py-1 bg-[#0f766e] hover:bg-[#115e59] text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors shrink-0"
              title="فتح وضع القارئ المريح الخالي من التشتت والتباين العالي (Reader View)"
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">وضع القارئ</span>
            </button>
          )}
          {/* Responsive Workspace Layout Selector */}
          <div className="flex items-center bg-black/5 dark:bg-white/5 p-0.5 rounded-xl border border-black/10 dark:border-white/10 text-xs">
            <button
              type="button"
              onClick={() => setWorkspaceMode('doc-only')}
              className={`px-2.5 py-1 rounded-lg font-bold flex items-center gap-1 transition-all cursor-pointer ${
                workspaceMode === 'doc-only'
                  ? 'bg-white dark:bg-black/40 text-[#0f766e] dark:text-[#2dd4bf] shadow-xs'
                  : 'text-gray-600 dark:text-gray-400 hover:text-gray-900'
              }`}
              title="عرض المستند فقط"
            >
              <FileText className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">المستند</span>
            </button>

            <button
              type="button"
              onClick={() => setWorkspaceMode(workspaceMode === 'split' ? 'doc-only' : 'split')}
              className={`px-2.5 py-1 rounded-lg font-bold flex items-center gap-1 transition-all cursor-pointer ${
                workspaceMode === 'split'
                  ? 'bg-[#0f766e] text-white shadow-xs'
                  : 'text-gray-600 dark:text-gray-400 hover:text-gray-900'
              }`}
              title="مساحة عمل متزامنة: المستند والملاحظات معاً بدون أي حجب"
            >
              <Layers className="w-3.5 h-3.5" />
              <span>تقسيم ({localAnnotations.length})</span>
            </button>

            <button
              type="button"
              onClick={() => setWorkspaceMode(workspaceMode === 'notes-full' ? 'doc-only' : 'notes-full')}
              className={`px-2 py-1 rounded-lg font-bold flex items-center gap-1 transition-all cursor-pointer ${
                workspaceMode === 'notes-full'
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'text-gray-600 dark:text-gray-400 hover:text-gray-900'
              }`}
              title="عرض قائمة الملاحظات بالكامل"
            >
              <Bookmark className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">الملاحظات</span>
            </button>
          </div>

          {/* Export to Markdown */}
          <button
            type="button"
            onClick={handleExportAllMarkdown}
            className="p-1.5 rounded-xl bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 border border-black/10 dark:border-white/10 transition-colors cursor-pointer"
            title="نسخ ملخص التظليلات كتقرير دراسي"
          >
            <Download className="w-4 h-4" />
          </button>

          {/* Wide / Fullscreen Mode Toggle */}
          {onToggleWideMode && (
            <button
              type="button"
              onClick={onToggleWideMode}
              className="p-1.5 rounded-xl bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 border border-black/10 dark:border-white/10 transition-colors cursor-pointer"
              title={isWideMode ? 'تصغير العرض إلى العرض العادي' : 'توسيع القارئ إلى كامل الشاشة (وضع التركيز)'}
            >
              {isWideMode ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>
          )}

          {/* Close Reader */}
          {onClose && (
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-xl bg-black/5 dark:bg-white/5 hover:bg-red-500 hover:text-white border border-black/10 dark:border-white/10 text-gray-400 transition-colors cursor-pointer"
              title="إغلاق القارئ"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* In-Document Search Toolbar Banner */}
      {isSearchOpen && (
        <div className="bg-amber-50 dark:bg-amber-950/60 border-b border-amber-200 dark:border-amber-800/60 px-4 py-2 flex flex-wrap items-center justify-between gap-3 text-xs shrink-0 z-20">
          <div className="flex items-center gap-2 flex-1 max-w-md">
            <Search className="w-4 h-4 text-amber-700 dark:text-amber-300 shrink-0" />
            <input
              id="in-doc-search-input"
              type="text"
              placeholder="اكتب كلمة أو مصطلحاً للبحث الفوري في المصدر..."
              value={inDocSearchTerm}
              onChange={(e) => {
                setInDocSearchTerm(e.target.value);
                setActiveSearchMatchIdx(0);
              }}
              className="w-full bg-white dark:bg-black/40 border border-amber-300 dark:border-amber-700/60 rounded-xl px-3 py-1 text-xs text-[#17201e] dark:text-[#eef7f4] focus:outline-none focus:ring-1 focus:ring-amber-500"
            />
          </div>

          <div className="flex items-center gap-2">
            {inDocSearchTerm && (
              <span className="text-[11px] font-bold text-amber-900 dark:text-amber-200">
                {searchMatches.length > 0
                  ? `المطابقة ${activeSearchMatchIdx + 1} من ${searchMatches.length}`
                  : 'لا توجد مطابقة'}
              </span>
            )}
            <button
              type="button"
              onClick={handlePrevSearchMatch}
              disabled={searchMatches.length <= 1}
              className="p-1 bg-white dark:bg-black/40 border border-amber-300 dark:border-amber-700/60 rounded-lg hover:bg-amber-100 disabled:opacity-30 cursor-pointer"
              title="المطابقة السابقة"
            >
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={handleNextSearchMatch}
              disabled={searchMatches.length <= 1}
              className="p-1 bg-white dark:bg-black/40 border border-amber-300 dark:border-amber-700/60 rounded-lg hover:bg-amber-100 disabled:opacity-30 cursor-pointer"
              title="المطابقة التالية"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => {
                setInDocSearchTerm('');
                setIsSearchOpen(false);
              }}
              className="p-1 text-gray-400 hover:text-gray-600 cursor-pointer"
              title="إغلاق شريط البحث"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Unified Intelligent Selection Floating Toolbar (Desktop & Mobile, Screen-Boundary-Safe, Non-Obstructing) */}
      {selectedText && toolbarPosition && (
        <div
          role="toolbar"
          aria-label="شريط خيارات تظليل واقتباس النص"
          className="fixed z-[60] bg-white dark:bg-[#14201c] border border-gray-300 dark:border-gray-700 rounded-2xl shadow-2xl p-1.5 flex items-center justify-between gap-1 sm:gap-1.5 animate-in fade-in zoom-in-95 duration-150 backdrop-blur-md"
          style={{
            top: `${toolbarPosition.top}px`,
            left: `${toolbarPosition.left}px`,
            width: `${toolbarPosition.width}px`,
            maxWidth: 'calc(100vw - 20px)',
          }}
          onMouseDown={(e) => {
            // Prevent browser from collapsing text selection
            e.preventDefault();
            e.stopPropagation();
          }}
          onTouchStart={(e) => {
            // Prevent mobile tap from immediately dismissing selection
            e.stopPropagation();
          }}
        >
          {/* Color pickers */}
          <div className="flex items-center gap-1 pl-1.5 border-l border-gray-200 dark:border-gray-700 shrink-0">
            {(Object.keys(COLOR_MAP) as HighlightColor[]).map((c) => (
              <button
                key={c}
                type="button"
                onMouseDown={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                }}
                onClick={() => {
                  setActiveColor(c);
                  handleQuickHighlight(c);
                }}
                className={`w-5 h-5 sm:w-6 sm:h-6 rounded-full border-2 transition-transform hover:scale-110 flex items-center justify-center cursor-pointer shrink-0 ${
                  activeColor === c ? 'border-gray-900 dark:border-white scale-110' : 'border-transparent'
                }`}
                style={{ backgroundColor: COLOR_MAP[c].bg }}
                title={`تظليل بلون ${COLOR_MAP[c].name}`}
              >
                {activeColor === c && <Check className="w-3 h-3 text-gray-900" />}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-1 overflow-x-auto no-scrollbar py-0.5">
            {/* Quick Highlight Button */}
            <button
              type="button"
              onMouseDown={(e) => {
                e.preventDefault();
                e.stopPropagation();
              }}
              onClick={() => handleQuickHighlight(activeColor)}
              className="px-2 sm:px-2.5 py-1 rounded-xl bg-teal-50 dark:bg-teal-950/60 text-[#0f766e] dark:text-[#2dd4bf] hover:bg-[#0f766e] hover:text-white transition-colors text-xs font-bold flex items-center gap-1 whitespace-nowrap cursor-pointer shrink-0"
              title="تظليل النص المختار باللون الحالي"
            >
              <Highlighter className="w-3.5 h-3.5" />
              <span>تظليل</span>
            </button>

            {/* Add Note Button */}
            <button
              type="button"
              onMouseDown={(e) => {
                e.preventDefault();
                e.stopPropagation();
              }}
              onClick={() => handleOpenAddNote(activeColor)}
              className="px-2 sm:px-2.5 py-1 rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-800 dark:text-amber-200 hover:bg-amber-600 hover:text-white transition-colors text-xs font-bold flex items-center gap-1 whitespace-nowrap cursor-pointer shrink-0"
              title="إضافة ملاحظة أو شرح شخصي على النص"
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>ملاحظة</span>
            </button>

            {/* Ask AI about Quote */}
            {onAskAboutQuote && (
              <button
                type="button"
                onMouseDown={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                }}
                onClick={() => {
                  onAskAboutQuote(selectedText, selectionOffsets?.pageNumber || currentPage);
                  setSelectedText('');
                  setToolbarPosition(null);
                }}
                className="px-2 sm:px-2.5 py-1 rounded-xl bg-purple-50 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 hover:bg-purple-600 hover:text-white transition-colors text-xs font-bold flex items-center gap-1 whitespace-nowrap cursor-pointer shrink-0"
                title="طرح هذا الاقتباس على المعلم الذكي مباشرة"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">اسأل AI</span>
                <span className="sm:hidden">AI</span>
              </button>
            )}

            {/* Copy Quote with Citation */}
            <button
              type="button"
              onMouseDown={(e) => {
                e.preventDefault();
                e.stopPropagation();
              }}
              onClick={() => handleCopyWithCitation(selectedText, selectionOffsets?.pageNumber || currentPage)}
              className="p-1 sm:p-1.5 rounded-lg text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800 cursor-pointer shrink-0"
              title="نسخ مع توثيق المرجع"
            >
              <Copy className="w-3.5 h-3.5" />
            </button>

            {/* Save directly to student notebook notes */}
            {onExportToNote && (
              <button
                type="button"
                onMouseDown={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                }}
                onClick={() => handleExportQuoteToNotebook(selectedText, selectionOffsets?.pageNumber || currentPage)}
                className="p-1 sm:p-1.5 rounded-lg text-gray-500 hover:text-[#0f766e] hover:bg-teal-50 dark:hover:bg-teal-950/60 cursor-pointer shrink-0"
                title="حفظ في تدوينات الدفتر"
              >
                <FileText className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Dismiss */}
          <button
            type="button"
            onMouseDown={(e) => {
              e.preventDefault();
              e.stopPropagation();
            }}
            onClick={() => {
              setSelectedText('');
              setToolbarPosition(null);
            }}
            className="p-1 text-gray-400 hover:text-gray-600 cursor-pointer shrink-0"
            title="إغلاق شريط التحديد"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Clicked Highlight Popover (for quick edit, color change, notes) */}
      {activePopoverHighlight && (
        <div
          className="fixed z-50 transform -translate-x-1/2 bg-white dark:bg-[#14201c] border border-gray-300 dark:border-gray-700 rounded-2xl shadow-2xl p-3 w-72 flex flex-col gap-2 animate-in fade-in zoom-in-95 duration-150"
          style={{
            top: `${activePopoverHighlight.position.y}px`,
            left: `${activePopoverHighlight.position.x}px`,
          }}
          onClick={(e) => e.stopPropagation()}
        >
          <div className="flex items-center justify-between pb-1 border-b border-gray-100 dark:border-gray-800">
            <span className="text-[11px] font-bold text-[#0f766e] dark:text-[#2dd4bf] flex items-center gap-1">
              <Highlighter className="w-3 h-3" />
              <span>تعديل التظليل (ص {activePopoverHighlight.annotation.pageNumber})</span>
            </span>
            <button
              type="button"
              onClick={() => setActivePopoverHighlight(null)}
              className="p-0.5 text-gray-400 hover:text-gray-600 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Color Switcher */}
          <div className="flex items-center justify-between gap-1 py-1">
            <span className="text-[10px] text-gray-500">اللون:</span>
            <div className="flex items-center gap-1.5">
              {(Object.keys(COLOR_MAP) as HighlightColor[]).map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => handleUpdateAnnotationColor(activePopoverHighlight.annotation.id, c)}
                  className={`w-5 h-5 rounded-full border-2 transition-transform cursor-pointer ${
                    activePopoverHighlight.annotation.color === c
                      ? 'border-gray-900 dark:border-white scale-110'
                      : 'border-transparent'
                  }`}
                  style={{ backgroundColor: COLOR_MAP[c].bg }}
                  title={COLOR_MAP[c].name}
                />
              ))}
            </div>
          </div>

          {/* Note content or add note trigger */}
          {activePopoverHighlight.annotation.note ? (
            <div className="bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60 p-2 rounded-xl text-xs text-amber-900 dark:text-amber-200">
              <div className="flex items-center justify-between mb-1 text-[10px] text-amber-700 dark:text-amber-300 font-bold">
                <span>💬 الملاحظة المدونة:</span>
              </div>
              <p className="whitespace-pre-wrap">{activePopoverHighlight.annotation.note}</p>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => {
                setPendingAnnotation(activePopoverHighlight.annotation);
                setNoteInputText('');
                setIsNoteModalOpen(true);
                setActivePopoverHighlight(null);
              }}
              className="py-1 px-2 text-xs text-amber-700 dark:text-amber-300 hover:bg-amber-50 dark:hover:bg-amber-950/40 rounded-lg font-bold flex items-center justify-center gap-1 border border-dashed border-amber-300 dark:border-amber-700 cursor-pointer"
            >
              <MessageSquare className="w-3 h-3" />
              <span>إضافة ملاحظة على هذا التظليل</span>
            </button>
          )}

          {/* Actions: Ask AI, Copy, Delete */}
          <div className="flex items-center justify-between gap-1 pt-1 border-t border-gray-100 dark:border-gray-800 text-xs">
            {onAskAboutQuote && (
              <button
                type="button"
                onClick={() => {
                  onAskAboutQuote(
                    activePopoverHighlight.annotation.selectedText,
                    activePopoverHighlight.annotation.pageNumber
                  );
                  setActivePopoverHighlight(null);
                }}
                className="px-2 py-1 bg-purple-50 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 rounded-lg font-bold hover:bg-purple-600 hover:text-white transition-colors flex items-center gap-1 cursor-pointer"
              >
                <Sparkles className="w-3 h-3" />
                <span>اسأل AI</span>
              </button>
            )}

            <button
              type="button"
              onClick={() => {
                handleCopyWithCitation(
                  activePopoverHighlight.annotation.selectedText,
                  activePopoverHighlight.annotation.pageNumber
                );
                setActivePopoverHighlight(null);
              }}
              className="p-1 text-gray-500 hover:text-gray-700 cursor-pointer"
              title="نسخ الاقتباس"
            >
              <Copy className="w-3.5 h-3.5" />
            </button>

            <button
              type="button"
              onClick={() => handleDeleteAnnotation(activePopoverHighlight.annotation.id)}
              className="px-2 py-1 text-red-600 hover:bg-red-50 dark:hover:bg-red-950/40 rounded-lg font-bold flex items-center gap-1 cursor-pointer"
            >
              <Trash2 className="w-3 h-3" />
              <span>حذف</span>
            </button>
          </div>
        </div>
      )}

      {/* Main Workspace Area: Responsive Document Reader + Annotations Synchronized Layout */}
      <div className={`flex-1 min-h-0 overflow-hidden relative flex ${
        workspaceMode === 'split' ? 'flex-col lg:flex-row' : 'flex-col'
      }`}>
        {/* Document Viewing Scrollable Container */}
        {workspaceMode !== 'notes-full' && (
          <div
            ref={textContainerRef}
            onMouseUp={handleTextSelection}
            onTouchEnd={handleTextSelection}
            onKeyUp={handleTextSelection}
            className={`select-text transition-all ${
              workspaceMode === 'split'
                ? 'h-[50%] lg:h-full lg:flex-1 lg:min-w-0 overflow-y-auto p-2 sm:p-5 flex flex-col items-center border-b lg:border-b-0 lg:border-l border-black/10 dark:border-white/10'
                : 'flex-1 h-full overflow-y-auto p-3 sm:p-6 flex flex-col items-center'
            }`}
          >
          {isPdfLoading ? (
            <div className="flex flex-col items-center justify-center h-64 text-center">
              <div className="w-10 h-10 border-3 border-teal-600 border-t-transparent rounded-full animate-spin mb-3" />
              <p className="text-xs font-bold opacity-80">
                جاري تحضير ملف الـ PDF للعرض الأكاديمي فائق الوضوح...
              </p>
            </div>
          ) : viewMode === 'canvas' && hasCanvasSupport ? (
            /* Original PDF Page Canvas Render */
            <div className="relative max-w-full flex flex-col items-center space-y-4">
              <div className="px-3 py-1 bg-teal-50 dark:bg-teal-950/50 border border-teal-200 dark:border-teal-800 text-teal-800 dark:text-teal-200 text-xs rounded-full font-bold flex items-center gap-1.5 shadow-xs">
                <Sparkles className="w-3.5 h-3.5 text-teal-600" />
                <span>يمكنك التبديل إلى «القارئ الذكي» بالأعلى لتظليل وتحديد أي نص بدقة وسرعة مباشرة</span>
              </div>

              <div className="relative inline-block border border-black/15 dark:border-white/15 rounded-xl shadow-lg overflow-hidden bg-white mx-auto">
                <SourceAnnotationOverlay
                  annotations={localAnnotations}
                  pageNumber={currentPage}
                  activeAnnotationId={activeTargetAnnotationId}
                  onSelectAnnotation={jumpToAnnotation}
                  onAskAboutAnnotation={(a) => onAskAboutQuote && onAskAboutQuote(a.selectedText, a.pageNumber)}
                />
                <canvas ref={canvasRef} className="block max-w-full h-auto" />
              </div>

              {/* Synchronized Text Card beneath Canvas for selection */}
              <div className={`w-full max-w-3xl p-5 rounded-2xl border ${themeClasses.page}`}>
                <div className="flex items-center justify-between pb-2 mb-3 border-b border-black/10 dark:border-white/10">
                  <span className="text-xs font-bold flex items-center gap-1 text-[#0f766e] dark:text-[#2dd4bf]">
                    <Highlighter className="w-3.5 h-3.5" />
                    نص الصفحة {currentPage} المتاح للتظليل والاقتباس المباشر:
                  </span>
                  <span className="text-[10px] text-gray-400">حدد بالماوس للتظليل</span>
                </div>
                <div
                  data-page-number={currentPage}
                  style={{ lineHeight: lineHeightValue }}
                  className="whitespace-pre-wrap select-text relative"
                >
                  <SourceAnnotationOverlay
                    annotations={localAnnotations}
                    pageNumber={currentPage}
                    activeAnnotationId={activeTargetAnnotationId}
                    onSelectAnnotation={jumpToAnnotation}
                    onAskAboutAnnotation={(a) => onAskAboutQuote && onAskAboutQuote(a.selectedText, a.pageNumber)}
                  />
                  {renderInteractivePageText(currentPageItem)}
                </div>
              </div>
            </div>
          ) : layoutMode === 'continuous' ? (
            /* Continuous Reading Mode (All Pages flowing seamlessly) */
            <div className="w-full max-w-3xl space-y-6">
              {documentPages.map((page) => (
                <div
                  key={`page-${page.pageNumber}`}
                  data-page-number={page.pageNumber}
                  className={`rounded-2xl border p-6 sm:p-8 transition-colors select-text ${themeClasses.page}`}
                >
                  <div className="flex items-center justify-between pb-3 mb-4 border-b border-black/10 dark:border-white/10">
                    <span className="px-2.5 py-0.5 rounded-lg bg-[#0f766e]/10 text-[#0f766e] dark:text-[#2dd4bf] text-xs font-bold">
                      الصفحة {page.pageNumber}
                    </span>
                    <span className="text-[11px] opacity-70">
                      {localAnnotations.filter((a) => a.pageNumber === page.pageNumber).length} تظليل
                    </span>
                  </div>

                  <div
                    style={{ lineHeight: lineHeightValue }}
                    className="whitespace-pre-wrap select-text relative"
                  >
                    <SourceAnnotationOverlay
                      annotations={localAnnotations}
                      pageNumber={page.pageNumber}
                      activeAnnotationId={activeTargetAnnotationId}
                      onSelectAnnotation={jumpToAnnotation}
                      onAskAboutAnnotation={(a) => onAskAboutQuote && onAskAboutQuote(a.selectedText, a.pageNumber)}
                    />
                    {renderInteractivePageText(page)}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            /* Paginated Single Page View */
            <div
              data-page-number={currentPageItem.pageNumber}
              className={`w-full max-w-3xl rounded-2xl border p-6 sm:p-8 transition-colors select-text ${themeClasses.page}`}
            >
              <div className="flex items-center justify-between pb-3 mb-4 border-b border-black/10 dark:border-white/10">
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-lg bg-[#0f766e]/10 text-[#0f766e] dark:text-[#2dd4bf] text-xs font-bold">
                    الصفحة {currentPageItem.pageNumber}
                  </span>
                  <span className="text-xs opacity-70">
                    ({localAnnotations.filter((a) => a.pageNumber === currentPageItem.pageNumber).length} تظليل وملاحظة)
                  </span>
                </div>

                <span className="text-[11px] text-[#0f766e] dark:text-[#2dd4bf] font-bold">
                  💡 حدد أي نص بالماوس أو اللمس لإظهار أدوات التظليل والتعليق
                </span>
              </div>

              <div
                style={{ lineHeight: lineHeightValue }}
                className="whitespace-pre-wrap select-text relative"
              >
                <SourceAnnotationOverlay
                  annotations={localAnnotations}
                  pageNumber={currentPageItem.pageNumber}
                  activeAnnotationId={activeTargetAnnotationId}
                  onSelectAnnotation={jumpToAnnotation}
                  onAskAboutAnnotation={(a) => onAskAboutQuote && onAskAboutQuote(a.selectedText, a.pageNumber)}
                />
                {renderInteractivePageText(currentPageItem)}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Mobile Split Workspace Divider Status Bar */}
      {workspaceMode === 'split' && (
        <div className="lg:hidden w-full bg-teal-50/95 dark:bg-[#132e29]/95 border-y border-teal-200 dark:border-teal-800 px-3 py-1 flex items-center justify-between text-[11px] font-bold text-[#0f766e] dark:text-[#2dd4bf] shrink-0">
          <span className="flex items-center gap-1.5">
            <Layers className="w-3.5 h-3.5" />
            المستند أعلاه ↕ الملاحظات أدناه (متزامن)
          </span>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setWorkspaceMode('doc-only')}
              className="text-gray-500 hover:text-gray-800 dark:hover:text-gray-200 cursor-pointer"
            >
              المستند فقط
            </button>
            <span>•</span>
            <button
              type="button"
              onClick={() => setWorkspaceMode('notes-full')}
              className="text-gray-500 hover:text-gray-800 dark:hover:text-gray-200 cursor-pointer"
            >
              الملاحظات كاملة
            </button>
          </div>
        </div>
      )}

      {/* Annotations & Notes Workspace Pane */}
      {workspaceMode !== 'doc-only' && (
        <div
          className={`flex flex-col transition-all shadow-xl z-20 ${
            workspaceMode === 'notes-full'
              ? 'flex-1 h-full w-full min-h-0'
              : 'lg:w-84 xl:w-96 lg:h-full lg:shrink-0 flex-1 min-h-0 h-[50%] border-t lg:border-t-0 lg:border-r border-black/10 dark:border-white/10'
          } ${themeClasses.sidebar}`}
        >
          {/* Drawer Header */}
          <div className="p-3.5 border-b border-black/10 dark:border-white/10 space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Bookmark className="w-4 h-4 text-[#0f766e] dark:text-[#2dd4bf]" />
                <h4 className="font-bold text-xs">
                  {workspaceMode === 'notes-full' ? 'لوحة الملاحظات والتظليلات الكاملة' : 'تظليلات وملاحظات المصدر'}
                </h4>
              </div>
              <div className="flex items-center gap-1.5">
                {workspaceMode === 'notes-full' && (
                  <button
                    type="button"
                    onClick={() => setWorkspaceMode('split')}
                    className="px-2 py-0.5 rounded-lg bg-teal-50 dark:bg-teal-950/60 text-[#0f766e] dark:text-[#2dd4bf] text-[11px] font-bold cursor-pointer hover:bg-teal-100"
                  >
                    عرض المستند (تقسيم)
                  </button>
                )}
                <span className="text-[11px] px-2 py-0.5 rounded-full bg-[#0f766e]/10 text-[#0f766e] dark:text-[#2dd4bf] font-bold">
                  {localAnnotations.length}
                </span>
                <button
                  type="button"
                  onClick={() => setWorkspaceMode('doc-only')}
                  className="p-1 text-gray-400 hover:text-gray-600 cursor-pointer"
                  title="إغلاق لوحة الملاحظات"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

              {/* Drawer Search */}
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-gray-400 absolute right-2.5 top-2.5" />
                <input
                  type="text"
                  placeholder="بحث في التظليلات أو التعليقات..."
                  value={drawerSearch}
                  onChange={(e) => setDrawerSearch(e.target.value)}
                  className="w-full pr-8 pl-3 py-1.5 bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 rounded-xl text-xs focus:outline-none focus:border-[#0f766e]"
                />
              </div>

              {/* Filters: Page & Color */}
              <div className="flex items-center justify-between gap-1 pt-1">
                <div className="flex bg-black/5 dark:bg-white/5 p-0.5 rounded-lg text-[10px] font-bold">
                  <button
                    type="button"
                    onClick={() => setDrawerPageFilter('all')}
                    className={`px-2 py-0.5 rounded cursor-pointer ${
                      drawerPageFilter === 'all' ? 'bg-white dark:bg-black/40 text-[#0f766e] shadow-xs' : 'opacity-60'
                    }`}
                  >
                    كل الصفحات
                  </button>
                  <button
                    type="button"
                    onClick={() => setDrawerPageFilter('current')}
                    className={`px-2 py-0.5 rounded cursor-pointer ${
                      drawerPageFilter === 'current' ? 'bg-white dark:bg-black/40 text-[#0f766e] shadow-xs' : 'opacity-60'
                    }`}
                  >
                    الصفحة الحالية ({currentPage})
                  </button>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => setDrawerColorFilter('all')}
                    className={`text-[10px] px-1.5 py-0.5 rounded font-bold cursor-pointer ${
                      drawerColorFilter === 'all' ? 'bg-black/10 dark:bg-white/10 font-black' : 'opacity-50'
                    }`}
                  >
                    الكل
                  </button>
                  {(Object.keys(COLOR_MAP) as HighlightColor[]).map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setDrawerColorFilter(c)}
                      className={`w-3.5 h-3.5 rounded-full border cursor-pointer transition-transform ${
                        drawerColorFilter === c ? 'scale-125 border-black dark:border-white' : 'border-transparent'
                      }`}
                      style={{ backgroundColor: COLOR_MAP[c].bg }}
                      title={COLOR_MAP[c].name}
                    />
                  ))}
                </div>
              </div>
            </div>

            {/* Annotations List */}
            <div className="flex-1 overflow-y-auto p-3 space-y-3">
              {localAnnotations.length === 0 ? (
                <div className="text-center py-12 px-4 text-xs opacity-60">
                  <Highlighter className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                  <p className="font-bold mb-1">لا توجد تظليلات محفوظة بعد</p>
                  <p className="text-[11px]">حدد أي نص في القارئ لإبراز وتدوين ملاحظاتك المرجعية.</p>
                </div>
              ) : (
                localAnnotations
                  .filter((ann) => {
                    if (drawerPageFilter === 'current' && ann.pageNumber !== currentPage) return false;
                    if (drawerColorFilter !== 'all' && ann.color !== drawerColorFilter) return false;
                    if (drawerSearch.trim()) {
                      const q = drawerSearch.toLowerCase();
                      const matchText = ann.selectedText.toLowerCase().includes(q);
                      const matchNote = ann.note?.toLowerCase().includes(q);
                      return matchText || matchNote;
                    }
                    return true;
                  })
                  .map((ann) => (
                    <SourceAnnotationCard
                      key={ann.id}
                      annotation={ann}
                      sourceTitle={source.title}
                      isActive={activeTargetAnnotationId === ann.id}
                      onJumpTo={jumpToAnnotation}
                      onAskAbout={(a) => onAskAboutQuote && onAskAboutQuote(a.selectedText, a.pageNumber)}
                      onDelete={handleDeleteAnnotation}
                      onUpdateColor={handleUpdateAnnotationColor}
                      onUpdateNote={handleUpdateAnnotationNote}
                      onExportToNote={(a) => handleExportQuoteToNotebook(a.selectedText, a.pageNumber)}
                    />
                  ))
              )}
            </div>
          </div>
        )}
      </div>

      {/* Note Creation / Editing Modal */}
      {isNoteModalOpen && pendingAnnotation && (
        <div className="fixed inset-0 z-50 p-4 bg-black/60 backdrop-blur-xs flex items-center justify-center animate-in fade-in duration-150">
          <div className="bg-white dark:bg-[#14201c] w-full max-w-md rounded-2xl shadow-2xl border border-gray-200 dark:border-gray-800 p-5 flex flex-col gap-4">
            <div className="flex items-center justify-between pb-2 border-b border-gray-100 dark:border-gray-800">
              <div className="flex items-center gap-2 text-[#0f766e] dark:text-[#2dd4bf]">
                <MessageSquare className="w-4 h-4" />
                <h3 className="font-bold text-sm text-[#17201e] dark:text-[#eef7f4]">
                  إضافة ملاحظة وتفسير على المقتبس
                </h3>
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsNoteModalOpen(false);
                  setPendingAnnotation(null);
                }}
                className="p-1 text-gray-400 hover:text-gray-600 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Target Quote Preview */}
            <div className="bg-gray-50 dark:bg-gray-800/40 p-3 rounded-xl border border-gray-200/60 dark:border-gray-700/60 text-xs italic line-clamp-3">
              «{pendingAnnotation.selectedText}»
            </div>

            {/* Color selection */}
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-gray-600 dark:text-gray-400">لون التظليل:</span>
              <div className="flex items-center gap-2">
                {(Object.keys(COLOR_MAP) as HighlightColor[]).map((c) => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setPendingAnnotation({ ...pendingAnnotation, color: c })}
                    className={`w-6 h-6 rounded-full border-2 transition-transform cursor-pointer ${
                      pendingAnnotation.color === c ? 'border-gray-900 dark:border-white scale-110' : 'border-transparent'
                    }`}
                    style={{ backgroundColor: COLOR_MAP[c].bg }}
                    title={COLOR_MAP[c].name}
                  >
                    {pendingAnnotation.color === c && <Check className="w-3 h-3 text-gray-900 mx-auto" />}
                  </button>
                ))}
              </div>
            </div>

            {/* Note text input */}
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-bold text-gray-700 dark:text-gray-300">
                الملاحظة أو التلخيص الشخصي:
              </label>
              <textarea
                rows={3}
                placeholder="اكتب فكرتك، شرحك، أو سؤالك حول هذا المقطع..."
                value={noteInputText}
                onChange={(e) => setNoteInputText(e.target.value)}
                className="w-full p-3 bg-gray-50 dark:bg-gray-800/50 border border-gray-200 dark:border-gray-700 rounded-xl text-xs text-[#17201e] dark:text-[#eef7f4] focus:outline-none focus:border-[#0f766e]"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  setIsNoteModalOpen(false);
                  setPendingAnnotation(null);
                }}
                className="px-4 py-2 rounded-xl text-xs font-bold text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800 cursor-pointer"
              >
                إلغاء
              </button>
              <button
                type="button"
                onClick={handleSavePendingNote}
                className="px-5 py-2 rounded-xl text-xs font-bold bg-[#0f766e] text-white hover:bg-[#0d645d] shadow-xs cursor-pointer"
              >
                حفظ التظليل والملاحظة
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
