import React, { useState } from 'react';
import {
  Sparkles,
  FlaskConical,
  Atom,
  Zap,
  Flame,
  Send,
  RotateCcw,
  BookOpen,
  CheckCircle,
  FileText,
  Sliders,
  ChevronDown,
  ChevronUp,
  Activity,
  Layers,
  Dna
} from 'lucide-react';
import { SafeMathText } from './SafeMathText';
import { callDirectGeminiWithKeyRotation } from '../lib/clientGeminiService';
import { solveAcademicallyOffline } from '../lib/questionBankData';

interface AiLabAssistantProps {
  onSaveExperimentAsNote?: (title: string, content: string) => void;
  activeDomain?: string;
  initialContext?: string;
}

interface LabPresetExperiment {
  id: string;
  title: string;
  category: 'physics' | 'chemistry' | 'biology';
  icon: string;
  summary: string;
  parameters: Array<{
    name: string;
    label: string;
    min: number;
    max: number;
    step: number;
    defaultValue: number;
    unit: string;
  }>;
  calculate: (params: Record<string, number>) => {
    results: Record<string, string>;
    scientificExplanation: string;
    formulaLatex: string;
  };
}

const PRESET_EXPERIMENTS: LabPresetExperiment[] = [
  {
    id: 'ohms_law',
    title: 'تحقيق قانون أوم والقدرة الكهربائية في الدوائر المغلقة',
    category: 'physics',
    icon: '⚡',
    summary: 'دراسة العلاقة الخطية بين فرق الجهد V وشدة التيار I عبر مقاومة أومية R وحساب القدرة المستهلكة P.',
    parameters: [
      { name: 'voltage', label: 'فرق الجهد (V)', min: 1, max: 24, step: 0.5, defaultValue: 12, unit: 'V' },
      { name: 'resistance', label: 'المقاومة الكهربائية (R)', min: 2, max: 100, step: 1, defaultValue: 10, unit: 'Ω' },
    ],
    calculate: (p) => {
      const v = p.voltage;
      const r = p.resistance;
      const current = v / r;
      const power = v * current;
      return {
        results: {
          'شدة التيار المار (I)': `${current.toFixed(3)} A (${(current * 1000).toFixed(1)} mA)`,
          'القدرة الكهربائية المستهلكة (P)': `${power.toFixed(2)} W`,
          'الطاقة المبددة في دقيقة (E)': `${(power * 60).toFixed(1)} J`,
        },
        formulaLatex: `I = \\frac{V}{R} \\quad , \\quad P = V \\cdot I = I^2 \\cdot R`,
        scientificExplanation: `وفق قانون أوم، تتناسب شدة التيار المار في موصل معدني طردياً مع فرق الجهد بين طرفيه عند ثبوت درجة الحرارة. مع زيادة الجهد إلى ${v} فولت وثبات المقاومة عند ${r} أوم، تزداد قوة دفع الإلكترونات الحرة عبر شبكة الموصل البلورية بمعدل خطي منتظم.`,
      };
    },
  },
  {
    id: 'ideal_gas',
    title: 'قانون الغاز المثالي والعلاقة الحركية (بويل وشارل)',
    category: 'chemistry',
    icon: '🌡️',
    summary: 'محاكاة ديناميكا الغاز المحصور وتأثير الحرارة والحجم على الضغط وفق المعادلة العامة للغازات.',
    parameters: [
      { name: 'tempK', label: 'درجة الحرارة المطلقة (T)', min: 150, max: 600, step: 10, defaultValue: 300, unit: 'K' },
      { name: 'volumeL', label: 'حجم الوعاء / المكبس (V)', min: 2, max: 40, step: 1, defaultValue: 10, unit: 'L' },
      { name: 'moles', label: 'كمية المادة (n)', min: 0.5, max: 5, step: 0.5, defaultValue: 1, unit: 'mol' },
    ],
    calculate: (p) => {
      const R = 0.08206; // L*atm/(mol*K)
      const t = p.tempK;
      const v = p.volumeL;
      const n = p.moles;
      const pressureAtm = (n * R * t) / v;
      const pressureKPa = pressureAtm * 101.325;
      return {
        results: {
          'الضغط المحسوب بالجو (P)': `${pressureAtm.toFixed(3)} atm`,
          'الضغط بالكيلوباسكال': `${pressureKPa.toFixed(2)} kPa`,
          'درجة الحرارة بالدرجة المئوية': `${(t - 273.15).toFixed(1)} °C`,
        },
        formulaLatex: `P \\cdot V = n \\cdot R \\cdot T \\implies P = \\frac{n R T}{V}`,
        scientificExplanation: `وفق النظرية الحركية الجزيئية للغازات، ينشأ الضغط عن تصادم جزيئات الغاز بجدران الوعاء. عند درجة حرارة ${t} كلفن وحجم ${v} لتر، يبلغ متوسط الطاقة الحركية الانتقالية للجزيئات قيمة تتناسب مع ${t}K، مما يؤدي إلى ضغط مقداره ${pressureAtm.toFixed(3)} ضغط جوي.`,
      };
    },
  },
  {
    id: 'projectile_kinetics',
    title: 'حركة المقذوفات في مجال الجاذبية الأرضية',
    category: 'physics',
    icon: '🚀',
    summary: 'حساب أقصى ارتفاع، زمن التحليق الكلي، والمدى الأفقي لجسيم مقذوف بزاوية في الفراغ.',
    parameters: [
      { name: 'speed', label: 'السرعة الابتدائية (v₀)', min: 5, max: 60, step: 1, defaultValue: 25, unit: 'm/s' },
      { name: 'angle', label: 'زاوية الإطلاق (θ)', min: 10, max: 85, step: 5, defaultValue: 45, unit: '°' },
    ],
    calculate: (p) => {
      const g = 9.80665;
      const v = p.speed;
      const thetaRad = (p.angle * Math.PI) / 180;
      const tFlight = (2 * v * Math.sin(thetaRad)) / g;
      const hMax = (Math.pow(v * Math.sin(thetaRad), 2)) / (2 * g);
      const range = (Math.pow(v, 2) * Math.sin(2 * thetaRad)) / g;
      return {
        results: {
          'أقصى ارتفاع عمودي (H_max)': `${hMax.toFixed(2)} m`,
          'المدى الأفقي الكلي (R)': `${range.toFixed(2)} m`,
          'زمن التحليق الكلي (T_flight)': `${tFlight.toFixed(2)} s`,
        },
        formulaLatex: `H_{max} = \\frac{v_0^2 \\sin^2\\theta}{2g} \\quad , \\quad R = \\frac{v_0^2 \\sin(2\\theta)}{g}`,
        scientificExplanation: `تتحلل حركة المقذوف إلى حركتين مستقلتين متعامدتين: حركة أفقية منتظمة السرعة (بدون تسارع)، وحركة رأسية منتظمة التغير بتسارع الجاذبية الأرضية g. بزاوية ${p.angle}° وسرعة ${v} م/ث، يتحقق أقصى استثمار لمركبتي السرعة.`,
      };
    },
  },
  {
    id: 'faraday_induction',
    title: 'الحث الكهرومغناطيسي وقانون فاراداي ولينز',
    category: 'physics',
    icon: '🧲',
    summary: 'حساب القوة الدافعة الكهربائية التأثيرية المتولدة في ملف ناتج عن تغير التدفق المغناطيسي.',
    parameters: [
      { name: 'turns', label: 'عدد لفات الملف (N)', min: 50, max: 1000, step: 50, defaultValue: 200, unit: 'لفّة' },
      { name: 'deltaPhi', label: 'التغير في التدفق (ΔΦ)', min: 0.01, max: 0.5, step: 0.01, defaultValue: 0.05, unit: 'Wb' },
      { name: 'deltaTime', label: 'الزمن المستغرق (Δt)', min: 0.01, max: 0.5, step: 0.01, defaultValue: 0.05, unit: 's' },
    ],
    calculate: (p) => {
      const emf = Math.abs(p.turns * (p.deltaPhi / Math.max(0.001, p.deltaTime)));
      return {
        results: {
          'القوة الدافعة التأثيرية (emf)': `${emf.toFixed(2)} V`,
          'معدل تغير التدفق (dΦ/dt)': `${(p.deltaPhi / p.deltaTime).toFixed(2)} Wb/s`,
        },
        formulaLatex: `\\mathcal{E} = -N \\frac{\\Delta \\Phi}{\\Delta t}`,
        scientificExplanation: `وفق قانون فاراداي، تتولد قوة دافعة كهربائية تأثيرية تتناسب طردياً مع المعدل الزمني لتغير التدفق المغناطيسي وعدد لفات الملف. وتشير إشارة السالب في قانون لينز إلى أن اتجاه التيار الحثي يعاكس التغير في التدفق المسبب له.`,
      };
    },
  },
  {
    id: 'dna_translation',
    title: 'ترجمة الشفرة الوراثية وتخليق البروتين',
    category: 'biology',
    icon: '🧬',
    summary: 'محاكاة ترجمة كودونات الـ mRNA إلى سلاسل أحماض أمينية ببتيدية في الريبوسوم.',
    parameters: [
      { name: 'codonsCount', label: 'طول سلسلة الكودونات', min: 3, max: 12, step: 1, defaultValue: 5, unit: 'كودون' },
    ],
    calculate: (p) => {
      const codonMap: Record<string, string> = {
        AUG: 'ميثيونين (Met - كودون البدء)',
        UUU: 'فينيل ألانين (Phe)',
        UUA: 'ليوسين (Leu)',
        GGU: 'جلايسين (Gly)',
        GCU: 'ألانين (Ala)',
        UAA: 'كودون الوقف (Stop)',
        UGG: 'تريبتوفان (Trp)',
        CAU: 'هيستيدين (His)',
      };
      const sampleCodons = ['AUG', 'UUU', 'GCU', 'GGU', 'UGG', 'CAU', 'UUA', 'UAA'];
      const active = sampleCodons.slice(0, Math.min(sampleCodons.length, p.codonsCount));
      const peptide = active.map((c) => codonMap[c] || 'حمض أميني').join(' — ');

      return {
        results: {
          'كودونات الـ mRNA': active.join(' - '),
          'السلسلة الببتيدية المترجمة': peptide,
          'عدد الروابط الببتيدية المتكونة': `${Math.max(0, active.length - 1)} رابطة ببتيدية`,
        },
        formulaLatex: `\\text{mRNA} \\xrightarrow{\\text{tRNA + Ribosome}} \\text{Polypeptide Chain} + (n-1) \\ce{H2O}`,
        scientificExplanation: `تتم ترجمة الشفرة الثلاثية على جزيء الـ mRNA بواسطة الريبوسومات بمساعدة جزيئات الـ tRNA الناقلة. يبدأ التخليق دائماً بكودون البدء AUG الذي يشفر الميثيونين، وترتبط الأحماض الأمينية المتتالية بروابط ببتيدية تساهمية قوية مع نزع جزيء ماء.`,
      };
    },
  },
];

export const AiLabAssistant: React.FC<AiLabAssistantProps> = ({
  onSaveExperimentAsNote,
  activeDomain,
  initialContext,
}) => {
  const [selectedPreset, setSelectedPreset] = useState<LabPresetExperiment>(PRESET_EXPERIMENTS[0]);
  const [paramValues, setParamValues] = useState<Record<string, number>>(() => {
    const init: Record<string, number> = {};
    PRESET_EXPERIMENTS[0].parameters.forEach((p) => {
      init[p.name] = p.defaultValue;
    });
    return init;
  });

  const [customPrompt, setCustomPrompt] = useState(initialContext || '');
  const [aiAnalysis, setAiAnalysis] = useState<string | null>(null);
  const [isLoadingAi, setIsLoadingAi] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [isExpanded, setIsExpanded] = useState(true);

  // Handle Preset Change
  const handleSelectPreset = (preset: LabPresetExperiment) => {
    setSelectedPreset(preset);
    const newParams: Record<string, number> = {};
    preset.parameters.forEach((p) => {
      newParams[p.name] = p.defaultValue;
    });
    setParamValues(newParams);
    setAiAnalysis(null);
  };

  // Live calculation
  const currentCalc = selectedPreset.calculate(paramValues);

  // Run Custom AI Lab Analysis
  const handleRunAiAnalysis = async (customText?: string) => {
    const textToQuery = customText || customPrompt;
    if (!textToQuery.trim() && !selectedPreset) return;

    setIsLoadingAi(true);
    setAiAnalysis(null);

    const experimentContext = `
تجربة مخبرية علمية: ${selectedPreset.title}
المجال: ${selectedPreset.category}
القانون الرياضي: ${currentCalc.formulaLatex}
المعطيات والبارامترات المسجلة:
${Object.entries(paramValues).map(([k, v]) => `- ${k}: ${v}`).join('\n')}
النتائج الحسابية المحسوبة:
${Object.entries(currentCalc.results).map(([k, v]) => `- ${k}: ${v}`).join('\n')}

السؤال أو الاستفسار المطلوب:
${textToQuery.trim() || 'حلل هذه التجربة تحليلاً مخبرياً دقيقاً، واشرح المتغيرات والعلاقات البيانية ومصادر الخطأ التجريبي المحتملة وفق المنهج العلمي الأكاديمي.'}
`.trim();

    try {
      const response = await callDirectGeminiWithKeyRotation({
        prompt: experimentContext,
        systemInstruction: `أنت كبير المستشارين المعمليين وأستاذ العلوم والفيزياء والكيمياء التجريبية في منصة D.CORE Schooler AI. قدم تحليلاً معملياً علمياً متقدماً، خالياً من الحشو والمقدمات، بصياغة رياضية قياسية دقيقة مستخدماً كتل LaTeX للأصل والمعادلات، مع نصائح السلامة المعملية ومصادر الخطأ المنهجي.`,
        timeoutMs: 9000,
      });

      if (response && response.text) {
        setAiAnalysis(response.text);
      } else {
        const offlineAns = solveAcademicallyOffline(textToQuery || selectedPreset.title);
        const offlineText = `### ${offlineAns.title}\n\n${offlineAns.detailedAnalysis}\n\n${offlineAns.formulaOrRule ? `**القانون الحاكم:**\n$$${offlineAns.formulaOrRule}$$\n\n` : ''}**الخلاصة العلمية:** ${offlineAns.keyTakeaway}`;
        setAiAnalysis(offlineText);
      }
    } catch (e) {
      console.warn('AI Lab call failed, falling back to comprehensive scientific offline engine:', e);
      const offlineAns = solveAcademicallyOffline(textToQuery || selectedPreset.title);
      const offlineText = `### ${offlineAns.title}\n\n${offlineAns.detailedAnalysis}\n\n${offlineAns.formulaOrRule ? `**القانون الحاكم:**\n$$${offlineAns.formulaOrRule}$$\n\n` : ''}**الخلاصة العلمية:** ${offlineAns.keyTakeaway}`;
      setAiAnalysis(offlineText);
    } finally {
      setIsLoadingAi(false);
    }
  };

  const handleSaveToNotebook = () => {
    if (!onSaveExperimentAsNote) return;
    const title = `تقرير معملي AI: ${selectedPreset.title}`;
    const content = `
### 🔬 تقرير المحاكاة المعملية التفاعلية
**التجربة:** ${selectedPreset.title}
**المجال:** ${selectedPreset.category}

#### 📐 القانون الحاكم:
$$${currentCalc.formulaLatex}$$

#### 📊 المعطيات والمدخلات:
${Object.entries(paramValues).map(([k, v]) => `- **${k}:** ${v}`).join('\n')}

#### 🧪 النتائج التجريبية:
${Object.entries(currentCalc.results).map(([k, v]) => `- **${k}:** ${v}`).join('\n')}

#### 💡 التحليل العلمي:
${currentCalc.scientificExplanation}

${aiAnalysis ? `\n#### 🤖 التحليل المعملي بالذكاء الاصطناعي:\n${aiAnalysis}` : ''}

*أُجريت التجربة في المختبر العلمي التفاعلي المتطور - منصة المعلم الذكي للدراسة والبحث العلمي.*
`.trim();

    onSaveExperimentAsNote(title, content);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  return (
    <div className="bg-white dark:bg-[#131f1c] rounded-3xl border border-teal-200 dark:border-teal-900/60 shadow-lg overflow-hidden transition-all">
      {/* Header */}
      <div className="p-4 sm:p-5 bg-gradient-to-r from-teal-800 via-teal-700 to-emerald-800 text-white flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-white/15 backdrop-blur-md border border-white/20 flex items-center justify-center shrink-0">
            <Sparkles className="w-5 h-5 text-teal-200 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base sm:text-lg font-black tracking-tight">
                المساعد المعملي الذكي والمحاكي التفاعلي
              </h3>
              <span className="px-2 py-0.5 rounded-full bg-emerald-400/20 text-emerald-200 text-[10px] font-bold border border-emerald-400/30">
                AI Lab Copilot
              </span>
            </div>
            <p className="text-xs text-teal-100/90 hidden sm:block">
              محاكاة فيزيائية وكيميائية وبيولوجية فورية مع استنتاج النتائج بالمعادلات وتحليل الذكاء الاصطناعي
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleSaveToNotebook}
            className="px-3 py-1.5 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs font-bold border border-white/20 backdrop-blur-sm flex items-center gap-1.5 transition-all cursor-pointer"
            title="حفظ تقرير هذه التجربة في الدفتر"
          >
            {savedSuccess ? <CheckCircle className="w-4 h-4 text-emerald-300" /> : <FileText className="w-4 h-4 text-teal-200" />}
            <span className="hidden sm:inline">{savedSuccess ? 'تم الحفظ في الملاحظات' : 'حفظ كتقرير في الدفتر'}</span>
          </button>

          <button
            type="button"
            onClick={() => setIsExpanded((prev) => !prev)}
            className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-all cursor-pointer"
            title={isExpanded ? 'طي اللوحة' : 'توسيع اللوحة'}
          >
            {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {isExpanded && (
        <div className="p-4 sm:p-6 space-y-6">
          {/* Preset Experiments Carousel */}
          <div>
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-2 flex items-center gap-1.5">
              <FlaskConical className="w-4 h-4 text-teal-600 dark:text-teal-400" />
              <span>اختر التجربة المعملية التفاعلية أو غيّر المتغيرات بحرية:</span>
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2">
              {PRESET_EXPERIMENTS.map((preset) => (
                <button
                  key={preset.id}
                  type="button"
                  onClick={() => handleSelectPreset(preset)}
                  className={`p-2.5 rounded-2xl text-right transition-all border cursor-pointer flex flex-col justify-between ${
                    selectedPreset.id === preset.id
                      ? 'bg-teal-50 dark:bg-teal-950/60 border-teal-500 shadow-sm ring-1 ring-teal-500'
                      : 'bg-slate-50 dark:bg-[#182723] border-slate-200 dark:border-[#243831] hover:border-teal-300 text-slate-700 dark:text-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-lg">{preset.icon}</span>
                    <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-full bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400 uppercase">
                      {preset.category}
                    </span>
                  </div>
                  <div className="text-xs font-bold line-clamp-2 text-slate-900 dark:text-slate-100">
                    {preset.title}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Experiment Controls & Live Real-time Simulation */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
            {/* Parameters Sliders */}
            <div className="lg:col-span-5 bg-slate-50 dark:bg-[#162320] p-4 rounded-2xl border border-slate-200 dark:border-[#22352f] space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-teal-800 dark:text-teal-300 flex items-center gap-1.5">
                  <Sliders className="w-4 h-4 text-teal-600" />
                  <span>المتغيرات والمدخلات التجريبية (Controls):</span>
                </span>
                <button
                  type="button"
                  onClick={() => {
                    const reset: Record<string, number> = {};
                    selectedPreset.parameters.forEach((p) => {
                      reset[p.name] = p.defaultValue;
                    });
                    setParamValues(reset);
                  }}
                  className="text-[11px] text-slate-500 hover:text-teal-600 flex items-center gap-1 cursor-pointer"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>إعادة ضبط</span>
                </button>
              </div>

              <div className="space-y-3.5">
                {selectedPreset.parameters.map((param) => (
                  <div key={param.name} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-slate-700 dark:text-slate-300">
                        {param.label}
                      </span>
                      <span className="font-mono font-bold text-teal-700 dark:text-teal-400">
                        {paramValues[param.name] ?? param.defaultValue} {param.unit}
                      </span>
                    </div>
                    <input
                      type="range"
                      min={param.min}
                      max={param.max}
                      step={param.step}
                      value={paramValues[param.name] ?? param.defaultValue}
                      onChange={(e) => {
                        const val = parseFloat(e.target.value);
                        setParamValues((prev) => ({ ...prev, [param.name]: val }));
                      }}
                      className="w-full h-2 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-teal-600"
                    />
                    <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                      <span>{param.min} {param.unit}</span>
                      <span>{param.max} {param.unit}</span>
                    </div>
                  </div>
                ))}
              </div>

              <div className="pt-2 border-t border-slate-200 dark:border-[#22352f]">
                <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                  {selectedPreset.summary}
                </p>
              </div>
            </div>

            {/* Live Scientific Output & KaTeX Formula Display */}
            <div className="lg:col-span-7 bg-white dark:bg-[#182723] p-4 rounded-2xl border border-teal-200 dark:border-teal-900/60 flex flex-col justify-between space-y-4 shadow-xs">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                    <Activity className="w-4 h-4 text-emerald-600" />
                    <span>النتائج اللحظية المحسوبة (Live Theoretical Output):</span>
                  </span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300">
                    دقة رياضية فيزيائية تامة
                  </span>
                </div>

                {/* Formula Block */}
                <div className="my-2 p-3 bg-teal-50/70 dark:bg-teal-950/40 rounded-xl border border-teal-100 dark:border-teal-900 text-center">
                  <span className="text-[10px] font-bold text-teal-700 dark:text-teal-400 block mb-1">
                    القانون الفيزيائي / الكيميائي الحاكم:
                  </span>
                  <div className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                    <SafeMathText content={`$$${currentCalc.formulaLatex}$$`} />
                  </div>
                </div>

                {/* Calculated Results Badges */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 my-3">
                  {Object.entries(currentCalc.results).map(([k, v]) => (
                    <div
                      key={k}
                      className="p-2.5 rounded-xl bg-slate-50 dark:bg-[#121c19] border border-slate-200 dark:border-[#22352f]"
                    >
                      <div className="text-[11px] text-slate-500 dark:text-slate-400 mb-0.5">{k}</div>
                      <div className="text-sm font-bold text-teal-800 dark:text-teal-300 font-mono">
                        {v}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Explanation */}
                <div className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed bg-slate-50 dark:bg-[#121c19] p-3 rounded-xl border border-slate-200 dark:border-[#22352f]">
                  <span className="font-bold text-teal-700 dark:text-teal-400 ml-1">تفسير الظاهرة:</span>
                  {currentCalc.scientificExplanation}
                </div>
              </div>

              {/* Action: Ask AI Copilot */}
              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => handleRunAiAnalysis()}
                  disabled={isLoadingAi}
                  className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-teal-700 via-teal-600 to-emerald-600 hover:from-teal-800 hover:to-emerald-700 text-white text-xs font-bold shadow-md flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-50"
                >
                  <Sparkles className="w-4 h-4 text-emerald-200" />
                  <span>
                    {isLoadingAi
                      ? 'جارٍ التحليل المعملي بالذكاء الاصطناعي...'
                      : 'طلب تحليل معمق وتفسير إحصائي بالذكاء الاصطناعي'}
                  </span>
                </button>
              </div>
            </div>
          </div>

          {/* Interactive Lab AI Prompt / Chat Input */}
          <div className="bg-slate-50 dark:bg-[#162320] p-4 rounded-2xl border border-slate-200 dark:border-[#22352f] space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                <Zap className="w-4 h-4 text-amber-500" />
                <span>طرح سؤال معملي مخصص أو فرضية لتوقع النتائج:</span>
              </label>
              <span className="text-[11px] text-slate-400">
                يعمل متصلاً بالذكاء الاصطناعي أو محلياً 100% دون إنترنت
              </span>
            </div>

            <div className="flex gap-2">
              <input
                type="text"
                value={customPrompt}
                onChange={(e) => setCustomPrompt(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleRunAiAnalysis();
                }}
                placeholder="مثال: ماذا يحدث إذا ضاعفنا المقاومة؟ أو كيف أحسب نسبة الخطأ في تجربة البندول؟"
                className="flex-1 px-4 py-2.5 rounded-xl bg-white dark:bg-[#121c19] border border-slate-300 dark:border-[#22352f] text-xs sm:text-sm text-slate-800 dark:text-slate-100 focus:outline-none focus:border-teal-600"
              />
              <button
                type="button"
                onClick={() => handleRunAiAnalysis()}
                disabled={isLoadingAi || !customPrompt.trim()}
                className="px-4 py-2.5 bg-teal-700 hover:bg-teal-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer disabled:opacity-50"
              >
                <Send className="w-4 h-4" />
                <span className="hidden sm:inline">تحليل</span>
              </button>
            </div>
          </div>

          {/* AI Response Display Box */}
          {aiAnalysis && (
            <div className="bg-white dark:bg-[#162320] p-5 rounded-2xl border border-teal-500/40 shadow-sm space-y-3 animate-in fade-in duration-300">
              <div className="flex items-center justify-between border-b border-teal-100 dark:border-teal-900/50 pb-2">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-teal-600 text-white flex items-center justify-center">
                    <Sparkles className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-slate-100">
                      التحليل المعملي الأكاديمي المتقدم
                    </h4>
                    <span className="text-[10px] text-teal-600 dark:text-teal-400">
                      تم الاستنتاج والتدقيق وفق القوانين الفيزيائية والكيميائية المعتمدة
                    </span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleSaveToNotebook}
                  className="text-xs font-bold text-teal-700 dark:text-teal-300 hover:underline flex items-center gap-1 cursor-pointer"
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>تضمين في الدفتر</span>
                </button>
              </div>

              <div className="text-xs sm:text-sm text-slate-800 dark:text-slate-200 leading-relaxed">
                <SafeMathText content={aiAnalysis} />
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
