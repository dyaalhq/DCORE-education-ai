import React, { useState, useRef, useEffect, useMemo } from 'react';
import { 
  ZoomIn, 
  ZoomOut, 
  Maximize2, 
  RotateCcw, 
  Download, 
  Printer, 
  Plus, 
  Trash2, 
  Edit3, 
  Layers, 
  Share2, 
  ChevronRight, 
  Sparkles,
  Palette,
  Layout,
  Check,
  X,
  FileText,
  BookOpen,
  Sigma,
  AlertCircle,
  GitFork
} from 'lucide-react';
import { MindMapNode, MindMapLayout } from '../types';
import { AcademicPrintModal } from './AcademicPrintModal';
import { mindMapToStructuredSummary } from '../lib/academicFormatter';
import { EducationalContent } from './EducationalContent';

interface InteractiveMindMapProps {
  initialData?: MindMapNode | null;
  onSave?: (data: MindMapNode) => void;
  readOnly?: boolean;
  notebookTitle?: string;
  notebookSubject?: string;
  initialLayout?: MindMapLayout;
  onExportPdf?: () => void;
}

const DEFAULT_MIND_MAP: MindMapNode = {
  id: 'root',
  title: 'الموضوع الأساسي للدراسة',
  level: 0,
  color: '#0f766e',
  children: [
    {
      id: 'b1',
      title: 'المحور الأول: المفاهيم والتعاريف',
      level: 1,
      color: '#0284c7',
      children: [
        { id: 'b1-1', title: 'التعريف العلمي الأساسي', level: 2, color: '#38bdf8' },
        { id: 'b1-2', title: 'الخصائص والمميزات الجوهرية', level: 2, color: '#38bdf8' },
        { id: 'b1-3', title: 'المصطلحات والمفردات ذات الصلة', level: 2, color: '#38bdf8' }
      ]
    },
    {
      id: 'b2',
      title: 'المحور الثاني: القوانين والمعادلات',
      level: 1,
      color: '#16a34a',
      children: [
        { id: 'b2-1', title: 'القاعدة الرئيسية وطريقة إثباتها', level: 2, color: '#4ade80' },
        { id: 'b2-2', title: 'الحالات الخاصة والاستثناءات', level: 2, color: '#4ade80' },
        { id: 'b2-3', title: 'وحدات القياس والتحويلات', level: 2, color: '#4ade80' }
      ]
    },
    {
      id: 'b3',
      title: 'المحور الثالث: التطبيقات والأمثلة المحلولة',
      level: 1,
      color: '#d97706',
      children: [
        { id: 'b3-1', title: 'مسألة نموذجية خطوة بخطوة', level: 2, color: '#fbbf24' },
        { id: 'b3-2', title: 'أخطاء شائعة في الاختبارات', level: 2, color: '#fbbf24' }
      ]
    },
    {
      id: 'b4',
      title: 'المحور الرابع: كبسولة المراجعة النهائية',
      level: 1,
      color: '#9333ea',
      children: [
        { id: 'b4-1', title: 'ملخص النقاط الذهبية', level: 2, color: '#c084fc' },
        { id: 'b4-2', title: 'أسئلة متوقعة للمراجعة', level: 2, color: '#c084fc' }
      ]
    }
  ]
};

// Node positioning calculation output
interface RenderNode {
  id: string;
  title: string;
  level: number;
  color: string;
  x: number;
  y: number;
  width: number;
  height: number;
  parentId?: string;
  childrenCount: number;
  rawNode: MindMapNode;
  notes?: string;
  formula?: string;
  badge?: string;
}

interface RenderEdge {
  id: string;
  sourceX: number;
  sourceY: number;
  targetX: number;
  targetY: number;
  color: string;
}

export const InteractiveMindMap: React.FC<InteractiveMindMapProps> = ({
  initialData,
  onSave,
  readOnly = false,
  notebookTitle = 'الدفتر الأكاديمي',
  notebookSubject = 'المنهج الدراسي',
  initialLayout = 'tree',
  onExportPdf,
}) => {
  const [data, setData] = useState<MindMapNode>(initialData || DEFAULT_MIND_MAP);
  const [layout, setLayout] = useState<MindMapLayout>(initialLayout || 'tree');
  const [zoom, setZoom] = useState<number>(1);
  const [pan, setPan] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
  const [editingNodeId, setEditingNodeId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [editNotes, setEditNotes] = useState('');
  const [editFormula, setEditFormula] = useState('');
  const [editBadge, setEditBadge] = useState('');
  const [colorTheme, setColorTheme] = useState<'emerald' | 'navy' | 'sunset' | 'monochrome'>('emerald');
  const [printPaperMode, setPrintPaperMode] = useState<'fit' | 'multi'>('fit');
  const [activeMindMapView, setActiveMindMapView] = useState<'canvas' | 'breakdown'>('canvas');
  const [isAcademicPrintOpen, setIsAcademicPrintOpen] = useState(false);
  const [matrixSearch, setMatrixSearch] = useState('');

  const containerRef = useRef<HTMLDivElement>(null);
  const svgRef = useRef<SVGSVGElement>(null);

  // Sync when initialData changes
  useEffect(() => {
    if (initialData) {
      setData(initialData);
    }
  }, [initialData]);

  // Sync when initialLayout changes
  useEffect(() => {
    if (initialLayout) {
      setLayout(initialLayout);
    }
  }, [initialLayout]);

  // Color schemes for auto coloring
  const themeColors = useMemo(() => {
    switch (colorTheme) {
      case 'navy':
        return ['#1e3a8a', '#2563eb', '#3b82f6', '#0284c7', '#0369a1'];
      case 'sunset':
        return ['#c2410c', '#ea580c', '#e11d48', '#d97706', '#db2777'];
      case 'monochrome':
        return ['#18181b', '#3f3f46', '#52525b', '#71717a', '#27272a'];
      case 'emerald':
      default:
        return ['#0f766e', '#0d9488', '#14b8a6', '#059669', '#10b981'];
    }
  }, [colorTheme]);

  // Tree measurement & layout algorithms
  const { nodes, edges, bounds } = useMemo(() => {
    const calculatedNodes: RenderNode[] = [];
    const calculatedEdges: RenderEdge[] = [];

    const rootWidth = 220;
    const rootHeight = 56;
    const branchWidth = 190;
    const branchHeight = 44;
    const leafWidth = 170;
    const leafHeight = 36;

    let minX = Infinity;
    let maxX = -Infinity;
    let minY = Infinity;
    let maxY = -Infinity;

    const updateBounds = (x: number, y: number, w: number, h: number) => {
      minX = Math.min(minX, x - w / 2);
      maxX = Math.max(maxX, x + w / 2);
      minY = Math.min(minY, y - h / 2);
      maxY = Math.max(maxY, y + h / 2);
    };

    if (layout === 'rtl' || layout === 'ltr') {
      const isRTL = layout === 'rtl';
      const rootX = 0;
      const rootY = 0;
      calculatedNodes.push({
        id: data.id,
        title: data.title,
        level: 0,
        color: themeColors[0],
        x: rootX,
        y: rootY,
        width: rootWidth,
        height: rootHeight,
        childrenCount: data.children?.length || 0,
        rawNode: data,
      });
      updateBounds(rootX, rootY, rootWidth, rootHeight);

      const branches = data.children || [];
      const totalBranches = branches.length;
      const verticalSpacing = 110;
      const startY = -((totalBranches - 1) * verticalSpacing) / 2;

      branches.forEach((b, bIdx) => {
        const bX = isRTL ? -290 : 290;
        const bY = startY + bIdx * verticalSpacing;
        const bColor = themeColors[(bIdx % (themeColors.length - 1)) + 1];

        calculatedNodes.push({
          id: b.id,
          title: b.title,
          level: 1,
          color: bColor,
          x: bX,
          y: bY,
          width: branchWidth,
          height: branchHeight,
          parentId: data.id,
          childrenCount: b.children?.length || 0,
          rawNode: b,
        });
        updateBounds(bX, bY, branchWidth, branchHeight);

        calculatedEdges.push({
          id: `${data.id}->${b.id}`,
          sourceX: isRTL ? rootX - rootWidth / 2 : rootX + rootWidth / 2,
          sourceY: rootY,
          targetX: isRTL ? bX + branchWidth / 2 : bX - branchWidth / 2,
          targetY: bY,
          color: bColor,
        });

        // Subtopics
        const leaves = b.children || [];
        const leafCount = leaves.length;
        const leafSpacing = 52;
        const leafStartY = bY - ((leafCount - 1) * leafSpacing) / 2;

        leaves.forEach((leaf, lIdx) => {
          const lX = isRTL ? bX - 250 : bX + 250;
          const lY = leafStartY + lIdx * leafSpacing;

          calculatedNodes.push({
            id: leaf.id,
            title: leaf.title,
            level: 2,
            color: bColor,
            x: lX,
            y: lY,
            width: leafWidth,
            height: leafHeight,
            parentId: b.id,
            childrenCount: leaf.children?.length || 0,
            rawNode: leaf,
          });
          updateBounds(lX, lY, leafWidth, leafHeight);

          calculatedEdges.push({
            id: `${b.id}->${leaf.id}`,
            sourceX: isRTL ? bX - branchWidth / 2 : bX + branchWidth / 2,
            sourceY: bY,
            targetX: isRTL ? lX + leafWidth / 2 : lX - leafWidth / 2,
            targetY: lY,
            color: bColor,
          });
        });
      });
    } else if (layout === 'radial') {
      // Radial Layout: 360 degrees around center
      const rootX = 0;
      const rootY = 0;
      calculatedNodes.push({
        id: data.id,
        title: data.title,
        level: 0,
        color: themeColors[0],
        x: rootX,
        y: rootY,
        width: rootWidth,
        height: rootHeight,
        childrenCount: data.children?.length || 0,
        rawNode: data,
      });
      updateBounds(rootX, rootY, rootWidth, rootHeight);

      const branches = data.children || [];
      const branchRadius = 280;
      const leafRadius = 490;

      branches.forEach((b, bIdx) => {
        const angle = (bIdx / Math.max(branches.length, 1)) * 2 * Math.PI - Math.PI / 2;
        const bX = Math.cos(angle) * branchRadius;
        const bY = Math.sin(angle) * branchRadius;
        const bColor = themeColors[(bIdx % (themeColors.length - 1)) + 1];

        calculatedNodes.push({
          id: b.id,
          title: b.title,
          level: 1,
          color: bColor,
          x: bX,
          y: bY,
          width: branchWidth,
          height: branchHeight,
          parentId: data.id,
          childrenCount: b.children?.length || 0,
          rawNode: b,
        });
        updateBounds(bX, bY, branchWidth, branchHeight);

        calculatedEdges.push({
          id: `${data.id}->${b.id}`,
          sourceX: rootX,
          sourceY: rootY,
          targetX: bX,
          targetY: bY,
          color: bColor,
        });

        // Subtopics fan out around branch angle
        const leaves = b.children || [];
        const leafSpread = 0.45; // angle spread
        const leafAngleStart = angle - leafSpread / 2;
        const leafStep = leaves.length > 1 ? leafSpread / (leaves.length - 1) : 0;

        leaves.forEach((leaf, lIdx) => {
          const lAngle = leaves.length === 1 ? angle : leafAngleStart + lIdx * leafStep;
          const lX = Math.cos(lAngle) * leafRadius;
          const lY = Math.sin(lAngle) * leafRadius;

          calculatedNodes.push({
            id: leaf.id,
            title: leaf.title,
            level: 2,
            color: bColor,
            x: lX,
            y: lY,
            width: leafWidth,
            height: leafHeight,
            parentId: b.id,
            childrenCount: leaf.children?.length || 0,
            rawNode: leaf,
          });
          updateBounds(lX, lY, leafWidth, leafHeight);

          calculatedEdges.push({
            id: `${b.id}->${leaf.id}`,
            sourceX: bX,
            sourceY: bY,
            targetX: lX,
            targetY: lY,
            color: bColor,
          });
        });
      });
    } else {
      // Top-Down Tree / Bottom-Up Tree
      const isTopDown = layout === 'tree';
      const rootX = 0;
      const rootY = isTopDown ? -200 : 200;

      calculatedNodes.push({
        id: data.id,
        title: data.title,
        level: 0,
        color: themeColors[0],
        x: rootX,
        y: rootY,
        width: rootWidth,
        height: rootHeight,
        childrenCount: data.children?.length || 0,
        rawNode: data,
      });
      updateBounds(rootX, rootY, rootWidth, rootHeight);

      const branches = data.children || [];
      const branchSpacing = 240;
      const startX = -((branches.length - 1) * branchSpacing) / 2;
      const branchY = isTopDown ? 0 : 0;

      branches.forEach((b, bIdx) => {
        const bX = startX + bIdx * branchSpacing;
        const bY = branchY;
        const bColor = themeColors[(bIdx % (themeColors.length - 1)) + 1];

        calculatedNodes.push({
          id: b.id,
          title: b.title,
          level: 1,
          color: bColor,
          x: bX,
          y: bY,
          width: branchWidth,
          height: branchHeight,
          parentId: data.id,
          childrenCount: b.children?.length || 0,
          rawNode: b,
        });
        updateBounds(bX, bY, branchWidth, branchHeight);

        calculatedEdges.push({
          id: `${data.id}->${b.id}`,
          sourceX: rootX,
          sourceY: isTopDown ? rootY + rootHeight / 2 : rootY - rootHeight / 2,
          targetX: bX,
          targetY: isTopDown ? bY - branchHeight / 2 : bY + branchHeight / 2,
          color: bColor,
        });

        // Leaves below branch
        const leaves = b.children || [];
        leaves.forEach((leaf, lIdx) => {
          const lX = bX;
          const lY = isTopDown ? bY + 90 + lIdx * 54 : bY - 90 - lIdx * 54;

          calculatedNodes.push({
            id: leaf.id,
            title: leaf.title,
            level: 2,
            color: bColor,
            x: lX,
            y: lY,
            width: leafWidth,
            height: leafHeight,
            parentId: b.id,
            childrenCount: leaf.children?.length || 0,
            rawNode: leaf,
          });
          updateBounds(lX, lY, leafWidth, leafHeight);

          // Connect first leaf to branch bottom, subsequent leaves to previous leaf bottom
          const sourceNodeY = lIdx === 0
            ? (isTopDown ? bY + branchHeight / 2 : bY - branchHeight / 2)
            : (isTopDown ? (bY + 90 + (lIdx - 1) * 54) + leafHeight / 2 : (bY - 90 - (lIdx - 1) * 54) - leafHeight / 2);

          calculatedEdges.push({
            id: lIdx === 0 ? `${b.id}->${leaf.id}` : `${leaves[lIdx - 1].id}->${leaf.id}`,
            sourceX: bX,
            sourceY: sourceNodeY,
            targetX: lX,
            targetY: isTopDown ? lY - leafHeight / 2 : lY + leafHeight / 2,
            color: bColor,
          });
        });
      });
    }

    const padding = 100;
    return {
      nodes: calculatedNodes,
      edges: calculatedEdges,
      bounds: {
        minX: minX - padding,
        maxX: maxX + padding,
        minY: minY - padding,
        maxY: maxY + padding,
        width: Math.max(maxX - minX + padding * 2, 800),
        height: Math.max(maxY - minY + padding * 2, 600),
      },
    };
  }, [data, layout, themeColors]);

  // Fit to screen function
  const handleFitToScreen = () => {
    if (!containerRef.current) return;
    const { clientWidth, clientHeight } = containerRef.current;
    const scaleX = (clientWidth - 80) / bounds.width;
    const scaleY = (clientHeight - 80) / bounds.height;
    const newZoom = Math.max(0.3, Math.min(1.4, Math.min(scaleX, scaleY)));
    setZoom(newZoom);
    setPan({ x: 0, y: 0 });
  };

  // Reset view
  const handleResetView = () => {
    setZoom(1);
    setPan({ x: 0, y: 0 });
  };

  // Drag pan handlers
  const handleMouseDown = (e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest('.mindmap-node-action')) return;
    setIsDragging(true);
    setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    setPan({
      x: e.clientX - dragStart.x,
      y: e.clientY - dragStart.y,
    });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  // Node editing actions
  const handleStartEdit = (node: RenderNode | MindMapNode, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const raw = 'rawNode' in node ? node.rawNode : node;
    setEditingNodeId(node.id);
    setEditTitle(node.title);
    setEditNotes(raw.notes || '');
    setEditFormula(raw.formula || '');
    setEditBadge(raw.badge || '');
  };

  const handleSaveEdit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!editingNodeId || !editTitle.trim()) {
      setEditingNodeId(null);
      return;
    }

    const updateRecursive = (cur: MindMapNode): MindMapNode => {
      if (cur.id === editingNodeId) {
        return {
          ...cur,
          title: editTitle.trim(),
          notes: editNotes.trim(),
          formula: editFormula.trim(),
          badge: editBadge.trim(),
        };
      }
      return {
        ...cur,
        children: cur.children?.map(updateRecursive),
      };
    };

    const updated = updateRecursive(data);
    setData(updated);
    if (onSave) onSave(updated);
    setEditingNodeId(null);
  };

  const handleAddChild = (parentNodeId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const newId = 'n_' + Math.random().toString(36).substring(2, 9);
    const newChild: MindMapNode = {
      id: newId,
      title: 'فرع جديد',
      level: 2,
    };

    const addRecursive = (cur: MindMapNode): MindMapNode => {
      if (cur.id === parentNodeId) {
        return {
          ...cur,
          children: [...(cur.children || []), newChild],
        };
      }
      return {
        ...cur,
        children: cur.children?.map(addRecursive),
      };
    };

    const updated = addRecursive(data);
    setData(updated);
    if (onSave) onSave(updated);
    setEditingNodeId(newId);
    setEditTitle('فرع جديد');
  };

  const handleDeleteNode = (nodeId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (nodeId === data.id) {
      alert('لا يمكن حذف الفكرة المركزية الرئيسية.');
      return;
    }

    const deleteRecursive = (cur: MindMapNode): MindMapNode => {
      return {
        ...cur,
        children: cur.children
          ?.filter((c) => c.id !== nodeId)
          .map(deleteRecursive),
      };
    };

    const updated = deleteRecursive(data);
    setData(updated);
    if (onSave) onSave(updated);
  };

  // Export SVG
  const handleExportSVG = () => {
    if (!svgRef.current) return;
    const svgClone = svgRef.current.cloneNode(true) as SVGSVGElement;
    svgClone.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
    const svgString = new XMLSerializer().serializeToString(svgClone);
    const blob = new Blob([svgString], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `mindmap-${data.title.replace(/\s+/g, '_')}.svg`;
    link.click();
    URL.revokeObjectURL(url);
  };

  // Export PNG (High Resolution)
  const handleExportPNG = () => {
    if (!svgRef.current) return;
    const svgString = new XMLSerializer().serializeToString(svgRef.current);
    const svgBlob = new Blob([svgString], { type: 'image/svg+xml;charset=utf-8' });
    const URLObject = window.URL || window.webkitURL || window;
    const blobURL = URLObject.createObjectURL(svgBlob);

    const image = new Image();
    image.onload = () => {
      const canvas = document.createElement('canvas');
      const scale = 2; // 2x high resolution
      canvas.width = bounds.width * scale;
      canvas.height = bounds.height * scale;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.scale(scale, scale);
        ctx.drawImage(image, 0, 0);
        const pngUrl = canvas.toDataURL('image/png');
        const link = document.createElement('a');
        link.href = pngUrl;
        link.download = `mindmap-${data.title.replace(/\s+/g, '_')}.png`;
        link.click();
      }
      URLObject.revokeObjectURL(blobURL);
    };
    image.src = blobURL;
  };

  // Native Print with Print-Ready Styles
  const handlePrint = () => {
    window.print();
  };

  // Find selected node details
  const selectedNodeObject = useMemo(() => {
    if (!selectedNodeId) return null;
    const findNode = (cur: MindMapNode): MindMapNode | null => {
      if (cur.id === selectedNodeId) return cur;
      for (const child of cur.children || []) {
        const found = findNode(child);
        if (found) return found;
      }
      return null;
    };
    return findNode(data);
  }, [selectedNodeId, data]);

  // Filtered branches for matrix breakdown
  const filteredBranches = useMemo(() => {
    const list = data.children || [];
    if (!matrixSearch.trim()) return list;
    const q = matrixSearch.toLowerCase();
    return list.filter((b) => {
      const inTitle = b.title.toLowerCase().includes(q);
      const inNotes = (b.notes || '').toLowerCase().includes(q);
      const inFormula = (b.formula || '').toLowerCase().includes(q);
      const inChildren = (b.children || []).some(
        (c) =>
          c.title.toLowerCase().includes(q) ||
          (c.notes || '').toLowerCase().includes(q) ||
          (c.formula || '').toLowerCase().includes(q)
      );
      return inTitle || inNotes || inFormula || inChildren;
    });
  }, [data, matrixSearch]);

  return (
    <div className="space-y-4">
      {/* Mind Map Toolbar */}
      <div className="bg-white dark:bg-[#14201c] p-3 rounded-2xl border border-[#e2e8e5] dark:border-[#22352f] flex flex-wrap items-center justify-between gap-3 shadow-xs no-print">
        {/* View Switcher: Diagram Canvas vs Academic Matrix */}
        <div className="flex items-center gap-1 bg-[#f6f8f7] dark:bg-[#1a2723] p-1 rounded-xl">
          <button
            type="button"
            onClick={() => setActiveMindMapView('canvas')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeMindMapView === 'canvas'
                ? 'bg-white dark:bg-[#121b18] text-[#0f766e] dark:text-[#2dd4bf] shadow-xs'
                : 'text-[#596762] dark:text-[#9ab3ab] hover:text-[#0f766e]'
            }`}
          >
            <GitFork className="w-3.5 h-3.5" />
            <span>المخطط الشبكي التفاعلي</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveMindMapView('breakdown')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeMindMapView === 'breakdown'
                ? 'bg-white dark:bg-[#121b18] text-[#0f766e] dark:text-[#2dd4bf] shadow-xs'
                : 'text-[#596762] dark:text-[#9ab3ab] hover:text-[#0f766e]'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>مصفوفة المحاور والقوانين التفصيلية</span>
          </button>
        </div>

        {/* Layout Switcher (shown in canvas mode) */}
        {activeMindMapView === 'canvas' && (
          <div className="flex items-center gap-1.5 bg-[#f6f8f7] dark:bg-[#1a2723] p-1 rounded-xl">
            <span className="text-[11px] font-bold text-[#596762] dark:text-[#9ab3ab] px-2 flex items-center gap-1">
              <Layout className="w-3.5 h-3.5" />
              التخطيط:
            </span>
            <button
              id="layout-tree-btn"
              onClick={() => {
                setLayout('tree');
                setTimeout(() => handleFitToScreen(), 80);
              }}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                layout === 'tree'
                  ? 'bg-white dark:bg-[#121b18] text-[#0f766e] dark:text-[#2dd4bf] shadow-xs'
                  : 'text-[#596762] dark:text-[#9ab3ab]'
              }`}
              title="هيكل شجري هرمي للمفاهيم الأساسية (Visual Tree Layout)"
            >
              <GitFork className="w-3.5 h-3.5 rotate-180 text-[#0f766e] dark:text-[#2dd4bf]" />
              <span>شجرة المفاهيم (Tree)</span>
            </button>
            <button
              onClick={() => setLayout('rtl')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                layout === 'rtl'
                  ? 'bg-white dark:bg-[#121b18] text-[#0f766e] dark:text-[#2dd4bf] shadow-xs'
                  : 'text-[#596762] dark:text-[#9ab3ab]'
              }`}
              title="يمين إلى يسار (أفقي عربي)"
            >
              يمين (RTL)
            </button>
            <button
              onClick={() => setLayout('radial')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                layout === 'radial'
                  ? 'bg-white dark:bg-[#121b18] text-[#0f766e] dark:text-[#2dd4bf] shadow-xs'
                  : 'text-[#596762] dark:text-[#9ab3ab]'
              }`}
              title="شعاعي دائري"
            >
              شعاعي
            </button>
            <button
              onClick={() => setLayout('ltr')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                layout === 'ltr'
                  ? 'bg-white dark:bg-[#121b18] text-[#0f766e] dark:text-[#2dd4bf] shadow-xs'
                  : 'text-[#596762] dark:text-[#9ab3ab]'
              }`}
              title="يسار إلى يمين"
            >
              يسار
            </button>
          </div>
        )}

        {/* Color Palette Selector (shown in canvas mode) */}
        {activeMindMapView === 'canvas' && (
          <div className="flex items-center gap-1.5">
            <Palette className="w-3.5 h-3.5 text-[#596762] dark:text-[#9ab3ab]" />
            <select
              value={colorTheme}
              onChange={(e: any) => setColorTheme(e.target.value)}
              className="px-2.5 py-1 bg-[#f6f8f7] dark:bg-[#1a2723] border border-[#e2e8e5] dark:border-[#22352f] rounded-lg text-xs font-bold text-[#17201e] dark:text-[#eef7f4]"
            >
              <option value="emerald">زمردي تعليمي</option>
              <option value="navy">أزرق ملكي</option>
              <option value="sunset">دافئ هادئ</option>
              <option value="monochrome">أبيض وأسود للطباعة</option>
            </select>
          </div>
        )}

        {/* Zoom & Navigation controls (shown in canvas mode) */}
        {activeMindMapView === 'canvas' && (
          <div className="flex items-center gap-1 bg-[#f6f8f7] dark:bg-[#1a2723] p-1 rounded-xl">
            <button
              onClick={() => setZoom((z) => Math.max(0.3, z - 0.15))}
              className="p-1.5 rounded-lg text-[#596762] dark:text-[#9ab3ab] hover:bg-white dark:hover:bg-[#121b18]"
              title="تصغير"
            >
              <ZoomOut className="w-4 h-4" />
            </button>
            <span className="text-[11px] font-mono font-bold px-2 text-[#17201e] dark:text-[#eef7f4]">
              {Math.round(zoom * 100)}%
            </span>
            <button
              onClick={() => setZoom((z) => Math.min(2.5, z + 0.15))}
              className="p-1.5 rounded-lg text-[#596762] dark:text-[#9ab3ab] hover:bg-white dark:hover:bg-[#121b18]"
              title="تكبير"
            >
              <ZoomIn className="w-4 h-4" />
            </button>
            <button
              onClick={handleFitToScreen}
              className="p-1.5 rounded-lg text-[#596762] dark:text-[#9ab3ab] hover:bg-white dark:hover:bg-[#121b18]"
              title="ملاءمة الشاشة"
            >
              <Maximize2 className="w-4 h-4" />
            </button>
            <button
              onClick={handleResetView}
              className="p-1.5 rounded-lg text-[#596762] dark:text-[#9ab3ab] hover:bg-white dark:hover:bg-[#121b18]"
              title="إعادة ضبط"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Academic PDF & Export actions */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            id="export-mindmap-pdf-btn"
            onClick={() => {
              setIsAcademicPrintOpen(true);
              onExportPdf?.();
            }}
            className="px-3.5 py-1.5 bg-gradient-to-r from-[#0f766e] to-[#0284c7] text-white rounded-xl text-xs font-bold hover:opacity-95 flex items-center gap-1.5 shadow-sm cursor-pointer"
            title="Export to PDF - طباعة وتصدير شجرة المفاهيم كدليل دراسي أكاديمي منظم (academic-report-style)"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Export to PDF (دليل دراسي أكاديمي)</span>
          </button>

          <button
            onClick={handlePrint}
            className="px-3 py-1.5 border border-[#e2e8e5] dark:border-[#22352f] text-[#596762] dark:text-[#9ab3ab] rounded-xl text-xs font-bold hover:bg-gray-50 dark:hover:bg-gray-800 flex items-center gap-1.5 shadow-xs cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>طباعة سريعة</span>
          </button>

          <div className="relative group">
            <button className="px-3 py-1.5 border border-[#e2e8e5] dark:border-[#22352f] text-[#596762] dark:text-[#9ab3ab] rounded-xl text-xs font-bold hover:bg-gray-50 dark:hover:bg-gray-800 flex items-center gap-1.5">
              <Download className="w-3.5 h-3.5" />
              <span>تنزيل صورة</span>
            </button>
            <div className="absolute left-0 mt-1 w-32 bg-white dark:bg-[#1a2723] border border-[#e2e8e5] dark:border-[#22352f] rounded-xl shadow-lg py-1 hidden group-hover:block z-30">
              <button
                onClick={handleExportPNG}
                className="w-full text-right px-3 py-1.5 text-xs font-bold text-gray-700 dark:text-gray-200 hover:bg-teal-50 dark:hover:bg-teal-950"
              >
                صورة PNG عالية الدقة
              </button>
              <button
                onClick={handleExportSVG}
                className="w-full text-right px-3 py-1.5 text-xs font-bold text-gray-700 dark:text-gray-200 hover:bg-teal-50 dark:hover:bg-teal-950"
              >
                ملف متجهي SVG
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Active View: Canvas vs Breakdown Matrix */}
      {activeMindMapView === 'canvas' ? (
        <div className="space-y-4">
          {/* Interactive Canvas */}
          <div
            ref={containerRef}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseUp}
            className={`relative w-full h-[580px] bg-[#fafcfb] dark:bg-[#0e1614] border border-[#e2e8e5] dark:border-[#22352f] rounded-2xl overflow-hidden cursor-${
              isDragging ? 'grabbing' : 'grab'
            } select-none print:h-auto print:border-none print:bg-white`}
          >
            {/* Quick helper tip */}
            <div className="absolute top-3 right-3 z-10 pointer-events-none bg-white/85 dark:bg-black/60 backdrop-blur-xs px-2.5 py-1 rounded-lg border border-gray-200/60 dark:border-gray-800 text-[10px] text-[#596762] dark:text-[#9ab3ab] flex items-center gap-1 shadow-xs">
              <span>💡 انقر على أي عقدة لعرض الشرح والمعادلات التفصيلية</span>
            </div>
        {/* Subtle grid background */}
        <div 
          className="absolute inset-0 opacity-[0.04] dark:opacity-[0.08] pointer-events-none"
          style={{
            backgroundImage: `radial-gradient(#0f766e 1px, transparent 1px)`,
            backgroundSize: '24px 24px'
          }}
        />

        {/* Viewport SVG Layer */}
        <svg
          ref={svgRef}
          viewBox={`${bounds.minX} ${bounds.minY} ${bounds.width} ${bounds.height}`}
          className="w-full h-full"
          style={{
            transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
            transformOrigin: 'center center',
            transition: isDragging ? 'none' : 'transform 0.15s ease-out',
          }}
        >
          <defs>
            <filter id="node-shadow" x="-10%" y="-10%" width="120%" height="130%">
              <feDropShadow dx="0" dy="2" stdDeviation="3" floodOpacity="0.08" />
            </filter>
            <filter id="root-glow" x="-20%" y="-20%" width="140%" height="140%">
              <feDropShadow dx="0" dy="4" stdDeviation="6" floodColor={themeColors[0]} floodOpacity="0.25" />
            </filter>
          </defs>

          {/* Connectors (Smooth Cubic Bezier Curves) */}
          <g className="edges">
            {edges.map((edge) => {
              const dx = edge.targetX - edge.sourceX;
              const dy = edge.targetY - edge.sourceY;
              
              let pathData = '';
              if (layout === 'rtl' || layout === 'ltr') {
                const cX1 = edge.sourceX + dx * 0.5;
                const cY1 = edge.sourceY;
                const cX2 = edge.sourceX + dx * 0.5;
                const cY2 = edge.targetY;
                pathData = `M ${edge.sourceX} ${edge.sourceY} C ${cX1} ${cY1}, ${cX2} ${cY2}, ${edge.targetX} ${edge.targetY}`;
              } else if (layout === 'radial') {
                pathData = `M ${edge.sourceX} ${edge.sourceY} Q ${(edge.sourceX + edge.targetX) / 2} ${(edge.sourceY + edge.targetY) / 2} ${edge.targetX} ${edge.targetY}`;
              } else {
                // Tree vertical
                const cX1 = edge.sourceX;
                const cY1 = edge.sourceY + dy * 0.5;
                const cX2 = edge.targetX;
                const cY2 = edge.sourceY + dy * 0.5;
                pathData = `M ${edge.sourceX} ${edge.sourceY} C ${cX1} ${cY1}, ${cX2} ${cY2}, ${edge.targetX} ${edge.targetY}`;
              }

              return (
                <path
                  key={edge.id}
                  d={pathData}
                  fill="none"
                  stroke={edge.color}
                  strokeWidth="2.5"
                  strokeOpacity="0.65"
                  strokeLinecap="round"
                />
              );
            })}
          </g>

          {/* Nodes Layer */}
          <g className="nodes">
            {nodes.map((node) => {
              const isRoot = node.level === 0;
              const isBranch = node.level === 1;
              const isSelected = selectedNodeId === node.id;

              return (
                <g
                  key={node.id}
                  transform={`translate(${node.x}, ${node.y})`}
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedNodeId(node.id);
                  }}
                  className="cursor-pointer group"
                >
                  {/* Node Capsule Background */}
                  <rect
                    x={-node.width / 2}
                    y={-node.height / 2}
                    width={node.width}
                    height={node.height}
                    rx={isRoot ? 20 : isBranch ? 14 : 10}
                    fill={isRoot ? node.color : '#ffffff'}
                    stroke={node.color}
                    strokeWidth={isRoot ? 0 : isSelected ? 3 : 2}
                    filter={isRoot ? 'url(#root-glow)' : 'url(#node-shadow)'}
                    className="transition-all"
                  />

                  {/* Level Tag / Badge */}
                  {isBranch && (
                    <rect
                      x={-node.width / 2 + 8}
                      y={-node.height / 2 + 8}
                      width={6}
                      height={node.height - 16}
                      rx={3}
                      fill={node.color}
                    />
                  )}

                  {/* Classification Badge Tag */}
                  {!isRoot && node.rawNode.badge && (
                    <g transform={`translate(${0}, ${-node.height / 2 - 7})`}>
                      <rect
                        x={-Math.min(node.rawNode.badge.length * 4.5 + 8, 48)}
                        y={-7}
                        width={Math.min(node.rawNode.badge.length * 9 + 16, 96)}
                        height={14}
                        rx={7}
                        fill="#ffffff"
                        stroke={node.color}
                        strokeWidth={1.2}
                      />
                      <text
                        x={0}
                        y={3}
                        dominantBaseline="middle"
                        textAnchor="middle"
                        fill={node.color}
                        fontSize={8.5}
                        fontWeight="bold"
                        fontFamily="Cairo, system-ui, sans-serif"
                      >
                        {node.rawNode.badge.length > 14 ? node.rawNode.badge.slice(0, 13) + '..' : node.rawNode.badge}
                      </text>
                    </g>
                  )}

                  {/* Formula Symbol indicator */}
                  {node.rawNode.formula && (
                    <g transform={`translate(${-node.width / 2 + 14}, ${0})`}>
                      <title>يحتوي على صيغة رياضية/علمية</title>
                      <circle r={7.5} fill="#0284c7" />
                      <text
                        x={0}
                        y={3}
                        dominantBaseline="middle"
                        textAnchor="middle"
                        fill="#ffffff"
                        fontSize={9}
                        fontWeight="bold"
                      >
                        Σ
                      </text>
                    </g>
                  )}

                  {/* Node Label Text */}
                  <text
                    x={isBranch ? 4 : 0}
                    y={1}
                    dominantBaseline="middle"
                    textAnchor="middle"
                    fill={isRoot ? '#ffffff' : '#17201e'}
                    fontWeight={isRoot ? 'bold' : isBranch ? '600' : '500'}
                    fontSize={isRoot ? 14 : isBranch ? 12 : 11}
                    fontFamily="Cairo, system-ui, sans-serif"
                    className="select-none"
                  >
                    {node.title.length > 26 ? node.title.slice(0, 24) + '...' : node.title}
                  </text>

                  {/* Children count pill */}
                  {node.childrenCount > 0 && !isRoot && (
                    <circle
                      cx={node.width / 2 - 8}
                      cy={-node.height / 2 + 8}
                      r={7}
                      fill={node.color}
                    />
                  )}
                  {node.childrenCount > 0 && !isRoot && (
                    <text
                      x={node.width / 2 - 8}
                      y={-node.height / 2 + 9}
                      dominantBaseline="middle"
                      textAnchor="middle"
                      fill="#ffffff"
                      fontSize="9"
                      fontWeight="bold"
                    >
                      {node.childrenCount}
                    </text>
                  )}

                  {/* Interactive Action Buttons on Hover or Selection */}
                  {!readOnly && (
                    <g
                      className={`mindmap-node-action opacity-0 group-hover:opacity-100 transition-opacity ${
                        isSelected ? 'opacity-100' : ''
                      }`}
                      transform={`translate(${node.width / 2 + 10}, ${-node.height / 2})`}
                    >
                      {/* Add child button */}
                      <circle
                        cx={8}
                        cy={8}
                        r={11}
                        fill="#0f766e"
                        className="hover:scale-110 transition-transform cursor-pointer"
                        onClick={(e) => handleAddChild(node.id, e as any)}
                      />
                      <text
                        x={8}
                        y={9}
                        dominantBaseline="middle"
                        textAnchor="middle"
                        fill="#ffffff"
                        fontSize="12"
                        fontWeight="bold"
                        onClick={(e) => handleAddChild(node.id, e as any)}
                      >
                        +
                      </text>

                      {/* Edit button */}
                      <circle
                        cx={34}
                        cy={8}
                        r={11}
                        fill="#0284c7"
                        className="hover:scale-110 transition-transform cursor-pointer"
                        onClick={(e) => handleStartEdit(node, e as any)}
                      />
                      <text
                        x={34}
                        y={9}
                        dominantBaseline="middle"
                        textAnchor="middle"
                        fill="#ffffff"
                        fontSize="10"
                        fontWeight="bold"
                        onClick={(e) => handleStartEdit(node, e as any)}
                      >
                        ✎
                      </text>

                      {/* Delete button (except root) */}
                      {!isRoot && (
                        <>
                          <circle
                            cx={60}
                            cy={8}
                            r={11}
                            fill="#ef4444"
                            className="hover:scale-110 transition-transform cursor-pointer"
                            onClick={(e) => handleDeleteNode(node.id, e as any)}
                          />
                          <text
                            x={60}
                            y={9}
                            dominantBaseline="middle"
                            textAnchor="middle"
                            fill="#ffffff"
                            fontSize="11"
                            fontWeight="bold"
                            onClick={(e) => handleDeleteNode(node.id, e as any)}
                          >
                            ×
                          </text>
                        </>
                      )}
                    </g>
                  )}
                </g>
              );
            })}
          </g>
        </svg>
      </div>

          {/* Selected Node Academic Inspector Card */}
          {selectedNodeObject && (
            <div className="bg-white dark:bg-[#14201c] p-4 sm:p-5 rounded-2xl border-2 border-[#0f766e]/30 dark:border-[#2dd4bf]/30 shadow-md space-y-3 animate-in fade-in slide-in-from-top-2">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-gray-100 dark:border-gray-800 pb-3">
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-teal-50 dark:bg-teal-950 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-800">
                    {selectedNodeObject.level === 0 ? '🌟 الفكرة المركزية' : selectedNodeObject.level === 1 ? '📌 محور رئيسي' : '↳ عنصر فرعي'}
                  </span>
                  {selectedNodeObject.badge && (
                    <span className="px-2 py-0.5 rounded-md text-[11px] font-bold bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800">
                      {selectedNodeObject.badge}
                    </span>
                  )}
                  <h4 className="text-sm sm:text-base font-extrabold text-[#17201e] dark:text-[#eef7f4]">
                    {selectedNodeObject.title}
                  </h4>
                </div>

                <div className="flex items-center gap-2">
                  {!readOnly && (
                    <>
                      <button
                        type="button"
                        onClick={() => handleStartEdit(selectedNodeObject)}
                        className="px-3 py-1 bg-teal-50 dark:bg-teal-950 text-teal-800 dark:text-teal-200 border border-teal-200 rounded-lg text-xs font-bold hover:bg-teal-100 flex items-center gap-1 cursor-pointer"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                        <span>تعديل الشرح والمعادلات</span>
                      </button>
                      <button
                        type="button"
                        onClick={(e) => handleAddChild(selectedNodeObject.id, e)}
                        className="px-3 py-1 bg-[#0f766e] text-white rounded-lg text-xs font-bold hover:bg-[#115e59] flex items-center gap-1 cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>إضافة تفرع</span>
                      </button>
                    </>
                  )}
                  <button
                    type="button"
                    onClick={() => setSelectedNodeId(null)}
                    className="p-1 text-gray-400 hover:text-gray-600 rounded-lg cursor-pointer"
                    title="إغلاق التحديد"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Node Formula if present */}
              {selectedNodeObject.formula && (
                <div className="p-3 bg-blue-50/70 dark:bg-blue-950/30 rounded-xl border border-blue-200 dark:border-blue-900">
                  <div className="text-[11px] font-bold text-blue-800 dark:text-blue-300 mb-1 flex items-center gap-1">
                    <Sigma className="w-3.5 h-3.5" />
                    <span>القانون أو الصيغة الرياضية / العلمية:</span>
                  </div>
                  <EducationalContent content={`$$${selectedNodeObject.formula}$$`} />
                </div>
              )}

              {/* Node Notes */}
              <div>
                <div className="text-[11px] font-bold text-gray-500 dark:text-gray-400 mb-1 flex items-center gap-1">
                  <BookOpen className="w-3.5 h-3.5 text-[#0f766e]" />
                  <span>الشرح والتفصيل العلمي للعنصر:</span>
                </div>
                {selectedNodeObject.notes ? (
                  <div className="text-xs sm:text-sm text-gray-800 dark:text-gray-200 leading-relaxed bg-gray-50 dark:bg-[#1a2723] p-3 rounded-xl border border-gray-200/70 dark:border-gray-800">
                    <EducationalContent content={selectedNodeObject.notes} />
                  </div>
                ) : (
                  <p className="text-xs text-gray-400 italic">لا توجد ملاحظات أو شروحات إضافية مسجلة لهذا العنصر بعد. انقر على «تعديل الشرح والمعادلات» لكتابة تفاصيل دقيقة.</p>
                )}
              </div>
            </div>
          )}
        </div>
      ) : (
        /* Breakdown Matrix Mode (Comprehensive Academic Table & Cards) */
        <div className="bg-white dark:bg-[#14201c] p-6 rounded-2xl border border-[#e2e8e5] dark:border-[#22352f] shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-gray-100 dark:border-gray-800">
            <div>
              <h3 className="font-extrabold text-base text-[#17201e] dark:text-[#eef7f4] flex items-center gap-2">
                <Layers className="w-5 h-5 text-[#0f766e] dark:text-[#2dd4bf]" />
                <span>مصفوفة المحاور والقوانين التفصيلية الشاملة</span>
              </h3>
              <p className="text-xs text-[#596762] dark:text-[#9ab3ab]">
                عرض أكاديمي منظم يبرز كافة فروع الخريطة، شروحاتها، معادلاتها، وتصنيفاتها العلمية في نموذج دراسي موحد.
              </p>
            </div>

            {/* Search filter in matrix */}
            <div className="w-full sm:w-64">
              <input
                type="text"
                value={matrixSearch}
                onChange={(e) => setMatrixSearch(e.target.value)}
                placeholder="بحث في المحاور أو القوانين..."
                className="w-full px-3.5 py-1.5 bg-[#f6f8f7] dark:bg-[#1a2723] border border-[#e2e8e5] dark:border-[#22352f] rounded-xl text-xs text-[#17201e] dark:text-[#eef7f4] focus:outline-none focus:ring-2 focus:ring-[#0f766e]"
              />
            </div>
          </div>

          {/* Root Topic Card */}
          <div className="p-4 bg-teal-50/60 dark:bg-teal-950/30 rounded-2xl border border-teal-200 dark:border-teal-800/60 flex items-center justify-between">
            <div>
              <span className="text-[11px] font-bold text-teal-800 dark:text-teal-300">الفكرة المركزية العامة:</span>
              <h2 className="text-lg font-extrabold text-[#17201e] dark:text-[#eef7f4]">{data.title}</h2>
              {data.notes && <p className="text-xs text-[#596762] dark:text-[#9ab3ab] mt-1">{data.notes}</p>}
            </div>
            {!readOnly && (
              <button
                type="button"
                onClick={() => handleStartEdit(data)}
                className="px-3 py-1.5 bg-white dark:bg-[#121b18] border border-teal-200 dark:border-teal-800 text-teal-800 dark:text-teal-300 rounded-xl text-xs font-bold hover:bg-teal-50 cursor-pointer"
              >
                تعديل الجذر
              </button>
            )}
          </div>

          {/* Branches list */}
          <div className="space-y-4">
            {filteredBranches.map((branch, bi) => (
              <div
                key={branch.id}
                className="p-5 rounded-2xl border border-gray-200 dark:border-gray-800 bg-[#fbfdfc] dark:bg-[#111c19] space-y-3"
              >
                {/* Branch Header */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-[#0f766e] text-white text-xs font-bold flex items-center justify-center font-mono">
                      {bi + 1}
                    </span>
                    <h4 className="font-extrabold text-sm sm:text-base text-[#17201e] dark:text-[#eef7f4]">
                      {branch.title}
                    </h4>
                    {branch.badge && (
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-teal-100 text-teal-900 dark:bg-teal-900/40 dark:text-teal-200">
                        {branch.badge}
                      </span>
                    )}
                  </div>

                  {!readOnly && (
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => handleStartEdit(branch)}
                        className="px-2.5 py-1 text-xs font-bold text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg flex items-center gap-1 cursor-pointer"
                      >
                        <Edit3 className="w-3 h-3" />
                        <span>تعديل</span>
                      </button>
                      <button
                        type="button"
                        onClick={(e) => handleAddChild(branch.id, e)}
                        className="px-2.5 py-1 text-xs font-bold text-[#0f766e] dark:text-[#2dd4bf] hover:bg-teal-50 dark:hover:bg-teal-950 rounded-lg flex items-center gap-1 cursor-pointer"
                      >
                        <Plus className="w-3 h-3" />
                        <span>إضافة فرع</span>
                      </button>
                    </div>
                  )}
                </div>

                {/* Branch notes */}
                {branch.notes && (
                  <div className="text-xs text-gray-700 dark:text-gray-300 bg-white dark:bg-[#162320] p-3 rounded-xl border border-gray-100 dark:border-gray-800 leading-relaxed">
                    <EducationalContent content={branch.notes} />
                  </div>
                )}

                {/* Branch formula */}
                {branch.formula && (
                  <div className="p-3 bg-blue-50/50 dark:bg-blue-950/20 rounded-xl border border-blue-200/60 dark:border-blue-900/60">
                    <span className="text-[10px] font-bold text-blue-700 dark:text-blue-300 block mb-1">القانون / المعادلة:</span>
                    <EducationalContent content={`$$${branch.formula}$$`} />
                  </div>
                )}

                {/* Subtopics */}
                {branch.children && branch.children.length > 0 && (
                  <div className="pt-2">
                    <span className="text-[11px] font-bold text-gray-500 mb-2 block">الفروع والنقاط التابعة ({branch.children.length}):</span>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                      {branch.children.map((sub, si) => (
                        <div
                          key={sub.id}
                          className="p-3 bg-white dark:bg-[#162320] rounded-xl border border-gray-200/80 dark:border-gray-800 space-y-1.5"
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-1.5">
                              <span className="w-4 h-4 rounded-full bg-teal-100 dark:bg-teal-900/60 text-teal-800 dark:text-teal-200 text-[10px] font-mono flex items-center justify-center font-bold">
                                {bi + 1}.{si + 1}
                              </span>
                              <span className="text-xs font-bold text-gray-900 dark:text-gray-100">{sub.title}</span>
                            </div>
                            {sub.badge && (
                              <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300">
                                {sub.badge}
                              </span>
                            )}
                          </div>

                          {sub.notes && (
                            <div className="text-[11px] text-gray-600 dark:text-gray-400 line-clamp-3">
                              <EducationalContent content={sub.notes} />
                            </div>
                          )}

                          {sub.formula && (
                            <div className="text-[11px] text-blue-600 dark:text-blue-400 font-mono">
                              {sub.formula}
                            </div>
                          )}

                          {!readOnly && (
                            <div className="pt-1 flex justify-end">
                              <button
                                type="button"
                                onClick={() => handleStartEdit(sub)}
                                className="text-[10px] text-teal-700 dark:text-teal-300 hover:underline flex items-center gap-0.5 cursor-pointer"
                              >
                                <Edit3 className="w-2.5 h-2.5" />
                                <span>تعديل</span>
                              </button>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Floating Node Edit Modal (Rich Academic Editor) */}
      {editingNodeId && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <form
            onSubmit={handleSaveEdit}
            className="bg-white dark:bg-[#14201c] p-6 rounded-2xl border border-[#e2e8e5] dark:border-[#22352f] shadow-2xl w-full max-w-lg space-y-4 animate-in zoom-in-95"
          >
            <div className="flex items-center justify-between border-b border-gray-100 dark:border-gray-800 pb-3">
              <span className="text-sm font-extrabold text-[#17201e] dark:text-[#eef7f4] flex items-center gap-2">
                <Edit3 className="w-4 h-4 text-[#0f766e]" />
                <span>تعديل المحتوى الأكاديمي للعقدة</span>
              </span>
              <button
                type="button"
                onClick={() => setEditingNodeId(null)}
                className="p-1 text-gray-400 hover:text-gray-600 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Title */}
            <div>
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                اسم العنصر أو المحور:
              </label>
              <input
                type="text"
                autoFocus
                value={editTitle}
                onChange={(e) => setEditTitle(e.target.value)}
                placeholder="مثال: قانون نيوتن الثاني للحركة"
                className="w-full px-3.5 py-2 bg-[#f6f8f7] dark:bg-[#1a2723] border border-[#e2e8e5] dark:border-[#22352f] rounded-xl text-xs font-bold text-[#17201e] dark:text-[#eef7f4]"
              />
            </div>

            {/* Badge Category */}
            <div>
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                التصنيف الأكاديمي (Badge):
              </label>
              <div className="flex gap-2 mb-2 flex-wrap">
                {['مفهوم أساسي', 'قانون وفيزياء', 'معادلة كيميائية', 'تطبيق عملي', 'تنبيه اختبار'].map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => setEditBadge(preset)}
                    className={`text-[10px] px-2 py-0.5 rounded-lg border font-semibold cursor-pointer ${
                      editBadge === preset
                        ? 'bg-[#0f766e] text-white border-[#0f766e]'
                        : 'bg-gray-50 dark:bg-gray-800 text-gray-600 dark:text-gray-300 border-gray-200 dark:border-gray-700'
                    }`}
                  >
                    {preset}
                  </button>
                ))}
              </div>
              <input
                type="text"
                value={editBadge}
                onChange={(e) => setEditBadge(e.target.value)}
                placeholder="أو اكتب تصنيفاً خاصاً..."
                className="w-full px-3 py-1.5 bg-[#f6f8f7] dark:bg-[#1a2723] border border-[#e2e8e5] dark:border-[#22352f] rounded-xl text-xs text-[#17201e] dark:text-[#eef7f4]"
              />
            </div>

            {/* Formula (LaTeX) */}
            <div>
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1 flex items-center gap-1">
                <Sigma className="w-3.5 h-3.5 text-blue-600" />
                <span>القانون أو الصيغة الرياضية (صيغة LaTeX أو نصية - اختياري):</span>
              </label>
              <input
                type="text"
                value={editFormula}
                onChange={(e) => setEditFormula(e.target.value)}
                placeholder="مثال: F = m \\times a أو v = \\frac{\\Delta d}{\\Delta t}"
                dir="ltr"
                className="w-full px-3.5 py-2 bg-[#f6f8f7] dark:bg-[#1a2723] border border-[#e2e8e5] dark:border-[#22352f] rounded-xl text-xs font-mono text-[#17201e] dark:text-[#eef7f4]"
              />
            </div>

            {/* Notes / Detailed Explanation */}
            <div>
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1 flex items-center gap-1">
                <BookOpen className="w-3.5 h-3.5 text-[#0f766e]" />
                <span>الشرح العلمي المفصل والملاحظات الأكاديمية:</span>
              </label>
              <textarea
                rows={4}
                value={editNotes}
                onChange={(e) => setEditNotes(e.target.value)}
                placeholder="اكتب هنا التعريف الدقيق، الاستنتاج، وحدات القياس، أو أي ملاحظات هامة ترغب في تضمينها في تقرير الخريطة..."
                className="w-full px-3.5 py-2.5 bg-[#f6f8f7] dark:bg-[#1a2723] border border-[#e2e8e5] dark:border-[#22352f] rounded-xl text-xs leading-relaxed text-[#17201e] dark:text-[#eef7f4]"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-gray-100 dark:border-gray-800">
              <button
                type="button"
                onClick={() => setEditingNodeId(null)}
                className="px-4 py-2 rounded-xl text-xs text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800 font-bold cursor-pointer"
              >
                إلغاء
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-[#0f766e] text-white rounded-xl text-xs font-bold hover:bg-[#115e59] shadow-sm cursor-pointer"
              >
                حفظ التعديلات الأكاديمية
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Academic Print / PDF Modal */}
      <AcademicPrintModal
        isOpen={isAcademicPrintOpen}
        onClose={() => setIsAcademicPrintOpen(false)}
        summary={mindMapToStructuredSummary(data, notebookTitle, notebookSubject)}
      />

      {/* Print-Only Viewport Header */}
      <div className="hidden print:block text-center mb-4">
        <h1 className="text-xl font-bold text-gray-900">{data.title}</h1>
        <p className="text-xs text-gray-500">تم إنشاؤها عبر المعلم الذكي - جاهزة للمذاكرة والطباعة الأكاديمية</p>
      </div>
    </div>
  );
};
