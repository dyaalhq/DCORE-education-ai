import React, { useEffect, useRef, useState, useMemo } from 'react';
import * as d3 from 'd3';
import {
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Maximize2,
  Download,
  FileText,
  Sparkles,
  GitFork,
  Search,
  BookOpen,
  HelpCircle,
  X,
  Copy,
  Check,
  Layers,
  ChevronLeft,
  ChevronRight,
  Share2,
  Compass,
} from 'lucide-react';
import { MindMapNode, GlossaryItem, MemoItem, Source, SourceChunk, NoteItem } from '../types';
import { generateClusteredNotebookMindMap, ClusteredMindMapResult } from '../lib/d3MindMapGenerator';
import { buildDeepMindMapFromText } from '../lib/mindMapParser';
import { generateMindMapFromSingleMessageAI, generateStudioMindMapData } from '../lib/studioAiBridge';
import { EducationalContent } from './EducationalContent';
import { AcademicPrintModal } from './AcademicPrintModal';
import { mindMapToStructuredSummary, StructuredSummary } from '../lib/academicFormatter';
import { generateInteractiveMindMapHtml } from '../lib/interactiveMindMapHtml';

export type D3MindMapLayoutType = 'tree' | 'radial' | 'force';

interface D3VisualMindMapProps {
  notebookTitle: string;
  notebookSubject: string;
  glossary?: GlossaryItem[];
  memos?: MemoItem[];
  sources?: Source[];
  chunks?: SourceChunk[];
  notes?: NoteItem[];
  chatMessages?: Array<{ id: string; role: 'user' | 'model' | 'ai'; text: string; date?: number }>;
  initialData?: MindMapNode | null;
  onSave?: (data: MindMapNode) => void;
  onAskAboutConcept?: (conceptTitle: string, conceptNotes?: string) => void;
}

export const D3VisualMindMap: React.FC<D3VisualMindMapProps> = ({
  notebookTitle,
  notebookSubject,
  glossary = [],
  memos = [],
  sources = [],
  chunks = [],
  notes = [],
  chatMessages = [],
  initialData,
  onSave,
  onAskAboutConcept,
}) => {
  // 1. Mind Map Tree State
  const [data, setData] = useState<MindMapNode>(() => {
    if (initialData) return initialData;
    return generateClusteredNotebookMindMap(
      notebookTitle,
      notebookSubject,
      glossary,
      memos,
      sources,
      chunks,
      notes
    ).root;
  });

  const [layoutType, setLayoutType] = useState<D3MindMapLayoutType>('tree');
  const [selectedNode, setSelectedNode] = useState<MindMapNode | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedConcept, setCopiedConcept] = useState(false);
  const [isExportingSvg, setIsExportingSvg] = useState(false);
  const [isAcademicPrintOpen, setIsAcademicPrintOpen] = useState(false);
  const [structuredSummary, setStructuredSummary] = useState<StructuredSummary | null>(null);

  // Dynamic Collapsible Nodes State & Depth Filter
  const [collapsedNodeIds, setCollapsedNodeIds] = useState<Set<string>>(new Set());
  const [maxDisplayDepth, setMaxDisplayDepth] = useState<number>(4);
  const [isFocusMode, setIsFocusMode] = useState(false);

  // Custom text / Chat conversion modal state
  const [showTextModal, setShowTextModal] = useState(false);
  const [customText, setCustomText] = useState('');
  const [customTitle, setCustomTitle] = useState('');
  const [isAiBuildingMap, setIsAiBuildingMap] = useState(false);

  // SVG and Zoom container references
  const svgRef = useRef<SVGSVGElement | null>(null);
  const gRef = useRef<SVGGElement | null>(null);
  const zoomBehaviorRef = useRef<d3.ZoomBehavior<SVGSVGElement, unknown> | null>(null);

  useEffect(() => {
    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setSelectedNode(null);
    };
    window.addEventListener('keydown', handleEscape);
    return () => window.removeEventListener('keydown', handleEscape);
  }, []);

  const toggleCollapse = (nodeId: string) => {
    setCollapsedNodeIds((prev) => {
      const next = new Set(prev);
      if (next.has(nodeId)) {
        next.delete(nodeId);
      } else {
        next.add(nodeId);
      }
      return next;
    });
  };

  const handleExpandAll = () => {
    setCollapsedNodeIds(new Set());
    setMaxDisplayDepth(4);
  };

  const handleCollapseAll = () => {
    const ids = new Set<string>();
    const gather = (node: MindMapNode, lvl = 0) => {
      if (lvl >= 1 && node.children && node.children.length > 0) {
        ids.add(node.id);
      }
      if (node.children) node.children.forEach((c) => gather(c, lvl + 1));
    };
    if (data) gather(data, 0);
    setCollapsedNodeIds(ids);
  };

  const handleExportPng = () => {
    if (!svgRef.current) return;
    try {
      const svg = svgRef.current;
      const serializer = new XMLSerializer();
      const svgString = serializer.serializeToString(svg);
      const svgBlob = new Blob([svgString], { type: 'image/svg+xml;charset=utf-8' });
      const URLObj = window.URL || window.webkitURL || window;
      const blobURL = URLObj.createObjectURL(svgBlob);
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = (svg.clientWidth || 1200) * 2;
        canvas.height = (svg.clientHeight || 800) * 2;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.scale(2, 2);
          ctx.fillStyle = document.documentElement.classList.contains('dark') ? '#0f1715' : '#ffffff';
          ctx.fillRect(0, 0, canvas.width, canvas.height);
          ctx.drawImage(img, 0, 0);
          const pngUrl = canvas.toDataURL('image/png');
          const a = document.createElement('a');
          a.download = `خريطة_ذهنية_${(notebookTitle || 'مفاهيم').replace(/\s+/g, '_')}.png`;
          a.href = pngUrl;
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
        }
        URLObj.revokeObjectURL(blobURL);
      };
      img.src = blobURL;
    } catch (e) {
      console.warn('Failed to export PNG:', e);
    }
  };

  // Sync if initialData changes externally
  useEffect(() => {
    if (initialData) {
      setData(initialData);
    }
  }, [initialData]);

  // Re-generate / re-cluster from notebook terms, sources & notes
  const handleRegenerateFromNotebook = () => {
    const result = generateClusteredNotebookMindMap(
      notebookTitle,
      notebookSubject,
      glossary,
      memos,
      sources,
      chunks,
      notes
    );
    setData(result.root);
    if (onSave) onSave(result.root);
    setSelectedNode(result.root);
  };

  // Convert current mind map to academic PDF summary
  const handleExportAcademicPdf = () => {
    const summary = mindMapToStructuredSummary(
      data,
      notebookTitle || 'الدفتر الأكاديمي',
      notebookSubject || 'دليل دراسي وشجرة المفاهيم الأساسية'
    );
    setStructuredSummary(summary);
    setIsAcademicPrintOpen(true);
  };

  // Export current D3 SVG as vector or file
  const handleExportSvg = () => {
    if (!svgRef.current) return;
    setIsExportingSvg(true);
    try {
      const serializer = new XMLSerializer();
      const svgString = serializer.serializeToString(svgRef.current);
      const blob = new Blob([svgString], { type: 'image/svg+xml;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `خريطة_ذهنية_${notebookTitle.replace(/\s+/g, '_')}_D3.svg`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (e) {
      console.error('Failed to export SVG:', e);
    } finally {
      setIsExportingSvg(false);
    }
  };

  // Download fully interactive standalone HTML mind map file
  const handleDownloadInteractiveHtml = () => {
    try {
      const html = generateInteractiveMindMapHtml(data, notebookTitle, notebookSubject);
      const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `خريطة_تفاعلية_${(notebookTitle || 'ذهنية').replace(/\s+/g, '_')}.html`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (e) {
      console.error('Failed to download interactive HTML mind map:', e);
    }
  };

  // Initialize Zoom behavior once
  useEffect(() => {
    if (!svgRef.current || !gRef.current) return;

    const svg = d3.select(svgRef.current);
    const g = d3.select(gRef.current);

    const zoom = d3
      .zoom<SVGSVGElement, unknown>()
      .scaleExtent([0.25, 3.5])
      .on('zoom', (event) => {
        g.attr('transform', event.transform);
      });

    zoomBehaviorRef.current = zoom;
    svg.call(zoom);

    // Initial positioning
    resetZoom();
  }, []);

  const resetZoom = () => {
    if (!svgRef.current || !zoomBehaviorRef.current) return;
    const svg = d3.select(svgRef.current);
    const width = svgRef.current.clientWidth || 900;
    const height = svgRef.current.clientHeight || 600;

    let initialTransform = d3.zoomIdentity.translate(width / 2, height / 2).scale(0.85);
    if (layoutType === 'tree') {
      initialTransform = d3.zoomIdentity.translate(width * 0.75, height / 2).scale(0.8);
    }

    svg.transition().duration(600).call(zoomBehaviorRef.current.transform, initialTransform);
  };

  const zoomIn = () => {
    if (!svgRef.current || !zoomBehaviorRef.current) return;
    d3.select(svgRef.current).transition().duration(300).call(zoomBehaviorRef.current.scaleBy, 1.3);
  };

  const zoomOut = () => {
    if (!svgRef.current || !zoomBehaviorRef.current) return;
    d3.select(svgRef.current).transition().duration(300).call(zoomBehaviorRef.current.scaleBy, 0.75);
  };

  // Main D3 Rendering Engine
  useEffect(() => {
    if (!svgRef.current || !gRef.current || !data) return;

    const g = d3.select(gRef.current);
    g.selectAll('*').remove(); // Clear previous render

    const isDarkMode = document.documentElement.classList.contains('dark');
    const textColor = isDarkMode ? '#eef7f4' : '#17201e';
    const linkColor = isDarkMode ? '#334155' : '#cbd5e1';
    const cardBgColor = isDarkMode ? '#14201c' : '#ffffff';
    const cardBorderColor = isDarkMode ? '#22352f' : '#e2e8e5';

    // Helper to recursively prepare hierarchy with expand/collapse state and depth limits
    const cloneWithCollapse = (node: MindMapNode, depth = 0): any => {
      const isCollapsed = collapsedNodeIds.has(node.id) || (maxDisplayDepth < 4 && depth >= maxDisplayDepth);
      const copy: any = { ...node, depth };
      if (node.children && node.children.length > 0) {
        if (isCollapsed) {
          copy._children = node.children.map((c) => cloneWithCollapse(c, depth + 1));
          copy.children = null;
        } else {
          copy.children = node.children.map((c) => cloneWithCollapse(c, depth + 1));
          copy._children = null;
        }
      }
      return copy;
    };

    // Build d3 hierarchy with collapsible tree branches and depth limits
    const treeData = cloneWithCollapse(data, 0);
    const root = d3.hierarchy<any>(treeData, (d) => d.children);

    if (layoutType === 'tree') {
      // -------------------------------------------------------------
      // 1. D3 Horizontal Tree Layout (Right-To-Left for Arabic)
      // -------------------------------------------------------------
      const nodeWidth = 220;
      const nodeHeight = 65;
      const treeLayout = d3.tree<MindMapNode>().nodeSize([nodeHeight + 28, nodeWidth + 90]);
      treeLayout(root);

      // Links
      const linksData = root.links();
      g.append('g')
        .attr('class', 'd3-links')
        .selectAll('path')
        .data(linksData)
        .enter()
        .append('path')
        .attr('d', (d) => {
          // In RTL: source is to the right (higher X), target is to the left (lower X)
          const sx = -(d.source.y ?? 0);
          const sy = d.source.x ?? 0;
          const tx = -(d.target.y ?? 0);
          const ty = d.target.x ?? 0;
          return `M ${sx} ${sy} C ${(sx + tx) / 2} ${sy}, ${(sx + tx) / 2} ${ty}, ${tx} ${ty}`;
        })
        .attr('fill', 'none')
        .attr('stroke', (d) => d.target.data.color || linkColor)
        .attr('stroke-width', 2)
        .attr('stroke-opacity', 0.65);

      // Nodes
      const nodesData = root.descendants();
      const nodeGroups = g
        .append('g')
        .attr('class', 'd3-nodes')
        .selectAll('g')
        .data(nodesData)
        .enter()
        .append('g')
        .attr('transform', (d) => `translate(${-(d.y ?? 0)}, ${d.x ?? 0})`)
        .attr('cursor', 'pointer')
        .on('click', (_event, d) => {
          setSelectedNode(d.data);
          const hasBranches = (d.data.children && d.data.children.length > 0) || (d.data._children && d.data._children.length > 0);
          if (hasBranches) {
            toggleCollapse(d.data.id);
          }
        });

      // Node Card Background
      nodeGroups
        .append('rect')
        .attr('x', -nodeWidth / 2)
        .attr('y', -nodeHeight / 2)
        .attr('width', nodeWidth)
        .attr('height', nodeHeight)
        .attr('rx', 12)
        .attr('fill', cardBgColor)
        .attr('stroke', (d) => {
          if (searchQuery && d.data.title.toLowerCase().includes(searchQuery.toLowerCase())) {
            return '#f59e0b'; // Spotlight Amber
          }
          if (selectedNode?.id === d.data.id) {
            return '#0f766e';
          }
          return d.data.color || cardBorderColor;
        })
        .attr('stroke-width', (d) => (selectedNode?.id === d.data.id || (searchQuery && d.data.title.toLowerCase().includes(searchQuery.toLowerCase())) ? 3 : 1.5))
        .attr('filter', 'drop-shadow(0 2px 4px rgba(0,0,0,0.06))');

      // Accent color pill / indicator on right side
      nodeGroups
        .append('rect')
        .attr('x', nodeWidth / 2 - 6)
        .attr('y', -nodeHeight / 2 + 8)
        .attr('width', 4)
        .attr('height', nodeHeight - 16)
        .attr('rx', 2)
        .attr('fill', (d) => d.data.color || '#0f766e');

      // Title Text
      nodeGroups
        .append('text')
        .attr('x', nodeWidth / 2 - 16)
        .attr('y', -4)
        .attr('text-anchor', 'end')
        .attr('fill', textColor)
        .attr('font-size', (d) => (d.depth === 0 ? '13px' : '12px'))
        .attr('font-weight', (d) => (d.depth === 0 ? '900' : '700'))
        .attr('font-family', 'system-ui, -apple-system, sans-serif')
        .text((d) => {
          const t = d.data.title;
          return t.length > 28 ? t.slice(0, 26) + '...' : t;
        });

      // Subtitle / Badge or Notes excerpt
      nodeGroups
        .append('text')
        .attr('x', nodeWidth / 2 - 16)
        .attr('y', 16)
        .attr('text-anchor', 'end')
        .attr('fill', isDarkMode ? '#a7c2b9' : '#475569')
        .attr('font-size', '10px')
        .attr('font-weight', '500')
        .attr('font-family', 'system-ui, -apple-system, sans-serif')
        .text((d) => {
          if (d.data.badge) return `🏷️ ${d.data.badge}`;
          if (d.data._children && d.data._children.length > 0) {
            return `• +${d.data._children.length} فروع (انقر للتفريع)`;
          }
          if (d.data.children && d.data.children.length > 0) {
            return `• ${d.data.children.length} فروع معروضة`;
          }
          return '• مفهوم تحليلي';
        });

      // Child counter / expand-collapse indicator bubble on left
      nodeGroups
        .filter((d) => Boolean((d.data.children && d.data.children.length > 0) || (d.data._children && d.data._children.length > 0)))
        .append('circle')
        .attr('cx', -nodeWidth / 2)
        .attr('cy', 0)
        .attr('r', 11)
        .attr('fill', (d) => (d.data._children ? '#d97706' : d.data.color || '#0f766e'))
        .attr('stroke', '#ffffff')
        .attr('stroke-width', 2);

      nodeGroups
        .filter((d) => Boolean((d.data.children && d.data.children.length > 0) || (d.data._children && d.data._children.length > 0)))
        .append('text')
        .attr('cx', -nodeWidth / 2)
        .attr('cy', 3.5)
        .attr('text-anchor', 'middle')
        .attr('fill', '#ffffff')
        .attr('font-size', '9.5px')
        .attr('font-weight', 'bold')
        .text((d) => {
          if (d.data._children && d.data._children.length > 0) {
            return `+${d.data._children.length}`;
          }
          return d.data.children?.length || '-';
        });

    } else if (layoutType === 'radial') {
      // -------------------------------------------------------------
      // 2. D3 Radial Dendrogram / Tree Layout
      // -------------------------------------------------------------
      const radius = 380;
      const treeLayout = d3
        .tree<MindMapNode>()
        .size([2 * Math.PI, radius])
        .separation((a, b) => (a.parent === b.parent ? 1 : 2) / a.depth);

      treeLayout(root);

      // Radial Links
      g.append('g')
        .attr('class', 'd3-radial-links')
        .selectAll('path')
        .data(root.links())
        .enter()
        .append('path')
        .attr(
          'd',
          d3
            .linkRadial<any, any>()
            .angle((d: any) => d.x)
            .radius((d: any) => d.y) as any
        )
        .attr('fill', 'none')
        .attr('stroke', (d) => d.target.data.color || linkColor)
        .attr('stroke-width', 2)
        .attr('stroke-opacity', 0.6);

      // Radial Nodes
      const nodeGroups = g
        .append('g')
        .attr('class', 'd3-radial-nodes')
        .selectAll('g')
        .data(root.descendants())
        .enter()
        .append('g')
        .attr('transform', (d: any) => `rotate(${(d.x * 180) / Math.PI - 90}) translate(${d.y}, 0)`)
        .attr('cursor', 'pointer')
        .on('click', (_event, d) => {
          setSelectedNode(d.data);
        });

      nodeGroups
        .append('circle')
        .attr('r', (d) => (d.depth === 0 ? 14 : d.depth === 1 ? 9 : 6))
        .attr('fill', (d) => d.data.color || '#0f766e')
        .attr('stroke', cardBgColor)
        .attr('stroke-width', 2);

      nodeGroups
        .append('text')
        .attr('dy', '0.31em')
        .attr('x', (d: any) => (d.x < Math.PI ? 12 : -12))
        .attr('text-anchor', (d: any) => (d.x < Math.PI ? 'start' : 'end'))
        .attr('transform', (d: any) => (d.x >= Math.PI ? 'rotate(180)' : null))
        .attr('fill', textColor)
        .attr('font-size', (d) => (d.depth === 0 ? '13px' : '10.5px'))
        .attr('font-weight', (d) => (d.depth < 2 ? 'bold' : 'normal'))
        .text((d) => d.data.title);

    } else if (layoutType === 'force') {
      // -------------------------------------------------------------
      // 3. D3 Force-Directed Network Graph (Clustered Physics)
      // -------------------------------------------------------------
      const nodesData: any[] = root.descendants().map((d) => ({
        id: d.data.id,
        title: d.data.title,
        color: d.data.color || '#0f766e',
        level: d.depth,
        rawNode: d.data,
        r: d.depth === 0 ? 32 : d.depth === 1 ? 22 : 15,
      }));

      const hierarchyLinks: any[] = root.links().map((l) => ({
        source: l.source.data.id,
        target: l.target.data.id,
        color: l.target.data.color || linkColor,
        isCrossLink: false,
      }));

      // Cross-concept relationships
      const crossConceptLinks: any[] = [];
      nodesData.forEach((n) => {
        if (n.rawNode.relatedNodeIds && Array.isArray(n.rawNode.relatedNodeIds)) {
          n.rawNode.relatedNodeIds.forEach((targetId: string) => {
            if (nodesData.some((nd) => nd.id === targetId)) {
              crossConceptLinks.push({
                source: n.id,
                target: targetId,
                color: '#f59e0b', // Amber connection
                isCrossLink: true,
              });
            }
          });
        }
      });

      const linksData = [...hierarchyLinks, ...crossConceptLinks];

      const simulation = d3
        .forceSimulation(nodesData)
        .force(
          'link',
          d3
            .forceLink(linksData)
            .id((d: any) => d.id)
            .distance((d: any) => (d.source.level === 0 ? 140 : 80))
        )
        .force('charge', d3.forceManyBody().strength(-350))
        .force('collide', d3.forceCollide().radius((d: any) => d.r + 25))
        .force('center', d3.forceCenter(0, 0));

      const link = g
        .append('g')
        .attr('class', 'd3-force-links')
        .selectAll('line')
        .data(linksData)
        .enter()
        .append('line')
        .attr('stroke', (d) => d.color)
        .attr('stroke-width', (d) => (d.isCrossLink ? 2.5 : 2))
        .attr('stroke-dasharray', (d) => (d.isCrossLink ? '4,4' : 'none'))
        .attr('stroke-opacity', (d) => (d.isCrossLink ? 0.85 : 0.6));

      // 3D Spatial Lighting Gradients
      const defs = g.append('defs');
      nodesData.forEach((nd, i) => {
        const gradId = `spatial-grad-${i}`;
        const grad = defs.append('radialGradient')
          .attr('id', gradId)
          .attr('cx', '32%')
          .attr('cy', '32%')
          .attr('r', '68%');
        grad.append('stop').attr('offset', '0%').attr('stop-color', '#ffffff').attr('stop-opacity', 0.85);
        grad.append('stop').attr('offset', '40%').attr('stop-color', nd.color);
        grad.append('stop').attr('offset', '100%').attr('stop-color', d3.color(nd.color)?.darker(1.6)?.toString() || '#042f2e');
        nd.gradId = gradId;
      });

      const node = g
        .append('g')
        .attr('class', 'd3-force-nodes')
        .selectAll('g')
        .data(nodesData)
        .enter()
        .append('g')
        .attr('cursor', 'grab')
        .call(
          d3
            .drag<any, any>()
            .on('start', (event, d) => {
              if (!event.active) simulation.alphaTarget(0.3).restart();
              d.fx = d.x;
              d.fy = d.y;
            })
            .on('drag', (event, d) => {
              d.fx = event.x;
              d.fy = event.y;
            })
            .on('end', (event, d) => {
              if (!event.active) simulation.alphaTarget(0);
              d.fx = null;
              d.fy = null;
            })
        )
        .on('click', (_event, d) => {
          setSelectedNode(d.rawNode);
          if (d.rawNode.children && d.rawNode.children.length > 0) {
            toggleCollapse(d.id);
          }
        });

      // Outer glowing orbital ring for root and level 1
      node
        .filter((d) => d.level <= 1)
        .append('circle')
        .attr('r', (d) => d.r + 6)
        .attr('fill', 'none')
        .attr('stroke', (d) => d.color)
        .attr('stroke-width', 1.5)
        .attr('stroke-opacity', 0.4)
        .attr('stroke-dasharray', '3,3');

      // 3D Spherical Body
      node
        .append('circle')
        .attr('r', (d) => d.r)
        .attr('fill', (d) => `url(#${d.gradId})`)
        .attr('stroke', isDarkMode ? '#1e293b' : '#ffffff')
        .attr('stroke-width', 2.5)
        .attr('filter', 'drop-shadow(0 6px 12px rgba(0,0,0,0.22))');

      // High-contrast title capsule below 3D sphere
      const labelGroup = node
        .append('g')
        .attr('transform', (d) => `translate(0, ${d.r + 14})`);

      labelGroup
        .append('rect')
        .attr('x', (d) => {
          const textLen = Math.min(d.title.length, 24);
          return -(textLen * 3.8 + 8);
        })
        .attr('y', -8)
        .attr('width', (d) => Math.min(d.title.length, 24) * 7.6 + 16)
        .attr('height', 18)
        .attr('rx', 6)
        .attr('fill', isDarkMode ? 'rgba(15, 23, 42, 0.92)' : 'rgba(255, 255, 255, 0.96)')
        .attr('stroke', (d) => d.color || '#0f766e')
        .attr('stroke-width', 1)
        .attr('filter', 'drop-shadow(0 2px 4px rgba(0,0,0,0.15))');

      labelGroup
        .append('text')
        .attr('text-anchor', 'middle')
        .attr('dy', 4)
        .attr('fill', textColor)
        .attr('font-size', (d) => (d.level === 0 ? '11.5px' : '10.5px'))
        .attr('font-weight', (d) => (d.level === 0 ? '900' : '700'))
        .attr('font-family', 'system-ui, -apple-system, sans-serif')
        .text((d) => (d.title.length > 22 ? d.title.slice(0, 20) + '...' : d.title));

      simulation.on('tick', () => {
        link
          .attr('x1', (d: any) => d.source.x)
          .attr('y1', (d: any) => d.source.y)
          .attr('x2', (d: any) => d.target.x)
          .attr('y2', (d: any) => d.target.y);

        node.attr('transform', (d: any) => `translate(${d.x},${d.y})`);
      });
    }
  }, [data, layoutType, selectedNode, searchQuery, collapsedNodeIds, maxDisplayDepth]);

  // Helper to find node in tree by id
  const findNodeById = (node: MindMapNode, id: string): MindMapNode | null => {
    if (node.id === id) return node;
    if (node.children) {
      for (const child of node.children) {
        const found = findNodeById(child, id);
        if (found) return found;
      }
    }
    return null;
  };

  // Copy concept data
  const handleCopyNodeInfo = () => {
    if (!selectedNode) return;
    const info = `المفهوم: ${selectedNode.title}\nالتصنيف: ${selectedNode.badge || 'مفهوم دراسي'}\n${selectedNode.notes ? `الملاحظات: ${selectedNode.notes}` : ''}${selectedNode.formula ? `\nالمعادلة: ${selectedNode.formula}` : ''}`;
    navigator.clipboard.writeText(info);
    setCopiedConcept(true);
    setTimeout(() => setCopiedConcept(false), 2000);
  };

  return (
    <div className="flex flex-col h-[78vh] sm:h-[82vh] bg-white dark:bg-[#14201c] rounded-2xl border border-[#e2e8e5] dark:border-[#22352f] overflow-hidden shadow-sm relative isolate z-10 w-full max-w-full box-border">
      {/* Top D3 Toolbar */}
      <div className="p-3 bg-[#f8fbfa] dark:bg-[#101916] border-b border-[#e2e8e5] dark:border-[#22352f] flex flex-wrap items-center justify-between gap-2.5 z-10">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-teal-600 text-white flex items-center justify-center shrink-0">
            <GitFork className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h3 className="text-xs sm:text-sm font-bold text-[#17201e] dark:text-[#eef7f4]">
                مخطط D3 التفاعلي للمفاهيم والمصطلحات
              </h3>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-teal-100 dark:bg-teal-950 text-teal-800 dark:text-teal-300">
                D3.js Clustered
              </span>
            </div>
            <p className="text-[11px] text-[#596762] dark:text-[#9ab3ab] hidden sm:block">
              تجميع ذكي للمصطلحات ({glossary.length}) والملاحظات ({memos.length}) والمصادر في شبكة ترابطية
            </p>
          </div>
        </div>

        {/* Action Controls & Layout Switcher */}
        <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
          {/* Dual-Mode Layout Switcher */}
          <div className="flex items-center bg-[#e6f4f1] dark:bg-[#192723] p-1 rounded-xl text-xs font-bold gap-1">
            <button
              onClick={() => setLayoutType('force')}
              className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
                layoutType === 'force'
                  ? 'bg-teal-700 text-white shadow-xs font-black'
                  : 'text-teal-900 dark:text-teal-200 hover:bg-teal-200/50'
              }`}
              title="خريطة تفاعلية ثلاثية الأبعاد بفيزياء حركية وعمق بصري وتكبير سلس"
            >
              <span>🌐</span>
              <span>خريطة تفاعلية 3D</span>
            </button>
            <button
              onClick={() => setLayoutType('tree')}
              className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
                layoutType === 'tree'
                  ? 'bg-teal-700 text-white shadow-xs font-black'
                  : 'text-teal-900 dark:text-teal-200 hover:bg-teal-200/50'
              }`}
              title="خريطة هيكلية شجرية كلاسيكية منظمة بأسلوب منصات XMind و MindMeister"
            >
              <span>🌳</span>
              <span>خريطة كلاسيكية 2D</span>
            </button>
            <button
              onClick={() => setLayoutType('radial')}
              className={`px-2.5 py-1.5 rounded-lg transition-all hidden md:flex items-center gap-1 cursor-pointer ${
                layoutType === 'radial'
                  ? 'bg-teal-700 text-white shadow-xs font-black'
                  : 'text-teal-900 dark:text-teal-200 hover:bg-teal-200/50'
              }`}
              title="مخطط دائري شعاعي للمفاهيم"
            >
              <span>⭕</span>
              <span>دائري</span>
            </button>
          </div>

          <button
            type="button"
            onClick={() => setIsFocusMode((prev) => !prev)}
            aria-pressed={isFocusMode}
            className={`px-2.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer border ${isFocusMode ? 'bg-teal-700 text-white border-teal-600' : 'bg-white dark:bg-[#1a2723] text-teal-800 dark:text-teal-200 border-[#e2e8e5] dark:border-[#22352f]'}`}
            title="تركيز العرض على الخريطة وإخفاء التفاصيل الجانبية"
          >
            <Compass className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">وضع التركيز</span>
          </button>

          {/* Search Input */}
          <div className="relative hidden md:block">
            <input
              type="text"
              placeholder="البحث في شجرة المفاهيم..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-40 lg:w-48 pl-2 pr-7 py-1 text-xs bg-white dark:bg-[#14201c] border border-[#cbd5e1] dark:border-[#334155] rounded-xl text-[#17201e] dark:text-[#eef7f4] focus:outline-none focus:border-teal-600"
            />
            <Search className="w-3.5 h-3.5 text-gray-400 absolute right-2.5 top-2" />
          </div>

          {/* Depth Level Selector */}
          <div className="flex items-center bg-slate-100 dark:bg-[#1a2723] p-1 rounded-xl text-xs gap-1">
            <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 px-1 hidden xl:inline">عمق الخريطة:</span>
            {[1, 2, 3, 4].map((lvl) => (
              <button
                key={lvl}
                type="button"
                onClick={() => setMaxDisplayDepth(lvl)}
                className={`px-2 py-0.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  maxDisplayDepth === lvl
                    ? 'bg-teal-700 text-white shadow-xs'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                }`}
                title={lvl === 4 ? 'عرض كافة المستويات والتفرعات' : `حصر العرض حتى المستوى ${lvl}`}
              >
                {lvl === 4 ? 'الكل' : `م${lvl}`}
              </button>
            ))}
          </div>

          {/* Expand/Collapse All */}
          <div className="hidden sm:flex items-center gap-1">
            <button
              type="button"
              onClick={handleExpandAll}
              className="px-2 py-1 bg-white dark:bg-[#1a2723] hover:bg-teal-50 dark:hover:bg-teal-950 text-teal-800 dark:text-teal-200 border border-slate-200 dark:border-[#22352f] rounded-lg text-xs font-bold cursor-pointer"
              title="توسيع كافة الفروع والعقد"
            >
              توسيع الكل
            </button>
            <button
              type="button"
              onClick={handleCollapseAll}
              className="px-2 py-1 bg-white dark:bg-[#1a2723] hover:bg-teal-50 dark:hover:bg-teal-950 text-teal-800 dark:text-teal-200 border border-slate-200 dark:border-[#22352f] rounded-lg text-xs font-bold cursor-pointer"
              title="طي الفروع إلى المستوى الرئيسي"
            >
              طي الكل
            </button>
          </div>

          {/* Custom Text & Chat Message Mind Map Generator */}
          <button
            onClick={() => setShowTextModal(true)}
            className="px-2.5 py-1.5 bg-teal-50 dark:bg-teal-950/70 border border-teal-500/40 text-teal-800 dark:text-teal-200 rounded-xl text-xs font-bold hover:bg-teal-100 flex items-center gap-1.5 shadow-xs cursor-pointer active:scale-95"
            title="توليد خريطة ذهنية متفرعة من نص مخصص أو من ردود المحادثة"
          >
            <GitFork className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
            <span>توليد من نص / محادثة</span>
          </button>

          {/* Regenerate Cluster */}
          <button
            onClick={handleRegenerateFromNotebook}
            className="px-2.5 py-1.5 bg-white dark:bg-[#1a2723] border border-[#e2e8e5] dark:border-[#22352f] text-teal-800 dark:text-teal-200 rounded-xl text-xs font-bold hover:bg-teal-50 dark:hover:bg-teal-950 flex items-center gap-1 shadow-xs"
            title="إعادة تجميع واستخراج المفاهيم والمصطلحات من الدفتر"
          >
            <Sparkles className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
            <span className="hidden sm:inline">تجميع ذكي D3</span>
          </button>

          {/* Download Fully Interactive HTML Mind Map */}
          <button
            onClick={handleDownloadInteractiveHtml}
            className="px-3 py-1.5 bg-gradient-to-r from-teal-700 via-teal-600 to-emerald-600 hover:from-teal-800 hover:to-emerald-700 text-white rounded-xl text-xs font-extrabold flex items-center gap-1.5 shadow-xs cursor-pointer border border-teal-500/40"
            title="تحميل الخريطة كملف HTML مستقل وتفاعلي بالكامل يعمل على أي جهاز دون إنترنت"
          >
            <Download className="w-3.5 h-3.5" />
            <span>HTML تفاعلي</span>
          </button>

          {/* Export PNG */}
          <button
            onClick={handleExportPng}
            className="px-2.5 py-1.5 bg-white dark:bg-[#1a2723] hover:bg-slate-100 dark:hover:bg-[#22352f] text-teal-800 dark:text-teal-200 border border-slate-200 dark:border-[#22352f] rounded-xl text-xs font-bold flex items-center gap-1 shadow-xs cursor-pointer"
            title="تحميل كصورة PNG عالية الدقة للمشاركة"
          >
            <span>🖼️</span>
            <span className="hidden sm:inline">صورة PNG</span>
          </button>

          {/* Export to Academic Report PDF */}
          <button
            onClick={handleExportAcademicPdf}
            className="px-2.5 py-1.5 bg-white dark:bg-[#1a2723] hover:bg-slate-100 dark:hover:bg-[#22352f] text-teal-800 dark:text-teal-200 border border-slate-200 dark:border-[#22352f] rounded-xl text-xs font-bold flex items-center gap-1 shadow-xs cursor-pointer"
            title="تصدير الشجرة كتقرير أكاديمي منظم (academic-report-style PDF)"
          >
            <FileText className="w-3.5 h-3.5 text-teal-600" />
            <span className="hidden sm:inline">تقرير PDF</span>
          </button>

          {/* Export SVG */}
          <button
            onClick={handleExportSvg}
            disabled={isExportingSvg}
            className="p-1.5 text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 rounded-lg hover:bg-gray-200/50"
            title="تحميل كصورة متجهة SVG"
          >
            <Download className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Helpful Interactive Instructions Bar */}
      <div className="bg-teal-50/70 dark:bg-teal-950/40 border-b border-teal-100 dark:border-teal-900/50 px-3.5 py-1.5 text-[11px] text-teal-900 dark:text-teal-200 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span className="font-bold text-teal-700 dark:text-teal-400">💡 كيف تعمل الخريطة:</span>
          <span>انقر على أي عقدة/دائرة لقراءة الشرح والمعادلات • اسحب للتنقل • استخدم عجلة الفأرة للتكبير • حمّلها كـ HTML تفاعلي لفتحها في أي وقت.</span>
        </div>
      </div>

      {/* D3 SVG Canvas Area + Floating Zoom Controls */}
      <div className="flex-1 relative overflow-hidden bg-[#fafcfb] dark:bg-[#0f1715] w-full max-w-full isolate">
        <svg
          ref={svgRef}
          className="w-full h-full block select-none touch-none max-w-full overflow-hidden"
        >
          <g ref={gRef} />
        </svg>

        {/* Floating Zoom & Reset Toolbar */}
        <div className="absolute bottom-4 left-4 z-20 flex items-center gap-1 p-1 bg-white/90 dark:bg-[#14201c]/90 border border-[#e2e8e5] dark:border-[#22352f] rounded-xl shadow-md backdrop-blur-md">
          <button
            onClick={zoomIn}
            className="p-1.5 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg"
            title="تكبير (+)"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
          <button
            onClick={zoomOut}
            className="p-1.5 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg"
            title="تصغير (-)"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          <button
            onClick={resetZoom}
            className="p-1.5 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg"
            title="إعادة ضبط الموضع (Fit to Center)"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>

        {/* Active Node Details Drawer (Right-aligned or Bottom on mobile) */}
        {selectedNode && !isFocusMode && (
          <div className="absolute top-3 right-3 bottom-3 w-72 sm:w-84 max-w-[calc(100%-24px)] bg-white dark:bg-[#14201c] border border-[#e2e8e5] dark:border-[#22352f] rounded-2xl shadow-xl flex flex-col z-30 animate-in slide-in-from-right duration-200">
            {/* Header */}
            <div className="p-3 border-b border-[#e2e8e5] dark:border-[#22352f] flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: selectedNode.color || '#0f766e' }}
                />
                <span className="text-xs font-bold text-gray-500 dark:text-gray-400">
                  {selectedNode.badge || (selectedNode.level === 0 ? 'الفكرة المركزية' : `مستوى ${selectedNode.level}`)}
                </span>
              </div>
              <button
                onClick={() => setSelectedNode(null)}
                className="p-1 rounded-lg text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Body Content */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              <h4 className="text-sm font-bold text-[#17201e] dark:text-[#eef7f4] leading-snug">
                {selectedNode.title}
              </h4>

              {/* Formula Render with KaTeX */}
              {selectedNode.formula && (
                <div className="p-3 bg-teal-50/70 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-800 rounded-xl">
                  <div className="text-[10px] font-bold text-teal-800 dark:text-teal-300 mb-1">
                    الصيغة الرياضية / المعادلة:
                  </div>
                  <EducationalContent
                    content={`$$${selectedNode.formula}$$`}
                    className="text-xs"
                  />
                </div>
              )}

              {/* Notes / Definitions */}
              {selectedNode.notes ? (
                <div className="text-xs text-[#596762] dark:text-[#9ab3ab] leading-relaxed whitespace-pre-wrap">
                  <EducationalContent content={selectedNode.notes} className="text-xs" />
                </div>
              ) : (
                <p className="text-xs text-gray-400 italic">
                  لا توجد ملاحظات إضافية لهذا المفهوم.
                </p>
              )}

              {/* Sub-concepts list */}
              {selectedNode.children && selectedNode.children.length > 0 && (
                <div className="pt-2 border-t border-[#e2e8e5] dark:border-[#22352f]">
                  <span className="text-[11px] font-bold text-[#17201e] dark:text-[#eef7f4] block mb-1.5">
                    الفروع المتصلة ({selectedNode.children.length}):
                  </span>
                  <div className="space-y-1">
                    {selectedNode.children.map((child) => (
                      <button
                        key={child.id}
                        onClick={() => setSelectedNode(child)}
                        className="w-full text-right p-2 rounded-xl text-xs bg-[#f8fbfa] dark:bg-[#1a2723] hover:bg-teal-50 dark:hover:bg-teal-950/60 border border-[#e2e8e5] dark:border-[#22352f] flex items-center justify-between text-[#17201e] dark:text-[#eef7f4]"
                      >
                        <span className="truncate">{child.title}</span>
                        <ChevronLeft className="w-3.5 h-3.5 text-gray-400 shrink-0" />
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Connected Concepts / Cross-Relationships */}
              {selectedNode.relatedNodeIds && selectedNode.relatedNodeIds.length > 0 && (
                <div className="pt-2 border-t border-[#e2e8e5] dark:border-[#22352f]">
                  <span className="text-[11px] font-bold text-amber-700 dark:text-amber-400 block mb-1.5 flex items-center gap-1">
                    <span>🔗 العلاقات والمفاهيم المرتبطة:</span>
                  </span>
                  <div className="space-y-1">
                    {selectedNode.relatedNodeIds.map((relId) => {
                      const relNode = findNodeById(data, relId);
                      if (!relNode) return null;
                      return (
                        <button
                          key={relId}
                          onClick={() => setSelectedNode(relNode)}
                          className="w-full text-right p-2 rounded-xl text-xs bg-amber-50/70 dark:bg-amber-950/40 hover:bg-amber-100 dark:hover:bg-amber-900/60 border border-amber-200 dark:border-amber-800 flex items-center justify-between text-[#17201e] dark:text-[#eef7f4] transition-all"
                        >
                          <div className="flex items-center gap-1.5 truncate">
                            <span className="w-2 h-2 rounded-full bg-amber-500 shrink-0" />
                            <span className="truncate font-semibold">{relNode.title}</span>
                          </div>
                          <span className="text-[10px] text-amber-700 dark:text-amber-300 font-bold shrink-0 mr-1">
                            {selectedNode.relationLabel || 'علاقة'}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

            {/* Drawer Actions */}
            <div className="p-3 border-t border-[#e2e8e5] dark:border-[#22352f] flex gap-2">
              <button
                onClick={handleCopyNodeInfo}
                className="flex-1 py-2 bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-colors"
              >
                {copiedConcept ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedConcept ? 'تم النسخ' : 'نسخ'}</span>
              </button>

              {onAskAboutConcept && (
                <button
                  onClick={() => onAskAboutConcept(selectedNode.title, selectedNode.notes)}
                  className="flex-1 py-2 bg-[#0f766e] hover:bg-[#115e59] text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-xs transition-colors"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>اسأل AI</span>
                </button>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Academic Print Report Modal */}
      {isAcademicPrintOpen && structuredSummary && (
        <AcademicPrintModal
          isOpen={isAcademicPrintOpen}
          onClose={() => setIsAcademicPrintOpen(false)}
          summary={structuredSummary}
        />
      )}

      {/* Modal: Generate Deep Interactive Mind Map from Text / Chat Message */}
      {showTextModal && (
        <div className="fixed inset-0 z-50 p-4 bg-black/60 backdrop-blur-sm flex items-center justify-center animate-in fade-in duration-150">
          <div className="bg-white dark:bg-[#14201c] w-full max-w-xl rounded-3xl p-5 sm:p-6 shadow-2xl border border-slate-200 dark:border-[#22352f] space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-[#22352f] pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-teal-50 dark:bg-teal-950/80 text-teal-700 dark:text-teal-300 flex items-center justify-center font-bold">
                  <GitFork className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base text-slate-800 dark:text-slate-100">
                    توليد خريطة ذهنية تفاعلية متفرعة
                  </h3>
                  <p className="text-[11px] text-teal-700 dark:text-teal-400 font-semibold">
                    اختر من المحادثة أو الصق نص الدرس لتحويله لشجرة مفاهيم هرمية
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowTextModal(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Quick Pick from Active Conversation */}
            {chatMessages && chatMessages.length > 0 && (
              <div className="space-y-1.5">
                <span className="text-xs font-bold text-slate-700 dark:text-slate-200 block">
                  ✦ الاختيار السريع من ردود المحادثة الأخيرة:
                </span>
                <div className="flex flex-col gap-1.5 max-h-40 overflow-y-auto pr-1">
                  {chatMessages
                    .filter((m) => m.role !== 'user' && m.text.length > 30)
                    .slice(-4)
                    .map((msg, i) => (
                      <button
                        key={msg.id || i}
                        type="button"
                        onClick={() => {
                          setCustomText(msg.text);
                          const firstLine = msg.text.split('\n')[0].replace(/[#*]/g, '').trim();
                          setCustomTitle(firstLine.slice(0, 30) || notebookTitle);
                        }}
                        className="text-right p-2.5 rounded-xl border border-slate-200 dark:border-[#22352f] bg-slate-50 dark:bg-[#182622] hover:border-teal-500 hover:bg-teal-50 dark:hover:bg-teal-950/50 text-xs text-slate-700 dark:text-slate-200 transition-all cursor-pointer flex items-center justify-between gap-2 group"
                      >
                        <span className="line-clamp-1 font-medium">
                          رد AI {i + 1}: «{msg.text.slice(0, 75)}...»
                        </span>
                        <span className="text-[10px] font-bold text-teal-600 dark:text-teal-400 shrink-0">
                          اختيار ↵
                        </span>
                      </button>
                    ))}
                </div>
              </div>
            )}

            {/* Title Input */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-200">
                عنوان الفكرة المركزية للخريطة (اختيا��ي):
              </label>
              <input
                type="text"
                value={customTitle}
                onChange={(e) => setCustomTitle(e.target.value)}
                placeholder={notebookTitle || 'مثال: قوانين الحركة والسرعة، النحو والبلاغة...'}
                className="w-full px-3.5 py-2 text-xs rounded-xl border border-slate-200 dark:border-[#22352f] bg-slate-50 dark:bg-[#121c18] text-slate-800 dark:text-slate-100 focus:outline-none focus:border-teal-600"
              />
            </div>

            {/* Custom Text Area */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-200">
                النص أو الشرح المراد تحويله لخريطة تفاعلية:
              </label>
              <textarea
                rows={6}
                value={customText}
                onChange={(e) => setCustomText(e.target.value)}
                placeholder="الصق هنا ملخص الدرس، رد الذكاء الاصطناعي، أو مقاطع من كتابك الدراسي ليتم تفكيكها إلى محاور رئيسية، مفاهيم فرعية، معادلات، وتفاصيل دقيقة..."
                className="w-full p-3 text-xs rounded-2xl border border-slate-200 dark:border-[#22352f] bg-slate-50 dark:bg-[#121c18] text-slate-800 dark:text-slate-100 focus:outline-none focus:border-teal-600 resize-none leading-relaxed"
              />
            </div>

            {/* Buttons */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 pt-2">
              <button
                type="button"
                disabled={!customText.trim() || isAiBuildingMap}
                onClick={async () => {
                  setIsAiBuildingMap(true);
                  try {
                    const generated = await generateMindMapFromSingleMessageAI(
                      customText,
                      customTitle.trim() || notebookTitle
                    );
                    setData(generated);
                    if (onSave) onSave(generated);
                    setSelectedNode(generated);
                    setShowTextModal(false);
                    setCustomText('');
                    setCustomTitle('');
                    setCollapsedNodeIds(new Set());
                    resetZoom();
                  } catch (e) {
                    console.warn('AI mind map failed, falling back:', e);
                    const fallback = buildDeepMindMapFromText(customText, customTitle.trim() || notebookTitle);
                    setData(fallback);
                    if (onSave) onSave(fallback);
                    setSelectedNode(fallback);
                    setShowTextModal(false);
                    resetZoom();
                  } finally {
                    setIsAiBuildingMap(false);
                  }
                }}
                className="flex-1 py-2.5 px-4 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-black flex items-center justify-center gap-2 shadow-sm transition-all disabled:opacity-40 cursor-pointer active:scale-95"
              >
                {isAiBuildingMap ? (
                  <>
                    <RotateCcw className="w-4 h-4 animate-spin text-teal-200" />
                    <span>جارٍ الاستخلاص بالذكاء الاصطناعي...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 text-amber-300" />
                    <span>توليد بالذكاء الاصطناعي (AI)</span>
                  </>
                )}
              </button>

              <button
                type="button"
                disabled={!customText.trim() || isAiBuildingMap}
                onClick={() => {
                  const generated = buildDeepMindMapFromText(customText, customTitle.trim() || notebookTitle);
                  setData(generated);
                  if (onSave) onSave(generated);
                  setSelectedNode(generated);
                  setShowTextModal(false);
                  setCustomText('');
                  setCustomTitle('');
                  setCollapsedNodeIds(new Set());
                  resetZoom();
                }}
                className="py-2.5 px-4 bg-slate-100 dark:bg-[#1a2723] hover:bg-slate-200 dark:hover:bg-[#22352f] text-teal-800 dark:text-teal-200 border border-slate-200 dark:border-[#22352f] rounded-xl text-xs font-bold transition-colors cursor-pointer"
              >
                إنشاء فوري سريع
              </button>

              <button
                type="button"
                onClick={() => setShowTextModal(false)}
                className="py-2.5 px-4 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-bold hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors cursor-pointer"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
