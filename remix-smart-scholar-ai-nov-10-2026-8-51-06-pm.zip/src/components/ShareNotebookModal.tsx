import React, { useState, useEffect } from 'react';
import {
  Share2,
  Copy,
  Check,
  Globe,
  X,
  ExternalLink,
  Sparkles,
  FileText,
  BookOpen,
  Layers,
  CheckSquare,
  ShieldCheck,
  Send,
  MessageCircle,
  RefreshCw,
  Eye,
  Calendar,
  User,
} from 'lucide-react';
import { Notebook, NoteItem, MemoItem, GlossaryItem, Flashcard, Source, CustomSummaryDoc } from '../types';
import { createPublicNotebookShare, SharedNotebookPayload } from '../lib/shareService';

interface ShareNotebookModalProps {
  isOpen: boolean;
  onClose: () => void;
  notebook: Notebook;
  summaries: CustomSummaryDoc[];
  generatedSummary?: string;
  notes: NoteItem[];
  memos: MemoItem[];
  glossary: GlossaryItem[];
  flashcards: Flashcard[];
  sources: Source[];
  mindMap?: any;
  defaultAuthorName?: string;
  onPreviewShared?: (shareData: SharedNotebookPayload) => void;
}

export const ShareNotebookModal: React.FC<ShareNotebookModalProps> = ({
  isOpen,
  onClose,
  notebook,
  summaries,
  generatedSummary,
  notes,
  memos,
  glossary,
  flashcards,
  sources,
  mindMap,
  defaultAuthorName = 'طالب باحث',
  onPreviewShared,
}) => {
  const [authorName, setAuthorName] = useState(defaultAuthorName || 'طالب باحث');
  const [includeSummaries, setIncludeSummaries] = useState(true);
  const [includeNotes, setIncludeNotes] = useState(true);
  const [includeMemos, setIncludeMemos] = useState(true);
  const [includeGlossary, setIncludeGlossary] = useState(true);
  const [includeFlashcards, setIncludeFlashcards] = useState(true);
  const [includeSources, setIncludeSources] = useState(true);

  const [shareUrl, setShareUrl] = useState<string>('');
  const [shareId, setShareId] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [copied, setCopied] = useState(false);
  const [copiedInvite, setCopiedInvite] = useState(false);
  const [lastPayload, setLastPayload] = useState<SharedNotebookPayload | null>(null);

  // Compile items
  const compiledSummaries = [
    ...summaries.map((s) => ({
      id: s.id,
      title: s.title,
      content: s.content,
      theme: s.theme,
      date: s.date,
      boxes: s.boxes,
    })),
    ...(generatedSummary && !summaries.length
      ? [
          {
            id: `sum_${notebook.id}_auto`,
            title: `ملخص دراسي شامل - ${notebook.name}`,
            content: generatedSummary,
            date: new Date().toLocaleDateString('ar-SA'),
          },
        ]
      : []),
  ];

  const generateLink = async () => {
    setIsGenerating(true);
    try {
      const payload: Omit<SharedNotebookPayload, 'shareId' | 'createdAt'> = {
        authorName: authorName.trim() || 'طالب باحث',
        notebook: {
          id: notebook.id,
          name: notebook.name,
          subject: notebook.subject || 'عام',
          description: notebook.description || '',
        },
        summaries: includeSummaries ? compiledSummaries : [],
        notes: includeNotes
          ? notes.map((n) => ({
              id: n.id,
              title: n.title,
              text: n.text,
              tags: n.tags,
              goal: n.goal,
              created: n.created,
            }))
          : [],
        memos: includeMemos
          ? memos.map((m) => ({
              id: m.id,
              text: m.text,
              createdAt: m.createdAt || m.date,
            }))
          : [],
        glossary: includeGlossary
          ? glossary.map((g) => ({
              id: g.id,
              term: g.term,
              def: g.def,
              ex: g.ex,
            }))
          : [],
        flashcards: includeFlashcards
          ? flashcards.map((f) => ({
              id: f.id,
              front: f.front,
              back: f.back,
              level: f.level,
            }))
          : [],
        sourcesOverview: includeSources
          ? sources.map((s) => ({
              id: s.id,
              title: s.title,
              type: s.type,
              wordCount: s.wordCount,
              summary: s.summary,
            }))
          : [],
        mindMap: mindMap || null,
        options: {
          includeSummaries,
          includeNotes,
          includeMemos,
          includeGlossary,
          includeFlashcards,
          includeSources,
        },
      };

      const result = await createPublicNotebookShare(payload, shareId || undefined);
      if (result.success) {
        setShareId(result.shareId);
        setShareUrl(result.shareUrl);
        setLastPayload({
          ...payload,
          shareId: result.shareId,
          createdAt: Date.now(),
        });
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsGenerating(false);
    }
  };

  // Generate link initially when modal opens
  useEffect(() => {
    if (isOpen) {
      generateLink();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleCopyLink = () => {
    if (!shareUrl) return;
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2200);
  };

  const handleCopyInviteText = () => {
    if (!shareUrl) return;
    const inviteText = `📚 *دعوة لمشاركة دفتر دراسي: ${notebook.name}*\nالمادة: ${notebook.subject || 'عام'}\nإعداد: ${authorName || 'زميل دراسي'}\n\nيحتوي الدفتر على ملخصات أكاديمية وملاحظات مركزة للمذاكرة الجماعية.\n\nتفضل بزيارة الرابط لمعاينة المحتوى مباشرة:\n${shareUrl}`;
    navigator.clipboard.writeText(inviteText);
    setCopiedInvite(true);
    setTimeout(() => setCopiedInvite(false), 2200);
  };

  const shareViaWhatsApp = () => {
    if (!shareUrl) return;
    const text = encodeURIComponent(
      `📚 شاركني مراجعة هذا الدفتر الأكاديمي (${notebook.name}):\n${shareUrl}`
    );
    window.open(`https://api.whatsapp.com/send?text=${text}`, '_blank');
  };

  const shareViaTelegram = () => {
    if (!shareUrl) return;
    const text = encodeURIComponent(`📚 دفتر دراسي: ${notebook.name}`);
    window.open(`https://t.me/share/url?url=${encodeURIComponent(shareUrl)}&text=${text}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-fadeIn" dir="rtl">
      <div className="bg-white dark:bg-[#14201c] rounded-2xl max-w-xl w-full p-6 shadow-2xl border border-[#e2e8e5] dark:border-[#22352f] max-h-[92vh] overflow-y-auto space-y-5">
        {/* Header */}
        <div className="flex items-start justify-between border-b border-[#e2e8e5] dark:border-[#22352f] pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-teal-50 dark:bg-teal-950/60 text-[#0f766e] dark:text-[#2dd4bf] flex items-center justify-center border border-teal-200 dark:border-teal-800">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-lg text-[#17201e] dark:text-[#eef7f4]">
                  رابط مشاركة عام للدفتر
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-teal-100 dark:bg-teal-950 text-teal-800 dark:text-teal-300">
                  للقراءة فقط (Read-Only)
                </span>
              </div>
              <p className="text-xs text-[#596762] dark:text-[#9ab3ab] mt-0.5">
                مشاركة ملخصات وملاحظات «{notebook.name}» مع الزملاء والطلاب برابط فوري.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
            title="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Share Link Input Box */}
        <div className="bg-[#f8faf9] dark:bg-[#1a2723] p-4 rounded-xl border border-teal-200 dark:border-teal-800/60 space-y-3">
          <div className="flex items-center justify-between text-xs font-bold text-[#17201e] dark:text-[#eef7f4]">
            <span className="flex items-center gap-1.5">
              <Globe className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
              <span>الرابط العام المباشر:</span>
            </span>
            {isGenerating && (
              <span className="flex items-center gap-1 text-teal-600 text-xs">
                <RefreshCw className="w-3 h-3 animate-spin" />
                <span>جارٍ تجهيز الرابط...</span>
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            <input
              type="text"
              readOnly
              value={shareUrl || 'جارٍ إنشاء الرابط العام...'}
              onClick={(e) => (e.target as HTMLInputElement).select()}
              className="flex-1 px-3 py-2 text-xs font-mono bg-white dark:bg-[#121b18] border border-gray-300 dark:border-gray-700 rounded-xl text-[#0f766e] dark:text-[#2dd4bf] select-all focus:outline-none"
            />
            <button
              onClick={handleCopyLink}
              disabled={!shareUrl || isGenerating}
              className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs ${
                copied
                  ? 'bg-emerald-600 text-white'
                  : 'bg-[#0f766e] text-white hover:bg-[#115e59]'
              }`}
            >
              {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              <span>{copied ? 'تم النسخ!' : 'نسخ الرابط'}</span>
            </button>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex flex-wrap items-center gap-2 pt-1">
            <button
              onClick={handleCopyInviteText}
              className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-white dark:bg-[#121b18] border border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800 flex items-center gap-1.5 text-[#17201e] dark:text-[#eef7f4] transition-colors"
            >
              {copiedInvite ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <FileText className="w-3.5 h-3.5 text-teal-600" />}
              <span>{copiedInvite ? 'تم نسخ نص الدعوة!' : 'نسخ رسالة دعوة جاهزة'}</span>
            </button>

            <button
              onClick={shareViaWhatsApp}
              className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-[#25d366]/10 text-[#25d366] hover:bg-[#25d366]/20 flex items-center gap-1.5 transition-colors"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              <span>واتساب</span>
            </button>

            <button
              onClick={shareViaTelegram}
              className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-[#229ed9]/10 text-[#229ed9] hover:bg-[#229ed9]/20 flex items-center gap-1.5 transition-colors"
            >
              <Send className="w-3.5 h-3.5" />
              <span>تيليجرام</span>
            </button>

            {lastPayload && onPreviewShared && (
              <button
                onClick={() => {
                  onPreviewShared(lastPayload);
                  onClose();
                }}
                className="mr-auto px-3 py-1.5 text-xs font-semibold rounded-lg bg-teal-50 dark:bg-teal-950 text-teal-700 dark:text-teal-300 hover:bg-teal-100 flex items-center gap-1.5 transition-colors"
              >
                <Eye className="w-3.5 h-3.5" />
                <span>معاينة ما يراه الزميل</span>
              </button>
            )}
          </div>
        </div>

        {/* Customization Options */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold text-[#17201e] dark:text-[#eef7f4] flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-teal-600" />
              <span>المحتويات المضمنة في الرابط المشترك:</span>
            </h4>
            <button
              onClick={generateLink}
              disabled={isGenerating}
              className="text-xs text-[#0f766e] dark:text-[#2dd4bf] hover:underline font-semibold flex items-center gap-1"
              title="تحديث الرابط بالخيارات الحالية"
            >
              <RefreshCw className={`w-3 h-3 ${isGenerating ? 'animate-spin' : ''}`} />
              <span>تحديث الرابط</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
            {/* Summaries */}
            <label className="flex items-center gap-2 p-2.5 rounded-xl border border-gray-200 dark:border-gray-800 hover:bg-gray-50 dark:hover:bg-gray-800/50 cursor-pointer">
              <input
                type="checkbox"
                checked={includeSummaries}
                onChange={(e) => setIncludeSummaries(e.target.checked)}
                className="w-4 h-4 text-teal-600 rounded focus:ring-teal-500 accent-teal-600"
              />
              <div className="flex-1">
                <span className="font-bold text-[#17201e] dark:text-[#eef7f4] block">الملخصات الأكاديمية</span>
                <span className="text-[10px] text-gray-500">
                  {compiledSummaries.length > 0 ? `${compiledSummaries.length} ملخص متاح` : 'ملخص الدفتر الحالي'}
                </span>
              </div>
            </label>

            {/* Notes */}
            <label className="flex items-center gap-2 p-2.5 rounded-xl border border-gray-200 dark:border-gray-800 hover:bg-gray-50 dark:hover:bg-gray-800/50 cursor-pointer">
              <input
                type="checkbox"
                checked={includeNotes}
                onChange={(e) => setIncludeNotes(e.target.checked)}
                className="w-4 h-4 text-teal-600 rounded focus:ring-teal-500 accent-teal-600"
              />
              <div className="flex-1">
                <span className="font-bold text-[#17201e] dark:text-[#eef7f4] block">الملاحظات التدوينية</span>
                <span className="text-[10px] text-gray-500">{notes.length} ملاحظة وتظليل</span>
              </div>
            </label>

            {/* Study Memos */}
            <label className="flex items-center gap-2 p-2.5 rounded-xl border border-gray-200 dark:border-gray-800 hover:bg-gray-50 dark:hover:bg-gray-800/50 cursor-pointer">
              <input
                type="checkbox"
                checked={includeMemos}
                onChange={(e) => setIncludeMemos(e.target.checked)}
                className="w-4 h-4 text-teal-600 rounded focus:ring-teal-500 accent-teal-600"
              />
              <div className="flex-1">
                <span className="font-bold text-[#17201e] dark:text-[#eef7f4] block">مذكرات الدراسة السريعة</span>
                <span className="text-[10px] text-gray-500">{memos.length} تدوينة دراسية</span>
              </div>
            </label>

            {/* Glossary */}
            <label className="flex items-center gap-2 p-2.5 rounded-xl border border-gray-200 dark:border-gray-800 hover:bg-gray-50 dark:hover:bg-gray-800/50 cursor-pointer">
              <input
                type="checkbox"
                checked={includeGlossary}
                onChange={(e) => setIncludeGlossary(e.target.checked)}
                className="w-4 h-4 text-teal-600 rounded focus:ring-teal-500 accent-teal-600"
              />
              <div className="flex-1">
                <span className="font-bold text-[#17201e] dark:text-[#eef7f4] block">معجم المصطلحات والمفاهيم</span>
                <span className="text-[10px] text-gray-500">{glossary.length} مصطلح مؤصل</span>
              </div>
            </label>

            {/* Flashcards */}
            <label className="flex items-center gap-2 p-2.5 rounded-xl border border-gray-200 dark:border-gray-800 hover:bg-gray-50 dark:hover:bg-gray-800/50 cursor-pointer">
              <input
                type="checkbox"
                checked={includeFlashcards}
                onChange={(e) => setIncludeFlashcards(e.target.checked)}
                className="w-4 h-4 text-teal-600 rounded focus:ring-teal-500 accent-teal-600"
              />
              <div className="flex-1">
                <span className="font-bold text-[#17201e] dark:text-[#eef7f4] block">بطاقات الاستذكار (Flashcards)</span>
                <span className="text-[10px] text-gray-500">{flashcards.length} بطاقة مراجعة</span>
              </div>
            </label>

            {/* Sources Overview */}
            <label className="flex items-center gap-2 p-2.5 rounded-xl border border-gray-200 dark:border-gray-800 hover:bg-gray-50 dark:hover:bg-gray-800/50 cursor-pointer">
              <input
                type="checkbox"
                checked={includeSources}
                onChange={(e) => setIncludeSources(e.target.checked)}
                className="w-4 h-4 text-teal-600 rounded focus:ring-teal-500 accent-teal-600"
              />
              <div className="flex-1">
                <span className="font-bold text-[#17201e] dark:text-[#eef7f4] block">قائمة المراجع والمصادر</span>
                <span className="text-[10px] text-gray-500">{sources.length} وثيقة ومصدر</span>
              </div>
            </label>
          </div>
        </div>

        {/* Author / Student Name */}
        <div className="flex items-center gap-3">
          <div className="w-full">
            <label className="block text-xs font-bold text-[#596762] dark:text-[#9ab3ab] mb-1">
              اسم الباحث / صاحب الدفتر (سيظهر للزملاء):
            </label>
            <div className="relative">
              <input
                type="text"
                value={authorName}
                onChange={(e) => setAuthorName(e.target.value)}
                placeholder="مثال: أحمد خالد، فريق العلوم..."
                className="w-full px-3 py-2 text-xs border border-gray-300 dark:border-gray-700 rounded-xl bg-[#f8faf9] dark:bg-[#121b18] text-[#17201e] dark:text-[#eef7f4] focus:outline-none focus:border-teal-500"
              />
              <User className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-3 pointer-events-none" />
            </div>
          </div>
        </div>

        {/* Privacy Note */}
        <div className="p-3 bg-teal-50/60 dark:bg-teal-950/40 rounded-xl border border-teal-200/80 dark:border-teal-900 flex items-start gap-2.5 text-xs text-teal-900 dark:text-teal-200">
          <ShieldCheck className="w-4 h-4 text-teal-600 dark:text-teal-400 shrink-0 mt-0.5" />
          <div className="space-y-1 leading-relaxed">
            <p className="font-bold">أمان وخصوصية تامة:</p>
            <p className="text-[11px] text-teal-800 dark:text-teal-300">
              الرابط للقراءة فقط ولا يمكن لأي شخص التعديل على بيانات دفترك الأصلية. يمكن للزميل استعراض التلخيصات وحفظ نسخة خاصة به في حسابه للمذاكرة.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between pt-2 border-t border-[#e2e8e5] dark:border-[#22352f]">
          <span className="text-[11px] text-gray-500">
            دفتر: {notebook.name} ({notebook.subject || 'عام'})
          </span>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-semibold border border-gray-300 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
            >
              إغلاق
            </button>
            <button
              onClick={handleCopyLink}
              className="px-5 py-2 rounded-xl text-xs font-bold bg-[#0f766e] text-white hover:bg-[#115e59] shadow-md shadow-[#0f766e]/20 flex items-center gap-1.5 transition-all"
            >
              {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              <span>{copied ? 'تم النسخ!' : 'نسخ رابط المشاركة'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
