import React, { useState } from 'react';
import {
  X,
  Globe,
  Scissors,
  CheckCircle2,
  AlertCircle,
  Loader2,
  FileText,
  Sparkles,
  ArrowRight,
  TrendingDown,
  Layers,
  BookOpen,
} from 'lucide-react';
import { Source, SourceChunk } from '../types';
import { chunkText } from '../lib/pdfExtractor';
import { generateInitialIndexingReport } from '../lib/indexingReporter';

interface WebArticleClipperModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentNotebookId: string;
  onAddSource: (source: Source, chunks: SourceChunk[]) => void;
}

export const WebArticleClipperModal: React.FC<WebArticleClipperModalProps> = ({
  isOpen,
  onClose,
  currentNotebookId,
  onAddSource,
}) => {
  const [url, setUrl] = useState('');
  const [titleHint, setTitleHint] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [stepStatus, setStepStatus] = useState('');
  const [extractedData, setExtractedData] = useState<{
    title: string;
    cleanText: string;
    originalSize: number;
    cleanedSize: number;
    prunedRatio: number;
    wordCount: number;
  } | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleClipArticle = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url.trim()) return;

    setErrorMsg(null);
    setIsProcessing(true);
    setExtractedData(null);

    try {
      setStepStatus('جاري الاتصال بعنوان المقال واستدعاء صفحة الويب...');
      
      const res = await fetch('/api/fetch-url', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: url.trim() }),
      });

      if (!res.ok) {
        throw new Error('تعذر جلب المقال من خادم الويب. يرجى التأكد من الرابط.');
      }

      setStepStatus('تشغيل تقنية تقليم المحتوى الزائد (DOM Trimming & Boilerplate Removal)...');

      const data = await res.json();
      if (!data.success && data.error) {
        throw new Error(data.error);
      }

      const rawContent = data.content || data.text || '';
      if (!rawContent || rawContent.trim().length < 40) {
        throw new Error('المحتوى المستخرج قصير جداً أو تم حجب المقال.');
      }

      const originalSize = data.size || rawContent.length * 2.5;
      const cleanedSize = rawContent.length;
      const prunedRatio = Math.max(15, Math.min(95, Math.round(((originalSize - cleanedSize) / Math.max(1, originalSize)) * 100)));

      setExtractedData({
        title: titleHint.trim() || data.title || 'مقال علمي مستورد من الويب',
        cleanText: rawContent,
        originalSize,
        cleanedSize,
        prunedRatio,
        wordCount: data.wordCount || rawContent.split(/\s+/).filter(Boolean).length,
      });

      setStepStatus('✓ تم تقليم المحتوى الزائد واستخلاص النص المعرفي الصافي بنجاح!');
    } catch (err: any) {
      console.error('Clipper error:', err);
      setErrorMsg(err.message || 'فشل استيراد وتقليم مقال الويب');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleConfirmImport = () => {
    if (!extractedData) return;

    const sourceId = `src_clipped_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const realChunks = chunkText(extractedData.cleanText, sourceId, extractedData.title, currentNotebookId, 750, 75);

    const newSource: Source = {
      id: sourceId,
      notebookId: currentNotebookId,
      title: extractedData.title,
      uri: url.trim(),
      type: 'text/html',
      size: extractedData.cleanedSize,
      status: 'Ready',
      content: extractedData.cleanText,
      wordCount: extractedData.wordCount,
      lineCount: extractedData.cleanText.split('\n').length,
      pageCount: 1,
      pages: [{ pageNumber: 1, text: extractedData.cleanText }],
      createdAt: Date.now(),
      updatedAt: Date.now(),
      localFileId: sourceId,
    };

    const indexingReport = generateInitialIndexingReport(
      extractedData.title,
      extractedData.cleanText,
      ['مقال ويب مقلّم ومنقّى دلالياً'],
      1
    );
    newSource.indexingReport = indexingReport;

    onAddSource(newSource, realChunks);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="bg-white dark:bg-[#121c19] border border-slate-200 dark:border-[#22352f] rounded-3xl shadow-2xl w-full max-w-2xl overflow-hidden flex flex-col max-h-[90vh]"
        dir="rtl"
      >
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-teal-50 to-emerald-50 dark:from-[#152420] dark:to-[#172722] border-b border-slate-200 dark:border-[#22352f] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-teal-600 text-white flex items-center justify-center shadow-xs">
              <Scissors className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-black text-slate-900 dark:text-slate-100 flex items-center gap-2">
                <span>أداة استيراد مقالات الويب وتقليم المحتوى الزائد</span>
                <span className="text-[10px] font-bold bg-teal-600 text-white px-2 py-0.5 rounded-full">
                  Boilerplate Pruning
                </span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                تقنية ذكية لحذف الإعلانات والقوائم والروابط الزائدة وتحويل المقال إلى مصدر معرفي صافٍ
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-4 flex-1">
          <form onSubmit={handleClipArticle} className="space-y-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                رابط صفحة أو مقال الويب المراد استيراده *
              </label>
              <div className="relative">
                <input
                  type="url"
                  required
                  placeholder="https://ar.wikipedia.org/wiki/... أو أي موقع علمي"
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  className="w-full pl-3 pr-10 py-2.5 text-xs bg-slate-50 dark:bg-[#182723] border border-slate-200 dark:border-[#263e36] rounded-xl text-slate-900 dark:text-slate-100 focus:outline-none focus:border-teal-500 transition-all font-mono"
                />
                <Globe className="w-4 h-4 text-slate-400 absolute right-3 top-3" />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                عنوان مخصص للمقال (اختياري)
              </label>
              <input
                type="text"
                placeholder="مثال: النظرية الكهرومغناطيسية وتطبيقاتها"
                value={titleHint}
                onChange={(e) => setTitleHint(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-[#182723] border border-slate-200 dark:border-[#263e36] rounded-xl text-slate-900 dark:text-slate-100 focus:outline-none focus:border-teal-500 transition-all"
              />
            </div>

            <button
              type="submit"
              disabled={isProcessing || !url.trim()}
              className="w-full py-2.5 px-4 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 shadow-xs transition-all cursor-pointer disabled:opacity-50 active:scale-98"
            >
              {isProcessing ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>جاري استخراج وتقليم المحتوى...</span>
                </>
              ) : (
                <>
                  <Scissors className="w-4 h-4" />
                  <span>تقليم الشوائب واستخراج النص المعرفي</span>
                </>
              )}
            </button>
          </form>

          {/* Processing Status / Toast */}
          {stepStatus && (
            <div className="p-3 rounded-xl bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-800 text-xs font-bold text-teal-800 dark:text-teal-300 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-teal-600 shrink-0" />
              <span>{stepStatus}</span>
            </div>
          )}

          {errorMsg && (
            <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-xs text-rose-800 dark:text-rose-200 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Extracted Preview Card */}
          {extractedData && (
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-[#162520] border border-teal-500/30 space-y-3 animate-in fade-in duration-150">
              <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-200 dark:border-[#20362f]">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                  <h4 className="text-xs font-black text-slate-900 dark:text-slate-100">
                    {extractedData.title}
                  </h4>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-bold px-2 py-0.5 rounded-md bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-mono flex items-center gap-1">
                    <TrendingDown className="w-3 h-3" />
                    <span>تم تقليم {extractedData.prunedRatio}% شوائب</span>
                  </span>
                  <span className="text-[11px] text-slate-500 font-mono">
                    {extractedData.wordCount} كلمة
                  </span>
                </div>
              </div>

              <div className="max-h-48 overflow-y-auto p-3 rounded-xl bg-white dark:bg-[#111c18] border border-slate-200 dark:border-[#22352f] text-xs text-slate-700 dark:text-slate-300 leading-relaxed font-sans whitespace-pre-line">
                {extractedData.cleanText.slice(0, 800)}...
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-3 py-1.5 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-[#1f332c] cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="button"
                  onClick={handleConfirmImport}
                  className="px-4 py-1.5 rounded-xl text-xs font-black bg-gradient-to-r from-teal-600 to-emerald-600 text-white hover:opacity-95 shadow-xs flex items-center gap-1.5 cursor-pointer"
                >
                  <BookOpen className="w-3.5 h-3.5" />
                  <span>تأكيد الإضافة كمصدر في الدفتر</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
