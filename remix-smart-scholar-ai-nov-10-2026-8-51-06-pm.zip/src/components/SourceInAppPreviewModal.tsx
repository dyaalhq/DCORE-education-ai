import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  X,
  Maximize2,
  Minimize2,
  FileText,
  BookOpen,
  MessageSquare,
  Download,
  Printer,
  Copy,
  Check,
  Search,
  Eye,
  Sparkles,
  ExternalLink,
  Highlighter,
  ChevronLeft,
  ChevronRight,
  ZoomIn,
  ZoomOut,
  Layers,
  FileCode,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { Source, SourceAnnotation, HighlightColor } from '../types';
import { getFileBlob, storeFileBlob } from '../lib/storage';
import { COLOR_MAP } from './PDFPreviewAnnotator';

interface SourceInAppPreviewModalProps {
  source: Source;
  onClose: () => void;
  onAskAboutSource?: (source: Source) => void;
  onAskAboutQuote?: (quote: string, pageNumber: number) => void;
  onExportToNote?: (title: string, content: string) => void;
  onUpdateAnnotations?: (sourceId: string, annotations: SourceAnnotation[]) => void;
}

export const SourceInAppPreviewModal: React.FC<SourceInAppPreviewModalProps> = ({
  source,
  onClose,
  onAskAboutSource,
  onAskAboutQuote,
  onExportToNote,
  onUpdateAnnotations,
}) => {
  const [activeTab, setActiveTab] = useState<'original' | 'reader' | 'extracted'>('original');
  const [blobUrl, setBlobUrl] = useState<string | null>(null);
  const [isLoadingBlob, setIsLoadingBlob] = useState(false);
  const [blobError, setBlobError] = useState<string | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [zoomLevel, setZoomLevel] = useState(100);
  const [copiedText, setCopiedText] = useState(false);
  const [selectedHighlightColor, setSelectedHighlightColor] = useState<HighlightColor>('yellow');
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const speechUtteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  const isPdf =
    source.type === 'application/pdf' ||
    source.title?.toLowerCase().endsWith('.pdf') ||
    (source.uri && source.uri.toLowerCase().includes('.pdf'));

  const isHtml =
    source.type?.includes('html') ||
    !!source.rawHtml ||
    source.title?.toLowerCase().endsWith('.html') ||
    source.title?.toLowerCase().endsWith('.htm');

  // Load Blob for native PDF or media preview
  useEffect(() => {
    let isCancelled = false;
    let createdUrl: string | null = null;

    async function loadSourceBlob() {
      if (!isPdf) return;
      setIsLoadingBlob(true);
      setBlobError(null);

      try {
        const fileId = source.localFileId || source.id;
        let blob = await getFileBlob(fileId);

        // If not found in IndexedDB but has external URL, fetch via proxy
        if (!blob && source.uri) {
          try {
            const proxyRes = await fetch(`/api/proxy-pdf?url=${encodeURIComponent(source.uri)}`);
            if (proxyRes.ok) {
              blob = await proxyRes.blob();
              await storeFileBlob(fileId, blob, {
                name: source.title,
                type: 'application/pdf',
                notebookId: source.notebookId,
              });
            }
          } catch (fetchErr) {
            console.warn('Proxy PDF fetch notice:', fetchErr);
          }
        }

        if (isCancelled) return;

        if (blob) {
          createdUrl = URL.createObjectURL(blob);
          setBlobUrl(createdUrl);
        } else {
          // If no blob is available, fallback to reader mode cleanly
          setActiveTab('reader');
        }
      } catch (err: any) {
        if (!isCancelled) {
          setBlobError('تعذر تجهيز العارض الأصلي للملف، تم التحويل تلقائياً لوضع القارئ الذكي.');
          setActiveTab('reader');
        }
      } finally {
        if (!isCancelled) setIsLoadingBlob(false);
      }
    }

    loadSourceBlob();

    return () => {
      isCancelled = true;
      if (createdUrl) {
        URL.revokeObjectURL(createdUrl);
      }
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, [source.id, source.localFileId, source.uri, isPdf, source.notebookId, source.title]);

  // Handle escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  // Handle Copy text
  const handleCopyContent = () => {
    const textToCopy = source.content || '';
    if (!textToCopy) return;
    navigator.clipboard.writeText(textToCopy);
    setCopiedText(true);
    setTimeout(() => setCopiedText(false), 2000);
  };

  // Text to Speech
  const handleToggleSpeak = () => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    if (isPlayingAudio) {
      window.speechSynthesis.cancel();
      setIsPlayingAudio(false);
      return;
    }

    const textToRead = source.pages?.find((p) => p.pageNumber === currentPage)?.text || source.content || '';
    if (!textToRead) return;

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(textToRead.slice(0, 3000));
    utterance.lang = 'ar-SA';
    utterance.rate = 1.0;
    utterance.onend = () => setIsPlayingAudio(false);
    utterance.onerror = () => setIsPlayingAudio(false);
    speechUtteranceRef.current = utterance;
    window.speechSynthesis.speak(utterance);
    setIsPlayingAudio(true);
  };

  // Filtered pages / content
  const pages = useMemo(() => {
    if (source.pages && source.pages.length > 0) {
      return source.pages;
    }
    // Fallback: split content into pseudo-pages of ~1500 chars
    const text = source.content || '';
    if (!text) return [{ pageNumber: 1, text: 'لا يوجد محتوى نصي مستخرج.' }];
    const chunkSize = 1800;
    const result: Array<{ pageNumber: number; text: string }> = [];
    for (let i = 0; i < text.length; i += chunkSize) {
      result.push({
        pageNumber: result.length + 1,
        text: text.slice(i, i + chunkSize),
      });
    }
    return result;
  }, [source.pages, source.content]);

  const totalPages = source.pageCount || pages.length || 1;
  const activePageData = pages.find((p) => p.pageNumber === currentPage) || pages[0];

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-md p-2 sm:p-4 animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        className={`bg-white dark:bg-[#121c18] rounded-3xl shadow-2xl border border-teal-500/30 flex flex-col overflow-hidden transition-all duration-300 ${
          isFullscreen ? 'w-full h-full rounded-none' : 'w-full max-w-6xl h-[92vh]'
        }`}
      >
        {/* Top Header Bar */}
        <div className="px-4 py-3 sm:px-6 bg-gradient-to-r from-teal-900 via-[#0f766e] to-teal-950 text-white flex flex-wrap items-center justify-between gap-3 border-b border-teal-600/40">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-white/15 flex items-center justify-center shrink-0 backdrop-blur-sm">
              {isPdf ? (
                <FileText className="w-5 h-5 text-amber-300" />
              ) : isHtml ? (
                <FileCode className="w-5 h-5 text-teal-200" />
              ) : (
                <BookOpen className="w-5 h-5 text-emerald-300" />
              )}
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h2 className="text-sm sm:text-base font-bold truncate max-w-md" title={source.title}>
                  {source.title}
                </h2>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-white/20 text-white shrink-0">
                  {isPdf ? 'مستند PDF' : isHtml ? 'صفحة ويب' : 'مستند نصي'}
                </span>
              </div>
              <div className="text-[11px] text-teal-100/80 flex items-center gap-2.5 mt-0.5">
                {source.pageCount && <span>{source.pageCount} صفحة</span>}
                {source.wordCount && <span>• {source.wordCount.toLocaleString()} كلمة</span>}
                {source.size && <span>• {(source.size / (1024 * 1024)).toFixed(1)} ميغابايت</span>}
              </div>
            </div>
          </div>

          {/* Navigation Mode Tabs */}
          <div className="flex items-center gap-1 bg-black/25 p-1 rounded-2xl backdrop-blur-md">
            {isPdf && blobUrl && (
              <button
                type="button"
                onClick={() => setActiveTab('original')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                  activeTab === 'original'
                    ? 'bg-white text-teal-900 shadow-sm'
                    : 'text-white/80 hover:text-white hover:bg-white/10'
                }`}
              >
                <Eye className="w-3.5 h-3.5" />
                <span>المستند الأصلي (PDF)</span>
              </button>
            )}

            {isHtml && source.rawHtml && (
              <button
                type="button"
                onClick={() => setActiveTab('original')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                  activeTab === 'original'
                    ? 'bg-white text-teal-900 shadow-sm'
                    : 'text-white/80 hover:text-white hover:bg-white/10'
                }`}
              >
                <Eye className="w-3.5 h-3.5" />
                <span>عرض الويب الأصلي</span>
              </button>
            )}

            <button
              type="button"
              onClick={() => setActiveTab('reader')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'reader'
                  ? 'bg-white text-teal-900 shadow-sm'
                  : 'text-white/80 hover:text-white hover:bg-white/10'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>القارئ الذكي والصفحات</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('extracted')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'extracted'
                  ? 'bg-white text-teal-900 shadow-sm'
                  : 'text-white/80 hover:text-white hover:bg-white/10'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>النص الكامل والمعالجة</span>
            </button>
          </div>

          {/* Quick Actions (Ask AI, Audio, Fullscreen, Close) */}
          <div className="flex items-center gap-2">
            {onAskAboutSource && (
              <button
                type="button"
                onClick={() => {
                  onAskAboutSource(source);
                  onClose();
                }}
                className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-600 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm cursor-pointer"
                title="افتح محادثة الذكاء الاصطناعي مع هذا المصدر"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">اسأل عنه في الدردشة</span>
              </button>
            )}

            <button
              type="button"
              onClick={handleToggleSpeak}
              className={`p-2 rounded-xl transition-all cursor-pointer ${
                isPlayingAudio ? 'bg-amber-400 text-amber-950 font-bold' : 'bg-white/15 hover:bg-white/25 text-white'
              }`}
              title={isPlayingAudio ? 'إيقاف القراءة الصوتية' : 'قراءة صوتية (Text-to-Speech)'}
            >
              {isPlayingAudio ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>

            <button
              type="button"
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="p-2 rounded-xl bg-white/15 hover:bg-white/25 text-white transition-all cursor-pointer"
              title={isFullscreen ? 'تصغير النافذة' : 'وضع ملء الشاشة'}
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>

            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl bg-white/20 hover:bg-rose-600 text-white transition-all cursor-pointer"
              title="إغلاق المعاينة (Esc)"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Content View Area */}
        <div className="flex-1 overflow-hidden relative flex flex-col bg-slate-50 dark:bg-[#0e1613]">
          {/* TAB 1: ORIGINAL DOCUMENT VIEW (Native PDF Object / Clean Web IFrame) */}
          {activeTab === 'original' && (
            <div className="w-full h-full flex flex-col">
              {isPdf ? (
                blobUrl ? (
                  <div className="w-full h-full relative">
                    <object
                      data={blobUrl}
                      type="application/pdf"
                      className="w-full h-full border-0"
                    >
                      <iframe
                        src={blobUrl}
                        title={source.title}
                        className="w-full h-full border-0"
                      >
                        <div className="p-8 text-center space-y-3">
                          <p className="text-sm font-semibold text-slate-700 dark:text-slate-300">
                            يتعذر على متصفحك عرض ملف PDF مباشرة عبر الإطار المضمن.
                          </p>
                          <button
                            type="button"
                            onClick={() => setActiveTab('reader')}
                            className="px-4 py-2 bg-teal-600 text-white rounded-xl text-xs font-bold cursor-pointer"
                          >
                            الانتقال إلى وضع القارئ الذكي
                          </button>
                        </div>
                      </iframe>
                    </object>
                  </div>
                ) : isLoadingBlob ? (
                  <div className="w-full h-full flex flex-col items-center justify-center p-8 space-y-3">
                    <div className="w-8 h-8 border-3 border-teal-600 border-t-transparent rounded-full animate-spin" />
                    <p className="text-xs font-bold text-teal-800 dark:text-teal-300">
                      جاري تجهيز وتحميل المستند الأصلي للعرض...
                    </p>
                  </div>
                ) : (
                  <div className="w-full h-full flex flex-col items-center justify-center p-8 text-center space-y-3">
                    <p className="text-xs text-slate-500">
                      الملف الأصلي غير مخزن محلياً كـ PDF مباشر. تم تحويلك للقارئ الذكي.
                    </p>
                    <button
                      type="button"
                      onClick={() => setActiveTab('reader')}
                      className="px-4 py-2 bg-teal-600 text-white rounded-xl text-xs font-bold"
                    >
                      فتح القارئ الذكي
                    </button>
                  </div>
                )
              ) : isHtml && source.rawHtml ? (
                <div className="w-full h-full">
                  <iframe
                    title={source.title}
                    srcDoc={source.rawHtml}
                    sandbox="allow-scripts allow-same-origin"
                    className="w-full h-full border-0 bg-white"
                  />
                </div>
              ) : (
                <div className="p-8 text-center">
                  <p className="text-xs text-slate-500">لا يوجد عارض أصلي متاح لهذا النوع من المصادر.</p>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: SMART READER & PAGE BY PAGE (With Search & Highlighting) */}
          {activeTab === 'reader' && (
            <div className="w-full h-full flex flex-col">
              {/* Reader Sub-Toolbar */}
              <div className="px-4 py-2.5 bg-white dark:bg-[#14201c] border-b border-slate-200 dark:border-[#22352f] flex flex-wrap items-center justify-between gap-3 text-xs">
                {/* Page Navigation */}
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    disabled={currentPage <= 1}
                    onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                    className="p-1.5 rounded-lg border border-slate-200 dark:border-[#22352f] disabled:opacity-40 hover:bg-slate-100 dark:hover:bg-[#1d2d27] cursor-pointer"
                    title="الصفحة السابقة"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                  <span className="font-bold text-slate-700 dark:text-slate-200">
                    صفحة {currentPage} من {totalPages}
                  </span>
                  <button
                    type="button"
                    disabled={currentPage >= totalPages}
                    onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                    className="p-1.5 rounded-lg border border-slate-200 dark:border-[#22352f] disabled:opacity-40 hover:bg-slate-100 dark:hover:bg-[#1d2d27] cursor-pointer"
                    title="الصفحة التالية"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                </div>

                {/* Search in Page */}
                <div className="relative flex-1 max-w-xs">
                  <Search className="w-3.5 h-3.5 absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="ابحث في نص الصفحة..."
                    className="w-full pr-8 pl-3 py-1.5 rounded-xl border border-slate-200 dark:border-[#22352f] bg-slate-50 dark:bg-[#101b17] text-xs focus:outline-none focus:border-teal-500"
                  />
                </div>

                {/* Highlight colors */}
                <div className="flex items-center gap-1">
                  <span className="text-[11px] text-slate-400 font-semibold ml-1">تظليل:</span>
                  {(['yellow', 'green', 'blue', 'purple', 'rose'] as HighlightColor[]).map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setSelectedHighlightColor(c)}
                      className={`w-5 h-5 rounded-full border-2 transition-all cursor-pointer ${
                        selectedHighlightColor === c ? 'scale-110 border-teal-700 dark:border-white shadow-xs' : 'border-transparent'
                      }`}
                      style={{ backgroundColor: COLOR_MAP[c].bg }}
                      title={COLOR_MAP[c].name}
                    />
                  ))}
                </div>

                {/* Copy & Note Buttons */}
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={handleCopyContent}
                    className="px-2.5 py-1 rounded-lg border border-slate-200 dark:border-[#22352f] hover:bg-slate-100 dark:hover:bg-[#1d2d27] flex items-center gap-1 text-[11px] font-semibold cursor-pointer"
                  >
                    {copiedText ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedText ? 'تم النسخ' : 'نسخ النص'}</span>
                  </button>

                  {onExportToNote && (
                    <button
                      type="button"
                      onClick={() => {
                        onExportToNote(
                          `ملاحظة من «${source.title}» - صفحة ${currentPage}`,
                          activePageData?.text || ''
                        );
                        alert('تم تصدير نص الصفحة إلى مذكراتك بنجاح! 📝');
                      }}
                      className="px-2.5 py-1 rounded-lg bg-teal-50 dark:bg-teal-950/60 text-teal-800 dark:text-teal-200 border border-teal-200 dark:border-teal-800 hover:bg-teal-100 text-[11px] font-bold cursor-pointer"
                    >
                      حفظ في الملاحظات
                    </button>
                  )}
                </div>
              </div>

              {/* Reader Page Content */}
              <div className="flex-1 overflow-y-auto p-4 sm:p-8 flex justify-center">
                <div className="w-full max-w-3xl bg-white dark:bg-[#14201c] rounded-2xl shadow-sm border border-slate-200 dark:border-[#22352f] p-6 sm:p-10 space-y-4">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-[#1d2d27] text-xs text-slate-400">
                    <span>{source.title}</span>
                    <span className="font-bold">الصفحة {currentPage}</span>
                  </div>

                  <div className="text-sm sm:text-base leading-relaxed text-slate-800 dark:text-slate-100 whitespace-pre-wrap font-sans selection:bg-teal-100 dark:selection:bg-teal-900/60 selection:text-teal-900 dark:selection:text-teal-100">
                    {searchQuery ? (
                      activePageData?.text.split(new RegExp(`(${searchQuery})`, 'gi')).map((part, i) =>
                        part.toLowerCase() === searchQuery.toLowerCase() ? (
                          <mark key={i} className="bg-yellow-300 dark:bg-yellow-500/40 text-black dark:text-white px-0.5 rounded">
                            {part}
                          </mark>
                        ) : (
                          part
                        )
                      )
                    ) : (
                      activePageData?.text || 'لا يوجد محتوى نصي لهذه الصفحة.'
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: EXTRACTED FULL TEXT & DATA BLOCKS */}
          {activeTab === 'extracted' && (
            <div className="w-full h-full overflow-y-auto p-4 sm:p-8 flex justify-center">
              <div className="w-full max-w-4xl bg-white dark:bg-[#14201c] rounded-2xl shadow-sm border border-slate-200 dark:border-[#22352f] p-6 sm:p-8 space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-[#1d2d27]">
                  <h3 className="font-bold text-sm text-slate-800 dark:text-slate-100 flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-teal-600" />
                    <span>النص المعالج الكامل المفهرس في نظام الذاكرة (RAG)</span>
                  </h3>
                  <button
                    type="button"
                    onClick={handleCopyContent}
                    className="px-3 py-1 bg-slate-100 dark:bg-[#1d2d27] hover:bg-slate-200 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-bold flex items-center gap-1 cursor-pointer"
                  >
                    {copiedText ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedText ? 'تم النسخ!' : 'نسخ المستند كاملاً'}</span>
                  </button>
                </div>

                <div className="p-4 rounded-xl bg-slate-50 dark:bg-[#101b17] border border-slate-200/80 dark:border-[#22352f] text-xs sm:text-sm leading-relaxed text-slate-800 dark:text-slate-200 whitespace-pre-wrap max-h-[60vh] overflow-y-auto font-mono">
                  {source.content || 'لا يتوفر نص مستخرج.'}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer Bar */}
        <div className="px-4 py-2.5 sm:px-6 bg-white dark:bg-[#121c18] border-t border-slate-200 dark:border-[#22352f] flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-slate-500 dark:text-slate-400">
            <span>المصدر: {source.title}</span>
            {source.uri && (
              <a
                href={source.uri}
                target="_blank"
                rel="noopener noreferrer"
                className="text-teal-600 dark:text-teal-400 hover:underline flex items-center gap-0.5"
              >
                <span>الرابط الأصلي</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            )}
          </div>

          <div className="flex items-center gap-2">
            {blobUrl && (
              <a
                href={blobUrl}
                download={`${source.title || 'document'}.pdf`}
                className="px-3 py-1.5 bg-slate-100 dark:bg-[#1d2d27] hover:bg-slate-200 text-slate-800 dark:text-slate-200 rounded-xl font-bold flex items-center gap-1 cursor-pointer transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                <span>تنزيل الملف</span>
              </a>
            )}

            <button
              type="button"
              onClick={onClose}
              className="px-4 py-1.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl font-bold cursor-pointer transition-colors"
            >
              إغلاق
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
