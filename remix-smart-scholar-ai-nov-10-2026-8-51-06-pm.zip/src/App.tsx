import React, { useState, useEffect } from 'react';
import { 
  loadAppState, 
  saveAppState, 
  AppState, 
  deleteFileBlob 
} from './lib/storage';
import { 
  Notebook, 
  Source, 
  SourceChunk, 
  ChatSession, 
  ChatMessage, 
  Citation, 
  Flashcard, 
  TodoItem, 
  MemoItem, 
  GlossaryItem, 
  FocusSession,
  AIMode,
  SourceAnnotation,
  NoteItem,
  MindMapNode
} from './types';
import { buildDeepMindMapFromText } from './lib/mindMapParser';
import {
  generateMindMapFromSingleMessageAI,
  generateMindMapFromConversationAI,
} from './lib/studioAiBridge';

import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { HomeView } from './components/HomeView';
import { SourcesView } from './components/SourcesView';
import { ChatView } from './components/ChatView';
import { StudyStudioView } from './components/StudyStudioView';
import { ToolsView } from './components/ToolsView';
import { ExportView } from './components/ExportView';
import { SettingsView } from './components/SettingsView';
import { ShareNotebookModal } from './components/ShareNotebookModal';
import { SharedNotebookView } from './components/SharedNotebookView';
import { AcademicPrintModal } from './components/AcademicPrintModal';
import { D3VisualMindMap } from './components/D3VisualMindMap';
import { StudentAuthModal } from './components/StudentAuthModal';
import { ScienceLabView } from './components/ScienceLabView';
import { QuestionBankView } from './components/QuestionBankView';
import { AchievementsDashboard } from './components/AchievementsDashboard';
import { OmniAcademicReferenceModal } from './components/OmniAcademicReferenceModal';
import { VoiceMemoModal } from './components/VoiceMemoModal';
import { ErrorBoundary } from './components/ErrorBoundary';
import { fetchPublicNotebookShare, SharedNotebookPayload } from './lib/shareService';
import { extractStructuredSummary, StructuredSummary } from './lib/academicFormatter';
import { 
  signInWithGoogleAccount, 
  syncWorkspaceToCloud, 
  restoreWorkspaceFromCloud,
  signOutGoogleSession 
} from './lib/cloudAuth';
import { backgroundSync } from './lib/backgroundSync';
import { vectorStore } from './lib/vectorStore';
import { playAlarmSound } from './lib/audioAlarm';
import { applyLanguageToDOM, getStoredLanguage, setStoredLanguage, SupportedLanguage, t } from './lib/i18n';
import { calculateSM2Schedule, ReviewRating } from './lib/spacedRepetition';
import { SupportModal } from './components/SupportModal';
import { OfflineIndicator } from './components/OfflineIndicator';
import { 
  Loader2, 
  AlertCircle, 
  ArrowRight,
  LayoutDashboard,
  MessageSquare,
  FileText,
  BookOpen,
  Menu as MenuIcon,
  GitFork,
  Sparkles,
  Play,
  Pause,
  RotateCcw,
  Clock,
  X,
  FlaskConical,
  HelpCircle,
  GraduationCap,
  User,
  Mic
} from 'lucide-react';

export function App() {
  const [appState, setAppState] = useState<AppState>(() => loadAppState());
  const [currentTab, setCurrentTab] = useState<string>('home');
  const [navHistory, setNavHistory] = useState<string[]>([]);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [selectedSourceIds, setSelectedSourceIds] = useState<string[]>([]);
  const [aiConnected, setAiConnected] = useState(true);
  const [prefilledChatPrompt, setPrefilledChatPrompt] = useState<string>('');

  const navigateToTab = (newTab: string) => {
    if (newTab === currentTab) return;
    setNavHistory((prev) => [...prev, currentTab]);
    setCurrentTab(newTab);
  };

  const handleGoBack = () => {
    if (navHistory.length === 0) return;
    const previousTab = navHistory[navHistory.length - 1];
    setNavHistory((prev) => prev.slice(0, prev.length - 1));
    setCurrentTab(previousTab);
  };

  // Public Sharing state
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [shareModalNotebookId, setShareModalNotebookId] = useState<string | null>(null);
  const [sharedViewPayload, setSharedViewPayload] = useState<SharedNotebookPayload | null>(null);
  const [isLoadingShared, setIsLoadingShared] = useState(false);
  const [shareLoadError, setShareLoadError] = useState<string | null>(null);
  const [sharedPrintModalSummary, setSharedPrintModalSummary] = useState<StructuredSummary | null>(null);

  // Cloud Auth & Sync state
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isSupportModalOpen, setIsSupportModalOpen] = useState(false);
  const [isAcademicRefModalOpen, setIsAcademicRefModalOpen] = useState(false);
  const [isVoiceMemoModalOpen, setIsVoiceMemoModalOpen] = useState(false);
  const [currentLanguage, setCurrentLanguage] = useState<SupportedLanguage>(() => getStoredLanguage());
  const [isSyncingCloud, setIsSyncingCloud] = useState(false);
  const [lastSyncTimestamp, setLastSyncTimestamp] = useState<number | undefined>(
    appState.userProfile?.lastSyncAt
  );

  const handleLanguageChange = (lang: SupportedLanguage) => {
    setCurrentLanguage(lang);
    setStoredLanguage(lang);
    applyLanguageToDOM(lang);
  };

  // Deep Focus Mode & Integrated Pomodoro Countdown State
  const [isDeepFocusActive, setIsDeepFocusActive] = useState<boolean>(false);
  const [deepFocusDurationMins, setDeepFocusDurationMins] = useState<number>(25);

  // Active Custom Mind Map State (from chat/text conversion)
  const [activeMindMapData, setActiveMindMapData] = useState<MindMapNode | null>(null);
  const [isGeneratingMindMap, setIsGeneratingMindMap] = useState<boolean>(false);
  const [mindMapToastMessage, setMindMapToastMessage] = useState<string>('');

  const handleGenerateMindMapFromText = async (text: string, title?: string) => {
    setIsGeneratingMindMap(true);
    setMindMapToastMessage('جارٍ بناء خريطة ذهنية تفاعلية لهذا الرد بالذكاء الاصطناعي...');
    try {
      const mapData = await generateMindMapFromSingleMessageAI(
        text,
        title || currentNotebook.name,
        appState.settings.fallbackAI
      );
      setActiveMindMapData(mapData);
      navigateToTab('mindmap');
    } catch (e) {
      console.warn('Failed to generate single message mind map with AI, falling back:', e);
      const fallbackMap = buildDeepMindMapFromText(text, title || currentNotebook.name);
      setActiveMindMapData(fallbackMap);
      navigateToTab('mindmap');
    } finally {
      setIsGeneratingMindMap(false);
      setTimeout(() => setMindMapToastMessage(''), 4000);
    }
  };

  const handleGenerateMindMapFromConversation = async (messages: ChatSession['messages']) => {
    setIsGeneratingMindMap(true);
    setMindMapToastMessage('جارٍ استخلاص وتوليد خريطة ذهنية تفاعلية لكامل المحادثة بالذكاء الاصطناعي...');
    try {
      const mapData = await generateMindMapFromConversationAI(
        messages,
        currentNotebook.name,
        appState.settings.fallbackAI
      );
      setActiveMindMapData(mapData);
      navigateToTab('mindmap');
    } catch (e) {
      console.warn('Failed to generate whole conversation mind map with AI, falling back:', e);
      const aiTexts = messages.filter((m) => m.role !== 'user').map((m) => m.text).join('\n\n');
      const fallbackMap = buildDeepMindMapFromText(aiTexts || currentNotebook.name, currentNotebook.name);
      setActiveMindMapData(fallbackMap);
      navigateToTab('mindmap');
    } finally {
      setIsGeneratingMindMap(false);
      setTimeout(() => setMindMapToastMessage(''), 4000);
    }
  };
  const [deepFocusTimeLeft, setDeepFocusTimeLeft] = useState<number>(25 * 60);
  const [isDeepFocusTimerRunning, setIsDeepFocusTimerRunning] = useState<boolean>(false);
  const [focusFinishedToast, setFocusFinishedToast] = useState<boolean>(false);

  // Pomodoro Countdown Timer Effect for Deep Focus Mode
  useEffect(() => {
    let interval: any = null;
    if (isDeepFocusActive && isDeepFocusTimerRunning) {
      interval = setInterval(() => {
        setDeepFocusTimeLeft((prev) => {
          if (prev <= 1) {
            clearInterval(interval);
            setIsDeepFocusTimerRunning(false);
            // Play alarm chime
            playAlarmSound((appState.settings.sound as any) || 'chime');
            setFocusFinishedToast(true);
            setTimeout(() => setFocusFinishedToast(false), 6000);

            // Record completed focus session in app state
            const newSession: FocusSession = {
              id: `focus_${Date.now()}`,
              notebookId: appState.currentNotebookId,
              durationMins: deepFocusDurationMins,
              date: Date.now(),
              timestamp: Date.now(),
              kind: 'pomodoro',
            };
            setAppState((p) => ({
              ...p,
              focusSessions: [newSession, ...p.focusSessions],
            }));
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isDeepFocusActive, isDeepFocusTimerRunning, appState.currentNotebookId, deepFocusDurationMins, appState.settings.sound]);

  const handleToggleDeepFocus = () => {
    setIsDeepFocusActive((prev) => {
      const next = !prev;
      if (next) {
        if (deepFocusTimeLeft === 0) {
          setDeepFocusTimeLeft(deepFocusDurationMins * 60);
        }
        setIsDeepFocusTimerRunning(true);
        if (currentTab === 'chat') {
          setCurrentTab('studio');
        }
      } else {
        setIsDeepFocusTimerRunning(false);
      }
      return next;
    });
  };

  const handleResetDeepFocusTimer = () => {
    setIsDeepFocusTimerRunning(false);
    setDeepFocusTimeLeft(deepFocusDurationMins * 60);
  };

  const handleChangeDeepFocusDuration = (mins: number) => {
    setDeepFocusDurationMins(mins);
    setDeepFocusTimeLeft(mins * 60);
    setIsDeepFocusTimerRunning(false);
  };

  const formatPomodoroTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  // Sync chunks to Vector Store for fast RAG retrieval
  useEffect(() => {
    if (appState.chunks && appState.chunks.length > 0) {
      vectorStore.indexChunks(appState.chunks);
    }
  }, [appState.chunks]);

  // Initialize Background Sync & Offline-first Resilience
  useEffect(() => {
    backgroundSync.initialize(
      () => appState,
      (syncedAt) => setLastSyncTimestamp(syncedAt)
    );
  }, []);

  // Synchronize DOM direction (RTL / LTR) and language tag
  useEffect(() => {
    applyLanguageToDOM(currentLanguage);
  }, [currentLanguage]);

  // Google Sign-In & Cloud Sync Handlers
  const handleGoogleSignIn = async (name?: string, email?: string) => {
    const profile = await signInWithGoogleAccount(name, email);
    setAppState((prev) => ({
      ...prev,
      userProfile: profile,
    }));
    setIsSyncingCloud(true);
    try {
      // Check if student has saved workspace in cloud database
      const cloudData = await restoreWorkspaceFromCloud(profile.uid);
      if (cloudData && cloudData.notebooks && cloudData.notebooks.length > 0) {
        setAppState({
          ...cloudData,
          userProfile: profile,
        });
        setLastSyncTimestamp(Date.now());
      } else {
        // First time or new account: sync current workspace into this account's cloud storage
        const syncRes = await syncWorkspaceToCloud(profile.uid, appState);
        if (syncRes.success && syncRes.syncedAt) {
          setLastSyncTimestamp(syncRes.syncedAt);
        }
      }
    } catch (e) {
      console.warn('Cloud sync error during sign-in:', e);
    } finally {
      setIsSyncingCloud(false);
    }
  };

  const handleGoogleSignOut = () => {
    signOutGoogleSession();
    setAppState((prev) => ({
      ...prev,
      userProfile: null,
    }));
    setIsAuthModalOpen(false);
  };

  const handleManualSyncNow = async () => {
    if (!appState.userProfile) return;
    setIsSyncingCloud(true);
    const res = await syncWorkspaceToCloud(appState.userProfile.uid, appState);
    if (res.success && res.syncedAt) {
      setLastSyncTimestamp(res.syncedAt);
    }
    setIsSyncingCloud(false);
  };

  const handleRestoreFromCloud = async () => {
    if (!appState.userProfile) return;
    setIsSyncingCloud(true);
    const cloudState = await restoreWorkspaceFromCloud(appState.userProfile.uid);
    if (cloudState) {
      setAppState(cloudState);
      saveAppState(cloudState);
    }
    setIsSyncingCloud(false);
  };

  // Apply dark mode to <html> tag
  useEffect(() => {
    if (appState.settings.theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [appState.settings.theme]);

  // Apply stored language and text direction (RTL/LTR) to <html> tag
  useEffect(() => {
    applyLanguageToDOM(getStoredLanguage());
  }, []);

  // Persist state on change
  useEffect(() => {
    saveAppState(appState);
  }, [appState]);

  // Check backend connectivity on mount
  useEffect(() => {
    fetch('/api/health')
      .then((res) => setAiConnected(res.ok))
      .catch(() => setAiConnected(false));
  }, []);

  // Check URL for public share parameter (?share=shareId)
  useEffect(() => {
    try {
      const urlParams = new URLSearchParams(window.location.search);
      const shareToken = urlParams.get('share');
      if (shareToken) {
        setIsLoadingShared(true);
        fetchPublicNotebookShare(shareToken)
          .then((data) => {
            if (data) {
              setSharedViewPayload(data);
            } else {
              setShareLoadError('عذراً، لم نتمكن من العثور على هذا الدفتر المشترك أو ربما انتهت صلاحيته.');
            }
          })
          .catch((err) => {
            console.error('Failed to load shared notebook:', err);
            setShareLoadError('تعذر تحميل الدفتر المشترك في هذه اللحظة. يرجى التحقق من الرابط والمحاولة مجدداً.');
          })
          .finally(() => {
            setIsLoadingShared(false);
          });
      }
    } catch (e) {
      console.warn('Error reading share URL param:', e);
    }
  }, []);

  // Visual Viewport tracking for mobile keyboards and dynamic 100dvh adaptation
  const [chatViewportHeight, setChatViewportHeight] = useState<number | null>(null);

  useEffect(() => {
    if (typeof window === 'undefined') return;

    const handleVisualViewportResize = () => {
      if (window.visualViewport) {
        setChatViewportHeight(window.visualViewport.height);
      }
    };

    if (window.visualViewport) {
      // Connect resize listener to adjust container height when keyboard appears (never on scroll)
      window.visualViewport.addEventListener('resize', handleVisualViewportResize);
      handleVisualViewportResize();
    }

    return () => {
      if (window.visualViewport) {
        window.visualViewport.removeEventListener('resize', handleVisualViewportResize);
      }
    };
  }, []);

  // Active Notebook resolution
  const currentNotebook = appState.notebooks.find(
    (nb) => nb.id === appState.currentNotebookId
  ) || appState.notebooks[0];

  // Current Notebook's scoped data
  const notebookSources = appState.sources.filter(
    (s) => s.notebookId === currentNotebook.id
  );
  const notebookChunks = appState.chunks.filter(
    (c) => c.notebookId === currentNotebook.id
  );
  const notebookSessions = appState.chatSessions.filter(
    (s) => s.notebookId === currentNotebook.id
  );
  const currentChatSession = notebookSessions[0] || {
    id: `chat_${currentNotebook.id}_default`,
    notebookId: currentNotebook.id,
    title: 'محادثة استكشافية',
    created: Date.now(),
    updated: Date.now(),
    messages: [],
  };

  const notebookFlashcards = appState.flashcards.filter(
    (f) => f.notebookId === currentNotebook.id
  );
  const notebookTodos = appState.todos.filter(
    (t) => t.notebookId === currentNotebook.id
  );
  const notebookMemos = appState.memos.filter(
    (m) => m.notebookId === currentNotebook.id
  );
  const notebookGlossary = appState.glossary.filter(
    (g) => g.notebookId === currentNotebook.id
  );
  const notebookFocusSessions = appState.focusSessions.filter(
    (f) => f.notebookId === currentNotebook.id
  );
  const notebookNotes = (appState.notes || []).filter(
    (n) => n.notebookId === currentNotebook.id
  );

  // Toggle Theme
  const handleToggleTheme = () => {
    const nextTheme = appState.settings.theme === 'dark' ? 'light' : 'dark';
    setAppState((prev) => ({
      ...prev,
      settings: { ...prev.settings, theme: nextTheme },
    }));
  };

  // Notebook handlers
  const handleSelectNotebook = (id: string) => {
    setAppState((prev) => ({ ...prev, currentNotebookId: id }));
    setSelectedSourceIds([]);
  };

  const handleCreateNotebook = (name: string, subject: string, description: string) => {
    const newId = `nb_${Date.now()}`;
    const newNb: Notebook = {
      id: newId,
      name,
      subject,
      description,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      sourceIds: [],
      noteIds: [],
      chatSessionIds: [`chat_${newId}_1`],
      progress: 0,
    };

    const newSession: ChatSession = {
      id: `chat_${newId}_1`,
      notebookId: newId,
      title: 'محادثة استكشافية',
      created: Date.now(),
      updated: Date.now(),
      sourceIds: [],
      messages: [
        {
          id: `msg_${Date.now()}`,
          role: 'ai',
          text: `مرحبًا بك في دفتر «${name}» ✦\n\nأضف مراجعك ومصادرك الآن للبدء بالمحادثة المعرفية وتوليد الملخصات والأسئلة.`,
          date: Date.now(),
          notebookId: newId,
          sessionId: `chat_${newId}_1`,
        },
      ],
    };

    setAppState((prev) => ({
      ...prev,
      notebooks: [...prev.notebooks, newNb],
      currentNotebookId: newId,
      chatSessions: [...prev.chatSessions, newSession],
    }));
    setSelectedSourceIds([]);
  };

  const handleDuplicateNotebook = (id: string) => {
    const original = appState.notebooks.find((n) => n.id === id);
    if (!original) return;
    handleCreateNotebook(
      `${original.name} (نسخة)`,
      original.subject,
      original.description
    );
  };

  const handleDeleteNotebook = (id: string) => {
    if (appState.notebooks.length <= 1) {
      alert('لا يمكن حذف الدفتر الوحيد المتبقي.');
      return;
    }
    const remaining = appState.notebooks.filter((n) => n.id !== id);
    setAppState((prev) => ({
      ...prev,
      notebooks: remaining,
      currentNotebookId: remaining[0].id,
      sources: prev.sources.filter((s) => s.notebookId !== id),
      chunks: prev.chunks.filter((c) => c.notebookId !== id),
      chatSessions: prev.chatSessions.filter((cs) => cs.notebookId !== id),
      flashcards: prev.flashcards.filter((f) => f.notebookId !== id),
      todos: prev.todos.filter((t) => t.notebookId !== id),
      memos: prev.memos.filter((m) => m.notebookId !== id),
      glossary: prev.glossary.filter((g) => g.notebookId !== id),
      focusSessions: prev.focusSessions.filter((fs) => fs.notebookId !== id),
    }));
  };

  // Sources handlers
  const handleAddSource = (source: Source, chunks: SourceChunk[]) => {
    setAppState((prev) => ({
      ...prev,
      sources: [source, ...prev.sources.filter((s) => s.id !== source.id)],
      chunks: [...prev.chunks.filter((c) => c.sourceId !== source.id), ...chunks],
    }));
    // Auto-select newly added source for RAG active sources so the active counter updates instantly
    setSelectedSourceIds((prev) => (prev.includes(source.id) ? prev : [...prev, source.id]));
  };

  const handleUpdateSource = (updatedSource: Source, newChunks?: SourceChunk[]) => {
    setAppState((prev) => ({
      ...prev,
      sources: prev.sources.map((s) => (s.id === updatedSource.id ? updatedSource : s)),
      chunks: newChunks
        ? [...prev.chunks.filter((c) => c.sourceId !== updatedSource.id), ...newChunks]
        : prev.chunks,
    }));
  };

  const handleDeleteSource = (sourceId: string) => {
    deleteFileBlob(sourceId);
    setAppState((prev) => ({
      ...prev,
      sources: prev.sources.filter((s) => s.id !== sourceId),
      chunks: prev.chunks.filter((c) => c.sourceId !== sourceId),
    }));
    setSelectedSourceIds((prev) => prev.filter((id) => id !== sourceId));
  };

  const handleRenameSource = (sourceId: string, newTitle: string) => {
    setAppState((prev) => ({
      ...prev,
      sources: prev.sources.map((s) =>
        s.id === sourceId ? { ...s, title: newTitle, updatedAt: Date.now() } : s
      ),
      chunks: prev.chunks.map((c) =>
        c.sourceId === sourceId ? { ...c, sourceTitle: newTitle } : c
      ),
    }));
  };

  const handleDeleteMultipleSources = (sourceIds: string[]) => {
    sourceIds.forEach((id) => deleteFileBlob(id));
    setAppState((prev) => ({
      ...prev,
      sources: prev.sources.filter((s) => !sourceIds.includes(s.id)),
      chunks: prev.chunks.filter((c) => !sourceIds.includes(c.sourceId)),
    }));
    setSelectedSourceIds((prev) => prev.filter((id) => !sourceIds.includes(id)));
  };

  const handleToggleSelectSource = (sourceId: string) => {
    setSelectedSourceIds((prev) =>
      prev.includes(sourceId)
        ? prev.filter((id) => id !== sourceId)
        : [...prev, sourceId]
    );
  };

  const handleSelectAllSources = () => {
    setSelectedSourceIds(notebookSources.map((s) => s.id));
  };

  const handleClearSelectedSources = () => {
    setSelectedSourceIds([]);
  };

  const handleAskAboutSource = (source: Source) => {
    const newSessionId = `chat_${currentNotebook.id}_${Date.now()}`;
    const newSession: ChatSession = {
      id: newSessionId,
      notebookId: currentNotebook.id,
      title: `محادثة: ${source.title.slice(0, 22)}`,
      created: Date.now(),
      updated: Date.now(),
      messages: [
        {
          id: `msg_${Date.now()}`,
          role: 'ai',
          text: `مرحباً بك! هذه الجلسة مخصصة حصرياً للمرجع «**${source.title}**». اطرح أي استفسار أو مسألة وسأجيبك استناداً إلى هذا المرجع فقط بدقة بالغة وبدون خلط بالمراجع الأخرى.`,
          date: Date.now(),
          notebookId: currentNotebook.id,
          sessionId: newSessionId,
        },
      ],
      sourceIds: [source.id],
    };
    setAppState((prev) => ({
      ...prev,
      chatSessions: [newSession, ...prev.chatSessions],
    }));
    setSelectedSourceIds([source.id]);
    navigateToTab('chat');
  };

  const handleUpdateSourceAnnotations = (sourceId: string, annotations: SourceAnnotation[]) => {
    setAppState((prev) => ({
      ...prev,
      sources: prev.sources.map((s) =>
        s.id === sourceId ? { ...s, annotations, updatedAt: Date.now() } : s
      ),
    }));
  };

  const handleAskAboutQuote = (quote: string, pageNumber?: number) => {
    const formattedPrompt = `اشرح لي بالتفصيل هذا المقتبس من المصدر${pageNumber ? ` (ص ${pageNumber})` : ''}:\n«${quote}»\nما معناه وأهميته وكيف يرتبط بالمفاهيم الأساسية؟`;
    setPrefilledChatPrompt(formattedPrompt);
    navigateToTab('chat');
  };

  const handleExportToNote = (title: string, content: string) => {
    const newNote: NoteItem = {
      id: `note_${Date.now()}`,
      notebookId: currentNotebook.id,
      subject: currentNotebook.subject || 'عام',
      level: 'متوسط',
      title,
      goal: 'ملخص التظليلات والملاحظات المرجعية من المصدر',
      tags: ['تظليلات_PDF', 'ملاحظات'],
      text: content,
      favorite: true,
      mastery: 0,
      created: Date.now(),
      updated: Date.now(),
    };

    setAppState((prev) => ({
      ...prev,
      notes: [newNote, ...prev.notes],
    }));
  };

  const handleAddNote = (title: string, text: string, tags: string[] = []) => {
    const newNote: NoteItem = {
      id: `note_${Date.now()}`,
      notebookId: currentNotebook.id,
      subject: currentNotebook.subject || 'عام',
      level: 'متوسط',
      title,
      goal: 'تدوينة دراسية',
      tags: tags.length > 0 ? tags : ['ملاحظة'],
      text,
      favorite: false,
      mastery: 0,
      created: Date.now(),
      updated: Date.now(),
    };

    setAppState((prev) => ({
      ...prev,
      notes: [newNote, ...prev.notes],
    }));
  };

  const handleDeleteNote = (id: string) => {
    setAppState((prev) => ({
      ...prev,
      notes: prev.notes.filter((n) => n.id !== id),
    }));
  };

  const handleAskAboutNote = (note: NoteItem) => {
    const prompt = `بناءً على تدوينتي الدراسية بعنوان «${note.title}»:\n«${note.text}»\nاشرح لي هذه النقاط بتعمق أكاديمي، وقدم أمثلة توضيحية وأسئلة لمراجعة الفهم واستيعاب الدرس.`;
    setPrefilledChatPrompt(prompt);
    navigateToTab('chat');
  };

  // Chat Sessions handlers
  const handleSelectSession = (sessionId: string) => {
    // Bring selected session to front of the notebook
    setAppState((prev) => {
      const idx = prev.chatSessions.findIndex((s) => s.id === sessionId);
      if (idx === -1) return prev;
      const target = prev.chatSessions[idx];
      const rest = prev.chatSessions.filter((s) => s.id !== sessionId);
      return { ...prev, chatSessions: [target, ...rest] };
    });
  };

  const handleNewSession = (initialSourceIds?: string[], initialTitle?: string) => {
    const newSessionId = `chat_${currentNotebook.id}_${Date.now()}`;
    const defaultSources = selectedSourceIds.length > 0 ? [...selectedSourceIds] : notebookSources.map((s) => s.id);
    const newSession: ChatSession = {
      id: newSessionId,
      notebookId: currentNotebook.id,
      title: initialTitle || `محادثة ${new Date().toLocaleTimeString('ar', { hour: '2-digit', minute: '2-digit' })}`,
      created: Date.now(),
      updated: Date.now(),
      messages: [],
      sourceIds: initialSourceIds !== undefined ? initialSourceIds : defaultSources,
    };
    setAppState((prev) => ({
      ...prev,
      chatSessions: [newSession, ...prev.chatSessions],
    }));
  };

  const handleToggleFavoriteSource = (sourceId: string) => {
    setAppState((prev) => {
      const currentFavs = prev.favoriteSourceIds || [];
      const exists = currentFavs.includes(sourceId);
      const nextFavs = exists
        ? currentFavs.filter((id) => id !== sourceId)
        : [...currentFavs, sourceId];
      return {
        ...prev,
        favoriteSourceIds: nextFavs,
        sources: prev.sources.map((s) => (s.id === sourceId ? { ...s, favorite: !exists } : s)),
      };
    });
  };

  const handleUpdateSessionSources = (sessionId: string, sourceIds: string[]) => {
    setAppState((prev) => ({
      ...prev,
      chatSessions: prev.chatSessions.map((s) =>
        s.id === sessionId ? { ...s, sourceIds, updated: Date.now() } : s
      ),
    }));
  };

  const handleDeleteSession = (sessionId: string) => {
    setAppState((prev) => ({
      ...prev,
      chatSessions: prev.chatSessions.filter((s) => s.id !== sessionId),
    }));
  };

  const handleRenameSession = (sessionId: string, newTitle: string) => {
    setAppState((prev) => ({
      ...prev,
      chatSessions: prev.chatSessions.map((s) =>
        s.id === sessionId ? { ...s, title: newTitle.trim() || s.title, updated: Date.now() } : s
      ),
    }));
  };

  // Immediate User Message Dispatch: appends user message to session instantaneously upon clicking Send
  const handleAddUserMessage = (userText: string): string => {
    const userMsgId = `msg_u_${Date.now()}`;
    const userMsg: ChatMessage = {
      id: userMsgId,
      role: 'user',
      text: userText,
      date: Date.now(),
      notebookId: currentNotebook.id,
      sessionId: currentChatSession.id,
    };

    setAppState((prev) => {
      const updatedSessions = prev.chatSessions.map((s) => {
        if (s.id === currentChatSession.id) {
          return {
            ...s,
            title: s.messages.length === 0 ? userText.slice(0, 24) + '...' : s.title,
            messages: [...s.messages, userMsg],
            updated: Date.now(),
          };
        }
        return s;
      });
      return { ...prev, chatSessions: updatedSessions };
    });
    return userMsgId;
  };

  // Immediate AI Response Appender: called when streaming or final response finishes
  const handleAddAiResponse = (
    aiText: string,
    citations?: Citation[],
    grounding?: any,
    providerInfo?: any,
    suggestedNextPrompt?: string,
    suggestedNextUnit?: string
  ) => {
    const aiMsg: ChatMessage = {
      id: `msg_ai_${Date.now()}`,
      role: 'ai',
      text: aiText,
      date: Date.now(),
      notebookId: currentNotebook.id,
      sessionId: currentChatSession.id,
      citations,
      groundingSources: (grounding?.sources || grounding?.webSearchSources || []).map((s: any) => ({
        title: s.title || s.url || s.uri || 'مصدر خارجي موثوق',
        uri: s.url || s.uri || '#',
        domain: s.domain,
        snippet: s.snippet,
      })),
      providerInfo,
      suggestedNextPrompt,
      suggestedNextUnit,
    };

    setAppState((prev) => {
      const updatedSessions = prev.chatSessions.map((s) => {
        if (s.id === currentChatSession.id) {
          return {
            ...s,
            messages: [...s.messages, aiMsg],
            updated: Date.now(),
          };
        }
        return s;
      });
      return { ...prev, chatSessions: updatedSessions };
    });
  };

  const handleSendMessage = (
    userText: string,
    aiText: string,
    citations?: Citation[],
    grounding?: any,
    providerInfo?: any,
    suggestedNextPrompt?: string,
    suggestedNextUnit?: string
  ) => {
    // Check if the user message was already added at send start
    const currentSessionInState = appState.chatSessions.find((s) => s.id === currentChatSession.id);
    const lastMsg = currentSessionInState?.messages[currentSessionInState.messages.length - 1];
    if (lastMsg && lastMsg.role === 'user' && lastMsg.text === userText) {
      handleAddAiResponse(aiText, citations, grounding, providerInfo, suggestedNextPrompt, suggestedNextUnit);
      return;
    }

    const userMsg: ChatMessage = {
      id: `msg_u_${Date.now()}`,
      role: 'user',
      text: userText,
      date: Date.now(),
      notebookId: currentNotebook.id,
      sessionId: currentChatSession.id,
    };

    const aiMsg: ChatMessage = {
      id: `msg_ai_${Date.now() + 1}`,
      role: 'ai',
      text: aiText,
      date: Date.now() + 1,
      notebookId: currentNotebook.id,
      sessionId: currentChatSession.id,
      citations,
      groundingSources: (grounding?.sources || grounding?.webSearchSources || []).map((s: any) => ({
        title: s.title || s.url || s.uri || 'مصدر خارجي موثوق',
        uri: s.url || s.uri || '#',
        domain: s.domain,
        snippet: s.snippet,
      })),
      providerInfo,
      suggestedNextPrompt,
      suggestedNextUnit,
    };

    setAppState((prev) => {
      const updatedSessions = prev.chatSessions.map((s) => {
        if (s.id === currentChatSession.id) {
          return {
            ...s,
            title: s.messages.length === 0 ? userText.slice(0, 24) + '...' : s.title,
            messages: [...s.messages, userMsg, aiMsg],
            updated: Date.now(),
          };
        }
        return s;
      });
      return { ...prev, chatSessions: updatedSessions };
    });
  };

  const handleDeleteMessage = (msgId: string) => {
    setAppState((prev) => {
      const updatedSessions = prev.chatSessions.map((s) => {
        if (s.id === currentChatSession.id) {
          return {
            ...s,
            messages: s.messages.filter((m) => m.id !== msgId),
          };
        }
        return s;
      });
      return { ...prev, chatSessions: updatedSessions };
    });
  };

  const handleRateMessage = (msgId: string, feedback: 'like' | 'dislike' | null) => {
    setAppState((prev) => {
      const updatedSessions = prev.chatSessions.map((s) => {
        if (s.id === currentChatSession.id) {
          return {
            ...s,
            messages: s.messages.map((m) => (m.id === msgId ? { ...m, feedback } : m)),
          };
        }
        return s;
      });
      return { ...prev, chatSessions: updatedSessions };
    });
  };

  // Study Tools handlers
  const handleAddFlashcards = (newCards: Flashcard[]) => {
    setAppState((prev) => ({
      ...prev,
      flashcards: [...newCards, ...prev.flashcards],
    }));
  };

  const handleReviewCard = (cardId: string, ratingOrKnown: boolean | ReviewRating) => {
    setAppState((prev) => {
      const updated = prev.flashcards.map((c) => {
        if (c.id === cardId) {
          const sm2 = calculateSM2Schedule(c, ratingOrKnown);
          const history = c.masteryHistory || [];
          return {
            ...c,
            level: sm2.level,
            reps: sm2.reps,
            easeFactor: sm2.easeFactor,
            intervalDays: sm2.intervalDays,
            nextReview: sm2.nextReview,
            mistake: sm2.mistake,
            lastReviewed: Date.now(),
            masteryHistory: [...history, { date: Date.now(), level: sm2.level }].slice(-20),
          };
        }
        return c;
      });
      return { ...prev, flashcards: updated };
    });
  };

  const handleAddTodo = (text: string, due?: string) => {
    const newTodo: TodoItem = {
      id: `todo_${Date.now()}`,
      notebookId: currentNotebook.id,
      text,
      done: false,
      createdAt: Date.now(),
      dueDate: due,
    };
    setAppState((prev) => ({ ...prev, todos: [newTodo, ...prev.todos] }));
  };

  const handleToggleTodo = (id: string) => {
    setAppState((prev) => ({
      ...prev,
      todos: prev.todos.map((t) => (t.id === id ? { ...t, done: !t.done } : t)),
    }));
  };

  const handleDeleteTodo = (id: string) => {
    setAppState((prev) => ({
      ...prev,
      todos: prev.todos.filter((t) => t.id !== id),
    }));
  };

  const handleAddMemo = (text: string) => {
    const newMemo: MemoItem = {
      id: `memo_${Date.now()}`,
      notebookId: currentNotebook.id,
      text,
      createdAt: Date.now(),
    };
    setAppState((prev) => ({ ...prev, memos: [newMemo, ...prev.memos] }));
  };

  const handleDeleteMemo = (id: string) => {
    setAppState((prev) => ({
      ...prev,
      memos: prev.memos.filter((m) => m.id !== id),
    }));
  };

  const handleAddGlossary = (term: string, def: string, ex?: string) => {
    const item: GlossaryItem = {
      id: `gloss_${Date.now()}`,
      notebookId: currentNotebook.id,
      term,
      def,
      ex,
      createdAt: Date.now(),
    };
    setAppState((prev) => ({ ...prev, glossary: [item, ...prev.glossary] }));
  };

  const handleDeleteGlossary = (id: string) => {
    setAppState((prev) => ({
      ...prev,
      glossary: prev.glossary.filter((g) => g.id !== id),
    }));
  };

  const handleAddFocusSession = (session: FocusSession) => {
    setAppState((prev) => ({
      ...prev,
      focusSessions: [session, ...prev.focusSessions],
    }));
  };

  // Full Export / Backup & Restore
  const handleExportAllData = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(appState, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `almoallim_backup_${new Date().toISOString().slice(0, 10)}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleImportData = (imported: AppState) => {
    setAppState(imported);
    saveAppState(imported);
  };

  const handleClearAllData = () => {
    localStorage.clear();
    window.location.reload();
  };

  // Global Search
  const handleGlobalSearch = (query: string) => {
    const lower = query.toLowerCase();
    const matchSrc = notebookSources.find((s) => s.title.toLowerCase().includes(lower) || s.content.toLowerCase().includes(lower));
    if (matchSrc) {
      setCurrentTab('sources');
      return;
    }
    const matchCard = notebookFlashcards.find((c) => c.front.toLowerCase().includes(lower) || c.back.toLowerCase().includes(lower));
    if (matchCard) {
      setCurrentTab('studio');
      return;
    }
    setCurrentTab('chat');
  };

  // Public Share Handlers & Resolution
  const targetShareNotebook = appState.notebooks.find(
    (nb) => nb.id === (shareModalNotebookId || currentNotebook.id)
  ) || currentNotebook;

  const targetShareSummaries = (appState.customSummaries || []).filter(
    (cs) => cs.notebookId === targetShareNotebook.id
  );
  const targetShareNotes = (appState.notes || []).filter(
    (n) => n.notebookId === targetShareNotebook.id
  );
  const targetShareMemos = appState.memos.filter(
    (m) => m.notebookId === targetShareNotebook.id
  );
  const targetShareGlossary = appState.glossary.filter(
    (g) => g.notebookId === targetShareNotebook.id
  );
  const targetShareFlashcards = appState.flashcards.filter(
    (f) => f.notebookId === targetShareNotebook.id
  );
  const targetShareSources = appState.sources.filter(
    (s) => s.notebookId === targetShareNotebook.id
  );

  const handleOpenShareNotebook = (notebookId?: string) => {
    setShareModalNotebookId(notebookId || currentNotebook.id);
    setIsShareModalOpen(true);
  };

  const handlePreviewSharedNotebook = (payload: SharedNotebookPayload) => {
    setSharedViewPayload(payload);
  };

  const handleExitSharedView = () => {
    setSharedViewPayload(null);
    setShareLoadError(null);
    try {
      const url = new URL(window.location.href);
      url.searchParams.delete('share');
      window.history.replaceState({}, '', url.pathname);
    } catch (e) {
      console.warn(e);
    }
  };

  const handleImportSharedNotebook = (sharedData: SharedNotebookPayload) => {
    const newNbId = `nb_shared_${Date.now()}`;
    const newNotebook: Notebook = {
      id: newNbId,
      name: `${sharedData.notebook.name} (نسخة مستوردة)`,
      subject: sharedData.notebook.subject || 'عام',
      description: sharedData.notebook.description || `نسخة مستوردة من الزميل ${sharedData.authorName}`,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      sourceIds: [],
      noteIds: [],
      chatSessionIds: [`chat_${newNbId}_default`],
      progress: 0,
    };

    const newChatSession: ChatSession = {
      id: `chat_${newNbId}_default`,
      notebookId: newNbId,
      title: 'محادثة حول الدفتر المشترك',
      created: Date.now(),
      updated: Date.now(),
      sourceIds: [],
      messages: [
        {
          id: `msg_${Date.now()}`,
          role: 'ai',
          text: `تم استيراد الدفتر «**${sharedData.notebook.name}**» بنجاح من زميلك (${sharedData.authorName})! 🎉\n\nتتضمن نسختك الآن:\n- 📑 **${sharedData.summaries.length}** ملخصات دراسية\n- 📝 **${sharedData.notes.length + sharedData.memos.length}** ملاحظات وتدوينات\n- 📖 **${sharedData.glossary.length}** مصطلحات ومفاهيم\n- 🗂️ **${sharedData.flashcards.length}** بطاقات مراجعة\n\nيمكنك الآن استكمال المذاكرة، طرح الأسئلة، وإضافة مصادرك الخاصة بحرية كاملة.`,
          date: Date.now(),
          notebookId: newNbId,
          sessionId: `chat_${newNbId}_default`,
        },
      ],
    };

    const importedNotes: NoteItem[] = sharedData.notes.map((n, idx) => ({
      id: `note_${newNbId}_${idx}_${Date.now()}`,
      notebookId: newNbId,
      subject: sharedData.notebook.subject || 'عام',
      level: 'متوسط',
      title: n.title,
      goal: n.goal || 'ملاحظة مستوردة',
      tags: n.tags || ['مشترك'],
      text: n.text,
      favorite: false,
      mastery: 0,
      created: n.created || Date.now(),
      updated: Date.now(),
    }));

    const importedMemos: MemoItem[] = sharedData.memos.map((m, idx) => ({
      id: `memo_${newNbId}_${idx}_${Date.now()}`,
      notebookId: newNbId,
      text: m.text,
      createdAt: m.createdAt || Date.now(),
    }));

    const importedGlossary: GlossaryItem[] = sharedData.glossary.map((g, idx) => ({
      id: `glos_${newNbId}_${idx}_${Date.now()}`,
      notebookId: newNbId,
      term: g.term,
      def: g.def,
      ex: g.ex,
      createdAt: Date.now(),
    }));

    const importedFlashcards: Flashcard[] = sharedData.flashcards.map((f, idx) => ({
      id: `fc_${newNbId}_${idx}_${Date.now()}`,
      notebookId: newNbId,
      front: f.front,
      back: f.back,
      level: f.level || 0,
      nextReview: Date.now(),
      mistake: false,
    }));

    const importedSummaries = sharedData.summaries.map((s, idx) => ({
      id: `sum_${newNbId}_${idx}_${Date.now()}`,
      notebookId: newNbId,
      title: s.title,
      subject: sharedData.notebook.subject || 'عام',
      author: sharedData.authorName || 'زميل دراسي',
      date: s.date || new Date().toLocaleDateString('ar-SA'),
      theme: 'teal' as const,
      printMode: 'colored' as const,
      paperSize: 'a4' as const,
      orientation: 'portrait' as const,
      fontSize: 'md' as const,
      showCoverPage: true,
      showPageNumbers: true,
      showTableOfContents: false,
      content: s.content,
      boxes: s.boxes || [],
      createdAt: Date.now(),
      updatedAt: Date.now(),
    }));

    setAppState((prev) => ({
      ...prev,
      notebooks: [newNotebook, ...prev.notebooks],
      currentNotebookId: newNbId,
      chatSessions: [newChatSession, ...prev.chatSessions],
      notes: [...importedNotes, ...prev.notes],
      memos: [...importedMemos, ...prev.memos],
      glossary: [...importedGlossary, ...prev.glossary],
      flashcards: [...importedFlashcards, ...prev.flashcards],
      customSummaries: [...importedSummaries, ...(prev.customSummaries || [])],
    }));

    handleExitSharedView();
    setCurrentTab('home');
  };

  const handlePrintSharedSummary = (title: string, content: string) => {
    if (!sharedViewPayload) return;
    const structured = extractStructuredSummary(
      content,
      sharedViewPayload.notebook.name,
      sharedViewPayload.notebook.subject
    );
    setSharedPrintModalSummary(structured);
  };

  // If currently loading a shared public link
  if (isLoadingShared) {
    return (
      <div className="min-h-screen bg-[#f8fbfa] dark:bg-[#0c1311] flex flex-col items-center justify-center p-6 text-center" dir="rtl">
        <Loader2 className="w-10 h-10 text-teal-600 animate-spin mb-4" />
        <h2 className="text-lg font-bold text-[#17201e] dark:text-[#eef7f4]">
          جارٍ تحميل الدفتر المشترك للزملاء...
        </h2>
        <p className="text-xs text-gray-500 mt-2">
          يتم استرجاع الملخصات والملاحظات الأكاديمية المنشورة.
        </p>
      </div>
    );
  }

  // If shared link error
  if (shareLoadError) {
    return (
      <div className="min-h-screen bg-[#f8fbfa] dark:bg-[#0c1311] flex flex-col items-center justify-center p-6 text-center" dir="rtl">
        <div className="max-w-md bg-white dark:bg-[#14201c] p-8 rounded-2xl border border-red-200 dark:border-red-900 shadow-sm space-y-4">
          <AlertCircle className="w-12 h-12 text-rose-500 mx-auto" />
          <h2 className="text-lg font-bold text-gray-900 dark:text-gray-100">
            تعذر فتح الدفتر المشترك
          </h2>
          <p className="text-xs text-gray-600 dark:text-gray-400 leading-relaxed">
            {shareLoadError}
          </p>
          <button
            onClick={handleExitSharedView}
            className="w-full py-2.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold transition-colors"
          >
            الانتقال إلى مساحة عملي
          </button>
        </div>
      </div>
    );
  }

  // If inspecting a public shared notebook (via link or preview)
  if (sharedViewPayload) {
    return (
      <>
        <SharedNotebookView
          shareData={sharedViewPayload}
          onImportToWorkspace={handleImportSharedNotebook}
          onExitSharedView={handleExitSharedView}
          onPrintSummary={handlePrintSharedSummary}
        />
        {sharedPrintModalSummary && (
          <AcademicPrintModal
            isOpen={!!sharedPrintModalSummary}
            onClose={() => setSharedPrintModalSummary(null)}
            summary={sharedPrintModalSummary}
          />
        )}
      </>
    );
  }

  return (
    <div className={`flex h-[100dvh] min-h-[100dvh] max-h-[100dvh] bg-[#f8fbfa] dark:bg-[#0c1311] text-[#17201e] dark:text-[#eef7f4] font-sans antialiased overflow-hidden ${isDeepFocusActive ? 'focus-mode-active' : ''}`} dir={currentLanguage === 'ar' ? 'rtl' : 'ltr'}>
      {/* Sidebar Navigation - Hidden in Deep Focus Mode to eliminate side distractions */}
      {!isDeepFocusActive && (
        <Sidebar
          currentTab={currentTab}
          onSelectTab={navigateToTab}
          notebooks={appState.notebooks}
          currentNotebook={currentNotebook}
          onSelectNotebook={handleSelectNotebook}
          onCreateNotebook={handleCreateNotebook}
          onDuplicateNotebook={handleDuplicateNotebook}
          onDeleteNotebook={handleDeleteNotebook}
          onBackup={handleExportAllData}
          onOpenShareNotebook={handleOpenShareNotebook}
          onOpenSupportModal={() => setIsSupportModalOpen(true)}
          isOpen={isSidebarOpen}
          onClose={() => setIsSidebarOpen(false)}
          isDark={appState.settings.theme === 'dark'}
          onToggleTheme={handleToggleTheme}
          sourceCount={notebookSources.length}
          currentLang={currentLanguage}
          notebookFlashcards={notebookFlashcards}
          notebookNotesCount={notebookNotes.length}
        />
      )}

      {/* Main Workspace Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <Header
          onToggleSidebar={() => setIsSidebarOpen(true)}
          currentTab={currentTab}
          currentNotebook={currentNotebook}
          onGlobalSearch={handleGlobalSearch}
          isDark={appState.settings.theme === 'dark'}
          onToggleTheme={handleToggleTheme}
          aiConnected={aiConnected}
          onBack={handleGoBack}
          canGoBack={navHistory.length > 0}
          userProfile={appState.userProfile}
          onOpenAuthModal={() => setIsAuthModalOpen(true)}
          onOpenSupportModal={() => setIsSupportModalOpen(true)}
          currentLang={currentLanguage}
          onChangeLang={handleLanguageChange}
          isSyncing={isSyncingCloud}
          isDeepFocusActive={isDeepFocusActive}
          onToggleDeepFocus={handleToggleDeepFocus}
          onOpenAcademicRefModal={() => setIsAcademicRefModalOpen(true)}
          onOpenVoiceMemo={() => setIsVoiceMemoModalOpen(true)}
        />

        {/* Deep Focus Top Pomodoro Banner */}
        {isDeepFocusActive && (
          <div className="bg-gradient-to-r from-emerald-950 via-teal-950 to-slate-950 text-white px-3 sm:px-6 py-2.5 flex flex-wrap items-center justify-between gap-3 shadow-md border-b border-emerald-500/30 z-20 animate-in slide-in-from-top-2 duration-200">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-300 shrink-0">
                <Clock className={`w-4 h-4 ${isDeepFocusTimerRunning ? 'animate-spin' : ''}`} />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs sm:text-sm font-bold text-emerald-200">
                    وضع التركيز العميق (Deep Focus Mode)
                  </span>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/25 text-emerald-300 font-semibold border border-emerald-400/30">
                    المشتتات معطلة
                  </span>
                </div>
                <p className="text-[11px] text-teal-200/80 hidden sm:block">
                  دفتر: «{currentNotebook.name}» — بيئة استيعاب ومذاكرة هادئة ومثمرة
                </p>
              </div>
            </div>

            {/* Countdown Display & Controls */}
            <div className="flex items-center gap-2.5">
              {/* Duration Switcher */}
              <div className="hidden sm:flex items-center bg-black/40 rounded-xl p-0.5 border border-white/10 text-xs">
                {[15, 25, 45].map((mins) => (
                  <button
                    key={mins}
                    onClick={() => handleChangeDeepFocusDuration(mins)}
                    className={`px-2.5 py-1 rounded-lg transition-colors font-semibold cursor-pointer ${
                      deepFocusDurationMins === mins
                        ? 'bg-emerald-500 text-white shadow-2xs'
                        : 'text-slate-300 hover:text-white'
                    }`}
                  >
                    {mins} د
                  </button>
                ))}
              </div>

              {/* Big Timer Display */}
              <div className="px-3.5 py-1 rounded-xl bg-black/50 border border-emerald-500/40 font-mono text-lg sm:text-xl font-black text-emerald-300 tracking-wider">
                {formatPomodoroTime(deepFocusTimeLeft)}
              </div>

              {/* Play/Pause Button */}
              <button
                onClick={() => setIsDeepFocusTimerRunning(!isDeepFocusTimerRunning)}
                className="p-2 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white shadow-md shadow-emerald-500/30 transition-transform active:scale-95 cursor-pointer"
                title={isDeepFocusTimerRunning ? 'إيقاف مؤقت' : 'بدء المؤقت'}
              >
                {isDeepFocusTimerRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-current" />}
              </button>

              {/* Reset Button */}
              <button
                onClick={handleResetDeepFocusTimer}
                className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-slate-200 transition-colors cursor-pointer"
                title="إعادة ضبط المؤقت"
              >
                <RotateCcw className="w-4 h-4" />
              </button>

              {/* Exit Focus Mode Button */}
              <button
                onClick={handleToggleDeepFocus}
                className="px-3 py-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-200 border border-rose-500/30 text-xs font-bold transition-colors cursor-pointer flex items-center gap-1 active:scale-95"
              >
                <X className="w-3.5 h-3.5" />
                <span>إنهاء التركيز</span>
              </button>
            </div>
          </div>
        )}

        {/* Focus Finished Toast */}
        {focusFinishedToast && (
          <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 bg-emerald-600 text-white px-5 py-3 rounded-2xl shadow-2xl border border-emerald-400 flex items-center gap-3 animate-in fade-in slide-in-from-top-4">
            <Sparkles className="w-5 h-5 text-amber-300 animate-spin" />
            <div>
              <p className="font-bold text-sm">أحسنت! اكتملت جلسة التركيز بنجاح 🎉</p>
              <p className="text-xs text-emerald-100">تم تسجيل الجلسة في سجل إنجازات المذاكرة.</p>
            </div>
          </div>
        )}

        {/* AI Mind Map Generation Toast */}
        {isGeneratingMindMap && (
          <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 bg-teal-800/95 backdrop-blur-md text-white px-5 py-3.5 rounded-2xl shadow-2xl border border-teal-500/40 flex items-center gap-3.5 animate-in fade-in slide-in-from-top-4 max-w-md w-[92%] sm:w-auto">
            <div className="w-7 h-7 rounded-xl bg-teal-700/80 flex items-center justify-center shrink-0">
              <GitFork className="w-4 h-4 text-teal-300 animate-spin" />
            </div>
            <div className="min-w-0">
              <p className="font-bold text-xs sm:text-sm text-teal-100 flex items-center gap-1.5">
                <span>توليد الخريطة الذهنية بالذكاء الاصطناعي</span>
                <span className="text-[10px] bg-teal-600 px-1.5 py-0.2 rounded font-mono">AI</span>
              </p>
              <p className="text-[11px] text-teal-200/90 truncate mt-0.5">
                {mindMapToastMessage || 'يتم استخلاص وهيكلة المفاهيم بدقة بدون كلام جانبي...'}
              </p>
            </div>
          </div>
        )}

        <main 
          style={(currentTab === 'chat' || currentTab === 'question_bank') && chatViewportHeight ? { height: `${chatViewportHeight}px` } : undefined}
          className={`flex-1 min-w-0 ${(currentTab === 'chat' || currentTab === 'question_bank') ? 'h-[100dvh] flex flex-col p-0 sm:p-2 lg:p-4 overflow-hidden' : 'overflow-y-auto p-3 sm:p-4 lg:p-6 pb-32 lg:pb-8'}`}
        >
          <div className={`mx-auto w-full ${currentTab === 'chat' ? 'h-full max-w-5xl flex flex-col flex-1 min-h-0' : currentTab === 'question_bank' ? 'h-full max-w-7xl flex flex-col flex-1 min-h-0' : 'max-w-7xl'}`}>
            {currentTab === 'home' && (
              <HomeView
                currentNotebook={currentNotebook}
                sources={notebookSources}
                chunks={notebookChunks}
                chatSession={currentChatSession}
                flashcards={notebookFlashcards}
                focusSessions={notebookFocusSessions}
                todos={notebookTodos}
                allNotes={appState.notes}
                allFlashcards={appState.flashcards}
                notebooks={appState.notebooks}
                onToggleTodo={handleToggleTodo}
                onAddTodo={handleAddTodo}
                showTodayTasks={appState.settings.showTodayTasksOnHome}
                onToggleShowTodayTasks={(val) =>
                  setAppState((prev) => ({
                    ...prev,
                    settings: { ...prev.settings, showTodayTasksOnHome: val },
                  }))
                }
                onNavigateTab={navigateToTab}
              />
            )}

            {currentTab === 'sources' && (
              <SourcesView
                sources={notebookSources}
                chunks={notebookChunks}
                currentNotebookId={currentNotebook.id}
                onAddSource={handleAddSource}
                onDeleteSource={handleDeleteSource}
                onRenameSource={handleRenameSource}
                onDeleteMultipleSources={handleDeleteMultipleSources}
                selectedSourceIds={selectedSourceIds}
                onToggleSelectSource={handleToggleSelectSource}
                onSelectAllSources={handleSelectAllSources}
                onClearSelectedSources={handleClearSelectedSources}
                onAskAboutSource={handleAskAboutSource}
                onUpdateSourceAnnotations={handleUpdateSourceAnnotations}
                onAskAboutQuote={handleAskAboutQuote}
                onExportToNote={handleExportToNote}
                onUpdateSource={handleUpdateSource}
                notebookName={currentNotebook.name}
                favoriteSourceIds={appState.favoriteSourceIds || []}
                onToggleFavoriteSource={handleToggleFavoriteSource}
              />
            )}

            {currentTab === 'question_bank' && (
              <ErrorBoundary fallbackTitle="حدث تعذر أثناء تحميل بنك الأسئلة والموسوعة">
                <QuestionBankView
                  currentLang={currentLanguage}
                  sources={notebookSources.length > 0 ? notebookSources : appState.sources}
                  chunks={notebookChunks.length > 0 ? notebookChunks : appState.chunks}
                  quizzes={appState.quizzes}
                  onAskAboutQuestion={(text) => {
                    setPrefilledChatPrompt(text);
                    setCurrentTab('chat');
                  }}
                  onExportToNote={(title, content) => {
                    handleAddNote(title, content, ['بنك_الأسئلة', 'وزاري_طبي']);
                  }}
                  onNavigateHome={() => navigateToTab('home')}
                  onRecordExamQuiz={(quiz) => {
                    setAppState((prev) => ({
                      ...prev,
                      quizzes: [quiz, ...prev.quizzes],
                    }));
                  }}
                />
              </ErrorBoundary>
            )}

            {currentTab === 'chat' && (
              <ChatView
                session={currentChatSession}
                allSessions={notebookSessions}
                onSelectSession={handleSelectSession}
                onNewSession={handleNewSession}
                onDeleteSession={handleDeleteSession}
                onRenameSession={handleRenameSession}
                sources={notebookSources}
                chunks={notebookChunks}
                selectedSourceIds={currentChatSession.sourceIds !== undefined ? currentChatSession.sourceIds : selectedSourceIds}
                onUpdateSessionSources={handleUpdateSessionSources}
                currentNotebookId={currentNotebook.id}
                notebookTitle={currentNotebook.name}
                notebookSubject={currentNotebook.subject}
                aiMode={appState.settings.aiMode}
                onChangeAIMode={(mode: AIMode) =>
                  setAppState((p) => ({
                    ...p,
                    settings: { ...p.settings, aiMode: mode },
                  }))
                }
                fallbackConfig={appState.settings.fallbackAI}
                onSendMessage={handleSendMessage}
                onAddUserMessage={handleAddUserMessage}
                onAddAiResponse={handleAddAiResponse}
                onDeleteMessage={handleDeleteMessage}
                onRateMessage={handleRateMessage}
                viewportHeight={chatViewportHeight}
                onNavigateHome={() => navigateToTab('home')}
                onNavigateToStudio={() => setCurrentTab('studio')}
                onUpdateSourceAnnotations={handleUpdateSourceAnnotations}
                onAskAboutQuote={handleAskAboutQuote}
                onExportToNote={handleExportToNote}
                onGenerateMindMapFromText={handleGenerateMindMapFromText}
                onGenerateMindMapFromConversation={handleGenerateMindMapFromConversation}
                prefilledPrompt={prefilledChatPrompt}
                onClearPrefilledPrompt={() => setPrefilledChatPrompt('')}
              />
            )}

            {currentTab === 'studio' && (
              <StudyStudioView
                currentNotebookId={currentNotebook.id}
                notebookTitle={currentNotebook.name}
                notebookSubject={currentNotebook.subject}
                sources={notebookSources}
                chunks={notebookChunks}
                notes={notebookNotes}
                onAddNote={handleAddNote}
                onDeleteNote={handleDeleteNote}
                onAskAboutNote={handleAskAboutNote}
                flashcards={notebookFlashcards}
                onAddFlashcards={handleAddFlashcards}
                onReviewCard={handleReviewCard}
                todos={notebookTodos}
                onAddTodo={handleAddTodo}
                onToggleTodo={handleToggleTodo}
                onDeleteTodo={handleDeleteTodo}
                memos={notebookMemos}
                onAddMemo={handleAddMemo}
                onDeleteMemo={handleDeleteMemo}
                glossary={notebookGlossary}
                onAddGlossary={handleAddGlossary}
                onDeleteGlossary={handleDeleteGlossary}
                fallbackConfig={appState.settings.fallbackAI}
              />
            )}

            {currentTab === 'mindmap' && (
              <div className="space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-[#14201c] p-4 rounded-2xl border border-[#e2e8e5] dark:border-[#22352f] shadow-sm">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded-md bg-teal-100 dark:bg-teal-950 text-teal-800 dark:text-teal-300 text-[10px] font-bold">
                        D3 Mind Map Automation
                      </span>
                      <span className="text-xs text-gray-500 font-mono">Interactive Knowledge Graph</span>
                    </div>
                    <h2 className="font-bold text-lg text-[#17201e] dark:text-[#eef7f4] flex items-center gap-2 mt-1">
                      <GitFork className="w-5 h-5 text-[#0f766e] dark:text-[#2dd4bf]" />
                      <span>الخريطة الذهنية التفاعلية لدفتر «{currentNotebook.name}»</span>
                    </h2>
                    <p className="text-xs text-[#596762] dark:text-[#9ab3ab] mt-0.5">
                      توليد خريطة ذهنية بصرية تلقائياً بناءً على المصادر ({notebookSources.length})، الملاحظات ({notebookNotes.length})، والمصطلحات ({notebookGlossary.length}) لربط المفاهيم وتصور العلاقات بمكتبة D3.
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setCurrentTab('chat')}
                      className="px-3.5 py-2 bg-[#f6f8f7] dark:bg-[#1a2723] hover:bg-teal-50 dark:hover:bg-teal-950 text-teal-800 dark:text-teal-200 border border-[#e2e8e5] dark:border-[#22352f] rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
                    >
                      <MessageSquare className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                      <span>مناقشة المفاهيم في المحادثة</span>
                    </button>
                    <button
                      onClick={() => setCurrentTab('studio')}
                      className="px-3.5 py-2 bg-[#0f766e] hover:bg-[#115e59] text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>أدوات الدراسة والملخصات</span>
                    </button>
                  </div>
                </div>

                <D3VisualMindMap
                  notebookTitle={currentNotebook.name}
                  notebookSubject={currentNotebook.subject}
                  glossary={notebookGlossary}
                  memos={notebookMemos}
                  sources={notebookSources}
                  chunks={notebookChunks}
                  notes={notebookNotes}
                  chatMessages={currentChatSession?.messages || []}
                  initialData={activeMindMapData}
                  onSave={(newData) => setActiveMindMapData(newData)}
                  onAskAboutConcept={(conceptTitle, conceptNotes) => {
                    handleAskAboutQuote(`اشرح لي بالتفصيل مفهوم «${conceptTitle}» وعلاقاته بالمفاهيم الأخرى في سياق هذا الدفتر الدراسي.${conceptNotes ? `\nالملاحظات المسجلة: ${conceptNotes}` : ''}`);
                  }}
                />
              </div>
            )}

            {currentTab === 'science' && (
              <ScienceLabView
                currentNotebook={currentNotebook}
                notebookSources={notebookSources}
                onAskAiAboutExperiment={(context) => {
                  setPrefilledChatPrompt(context);
                  setCurrentTab('chat');
                }}
                onSaveExperimentAsNote={(title, content) => {
                  handleAddNote(title, content, ['معمل', 'علوم']);
                }}
              />
            )}

            {currentTab === 'achievements' && (
              <AchievementsDashboard
                notebooks={appState.notebooks}
                currentNotebook={currentNotebook}
                sources={notebookSources}
                flashcards={notebookFlashcards}
                focusSessions={appState.focusSessions}
                notes={appState.notes}
                onNavigateTab={navigateToTab}
              />
            )}

            {currentTab === 'tools' && (
              <ToolsView
                currentNotebookId={currentNotebook.id}
                focusSessions={notebookFocusSessions}
                allFocusSessions={appState.focusSessions}
                notebooks={appState.notebooks}
                onAddFocusSession={handleAddFocusSession}
              />
            )}

            {currentTab === 'export' && (
              <ExportView
                currentNotebook={currentNotebook}
                sources={notebookSources}
                chatSession={currentChatSession}
                flashcards={notebookFlashcards}
                notes={notebookNotes}
                onExportAllData={handleExportAllData}
                onImportData={handleImportData}
              />
            )}

            {currentTab === 'settings' && (
              <SettingsView
                state={appState}
                onUpdateSettings={(s) => setAppState((p) => ({ ...p, settings: s }))}
                onClearAllData={handleClearAllData}
                userProfile={appState.userProfile}
                onSignIn={handleGoogleSignIn}
                onSignOut={handleGoogleSignOut}
                onSyncNow={handleManualSyncNow}
                onRestoreFromCloud={handleRestoreFromCloud}
                isSyncing={isSyncingCloud}
                lastSyncAt={lastSyncTimestamp}
                onOpenSupportModal={() => setIsSupportModalOpen(true)}
                onChangeLanguage={handleLanguageChange}
              />
            )}
          </div>
        </main>

        {/* Mobile Bottom Navigation Bar (Enhanced 6 Touch Destinations) */}
        {!isDeepFocusActive && (
          <nav
            aria-label="شريط التنقل السفلي للهواتف"
            className="lg:hidden fixed bottom-0 inset-x-0 z-40 bg-white/95 dark:bg-[#121b18]/95 backdrop-blur-md border-t border-[#e2e8e5] dark:border-[#22352f] px-1 py-1 flex items-center justify-around shadow-xl"
          >
            <button
              type="button"
              onClick={() => navigateToTab('home')}
              className={`flex flex-col items-center gap-0.5 py-1 px-3 rounded-xl transition-all cursor-pointer ${
                currentTab === 'home'
                  ? 'text-[#0f766e] dark:text-[#2dd4bf] font-bold'
                  : 'text-[#596762] dark:text-[#9ab3ab]'
              }`}
            >
              <LayoutDashboard className="w-5 h-5" />
              <span className="text-[10px]">{t('nav.home', currentLanguage, 'الرئيسية')}</span>
            </button>

            <button
              type="button"
              onClick={() => navigateToTab('chat')}
              className={`flex flex-col items-center gap-0.5 py-1 px-3 rounded-xl transition-all cursor-pointer relative ${
                currentTab === 'chat'
                  ? 'text-[#0f766e] dark:text-[#2dd4bf] font-bold'
                  : 'text-[#596762] dark:text-[#9ab3ab]'
              }`}
            >
              <MessageSquare className="w-5 h-5" />
              <span className="text-[10px]">{t('nav.chat', currentLanguage, 'المعلم AI')}</span>
            </button>

            <button
              type="button"
              onClick={() => navigateToTab('sources')}
              className={`flex flex-col items-center gap-0.5 py-1 px-3 rounded-xl transition-all cursor-pointer relative ${
                currentTab === 'sources'
                  ? 'text-[#0f766e] dark:text-[#2dd4bf] font-bold'
                  : 'text-[#596762] dark:text-[#9ab3ab]'
              }`}
            >
              <div className="relative">
                <FileText className="w-5 h-5" />
                {notebookSources.length > 0 && (
                  <span className="absolute -top-1 -right-2 w-3.5 h-3.5 rounded-full bg-[#0f766e] dark:bg-[#2dd4bf] text-white dark:text-[#0c1412] text-[8px] flex items-center justify-center font-bold">
                    {notebookSources.length}
                  </span>
                )}
              </div>
              <span className="text-[10px]">{t('nav.sources', currentLanguage, 'المصادر')}</span>
            </button>

            <button
              type="button"
              onClick={() => navigateToTab('settings')}
              className={`flex flex-col items-center gap-0.5 py-1 px-3 rounded-xl transition-all cursor-pointer ${
                currentTab === 'settings'
                  ? 'text-[#0f766e] dark:text-[#2dd4bf] font-bold'
                  : 'text-[#596762] dark:text-[#9ab3ab]'
              }`}
            >
              <User className="w-5 h-5" />
              <span className="text-[10px]">{t('nav.account', currentLanguage, 'حسابي')}</span>
            </button>
          </nav>
        )}

        {/* Discreet Institutional Ownership Footer */}
        <footer className="hidden sm:flex items-center justify-between px-6 py-1.5 bg-[#f0f4f2] dark:bg-[#0e1714] border-t border-[#e2e8e5] dark:border-[#1c2a25] text-[10px] text-slate-500 dark:text-slate-400 shrink-0">
          <div className="flex items-center gap-1.5 font-medium">
            <span className="w-1.5 h-1.5 rounded-full bg-teal-500 animate-pulse" />
            <span>Developed by <b className="text-teal-700 dark:text-teal-300 font-bold">Dhiyaa Al-Haq Subayqaa & The D.CORE Academic Team</b></span>
          </div>
          <div className="text-[10px] text-slate-400 dark:text-slate-500 font-medium">
            تم التطوير بواسطة المهندس ضياء الحق سبيقاء وفريق D.CORE الأكاديمي
          </div>
        </footer>
      </div>

      {/* Google Cloud Authentication & Synchronization Modal */}
      {isAuthModalOpen && (
        <StudentAuthModal
          isOpen={isAuthModalOpen}
          onClose={() => setIsAuthModalOpen(false)}
          userProfile={appState.userProfile || null}
          onSignIn={handleGoogleSignIn}
          onSignOut={handleGoogleSignOut}
          onSyncNow={handleManualSyncNow}
          onRestoreFromCloud={handleRestoreFromCloud}
          isSyncing={isSyncingCloud}
          lastSyncAt={lastSyncTimestamp}
        />
      )}

      {/* Public Share Notebook Modal */}
      {isShareModalOpen && (
        <ShareNotebookModal
          isOpen={isShareModalOpen}
          onClose={() => setIsShareModalOpen(false)}
          notebook={targetShareNotebook}
          summaries={targetShareSummaries}
          notes={targetShareNotes}
          memos={targetShareMemos}
          glossary={targetShareGlossary}
          flashcards={targetShareFlashcards}
          sources={targetShareSources}
          defaultAuthorName={appState.settings.userName || 'طالب باحث'}
          onPreviewShared={handlePreviewSharedNotebook}
        />
      )}

      {/* In-App Direct Support Modal routing to dyaalhqsbyqa10@gmail.com */}
      <SupportModal
        isOpen={isSupportModalOpen}
        onClose={() => setIsSupportModalOpen(false)}
        userProfile={appState.userProfile}
        currentLang={currentLanguage}
      />

      {/* Omni Academic Reference & Knowledge Explorer Modal */}
      <OmniAcademicReferenceModal
        isOpen={isAcademicRefModalOpen}
        onClose={() => setIsAcademicRefModalOpen(false)}
        onSaveAsNote={(title, content) => {
          handleAddNote(title, content, ['مرجع_أكاديمي', 'موسوعة']);
        }}
        onAskAi={(prompt) => {
          setPrefilledChatPrompt(prompt);
          navigateToTab('chat');
        }}
      />


      {/* Voice Note Recording & Speech-to-Text Modal (Stored as MemoItem) */}
      <VoiceMemoModal
        isOpen={isVoiceMemoModalOpen}
        onClose={() => setIsVoiceMemoModalOpen(false)}
        currentNotebook={currentNotebook}
        onSaveMemo={(memoText) => {
          handleAddMemo(memoText);
        }}
        onNavigateToStudioMemos={() => {
          navigateToTab('studio');
        }}
      />

      {/* PWA Network Connectivity & Offline Mode Indicator */}
      <OfflineIndicator />
    </div>
  );
}

export default App;
