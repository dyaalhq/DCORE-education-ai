import { Notebook, Source, SourceChunk, ChatSession, NoteItem, QuizResult, Flashcard, StudyPlan, TodoItem, MemoItem, GlossaryItem, FocusSession, FallbackAISettings, UserProfile, CustomSummaryDoc } from '../types';
import { EncyclopediaArticle } from './offlineDatabase';
import { COMPREHENSIVE_ENCYCLOPEDIA_ARTICLES } from './encyclopediaData';

const STORAGE_KEY = 'almoallim_v28_state';
const LEGACY_KEYS = ['pro_study_v9_ultimate_data', 'pro_study_v18_production_data', 'pro_study_v17_production_data'];

export interface ScienceCategory {
  id: string;
  name: string;
  description: string;
  icon?: string;
  subCategories: string[];
}

export interface AcademicEncyclopediaState {
  articles: EncyclopediaArticle[];
  categories: ScienceCategory[];
  userBookmarks: string[];
  recentResolvedQueries: {
    query: string;
    resolvedAt: number;
    articleId: string;
  }[];
}

export interface AppState {
  notebooks: Notebook[];
  currentNotebookId: string;
  sources: Source[];
  chunks: SourceChunk[];
  chatSessions: ChatSession[];
  notes: NoteItem[];
  quizzes: QuizResult[];
  flashcards: Flashcard[];
  plans: StudyPlan[];
  todos: TodoItem[];
  memos: MemoItem[];
  glossary: GlossaryItem[];
  focusSessions: FocusSession[];
  userProfile?: UserProfile | null;
  customSummaries?: CustomSummaryDoc[];
  savedMindMaps?: any[];
  favoriteSourceIds?: string[];
  academicEncyclopedia?: AcademicEncyclopediaState;
  settings: {
    theme: 'light' | 'dark';
    aiMode: 'notebook' | 'hybrid' | 'general';
    sound: string;
    language?: 'ar' | 'en' | 'fr' | 'tr';
    userName: string;
    showTodayTasksOnHome?: boolean;
    fallbackAI?: FallbackAISettings;
  };
}

export const DEFAULT_SCIENCE_CATEGORIES: ScienceCategory[] = [
  {
    id: 'physics_cosmology',
    name: 'الفيزياء والكونيات',
    description: 'النسبية، ميكانيكا الكم، الديناميكا الحرارية، الكهرومغناطيسية والدوائر، والفيزياء النووية.',
    icon: 'Atom',
    subCategories: ['النسبية العامة والخاصة', 'ميكانيكا الكم', 'الديناميكا الحرارية والإنتروبيا', 'الكهرومغناطيسية والرنين', 'الفيزياء الفلكية']
  },
  {
    id: 'mathematics_analysis',
    name: 'الرياضيات والتحليل',
    description: 'التفاضل والتكامل، الجبر الخطي، المعادلات التفاضلية، التحليل المركب، والإحصاء الرياضي.',
    icon: 'Binary',
    subCategories: ['حساب التفاضل والتكامل', 'الجبر الخطي و SVD', 'المعادلات التفاضلية الجزئية', 'الأعداد المركبة']
  },
  {
    id: 'medicine_biosciences',
    name: 'الطب والعلوم الحيوية',
    description: 'الفسيولوجيا، الحركية الدوائية، علم المناعة، علم الوراثة والجينوم، وطب القلب والأوعية.',
    icon: 'HeartPulse',
    subCategories: ['علم العقاقير والحركية الدوائية', 'الفسيولوجيا العصبية', 'علم المناعة الخلوية', 'طب القلب والدورة الدموية']
  },
  {
    id: 'chemistry_materials',
    name: 'الكيمياء وتطبيقاتها',
    description: 'الكيمياء الكهربائية، الاتزان الكيميائي، الديناميكا الحرارية الكيميائية، والكيمياء العضوية.',
    icon: 'FlaskConical',
    subCategories: ['الكيمياء الكهربائية ومعادلة نيرنست', 'الاتزان الكيميائي', 'الكيمياء العضوية']
  },
  {
    id: 'ai_computer_science',
    name: 'الذكاء الاصطناعي والحاسوب',
    description: 'نماذج المحولات، معالجة اللغات الطبيعية، التعلم العميق، الحوسبة الكمومية، وهياكل البيانات.',
    icon: 'Cpu',
    subCategories: ['معمارية المحولات و LLMs', 'الشبكات العصبية العميقة', 'الحوسبة الكمومية']
  },
  {
    id: 'arabic_linguistics',
    name: 'اللغة العربية والأدب',
    description: 'علم النحو والإعراب، علم الصرف، البلاغة والإعجاز، علم العروض وبحور الشعر، وفقه اللغة.',
    icon: 'BookOpen',
    subCategories: ['علم العروض وبحور الشعر', 'قواعد النحو والإعراب', 'البلاغة والبيان']
  },
  {
    id: 'history_civilizations',
    name: 'التاريخ والحضارات',
    description: 'تاريخ اليمن القديم وحضارات سبأ وحمير، حضارة ما بين النهرين، والتاريخ الإنساني المقارن.',
    icon: 'Landmark',
    subCategories: ['حضارات اليمن القديم وسد مأرب', 'حضارة ما بين النهرين وشريعة حمورابي']
  },
  {
    id: 'islamic_jurisprudence',
    name: 'العلوم الشرعية والفقه',
    description: 'أصول الفقه، فقه المعاملات والفرائض، أحكام التجويد والقرآن، والقواعد الفقهية الكبرى.',
    icon: 'Scale',
    subCategories: ['أصول الفقه والقواعد الفقهية', 'فقه المواريث والفرائض', 'أحكام التلاوة والتجويد']
  },
  {
    id: 'economics_game_theory',
    name: 'الاقتصاد ونظرية الألعاب',
    description: 'نظرية الألعاب وتوازن ناش، الاقتصاد الكلي، والسياسات النقدية والمالية.',
    icon: 'TrendingUp',
    subCategories: ['نظرية الألعاب وتوازن ناش', 'السياسات النقدية والاقتصاد الكلي']
  }
];

function createDefaultState(): AppState {
  const defaultNb: Notebook = {
    id: 'nb_default',
    name: 'مساحة التعلم الرئيسية',
    subject: 'عام',
    description: 'مساحة دراسية لجمع المصادر والمحادثة الذكية والمذاكرة الفعالة.',
    createdAt: Date.now(),
    updatedAt: Date.now(),
    sourceIds: [],
    noteIds: [],
    chatSessionIds: ['chat_default'],
    progress: 0,
  };

  const defaultSession: ChatSession = {
    id: 'chat_default',
    notebookId: 'nb_default',
    title: 'محادثة استكشافية',
    created: Date.now(),
    updated: Date.now(),
    messages: [
      {
        id: 'msg_welcome',
        role: 'ai',
        text: `مرحبًا بك في **المعلم الذكي** ✦\n\nمنصتك التعليمية المتكاملة بأسلوب Google NotebookLM.\n\nيمكنك الآن:\n1. 📁 **إضافة مصادر**: ارفع ملفات PDF، صفحات HTML، مستندات، أو أضف روابط ويب ومصادر موثوقة.\n2. 💬 **المحادثة مع المصادر**: اسأل الذكاء الاصطناعي ليجيبك بدقة ويشرح لك أي مفهوم.\n3. 📝 **الملخصات والمذكرات الخاصة**: أضف ملخصاتك الخاصة وخصصها واطبعها كملف PDF ملون أو موفر للحبر.\n4. 🗺️ **الخرائط الذهنية المتطورة**: أنشئ خرائط ذهنية تفاعلية بأشكال متعددة (دائري، شجري، RTL) مع تصدير عالي الدقة.\n5. 🔑 **حساب Google**: سجل دخولك بحساب Google لمزامنة كافة أبحاثك ودفاترك سحابياً.`,
        date: Date.now(),
        notebookId: 'nb_default',
        sessionId: 'chat_default',
      }
    ],
    sourceIds: [],
  };

  return {
    notebooks: [defaultNb],
    currentNotebookId: 'nb_default',
    sources: [],
    chunks: [],
    chatSessions: [defaultSession],
    notes: [],
    quizzes: [],
    flashcards: [],
    plans: [],
    todos: [],
    memos: [],
    glossary: [],
    focusSessions: [],
    userProfile: null,
    customSummaries: [],
    savedMindMaps: [],
    favoriteSourceIds: [],
    academicEncyclopedia: {
      articles: COMPREHENSIVE_ENCYCLOPEDIA_ARTICLES,
      categories: DEFAULT_SCIENCE_CATEGORIES,
      userBookmarks: [],
      recentResolvedQueries: []
    },
    settings: {
      theme: 'light',
      aiMode: 'notebook',
      sound: 'chime',
      language: 'ar',
      userName: '',
      showTodayTasksOnHome: true,
      fallbackAI: {
        enabled: true,
        activeProvider: 'auto',
        providerName: 'OpenAI / Groq / OpenRouter',
        apiKey: '',
        baseUrl: 'https://api.openai.com/v1',
        model: 'gpt-4o-mini',
        geminiApiKey: '',
        geminiModel: 'gemini-3.8-flash',
      },
    }
  };
}

export async function syncStateToCloud(email: string, state: AppState): Promise<boolean> {
  try {
    const res = await fetch('/api/user/sync', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userEmail: email, appState: state }),
    });
    const data = await res.json();
    return !!data.success;
  } catch (err) {
    console.warn('syncStateToCloud error:', err);
    return false;
  }
}

export async function loadStateFromCloud(email: string): Promise<AppState | null> {
  try {
    const res = await fetch(`/api/user/sync?userEmail=${encodeURIComponent(email)}`);
    const data = await res.json();
    if (data.success && data.appState) {
      return data.appState;
    }
    return null;
  } catch (err) {
    console.warn('loadStateFromCloud error:', err);
    return null;
  }
}

export function loadAppState(): AppState {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      if (parsed.notebooks && parsed.notebooks.length > 0) {
        // Guarantee isolated sourceIds per chat session
        if (Array.isArray(parsed.chatSessions)) {
          parsed.chatSessions = parsed.chatSessions.map((session: any) => ({
            ...session,
            sourceIds: Array.isArray(session.sourceIds) ? session.sourceIds : [],
          }));
        }
        parsed.favoriteSourceIds = Array.isArray(parsed.favoriteSourceIds) ? parsed.favoriteSourceIds : [];

        if (!parsed.academicEncyclopedia || !Array.isArray(parsed.academicEncyclopedia.articles) || parsed.academicEncyclopedia.articles.length === 0) {
          parsed.academicEncyclopedia = {
            articles: COMPREHENSIVE_ENCYCLOPEDIA_ARTICLES,
            categories: DEFAULT_SCIENCE_CATEGORIES,
            userBookmarks: [],
            recentResolvedQueries: []
          };
        } else {
          const existingCatIds = new Set(parsed.academicEncyclopedia.categories?.map((c: any) => c.id) || []);
          const mergedCategories = [
            ...(parsed.academicEncyclopedia.categories || []),
            ...DEFAULT_SCIENCE_CATEGORIES.filter((c) => !existingCatIds.has(c.id))
          ];
          parsed.academicEncyclopedia.categories = mergedCategories;
        }

        return parsed;
      }
    }

    // Try legacy migration
    for (const key of LEGACY_KEYS) {
      const old = localStorage.getItem(key);
      if (old) {
        try {
          const parsedOld = JSON.parse(old);
          const state = createDefaultState();
          if (Array.isArray(parsedOld.notebooks) && parsedOld.notebooks.length > 0) {
            state.notebooks = parsedOld.notebooks;
            state.currentNotebookId = parsedOld.currentNotebookId || parsedOld.notebooks[0].id;
          }
          if (Array.isArray(parsedOld.sources)) state.sources = parsedOld.sources;
          if (Array.isArray(parsedOld.sourceChunks)) state.chunks = parsedOld.sourceChunks;
          if (Array.isArray(parsedOld.chatSessions)) state.chatSessions = parsedOld.chatSessions;
          if (Array.isArray(parsedOld.notes)) state.notes = parsedOld.notes;
          if (Array.isArray(parsedOld.cards)) state.flashcards = parsedOld.cards;
          if (Array.isArray(parsedOld.memos)) state.memos = parsedOld.memos;
          if (Array.isArray(parsedOld.glossary)) state.glossary = parsedOld.glossary;
          if (Array.isArray(parsedOld.todos)) state.todos = parsedOld.todos;
          saveAppState(state);
          return state;
        } catch (e) {
          console.warn('Legacy data parse error:', e);
        }
      }
    }
  } catch (err) {
    console.error('Failed to load state from localStorage:', err);
  }

  const def = createDefaultState();
  saveAppState(def);
  return def;
}

export function saveAppState(state: AppState) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (err) {
    console.error('Failed to save state to localStorage:', err);
  }
}

// IndexedDB for large files and PDF blobs
const DB_NAME = 'AlmoallimIndexedDB';
const DB_VERSION = 1;

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains('files')) {
        db.createObjectStore('files', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('cached_results')) {
        db.createObjectStore('cached_results', { keyPath: 'key' });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function storeFileBlob(id: string, file: File | Blob, metadata: Record<string, any> = {}): Promise<void> {
  try {
    const db = await openDB();
    const tx = db.transaction('files', 'readwrite');
    const store = tx.objectStore('files');
    store.put({ id, blob: file, ...metadata, savedAt: Date.now() });
    return new Promise((res, rej) => {
      tx.oncomplete = () => res();
      tx.onerror = () => rej(tx.error);
    });
  } catch (err) {
    console.warn('storeFileBlob error:', err);
  }
}

export async function getFileBlob(id: string): Promise<Blob | null> {
  try {
    const db = await openDB();
    const tx = db.transaction('files', 'readonly');
    const store = tx.objectStore('files');
    const req = store.get(id);
    return new Promise((res, rej) => {
      req.onsuccess = () => res(req.result?.blob || null);
      req.onerror = () => rej(req.error);
    });
  } catch (err) {
    console.warn('getFileBlob error:', err);
    return null;
  }
}

export async function deleteFileBlob(id: string): Promise<void> {
  try {
    const db = await openDB();
    const tx = db.transaction('files', 'readwrite');
    const store = tx.objectStore('files');
    store.delete(id);
    return new Promise((res, rej) => {
      tx.oncomplete = () => res();
      tx.onerror = () => rej(tx.error);
    });
  } catch (err) {
    console.warn('deleteFileBlob error:', err);
  }
}
