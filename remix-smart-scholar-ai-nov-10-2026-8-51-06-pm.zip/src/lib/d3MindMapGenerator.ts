import { MindMapNode, GlossaryItem, MemoItem, Source, SourceChunk, NoteItem } from '../types';

export interface ClusteredMindMapResult {
  root: MindMapNode;
  termCount: number;
  memoCount: number;
  notesCount: number;
  sourcesCount: number;
  clustersCount: number;
  crossLinks: Array<{ sourceId: string; targetId: string; label?: string }>;
}

/**
 * Clusters terms, memos, student notes, and source concepts into an interconnected MindMapNode tree
 * designed specifically for D3 hierarchical, radial, and force-directed graph visualization.
 * Automatically discovers relationships and cross-links between concepts.
 */
export function generateClusteredNotebookMindMap(
  notebookTitle: string,
  notebookSubject: string,
  glossary: GlossaryItem[] = [],
  memos: MemoItem[] = [],
  sources: Source[] = [],
  chunks: SourceChunk[] = [],
  notes: NoteItem[] = [],
  existingData?: MindMapNode | null
): ClusteredMindMapResult {
  const rootTitle = notebookTitle || 'الفكرة المركزية للدراسة';
  const rootColor = '#0f766e'; // Dark Emerald
  const crossLinks: Array<{ sourceId: string; targetId: string; label?: string }> = [];

  // 1. Group Glossary Items into meaningful semantic clusters
  const termsCluster: MindMapNode = {
    id: 'cluster-terms',
    title: 'المفاهيم والمصطلحات المحورية (Glossary)',
    level: 1,
    color: '#0284c7', // Sky Blue
    badge: `${glossary.length} مصطلح`,
    notes: 'المصطلحات الأساسية والتعاريف العلمية المترابطة المستخلصة من سياق الدفتر والمصادر.',
    children: [],
  };

  if (glossary.length > 0) {
    glossary.forEach((item, index) => {
      const termId = `term-${index + 1}`;
      termsCluster.children?.push({
        id: termId,
        title: item.term,
        level: 2,
        color: '#0284c7',
        badge: 'مصطلح علمي',
        notes: item.def + (item.ex ? `\n\nمثال توضيحي: ${item.ex}` : ''),
      });
    });
  } else {
    // Extract potential concepts from sources if glossary is empty
    const extractedTerms: string[] = [];
    sources.forEach((s) => {
      const boldMatches = s.content.match(/\*\*([^\*\n]{3,35})\*\*/g);
      if (boldMatches) {
        boldMatches.forEach((m) => {
          const clean = m.replace(/\*/g, '').trim();
          if (clean && !extractedTerms.includes(clean) && extractedTerms.length < 5) {
            extractedTerms.push(clean);
          }
        });
      }
    });

    if (extractedTerms.length > 0) {
      extractedTerms.forEach((term, index) => {
        termsCluster.children?.push({
          id: `term-ext-${index + 1}`,
          title: term,
          level: 2,
          color: '#0284c7',
          badge: 'مفهوم مستخلص',
          notes: `مفهوم محوري مستخرج تلقائياً من محتوى مصادر الدفتر «${notebookTitle}».`,
        });
      });
    } else {
      termsCluster.children = [
        {
          id: 'term-def-1',
          title: 'التعريف المنهجي والمبادئ الأولى',
          level: 2,
          color: '#0284c7',
          badge: 'تأسيس',
          notes: 'الأساس النظري والتأصيل العلمي للموضوع.',
        },
        {
          id: 'term-def-2',
          title: 'المحددات والخصائص الجوهرية',
          level: 2,
          color: '#0284c7',
          badge: 'خصائص',
          notes: 'السمات الفارقة والشروط الحاكمة في المنهج.',
        },
      ];
    }
  }

  // 2. Group Student Notes (NoteItem) into notes cluster
  const notesCluster: MindMapNode = {
    id: 'cluster-notes',
    title: 'ملاحظات وتدوينات الطالب (Student Notes)',
    level: 1,
    color: '#059669', // Emerald Green
    badge: `${notes.length} ملاحظة`,
    notes: 'الملاحظات والتدوينات المصاغة مباشرة لدعم الاستيعاب والمراجعة.',
    children: [],
  };

  if (notes.length > 0) {
    notes.forEach((n, idx) => {
      const noteNodeId = `note-${n.id || idx + 1}`;
      const relatedTerms: string[] = [];

      // Check if note mentions any glossary term
      termsCluster.children?.forEach((tNode) => {
        if (n.text.toLowerCase().includes(tNode.title.toLowerCase())) {
          relatedTerms.push(tNode.id);
          crossLinks.push({
            sourceId: noteNodeId,
            targetId: tNode.id,
            label: 'تطبيق للمفهوم',
          });
        }
      });

      notesCluster.children?.push({
        id: noteNodeId,
        title: n.title || `ملاحظة دراسية ${idx + 1}`,
        level: 2,
        color: '#059669',
        badge: n.level ? `مستوى ${n.level}` : 'ملاحظة',
        notes: `${n.text}${n.goal ? `\n\n🎯 الهدف: ${n.goal}` : ''}`,
        relatedNodeIds: relatedTerms.length > 0 ? relatedTerms : undefined,
        relationLabel: relatedTerms.length > 0 ? 'يرتبط بمفهوم محوري' : undefined,
      });
    });
  } else {
    notesCluster.children = [
      {
        id: 'note-def-1',
        title: 'ملخص المفاهيم واستنتاجات القراءة',
        level: 2,
        color: '#059669',
        badge: 'استنتاج',
        notes: 'الخلاصة المستنتجة من مطالعة فصول الدفتر ومناقشة المعلم الذكي.',
      },
    ];
  }

  // 3. Group Study Memos (MemoItem)
  const memosCluster: MindMapNode = {
    id: 'cluster-memos',
    title: 'الملاحظات السريعة والاستذكار (Study Memos)',
    level: 1,
    color: '#10b981', // Light Teal/Emerald
    badge: `${memos.length} مذكرة`,
    notes: 'الفوائد المنهجية والتدوينات السريعة المسجلة أثناء القراءة.',
    children: [],
  };

  if (memos.length > 0) {
    memos.forEach((item, index) => {
      const memoId = `memo-${index + 1}`;
      memosCluster.children?.push({
        id: memoId,
        title: item.text.length > 40 ? `${item.text.slice(0, 38)}...` : item.text,
        level: 2,
        color: '#10b981',
        badge: 'مذكرة ذهبية',
        notes: item.text,
      });
    });
  } else {
    memosCluster.children = [
      {
        id: 'memo-def-1',
        title: 'نقاط ارتكاز الاختبار والمراجعة',
        level: 2,
        color: '#10b981',
        badge: 'تنبيه',
        notes: 'التركيز على الأسئلة الشائعة وتطبيقات المادة.',
      },
      {
        id: 'memo-def-2',
        title: 'الروابط البينية بين الفصول',
        level: 2,
        color: '#10b981',
        badge: 'ربط',
        notes: 'كيف تتكامل المفاهيم النظرية مع النماذج التطبيقية.',
      },
    ];
  }

  // 4. Group Sources and Documents into knowledge reference branches
  const sourcesCluster: MindMapNode = {
    id: 'cluster-sources',
    title: 'المصادر والوثائق المعتمدة (Sources & Evidence)',
    level: 1,
    color: '#d97706', // Amber
    badge: `${sources.length} مصدر`,
    notes: 'الأصول المعرفية والمراجع الأكاديمية المدخلة في هذا الدفتر.',
    children: [],
  };

  if (sources.length > 0) {
    sources.forEach((src, idx) => {
      const srcNodeId = `source-branch-${idx + 1}`;
      const srcChunks = chunks.filter((c) => c.sourceId === src.id).slice(0, 3);
      const relatedTerms: string[] = [];

      // Detect term cross-links in source title or chunks
      termsCluster.children?.forEach((tNode) => {
        if (
          src.title.toLowerCase().includes(tNode.title.toLowerCase()) ||
          srcChunks.some((c) => c.text.toLowerCase().includes(tNode.title.toLowerCase()))
        ) {
          relatedTerms.push(tNode.id);
          crossLinks.push({
            sourceId: srcNodeId,
            targetId: tNode.id,
            label: 'شاهد من المصدر',
          });
        }
      });

      sourcesCluster.children?.push({
        id: srcNodeId,
        title: src.title.length > 38 ? `${src.title.slice(0, 36)}...` : src.title,
        level: 2,
        color: '#d97706',
        badge: src.type.toUpperCase(),
        notes: `مصدر معتمد: ${src.title}\nنوع الملف: ${src.type}\nعدد المقاطع المفهرسة: ${srcChunks.length}`,
        relatedNodeIds: relatedTerms.length > 0 ? relatedTerms : undefined,
        relationLabel: relatedTerms.length > 0 ? 'يوثق مفاهيم أساسية' : undefined,
        children: srcChunks.map((c, cIdx) => ({
          id: `chunk-sub-${idx + 1}-${cIdx + 1}`,
          title: c.text.slice(0, 32) + '...',
          level: 3,
          color: '#d97706',
          badge: `فقرة ${cIdx + 1}`,
          notes: c.text,
        })),
      });
    });
  } else {
    sourcesCluster.children = [
      {
        id: 'src-def-1',
        title: 'المرجع التأسيسي والوثائق المنهجية',
        level: 2,
        color: '#d97706',
        badge: 'مرجع',
        notes: 'المتون والكتب المقررة وأوراق العمل.',
      },
    ];
  }

  // 5. Group Laws & Analytical Relationships
  const relationshipsCluster: MindMapNode = {
    id: 'cluster-laws',
    title: 'العلاقات الرياضية والقوانين والنماذج',
    level: 1,
    color: '#9333ea', // Purple
    badge: 'علاقات وقوانين',
    notes: 'الصيغ التحليلية والنماذج الرياضية المستخرجة.',
    children: [
      {
        id: 'law-1',
        title: 'قانون التكافؤ والارتباط السببي',
        level: 2,
        color: '#9333ea',
        badge: 'قاعدة أساسية',
        formula: 'E = m \\cdot c^2',
        notes: 'صيغة تكافؤ الكتلة والطاقة والعلاقة النسبية في النظم الفيزيائية.',
      },
      {
        id: 'law-2',
        title: 'معادلة الاتزان الديناميكي والنسب',
        level: 2,
        color: '#9333ea',
        badge: 'اتزان نسبي',
        formula: 'K_c = \\frac{[C]^c \\cdot [D]^d}{[A]^a \\cdot [B]^b}',
        notes: 'قانون فعل الكتلة للاتزان والترابط بين المدخلات والمخرجات.',
      },
    ],
  };

  // If user already had custom branches in existingData, merge them intelligently
  const customBranches: MindMapNode[] = [];
  if (existingData && existingData.children) {
    existingData.children.forEach((b) => {
      if (
        b.id !== 'cluster-terms' &&
        b.id !== 'cluster-notes' &&
        b.id !== 'cluster-memos' &&
        b.id !== 'cluster-sources' &&
        b.id !== 'cluster-laws'
      ) {
        customBranches.push(b);
      }
    });
  }

  const rootNode: MindMapNode = {
    id: 'root-notebook-mindmap',
    title: rootTitle,
    level: 0,
    color: rootColor,
    badge: notebookSubject || 'موضوع رئيسي',
    notes: `خريطة ذهنية تجميعية متكاملة لدفتر «${notebookTitle}». تم توليدها تلقائياً بالاعتماد على المصادر، الملاحظات، والمصطلحات لربط المفاهيم واستعراض العلاقات بوضوح عبر مكتبة D3.`,
    children: [
      termsCluster,
      notesCluster,
      memosCluster,
      sourcesCluster,
      relationshipsCluster,
      ...customBranches,
    ],
  };

  return {
    root: rootNode,
    termCount: termsCluster.children?.length || 0,
    memoCount: memosCluster.children?.length || 0,
    notesCount: notesCluster.children?.length || 0,
    sourcesCount: sourcesCluster.children?.length || 0,
    clustersCount: rootNode.children?.length || 5,
    crossLinks,
  };
}
