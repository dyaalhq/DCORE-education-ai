export class CalculatorEngine {
  private memory = 0;
  private lastAns = 0;
  private isDegree = true;

  setDegreeMode(deg: boolean) {
    this.isDegree = deg;
  }

  getDegreeMode(): boolean {
    return this.isDegree;
  }

  getMemory(): number {
    return this.memory;
  }

  setMemory(val: number) {
    this.memory = val;
  }

  getAns(): number {
    return this.lastAns;
  }

  setAns(val: number) {
    this.lastAns = val;
  }

  tokenize(input: string): string[] {
    const s = input
      .replace(/×/g, '*')
      .replace(/÷/g, '/')
      .replace(/−/g, '-')
      .replace(/π/g, 'pi')
      .replace(/√/g, 'sqrt')
      .replace(/\s+/g, '');

    const tokens: string[] = [];
    let i = 0;

    while (i < s.length) {
      const ch = s[i];

      // Numbers
      if (/[0-9.]/.test(ch)) {
        let num = '';
        while (i < s.length && /[0-9.]/.test(s[i])) {
          num += s[i++];
        }
        tokens.push(num);
        continue;
      }

      // Word identifiers / functions
      if (/[a-zA-Z]/.test(ch)) {
        let word = '';
        while (i < s.length && /[a-zA-Z0-9]/.test(s[i])) {
          word += s[i++];
        }
        tokens.push(word.toLowerCase());
        continue;
      }

      // Operators
      if ('+-*/%^(),!'.includes(ch)) {
        tokens.push(ch);
        i++;
        continue;
      }

      throw new Error(`رمز غير مدعوم: ${ch}`);
    }

    return tokens;
  }

  evaluate(expr: string): number {
    if (!expr.trim()) return 0;
    const tokens = this.tokenize(expr);
    let index = 0;

    const peek = () => tokens[index];
    const consume = () => tokens[index++];

    const parsePrimary = (): number => {
      const token = consume();
      if (!token) throw new Error('تعبير غير مكتمل');

      if (!isNaN(Number(token))) {
        return Number(token);
      }

      if (token === 'pi') return Math.PI;
      if (token === 'e') return Math.E;
      if (token === 'ans') return this.lastAns;

      // Function calls: sin, cos, tan, sqrt, etc.
      const functions = ['sin', 'cos', 'tan', 'asin', 'acos', 'atan', 'sqrt', 'log', 'ln', 'abs'];
      if (functions.includes(token)) {
        if (consume() !== '(') throw new Error(`توقع '(' بعد الدالة ${token}`);
        const arg = parseExpression();
        if (consume() !== ')') throw new Error(`توقع ')' لإغلاق الدالة ${token}`);

        const rad = this.isDegree ? (arg * Math.PI) / 180 : arg;

        switch (token) {
          case 'sin': return Math.sin(rad);
          case 'cos': return Math.cos(rad);
          case 'tan': {
            if (Math.abs(Math.cos(rad)) < 1e-12) throw new Error('tan غير معرفة لهذه الزاوية');
            return Math.tan(rad);
          }
          case 'asin': {
            if (arg < -1 || arg > 1) throw new Error('asin خارج نطاق [-1, 1]');
            const res = Math.asin(arg);
            return this.isDegree ? (res * 180) / Math.PI : res;
          }
          case 'acos': {
            if (arg < -1 || arg > 1) throw new Error('acos خارج نطاق [-1, 1]');
            const res = Math.acos(arg);
            return this.isDegree ? (res * 180) / Math.PI : res;
          }
          case 'atan': {
            const res = Math.atan(arg);
            return this.isDegree ? (res * 180) / Math.PI : res;
          }
          case 'sqrt': {
            if (arg < 0) throw new Error('الجذر التربيعي لا يقبل عددًا سالبًا');
            return Math.sqrt(arg);
          }
          case 'log': {
            if (arg <= 0) throw new Error('log يحتاج عددًا موجبًا');
            return Math.log10(arg);
          }
          case 'ln': {
            if (arg <= 0) throw new Error('ln يحتاج عددًا موجبًا');
            return Math.log(arg);
          }
          case 'abs': return Math.abs(arg);
        }
      }

      if (token === '(') {
        const val = parseExpression();
        if (consume() !== ')') throw new Error("توقع ')'");
        return val;
      }

      if (token === '-') {
        return -parsePrimary();
      }

      if (token === '+') {
        return parsePrimary();
      }

      throw new Error(`عنصر غير متوقع: ${token}`);
    };

    const parsePostfix = (): number => {
      let val = parsePrimary();
      while (peek() === '!' || peek() === '%') {
        const op = consume();
        if (op === '!') {
          if (val < 0 || Math.floor(val) !== val || val > 150) {
            throw new Error('العامل ! يتطلب عددًا صحيحًا موجبًا أصغر من 150');
          }
          let fact = 1;
          for (let i = 2; i <= val; i++) fact *= i;
          val = fact;
        } else if (op === '%') {
          val = val / 100;
        }
      }
      return val;
    };

    const parsePower = (): number => {
      let val = parsePostfix();
      if (peek() === '^') {
        consume();
        const exp = parsePower();
        val = Math.pow(val, exp);
      }
      return val;
    };

    const parseFactor = (): number => {
      let val = parsePower();
      while (peek() === '*' || peek() === '/') {
        const op = consume();
        const next = parsePower();
        if (op === '*') val *= next;
        if (op === '/') {
          if (next === 0) throw new Error('لا يمكن القسمة على صفر');
          val /= next;
        }
      }
      return val;
    };

    const parseExpression = (): number => {
      let val = parseFactor();
      while (peek() === '+' || peek() === '-') {
        const op = consume();
        const next = parseFactor();
        if (op === '+') val += next;
        if (op === '-') val -= next;
      }
      return val;
    };

    const result = parseExpression();
    if (index < tokens.length) {
      throw new Error(`تعبير غير صالح بالقرب من '${tokens[index]}'`);
    }

    if (!Number.isFinite(result)) {
      throw new Error('النتيجة خارج النطاق الرياضي');
    }

    this.lastAns = result;
    return result;
  }
}
