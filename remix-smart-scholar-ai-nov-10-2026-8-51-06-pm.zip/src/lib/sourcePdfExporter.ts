/**
 * Export Source to PDF using jsPDF
 * Formats academic sources with metadata, page numbers, and clean layout
 */
import { jsPDF } from 'jspdf';
import { Source } from '../types';

export function exportSourceToPdf(source: Source, notebookName?: string): void {
  try {
    const doc = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
    });

    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    const margin = 18;
    const contentWidth = pageWidth - margin * 2;
    let yPos = margin;

    // Header banner
    doc.setFillColor(15, 118, 110); // Teal 700
    doc.roundedRect(margin, yPos, contentWidth, 24, 3, 3, 'F');

    doc.setTextColor(255, 255, 255);
    doc.setFontSize(14);
    doc.text('Smart Scholar AI - وثيقة مرجعية أكاديمية', pageWidth / 2, yPos + 10, { align: 'center' });
    
    doc.setFontSize(10);
    const subtitle = notebookName ? `الدفتر: ${notebookName} | النوع: ${source.type}` : `النوع: ${source.type}`;
    doc.text(subtitle, pageWidth / 2, yPos + 18, { align: 'center' });

    yPos += 32;

    // Source Title
    doc.setTextColor(23, 32, 30);
    doc.setFontSize(16);
    const titleLines = doc.splitTextToSize(source.title, contentWidth);
    doc.text(titleLines, pageWidth / 2, yPos, { align: 'center' });
    yPos += titleLines.length * 7 + 4;

    // Metadata bar
    doc.setFillColor(243, 244, 246);
    doc.roundedRect(margin, yPos, contentWidth, 14, 2, 2, 'F');
    doc.setFontSize(8);
    doc.setTextColor(80, 90, 85);

    const dateStr = new Date(source.createdAt || Date.now()).toLocaleDateString('ar-EG');
    const wordCountStr = `عدد الكلمات: ${source.wordCount || source.content.split(/\s+/).length}`;
    const uriStr = source.uri ? `المصدر: ${source.uri.slice(0, 45)}...` : '';
    
    doc.text(`تاريخ الإضافة: ${dateStr}  |  ${wordCountStr}  ${uriStr ? ` |  ${uriStr}` : ''}`, margin + 4, yPos + 9);
    yPos += 20;

    // Source Content Body
    doc.setFontSize(10);
    doc.setTextColor(30, 40, 36);

    const rawContent = source.content || 'لا يوجد محتوى نصي لهذا المرجع.';
    const paragraphs = rawContent.split('\n');

    for (let p of paragraphs) {
      const trimmed = p.trim();
      if (!trimmed) {
        yPos += 4;
        continue;
      }

      // Check if heading
      if (trimmed.startsWith('#')) {
        const headingText = trimmed.replace(/^#+\s*/, '');
        doc.setFontSize(12);
        doc.setTextColor(15, 118, 110);
        const hLines = doc.splitTextToSize(headingText, contentWidth);
        
        if (yPos + hLines.length * 6 > pageHeight - margin) {
          doc.addPage();
          yPos = margin + 5;
        }
        
        doc.text(hLines, margin, yPos);
        yPos += hLines.length * 6 + 2;
        doc.setFontSize(10);
        doc.setTextColor(30, 40, 36);
        continue;
      }

      const splitLines = doc.splitTextToSize(trimmed, contentWidth);

      if (yPos + splitLines.length * 5.5 > pageHeight - margin) {
        doc.addPage();
        yPos = margin + 5;
      }

      doc.text(splitLines, margin, yPos);
      yPos += splitLines.length * 5.5 + 2;
    }

    // Add page numbers to all pages
    const pageCount = (doc.internal as any).getNumberOfPages();
    for (let i = 1; i <= pageCount; i++) {
      doc.setPage(i);
      doc.setFontSize(8);
      doc.setTextColor(140, 150, 145);
      doc.text(
        `Developed by Dhiyaa Al-Haq Subayqaa & The D.CORE Academic Team | صفحة ${i} من ${pageCount}`,
        pageWidth / 2,
        pageHeight - 8,
        { align: 'center' }
      );
    }

    // Download PDF
    const safeTitle = (source.title || 'source')
      .replace(/[^\w\u0600-\u06FF\s-]/g, '')
      .trim()
      .slice(0, 40);
    doc.save(`${safeTitle || 'source'}.pdf`);
  } catch (err) {
    console.error('Failed to export source to PDF via jsPDF:', err);
    throw err;
  }
}
