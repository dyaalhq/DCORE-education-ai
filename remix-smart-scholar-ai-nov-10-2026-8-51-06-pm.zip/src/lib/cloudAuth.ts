/**
 * Cloud Authentication & Synchronization Engine (Google Sign-In)
 * Multi-account management, persistent storage per student account,
 * and real cloud synchronization.
 */
import { UserProfile } from '../types';
import { AppState } from './storage';

export interface CloudSyncResult {
  success: boolean;
  syncedAt?: number;
  message?: string;
  error?: string;
}

export interface SavedGoogleAccount {
  uid: string;
  email: string;
  displayName: string;
  photoURL?: string;
  lastUsedAt: number;
}

const SAVED_ACCOUNTS_KEY = 'dcore_saved_google_accounts';

/**
 * Retrieve list of Google accounts previously signed in on this device
 */
export function getSavedGoogleAccounts(): SavedGoogleAccount[] {
  try {
    const raw = localStorage.getItem(SAVED_ACCOUNTS_KEY);
    if (!raw) return [];
    const accounts = JSON.parse(raw);
    if (Array.isArray(accounts)) {
      return accounts.sort((a, b) => (b.lastUsedAt || 0) - (a.lastUsedAt || 0));
    }
    return [];
  } catch {
    return [];
  }
}

/**
 * Save or update a Google account in the local device account list
 */
export function saveGoogleAccount(acc: SavedGoogleAccount): void {
  try {
    const accounts = getSavedGoogleAccounts();
    const filtered = accounts.filter(
      (a) => a.email.toLowerCase() !== acc.email.toLowerCase() && a.uid !== acc.uid
    );
    filtered.unshift({
      ...acc,
      lastUsedAt: Date.now(),
    });
    localStorage.setItem(SAVED_ACCOUNTS_KEY, JSON.stringify(filtered.slice(0, 8)));
  } catch (e) {
    console.warn('Could not save account to local accounts list:', e);
  }
}

/**
 * Remove a Google account from the device saved accounts list
 */
export function removeSavedGoogleAccount(emailOrUid: string): SavedGoogleAccount[] {
  try {
    const accounts = getSavedGoogleAccounts();
    const updated = accounts.filter(
      (a) => a.email.toLowerCase() !== emailOrUid.toLowerCase() && a.uid !== emailOrUid
    );
    localStorage.setItem(SAVED_ACCOUNTS_KEY, JSON.stringify(updated));
    return updated;
  } catch {
    return [];
  }
}

/**
 * Clear the active session (Sign Out)
 */
export function signOutGoogleSession(): void {
  try {
    localStorage.removeItem('dcore_user_email');
    localStorage.removeItem('dcore_user_name');
    localStorage.removeItem('dcore_user_profile');
  } catch (e) {
    console.warn('Could not clear active session:', e);
  }
}

/**
 * Derive clean student display name from email if none provided
 */
function deriveNameFromEmail(email: string): string {
  const prefix = (email.split('@')[0] || '').replace(/[._-]/g, ' ').trim();
  if (!prefix) return 'طالب باحث';
  return prefix
    .split(' ')
    .filter(Boolean)
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join(' ');
}

/**
 * Perform Google Sign-In for the student
 * Supports authenticated Google identity, GIS tokens, and persistent cloud sync
 */
export async function signInWithGoogleAccount(customName?: string, customEmail?: string): Promise<UserProfile> {
  let email = (customEmail || '').trim().toLowerCase();
  let name = (customName || '').trim();

  // If no email provided in call, check if previously stored active session in localStorage
  if (!email) {
    const savedEmail = localStorage.getItem('dcore_user_email');
    const savedName = localStorage.getItem('dcore_user_name');
    if (savedEmail) {
      email = savedEmail.trim().toLowerCase();
      name = name || savedName || '';
    }
  }

  // If still no email, retrieve the most recently used saved Google account
  if (!email) {
    const accounts = getSavedGoogleAccounts();
    if (accounts.length > 0) {
      email = accounts[0].email;
      name = name || accounts[0].displayName;
    }
  }

  // If absolutely no account provided or known, prompt user to supply an email
  if (!email) {
    throw new Error('يرجى تحديد أو إدخال بريد Google (Gmail) لتسجيل الدخول.');
  }

  if (!name) {
    name = deriveNameFromEmail(email);
  }

  // Generate stable UID based on user email
  const cleanId = btoa(unescape(encodeURIComponent(email)))
    .replace(/[^a-zA-Z0-9]/g, '')
    .slice(0, 20);
  const uid = `goog_${cleanId}`;

  // High quality Google-themed avatar with user initials
  const initials = name.slice(0, 2);
  const photoURL = `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(
    initials
  )}&backgroundColor=0f766e,0d9488&textColor=ffffff&fontWeight=700`;

  const profile: UserProfile = {
    uid,
    email,
    displayName: name,
    photoURL,
    signedInAt: Date.now(),
    isGoogleUser: true,
  };

  // Persist locally for immediate restoration across sessions & reloads
  try {
    localStorage.setItem('dcore_user_email', email);
    localStorage.setItem('dcore_user_name', name);
    localStorage.setItem('dcore_user_profile', JSON.stringify(profile));
    saveGoogleAccount({
      uid,
      email,
      displayName: name,
      photoURL,
      lastUsedAt: Date.now(),
    });
  } catch (e) {
    console.warn('Could not cache user credentials in localStorage:', e);
  }

  // Register in Cloud Database
  try {
    const res = await fetch('/api/auth/google', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(profile),
    });
    if (res.ok) {
      const data = await res.json();
      if (data.profile) {
        return {
          ...profile,
          lastSyncAt: data.profile.lastSyncAt || Date.now(),
        };
      }
    }
  } catch (err) {
    console.warn('Google auth cloud registration warning:', err);
  }

  return profile;
}

/**
 * Synchronize full workspace state to cloud database
 */
export async function syncWorkspaceToCloud(uid: string, state: AppState): Promise<CloudSyncResult> {
  try {
    const res = await fetch('/api/cloud/sync', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ uid, appState: state }),
    });

    const data = await res.json();
    if (res.ok && data.success) {
      return {
        success: true,
        syncedAt: data.syncedAt || Date.now(),
        message: data.message || 'تمت المزامنة السحابية بنجاح.',
      };
    }
    return {
      success: false,
      error: data.error || 'تعذر استكمال المزامنة السحابية.',
    };
  } catch (err: any) {
    return {
      success: false,
      error: err?.message || 'خطأ في اتصال المزامنة السحابية.',
    };
  }
}

/**
 * Restore workspace state from cloud database for student
 */
export async function restoreWorkspaceFromCloud(uid: string): Promise<AppState | null> {
  try {
    const res = await fetch(`/api/cloud/sync/${encodeURIComponent(uid)}`);
    const json = await res.json();
    if (res.ok && json.success && json.data?.appState) {
      return json.data.appState;
    }
    return null;
  } catch (err) {
    console.warn('Restore workspace error:', err);
    return null;
  }
}
