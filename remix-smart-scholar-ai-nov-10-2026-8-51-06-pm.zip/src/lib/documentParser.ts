import { SourceChunk, ChunkMetadata } from '../types';
import { normalizeArabicWord, tokenize } from './retrieval';

// Stopwords in Arabic and English to exclude from keyword extraction
const STOPWORDS = new Set([
  'في', 'من', 'على', 'إلى', 'عن', 'مع', 'هذا', 'هذه', 'تم', 'كان', 'كانت', 'يكون',
  'أن', 'إن', 'التي', 'الذي', 'الذين', 'اللاتي', 'كل', 'ذلك', 'تلك', 'قد', 'لا', 'ما',
  'لم', 'لن', 'ثم', 'أو', 'أم', 'بل', 'لكن', 'حيث', 'بين', 'خلال', 'نحو', 'غير', 'كما',
  'وهو', 'وهي', 'هو', 'هي', 'هم', 'نحن', 'أنا', 'أنتم', 'هنا', 'هناك', 'عند', 'بعد', 'قبل',
  'the', 'is', 'at', 'which', 'on', 'and', 'a', 'an', 'in', 'to', 'for', 'of', 'with', 'as',
]);

export interface ChunkingOptions {
  targetChunkSize?: number; // target character count ~1000-1400 (approx 200-280 words)
  minChunkSize?: number; // minimum characters before finalizing (default 220)
  overlapSentences?: number; // number of full sentences to overlap (default 1 or 2 sentences)
  overlapSize?: number; // backwards compatibility
  sourceType?: string;
}

// Regex patterns for academic headings and structure
const HEADING_PATTERNS = [
  /^(#{1,6})\s+(.+)$/m, // Markdown headings: # Title
  /^(الفصل\s+[^\n:.]+[:.]?)/im, // Chapter
  /^(الوحدة\s+[^\n:.]+[:.]?)/im, // Unit
  /^(الباب\s+[^\n:.]+[:.]?)/im, // Part/Gate
  /^(المبحث\s+[^\n:.]+[:.]?)/im, // Sub-chapter
  /^(المطلب\s+[^\n:.]+[:.]?)/im, // Topic
  /^(الدرس\s+[^\n:.]+[:.]?)/im, // Lesson
  /^(المحور\s+[^\n:.]+[:.]?)/im, // Axis
  /^(القانون\s+[^\n:.]+[:.]?)/im, // Scientific Law
  /^(النظرية\s+[^\n:.]+[:.]?)/im, // Theorem
  /^(المقدمة|الخاتمة|ملخص الدرس|أهداف التعلم|نتائج التجربة)/im,
];

/**
 * Common abbreviations in Arabic and English that shouldn't trigger sentence splitting
 */
const ABBREVIATIONS = new Set([
  'د.', 'أ.', 'م.', 'ص.', 'ج.', 'ق.', 'هـ.', 'مـ.', 'ش.',
  'dr.', 'prof.', 'mr.', 'mrs.', 'ms.', 'e.g.', 'i.e.', 'etc.', 'vs.', 'fig.', 'al.',
]);

/**
 * Robust Sentence Boundary Detector for Academic and Scientific Arabic & English texts
 * Preserves complete sentences without cutting words or formulas in half
 */
export function splitIntoSentences(text: string): string[] {
  if (!text || !text.trim()) return [];

  // Protect LaTeX formulas and chemical formulas from being split
  const mathPlaceholders: string[] = [];
  let protectedText = text.replace(/(\$\$[\s\S]*?\$\$|\$[^\$\n]+\$|\\\[[\s\S]*?\\\]|\\\([\s\S]*?\\\))/g, (m) => {
    const placeholder = `__MATH_BLOCK_${mathPlaceholders.length}__`;
    mathPlaceholders.push(m);
    return placeholder;
  });

  // Protect common abbreviation dots e.g. "د." -> "د_DOT_"
  protectedText = protectedText.replace(/(?:^|\s)([\u0600-\u06FFa-zA-Z]{1,4})\.(?=\s)/g, (full, abbr) => {
    const lower = `${abbr.toLowerCase()}.`;
    if (ABBREVIATIONS.has(lower) || ABBREVIATIONS.has(`${abbr}.`)) {
      return full.replace('.', '_DOT_');
    }
    return full;
  });

  // Protect decimal numbers like 3.14 or 1.5
  protectedText = protectedText.replace(/(\d+)\.(\d+)/g, '$1_DECIMAL_$2');

  // Protect numbered lists like "1." or "2." at start of line
  protectedText = protectedText.replace(/(^|\n)(\d+)\.\s+/g, '$1$2_NUMDOT_ ');

  // Sentence split boundaries:
  // Split on [.!?؟؛;] followed by whitespace or line breaks
  const rawSegments = protectedText.split(/(?<=[.!?؟؛;\n])\s+/);

  const sentences: string[] = [];
  for (let segment of rawSegments) {
    let restored = segment
      .replace(/_DOT_/g, '.')
      .replace(/_DECIMAL_/g, '.')
      .replace(/_NUMDOT_/g, '.')
      .trim();

    // Restore math formulas
    if (mathPlaceholders.length > 0) {
      restored = restored.replace(/__MATH_BLOCK_(\d+)__/g, (_, idx) => mathPlaceholders[parseInt(idx, 10)] || '');
    }

    if (restored) {
      sentences.push(restored);
    }
  }

  return sentences;
}

/**
 * Extract salient academic keywords from text using normalized frequency
 */
export function extractKeywords(text: string, topK = 6): string[] {
  if (!text) return [];
  const tokens = tokenize(text);
  const freqMap = new Map<string, number>();

  for (const t of tokens) {
    const norm = normalizeArabicWord(t);
    if (norm.length > 2 && !STOPWORDS.has(norm) && !STOPWORDS.has(t)) {
      freqMap.set(norm, (freqMap.get(norm) || 0) + 1);
    }
  }

  return Array.from(freqMap.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, topK)
    .map(([w]) => w);
}

/**
 * Check if a line is a title or structural heading
 */
export function detectHeading(line: string): { isHeading: boolean; title?: string; level?: number } {
  const trimmed = line.trim();
  if (!trimmed || trimmed.length > 120) return { isHeading: false };

  // 1. Markdown syntax (# Heading)
  const mdMatch = trimmed.match(/^(#{1,6})\s+(.+)$/);
  if (mdMatch) {
    return {
      isHeading: true,
      title: mdMatch[2].trim(),
      level: mdMatch[1].length,
    };
  }

  // 2. Arabic academic markers at the start of line
  for (const pattern of HEADING_PATTERNS) {
    if (pattern.test(trimmed)) {
      return {
        isHeading: true,
        title: trimmed,
        level: 2,
      };
    }
  }

  // 3. Short standalone capitalized or numbered headings
  if (trimmed.length < 50 && (trimmed.endsWith(':') || !trimmed.startsWith('•'))) {
    if (/^(أولاً|ثانياً|ثالثاً|رابعاً|خامساً|سادساً|سابعاً|ثامناً|تاسعاً|عاشراً)/.test(trimmed)) {
      return { isHeading: true, title: trimmed, level: 3 };
    }
  }

  return { isHeading: false };
}

/**
 * Advanced Semantic Chunking Engine (Sentence & Structural Boundary Based)
 * - Guarantees zero cut-in-the-middle sentences
 * - Segments based on natural paragraph and sentence units
 * - Preserves structural context (Headings, Units, Chapters, and Page numbers)
 * - Overlaps using complete sentences rather than crude character slices
 */
export function parseAndChunkDocument(
  fullText: string,
  sourceId: string,
  sourceTitle: string,
  notebookId: string,
  options: ChunkingOptions = {}
): SourceChunk[] {
  const targetSize = options.targetChunkSize || 1200;
  const minSize = options.minChunkSize || 220;
  const overlapSentenceCount = options.overlapSentences ?? 2;

  const clean = fullText.replace(/\r/g, '').trim();
  if (!clean) return [];

  const chunks: SourceChunk[] = [];

  // Track heading hierarchy as document unfolds
  let currentSection = sourceTitle;
  const headingStack: string[] = [sourceTitle];

  // Split into raw paragraphs while tracking page boundary markers
  const rawParagraphs = clean.split(/\n\s*\n/);
  let globalOffset = 0;
  let chunkIdx = 1;
  let currentPageNumber: number | null = null;

  // Active accumulator of complete sentences for current chunk
  let currentSentences: string[] = [];
  let currentSentencesLength = 0;
  let chunkStartOffset = 0;
  let currentParagraphIdx = 0;

  const flushChunk = (isSectionBoundary = false) => {
    if (currentSentences.length === 0) return;

    const chunkTextContent = currentSentences.join(' ').trim();
    if (chunkTextContent.length >= minSize || chunks.length === 0 || isSectionBoundary) {
      const hasMath = /[$]|\\frac|\\sqrt|\\sum|\\int|\\alpha|\\beta|\\Delta|\\ce\{/.test(chunkTextContent);
      const hasTable = /\|.+\|.+\|/.test(chunkTextContent);

      const metadata: ChunkMetadata = {
        paragraphIndex: currentParagraphIdx,
        sectionTitle: currentSection,
        headingHierarchy: [...headingStack],
        charOffset: chunkStartOffset,
        charLength: chunkTextContent.length,
        tokenEstimate: Math.round(chunkTextContent.length / 3.8),
        keywords: extractKeywords(chunkTextContent, 6),
        topics: headingStack.slice(-2),
        sourceType: options.sourceType || 'document',
        hasMath,
        hasTable,
      };

      chunks.push({
        id: `${sourceId}_chunk_${chunkIdx++}`,
        sourceId,
        sourceTitle,
        notebookId,
        text: chunkTextContent,
        pageNumber: currentPageNumber,
        section: currentSection,
        offset: chunkStartOffset,
        metadata,
      });

      // Semantic sentence overlap:
      // Carry over the last N complete sentences to give seamless context to the next chunk
      if (!isSectionBoundary && overlapSentenceCount > 0 && currentSentences.length > overlapSentenceCount) {
        const overlapSentences = currentSentences.slice(-overlapSentenceCount);
        currentSentences = [...overlapSentences];
        currentSentencesLength = overlapSentences.reduce((acc, s) => acc + s.length + 1, 0);
        chunkStartOffset += chunkTextContent.length - currentSentencesLength;
      } else {
        currentSentences = [];
        currentSentencesLength = 0;
      }
    }
  };

  for (let pIdx = 0; pIdx < rawParagraphs.length; pIdx++) {
    const rawP = rawParagraphs[pIdx].trim();
    if (!rawP) continue;

    // Detect page boundary tags e.g. [الصفحة 3] or Page 3
    const pageMatch = rawP.match(/\[(?:الصفحة|Page)\s+(\d+)\]/i);
    if (pageMatch) {
      currentPageNumber = parseInt(pageMatch[1], 10);
    }

    // Detect structural Headings
    const headingCheck = detectHeading(rawP);
    if (headingCheck.isHeading && headingCheck.title) {
      // Flush previous chunk before starting new major semantic chapter/heading
      if (currentSentencesLength >= minSize) {
        flushChunk(true);
      }

      currentSection = headingCheck.title;
      if (headingCheck.level && headingCheck.level <= 2) {
        headingStack.splice(1);
        headingStack.push(headingCheck.title);
      } else {
        if (headingStack.length > 3) headingStack.pop();
        headingStack.push(headingCheck.title);
      }
    }

    // Segment paragraph into complete sentences
    const paragraphSentences = splitIntoSentences(rawP);

    for (const sentence of paragraphSentences) {
      const cleanSentence = sentence.trim();
      if (!cleanSentence) continue;

      if (currentSentences.length === 0) {
        chunkStartOffset = globalOffset;
        currentParagraphIdx = pIdx + 1;
      }

      // Check if adding this complete sentence exceeds the target size
      if (currentSentencesLength + cleanSentence.length > targetSize && currentSentencesLength >= minSize) {
        flushChunk(false);
        if (currentSentences.length === 0) {
          chunkStartOffset = globalOffset;
          currentParagraphIdx = pIdx + 1;
        }
      }

      currentSentences.push(cleanSentence);
      currentSentencesLength += cleanSentence.length + 1;
    }

    globalOffset += rawP.length + 2;
  }

  // Flush remaining sentences
  if (currentSentences.length > 0) {
    flushChunk(true);
  }

  return chunks;
}

/**
 * Backwards-compatible drop-in replacement for chunkText
 */
export function chunkText(
  text: string,
  sourceId: string,
  sourceTitle: string,
  notebookId: string,
  chunkSize = 750,
  overlap = 75
): SourceChunk[] {
  return parseAndChunkDocument(text, sourceId, sourceTitle, notebookId, {
    targetChunkSize: chunkSize,
    minChunkSize: 180,
    overlapSize: overlap,
    overlapSentences: 1,
  });
}

/**
 * Match a highlighted text snippet to its exact corresponding SourceChunk in the database
 */
export function findMatchingChunk(
  chunks: SourceChunk[],
  selectedText: string,
  pageNumber?: number | null
): SourceChunk | undefined {
  if (!chunks || chunks.length === 0 || !selectedText.trim()) return undefined;

  const cleanQuery = selectedText.trim().toLowerCase();

  // 1. Direct page + exact text match
  if (pageNumber) {
    const pageChunks = chunks.filter((c) => c.pageNumber === pageNumber);
    const directPageMatch = pageChunks.find((c) => c.text.toLowerCase().includes(cleanQuery));
    if (directPageMatch) return directPageMatch;
  }

  // 2. Exact match across all chunks
  const directMatch = chunks.find((c) => c.text.toLowerCase().includes(cleanQuery));
  if (directMatch) return directMatch;

  // 3. Substring / significant slice match (first 40 characters)
  const sample = cleanQuery.slice(0, Math.min(40, cleanQuery.length));
  if (sample.length >= 10) {
    const sampleMatch = chunks.find((c) => c.text.toLowerCase().includes(sample));
    if (sampleMatch) return sampleMatch;
  }

  // 4. Token overlap match
  const selTokens = tokenize(selectedText);
  if (selTokens.length === 0) return undefined;

  let bestChunk: SourceChunk | undefined;
  let bestScore = 0;

  for (const chunk of chunks) {
    if (pageNumber && chunk.pageNumber && chunk.pageNumber !== pageNumber) continue;
    const chunkTokens = new Set(tokenize(chunk.text));
    let matches = 0;
    for (const t of selTokens) {
      if (chunkTokens.has(t)) matches++;
    }
    const score = matches / selTokens.length;
    if (score > bestScore && score >= 0.4) {
      bestScore = score;
      bestChunk = chunk;
    }
  }

  return bestChunk;
}
