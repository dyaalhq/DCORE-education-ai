// Universal AI Bridge for Study Studio & Dual Mind Maps
// Seamlessly works across both hosted server environments and standalone single-file builds
// Connects 100% dynamically to Google Gemini with automatic multi-key rotation and zero fluff

import { getApiUrl, isStandaloneApp } from './apiConfig';
import { callDirectGeminiWithKeyRotation } from './clientGeminiService';
import { Source, NoteItem, MemoItem, GlossaryItem, QuizQuestion, Flashcard, MindMapNode, StudyPlan } from '../types';

export interface StudioContext {
  notebookId?: string;
  notebookTitle: string;
  notebookSubject: string;
  sources?: Source[];
  notes?: NoteItem[];
  memos?: MemoItem[];
  glossary?: GlossaryItem[];
  fallbackConfig?: any;
}

/**
 * Robust Multi-Pass JSON Parser with automatic markdown fence stripping,
 * quote repair, and balance checks to ensure 0 rendering bugs.
 */
export function robustParseJson<T = any>(rawText: string, fallbackValue?: T): T {
  if (!rawText || typeof rawText !== 'string') {
    return fallbackValue as T;
  }

  const cleaned = rawText.trim();

  // Pass 1: Direct JSON parse
  try {
    return JSON.parse(cleaned);
  } catch {}

  // Pass 2: Extract from ```json ... ``` code fence
  const codeBlockMatch = cleaned.match(/```(?:json)?\s*([\s\S]*?)\s*```/i);
  if (codeBlockMatch && codeBlockMatch[1]) {
    try {
      return JSON.parse(codeBlockMatch[1].trim());
    } catch {}
  }

  // Pass 3: Extract first balanced { ... } or [ ... ]
  const firstBrace = cleaned.indexOf('{');
  const firstBracket = cleaned.indexOf('[');
  let startIdx = -1;
  let endChar = '';

  if (firstBrace !== -1 && (firstBracket === -1 || firstBrace < firstBracket)) {
    startIdx = firstBrace;
    endChar = '}';
  } else if (firstBracket !== -1) {
    startIdx = firstBracket;
    endChar = ']';
  }

  if (startIdx !== -1) {
    const lastIdx = cleaned.lastIndexOf(endChar);
    if (lastIdx > startIdx) {
      const candidate = cleaned.slice(startIdx, lastIdx + 1);
      try {
        return JSON.parse(candidate);
      } catch {
        // Try fixing trailing commas
        try {
          const sanitized = candidate.replace(/,\s*([\]}])/g, '$1');
          return JSON.parse(sanitized);
        } catch {}
      }
    }
  }

  if (fallbackValue !== undefined) {
    return fallbackValue;
  }

  throw new Error('تعذر معالجة استجابة البيانات المهيكلة من الذكاء الاصطناعي.');
}

/**
 * Universal text generation that routes to hosted backend or direct client-side rotation
 */
export async function executeStudioPrompt(
  prompt: string,
  systemInstruction?: string,
  fallbackConfig?: any
): Promise<string> {
  const isStandalone = isStandaloneApp();

  if (!isStandalone) {
    try {
      const response = await fetch(getApiUrl('/api/chat'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt,
          systemInstruction,
          mode: 'notebook',
          fallbackConfig,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        if (data && data.text && data.text.trim()) {
          return data.text.trim();
        }
      }
    } catch (e) {
      console.warn('Hosted API call failed, falling back to direct key rotation:', e);
    }
  }

  // Standalone or Failover: Direct client-side Gemini with automatic key rotation
  const directResult = await callDirectGeminiWithKeyRotation({
    prompt,
    systemInstruction,
    timeoutMs: 30000,
  });

  return directResult.text.trim();
}

/**
 * Formats full curriculum context from notebook assets
 */
export function buildComprehensiveStudyContext(ctx: StudioContext): string {
  const parts: string[] = [];

  parts.push(`العنوان والمقرر الدراسي: ${ctx.notebookTitle || 'عام'} (${ctx.notebookSubject || 'دراسة عامة'})`);

  if (ctx.sources && ctx.sources.length > 0) {
    const srcText = ctx.sources
      .map((s, i) => {
        const content = (s.content || '').trim();
        return `[المصدر ${i + 1}: ${s.title}]\n${content}`;
      })
      .join('\n\n');
    parts.push(`### المراجع والكتب المعتمدة:\n${srcText}`);
  }

  if (ctx.glossary && ctx.glossary.length > 0) {
    const glossText = ctx.glossary
      .map((g) => `- ${g.term}: ${g.def}${g.ex ? ` (مثال: ${g.ex})` : ''}`)
      .join('\n');
    parts.push(`### مسرد المصطلحات الأساسية:\n${glossText}`);
  }

  if (ctx.notes && ctx.notes.length > 0) {
    const notesText = ctx.notes
      .map((n) => `- ${n.title}: ${n.text}`)
      .join('\n');
    parts.push(`### تدوينات الطالب:\n${notesText}`);
  }

  if (ctx.memos && ctx.memos.length > 0) {
    const memosText = ctx.memos.map((m) => `- ${m.text}`).join('\n');
    parts.push(`### ملاحظات سريعة:\n${memosText}`);
  }

  return parts.join('\n\n');
}

/**
 * 1. AI Deep Academic Summary Generator
 */
export async function generateStudioSummary(ctx: StudioContext): Promise<string> {
  const context = buildComprehensiveStudyContext(ctx);
  const prompt = `أنت خبير مناهج وأستاذ أكاديمي متخصص.
المطلوب: توليد ملخص دراسي عميق، شامل، وموسع لأقصى درجة ممكنة لمحتوى هذا الدرس دون أي حشو أو كلام جانبي.
ابدأ مباشرة في صلب الدرس بالهيكلية التالية:
1. 🎯 الأطروحة والهدف التعليمي المحوري
2. 📌 المفاهيم والركائز الأساسية (تحليل علمي مفصل لكل مفهوم)
3. 📐 القوانين والمعادلات بصيغة LaTeX القياسية ($...$ أو $$...$$) مع دلالات الرموز
4. ⚖️ مقارنة منهجية بين المتشابهات لتفادي الخلط
5. ⚠️ التنبيهات والأفخاخ الامتحانية
6. ✅ خلاصة الاستيعاب والتطبيقات العملية

سياق الدرس والمصادر:\n${context}`;

  return executeStudioPrompt(prompt, undefined, ctx.fallbackConfig);
}

/**
 * 2. AI Interactive Quiz Generator (MCQs & True/False with Explanations)
 */
export async function generateStudioQuiz(ctx: StudioContext, questionCount = 6): Promise<QuizQuestion[]> {
  const context = buildComprehensiveStudyContext(ctx);
  const prompt = `أنشئ بنك أسئلة تدريبية دقيقاً وعميقاً بعدد ${questionCount} أسئلة متنوعة (اختيار من متعدد MCQ وصح أو خطأ) بناءً على محتوى الدرس والمصادر المرفقة حصراً.
يجب أن تركز الأسئلة على الفهم العميق والقوانين والتعليلات العلمية.
أعد الناتج بتنسيق JSON حصراً كالتالي:
{
  "questions": [
    {
      "id": "q1",
      "question": "نص السؤال الدقيق هنا؟",
      "type": "mcq",
      "options": ["الخيار الأول الصحيح", "خيار بديل 1", "خيار بديل 2", "خيار بديل 3"],
      "answer": 0,
      "explanation": "التعليل العلمي الدقيق والمفصل لسبب صحة هذا الخيار"
    },
    {
      "id": "q2",
      "question": "العبارة العلمية المراد التحقق من صحتها؟",
      "type": "tf",
      "options": ["صح", "خطأ"],
      "answer": 0,
      "explanation": "شرح السبب والبرهان العلمي"
    }
  ]
}

سياق المقرر الدراسي:\n${context}`;

  const raw = await executeStudioPrompt(prompt, undefined, ctx.fallbackConfig);
  const parsed = robustParseJson<{ questions: QuizQuestion[] }>(raw, { questions: [] });
  const normalizedQuestions = (Array.isArray(parsed.questions) ? parsed.questions : [])
    .filter((question) => {
      if (!question || typeof question.question !== 'string' || question.question.trim().length < 8) return false;
      const options = Array.isArray(question.options) ? question.options.filter((option) => typeof option === 'string' && option.trim()) : [];
      return options.length >= 2 && Number.isInteger(Number(question.answer)) && Number(question.answer) >= 0 && Number(question.answer) < options.length;
    })
    .slice(0, questionCount)
    .map((question, index): QuizQuestion => {
      const options = (question.options || []).filter((option) => typeof option === 'string' && option.trim()).map((option) => option.trim());
      return {
      ...question,
      id: `studio_q_${Date.now()}_${index}`,
      type: question.type === 'tf' ? 'tf' : 'mcq',
      options,
      answer: Number(question.answer),
      question: question.question.trim(),
      explanation: typeof question.explanation === 'string' ? question.explanation.trim() : 'الإجابة الصحيحة مستندة إلى سياق المصادر المرفقة.',
      };
    });
  
  if (normalizedQuestions.length === 0) {
    // Fallback question to guarantee zero crashes
    return [
      {
        id: 'q_default_1',
        question: `ما هو المحور الأساسي الذي يعالجه مقرر «${ctx.notebookTitle}»؟`,
        type: 'mcq',
        options: [
          `المفاهيم التأسيسية والقوانين الرئيسية لـ ${ctx.notebookTitle}`,
          'معلومات عامة غير مرتبطة بالمنهج',
          'بيانات إحصائية غير مدققة',
          'أفكار خارج نطاق التخصص',
        ],
        answer: 0,
        explanation: `يركز المقرر بشكل أساسي على تفكيك ودراسة القواعد والتطبيقات المرتبطة بـ ${ctx.notebookTitle}.`,
      },
    ];
  }

  return normalizedQuestions;
}

/**
 * 3. AI Active Recall Flashcards Generator
 */
export async function generateStudioFlashcards(ctx: StudioContext, count = 8): Promise<Flashcard[]> {
  const context = buildComprehensiveStudyContext(ctx);
  const prompt = `استخرج أهم ${count} بطاقات استرجاع نشط (Active Recall Flashcards) للحقائق، القوانين، والتعريفات الأساسية من محتوى الدرس.
أعد الناتج بتنسيق JSON فقط:
{
  "cards": [
    {
      "front": "ما هو التعريف الدقيق لـ [المفهوم]؟ أو ما هو قانون [كذا]؟",
      "back": "الإجابة العلمية الوافية والمباشرة مع الصيغة الرياضية إن وجدت"
    }
  ]
}

سياق المقرر:\n${context}`;

  const raw = await executeStudioPrompt(prompt, undefined, ctx.fallbackConfig);
  const parsed = robustParseJson<{ cards: Array<{ front: string; back: string }> }>(raw, { cards: [] });

  const generated = (parsed.cards || [])
    .filter((c) => typeof c?.front === 'string' && c.front.trim() && typeof c?.back === 'string' && c.back.trim())
    .map((c, i) => ({
    id: `fc_${Date.now()}_${i}`,
    notebookId: ctx.notebookId || ctx.notebookTitle,
    front: c.front.trim(),
    back: c.back.trim(),
    level: 0,
    nextReview: Date.now(),
    mistake: false,
  }));

  if (generated.length === 0) {
    return [
      {
        id: `fc_fallback_${Date.now()}`,
        notebookId: ctx.notebookTitle,
        front: `ما هي الفكرة المحورية في درس «${ctx.notebookTitle}»؟`,
        back: `استيعاب المبادئ التأسيسية والقواعد العلمية المرتبطة بـ ${ctx.notebookSubject || ctx.notebookTitle}.`,
        level: 0,
        nextReview: Date.now(),
        mistake: false,
      },
    ];
  }

  return generated;
}

/**
 * 4. AI Dual Mind Map Generator (3D & 2D)
 * Extracts pure lesson concepts without any random talk.
 */
export async function generateStudioMindMapData(ctx: StudioContext): Promise<MindMapNode> {
  const context = buildComprehensiveStudyContext(ctx);
  const prompt = `أنت مصمم مناهج وخبير هندسة معرفية.
حلل سياق هذا الدرس الأكاديمي واستخرج وهيكل المفاهيم الأساسية (Main Concepts) بدقة إلى شجرة معرفية عميقة ومنظمة.
يُحظر تماماً أي كلام جانبي، مقدمات، أو جمل عشوائية. اعتمد فقط على المحتوى الفعلي للدرس.

قواعد الهيكلة:
1. الفكرة المركزية (Root): الموضوع العام المباشر ("${ctx.notebookTitle}").
2. المحاور الرئيسية (Branches): من 3 إلى 5 محاور علمية تأسيسية للدرس.
3. المفاهيم الفرعية (Subtopics): من 2 إلى 4 عناصر لكل محور (تعريفات، قوانين LaTeX، تطبيقات).

أعد الناتج بتنسيق JSON هرمي فقط بالشكل التالي:
{
  "title": "${ctx.notebookTitle || 'الفكرة المركزية'}",
  "notes": "شرح المحور الأساسي للدرس والمخرجات التعليمية",
  "badge": "الموضوع العام",
  "branches": [
    {
      "title": "اسم المحور الأول",
      "badge": "مفهوم أساسي",
      "notes": "شرح علمي دقيق للمحور",
      "formula": "معادلة بصيغة LaTeX إن وجدت",
      "subtopics": [
        {
          "title": "العنصر الفرعي الأول",
          "notes": "الشرح التفصيلي والتطبيق",
          "formula": "صيغة فرعية إن وجدت",
          "badge": "تطبيق أو قاعدة"
        }
      ]
    }
  ]
}

سياق الدرس والمصادر:\n${context}`;

  const raw = await executeStudioPrompt(prompt, undefined, ctx.fallbackConfig);
  const branchColors = ['#0f766e', '#0284c7', '#7c3aed', '#d97706', '#059669', '#dc2626'];

  try {
    const parsed = robustParseJson<any>(raw);
    if (parsed && (parsed.title || parsed.branches)) {
      const rootNode: MindMapNode = {
        id: 'root',
        title: parsed.title || ctx.notebookTitle || 'الفكرة المركزية',
        notes: parsed.notes || 'الفكرة المركزية للدراسة واستخلاص المفاهيم.',
        badge: parsed.badge || 'الموضوع العام',
        level: 0,
        color: '#0f766e',
        children: (parsed.branches || []).map((b: any, i: number) => {
          const color = branchColors[i % branchColors.length];
          return {
            id: `branch-${i + 1}`,
            title: b.title || `المحور الرئيسي ${i + 1}`,
            badge: b.badge || 'مفهوم رئيسي',
            notes: b.notes || '',
            formula: b.formula || undefined,
            level: 1,
            color,
            children: (b.subtopics || []).map((sub: any, j: number) => {
              const isObj = typeof sub === 'object' && sub !== null;
              return {
                id: `sub-${i + 1}-${j + 1}`,
                title: isObj ? sub.title : String(sub),
                notes: isObj ? sub.notes : undefined,
                formula: isObj ? sub.formula : undefined,
                badge: isObj ? sub.badge : 'تفريع جزئي',
                level: 2,
                color,
              };
            }),
          };
        }),
      };
      return rootNode;
    }
  } catch (e) {
    console.warn('JSON parsing failed for mindmap, building fallback structure:', e);
  }

  // Fallback high-quality curriculum tree
  return {
    id: 'root',
    title: ctx.notebookTitle || 'المفاهيم الأساسية',
    notes: `خريطة تفاعلية شاملة لمقرر ${ctx.notebookTitle}`,
    badge: 'الفكرة المركزية',
    level: 0,
    color: '#0f766e',
    children: [
      {
        id: 'b1',
        title: 'المفاهيم والتعاريف الأساسية',
        badge: 'تأصيل نظري',
        level: 1,
        color: '#0f766e',
        notes: 'الأسس والمصطلحات المعتمدة في المنهج.',
        children: [
          { id: 'b1-1', title: 'التعريف العلمي الدقيق', level: 2, color: '#0f766e', badge: 'تعريف' },
          { id: 'b1-2', title: 'الأركان والشروط الجوهرية', level: 2, color: '#0f766e', badge: 'شروط' },
        ],
      },
      {
        id: 'b2',
        title: 'القوانين والمعادلات الرياضية',
        badge: 'قوانين ونماذج',
        level: 1,
        color: '#0284c7',
        notes: 'الصيغ والرموز والعلاقات التناسبية.',
        children: [
          { id: 'b2-1', title: 'العلاقة الرياض��ة الأساسية', level: 2, color: '#0284c7', badge: 'قانون' },
          { id: 'b2-2', title: 'دلالات الرموز ووحدات القياس', level: 2, color: '#0284c7', badge: 'وحدات' },
        ],
      },
      {
        id: 'b3',
        title: 'التطبيقات والمسائل الامتحانية',
        badge: 'تطبيقات عملية',
        level: 1,
        color: '#d97706',
        notes: 'طرق حل التمارين ونماذج الأسئلة.',
        children: [
          { id: 'b3-1', title: 'خطوات ��لحل المنهجية', level: 2, color: '#d97706', badge: 'خطوات' },
          { id: 'b3-2', title: 'المحاذير والأخطاء الشائعة', level: 2, color: '#d97706', badge: 'تنبيه' },
        ],
      },
    ],
  };
}

/**
 * 5. AI Study Plan Generator (Real distribution across days)
 */
export async function generateStudioPlan(
  ctx: StudioContext,
  goal: string,
  days = 7
): Promise<StudyPlan> {
  const context = buildComprehensiveStudyContext(ctx);
  const prompt = `أنت موجه أكاديمي خبير في تنظيم المذاكرة والتحصيل للامتحانات.
الهدف الدراسي للطالب: "${goal || `إنهاء وإتقان مقرر ${ctx.notebookTitle}`}"
المدة المحددة: ${days} أيام.

المطلوب: توزيع منهج ومحتوى هذا الدرس بذكاء وتدرج منطقي على ${days} أيام بحيث يشمل:
- أيام للشرح والقراءة العميقة
- أيام للمسائل والتطبيقات
- أيام للمراجعة الشاملة وحل الامتحانات

أعد الناتج بتنسيق JSON حصراً كالتالي:
{
  "goal": "${goal}",
  "days": ${days},
  "minsPerDay": 45,
  "schedule": [
    {
      "day": 1,
      "task": "مهمة اليوم الأول المحددة بالتفصيل...",
      "focusTopic": "اسم الموضوع أو الفصل"
    }
  ]
}

سياق المنهج والمصادر:\n${context}`;

  try {
    const raw = await executeStudioPrompt(prompt, undefined, ctx.fallbackConfig);
    const parsed = robustParseJson<{ schedule: Array<{ day: number; task: string; focusTopic?: string }>; minsPerDay?: number }>(raw);

    if (parsed && Array.isArray(parsed.schedule) && parsed.schedule.length > 0) {
      const items = parsed.schedule.map((item, idx) => ({
        day: item.day || idx + 1,
        date: new Date(Date.now() + idx * 86400000).toISOString().slice(0, 10),
        task: item.focusTopic ? `[${item.focusTopic}] ${item.task}` : item.task,
        done: false,
      }));

      return {
        id: `plan_${Date.now()}`,
        notebookId: ctx.notebookTitle,
        goal: goal || ctx.notebookTitle,
        start: new Date().toISOString().slice(0, 10),
        days,
        mins: parsed.minsPerDay || 45,
        items,
      };
    }
  } catch (e) {
    console.warn('AI study plan generation failed, creating dynamic curriculum schedule:', e);
  }

  // Curriculum-based fallback plan
  const items = Array.from({ length: days }, (_, i) => ({
    day: i + 1,
    date: new Date(Date.now() + i * 86400000).toISOString().slice(0, 10),
    task: i === 0
      ? `قراءة المبادئ والتعريفات التأسيسية لـ «${ctx.notebookTitle}» وتلخيص المصطلحات`
      : i === days - 1
      ? `المراجعة الختامية الشاملة لـ «${ctx.notebookTitle}» وحل بنك الأسئلة التدريبي`
      : `دراسة القسم (${i + 1}) وحل المسائل التدريبية واستخراج بطاقات الاسترجاع`,
    done: false,
  }));

  return {
    id: `plan_${Date.now()}`,
    notebookId: ctx.notebookTitle,
    goal: goal || ctx.notebookTitle,
    start: new Date().toISOString().slice(0, 10),
    days,
    mins: 45,
    items,
  };
}

/**
 * 6. AI Terminology & Glossary Extractor
 */
export async function generateStudioGlossary(ctx: StudioContext): Promise<GlossaryItem[]> {
  const context = buildComprehensiveStudyContext(ctx);
  const prompt = `استخرج أهم 6 إلى 10 مصطلحات ومفاهيم محورية من محتوى هذا الدرس الأكاديمي مع تعريفها الدقيق ومثال تطبيقي عليها.
أعد الناتج بتنسيق JSON فقط:
{
  "glossary": [
    {
      "term": "اسم المصطلح أو المفهوم",
      "def": "التعريف العلمي الشامل والمعتمد",
      "ex": "مثال توضيحي أو سياق استخدام"
    }
  ]
}

سياق المقرر الدراسي:\n${context}`;

  try {
    const raw = await executeStudioPrompt(prompt, undefined, ctx.fallbackConfig);
    const parsed = robustParseJson<{ glossary: Array<{ term: string; def: string; ex?: string }> }>(raw);

    if (parsed && Array.isArray(parsed.glossary) && parsed.glossary.length > 0) {
      return parsed.glossary.map((g, i) => ({
        id: `gloss_${Date.now()}_${i}`,
        notebookId: ctx.notebookId || ctx.notebookTitle,
        term: g.term?.trim() || 'مصطلح غير معنون',
        def: g.def?.trim() || 'لم يرد تعريف موثق لهذا المصطلح.',
        ex: g.ex?.trim() || '',
        createdAt: Date.now(),
      }));
    }
  } catch (e) {
    console.warn('Glossary extraction failed:', e);
  }

  return [];
}

/**
 * 7. Dedicated AI Mind Map Generator for a Single Chat Message
 * Strictly isolates and distills ONLY the specified message into a multi-tiered mind map.
 */
export async function generateMindMapFromSingleMessageAI(
  messageText: string,
  fallbackTitle?: string,
  fallbackConfig?: any
): Promise<MindMapNode> {
  const cleanMessage = (messageText || '').trim();
  if (!cleanMessage) {
    throw new Error('نص الرسالة فارغ.');
  }

  const prompt = `أنت مهندس خرائط معرفية وخبير مناهج تعليمية عالمي بأسلوب منصات MindMeister و Miro و NotebookLM.
المطلوب: تحليل نص هذه الرسالة الواحدة فقط واستخراج خريطة ذهنية تفاعلية هرمية متفرعة وشديدة التنظيم والعمق.
يُحظر تماماً أي كلام جانبي، تحيات، أو مجاملات؛ استخرج فقط المفاهيم الأكاديمية والعلمية والقوانين المشروحة في هذه الرسالة حصراً دون إقحام مواضيع خارجية.

قواعد الهيكلة:
1. الفكرة المركزية (Root Node): عنوان المفهوم الرئيسي المشروح في هذه الرسالة (أقل من 30 حرف).
2. المحاور الرئيسية (Branches): من 3 إلى 5 فروع رئيسية تمثل المحاور الكبرى التي شرحتها الرسالة.
3. المفاهيم الفرعية (Subtopics): من 2 إلى 4 تفريعات لكل فرع (تعريفات، قوانين LaTeX، تطبيقات).
4. أخرج الناتج بتنسيق JSON حصراً كالتالي:
{
  "title": "عنوان الفكرة المركزية المستخلصة من الرسالة",
  "notes": "خلاصة علمية مركزة ومباشرة للموضوع",
  "badge": "فكرة مركزية",
  "branches": [
    {
      "title": "عنوان المحور الرئيسي الأول",
      "badge": "محور رئيسي",
      "notes": "شرح علمي للمحور",
      "formula": "معادلة بصيغة LaTeX إن وجدت",
      "subtopics": [
        {
          "title": "العنصر الفرعي",
          "notes": "الشرح العلمي والتطبيق",
          "formula": "صيغة فرعية إن وجدت",
          "badge": "مفهوم فرعي"
        }
      ]
    }
  ]
}

نص الرسالة المراد تحويلها لخريطة:\n«${cleanMessage}»`;

  const branchColors = ['#0f766e', '#0284c7', '#7c3aed', '#d97706', '#059669', '#dc2626', '#0891b2', '#4f46e5'];

  const systemInstruction = `أنت مهندس استخلاص خرائط مفاهيمية وذهنية دقيق وصارم. التزم بنص الرسالة الواحدة فقط دون إدخال أي معلومات خارجها. يُحظر عليك منعاً باتاً كتابة أي مقدمات أو شروحات جانبية؛ أخرج كائن JSON الصالح والمطابق للهيكل المحدد حصراً.`;

  try {
    const raw = await executeStudioPrompt(prompt, systemInstruction, fallbackConfig);
    const parsed = robustParseJson<any>(raw);

    if (parsed && (parsed.title || (Array.isArray(parsed.branches) && parsed.branches.length > 0))) {
      const rootNode: MindMapNode = {
        id: `map-msg-${Date.now()}`,
        title: parsed.title || fallbackTitle || 'المفهوم المستخلص',
        notes: parsed.notes || 'خريطة ذهنية مستخلصة بالذكاء الاصطناعي من رسالة الشرح.',
        badge: parsed.badge || 'الفكرة المركزية',
        level: 0,
        color: '#0f766e',
        children: (parsed.branches || []).map((b: any, i: number) => {
          const color = branchColors[i % branchColors.length];
          return {
            id: `msg-branch-${i + 1}`,
            title: b.title || `المحور ${i + 1}`,
            badge: b.badge || 'محور رئيسي',
            notes: b.notes || '',
            formula: b.formula || undefined,
            level: 1,
            color,
            children: (b.subtopics || []).map((sub: any, j: number) => {
              const isObj = typeof sub === 'object' && sub !== null;
              return {
                id: `msg-sub-${i + 1}-${j + 1}`,
                title: isObj ? sub.title : String(sub),
                notes: isObj ? sub.notes : undefined,
                formula: isObj ? sub.formula : undefined,
                badge: isObj ? sub.badge : 'تفريعة فرعية',
                level: 2,
                color,
              };
            }),
          };
        }),
      };

      if (rootNode.children && rootNode.children.length > 0) {
        return rootNode;
      }
    }
  } catch (e) {
    console.warn('AI single message mind map failed, falling back to algorithmic parser:', e);
  }

  // Fallback to offline parser from mindMapParser.ts
  const { buildDeepMindMapFromText } = await import('./mindMapParser');
  return buildDeepMindMapFromText(cleanMessage, fallbackTitle || 'مفهوم الشرح المستخلص');
}

/**
 * 8. Dedicated AI Mind Map Generator for the Entire Conversation
 * Synthesizes all messages into a unified, holistic multi-tiered knowledge graph.
 */
export async function generateMindMapFromConversationAI(
  messages: Array<{ role: string; text: string }>,
  notebookTitle: string,
  fallbackConfig?: any
): Promise<MindMapNode> {
  const meaningfulMessages = (messages || [])
    .filter((m) => m && m.text && m.text.trim().length > 10)
    .slice(-20);

  if (meaningfulMessages.length === 0) {
    throw new Error('لا توجد رسائل كافية في المحادثة لإنشاء خريطة ذهنية.');
  }

  const conversationTranscript = meaningfulMessages
    .map((m, idx) => `[رسالة ${idx + 1} - ${m.role === 'user' ? 'سؤال المتعلم' : 'شرح المعلم الذكي'}]:\n${m.text.trim()}`)
    .join('\n\n---\n\n');

  const prompt = `أنت مصمم خرائط ذهنية ومنظّم معرفي عالمي للمناهج الأكاديمية.
المطلوب: دراسة كامل المحادثة التعليمية واستخراج خريطة ذهنية تفاعلية موحدة وشاملة تجمع كل المحاور والمفاهيم والقوانين التي تمت مناقشتها عبر كافة الرسائل.
احذف تماماً أي كلام جانبي، تحيات، أو استفسارات عابرة، واجمع الموضوعات المترابطة في شجرة هرمية متناسقة.

قواعد الهيكلة:
1. الفكرة المركزية (Root): الموضوع العام الشامل لمقرر «${notebookTitle}».
2. المحاور الكبرى (Branches): من 4 إلى 6 محاور رئيسية تغطي كافة الدروس والأسئلة التي عولجت في المحادثة.
3. المفاهيم الفرعية (Subtopics): من 2 إلى 4 عناصر لكل محور مع التعريفات والقوانين بصيغة LaTeX.

أعد الناتج بتنسيق JSON حصراً:
{
  "title": "${notebookTitle || 'موضوع المحادثة'}",
  "notes": "خريطة تفاعلية شاملة لكافة المحاور المشروحة في سجل المحادثة",
  "badge": "المحادثة كاملة",
  "branches": [
    {
      "title": "اسم المحور الرئيسي",
      "badge": "محور رئيسي",
      "notes": "شرح المحور وما تم بحثه بالمحادثة",
      "formula": "معادلة رئيسية إن وجدت",
      "subtopics": [
        {
          "title": "العنصر الفرعي",
          "notes": "الشرح والتطبيق",
          "formula": "صيغة رياضية فرعية إن وجدت",
          "badge": "مفهوم مستخلص"
        }
      ]
    }
  ]
}

سجل المحادثة الكاملة:\n${conversationTranscript}`;

  const branchColors = ['#0f766e', '#0284c7', '#7c3aed', '#d97706', '#059669', '#dc2626', '#0891b2', '#4f46e5'];

  try {
    const raw = await executeStudioPrompt(prompt, undefined, fallbackConfig);
    const parsed = robustParseJson<any>(raw);

    if (parsed && (parsed.title || (Array.isArray(parsed.branches) && parsed.branches.length > 0))) {
      const rootNode: MindMapNode = {
        id: `map-conv-${Date.now()}`,
        title: parsed.title || notebookTitle || 'خريطة المحادثة الكاملة',
        notes: parsed.notes || 'خريطة شاملة مستخلصة بالذكاء الاصطناعي لكافة محاور المحادثة.',
        badge: parsed.badge || 'المحادثة كاملة',
        level: 0,
        color: '#0f766e',
        children: (parsed.branches || []).map((b: any, i: number) => {
          const color = branchColors[i % branchColors.length];
          return {
            id: `conv-branch-${i + 1}`,
            title: b.title || `المحور ${i + 1}`,
            badge: b.badge || 'محور رئيسي',
            notes: b.notes || '',
            formula: b.formula || undefined,
            level: 1,
            color,
            children: (b.subtopics || []).map((sub: any, j: number) => {
              const isObj = typeof sub === 'object' && sub !== null;
              return {
                id: `conv-sub-${i + 1}-${j + 1}`,
                title: isObj ? sub.title : String(sub),
                notes: isObj ? sub.notes : undefined,
                formula: isObj ? sub.formula : undefined,
                badge: isObj ? sub.badge : 'مفهوم فرعي',
                level: 2,
                color,
              };
            }),
          };
        }),
      };

      if (rootNode.children && rootNode.children.length > 0) {
        return rootNode;
      }
    }
  } catch (e) {
    console.warn('AI conversation mind map failed, falling back to algorithmic parser:', e);
  }

  // Fallback: Combine AI messages into deep mind map
  const aiTexts = meaningfulMessages
    .filter((m) => m.role !== 'user')
    .map((m) => m.text)
    .join('\n\n');
  const { buildDeepMindMapFromText } = await import('./mindMapParser');
  return buildDeepMindMapFromText(aiTexts || conversationTranscript, notebookTitle || 'خريطة المحادثة الدراسية');
}
