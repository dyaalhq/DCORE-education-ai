import { SourceChunk, Citation } from '../types';

export interface SearchResult {
  chunk: SourceChunk;
  score: number;
}

// Tokenize text for Arabic & English with lightweight stemming
export function normalizeArabicWord(w: string): string {
  if (!w || typeof w !== 'string') return '';
  let word = w
    .toLowerCase()
    .normalize('NFKC')
    .replace(/[ًٌٍَُِّْـ]/g, '')
    .replace(/[أإآ]/g, 'ا')
    .replace(/ى/g, 'ي')
    .replace(/ة/g, 'ه');

  // Strip common Arabic definite article "ال"
  if (word.startsWith('ال') && word.length > 3) {
    word = word.slice(2);
  } else if ((word.startsWith('و') || word.startsWith('ف') || word.startsWith('ب') || word.startsWith('ك') || word.startsWith('ل')) && word.length > 4) {
    if (word.slice(1).startsWith('ال')) {
      word = word.slice(3);
    } else {
      word = word.slice(1);
    }
  }

  // Strip common plural / dual suffixes if length allows
  if (word.length > 4) {
    if (word.endsWith('ات') || word.endsWith('ين') || word.endsWith('ون') || word.endsWith('ان')) {
      word = word.slice(0, -2);
    }
  }

  return word;
}

export function tokenize(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  const rawWords = text
    .toLowerCase()
    .normalize('NFKC')
    .replace(/[ًٌٍَُِّْـ]/g, '')
    .replace(/[أإآ]/g, 'ا')
    .replace(/ى/g, 'ي')
    .replace(/ة/g, 'ه')
    .replace(/[^\p{L}\p{N}\s]/gu, ' ')
    .split(/\s+/)
    .filter((w) => w.length > 1);

  const tokens = new Set<string>();
  for (const w of rawWords) {
    tokens.add(w);
    const normalized = normalizeArabicWord(w);
    if (normalized.length > 1) {
      tokens.add(normalized);
    }
  }
  return Array.from(tokens);
}

// Detect if query is a broad/comprehensive request
export function isComprehensiveQuery(query: string): boolean {
  if (!query || typeof query !== 'string') return false;
  const q = query.toLowerCase();
  return /(كامل|شامل|مفصل|موسع|كل الكتاب|المنهج بالتفصيل|اشرح الكتاب|شرح الكتاب|تغطية شاملة|المنهج كامل|كل المنهج|شرح المنهج|فهرس الكتاب|محتويات الكتاب|الكتاب كاملا|التفصيل الممل|جميع الوحدات|كل الفصول|كل الدروس|شرح الدروس كلها|مقرر كامل|من البداية للنهاية|ملخص|لخص|كل|جميع|محتوى|فهرس|مواضيع|نظرة عامة|تلخيص|استخرج كل)/i.test(q);
}

// Select representative chunks across the whole document with deep curriculum coverage
export function getComprehensiveChunks(
  chunks: SourceChunk[],
  limit = 20
): SearchResult[] {
  if (chunks.length <= limit) {
    return chunks.map((chunk, i) => ({ chunk, score: 10 - i * 0.1 }));
  }

  const selectedChunks: SourceChunk[] = [];
  const step = (chunks.length - 1) / (limit - 1);

  for (let i = 0; i < limit; i++) {
    const idx = Math.min(chunks.length - 1, Math.round(i * step));
    const candidate = chunks[idx];
    if (!selectedChunks.some((c) => c.id === candidate.id)) {
      selectedChunks.push(candidate);
    }
  }

  return selectedChunks.map((chunk, i) => ({ chunk, score: 10 - i * 0.2 }));
}

// Extract n-gram vector for character & subword similarity
export function vectorize(text: string): Map<string, number> {
  const grams = new Map<string, number>();
  if (!text || typeof text !== 'string') return grams;
  const clean = ' ' + text.toLowerCase().normalize('NFKC').replace(/\s+/g, ' ') + ' ';
  for (let i = 0; i < clean.length - 2; i++) {
    const gram = clean.slice(i, i + 3);
    grams.set(gram, (grams.get(gram) || 0) + 1);
  }
  const norm = Math.sqrt([...grams.values()].reduce((s, v) => s + v * v, 0)) || 1;
  for (const [k, v] of grams) {
    grams.set(k, v / norm);
  }
  return grams;
}

export function cosineSim(a: Map<string, number>, b: Map<string, number>): number {
  let score = 0;
  const small = a.size <= b.size ? a : b;
  const large = a.size <= b.size ? b : a;
  for (const [k, v] of small) {
    score += v * (large.get(k) || 0);
  }
  return score;
}

export function searchChunks(
  query: string,
  chunks: SourceChunk[],
  limit = 8
): SearchResult[] {
  if (!query.trim() || chunks.length === 0) return [];

  const qTokens = tokenize(query);
  const qVector = vectorize(query);
  const N = Math.max(1, chunks.length);

  // Document frequency map
  const df = new Map<string, number>();
  for (const c of chunks) {
    const chunkTokens = new Set(tokenize(c.text));
    for (const w of qTokens) {
      if (chunkTokens.has(w)) {
        df.set(w, (df.get(w) || 0) + 1);
      }
    }
  }

  const results: SearchResult[] = [];

  for (const chunk of chunks) {
    const tokens = tokenize(chunk.text);
    const tokenSet = new Set(tokens);

    let lexicalScore = 0;
    let matchCount = 0;

    for (const w of qTokens) {
      if (tokenSet.has(w)) {
        matchCount++;
        const idf = Math.log(1 + (N - (df.get(w) || 0) + 0.5) / ((df.get(w) || 0) + 0.5));
        const tf = tokens.filter((t) => t === w).length;
        lexicalScore += idf * ((tf * 2.2) / (tf + 1.2));
      }
    }

    // Metadata keyword & section bonus
    let metadataBonus = 0;
    if (chunk.metadata?.keywords && chunk.metadata.keywords.length > 0) {
      for (const kw of chunk.metadata.keywords) {
        if (qTokens.includes(kw)) {
          metadataBonus += 2.5;
        }
      }
    }
    if (chunk.section && qTokens.some((w) => chunk.section!.toLowerCase().includes(w))) {
      metadataBonus += 3.0;
    }

    const vectorScore = cosineSim(qVector, vectorize(chunk.text));
    const finalScore = lexicalScore * 0.75 + vectorScore * 15 + metadataBonus;

    if (finalScore > 0.05 || matchCount > 0) {
      results.push({ chunk, score: finalScore });
    }
  }

  return results.sort((a, b) => b.score - a.score).slice(0, limit);
}

export function formatContext(results: SearchResult[], query?: string): {
  contextText: string;
  citations: Citation[];
} {
  const citations: Citation[] = [];
  const textParts: string[] = [];
  const qTokens = query ? tokenize(query) : [];

  // Determine max score for normalization
  const maxScore = results.length > 0 ? Math.max(...results.map((r) => r.score), 1) : 1;

  results.forEach((r, idx) => {
    const refNum = idx + 1;
    const pageStr = r.chunk.pageNumber ? ` (ص ${r.chunk.pageNumber})` : '';
    const sectionStr = r.chunk.section ? ` [قسم: ${r.chunk.section}]` : '';
    const hierarchyStr = r.chunk.metadata?.headingHierarchy && r.chunk.metadata.headingHierarchy.length > 1
      ? ` [المسار الأكاديمي: ${r.chunk.metadata.headingHierarchy.join(' > ')}]`
      : '';
    
    textParts.push(
      `[كتلة بيانات ${refNum} - مصدر: ${r.chunk.sourceTitle}${pageStr}${sectionStr}${hierarchyStr}]\n${r.chunk.text.trim()}`
    );

    // Calculate confidence percentage (e.g. 75% to 99%)
    const normalizedRatio = Math.min(1, Math.max(0.2, r.score / maxScore));
    const confidenceScore = Math.round(78 + normalizedRatio * 21); // Scale between 78% and 99%
    const confidenceLevel: 'high' | 'medium' | 'moderate' = 
      confidenceScore >= 90 ? 'high' : confidenceScore >= 82 ? 'medium' : 'moderate';

    // Find matched keywords in chunk
    const chunkTokens = new Set(tokenize(r.chunk.text));
    const matchedKeywords = qTokens.filter((t) => chunkTokens.has(t)).slice(0, 5);

    citations.push({
      sourceId: r.chunk.sourceId,
      sourceTitle: r.chunk.sourceTitle,
      pageNumber: r.chunk.pageNumber,
      section: r.chunk.section,
      quote: r.chunk.text.slice(0, 260).trim() + '...',
      confidenceScore,
      confidenceLevel,
      matchedKeywords,
      chunkId: r.chunk.id,
      headingHierarchy: r.chunk.metadata?.headingHierarchy,
    });
  });

  return {
    contextText: textParts.join('\n\n---\n\n'),
    citations,
  };
}
