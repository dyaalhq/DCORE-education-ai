// Standalone Interactive HTML Generator for D3 Mind Maps
// Creates a completely self-contained, offline-capable interactive mind map HTML file
// With hierarchical expand/collapse, touch gestures, search, and D.CORE branding

import { MindMapNode } from '../types';

export function generateInteractiveMindMapHtml(
  rootData: MindMapNode,
  title: string,
  subject: string
): string {
  const dataJson = JSON.stringify(rootData);
  const cleanTitle = title || 'خريطة المفاهيم الذهنية التفاعلية';
  const cleanSubject = subject || 'عام';

  return `<!DOCTYPE html>
<html lang="ar" dir="rtl" data-theme="light">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <title>${cleanTitle} | خريطة تفاعلية - فريق D.CORE الذكي</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800;900&display=swap" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/d3@7"></script>
  <script>
    if (typeof d3 === 'undefined') {
      document.write('<script src="https://cdnjs.cloudflare.com/ajax/libs/d3/7.9.0/d3.min.js"><\\/script>');
    }
  </script>
  <script>
    if (typeof d3 === 'undefined') {
      document.write('<script src="https://unpkg.com/d3@7/dist/d3.min.js"><\\/script>');
    }
  </script>
  <script>
    if (typeof d3 === 'undefined') {
      document.write('<script src="https://cdn.jsdelivr.net/npm/d3@7"><\\/script>');
    }
  </script>
  <style>
    :root {
      --primary: #0f766e;
      --primary-hover: #115e59;
      --bg: #f8fafc;
      --card-bg: #ffffff;
      --card-border: #e2e8f0;
      --text: #0f172a;
      --text-muted: #64748b;
      --node-stroke: #cbd5e1;
    }
    [data-theme="dark"] {
      --primary: #2dd4bf;
      --primary-hover: #14b8a6;
      --bg: #091210;
      --card-bg: #111d19;
      --card-border: #1e332c;
      --text: #f1f5f9;
      --text-muted: #94a3b8;
      --node-stroke: #233c34;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-tap-highlight-color: transparent;
    }
    body {
      font-family: 'Tajawal', system-ui, -apple-system, sans-serif;
      background: var(--bg);
      color: var(--text);
      overflow: hidden;
      height: 100vh;
      height: 100dvh;
      display: flex;
      flex-direction: column;
    }
    header {
      padding: 0.6rem 1rem;
      background: var(--card-bg);
      border-bottom: 1px solid var(--card-border);
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      align-items: center;
      gap: 0.75rem;
      z-index: 20;
      box-shadow: 0 1px 3px rgba(0,0,0,0.04);
    }
    .brand-section {
      display: flex;
      align-items: center;
      gap: 0.6rem;
    }
    .brand-logo {
      width: 32px;
      height: 32px;
      border-radius: 10px;
      background: linear-gradient(135deg, #0f766e, #10b981);
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 900;
      font-size: 14px;
      box-shadow: 0 2px 6px rgba(15,118,110,0.25);
    }
    .badge {
      font-size: 0.68rem;
      font-weight: 800;
      padding: 0.2rem 0.5rem;
      border-radius: 9999px;
      background: rgba(15, 118, 110, 0.12);
      color: var(--primary);
      border: 1px solid rgba(15, 118, 110, 0.2);
    }
    .toolbar {
      display: flex;
      align-items: center;
      gap: 0.4rem;
      flex-wrap: wrap;
    }
    button {
      font-family: inherit;
      font-size: 0.75rem;
      font-weight: 700;
      padding: 0.35rem 0.7rem;
      border-radius: 0.65rem;
      border: 1px solid var(--card-border);
      background: var(--card-bg);
      color: var(--text);
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 0.35rem;
      transition: all 0.15s ease;
    }
    button:hover {
      background: rgba(15, 118, 110, 0.08);
      border-color: var(--primary);
    }
    button.active {
      background: #0f766e;
      color: #ffffff;
      border-color: #0f766e;
    }
    .search-input {
      font-family: inherit;
      font-size: 0.75rem;
      padding: 0.35rem 0.7rem;
      border-radius: 0.65rem;
      border: 1px solid var(--card-border);
      background: var(--card-bg);
      color: var(--text);
      width: 140px;
      outline: none;
    }
    .search-input:focus {
      border-color: var(--primary);
    }
    #canvas-container {
      flex: 1;
      position: relative;
      overflow: hidden;
      touch-action: none;
    }
    svg {
      width: 100%;
      height: 100%;
      cursor: grab;
      user-select: none;
    }
    svg:active {
      cursor: grabbing;
    }
    .floating-controls {
      position: absolute;
      bottom: 1rem;
      left: 1rem;
      display: flex;
      gap: 0.35rem;
      background: var(--card-bg);
      padding: 0.35rem;
      border-radius: 0.85rem;
      border: 1px solid var(--card-border);
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
      z-index: 15;
    }
    .floating-controls button {
      padding: 0.35rem 0.55rem;
      font-size: 0.95rem;
      line-height: 1;
    }
    .help-banner {
      position: absolute;
      bottom: 1rem;
      right: 1rem;
      background: var(--card-bg);
      padding: 0.4rem 0.85rem;
      border-radius: 0.85rem;
      border: 1px solid var(--card-border);
      font-size: 0.72rem;
      color: var(--text-muted);
      box-shadow: 0 4px 12px rgba(0,0,0,0.06);
      z-index: 10;
      pointer-events: none;
    }
    /* Node drawer */
    #node-drawer {
      position: absolute;
      top: 1rem;
      right: 1rem;
      bottom: 1rem;
      width: 320px;
      max-width: calc(100% - 2rem);
      background: var(--card-bg);
      border: 1px solid var(--card-border);
      border-radius: 1.25rem;
      box-shadow: 0 12px 30px rgba(0,0,0,0.18);
      display: none;
      flex-direction: column;
      z-index: 30;
      animation: slideIn 0.2s ease;
    }
    @keyframes slideIn {
      from { transform: translateX(20px); opacity: 0; }
      to { transform: translateX(0); opacity: 1; }
    }
    #node-drawer.open {
      display: flex;
    }
    .drawer-header {
      padding: 0.85rem 1rem;
      border-bottom: 1px solid var(--card-border);
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .drawer-body {
      padding: 1rem;
      overflow-y: auto;
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 0.85rem;
    }
    .formula-box {
      background: rgba(15, 118, 110, 0.08);
      border: 1px solid rgba(15, 118, 110, 0.25);
      border-radius: 0.75rem;
      padding: 0.6rem;
      font-family: monospace;
      font-size: 0.85rem;
      color: var(--primary);
      direction: ltr;
      text-align: center;
    }
    .notes-box {
      font-size: 0.82rem;
      line-height: 1.7;
      color: var(--text-muted);
      white-space: pre-wrap;
    }
    .creator-tag {
      font-size: 0.68rem;
      color: var(--text-muted);
      display: block;
      margin-top: 0.15rem;
    }
  </style>
</head>
<body>
  <header>
    <div class="brand-section">
      <div class="brand-logo">✦</div>
      <div>
        <div style="display:flex; align-items:center; gap:0.4rem;">
          <h2 style="font-size: 0.92rem; font-weight: 900;">${cleanTitle}</h2>
          <span class="badge">${cleanSubject}</span>
        </div>
        <span class="creator-tag">صناعة وتطوير: <b>فريق D.CORE الذكي</b></span>
      </div>
    </div>

    <div class="toolbar">
      <input type="text" id="searchInput" class="search-input" placeholder="بحث في الفروع...">
      <button id="btnTree" class="active">شجرة هرمية</button>
      <button id="btnRadial">دائري شعاعي</button>
      <button id="btnExpandAll">توسيع الكل</button>
      <button id="btnCollapseAll">طي الفروع</button>
      <button id="btnTheme">☀️/🌙</button>
      <button id="btnPrint" style="background:#0f766e; color:#fff;">طباعة / PDF</button>
    </div>
  </header>

  <div id="canvas-container">
    <svg id="mindMapSvg">
      <g id="mainGroup"></g>
    </svg>

    <div class="floating-controls">
      <button id="btnZoomIn" title="تكبير">+</button>
      <button id="btnZoomOut" title="تصغير">-</button>
      <button id="btnReset" title="إعادة ضبط الموضع">⟲</button>
    </div>

    <div class="help-banner">
      💡 انقر على أي عقدة للتوسيع والطي • اسحب للتحريك • انقر مرتين للتكبير
    </div>

    <div id="node-drawer">
      <div class="drawer-header">
        <span id="drawerBadge" class="badge">مفهوم أساسي</span>
        <button id="btnCloseDrawer" style="padding: 0.2rem 0.5rem; font-size:12px;">✕ إغلاق</button>
      </div>
      <div class="drawer-body">
        <h3 id="drawerTitle" style="font-size: 1.05rem; font-weight: 800; line-height: 1.4;"></h3>
        <div id="drawerFormula" class="formula-box" style="display: none;"></div>
        <div id="drawerNotes" class="notes-box"></div>
      </div>
    </div>
  </div>

  <script>
    const rawData = ${dataJson};
    let currentLayout = 'tree';
    let searchQuery = '';
    let rootHierarchy = null;

    const svg = d3.select("#mindMapSvg");
    const g = d3.select("#mainGroup");

    const zoom = d3.zoom()
      .scaleExtent([0.15, 4.5])
      .on("zoom", (e) => g.attr("transform", e.transform));

    svg.call(zoom);

    // Deep clone data to allow interactive mutation
    let treeData = JSON.parse(JSON.stringify(rawData));

    // Initialize collapsible state
    function initCollapsible(node, depth = 0) {
      if (node.children && node.children.length > 0) {
        node.children.forEach(c => initCollapsible(c, depth + 1));
        // Keep Level 0 and Level 1 expanded, collapse deeper levels initially for clean view
        if (depth >= 2) {
          node._children = node.children;
          node.children = null;
        }
      }
    }
    initCollapsible(treeData, 0);

    function toggleNode(d) {
      if (d.data.children) {
        d.data._children = d.data.children;
        d.data.children = null;
      } else if (d.data._children) {
        d.data.children = d.data._children;
        d.data._children = null;
      }
      render();
    }

    function expandAllNodes(node) {
      if (node._children) {
        node.children = node._children;
        node._children = null;
      }
      if (node.children) {
        node.children.forEach(expandAllNodes);
      }
    }

    function collapseAllNodes(node, depth = 0) {
      if (node.children) {
        node.children.forEach(c => collapseAllNodes(c, depth + 1));
        if (depth >= 1) {
          node._children = node.children;
          node.children = null;
        }
      }
    }

    function render() {
      g.selectAll("*").remove();

      const width = svg.node().clientWidth || 1000;
      const height = svg.node().clientHeight || 700;

      rootHierarchy = d3.hierarchy(treeData, d => d.children);

      const isDarkMode = document.documentElement.getAttribute("data-theme") === "dark";
      const cardBg = isDarkMode ? "#14221d" : "#ffffff";
      const cardBorder = isDarkMode ? "#223930" : "#e2e8f0";
      const textColor = isDarkMode ? "#f1f5f9" : "#0f172a";
      const linkColor = isDarkMode ? "#2dd4bf" : "#0f766e";

      if (currentLayout === 'tree') {
        const dx = 55;
        const dy = 230;
        const tree = d3.tree().nodeSize([dx, dy]);
        tree(rootHierarchy);

        // Links with smooth cubic curves
        g.append("g")
          .attr("fill", "none")
          .attr("stroke", linkColor)
          .attr("stroke-opacity", 0.45)
          .attr("stroke-width", 2)
          .selectAll("path")
          .data(rootHierarchy.links())
          .enter()
          .append("path")
          .attr("d", d3.linkHorizontal().x(d => -d.y).y(d => d.x));

        // Node Cards
        const node = g.append("g")
          .selectAll("g")
          .data(rootHierarchy.descendants())
          .enter()
          .append("g")
          .attr("transform", d => "translate(" + -d.y + "," + d.x + ")")
          .attr("cursor", "pointer");

        const nodeW = 180;
        const nodeH = 46;

        node.append("rect")
          .attr("x", -nodeW / 2)
          .attr("y", -nodeH / 2)
          .attr("width", nodeW)
          .attr("height", nodeH)
          .attr("rx", 12)
          .attr("fill", cardBg)
          .attr("stroke", d => {
            if (searchQuery && (d.data.title || '').toLowerCase().includes(searchQuery.toLowerCase())) {
              return "#f59e0b";
            }
            return d.data.color || (d.depth === 0 ? "#0f766e" : cardBorder);
          })
          .attr("stroke-width", d => (searchQuery && (d.data.title || '').toLowerCase().includes(searchQuery.toLowerCase()) ? 3 : 1.5))
          .attr("filter", "drop-shadow(0 2px 5px rgba(0,0,0,0.08))")
          .on("click", (e, d) => {
            if (d.data.children || d.data._children) {
              toggleNode(d);
            }
            showDrawer(d.data);
          });

        // Color accent line
        node.append("rect")
          .attr("x", nodeW / 2 - 5)
          .attr("y", -nodeH / 2 + 6)
          .attr("width", 3.5)
          .attr("height", nodeH - 12)
          .attr("rx", 2)
          .attr("fill", d => d.data.color || "#0f766e");

        // Title
        node.append("text")
          .attr("x", nodeW / 2 - 12)
          .attr("y", -2)
          .attr("text-anchor", "end")
          .attr("fill", textColor)
          .attr("font-size", "11.5px")
          .attr("font-weight", d => d.depth === 0 ? "800" : "600")
          .text(d => {
            const t = d.data.title || '';
            return t.length > 20 ? t.slice(0, 18) + '...' : t;
          })
          .on("click", (e, d) => {
            if (d.data.children || d.data._children) {
              toggleNode(d);
            }
            showDrawer(d.data);
          });

        // Subtitle / Badge
        node.append("text")
          .attr("x", nodeW / 2 - 12)
          .attr("y", 14)
          .attr("text-anchor", "end")
          .attr("fill", "#64748b")
          .attr("font-size", "9.5px")
          .text(d => {
            if (d.data._children && d.data._children.length > 0) {
              return '• +' + d.data._children.length + ' فروع (انقر للتفريع)';
            }
            if (d.data.children && d.data.children.length > 0) {
              return '• ' + d.data.children.length + ' فروع (انقر للطي)';
            }
            return d.data.badge || (d.depth === 0 ? "الموضوع العام" : "مفهوم");
          })
          .on("click", (e, d) => {
            if (d.data.children || d.data._children) {
              toggleNode(d);
            }
            showDrawer(d.data);
          });

        // Expand / Collapse Action Circle
        const toggleBtn = node.filter(d => (d.data.children && d.data.children.length > 0) || (d.data._children && d.data._children.length > 0))
          .append("g")
          .attr("transform", "translate(" + (-nodeW / 2 - 8) + ", 0)")
          .on("click", (e, d) => {
            e.stopPropagation();
            toggleNode(d);
          });

        toggleBtn.append("circle")
          .attr("r", 9)
          .attr("fill", d => d.data._children ? "#0f766e" : "#e2e8f0")
          .attr("stroke", "#0f766e")
          .attr("stroke-width", 1.5);

        toggleBtn.append("text")
          .attr("text-anchor", "middle")
          .attr("dy", "3.5px")
          .attr("font-size", "10px")
          .attr("font-weight", "bold")
          .attr("fill", d => d.data._children ? "#ffffff" : "#0f766e")
          .text(d => d.data._children ? "+" : "−");

      } else {
        // Radial Layout
        const radius = Math.min(width, height) / 2 - 70;
        const cluster = d3.cluster().size([2 * Math.PI, radius]);
        cluster(rootHierarchy);

        g.append("g")
          .attr("fill", "none")
          .attr("stroke", linkColor)
          .attr("stroke-opacity", 0.5)
          .attr("stroke-width", 2)
          .selectAll("path")
          .data(rootHierarchy.links())
          .enter()
          .append("path")
          .attr("d", d3.linkRadial().angle(d => d.x).radius(d => d.y));

        const node = g.append("g")
          .selectAll("g")
          .data(rootHierarchy.descendants())
          .enter()
          .append("g")
          .attr("transform", d => \`rotate(\${(d.x * 180 / Math.PI - 90)})translate(\${d.y},0)\`)
          .attr("cursor", "pointer")
          .on("click", (e, d) => showDrawer(d.data));

        node.append("circle")
          .attr("r", d => d.depth === 0 ? 14 : 8)
          .attr("fill", d => d.data.color || "#0f766e")
          .attr("stroke", "#ffffff")
          .attr("stroke-width", 2);

        node.append("text")
          .attr("dy", "0.32em")
          .attr("x", d => d.x < Math.PI === !d.children ? 12 : -12)
          .attr("text-anchor", d => d.x < Math.PI === !d.children ? "start" : "end")
          .attr("transform", d => d.x >= Math.PI ? "rotate(180)" : null)
          .text(d => d.data.title || '')
          .attr("fill", textColor)
          .attr("font-size", "11px")
          .attr("font-weight", "700");
      }
    }

    function resetView() {
      const width = svg.node().clientWidth || 1000;
      const height = svg.node().clientHeight || 700;
      let transform;
      if (currentLayout === 'tree') {
        transform = d3.zoomIdentity.translate(width * 0.75, height / 2).scale(0.85);
      } else {
        transform = d3.zoomIdentity.translate(width / 2, height / 2).scale(0.85);
      }
      svg.transition().duration(500).call(zoom.transform, transform);
    }

    function showDrawer(node) {
      document.getElementById("drawerTitle").textContent = node.title || '';
      document.getElementById("drawerBadge").textContent = node.badge || (node.level === 0 ? 'الموضوع الرئيسي' : 'مفهوم دراسي');
      
      const formulaEl = document.getElementById("drawerFormula");
      if (node.formula) {
        formulaEl.textContent = node.formula;
        formulaEl.style.display = "block";
      } else {
        formulaEl.style.display = "none";
      }

      document.getElementById("drawerNotes").textContent = node.notes || 'لا توجد ملاحظات إضافية لهذا المفهوم.';
      document.getElementById("node-drawer").classList.add("open");
    }

    document.getElementById("btnCloseDrawer").addEventListener("click", () => {
      document.getElementById("node-drawer").classList.remove("open");
    });

    document.getElementById("btnTree").addEventListener("click", function() {
      currentLayout = 'tree';
      this.classList.add("active");
      document.getElementById("btnRadial").classList.remove("active");
      render();
    });

    document.getElementById("btnRadial").addEventListener("click", function() {
      currentLayout = 'radial';
      this.classList.add("active");
      document.getElementById("btnTree").classList.remove("active");
      render();
    });

    document.getElementById("btnExpandAll").addEventListener("click", () => {
      expandAllNodes(treeData);
      render();
    });

    document.getElementById("btnCollapseAll").addEventListener("click", () => {
      collapseAllNodes(treeData, 0);
      render();
    });

    document.getElementById("searchInput").addEventListener("input", (e) => {
      searchQuery = e.target.value.trim();
      render();
    });

    document.getElementById("btnZoomIn").addEventListener("click", () => {
      svg.transition().duration(250).call(zoom.scaleBy, 1.3);
    });

    document.getElementById("btnZoomOut").addEventListener("click", () => {
      svg.transition().duration(250).call(zoom.scaleBy, 0.75);
    });

    document.getElementById("btnReset").addEventListener("click", resetView);

    document.getElementById("btnTheme").addEventListener("click", () => {
      const isDark = document.documentElement.getAttribute("data-theme") === "dark";
      document.documentElement.setAttribute("data-theme", isDark ? "light" : "dark");
      render();
    });

    document.getElementById("btnPrint").addEventListener("click", () => window.print());

    window.addEventListener("resize", render);
    render();
    resetView();
  </script>
</body>
</html>`;
}
