// Deep Interactive Mind Map Parser & Generator
// Converts any text, conversation message, AI explanation, or study notes
// into a rich, multi-tiered, hierarchical MindMapNode tree
// Developed by: فريق D.CORE الذكي

import { MindMapNode } from '../types';

const BRANCH_COLORS = [
  '#0f766e', // Deep Teal
  '#0284c7', // Sky Blue
  '#7c3aed', // Violet
  '#d97706', // Amber
  '#059669', // Emerald
  '#dc2626', // Crimson
  '#0891b2', // Cyan
  '#4f46e5', // Indigo
];

/**
 * Parses any text or AI response into a deep, multi-tiered interactive mind map tree
 */
export function buildDeepMindMapFromText(rawText: string, fallbackTitle?: string): MindMapNode {
  if (!rawText || !rawText.trim()) {
    return {
      id: 'empty-root',
      title: fallbackTitle || 'المفهوم الرئيسي',
      level: 0,
      color: '#0f766e',
      badge: 'فكرة مركزية',
      notes: 'خريطة ذهنية تفاعلية جديدة.',
      children: [],
    };
  }

  const cleanText = rawText.replace(/\r\n/g, '\n');
  const lines = cleanText.split('\n');

  // 1. Identify Root Title
  let rootTitle = (fallbackTitle || '').trim();
  if (!rootTitle || rootTitle.length < 3) {
    for (const l of lines) {
      const trimmed = l.trim();
      if (trimmed.startsWith('# ') || trimmed.startsWith('## ')) {
        rootTitle = trimmed.replace(/^#+\s*/, '').replace(/[💡📘🎯📋*#]/g, '').trim();
        break;
      }
    }
  }

  if (!rootTitle) {
    const firstNonEmpty = lines.find((l) => l.trim().length > 3)?.trim() || 'المفهوم الأكاديمي';
    rootTitle = firstNonEmpty.slice(0, 35).replace(/^[#\-*\d.]+\s*/, '');
  }

  // 2. Extract Headings and Structural Sections
  interface SectionBlock {
    title: string;
    level: number;
    lines: string[];
    formula?: string;
  }

  const sections: SectionBlock[] = [];
  let currentSection: SectionBlock | null = null;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const trimmed = line.trim();
    if (!trimmed) continue;

    // Detect Level 1/2 headings or numbered pillars
    const isHeading2 = trimmed.startsWith('## ') && !trimmed.startsWith('### ');
    const isHeading3 = trimmed.startsWith('### ');
    const isPillar = /^(أولاً|ثانياً|ثالثاً|رابعاً|خامساً|سادساً|المحور|القسم|الوحدة|الفصل|الباب)\s*[:：\-]/i.test(trimmed);
    const isNumberedPillar = /^[1-9]\s*[\-\.)]\s*([^\n]{3,60})$/.test(trimmed) && trimmed.length < 70;

    if (isHeading2 || isPillar || (isNumberedPillar && !currentSection)) {
      if (currentSection) {
        sections.push(currentSection);
      }
      const titleClean = trimmed
        .replace(/^##\s*/, '')
        .replace(/^[1-9]\s*[\-\.)]\s*/, '')
        .replace(/[💡📘🎯📋*#]/g, '')
        .trim();

      currentSection = {
        title: titleClean.length > 40 ? titleClean.slice(0, 38) + '...' : titleClean,
        level: 1,
        lines: [],
      };
      continue;
    }

    if (isHeading3) {
      if (currentSection) {
        sections.push(currentSection);
      }
      const titleClean = trimmed.replace(/^###\s*/, '').replace(/[💡📘🎯📋*#]/g, '').trim();
      currentSection = {
        title: titleClean.length > 40 ? titleClean.slice(0, 38) + '...' : titleClean,
        level: 2,
        lines: [],
      };
      continue;
    }

    if (currentSection) {
      currentSection.lines.push(trimmed);
    } else {
      // Intro lines before any heading
      if (!currentSection) {
        currentSection = {
          title: 'المدخل التأسيسي والمفاهيم الأولية',
          level: 1,
          lines: [trimmed],
        };
      }
    }
  }

  if (currentSection) {
    sections.push(currentSection);
  }

  // 3. Fallback if no markdown headings were detected: break by paragraphs or sentences
  if (sections.length <= 1) {
    const paragraphs = cleanText
      .split(/\n\s*\n/)
      .map((p) => p.trim())
      .filter((p) => p.length > 15);

    if (paragraphs.length > 1) {
      sections.length = 0;
      paragraphs.forEach((p, idx) => {
        const firstLine = p.split('\n')[0].replace(/[#*\-]/g, '').trim();
        sections.push({
          title: firstLine.length > 35 ? firstLine.slice(0, 32) + '...' : firstLine,
          level: 1,
          lines: p.split('\n').slice(1),
        });
      });
    }
  }

  // 4. Transform sections into deeply nested MindMapNode structures
  const children: MindMapNode[] = [];

  sections.slice(0, 8).forEach((sec, sIdx) => {
    const secColor = BRANCH_COLORS[sIdx % BRANCH_COLORS.length];
    const secNodeId = `sec-branch-${sIdx + 1}`;

    // Extract formulas in this section
    const secText = sec.lines.join('\n');
    const mathMatch = secText.match(/\$\$([^$]+)\$\$/) || secText.match(/\$([^$]+)\$/);
    const formula = mathMatch ? mathMatch[1].trim() : undefined;

    // Sub-items: find bullet points, numbers, or key definitions
    const subChildren: MindMapNode[] = [];
    const bulletLines = sec.lines.filter(
      (l) => l.startsWith('- ') || l.startsWith('* ') || /^[1-9]\s*[\-\.)]/.test(l)
    );

    if (bulletLines.length > 0) {
      bulletLines.slice(0, 6).forEach((bl, bIdx) => {
        const cleanBullet = bl.replace(/^[-*•]\s*/, '').replace(/^[1-9]\s*[\-\.)]\s*/, '').trim();
        const boldPart = cleanBullet.match(/\*\*([^\*]+)\*\*/)?.[1];
        const subTitle = boldPart || cleanBullet.split(/[:：]/)[0] || cleanBullet.slice(0, 30);

        // Check for formula inside this bullet
        const bMath = cleanBullet.match(/\$([^$]+)\$/);

        // Sub-details (Level 3)
        const microDetails: MindMapNode[] = [];
        if (cleanBullet.length > subTitle.length + 10) {
          const detailText = cleanBullet.replace(new RegExp(`^\\*\\*${subTitle}\\*\\*[:：]?\\s*`), '');
          microDetails.push({
            id: `${secNodeId}-sub-${bIdx + 1}-detail`,
            title: detailText.length > 32 ? detailText.slice(0, 30) + '...' : detailText,
            level: 3,
            color: secColor,
            badge: 'تفصيل دقيق',
            notes: detailText,
            formula: bMath ? bMath[1].trim() : undefined,
          });
        }

        subChildren.push({
          id: `${secNodeId}-sub-${bIdx + 1}`,
          title: subTitle.length > 30 ? subTitle.slice(0, 28) + '...' : subTitle,
          level: 2,
          color: secColor,
          badge: `عنصر ${bIdx + 1}`,
          notes: cleanBullet,
          formula: bMath ? bMath[1].trim() : undefined,
          children: microDetails.length > 0 ? microDetails : undefined,
        });
      });
    } else {
      // Create semantic analytical sub-branches from text paragraphs
      const meaningfulLines = sec.lines.filter((l) => l.length > 10).slice(0, 4);
      meaningfulLines.forEach((ml, mIdx) => {
        const mTitle = ml.split(/[:：.،]/)[0].trim() || `تفريعة ${mIdx + 1}`;
        subChildren.push({
          id: `${secNodeId}-sub-${mIdx + 1}`,
          title: mTitle.length > 28 ? mTitle.slice(0, 26) + '...' : mTitle,
          level: 2,
          color: secColor,
          badge: 'مفهوم فرعي',
          notes: ml,
          formula: ml.match(/\$([^$]+)\$/)?.[1],
        });
      });
    }

    // Always guarantee at least one sub-branch for depth
    if (subChildren.length === 0) {
      subChildren.push({
        id: `${secNodeId}-sub-core`,
        title: 'الجوهر والشرح التفصيلي',
        level: 2,
        color: secColor,
        badge: 'تأصيل',
        notes: sec.lines.join('\n') || 'تفاصيل المحور الأكاديمي.',
      });
    }

    children.push({
      id: secNodeId,
      title: sec.title,
      level: 1,
      color: secColor,
      badge: `${subChildren.length} تفريعات`,
      notes: sec.lines.join('\n') || `المحور: ${sec.title}`,
      formula,
      children: subChildren,
    });
  });

  // Guarantee root has children
  if (children.length === 0) {
    children.push(
      {
        id: 'sec-1',
        title: 'التعريف والأساس العلمي',
        level: 1,
        color: '#0f766e',
        badge: 'تأسيس',
        notes: 'الأساس المعرفي والتعريف المنهجي للموضوع.',
        children: [
          {
            id: 'sec-1-sub-1',
            title: 'المبادئ والقوانين الحاكمة',
            level: 2,
            color: '#0f766e',
            notes: 'القواعد الأساسية المؤطرة لهذا المفهوم.',
          },
        ],
      },
      {
        id: 'sec-2',
        title: 'التطبيقات والمسائل النموذجية',
        level: 1,
        color: '#0284c7',
        badge: 'تطبيق',
        notes: 'الأمثلة الحسابية والتطبيقات العملية في الامتحانات.',
        children: [
          {
            id: 'sec-2-sub-1',
            title: 'خطوات الحل المنهجي',
            level: 2,
            color: '#0284c7',
            notes: 'المعطيات، المطلوب، القانون، والتعويض.',
          },
        ],
      }
    );
  }

  return {
    id: 'deep-mindmap-root',
    title: rootTitle,
    level: 0,
    color: '#0f766e',
    badge: 'خريطة تفاعلية شاملة',
    notes: `خريطة ذهنية تفاعلية متفرعة وشاملة لكافة الأقسام والمفاهيم. تم استخراجها وتنسيقها بواسطة المعلم الذكي - فريق D.CORE الذكي.`,
    children,
  };
}
