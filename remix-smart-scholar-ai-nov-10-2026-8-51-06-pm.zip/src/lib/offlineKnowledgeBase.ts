export interface OfflineKnowledgeEntry {
  id: string;
  title: string;
  category: string;
  keywords: string[];
  summary: string;
  details: string;
  formulaOrRule?: string;
}

/** Curated, versioned facts that ship with the app and remain available offline. */
export const OFFLINE_KNOWLEDGE_BASE: OfflineKnowledgeEntry[] = [
  { id: 'math-pythagoras', title: 'نظرية فيثاغورس', category: 'الرياضيات والهندسة', keywords: ['فيثاغورس', 'مثلث قائم', 'وتر'], summary: 'في المثلث القائم، مربع طول الوتر يساوي مجموع مربعي طولي الضلعين القائمين.', details: 'إذا كان a و b ضلعي القائمة و c الوتر، فاحسب c بعد التحقق من أن الزاوية قائمة. النتيجة طولية ولا تمثل مساحة.', formulaOrRule: 'c^2 = a^2 + b^2' },
  { id: 'math-derivative', title: 'المشتقة', category: 'الرياضيات والتفاضل', keywords: ['مشتقة', 'تفاضل', 'معدل التغير'], summary: 'المشتقة تقيس معدل تغير الدالة بالنسبة إلى متغيرها، وتساوي ميل المماس عند نقطة.', details: 'للدالة كثيرة الحدود نشتق كل حد وفق قاعدة القوة، ثم نجمع النتائج. يجب تحديد مجال الدالة قبل تفسير النتيجة.', formulaOrRule: '\\frac{d}{dx}x^n = nx^{n-1}' },
  { id: 'physics-newton', title: 'قانون نيوتن الثاني', category: 'الفيزياء والميكانيكا', keywords: ['نيوتن', 'قوة', 'كتلة', 'تسارع'], summary: 'محصلة القوى المؤثرة في جسم تساوي حاصل ضرب كتلته في تسارعه.', details: 'اختر محوراً واتجاهاً موجباً، ارسم مخطط القوى، وحوّل الوحدات إلى النظام الدولي قبل التعويض.', formulaOrRule: 'F = m \\cdot a' },
  { id: 'physics-energy', title: 'حفظ الطاقة', category: 'الفيزياء والطاقة', keywords: ['طاقة', 'حفظ الطاقة', 'طاقة حركة', 'طاقة وضع'], summary: 'الطاقة لا تفنى ولا تستحدث في نظام معزول، لكنها تتحول بين صور مختلفة.', details: 'قارن الطاقة الابتدائية بالنهائية، وأدرج الشغل الخارجي أو الفقد الحراري عندما يكون النظام غير معزول.', formulaOrRule: 'E_{initial} + W_{external} = E_{final}' },
  { id: 'chem-ph', title: 'الرقم الهيدروجيني', category: 'الكيمياء والمحاليل', keywords: ['ph', 'حموضة', 'قاعدية', 'هيدروجين'], summary: 'يقيس pH حموضة المحلول على مقياس لوغاريتمي؛ انخفاضه يعني زيادة تركيز أيونات الهيدروجين.', details: 'القيمة 7 تقريباً متعادلة عند 25 درجة مئوية، والقيم الأقل حمضية والأعلى قاعدية. لا تُقارن المحاليل دون مراعاة درجة الحرارة والتركيز.', formulaOrRule: 'pH = -\\log_{10}[H^+]' },
  { id: 'biology-cell', title: 'نظرية الخلية', category: 'الأحياء والعلوم الحيوية', keywords: ['خلية', 'نظرية الخلية', 'كائن حي'], summary: 'الخلية هي وحدة البناء والوظيفة الأساسية في الكائنات الحية، وكل خلية تنشأ من خلية سابقة.', details: 'تختلف الخلايا بدائية النوى عن حقيقية النوى في وجود النواة المحاطة بغشاء والعضيات الغشائية.', formulaOrRule: undefined },
  { id: 'medicine-homeostasis', title: 'الاتزان الداخلي', category: 'الطب والصحة', keywords: ['اتزان داخلي', 'homeostasis', 'حرارة', 'هرمونات'], summary: 'يحافظ الجسم على ثبات نسبي للبيئة الداخلية عبر مستقبلات ومراكز تحكم وأعضاء منفذة.', details: 'غالباً تعمل حلقات التغذية الراجعة السلبية على إعادة المتغير إلى المجال الطبيعي. هذه معلومة تعليمية وليست تشخيصاً أو بديلاً عن الطبيب.', formulaOrRule: undefined },
  { id: 'computer-algorithm', title: 'الخوارزمية', category: 'علوم الحاسوب', keywords: ['خوارزمية', 'تعقيد', 'برمجة'], summary: 'الخوارزمية خطوات محددة ومنتهية لحل مشكلة أو تنفيذ مهمة.', details: 'الخوارزمية الجيدة واضحة وقابلة للتنفيذ، ويُقاس أداؤها عادةً بزمن التنفيذ واستهلاك الذاكرة بالنسبة إلى حجم المدخلات.', formulaOrRule: 'O(n), O(n\\log n), O(n^2)' },
  { id: 'ai-transformer', title: 'آلية الانتباه الذاتي', category: 'الذكاء الاصطناعي', keywords: ['ذكاء اصطناعي', 'transformer', 'انتباه', 'تعلم آلي'], summary: 'تسمح آلية الانتباه الذاتي للنموذج بوزن علاقة كل رمز بالرموز الأخرى في السياق.', details: 'تُحوّل المدخلات إلى استعلامات ومفاتيح وقيم، ثم تُحسب أوزان التشابه قبل تجميع القيم. النتيجة تعتمد على بيانات التدريب ولا تضمن صحة كل إجابة.', formulaOrRule: 'Attention(Q,K,V)=softmax(\\frac{QK^T}{\\sqrt{d_k}})V' },
  { id: 'history-civilization', title: 'منهج دراسة الحضارات', category: 'التاريخ والحضارات', keywords: ['تاريخ', 'حضارة', 'مصدر تاريخي'], summary: 'تُدرس الحضارات عبر مقارنة الأدلة المادية والنصية والسياق الزمني والجغرافي.', details: 'ينبغي التمييز بين المصدر الأولي والتفسير اللاحق، وذكر درجة اليقين عند وجود خلاف بين الباحثين.', formulaOrRule: undefined },
  { id: 'arabic-nahw', title: 'المبتدأ والخبر', category: 'اللغة العربية', keywords: ['مبتدأ', 'خبر', 'نحو', 'إعراب'], summary: 'الجملة الاسمية تتكون غالباً من مبتدأ مرفوع وخبر يكمّل معناه، مع وجود صور واستثناءات نحوية.', details: 'حدّد العامل والسياق أولاً، ثم اضبط الإعراب بحسب موقع الكلمة لا بحسب ترتيبها الظاهري فقط.', formulaOrRule: undefined },
  { id: 'research-literacy', title: 'التحقق من المعلومات', category: 'منهجية البحث', keywords: ['مصدر', 'تحقق', 'موسوعة', 'معلومة'], summary: 'تزداد موثوقية المعلومة بمقارنتها بين مصادر مستقلة ومتخصصة وحديثة، مع التمييز بين الحقيقة والرأي.', details: 'المحتوى المدمج هنا مرجع تمهيدي قابل للتوسعة وليس موسوعة كاملة. عند الاتصال بالإنترنت يمكن إرفاق مصادر حديثة، وعند عدمه يجب التصريح بحدود المعرفة.', formulaOrRule: undefined },
];

export function searchOfflineKnowledge(query: string): OfflineKnowledgeEntry[] {
  const normalized = query.trim().toLocaleLowerCase('ar');
  if (!normalized) return [];
  const tokens = normalized.split(/\\s+/).filter((token) => token.length > 1);
  return OFFLINE_KNOWLEDGE_BASE
    .map((entry) => {
      const searchableText = `${entry.title} ${entry.category} ${entry.keywords.join(' ')} ${entry.summary}`.toLocaleLowerCase('ar');
      const score = tokens.reduce((total, token) => total + (searchableText.includes(token) ? 1 : 0), 0);
      return { entry, score };
    })
    .filter(({ score }) => score > 0)
    .sort((a, b) => b.score - a.score)
    .map(({ entry }) => entry);
}
