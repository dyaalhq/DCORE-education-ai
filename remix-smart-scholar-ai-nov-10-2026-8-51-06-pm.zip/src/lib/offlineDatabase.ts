import Dexie, { Table } from 'dexie';
import { BankQuestion, QuestionSection, DifficultyLevel, QuestionType } from './questionBankData';

export interface EncyclopediaArticle {
  id: string;
  slug: string;
  title: string;
  category: string;
  subCategory?: string;
  summary: string;
  markdownContent: string;
  formulaLatex?: string;
  keyConcepts: string[];
  historicalEra?: string;
  references: string[];
  readingTimeMinutes: number;
  lastUpdated: string;
  tags: string[];
}

export interface UserExamRecord {
  id?: number;
  section: QuestionSection;
  subject: string;
  stageOrBlock?: string;
  totalQuestions: number;
  correctAnswers: number;
  scorePercentage: number;
  timeSpentSeconds: number;
  date: number;
  wrongQuestionIds: string[];
}

export interface UserBookmark {
  questionId: string;
  savedAt: number;
  note?: string;
}

export class ScholarOfflineDatabase extends Dexie {
  questions!: Table<BankQuestion, string>;
  encyclopedia!: Table<EncyclopediaArticle, string>;
  examRecords!: Table<UserExamRecord, number>;
  bookmarks!: Table<UserBookmark, string>;

  constructor() {
    super('AlMuallemSmartScholarDB');

    this.version(1).stores({
      questions: 'id, section, stage, medicalBlock, subject, unitOrTopic, difficulty, year, *tags',
      encyclopedia: 'id, slug, title, category, *keyConcepts, *tags',
      examRecords: '++id, section, subject, date, scorePercentage',
      bookmarks: 'questionId, savedAt',
    });
  }
}

export const offlineDb = new ScholarOfflineDatabase();

/**
 * High-performance full-text indexed search for offline questions
 */
export async function searchOfflineQuestions(params: {
  section?: QuestionSection;
  stage?: string;
  medicalBlock?: string;
  subject?: string;
  difficulty?: DifficultyLevel;
  type?: QuestionType;
  query?: string;
  limit?: number;
  offset?: number;
}): Promise<{ items: BankQuestion[]; total: number }> {
  try {
    let collection = offlineDb.questions.toCollection();

    if (params.section) {
      collection = offlineDb.questions.where('section').equals(params.section);
    }

    let items = await collection.toArray();

    if (params.stage) {
      items = items.filter((q) => q.stage === params.stage);
    }
    if (params.medicalBlock) {
      items = items.filter((q) => q.medicalBlock === params.medicalBlock);
    }
    if (params.subject && params.subject !== 'الكل') {
      items = items.filter((q) => q.subject === params.subject);
    }
    if (params.difficulty) {
      items = items.filter((q) => q.difficulty === params.difficulty);
    }
    if (params.type) {
      items = items.filter((q) => q.type === params.type);
    }

    if (params.query && params.query.trim()) {
      const qLower = params.query.toLowerCase().trim();
      items = items.filter((q) => {
        return (
          q.question.toLowerCase().includes(qLower) ||
          q.explanation.toLowerCase().includes(qLower) ||
          q.subject.toLowerCase().includes(qLower) ||
          q.unitOrTopic.toLowerCase().includes(qLower) ||
          (q.options && q.options.some((o) => o.toLowerCase().includes(qLower))) ||
          (q.tags && q.tags.some((t) => t.toLowerCase().includes(qLower))) ||
          (q.clinicalContext?.scenarioAr && q.clinicalContext.scenarioAr.toLowerCase().includes(qLower)) ||
          (q.clinicalContext?.scenarioEn && q.clinicalContext.scenarioEn.toLowerCase().includes(qLower))
        );
      });
    }

    const total = items.length;
    const offset = params.offset || 0;
    const limit = params.limit || 50;

    return {
      items: items.slice(offset, offset + limit),
      total,
    };
  } catch (e) {
    console.warn('Failed to query offline questions from IndexedDB:', e);
    return { items: [], total: 0 };
  }
}

/**
 * Save user bookmark in IndexedDB
 */
export async function toggleOfflineBookmark(questionId: string): Promise<boolean> {
  const existing = await offlineDb.bookmarks.get(questionId);
  if (existing) {
    await offlineDb.bookmarks.delete(questionId);
    return false;
  } else {
    await offlineDb.bookmarks.put({ questionId, savedAt: Date.now() });
    return true;
  }
}

export async function getBookmarkedQuestionIds(): Promise<Set<string>> {
  const bookmarks = await offlineDb.bookmarks.toArray();
  return new Set(bookmarks.map((b) => b.questionId));
}

/**
 * Record an exam attempt
 */
export async function recordExamAttempt(record: Omit<UserExamRecord, 'id'>): Promise<number> {
  return await offlineDb.examRecords.add(record);
}

export async function getExamRecords(): Promise<UserExamRecord[]> {
  return await offlineDb.examRecords.orderBy('date').reverse().toArray();
}
