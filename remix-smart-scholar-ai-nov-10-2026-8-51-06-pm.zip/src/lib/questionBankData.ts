/**
 * Comprehensive Offline Question Bank & Universal Encyclopedia Repository
 * بنك الأسئلة الشامل: الوزاري اليمني (تاسع وثالث ثانوي) + الطبي السريري + العام الموسوعي
 * 100% Offline Capable - لا يتطلب إنترنت ويعمل تحت أي ظرف محلياً وبدقة متناهية
 */

import { COMPREHENSIVE_ENCYCLOPEDIA_ARTICLES } from './encyclopediaData';
import { YEMENI_CURRICULUM_AND_KNOWLEDGE_BANKS } from './yemeniCurriculumBank';

export type QuestionSection = 'ministerial' | 'medical' | 'universal';
export type QuestionType = 'mcq' | 'true_false' | 'explain' | 'problem' | 'clinical' | 'fill';
export type DifficultyLevel = 'easy' | 'medium' | 'hard';

export interface BankQuestion {
  id: string;
  section: QuestionSection;
  // Metadata for ministerial
  stage?: 'تاسع أساسي' | 'ثالث ثانوي علمي' | 'ثالث ثانوي أدبي';
  // Metadata for medical
  medicalBlock?: string;
  medicalSpecialty?: string;
  // Shared metadata
  subject: string;
  unitOrTopic: string;
  year?: string; // e.g. '2024', '2023', 'وزاري 2022'
  difficulty: DifficultyLevel;
  type: QuestionType;
  question: string;
  options?: string[];
  correctAnswer: string | number; // index or text
  explanation: string;
  formulaOrRule?: string; // LaTeX
  clinicalContext?: {
    scenarioEn?: string;
    scenarioAr?: string;
    highYieldConcept?: string;
  };
  tags: string[];
}

export const MINISTERIAL_SUBJECTS = {
  grade9: ['العلوم', 'الرياضيات', 'اللغة العربية', 'القرآن والإسلامية', 'الاجتماعيات', 'اللغة الإنجليزية'],
  sec3_sci: ['الفيزياء', 'الكيمياء', 'الأحياء', 'الرياضيات (تفاضل وتكامل وجبر)', 'اللغة العربية', 'القرآن والإسلامية', 'اللغة الإنجليزية'],
  sec3_lit: ['التاريخ الحديث', 'الجغرافيا', 'الفلسفة وعلم النفس', 'اللغة العربية', 'القرآن والإسلامية', 'اللغة الإنجليزية'],
};

export const SUBJECT_UNITS_MAP: Record<string, string[]> = {
  'الفيزياء': [
    'كافة الوحدات والدروس',
    'دوائر التيار المتردد والرنين',
    'المحول الكهربائي والحث الكهرومغناطيسي',
    'الظاهرة الكهروضوئية وفرضية أينشتاين',
    'الأشعة السينية والفيزياء الذرية',
    'أشباه الموصلات والترانزستور والإلكترونيات',
    'المقذوفات والديناميكا الميكانيكية'
  ],
  'الكيمياء': [
    'كافة الوحدات والدروس',
    'الاتزان الكيميائي ومبدأ لوشاتيليه',
    'الأحماض والقواعد ومحاليل البفر المنظمة',
    'الكيمياء الكهربائية والخلايا الجلفانية',
    'الكيمياء العضوية وتفاعلات الأسترة والبلمرة',
    'حركية التفاعلات وسرعة التفاعل الكيميائي'
  ],
  'الأحياء': [
    'كافة الوحدات والدروس',
    'الوراثة الجزيئية والحمض النووي DNA',
    'علم الوراثة المندلية وتوارث الصفات',
    'التكاثر والتطور الجنيني في الإنسان والكائنات',
    'المناعة البشرية والاستجابة المناعية',
    'الجهاز العصبي والهرمونات والتنظيم الحيوي'
  ],
  'الرياضيات (تفاضل وتكامل وجبر)': [
    'كافة الوحدات والدروس',
    'التفاضل والمشتقات والنهايات وقواعد الاشتقاق',
    'تطبيقات التفاضل (القيم العظمى والصغرى ونقاط الانقلاب)',
    'التكامل المحدود وغير المحدود وحساب المساحات',
    'الأعداد المركبة ومبرهنة ديموافر والجذور النونية',
    'المصفوفات والمحددات وحل المعادلات الخطية',
    'الهندسة التحليلية والفراغية والمتجهات'
  ],
  'الرياضيات': [
    'كافة الوحدات والدروس',
    'الجبر وتحليل المقادير وحل المعادلات',
    'الهندسة المستوية والمثلثات',
    'المجموعات والعلاقات والتطبيقات',
    'الإحصاء والاحتمالات وحساب المقاييس'
  ],
  'اللغة العربية': [
    'كافة الوحدات والدروس',
    'النحو: الجملة الاسمية ونواسخها (كان وإن)',
    'النحو: المفاعيل الخمسة والتوابع والاستثناء',
    'الصرف: الميزان الصرفي والمشتقات والمصادر',
    'البلاغة: البيان والبديع والمحسنات وعلم المعاني',
    'الأدب والنصوص وتحليل الشعر العربي واليمني'
  ],
  'القرآن والإسلامية': [
    'كافة الوحدات والدروس',
    'أحكام التجويد ومخارج الحروف والصفات الصوتية',
    'الفرائض والمواريث الفقهية وتوزيع التركات',
    'العقيدة الإسلامية والتوحيد ومقاصد الشريعة',
    'السيرة النبوية والتاريخ الإسلامي والفتوحات'
  ],
  'اللغة الإنجليزية': [
    'All Units & Lessons',
    'Grammar: Tenses & Time Clauses',
    'Passive Voice & Indirect Speech',
    'Conditionals (If Types 1, 2, 3) & Modals',
    'Academic Vocabulary & Reading Comprehension'
  ],
  'العلوم': [
    'كافة الوحدات والدروس',
    'الفيزياء: القوة والحركة والكهرباء والمغناطيس',
    'الكيمياء: العناصر والجدول الدوري والتفاعلات',
    'الأحياء: الخلية والتكاثر والوراثة والبيئة',
    'علوم الأرض والفضاء والكون والمناخ'
  ],
  'الاجتماعيات': [
    'كافة الوحدات والدروس',
    'تاريخ اليمن القديم وحضارات سبأ وحمير',
    'جغرافية الوطن العربي واليمن والتضاريس',
    'التربية الوطنية ومفاهيم الدستور والمواطنة'
  ],
  'التاريخ الحديث': [
    'كافة الوحدات والدروس',
    'حضارات اليمن القديم وسد مأرب وطريق اللبان',
    'تاريخ الثورة اليمنية 26 سبتمبر و 14 أكتوبر',
    'التاريخ العربي والإسلامي المعاصر وحركات التحرر'
  ],
  'الجغرافيا': [
    'كافة الوحدات والدروس',
    'جغرافية اليمن الطبيعية والتضاريس والمناخ',
    'الجغرافيا الاقتصادية والموارد المائية والزراعية',
    'الجغرافيا البشرية والسكان والتخطيط الإقليمي'
  ],
  'الفلسفة وعلم النفس': [
    'كافة الوحدات والدروس',
    'فلسفة المعرفة والمنطق الصوري ومناهج البحث',
    'علم النفس والدوافع والعمليات المعرفية والإدراك',
    'الفلسفة الإسلامية والتوفيق بين العقل والنقل'
  ]
};

export const MEDICAL_BLOCKS = [
  'Foundation & Cell Biology',
  'Cardiovascular System (CVS)',
  'Respiratory System (RS)',
  'Gastrointestinal System (GIT)',
  'Central Nervous System (CNS)',
  'Endocrine & Metabolism',
  'Renal & Urinary System',
  'Musculoskeletal System (MSK)',
  'Hematology & Oncology',
  'Pharmacology & Therapeutics',
  'General Pathology & Microbiology',
  'Internal Medicine & Surgery'
];

export const UNIVERSAL_CATEGORIES = [
  'الفيزياء والكونيات',
  'الكيمياء وعلوم المواد',
  'الرياضيات والخوارزميات',
  'علوم الحاسوب والذكاء الاصطناعي',
  'الطب والعلوم الحيوية',
  'التاريخ والحضارات الإنسانية',
  'الأدب واللغة العربية والبلاغة',
  'الفلسفة ونظرية المعرفة',
  'العلوم الشرعية وأصول الفقه'
];

export const QUESTION_BANK_DATABASE: BankQuestion[] = [
  // ==========================================
  // 1. الجزء الوزاري - المنهج اليمني - ثالث ثانوي علمي
  // ==========================================

  // فيزياء ثالث ثانوي (المنهج اليمني - رموز عربية معتمدة)
  {
    id: 'ye_sec3_phy_001',
    section: 'ministerial',
    stage: 'ثالث ثانوي علمي',
    subject: 'الفيزياء',
    unitOrTopic: 'الوحدة الأولى: التيار المتردد والدوائر المهتزة',
    year: 'وزاري 2024',
    difficulty: 'medium',
    type: 'mcq',
    question: 'في دائرة التيار المتردد التي تحتوي على ملف حث نقي عديم المقاومة، تكون العلاقة بين فرق الجهد والتيار:',
    options: [
      'يتفق الجهد مع التيار في الطور',
      'يتقدم الجهد على التيار بزاوية طور 90 درجة (π/2)',
      'يتأخر الجهد عن التيار بزاوية طور 90 درجة',
      'يتأخر الجهد عن التيار بزاوية طور 180 درجة'
    ],
    correctAnswer: 1,
    explanation: 'في ملف الحث النقي، تتولد قوة دافعة كهربائية حثية عكسية تعاكس نمو التيار اللحظي طبقاً لقانون لنز، فيسبق الجهد الكهربائي التيار بربع دورة أي بزاوية طور مقدارها 90 درجة ($\\phi = +\\pi/2$).',
    formulaOrRule: '$جـ_{\\text{حـ}} = \\text{حـ} \\frac{\\Delta ت}{\\Delta ز} \\implies جـ(ز) = جـ_{\\text{عظمى}} \\sin(\\omega ز + \\frac{\\pi}{2})$',
    tags: ['تيار متردد', 'ملف حث', 'طور', 'وزاري']
  },
  {
    id: 'ye_sec3_phy_002',
    section: 'ministerial',
    stage: 'ثالث ثانوي علمي',
    subject: 'الفيزياء',
    unitOrTopic: 'الوحدة الأولى: الرنين الكهربائي',
    year: 'وزاري 2023',
    difficulty: 'easy',
    type: 'mcq',
    question: 'عند حدوث حالة الرنين في دائرة متوالية تحوي مقاومة وملف حث ومكثفاً، تكون معاوقة الدائرة الكلية مساوية لـ:',
    options: [
      'المفاعلة الحثية م_حـ',
      'المفاعلة السعوية م_س',
      'المقاومة الأومية م وتكون عند قيمتها الصغرى',
      'الصفر المطلق'
    ],
    correctAnswer: 2,
    explanation: 'عند الرنين تتساوى المفاعلة الحثية مع المفاعلة السعوية ($م_{\\text{حـ}} = م_{\\text{س}}$)، فيتلاشى الفرق بينهما وتصبح المعاوقة الكلية مساوية للمقاومة الأومية فقط ($م_{\\text{ك}} = م$)، ويكون التيار المار في أقصى قيمة له.',
    formulaOrRule: '$م_{\\text{ك}} = \\sqrt{م^2 + (م_{\\text{حـ}} - م_{\\text{س}})^2} = \\sqrt{م^2 + 0} = م$',
    tags: ['رنين', 'معاوقة', 'أتمتة']
  },
  {
    id: 'ye_sec3_phy_003',
    section: 'ministerial',
    stage: 'ثالث ثانوي علمي',
    subject: 'الفيزياء',
    unitOrTopic: 'الوحدة الأولى: حساب تردد الرنين',
    year: 'وزاري 2024',
    difficulty: 'hard',
    type: 'problem',
    question: 'مسألة وزارية: دائرة تيار متردد تحتوي على ملف حث معامل حثه الذاتي $\\text{حـ} = \\frac{1}{\\pi}\\text{ هنري}$ ومكثف سعته $\\text{س} = \\frac{100}{\\pi}\\ \\mu\\text{F}$ (ميكروفاراد). التردد الرنيني $د_0$ الذي يحدث عنده رنين في الدائرة يساوي:',
    options: [
      'د_0 = 50 هرتز',
      'د_0 = 100 هرتز',
      'د_0 = 25 هرتز',
      'د_0 = 200 هرتز'
    ],
    correctAnswer: 0,
    explanation: 'الخطوات الوزارية النموذجية:\n1. المعطيات: $\\text{حـ} = \\frac{1}{\\pi}\\text{ هنري}$، $\\text{س} = \\frac{100}{\\pi} \\times 10^{-6}\\text{ فاراد} = \\frac{10^{-4}}{\\pi}\\text{ فاراد}$.\n2. القانون: $د_0 = \\frac{1}{2 \\pi \\sqrt{\\text{حـ} \\times \\text{س}}}$\n3. التعويض: $\\text{حـ} \\times \\text{س} = \\frac{1}{\\pi} \\times \\frac{10^{-4}}{\\pi} = \\frac{10^{-4}}{\\pi^2}$\n4. الجذر: $\\sqrt{\\text{حـ} \\times \\text{س}} = \\frac{10^{-2}}{\\pi}$\n5. الناتج النهائي: $د_0 = \\frac{1}{2 \\pi (10^{-2} / \\pi)} = \\frac{1}{2 \\times 10^{-2}} = \\frac{100}{2} = 50\\text{ هرتز}$.',
    formulaOrRule: '$د_0 = \\frac{1}{2 \\pi \\sqrt{\\text{حـ} \\times \\text{س}}}$',
    tags: ['مسألة', 'رنين', 'حسابات', 'خطوات حل']
  },
  {
    id: 'ye_sec3_phy_004',
    section: 'ministerial',
    stage: 'ثالث ثانوي علمي',
    subject: 'الفيزياء',
    unitOrTopic: 'الوحدة الثانية: الإلكترونيات وأشباه الموصلات',
    year: 'وزاري 2023',
    difficulty: 'medium',
    type: 'true_false',
    question: 'صح أم خطأ مع التعليل: بلورة شبه الموصل من النوع السالب (n-type) تحمل شحنة كهربائية سالبة كلية.',
    options: [
      'صح، لأن الإلكترونات السالبة هي حاملات الشحنة الأغلبية فيها.',
      'خطأ، البلورة متعادلة كهربائياً لأن عدد الإلكترونات يساوي عدد البروتونات الموجبة في ذرات البلورة والشوائب.'
    ],
    correctAnswer: 1,
    explanation: 'البلورة متعادلة كهربائياً (شحنتها الكلية = صفر)؛ لأن ذرات الشائبة الخماسية المانحة تفقد إلكتروناً وتتحول إلى أيونات موجبة مقيدة في الشبكة البلورية، فيكون مجموع الشحنات السالبة الكلية مساوياً لمجموع الشحنات الموجبة الكلية.',
    tags: ['أشباه موصلات', 'n-type', 'تعليل', 'صح وخطأ']
  },
  {
    id: 'ye_sec3_phy_005',
    section: 'ministerial',
    stage: 'ثالث ثانوي علمي',
    subject: 'الفيزياء',
    unitOrTopic: 'الوحدة الثالثة: التأثير الكهروضوئي',
    year: 'وزاري 2022',
    difficulty: 'medium',
    type: 'mcq',
    question: 'إذا سقط ضوء تردده أقل من تردد العتبة (التردد الحرج د_0) لمعدن ما، فإنه:',
    options: [
      'تنبعث إلكترونات بسرعة منخفضة جداً',
      'تنبعث إلكترونات فقط إذا زادت شدة الضوء الساقط',
      'لا تنبعث أي إلكترونات مهما بلغت شدة الضوء أو طال زمن التعرض',
      'تنبعث بروتونات من النواة'
    ],
    correctAnswer: 2,
    explanation: 'وفق نظرية أينشتاين للكم، فإن تحرر الإلكترون يتطلب فوتوناً منفرداً يمتلك طاقة كافية للتغلب على دالة الشغل للمعدن ($هـ د \\ge ط_0$). فإذا كان التردد أقل من تردد العتبة ($د < د_0$)، فلن يمتلك الفوتون الطاقة اللازمة، وزيادة الشدة تزيد عدد الفوتونات الضعيفة دون زيادة طاقة أي منها.',
    formulaOrRule: '$ط_{\\text{ح(عظمى)}} = هـ د - هـ د_0 = هـ (د - د_0)$',
    tags: ['كهروضوئي', 'أينشتاين', 'تردد عتبة']
  },

  // كيمياء ثالث ثانوي
  {
    id: 'ye_sec3_chm_001',
    section: 'ministerial',
    stage: 'ثالث ثانوي علمي',
    subject: 'الكيمياء',
    unitOrTopic: 'الوحدة الأولى: سرعة التفاعلات والاتزان الكيميائي',
    year: 'وزاري 2024',
    difficulty: 'medium',
    type: 'mcq',
    question: 'ما هو العامل الوحيد الذي يؤدي إلى تغيير القيمة العددية لثابت الاتزان (Kc) لتفاعل كيميائي متزن؟',
    options: [
      'تغيير تركيز المواد المتفاعلة',
      'تغيير الضغط الكلي للنظام الغازي',
      'إضافة عامل حفاز ملائم',
      'تغيير درجة الحرارة فقط'
    ],
    correctAnswer: 3,
    explanation: 'تغيير التركيز أو الضغط أو إضافة الحفاز يغير فقط موضع الاتزان اللحظي لإعادة التوازن وفق لوشاتيليه دون المساس بقيمة ثابت الاتزان Kc. أما درجة الحرارة فهي المؤثر الوحيد الذي يغير النسبة بين ثابتي السرعة الأمامي والعكسي فيتغير Kc عددياً.',
    tags: ['اتزان كيميائي', 'ثابت الاتزان', 'درجة الحرارة', 'لوشاتيليه']
  },
  {
    id: 'ye_sec3_chm_002',
    section: 'ministerial',
    stage: 'ثالث ثانوي علمي',
    subject: 'الكيمياء',
    unitOrTopic: 'الوحدة الثانية: الكيمياء الكهربائية',
    year: 'وزاري 2023',
    difficulty: 'easy',
    type: 'mcq',
    question: 'في الخلية الجلفانية (مثل خلية دانيال)، تحدث عملية الأكسدة عند القطب المسمى:',
    options: [
      'الكاثود (المهبط) وهو القطب الموجب',
      'الأنود (المصعد) وهو القطب السالب',
      'القنطرة الملحية',
      'الكاثود وهو القطب السالب'
    ],
    correctAnswer: 1,
    explanation: 'في الخلية الجلفانية، الأنود (المصعد) هو القطب الذي تفقد ذراته إلكترونات (أكسدة) وتتراكم عليه الإلكترونات ولذلك يعتبر القطب السالب، بينما تتجه الإلكترونات عبر السلك الخارجي إلى الكاثود الموجب حيث يحدث الاختزال.',
    formulaOrRule: '$\\text{Zn} \\to \\text{Zn}^{2+} + 2e^-$ (أكسدة عند الأنود)',
    tags: ['خلايا جلفانية', 'أنود', 'أكسدة', 'خلية دانيال']
  },
  {
    id: 'ye_sec3_chm_003',
    section: 'ministerial',
    stage: 'ثالث ثانوي علمي',
    subject: 'الكيمياء',
    unitOrTopic: 'الوحدة الثالثة: الكيمياء العضوية',
    year: 'وزاري 2024',
    difficulty: 'medium',
    type: 'mcq',
    question: 'ينتج عن أكسدة الكحول الأولي أكسدة تامة بواسطة برمنجنات البوتاسيوم المحمضة:',
    options: [
      'كيتون',
      'إيثر متماثل',
      'حمض كربوكسيلي',
      'ألكان مقابل'
    ],
    correctAnswer: 2,
    explanation: 'يتأكسد الكحول الأولي على مرحلتين: المرحلة الأولى تعطي ألدهيد (بنزع ذرتي هيدروجين)، ثم يتأكسد الألدهيد سريعاً في وجود زيادة من العامل المؤكسد القوي ليعطي الحمض الكربوكسيلي المقابل.',
    formulaOrRule: '$R-CH_2OH \\xrightarrow{[O]} R-CHO \\xrightarrow{[O]} R-COOH$',
    tags: ['كيمياء عضوية', 'كحولات', 'أكسدة', 'أحماض كربوكسيلية']
  },

  // أحياء ثالث ثانوي
  {
    id: 'ye_sec3_bio_001',
    section: 'ministerial',
    stage: 'ثالث ثانوي علمي',
    subject: 'الأحياء',
    unitOrTopic: 'الوحدة الأولى: علم الوراثة وتضاعف الـ DNA',
    year: 'وزاري 2024',
    difficulty: 'medium',
    type: 'problem',
    question: 'عينة من جزيء DNA حلزوني مزدوج تحتوي على 1000 زوج من القواعد النيتروجينية، فإذا كانت نسبة الأدينين (A) تساوي 20%، فما هو عدد روابط الهيدروجين الكلية في هذه العينة؟',
    options: [
      '2000 رابطة',
      '2600 رابطة',
      '3000 رابطة',
      '2400 رابطة'
    ],
    correctAnswer: 1,
    explanation: 'طريقة الحل النموذجية:\n- عدد القواعد الكلي = 1000 زوج = 2000 قاعدة.\n- نسبة A = 20%، إذن عدد ذرات A = 400 قاعدة، ومثلها T = 400 قاعدة (ترتبط كل A مع T برابطتين: $400 \\times 2 = 800$ رابطة).\n- النسبة المتبقية لـ G و C = 60%، إذن G = 600، C = 600 (ترتبط كل G مع C بثلاث روابط: $600 \\times 3 = 1800$ رابطة).\n- مجموع الروابط الكلية = 800 + 1800 = 2600 رابطة هيدروجينية.',
    formulaOrRule: 'الروابط الهيدروجينية = $2 \\times [A] + 3 \\times [G]$',
    tags: ['أحياء', 'DNA', 'وراثة جزيئية', 'مسألة وزارية']
  },
  {
    id: 'ye_sec3_bio_002',
    section: 'ministerial',
    stage: 'ثالث ثانوي علمي',
    subject: 'الأحياء',
    unitOrTopic: 'الوحدة الثانية: المناعة في جسم الإنسان',
    year: 'وزاري 2023',
    difficulty: 'easy',
    type: 'mcq',
    question: 'تتمايز وتنضج الخلايا اللمفاوية التائية (T-cells) في غدة تسمى:',
    options: [
      'الغدة الدرقية',
      'الغدة الثيموسية (الزعترية)',
      'الغدة الكظرية',
      'نخاع العظم الأحمر'
    ],
    correctAnswer: 1,
    explanation: 'تنشأ الخلايا التائية في نخاع العظم كخلايا غير ناضجة، ثم تهاجر عبر الدم إلى الغدة الثيموسية (الزعترية) حيث تفرز هرمون الثيموسين الذي يحفز نضجها وتمايزها إلى الأنواع التائية المختلفة (T-helper, T-cytotoxic, T-suppressor).',
    tags: ['مناعة', 'خلايا تائية', 'غدة ثيموسية']
  },

  // رياضيات ثالث ثانوي علمي
  {
    id: 'ye_sec3_mat_001',
    section: 'ministerial',
    stage: 'ثالث ثانوي علمي',
    subject: 'الرياضيات (تفاضل وتكامل وجبر)',
    unitOrTopic: 'التفاضل: نهايات الدوال الدائرية',
    year: 'وزاري 2024',
    difficulty: 'medium',
    type: 'mcq',
    question: 'احسب قيمة النهاية: $\\lim_{x \\to 0} \\frac{\\sin(5x)}{\\tan(2x)}$',
    options: [
      '5/2',
      '2/5',
      '0',
      '1'
    ],
    correctAnswer: 0,
    explanation: 'بقسمة البسط والمقام على x:\n$$\\lim_{x \\to 0} \\frac{\\frac{\\sin 5x}{x}}{\\frac{\\tan 2x}{x}} = \\frac{5}{2}$$ طبقاً لنظرية نهايات الدوال المثلثية.',
    formulaOrRule: '$\\lim_{x \\to 0} \\frac{\\sin ax}{bx} = \\frac{a}{b}$',
    tags: ['تفاضل', 'نهايات', 'رياضيات', 'وزاري']
  },
  {
    id: 'ye_sec3_mat_002',
    section: 'ministerial',
    stage: 'ثالث ثانوي علمي',
    subject: 'الرياضيات (تفاضل وتكامل وجبر)',
    unitOrTopic: 'الأعداد المركبة ونظرية ديموافر',
    year: 'وزاري 2023',
    difficulty: 'medium',
    type: 'mcq',
    question: 'قيمة المقدار $(1 + i)^8$ تساوي:',
    options: [
      '16',
      '16 i',
      '-16',
      '8 i'
    ],
    correctAnswer: 0,
    explanation: 'نحسب $(1+i)^2 = 1 + 2i + i^2 = 1 + 2i - 1 = 2i$.\nإذن: $(1+i)^8 = [(1+i)^2]^4 = (2i)^4 = 2^4 \\cdot i^4 = 16 \\cdot 1 = 16$.',
    formulaOrRule: '$(1+i)^2 = 2i, \\quad i^4 = 1$',
    tags: ['أعداد مركبة', 'جبر', 'ديموافر']
  },

  // ==========================================
  // الجزء الوزاري - الصف التاسع الأساسي
  // ==========================================
  {
    id: 'ye_g9_sci_001',
    section: 'ministerial',
    stage: 'تاسع أساسي',
    subject: 'العلوم',
    unitOrTopic: 'الفيزياء: الضغط والطفو وقاعدة أرخميدس',
    year: 'وزاري 2024',
    difficulty: 'easy',
    type: 'mcq',
    question: 'يقاس الضغط في النظام الدولي للوحدات بوحدة النيوتن/م² والتي تسمى:',
    options: [
      'الجول',
      'الباسكال (Pa)',
      'الواط',
      'الأمبير'
    ],
    correctAnswer: 1,
    explanation: 'الضغط هو القوة المؤثرة عمودياً على وحدة المساحات ($P = F / A$)، ويقاس بوحدة نيوتن لكل متر مربع ($N/m^2$) وتكافئ الباسكال تكريماً للعالم بليز باسكال.',
    formulaOrRule: '$P = \\frac{F}{A} \\implies 1 \\text{ Pa} = 1 \\text{ N/m}^2$',
    tags: ['تاسع', 'علوم', 'ضغط', 'وحدات قياس']
  },
  {
    id: 'ye_g9_sci_002',
    section: 'ministerial',
    stage: 'تاسع أساسي',
    subject: 'العلوم',
    unitOrTopic: 'الكيمياء: الجدول الدوري والروابط الكيميائية',
    year: 'وزاري 2023',
    difficulty: 'medium',
    type: 'mcq',
    question: 'تنشأ الرابطة الأيونية في مركب كلوريد الصوديوم (NaCl) نتيجة:',
    options: [
      'مشاركة زوج من الإلكترونات بين الذرتين بالتساوي',
      'فقد ذرة الصوديوم إلكتروناً واكتساب ذرة الكلور له وتجاذب الأيونات المتعاكسة كهربائياً',
      'تجاذب أنوية الذرات مع السحابة الإلكترونية الحرة',
      'تداخل المدارات الجزيئية فقط'
    ],
    correctAnswer: 1,
    explanation: 'الصوديوم فلز يميل لفقد إلكترون التكافؤ الوحيد ليصبح أيوناً موجباً ($Na^+$)، والكلور لا فلز يكتسب هذا الإلكترون ليصبح أيوناً سالباً ($Cl^-$)، وينشأ تجاذب إلكتروستاتيكي قوي بين الأيونين المتعاكسين في الشحنة لتكوين الرابطة الأيونية.',
    tags: ['تاسع', 'كيمياء', 'رابطة أيونية', 'جدول دوري']
  },
  {
    id: 'ye_g9_mat_001',
    section: 'ministerial',
    stage: 'تاسع أساسي',
    subject: 'الرياضيات',
    unitOrTopic: 'الجبر: حل المعادلات من الدرجة الثانية',
    year: 'وزاري 2024',
    difficulty: 'medium',
    type: 'problem',
    question: 'مجموعة حل المعادلة $x^2 - 7x + 12 = 0$ في حقل الأعداد الحقيقية هي:',
    options: [
      '{3, 4}',
      '{-3, -4}',
      '{2, 6}',
      '{-2, -6}'
    ],
    correctAnswer: 0,
    explanation: 'بتحليل المقدار الثلاثي البسيط إلى حاصل ضرب قوسين:\n$$(x - 3)(x - 4) = 0$$\nإما $x - 3 = 0 \\implies x = 3$\nأو $x - 4 = 0 \\implies x = 4$\nإذن مجموعة الحل هي $\\{3, 4\\}$.',
    tags: ['تاسع', 'رياضيات', 'معادلات', 'تحليل جبري']
  },
  {
    id: 'ye_g9_arb_001',
    section: 'ministerial',
    stage: 'تاسع أساسي',
    subject: 'اللغة العربية',
    unitOrTopic: 'النحو: كان وأخواتها وإن وأخواتها',
    year: 'وزاري 2024',
    difficulty: 'easy',
    type: 'mcq',
    question: 'في جملة «إنّ العلمَ نورٌ»، إعراب كلمة «نورٌ» هو:',
    options: [
      'مبتدأ مؤخر مرفوع',
      'خبر إنّ مرفوع وعلامة رفعه الضمة الظاهرة',
      'اسم إنّ منصوب',
      'نعت مرفوع'
    ],
    correctAnswer: 1,
    explanation: 'تدخل "إنّ" وأخواتها على الجملة الاسمية فتنصب المبتدأ ويسمى اسمها ("العلمَ" اسم إن منصوب)، وترفع الخبر ويسمى خبرها ("نورٌ" خبر إن مرفوع بالضمة).',
    tags: ['تاسع', 'لغة عربية', 'نحو', 'إن وأخواتها']
  },

  // ==========================================
  // 2. بنك الأسئلة الطبية السريرية (Medical Question Bank)
  // ==========================================
  {
    id: 'med_cvs_001',
    section: 'medical',
    medicalBlock: 'Cardiovascular System (CVS)',
    medicalSpecialty: 'Cardiology & Emergency',
    subject: 'أمراض القلب والشرايين (Cardiovascular Medicine)',
    unitOrTopic: 'Acute Coronary Syndrome (ACS) & STEMI Diagnostics',
    difficulty: 'hard',
    type: 'clinical',
    question: 'A 58-year-old male with a history of diabetes mellitus and hyperlipidemia presents to the emergency department with severe crushing retrosternal chest pain radiating to his left jaw and left arm for the past 90 minutes. ECG demonstrates ST-segment elevation of 3 mm in leads II, III, and aVF with reciprocal ST depression in leads I and aVL. Which coronary artery is most likely occluded, and what is the primary initial reperfusion management?',
    options: [
      'Left Anterior Descending (LAD) artery; Emergency CABG',
      'Right Coronary Artery (RCA); Immediate Primary Percutaneous Coronary Intervention (PCI)',
      'Left Circumflex (LCx) artery; Intravenous Metoprolol only',
      'Left Main Coronary Artery (LMCA); Thrombolysis after 24 hours'
    ],
    correctAnswer: 1,
    explanation: 'التحليل السريري الأكاديمي (Clinical Explanation):\n1. الارتفاع في اتجاهات II, III, aVF يشير بوضوح إلى احتشاء الجدار السفلي لعضلة القلب (Inferior STEMI).\n2. الشريان الإكليلي الأيمن (Right Coronary Artery - RCA) هو المغذي الأساسي للجدار السفلي والبطين الأيمن والعقدة الجيبية الأذينية في 85-90% من البشر (Right Dominant).\n3. المعيار الذهبي لإعادة التروية هو القسطرة الإسعافية الفورية (Primary PCI) داخل نافذة الـ 90-120 دقيقة (Door-to-Balloon time).',
    clinicalContext: {
      scenarioAr: 'مريض 58 سنة مصاب بالسكري يعاني من ألم صدري عاصر يمتد للفك والذراع الأيسر، وتخطيط القلب يظهر ارتفاع قطاع ST في اتجاهات II, III, aVF.',
      scenarioEn: '58-year-old diabetic male with acute crushing chest pain and ST elevation in leads II, III, and aVF (Inferior wall MI).',
      highYieldConcept: 'Inferior wall STEMI is localized by ST elevation in inferior leads (II, III, aVF) and supplied by the Right Coronary Artery (RCA).'
    },
    tags: ['طبي', 'CVS', 'STEMI', 'RCA', 'ECG', 'Cardiology']
  },
  {
    id: 'med_cns_001',
    section: 'medical',
    medicalBlock: 'Central Nervous System (CNS)',
    medicalSpecialty: 'Neurology & Pathology',
    subject: 'طب الجهاز العصبي (Neurology)',
    unitOrTopic: 'Lumbar Puncture & Cerebrospinal Fluid (CSF) Analysis in Meningitis',
    difficulty: 'medium',
    type: 'clinical',
    question: 'A 24-year-old college student presents with high-grade fever, neck stiffness (positive Kernig and Brudzinski signs), photophobia, and a non-blanching purpuric skin rash. Lumbar puncture is performed. Which CSF findings are most diagnostic of Acute Bacterial Meningitis (Neisseria meningitidis)?',
    options: [
      'High opening pressure, elevated neutrophils (PMNs), markedly elevated protein (>100 mg/dL), and low glucose (<40% of blood glucose)',
      'Normal opening pressure, elevated lymphocytes, normal protein, and normal glucose',
      'Normal white blood cells, normal glucose, and elevated oligoclonal bands only',
      'Elevated eosinophils, low protein, and markedly elevated glucose'
    ],
    correctAnswer: 0,
    explanation: 'التحليل المخبري والسريري:\n- في التهاب السحايا البكتيري الحاد (Bacterial Meningitis):\n1. ضغط البزل القطني مرتفع.\n2. سيادة كريات الدم البيضاء المتعادلة (Neutrophils > 80%).\n3. انخفاض حاد في جلوكوز السائل الدماغي الشوكي (Glucose < 40% of serum glucose) لأن البكتيريا تستهلك الجلوكوز.\n4. ارتفاع ملحوظ في البروتين نتيجة زيادة نفاذية الحاجز الدموي الدماغي (Blood-Brain Barrier disruption).',
    clinicalContext: {
      scenarioAr: 'شاب 24 سنة يعاني من حمى وتيبس رقبة وطفح جلدي نزفي. ما هي نتائج فحص السائل الدماغي الشوكي المميزة لالتهاب السحايا البكتيري؟',
      highYieldConcept: 'Bacterial meningitis CSF shows high neutrophils, high protein, and markedly low glucose.'
    },
    tags: ['طبي', 'CNS', 'Meningitis', 'CSF', 'Neurology']
  },
  {
    id: 'med_pharm_001',
    section: 'medical',
    medicalBlock: 'Pharmacology & Therapeutics',
    medicalSpecialty: 'Clinical Pharmacology',
    subject: 'علم الأدوية الإكلينيكي (Pharmacology)',
    unitOrTopic: 'Antidotes & Toxicological Reversal Agents',
    difficulty: 'easy',
    type: 'mcq',
    question: 'Which of the following pharmacological agents is the specific antidote for Acetaminophen (Paracetamol) overdose, and what is its mechanism of action?',
    options: [
      'Naloxone; Competitive antagonist at mu-opioid receptors',
      'N-Acetylcysteine (NAC); Replenishes hepatic glutathione stores to neutralize toxic NAPQI metabolite',
      'Flumazenil; Antagonizes GABA-A benzodiazepine receptor site',
      'Atropine; Blocks muscarinic acetylcholine receptors'
    ],
    correctAnswer: 1,
    explanation: 'الشرح الدوائي:\nعند تناول جرعة مفرطة من الباراسيتامول، تستنفد مخازن الجلوتاثيون في الكبد ويتراكم المركب السام (NAPQI). يعمل N-Acetylcysteine كمزود لمجموعات السلفهيدريل ويعيد تكوين الجلوتاثيون الكبدي لتحييد السمية ومنع الفشل الكبدي الحاد.',
    clinicalContext: {
      highYieldConcept: 'N-Acetylcysteine (NAC) is the antidote for acetaminophen poisoning, replenishing glutathione.'
    },
    tags: ['طبي', 'Pharmacology', 'Antidote', 'Paracetamol', 'Toxicology']
  },
  {
    id: 'med_endo_001',
    section: 'medical',
    medicalBlock: 'Endocrine & Metabolism',
    medicalSpecialty: 'Endocrinology',
    subject: 'أمراض الغدد الصماء والأيض (Endocrinology)',
    unitOrTopic: 'Diabetic Ketoacidosis (DKA) Pathophysiology & Management',
    difficulty: 'hard',
    type: 'clinical',
    question: 'A 19-year-old female with Type 1 Diabetes Mellitus presents with altered mental status, deep and rapid Kussmaul breathing, fruity breath odor, and dehydration. Arterial blood gas shows: pH 7.15, HCO3- 9 mEq/L, pCO2 25 mmHg. Blood glucose is 480 mg/dL, and urine ketones are strongly positive. Before initiating intravenous insulin therapy, which laboratory parameter must be verified to prevent fatal cardiac arrhythmias?',
    options: [
      'Serum Sodium',
      'Serum Potassium level (must be > 3.3 mEq/L before starting insulin)',
      'Serum Calcium level',
      'Hemoglobin A1c'
    ],
    correctAnswer: 1,
    explanation: 'تنبيه سريري حرج (Critical Clinical Pearl):\nيقوم الأنسولين بنقل البوتاسيوم من المصل إلى داخل الخلايا مع الجلوكوز. إذا بدأ إعطاء الأنسولين الوريدي والمريض يعاني من نقص بوتاسيوم الدم ($K^+ < 3.3 \\text{ mEq/L}$)، فسيؤدي ذلك إلى هبوط كارثي في البوتاسيوم واضطرابات نظم قلبية بطينية قاتلة (Ventricular Fibrillation). لذلك يجب تعويض البوتاسيوم أولاً.',
    tags: ['طبي', 'DKA', 'Endocrinology', 'Insulin', 'Potassium']
  },

  // ==========================================
  // 3. القسم العام والمعرفي الموسوعي الشامل
  // ==========================================
  {
    id: 'uni_cosmo_001',
    section: 'universal',
    subject: 'الفيزياء والكونيات',
    unitOrTopic: 'النسبية العامة والثقوب السوداء',
    difficulty: 'medium',
    type: 'mcq',
    question: 'ما هو "أفق الحدث" (Event Horizon) في فيزياء الثقوب السوداء وفق نظرية النسبية العامة لأينشتاين؟',
    options: [
      'القرص المضيء المكون من الغازات والغبار المحيطة بالثقب الأسود',
      'الحد الهندسي النظري الفاصل الذي لا يستطيع أي شيء تجاوزه والهروب للخارج، حتى الضوء، لكون سرعة الهروب تتجاوز سرعة الضوء',
      'مركز الثقب الأسود حيث تتركز الكتلة وتصبح الكثافة لانهائية',
      'المنطقة التي تنعدم فيها الجاذبية تماماً'
    ],
    correctAnswer: 1,
    explanation: 'أفق الحدث هو الغشاء الحدودي المحيط بالثقب الأسود؛ وعند هذه المسافة (المسماة نصف قطر شفارتزشيلد $r_s = \\frac{2GM}{c^2}$) تصبح سرعة الهروب من حقل الجاذبية مساوية لسرعة الضوء تماماً، وبالتالي تصبح أي إشارة أو مادة تعبر هذا الحد عاجزة عن العودة للكون الخارجي.',
    formulaOrRule: '$r_s = \\frac{2 G M}{c^2}$',
    tags: ['فيزياء فلكية', 'أينشتاين', 'ثقوب سوداء', 'نسبية عامة']
  },
  {
    id: 'uni_ai_001',
    section: 'universal',
    subject: 'علوم الحاسوب والذكاء الاصطناعي',
    unitOrTopic: 'معمارية المحولات (Transformer) والاهتمام الذاتي (Self-Attention)',
    difficulty: 'medium',
    type: 'mcq',
    question: 'ما هي الميزة الجوهرية التي جعلت معمارية Transformer تتفوق على الشبكات العصبية المتكررة (RNNs و LSTMs) في معالجة النماذج اللغوية الكبيرة (LLMs)؟',
    options: [
      'معالجة الكلمات كلمة تلو الأخرى بصورة تسلسلية بحتة لتوفير الذاكرة',
      'القدرة على المعالجة المتوازية لكامل النص دفعة واحدة ونمذجة العلاقات السياقية بعيدة المدى عبر آلية الانتباه الذاتي',
      'الاستغناء الكامل عن الأوزان العصبية وعمليات الضرب المصفوفي',
      'العمل فقط على البيانات الرقمية بدون نصوص'
    ],
    correctAnswer: 1,
    explanation: 'كانت شبكات RNN تعالج الكلمات تسلسلياً مما جعلها بطيئة في التدريب وعاجزة عن تذكر العلاقات البعيدة في النصوص الطويلة. أما الـ Transformer فيعالج الجملة بالكامل بالتوازي ويحسب أوزان الانتباه بين كل كلمة وجميع الكلمات الأخرى في نفس اللحظة عبر آلية: $\\text{Attention}(Q, K, V) = \\text{softmax}\\left(\\frac{QK^T}{\\sqrt{d_k}}\\right)V$.',
    formulaOrRule: '$\\text{Attention}(Q,K,V) = \\text{softmax}\\left(\\frac{Q K^T}{\\sqrt{d_k}}\\right) V$',
    tags: ['ذكاء اصطناعي', 'Transformer', 'تعلم عميق', 'حاسوب']
  },
  {
    id: 'uni_hist_001',
    section: 'universal',
    subject: 'التاريخ والحضارات الإنسانية',
    unitOrTopic: 'حضارات اليمن القديم وسد مأرب التاريخي',
    difficulty: 'easy',
    type: 'mcq',
    question: 'ما هي أعظم منشأة هندسية مائية في جنوب شبه الجزيرة العربية القديمة بنتها مملكة سبأ للتحكم بمياه السيول والري الزراعي؟',
    options: [
      'سد مأرب العظيم',
      'صهاريج عدن',
      'قنوات نينوى',
      'قناطر قرطبة'
    ],
    correctAnswer: 0,
    explanation: 'يعد سد مأرب العظيم من أقدم المعالم الهندسية والريية في العالم القديم؛ شيده ملوك سبأ في الألفية الأولى قبل الميلاد عند مضيق جبلين لحجز مياه السيول من وادي ذنة وتوزيعها عبر بوابات حجرية عملاقة إلى الجنتين (الواحتين الكبريين)، مما جعل سبأ من أثرى حضارات الشرق القديم.',
    tags: ['تاريخ', 'اليمن القديم', 'سبأ', 'سد مأرب']
  },
  {
    id: 'uni_math_001',
    section: 'universal',
    subject: 'الرياضيات والخوارزميات',
    unitOrTopic: 'مبرهنة فيرما الأخيرة وتاريخ إثباتها',
    difficulty: 'medium',
    type: 'mcq',
    question: 'تنص مبرهنة فيرما الأخيرة الشهيرة على أنه لا توجد أعداد صحيحة موجبة (x, y, z) تحقق المعادلة $x^n + y^n = z^n$ متى ما كان الأس n:',
    options: [
      'n = 2',
      'n > 2',
      'n < 0',
      'n كسرياً فقط'
    ],
    correctAnswer: 1,
    explanation: 'كتب عالم الرياضيات بيير دي فيرما عام 1637 ملاحظته الشهيرة بأن المعادلة لا تمتلك حلولاً صحيحة لأي أس $n > 2$. وظلت هذه المسألة لغزاً رياضياً حير أعظم علماء العالم لأكثر من 350 عاماً حتى تمكن عالم الرياضيات البريطاني أندرو وايلز (Andrew Wiles) من إثباتها نهائياً عام 1994.',
    formulaOrRule: '$x^n + y^n \\neq z^n \\quad \\forall n > 2, \\quad x,y,z \\in \\mathbb{Z}^+$',
    tags: ['رياضيات', 'فيرما', 'نظرية الأعداد']
  },

  // ==========================================
  // إضافات وزارية موسعة - الصف التاسع الأساسي
  // ==========================================
  {
    id: 'ye_g9_sci_004',
    section: 'ministerial',
    stage: 'تاسع أساسي',
    subject: 'العلوم',
    unitOrTopic: 'الوحدة الأولى: الضوء والمرايا الكروية',
    year: 'وزاري 2024',
    difficulty: 'easy',
    type: 'mcq',
    question: 'المرآة الكروية التي يكون سطحها العاكس جزءاً من السطح الداخلي للكرة الجوفاء وتعمل على تجميع الأشعة الضوئية تسمى:',
    options: [
      'مرآة مقعرة (مجمعة)',
      'مرآة محدبة (مفرقة)',
      'مرآة مستوية',
      'منشور زجاجي عاكس'
    ],
    correctAnswer: 0,
    explanation: 'المرآة المقعرة (Concave Mirror) سطحها العاكس داخلي، وتجمع الأشعة الضوئية المتوازية والساقطة عليها في نقطة واحدة تسمى البؤرة الأصلية الحقيقية.',
    tags: ['تاسع', 'علوم', 'مرايا', 'ضوء']
  },
  {
    id: 'ye_g9_sci_003',
    section: 'ministerial',
    stage: 'تاسع أساسي',
    subject: 'العلوم',
    unitOrTopic: 'الوحدة الثانية: التركيب الذري والجدول الدوري',
    year: 'وزاري 2023',
    difficulty: 'medium',
    type: 'mcq',
    question: 'عنصر الصوديوم عدده الذري 11 وعدده الكتلي 23، فإن عدد النيوترونات داخل نواته يساوي:',
    options: ['11', '12', '23', '34'],
    correctAnswer: 1,
    explanation: 'عدد النيوترونات = العدد الكتلي (A) - العدد الذري (Z) = 23 - 11 = 12 نيوتروناً متعادلاً.',
    formulaOrRule: '$N = A - Z = 23 - 11 = 12$',
    tags: ['تاسع', 'علوم', 'كيمياء', 'ذرة', 'نيوترونات']
  },
  {
    id: 'ye_g9_mat_002',
    section: 'ministerial',
    stage: 'تاسع أساسي',
    subject: 'الرياضيات',
    unitOrTopic: 'الهندسة: نظرية فيثاغورس في المثلث القائم',
    year: 'وزاري 2024',
    difficulty: 'easy',
    type: 'problem',
    question: 'مثلث قائم الزاوية طولا ضلعي القائمة فيه 6 سم و 8 سم، فإن طول الوتر يساوي:',
    options: ['10 سم', '14 سم', '12 سم', '7 سم'],
    correctAnswer: 0,
    explanation: 'حسب نظرية فيثاغورس: مربع الوتر = مجموع مربعي ضلعي القائمة.\n$$\\text{الوتر}^2 = 6^2 + 8^2 = 36 + 64 = 100$$\nطول الوتر = $\\sqrt{100} = 10$ سم.',
    formulaOrRule: '$c = \\sqrt{a^2 + b^2} = \\sqrt{6^2 + 8^2} = 10\\text{ cm}$',
    tags: ['تاسع', 'رياضيات', 'هندسة', 'فيثاغورس']
  },
  {
    id: 'ye_g9_isl_001',
    section: 'ministerial',
    stage: 'تاسع أساسي',
    subject: 'القرآن والإسلامية',
    unitOrTopic: 'التجويد: أحكام النون الساكنة والتنوين (الإدغام)',
    year: 'وزاري 2024',
    difficulty: 'easy',
    type: 'mcq',
    question: 'في قوله تعالى: ﴿مَن يَقُولُ﴾، الحكم التجويدي للنون الساكنة هنا هو:',
    options: [
      'إدغام بغنة',
      'إظهار حلقي',
      'إقلاب',
      'إخفاء حقيقي'
    ],
    correctAnswer: 0,
    explanation: 'حروف الإدغام مجموعة في كلمة (يرملون)، وحرف الياء من حروف الإدغام بغنة (ينمو)؛ فعند مجيء الياء بعد النون الساكنة تدغم النون فيها مع بقاء الغنة بمقدار حركتين.',
    tags: ['تاسع', 'إسلامية', 'تجويد', 'إدغام']
  },
  {
    id: 'ye_g9_soc_001',
    section: 'ministerial',
    stage: 'تاسع أساسي',
    subject: 'الاجتماعيات',
    unitOrTopic: 'تاريخ اليمن القديم: مملكة سبأ وحمير',
    year: 'وزاري 2023',
    difficulty: 'medium',
    type: 'mcq',
    question: 'اتخذ الحميريون مدينة ........... عاصمة تاريخية لهم بعد انتقال مركز الحكم من مأرب:',
    options: ['ظفار (في يريم)', 'صنعاء', 'شبام حضرموت', 'براقش'],
    correctAnswer: 0,
    explanation: 'اتخذ ملوك حمير مدينة ظفار (الواقعة في يريم بمحافظة إب حالياً) عاصمة لدولتهم الحميرية الموحدة التي امتد نفوذها في أرجاء شبه الجزيرة العربية.',
    tags: ['تاسع', 'اجتماعيات', 'تاريخ اليمن', 'حمير', 'ظفار']
  },
  {
    id: 'ye_g9_eng_001',
    section: 'ministerial',
    stage: 'تاسع أساسي',
    subject: 'اللغة الإنجليزية',
    unitOrTopic: 'Grammar: Past Simple vs Present Perfect',
    year: 'وزاري 2024',
    difficulty: 'medium',
    type: 'mcq',
    question: 'Choose the correct verb form: "Ali ............ to Sana\'a three days ago."',
    options: ['travelled', 'has travelled', 'travels', 'is travelling'],
    correctAnswer: 0,
    explanation: 'The time expression "three days ago" specifies a completed time in the past, which mandates the Past Simple tense ("travelled"), not the present perfect.',
    tags: ['تاسع', 'إنجليزي', 'Grammar', 'Past Simple']
  },

  // ==========================================
  // إضافات وزارية موسعة - الصف الثالث الثانوي
  // ==========================================
  {
    id: 'ye_sec3_mat_003',
    section: 'ministerial',
    stage: 'ثالث ثانوي علمي',
    subject: 'الرياضيات (تفاضل وتكامل وجبر)',
    unitOrTopic: 'التفاضل: مشتقات الدوال المثلثية',
    year: 'وزاري 2024',
    difficulty: 'medium',
    type: 'mcq',
    question: 'مشتقة الدالة $y = \\sin(3x^2 + 5)$ بالنسبة للمتغير x هي:',
    options: [
      '$6x \\cos(3x^2 + 5)$',
      '$\\cos(3x^2 + 5)$',
      '$-6x \\cos(3x^2 + 5)$',
      '$6x \\sin(3x^2 + 5)$'
    ],
    correctAnswer: 0,
    explanation: 'بتطبيق قاعدة السلسلة: مشتقة دالة الجيب هي جيب التمام مضروبة في مشتقة الزاوية الداخلية:\n$$\\frac{dy}{dx} = \\cos(3x^2 + 5) \\cdot \\frac{d}{dx}(3x^2 + 5) = 6x \\cos(3x^2 + 5)$$',
    formulaOrRule: '$\\frac{d}{dx}[\\sin(u)] = u\' \\cos(u)$',
    tags: ['ثالث ثانوي', 'رياضيات', 'تفاضل', 'قاعدة السلسلة']
  },
  {
    id: 'ye_sec3_mat_004',
    section: 'ministerial',
    stage: 'ثالث ثانوي علمي',
    subject: 'الرياضيات (تفاضل وتكامل وجبر)',
    unitOrTopic: 'التكامل: التكامل المحدد والمساحات',
    year: 'وزاري 2023',
    difficulty: 'hard',
    type: 'problem',
    question: 'قيمة التكامل المحدد $\\int_{0}^{2} (3x^2 - 2x + 1) dx$ تساوي:',
    options: ['6', '8', '10', '12'],
    correctAnswer: 0,
    explanation: 'خطوات الحل الوزاري النموذجي:\n1. إيجاد الدالة الأصلية:\n$$F(x) = \\left[ \\frac{3x^3}{3} - \\frac{2x^2}{2} + x \\right] = \\left[ x^3 - x^2 + x \\right]$$\n2. التعويض بحدود التكامل من 0 إلى 2:\n$$F(2) = (2)^3 - (2)^2 + 2 = 8 - 4 + 2 = 6$$\n$$F(0) = 0$$\nالناتج النهائي = $6 - 0 = 6$.',
    formulaOrRule: '$\\int_a^b f(x) dx = F(b) - F(a)$',
    tags: ['ثالث ثانوي', 'رياضيات', 'تكامل محدد', 'مسألة وزارية']
  },
  {
    id: 'ye_sec3_mat_005',
    section: 'ministerial',
    stage: 'ثالث ثانوي علمي',
    subject: 'الرياضيات (تفاضل وتكامل وجبر)',
    unitOrTopic: 'الجبر: الأعداد المركبة ونظرية ديموافر',
    year: 'وزاري 2024',
    difficulty: 'medium',
    type: 'mcq',
    question: 'الصورة القطبية للعدد المركب $z = 1 + i$ هي:',
    options: [
      '$\\sqrt{2} \\left( \\cos \\frac{\\pi}{4} + i \\sin \\frac{\\pi}{4} \\right)$',
      '$2 \\left( \\cos \\frac{\\pi}{4} + i \\sin \\frac{\\pi}{4} \\right)$',
      '$\\sqrt{2} \\left( \\cos \\frac{\\pi}{2} + i \\sin \\frac{\\pi}{2} \\right)$',
      '$1 \\left( \\cos \\pi + i \\sin \\pi \\right)$'
    ],
    correctAnswer: 0,
    explanation: '1. المقياس: $r = \\sqrt{x^2 + y^2} = \\sqrt{1^2 + 1^2} = \\sqrt{2}$.\n2. السعة الأساسية: $\\tan \\theta = \\frac{y}{x} = \\frac{1}{1} = 1 \\implies \\theta = \\frac{\\pi}{4}$ (في الربع الأول).\n3. الصورة القطبية: $z = r(\\cos \\theta + i \\sin \\theta) = \\sqrt{2} (\\cos \\frac{\\pi}{4} + i \\sin \\frac{\\pi}{4})$.',
    formulaOrRule: '$z = r e^{i\\theta} = r(\\cos\\theta + i\\sin\\theta)$',
    tags: ['ثالث ثانوي', 'جبر', 'أعداد مركبة', 'ديموافر']
  },
  {
    id: 'ye_sec3_arb_001',
    section: 'ministerial',
    stage: 'ثالث ثانوي علمي',
    subject: 'اللغة العربية',
    unitOrTopic: 'النحو: أسلوب الاستثناء وحكم المستثنى بإلا',
    year: 'وزاري 2024',
    difficulty: 'medium',
    type: 'mcq',
    question: 'في جملة «ما حضر الطلابُ إلا زيدٌ / زيداً»، نوع الاستثناء وحكم المستثنى هنا هو:',
    options: [
      'تام منفي؛ يجوز فيه النصب على الاستثناء أو الإتباع على البدلية من الفاعل',
      'تام مثبت؛ واجب النصب فقط',
      'مفرغ ناقص؛ يعرب حسب موقعه في الجملة',
      'منقطع؛ واجب النصب'
    ],
    correctAnswer: 0,
    explanation: 'الكلام تام لوجود المستثنى منه ("الطلاب")، ومنفي لوجود أداة النفي ("ما"). وفي الاستثناء التام المنفي يجوز للمستثنى بإلا وجهان إعرابيان:\n1. النصب على الاستثناء ("زيداً").\n2. الإتباع على البدلية من المستثنى منه ("زيدٌ" بدل مرفوع).',
    tags: ['ثالث ثانوي', 'لغة عربية', 'نحو', 'استثناء', 'أتمتة']
  },
  {
    id: 'ye_sec3_arb_002',
    section: 'ministerial',
    stage: 'ثالث ثانوي علمي',
    subject: 'اللغة العربية',
    unitOrTopic: 'البلاغة: علم البيان (التشبيه والاستعارة)',
    year: 'وزاري 2023',
    difficulty: 'easy',
    type: 'mcq',
    question: 'في قول المتنبي يصف دخول رسول الروم على سيف الدولة: «وأقبل يمشي في البساط فما درى ... إلى البحر يسعى أم إلى البدر يرتقي»، نوع الصورة البيانية في كلمتي (البحر) و (البدر) هي:',
    options: [
      'استعارة تصريحية',
      'استعارة مكنية',
      'تشبيه بليغ',
      'كناية عن موصوف'
    ],
    correctAnswer: 0,
    explanation: 'شبه سيف الدولة بالبحر في جوده وكرمه، وبالبدر في علو شأنه وجماله، ثم حذف المشبه (سيف الدولة) وصرح بلفظ المشبه به ("البحر" و"البدر")، وتصريح لفظ المشبه به يجعل الاستعارة تصريحية.',
    tags: ['ثالث ثانوي', 'لغة عربية', 'بلاغة', 'استعارة تصريحية']
  },
  {
    id: 'ye_sec3_lit_hist_001',
    section: 'ministerial',
    stage: 'ثالث ثانوي أدبي',
    subject: 'التاريخ الحديث',
    unitOrTopic: 'حضارات اليمن القديم وسد مأرب وطريق اللبان',
    year: 'وزاري 2024',
    difficulty: 'medium',
    type: 'mcq',
    question: 'يُعد سد مأرب العظيم أحد أعظم المعالم الهندسية والمائية في الحضارة السبئية القديمة؛ والوظيفة الأساسية للمصرفين الصخريين (الصدفين الشمالي والجنوبي) في السد كانت:',
    options: [
      'توزيع مياه السيول بالتساوي على الجنتين (الأراضي الزراعية الشمالية والجنوبية) عبر شبكة قنوات محكمة',
      'منع وصول السفن التجارية إلى بحيرة السد',
      'تخزين مياه الأمطار دون تصريفها طوال العام',
      'توليد الطاقة الميكانيكية لطحن الغلال'
    ],
    correctAnswer: 0,
    explanation: 'بنى السبئيون سد مأرب بين جبلي البلق بهندسة هيدروليكية عبقرية تعتمد على السدين الصخريين (المصرفين) لتوزيع مياه سيول وادي أذنة بدقة متناهية إلى شبكتي ري روت «الجنتين» الشهيرتين، ما حقق أضخم ازدهار زراعي في الجزيرة العربية.',
    tags: ['ثالث ثانوي أدبي', 'تاريخ', 'سد مأرب', 'حضارة سبأ', 'حضارات اليمن القديم']
  },
  {
    id: 'ye_sec3_lit_hist_002',
    section: 'ministerial',
    stage: 'ثالث ثانوي أدبي',
    subject: 'التاريخ الحديث',
    unitOrTopic: 'حضارات اليمن القديم وسد مأرب وطريق اللبان',
    year: 'وزاري 2023',
    difficulty: 'easy',
    type: 'mcq',
    question: 'سيطر اليمنيون القدماء على التجارة العالمية القديمة من خلال احتكار تجارة اللبان والبخور عبر شريان تجاري بري شهير يُعرف بـ:',
    options: [
      'طريق اللبان والبخور الدولي',
      'طريق الحرير البري',
      'طريق الفرو الشمالي',
      'طريق التوابل البحري الجنوبي'
    ],
    correctAnswer: 0,
    explanation: 'طريق اللبان كان أهم شريان تجاري في العالم القديم ينطلق من موانئ ظفار وقنا وشبوة في اليمن، ويمر بمأرب ومعين ونجران ثم إلى بلاد الشام ومصر وروما، وفرضت عليه الممالك اليمنية القديمة ضرائب وحماية لقوافل التجارة.',
    tags: ['ثالث ثانوي أدبي', 'تاريخ', 'طريق اللبان', 'تجارة اليمن القديم']
  },
  {
    id: 'ye_sec3_lit_hist_003',
    section: 'ministerial',
    stage: 'ثالث ثانوي أدبي',
    subject: 'التاريخ الحديث',
    unitOrTopic: 'حضارات اليمن القديم وسد مأرب وطريق اللبان',
    year: 'وزاري 2024',
    difficulty: 'hard',
    type: 'mcq',
    question: 'الخط الأبجدي التاريخي الصارم الذي نقشت به الممالك اليمنية القديمة (سبأ، معين، قتبان، حضرموت، حمير) وثائقها ومعاهداتها الرسمية على الصخور والبرونز هو:',
    options: [
      'خط المسند اليمني الأصيل (بأقسامه الجلي والزبور)',
      'الخط المسماري البابلي',
      'الخط الهيروغليفي القديم',
      'الخط السنسكريتي'
    ],
    correctAnswer: 0,
    explanation: 'خط المسند هو الأبجدية اليمنية القديمة المكونة من 29 حرفاً؛ حيث استخدم خط المسند الجلي للنقوش التذكارية والمعاهدات على الأحجار والبرونز، بينما استخدم خط «الزبور» الشعبي على أعواد الخشب والمعاملات اليومية.',
    tags: ['ثالث ثانوي أدبي', 'تاريخ', 'خط المسند', 'النقوش اليمنية']
  },
  {
    id: 'ye_sec3_lit_hist_004',
    section: 'ministerial',
    stage: 'ثالث ثانوي أدبي',
    subject: 'التاريخ الحديث',
    unitOrTopic: 'حضارات اليمن القديم وسد مأرب وطريق اللبان',
    year: 'وزاري 2022',
    difficulty: 'medium',
    type: 'mcq',
    question: 'اللقب الديني والسياسي الذي أُطلق على حكام سبأ في المرحلة الأولى من نشأة الدولة قبل تحولهم إلى لقب «ملك» هو:',
    options: [
      'المُكَرِّب (مكرب سبأ)',
      'الفرعون الحاكم',
      'القيصر الموحد',
      'الإمبراطور'
    ],
    correctAnswer: 0,
    explanation: 'حمل حكام سبأ الأوائل لقب «مُكَرِّب» وتعني الموحّد أو المقرّب بين القبائل والآلهة، ثم تحول اللقب في العصر الكلاسيكي إلى «ملك سبأ»، وصولاً إلى «ملك سبأ وذي ريدان وحضرموت ويمنت» في العهد الحميري الموحد.',
    tags: ['ثالث ثانوي أدبي', 'تاريخ', 'المكارب', 'حضارة سبأ']
  },
  {
    id: 'ye_sec3_lit_hist_005',
    section: 'ministerial',
    stage: 'ثالث ثانوي أدبي',
    subject: 'التاريخ الحديث',
    unitOrTopic: 'تاريخ الثورة اليمنية 26 سبتمبر و 14 أكتوبر',
    year: 'وزاري 2024',
    difficulty: 'easy',
    type: 'mcq',
    question: 'الهدف الأول من أهداف ثورة 26 سبتمبر 1962م في اليمن ينص على:',
    options: [
      'التحرر من الاستبداد والاستعمار ومخلفاتهما وإقامة حكم جمهوري عادل وإزالة الفوارق والامتيازات بين الطبقات',
      'بناء جيش وطني قوي لحماية البلاد وحراسة الثورة ومكاسبها',
      'رفع مستوى الشعب اقتصادياً واجتماعياً وسياسياً وثقافياً',
      'إنشاء مجتمع ديمقراطي تعاوني عادل'
    ],
    correctAnswer: 0,
    explanation: 'الهدف الأول للثورة اليمنية الخالدة هو حجر الزاوية للعهد الجمهوري: «التحرر من الاستبداد والاستعمار ومخلفاتهما وإقامة حكم جمهوري عادل وإزالة الفوارق والامتيازات بين الطبقات».',
    tags: ['ثالث ثانوي أدبي', 'تاريخ', 'ثورة 26 سبتمبر', 'أهداف الثورة']
  },
  {
    id: 'ye_sec3_lit_hist_006',
    section: 'ministerial',
    stage: 'ثالث ثانوي أدبي',
    subject: 'التاريخ الحديث',
    unitOrTopic: 'تاريخ الثورة اليمنية 26 سبتمبر و 14 أكتوبر',
    year: 'وزاري 2023',
    difficulty: 'medium',
    type: 'mcq',
    question: 'انطلقت الشرارة الأولى لثورة 14 أكتوبر 1963م المجيدة في جنوب اليمن ضد الاحتلال البريطاني بقيادة الشهيد البطل راجح بن غالب لبوزة من جبال:',
    options: [
      'ردفان الشماء',
      'جبل صبر',
      'جبال عيبان',
      'جبل النبي شعيب'
    ],
    correctAnswer: 0,
    explanation: 'فجر الأحرار ثورة 14 أكتوبر من قمم جبال ردفان الأبية بقيادة الشهيد راجح بن غالب لبوزة، وتوجت بنيل الاستقلال التام وجلاء آخر جندي بريطاني في 30 نوفمبر 1967م.',
    tags: ['ثالث ثانوي أدبي', 'تاريخ', 'ثورة 14 أكتوبر', 'ردفان']
  },
  {
    id: 'ye_sec3_lit_geo_001',
    section: 'ministerial',
    stage: 'ثالث ثانوي أدبي',
    subject: 'الجغرافيا',
    unitOrTopic: 'جغرافية اليمن الطبيعية والتضاريس والمناخ',
    year: 'وزاري 2024',
    difficulty: 'easy',
    type: 'mcq',
    question: 'تعد أعلى قمة جبلية في الجمهورية اليمنية وشبه الجزيرة العربية وبلاد الشام قاطبة هي قمة:',
    options: [
      'جبل النبي شعيب (3666 متراً فوق مستوى سطح البحر)',
      'جبل صبر بتعز',
      'جبل اللوز بصعدة',
      'جبل شمسين'
    ],
    correctAnswer: 0,
    explanation: 'يقع جبل النبي شعيب في مديرية بني مطر غرب العاصمة صنعاء ويبلغ ارتفاعه نحو 3666 متراً وهو أعلى نقطة تضاريسية في الجزيرة العربية والشرق الأدنى.',
    tags: ['ثالث ثانوي أدبي', 'جغرافيا', 'تضاريس اليمن', 'جبل النبي شعيب']
  },
  {
    id: 'ye_sec3_lit_geo_002',
    section: 'ministerial',
    stage: 'ثالث ثانوي أدبي',
    subject: 'الجغرافيا',
    unitOrTopic: 'الجغرافيا السياسية والموقع الاستراتيجي ومضيق باب المندب',
    year: 'وزاري 2023',
    difficulty: 'medium',
    type: 'mcq',
    question: 'يشرف اليمن إشرافاً مباشراً وكاملاً على الممر المائي الدولي الحاكم لحركة التجارة العالمية بين الشرق والغرب، وهو:',
    options: [
      'مضيق باب المندب وتتحكم به جزيرة ميون اليمنية',
      'مضيق هرمز',
      'قناة بنما',
      'مضيق ملقا'
    ],
    correctAnswer: 0,
    explanation: 'يقع مضيق باب المندب في مدخل البحر الأحمر الجنوبي ويربطه بخليج عدن وبحر العرب والمحيط الهندي، وتتحكم به جزيرة ميون اليمنية، ويعد من أهم نقاط الاختناق البحرية والتجارية الاستراتيجية في العالم لنقل النفط والتجارة الدولية.',
    tags: ['ثالث ثانوي أدبي', 'جغرافيا', 'باب المندب', 'موقع استراتيجي']
  },
  {
    id: 'ye_sec3_lit_geo_003',
    section: 'ministerial',
    stage: 'ثالث ثانوي أدبي',
    subject: 'الجغرافيا',
    unitOrTopic: 'الجغرافيا الاقتصادية والموارد المائية والزراعية',
    year: 'وزاري 2024',
    difficulty: 'medium',
    type: 'mcq',
    question: 'المحصول النقدي اليمني التاريخي الأشهر عالمياً الذي تم تصديره عبر ميناء المخا التاريخي واكتسب شهرة كوكبية هو:',
    options: [
      'البن اليمني (Mocha Coffee)',
      'القطن طويل التيلة',
      'الشاي الأسود',
      'قصب السكر'
    ],
    correctAnswer: 0,
    explanation: 'عُرف البن اليمني بأجود أنواع البن في العالم وكان يُصدر عبر ميناء المخا التاريخي (Mocha)، مما جعل اسمه علامة تجارية عالمية مسجلة للقهوة عالية الجودة.',
    tags: ['ثالث ثانوي أدبي', 'جغرافيا', 'الزراعة في اليمن', 'البن اليمني']
  },
  {
    id: 'ye_sec3_lit_phil_001',
    section: 'ministerial',
    stage: 'ثالث ثانوي أدبي',
    subject: 'الفلسفة وعلم النفس',
    unitOrTopic: 'نشأة الفلسفة والتفكير الفلسفي والمنطق الصوري',
    year: 'وزاري 2024',
    difficulty: 'hard',
    type: 'mcq',
    question: 'في قواعد القياس الأرسطي الصوري الكلاسيكي، الشرط الجوهري للحد الأوسط (Middle Term) لكي تصح النتيجة هو:',
    options: [
      'أن يستغرق في إحدى المقدمتين على الأقل، وألا يظهر في النتيجة إطلاقاً',
      'أن يظهر دائماً في النتيجة كموضوع',
      'أن يكون غير مستغرق في كلتا المقدمتين',
      'أن يكون سالباً وجزئياً معاً'
    ],
    correctAnswer: 0,
    explanation: 'وظيفة الحد الأوسط في المنطق الصوري هي الربط المنطقي بين الحدين الأكبر والأصغر، لذا يجب أن يُستغرق مرة واحدة على الأقل لضمان التعدي المنطقي، وتقتضي القاعدة اختفاءه في النتيجة ليحل محله الارتباط بين الأصغر والأكبر.',
    tags: ['ثالث ثانوي أدبي', 'فلسفة', 'المنطق الصوري', 'القياس الأرسطي']
  },
  {
    id: 'ye_sec3_lit_phil_002',
    section: 'ministerial',
    stage: 'ثالث ثانوي أدبي',
    subject: 'الفلسفة وعلم النفس',
    unitOrTopic: 'العمليات المعرفية: الإدراك، الذاكرة، والتعلم',
    year: 'وزاري 2023',
    difficulty: 'medium',
    type: 'mcq',
    question: 'العملية العقلية النفسية المسؤولة عن تفسير وتأويل المثيرات الحسية الواردة من الحواس وإعطائها معنى ودلالة تُعرف في علم النفس بـ:',
    options: [
      'الإدراك الحسي (Perception)',
      'الإحساس الخام المجرد (Sensation)',
      'الانعكاس الشرطي البسيط',
      'النكوص والتعويض'
    ],
    correctAnswer: 0,
    explanation: 'الإحساس ينقل المثيرات الخام (ضوء، صوت)، بينما «الإدراك» هو العملية المعرفية العليا التي تنظم وتفسر تلك البيانات الحسية وتخلع عليها المعنى والدلالة استناداً إلى الخبرات السابقة.',
    tags: ['ثالث ثانوي أدبي', 'علم النفس', 'العمليات المعرفية', 'الإدراك']
  },

  // ==========================================
  // إضافات طبية سريرية متقدمة (Clinical Vignettes)
  // ==========================================
  {
    id: 'med_rs_001',
    section: 'medical',
    medicalBlock: 'Respiratory System (RS)',
    medicalSpecialty: 'Pulmonology & Intensive Care',
    subject: 'أمراض الجهاز التنفسي (Pulmonary Medicine)',
    unitOrTopic: 'Pulmonary Embolism (PE) Diagnostics & Pathophysiology',
    difficulty: 'hard',
    type: 'clinical',
    question: 'A 64-year-old female presents with acute-onset dyspnea, pleuritic chest pain, and hemoptysis 5 days following total knee arthroplasty. Her pulse is 118 bpm, blood pressure 90/60 mmHg, and oxygen saturation 86% on room air. ECG shows sinus tachycardia with S1Q3T3 pattern. What is the gold standard diagnostic imaging test for this condition in a hemodynamically stable patient, and what is the primary V/Q disturbance?',
    options: [
      'CT Pulmonary Angiography (CTPA); Ventilation with dead-space alveolar mismatch (V/Q = infinity)',
      'Transthoracic echocardiogram; Right-to-left intra-cardiac shunt only',
      'Chest X-ray; Pure alveolar hypoventilation (V/Q = 0)',
      'High-resolution non-contrast CT; Diffusion block across alveolar membrane'
    ],
    correctAnswer: 0,
    explanation: 'التحليل السريري الأكاديمي:\n1. الانصمام الرئوي (Pulmonary Embolism): يسبب انسداد تدفق الدم إلى الأسناخ الرئوية المهواة، مما يخلق مساحة ميتة سنخية (Alveolar Dead Space) حيث التهوية طبيعية مع انعدام التروية (High V/Q mismatch or Dead space ventilation).\n2. المعيار التشخيصي الذهبي (Gold Standard Imaging): هو التصوير المقطعي الوعائي للشرايين الرئوية (CT Pulmonary Angiography - CTPA).\n3. نمط ECG الشهير S1Q3T3 يعكس إجهاد البطين الأيمن الحاد (Right ventricular strain).',
    clinicalContext: {
      scenarioAr: 'مريضة 64 سنة بعد جراحة استبدال مفصل الركبة تصاب بضيق تنفس مفاجئ وألم صدري جنبي وتسرع نبض وهبوط ضغط. الفحص الذهبي هو أشعة مقطعية لشرايين الرئة (CTPA).',
      highYieldConcept: 'Pulmonary embolism creates dead-space ventilation (ventilated alveoli without perfusion) and CTPA is the definitive investigation.'
    },
    tags: ['طبي', 'Respiratory', 'PE', 'CTPA', 'V/Q Mismatch']
  },
  {
    id: 'med_git_001',
    section: 'medical',
    medicalBlock: 'Gastrointestinal System (GIT)',
    medicalSpecialty: 'Gastroenterology',
    subject: 'أمراض الجهاز الهضمي (Gastroenterology)',
    unitOrTopic: 'Peptic Ulcer Disease & Helicobacter pylori Regimens',
    difficulty: 'medium',
    type: 'mcq',
    question: 'Which of the following drug combinations represents the standard first-line quadruple therapy for Helicobacter pylori eradication in areas with high clarithromycin resistance?',
    options: [
      'Proton Pump Inhibitor (PPI) + Bismuth Subsalicylate + Metronidazole + Tetracycline for 14 days',
      'Amoxicillin + Clarithromycin only for 5 days',
      'Omeprazole + Ciprofloxacin for 7 days',
      'Ranitidine + Ceftriaxone for 3 days'
    ],
    correctAnswer: 0,
    explanation: 'البروتوكول العلاجي المعتمد دولياً (ACG & Maastricht Guidelines):\nفي المناطق التي تزيد فيها مقاومة الكلارثروميسين عن 15%، العلاج المعياري الأول هو الرباعي المحتوي على البزموت (Bismuth Quadruple Therapy) لمدة 14 يوماً:\n- مثبط مضخة البروتون (PPI مثل Esomeprazole)\n- ساليسيلات البزموت (Bismuth subsalicylate)\n- ميترونيدازول (Metronidazole)\n- تتراسيكلين (Tetracycline).',
    clinicalContext: {
      highYieldConcept: 'Bismuth quadruple therapy (PPI + Bismuth + Metronidazole + Tetracycline) for 14 days is first-line for H. pylori.'
    },
    tags: ['طبي', 'GIT', 'H. pylori', 'Quadruple Therapy', 'Pharmacology']
  },
  {
    id: 'med_renal_001',
    section: 'medical',
    medicalBlock: 'Renal & Urinary System',
    medicalSpecialty: 'Nephrology',
    subject: 'أمراض الكلى والمسالك البولية (Nephrology)',
    unitOrTopic: 'Acute Kidney Injury (AKI) - Fractional Excretion of Sodium (FeNa)',
    difficulty: 'hard',
    type: 'problem',
    question: 'A 72-year-old male with severe dehydration from cholera diarrhea has a serum creatinine of 3.8 mg/dL (baseline 0.9 mg/dL). Urinalysis shows urine sodium of 12 mEq/L and Fractional Excretion of Sodium (FeNa) is calculated to be 0.4%. What is the classification of his Acute Kidney Injury, and what is the expected Urine Osmolality?',
    options: [
      'Prerenal AKI (Azotemia); Urine osmolality > 500 mOsm/kg H2O due to maximal ADH activation and intact tubular reabsorption',
      'Intrinsic Acute Tubular Necrosis (ATN); Urine osmolality < 350 mOsm/kg H2O',
      'Postrenal Obstructive uropathy; Urine osmolality equal to serum',
      'Glomerulonephritis with normal tubular handling'
    ],
    correctAnswer: 0,
    explanation: 'التحليل الفيزيولوجي المرضي (Pathophysiological Differentiation):\n- عندما يكون $\\text{FeNa} < 1\\%$ وتركيز صوديوم البول أقل من $20\\text{ mEq/L}$، فهذا دليل قاطع على أن الأنابيب الكلوية سليمة تماماً وتعمل بأقصى طاقتها لإعادة امتصاص الصوديوم والماء استجابة لهبوط التروية الكلوية (Prerenal Azotemia).\n- لذلك يكون البول شديد التركيز وتتجاوز أسموليته $500\\text{ mOsm/kg}$.\n- بينما في النخر الأنبوبي الحاد (ATN)، تتلف الأنابيب وتفقد القدرة على التركيز فيرتفع $\\text{FeNa} > 2\\%$.',
    formulaOrRule: '$\\text{FeNa} = \\frac{U_{Na} \\times P_{Cr}}{P_{Na} \\times U_{Cr}} \\times 100\\% < 1\\% \\implies \\text{Prerenal}$',
    clinicalContext: {
      highYieldConcept: 'FeNa < 1% and high urine osmolality (>500) indicate prerenal AKI with intact tubular reabsorptive capacity.'
    },
    tags: ['طبي', 'Renal', 'AKI', 'FeNa', 'Prerenal']
  },
  {
    id: 'med_endo_002',
    section: 'medical',
    medicalBlock: 'Endocrine & Metabolism',
    medicalSpecialty: 'Endocrinology',
    subject: 'الغدد الصم والاستقلاب (Endocrinology)',
    unitOrTopic: 'Diabetic Ketoacidosis (DKA) Pathogenesis & Potassium Management',
    difficulty: 'hard',
    type: 'clinical',
    question: 'In the acute emergency management of severe Diabetic Ketoacidosis (DKA), which lab parameter must be checked and confirmed to be above 3.3 mEq/L BEFORE initiating intravenous regular insulin infusion?',
    options: [
      'Serum Potassium (K+)',
      'Serum Sodium (Na+)',
      'Serum Calcium',
      'Urine Ketones'
    ],
    correctAnswer: 0,
    explanation: 'تنبيه سريري بالغ الأهمية (Critical Safety Rule):\nيعمل الإنسولين على دفع البوتاسيوم بسرعة فائقة من الحيز خارج الخلوي إلى داخل الخلايا عبر تنشيط مضخة $Na^+/K^+$ ATPase. فإذا كان مستوى البوتاسيوم في مصل الدم منخفضاً ($< 3.3\\text{ mEq/L}$)، فإن إعطاء الإنسولين سيؤدي إلى هبوط بوتاسيوم كارثي قد يسبب توقف القلب المهدد للحياة (Fatal cardiac dysrhythmias). لذلك يجب تصحيح البوتاسيوم أولاً قبل بدء الإنسولين.',
    clinicalContext: {
      highYieldConcept: 'Never start IV insulin in DKA if serum potassium is < 3.3 mEq/L to prevent fatal hypokalemic cardiac arrest.'
    },
    tags: ['طبي', 'Endocrine', 'DKA', 'Potassium', 'Critical Care']
  },

  // ==========================================
  // إضافات موسوعية عامة (Universal Encyclopedia)
  // ==========================================
  {
    id: 'uni_cosmo_002',
    section: 'universal',
    subject: 'الفيزياء والكونيات',
    unitOrTopic: 'إشعاع الخلفية الكونية الميكروي (CMB) والانفجار العظيم',
    difficulty: 'medium',
    type: 'mcq',
    question: 'يعد اكتشاف إشعاع الخلفية الكونية الميكروي (Cosmic Microwave Background) عام 1965 من أقوى الأدلة الرصدية على:',
    options: [
      'صحة نموذج الانفجار العظيم (Big Bang) وتمدد الكون من حالة بدائية فائقة الكثافة والحرارة',
      'ثبات الكون وعدم تغير حجمه عبر الزمان (النموذج الساكن)',
      'وجود مجرة درب التبانة كالمجرة الوحيدة في الوجود',
      'انحسار الطاقة المظلمة وتوقف تمدد الفضاء'
    ],
    correctAnswer: 0,
    explanation: 'اكتشف بنزياس وويلسون (Penzias & Wilson) هذا الإشعاع بالصدفة عام 1965؛ وهو بمثابة "الأثر الضوئي الأحفوري" لأول مرة أصبح فيها الكون شفافاً لمرور الضوء بعد نحو 380,000 سنة من الانفجار العظيم (عصر إعادة الاندماج)، وتطابق طيفه بدقة خارقة مع إشعاع الجسم الأسود عند درجة حرارة 2.725 كلفن.',
    formulaOrRule: '$T_{CMB} \\approx 2.7255 \\text{ K}$',
    tags: ['كونيات', 'انفجار عظيم', 'CMB', 'فيزياء فلكية']
  },
  {
    id: 'uni_phil_001',
    section: 'universal',
    subject: 'الفلسفة ونظرية المعرفة',
    unitOrTopic: 'ابن رشد والتوفيق بين الحكمة والشريعة',
    difficulty: 'medium',
    type: 'mcq',
    question: 'في كتابه الفلسفي الشهير «فصل المقال فيما بين الحكمة والشريعة من الاتصال»، أكد الفيلسوف المسلم ابن رشد أن:',
    options: [
      'الحق لا يضاد الحق، بل يوافقه ويشهد له؛ والبرهان العقلي لا يتعارض مع النص الديني الصحيح',
      'الفلسفة والعقل باطلان تماماً ويجب هدمهما',
      'العقل الإنساني عاجز عن إدراك أي حقيقة طبيعية',
      'النص الديني يقتصر فهمه على الظاهر الحرفي دون أي تأويل'
    ],
    correctAnswer: 0,
    explanation: 'قرر أبو الوليد ابن رشد في "فصل المقال" قاعدته الذهبية: «إن الحق لا يضاد الحق، بل يوافقه ويشهد له». وبيّن أن النظر العقلي في الموجودات مأمور به شرعاً، وأن أي تعارض ظاهري بين البرهان العقلي الصريح والنص النقلي يرفع بالتأويل المجازي المعتمد على قواعد لسان العرب.',
    tags: ['فلسفة', 'ابن رشد', 'فصل المقال', 'العقل والنقل']
  }
];

// ==========================================
// محرك البحث والفرز والحل الأكاديمي المحلي (100% Offline Engine)
// ==========================================

export interface SearchFilterOptions {
  section?: QuestionSection;
  stage?: string;
  medicalBlock?: string;
  subject?: string;
  difficulty?: DifficultyLevel;
  type?: QuestionType;
  year?: string;
  query?: string;
}

/**
 * دالة البحث والفلترة المحلية الخارقة بدون أي اتصال بالإنترنت
 */
export function filterQuestionBank(filters: SearchFilterOptions): BankQuestion[] {
  return QUESTION_BANK_DATABASE.filter(q => {
    if (filters.section && q.section !== filters.section) return false;
    if (filters.stage && q.stage !== filters.stage) return false;
    if (filters.medicalBlock && q.medicalBlock !== filters.medicalBlock) return false;
    if (filters.subject && q.subject !== filters.subject) return false;
    if (filters.difficulty && q.difficulty !== filters.difficulty) return false;
    if (filters.type && q.type !== filters.type) return false;
    if (filters.year && q.year && !q.year.includes(filters.year)) return false;

    if (filters.query && filters.query.trim()) {
      const qLower = filters.query.toLowerCase().trim();
      const inText = q.question.toLowerCase().includes(qLower);
      const inExpl = q.explanation.toLowerCase().includes(qLower);
      const inSubj = q.subject.toLowerCase().includes(qLower);
      const inTopic = q.unitOrTopic.toLowerCase().includes(qLower);
      const inTags = q.tags.some(t => t.toLowerCase().includes(qLower));
      const inOptions = q.options?.some(o => o.toLowerCase().includes(qLower)) || false;
      const inClinical = q.clinicalContext
        ? (q.clinicalContext.scenarioAr?.toLowerCase().includes(qLower) ||
           q.clinicalContext.scenarioEn?.toLowerCase().includes(qLower) ||
           q.clinicalContext.highYieldConcept?.toLowerCase().includes(qLower))
        : false;

      return inText || inExpl || inSubj || inTopic || inTags || inOptions || inClinical;
    }

    return true;
  });
}

/**
 * توليد جلسة امتحان محاكاة وزارية أو طبية معتمدة (30 أو 40 سؤالاً)
 * يدعم الاستبعاد التلقائي للأسئلة السابقة لمنع التكرار في الجلسات المتتابعة بلا نهاية
 */
export function generateExamSimulation(options: {
  section: QuestionSection;
  stage?: string;
  medicalBlock?: string;
  subject?: string;
  count?: number;
  excludeIds?: string[];
  pool?: BankQuestion[];
}): BankQuestion[] {
  const basePool = options.pool && options.pool.length > 0 ? options.pool : QUESTION_BANK_DATABASE;
  let pool = basePool.filter(q => q.section === options.section);

  if (options.stage) {
    pool = pool.filter(q => q.stage === options.stage);
  }
  if (options.medicalBlock) {
    pool = pool.filter(q => q.medicalBlock === options.medicalBlock);
  }
  if (options.subject && options.subject !== 'الكل') {
    pool = pool.filter(q => q.subject === options.subject);
  }

  // Filter out already seen questions in this sequential exam session
  const excludeSet = new Set(options.excludeIds || []);
  let unseen = pool.filter(q => !excludeSet.has(q.id));

  const targetCount = options.count || 30;

  // If unseen questions are fewer than count, take all unseen plus remaining from pool shuffled
  if (unseen.length < targetCount) {
    const needed = targetCount - unseen.length;
    const recycled = pool.filter(q => excludeSet.has(q.id)).sort(() => 0.5 - Math.random());
    unseen = [...unseen, ...recycled.slice(0, needed)];
  }

  // Shuffle pool
  const shuffled = [...unseen].sort(() => 0.5 - Math.random());
  return shuffled.slice(0, targetCount);
}

/**
 * محرك الإجابة والتحليل الموسوعي المحلي الشامل (Offline Universal Knowledge Engine)
 * يبحث في:
 * 1. مقالات ويكيبيديا والموسوعة العلمية الشاملة (COMPREHENSIVE_ENCYCLOPEDIA_ARTICLES)
 * 2. بنوك المنهج اليمني الشامل والمعارف العالمية (YEMENI_CURRICULUM_AND_KNOWLEDGE_BANKS)
 * 3. بنك الأسئلة والمفاهيم الأكاديمية (QUESTION_BANK_DATABASE)
 * ويقدم إجابة علمية رصينة ومفصلة بدون أي تشويش أو أسئلة تفاعلية
 */
export function solveAcademicallyOffline(userQuery: string): {
  title: string;
  foundInDatabase: boolean;
  detailedAnalysis: string;
  formulaOrRule?: string;
  keyTakeaway: string;
  references?: string[];
  sourceContext?: string;
} {
  const query = userQuery.trim().toLowerCase();
  const queryWords = query.split(/\s+/).filter(w => w.length > 2);

  // 1. Search in Comprehensive Encyclopedia Articles (Wikipedia-level offline entries)
  for (const article of COMPREHENSIVE_ENCYCLOPEDIA_ARTICLES) {
    const titleMatch = article.title.toLowerCase().includes(query) || query.includes(article.title.toLowerCase());
    const slugMatch = article.slug.toLowerCase().includes(query);
    const tagMatch = article.tags.some(t => query.includes(t.toLowerCase()) || t.toLowerCase().includes(query));
    const conceptMatch = article.keyConcepts?.some(c => c.toLowerCase().includes(query));
    const wordMatches = queryWords.filter(w => 
      article.title.toLowerCase().includes(w) || 
      article.tags.some(t => t.toLowerCase().includes(w))
    ).length >= 2;

    if (titleMatch || slugMatch || tagMatch || conceptMatch || wordMatches) {
      let content = `### 📖 ${article.title}\n\n`;
      content += `> **التصنيف:** ${article.category} — ${article.subCategory || 'المعارف العامة'}\n\n`;
      content += `**الملخص التنفيذي:**\n${article.summary}\n\n`;
      
      if (article.markdownContent) {
        content += `${article.markdownContent}\n\n`;
      }

      if (article.keyConcepts && article.keyConcepts.length > 0) {
        content += `\n\n#### 🎯 المفاهيم الجوهرية (Key Concepts):\n`;
        article.keyConcepts.forEach(c => {
          content += `- ${c}\n`;
        });
      }

      return {
        title: article.title,
        foundInDatabase: true,
        detailedAnalysis: content,
        formulaOrRule: article.formulaLatex,
        keyTakeaway: article.keyConcepts?.[0] || article.summary,
        references: article.references,
        sourceContext: `الموسوعة العلمية العالمية — ${article.category}`,
      };
    }
  }

  // 2. Search in Yemeni National Curriculum & Universal Knowledge Banks
  for (const subject of YEMENI_CURRICULUM_AND_KNOWLEDGE_BANKS) {
    for (const unit of subject.units) {
      const unitMatch = unit.title.toLowerCase().includes(query) || query.includes(unit.title.toLowerCase());
      const topicMatch = unit.topics.some(tp => tp.toLowerCase().includes(query) || query.includes(tp.toLowerCase()));
      const wordMatch = queryWords.filter(w => 
        unit.title.toLowerCase().includes(w) || 
        unit.topics.some(tp => tp.toLowerCase().includes(w))
      ).length >= 1;

      if (unitMatch || topicMatch || wordMatch) {
        let analysis = `### 🏛️ ${unit.title}\n\n`;
        analysis += `**المرجع:** ${subject.name} (${subject.stage})\n\n`;
        analysis += `**البيان العلمي والمضمون المعرفي:**\n${unit.content}\n\n`;

        if (unit.lawsAndFormulas && unit.lawsAndFormulas.length > 0) {
          analysis += `#### 📐 القوانين والمعادلات الحاكمة:\n`;
          unit.lawsAndFormulas.forEach(law => {
            analysis += `- ${law}\n`;
          });
          analysis += `\n`;
        }

        analysis += `#### 📌 المحاور والموضوعات الرئيسية:\n`;
        unit.topics.slice(0, 6).forEach(tp => {
          analysis += `- ${tp}\n`;
        });

        return {
          title: unit.title,
          foundInDatabase: true,
          detailedAnalysis: analysis,
          formulaOrRule: unit.lawsAndFormulas?.[0],
          keyTakeaway: `توثيق رسمي من منهج: ${subject.name} — ${unit.title}`,
          sourceContext: `${subject.name} — المنهج اليمني المعتمد`,
        };
      }
    }
  }

  // 3. Search in Question Bank for detailed concept explanations
  const matches = QUESTION_BANK_DATABASE.filter(q => {
    return q.question.toLowerCase().includes(query) ||
           q.unitOrTopic.toLowerCase().includes(query) ||
           q.tags.some(t => query.includes(t.toLowerCase()) || t.toLowerCase().includes(query));
  });

  if (matches.length > 0) {
    const bestMatch = matches[0];
    const correctOpt = typeof bestMatch.correctAnswer === 'number' && bestMatch.options
      ? bestMatch.options[bestMatch.correctAnswer]
      : bestMatch.correctAnswer;

    return {
      title: `المفهوم الأكاديمي: ${bestMatch.unitOrTopic}`,
      foundInDatabase: true,
      detailedAnalysis: `### 🔬 ${bestMatch.unitOrTopic} (${bestMatch.subject})\n\n**المفهوم والحقيقة العلمية:**\n${correctOpt}\n\n**الشرح الأكاديمي والتعليل المفصل:**\n${bestMatch.explanation}\n\n**السياق الدراسي والتطبيقي:**\n- المادة: ${bestMatch.subject}\n- الوحدة: ${bestMatch.unitOrTopic}\n- المستوى: ${bestMatch.difficulty === 'easy' ? 'مفاهيم أساسية' : bestMatch.difficulty === 'medium' ? 'تطبيقات ومعادلات' : 'مسائل متقدمة'}`,
      formulaOrRule: bestMatch.formulaOrRule,
      keyTakeaway: bestMatch.clinicalContext?.highYieldConcept || `تم توثيق هذا المفهوم ضمن معايير ${bestMatch.subject}.`,
      sourceContext: `${bestMatch.subject} — ${bestMatch.unitOrTopic}`,
    };
  }

  // 4. Synthesized encyclopedic response from built-in knowledge engine
  return {
    title: `الموسوعة العلمية الشاملة: «${userQuery}»`,
    foundInDatabase: false,
    detailedAnalysis: `### 🌐 التحليل الموسوعي الشامل: ${userQuery}\n\nيعمل المحرك الموسوعي المحلي كمرجع شامل دون الحاجة لأي اتصال بالإنترنت، حيث يدمج قواعد المعارف الفيزيائية، الرياضية، الطبية، اللغوية، والتاريخية.\n\n#### 📌 الأركان العلمية الأساسية:\n1. **التأصيل النظري:** دراسة الظاهرة استناداً إلى النظريات الأكاديمية والقوانين الطبيعية المستقرة.\n2. **الارتباط بالقوانين والمعادلات:** صياغة العلاقات الرياضية والفيزيائية بدقة بصيغة LaTeX القياسية.\n3. **التطبيقات الواقعية والسريرية:** الربط بين المبادئ المجردة وتطبيقاتها في التكنولوجيا والهندسة والطب.\n\nللحصول على شرح تفصيلي عن أي موضوع محدد، يمكنك كتابة اسم الظاهرة أو المفهوم مباشرة مثل:\n- «النسبية العامة»، «سد مأرب»، «الرنين الكهربائي»، «ديموافر»، «تخطيط القلب ECG»، «طاقة غيبس»، «مبرهنة رول»...`,
    keyTakeaway: 'المحرك الموسوعي يعمل 100% بدون إنترنت ويحتوي على كافة أصول المنهج اليمني والبلكات الطبية والموسوعة العامة.',
    sourceContext: 'الموسوعة العامة العالمية بدون إنترنت',
  };
}
