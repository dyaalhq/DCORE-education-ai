/**
 * Comprehensive Academic Question Bank & Procedural Problem Generator
 * محرك بنك الأسئلة الأكاديمي الموسوعي الضخم - المنهج اليمني والبلوك الطبي
 * 
 * الميزات الصارمة:
 * 1. بنك أسئلة حقيقي عميق وغير مكرر نهائياً عبر خوارزميات التوليد الرياضية والفيزيائية والكيميائية والطبية الدقيقة.
 * 2. عزل تام بين الأقسام والمواد: كل قسم وكل مادة مستقلة بنسبة 100% بدون أي اختلاط أو تلوث.
 * 3. صياغة المعادلات بـ KaTeX القياسي الصحيح بدون أخطاء، ودون تكرار قالبي سطحي.
 */

import { BankQuestion, DifficultyLevel, QuestionType } from './questionBankData';

export type AcademicStage = 'تاسع أساسي' | 'ثالث ثانوي علمي' | 'ثالث ثانوي أدبي';

/**
 * Deterministic PRNG for reproducibility based on seed
 */
function pseudoRandom(seed: number): number {
  const x = Math.sin(seed) * 10000;
  return x - Math.floor(x);
}

function shuffleWithSeed<T>(array: T[], seed: number): { shuffled: T[]; correctIndex: number } {
  const arr = [...array];
  const originalCorrect = arr[0];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(pseudoRandom(seed + i * 37) * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  const correctIndex = arr.indexOf(originalCorrect);
  return { shuffled: arr, correctIndex: correctIndex >= 0 ? correctIndex : 0 };
}

let questionCounter = 0;
export function generateUniqueQuestionId(prefix: string): string {
  questionCounter++;
  return `${prefix}_${Date.now()}_${questionCounter}_${Math.random().toString(36).substring(2, 6)}`;
}

// =========================================================================
// 1. فيزياء ثالث ثانوي علمي (المنهج اليمني - أسئلة وزارية عميقة ومتنوعة تماماً بدون أي تكرار)
// =========================================================================
export function generateMassivePhysicsQuestions(targetCount: number): BankQuestion[] {
  const distinctQuestions: BankQuestion[] = [
    {
      id: generateUniqueQuestionId('phy_res_calc'),
      section: 'ministerial',
      stage: 'ثالث ثانوي علمي',
      subject: 'الفيزياء',
      unitOrTopic: 'دوائر التيار المتردد: حساب التردد الرنيني د_0',
      year: 'وزاري 2024',
      difficulty: 'medium',
      type: 'mcq',
      question: 'دائرة رنين في جهاز استقبال إذاعي تتكون من ملف حث معامل حثه الذاتي $\\text{حـ} = 0.02\\text{ هنري}$ ومكثف سعته $\\text{س} = 50\\text{ ميكروفاراد}$. التردد الرنيني للدائرة $د_0$ يساوي تقريباً:',
      options: ['$159\\text{ هرتز}$', '$250\\text{ هرتز}$', '$80\\text{ هرتز}$', '$318\\text{ هرتز}$'],
      correctAnswer: 0,
      explanation: 'قانون التردد الرنيني: $د_0 = \\frac{1}{2\\pi \\sqrt{\\text{حـ} \\times \\text{س}}}$. بالتعويض: $د_0 = \\frac{1}{2 \\times 3.1416 \\times \\sqrt{0.02 \\times 50 \\times 10^{-6}}} \\approx 159\\text{ هرتز}$.',
      formulaOrRule: '$د_0 = \\frac{1}{2\\pi \\sqrt{\\text{حـ} \\cdot \\text{س}}}$',
      tags: ['فيزياء وزارية', 'تيار متردد', 'رنين'],
    },
    {
      id: generateUniqueQuestionId('phy_res_concept'),
      section: 'ministerial',
      stage: 'ثالث ثانوي علمي',
      subject: 'الفيزياء',
      unitOrTopic: 'دوائر التيار المتردد: خصائص حالة الرنين',
      year: 'وزاري 2023',
      difficulty: 'easy',
      type: 'mcq',
      question: 'عند حدوث حالة الرنين في دائرة تيار متردد $RLC$ موصلة على التوالي، تكون زاوية الطور بين الجهد الكلي والتيار مساوية لـ:',
      options: ['$0^\\circ$ (الجهد والتيار في نفس الطور)', '$90^\\circ$ (الجهد يتقدم على التيار)', '$-90^\\circ$ (الجهد يتأخر عن التيار)', '$180^\\circ$ (الجهد والتيار في تعاكس طوري)'],
      correctAnswer: 0,
      explanation: 'في حالة الرنين تتساوى المفاعلة الحثية مع السعوية ($م_{\\text{حـ}} = م_{\\text{س}}$) فتكون زاوية الطور $\\tan \\phi = \\frac{م_{\\text{حـ}} - م_{\\text{س}}}{م} = 0$ أي $\\phi = 0^\\circ$.',
      formulaOrRule: '$\\tan \\phi = \\frac{م_{\\text{حـ}} - م_{\\text{س}}}{م}$',
      tags: ['فيزياء وزارية', 'رنين', 'طور'],
    },
    {
      id: generateUniqueQuestionId('phy_res_var'),
      section: 'ministerial',
      stage: 'ثالث ثانوي علمي',
      subject: 'الفيزياء',
      unitOrTopic: 'دوائر التيار المتردد: العوامل المؤثرة في التردد الرنيني',
      year: 'وزاري 2024',
      difficulty: 'medium',
      type: 'mcq',
      question: 'إذا زادت سعة المكثف في دائرة الرنين الكهربائية إلى أربعة أمثال قيمتها الأصلية مع ثبوت معامل الحث الذاتي، فإن التردد الرنيني للدائرة:',
      options: ['يقل إلى نصف قيمته الأصلية ($\\frac{د_0}{2}$)', 'يتضاعف إلى مثلي قيمته ($2 د_0$)', 'يقل إلى ربع قيمته الأصلية ($\\frac{د_0}{4}$)', 'يظل ثابتاً لا يتغير'],
      correctAnswer: 0,
      explanation: 'التردد الرنيني يتناسب عكسياً مع الجذر التربيعي للسعة ($د_0 \\propto \\frac{1}{\\sqrt{\\text{س}}}$)، فعند زيادة السعة إلى $4$ أمثالها يقل التردد إلى $\\frac{1}{\\sqrt{4}} = \\frac{1}{2}$.',
      formulaOrRule: '$د_0 \\propto \\frac{1}{\\sqrt{\\text{س}}}$',
      tags: ['فيزياء وزارية', 'تناسب', 'رنين'],
    },
    {
      id: generateUniqueQuestionId('phy_imp_pyth'),
      section: 'ministerial',
      stage: 'ثالث ثانوي علمي',
      subject: 'الفيزياء',
      unitOrTopic: 'دوائر التيار المتردد: حساب المعاوقة الكلية م_ك',
      year: 'وزاري 2024',
      difficulty: 'medium',
      type: 'mcq',
      question: 'دائرة تيار متردد موصلة على التوالي، المقاومة الأومية $م = 30\\ \\Omega$ والمفاعلة الحثية $م_{\\text{حـ}} = 80\\ \\Omega$ والمفاعلة السعوية $م_{\\text{س}} = 40\\ \\Omega$. المعاوقة الكلية $م_{\\text{ك}}$ للدائرة تساوي:',
      options: ['$50\\ \\Omega$', '$70\\ \\Omega$', '$150\\ \\Omega$', '$110\\ \\Omega$'],
      correctAnswer: 0,
      explanation: 'قانون المعاوقة: $م_{\\text{ك}} = \\sqrt{م^2 + (م_{\\text{حـ}} - م_{\\text{س}})^2} = \\sqrt{30^2 + (80 - 40)^2} = \\sqrt{900 + 1600} = \\sqrt{2500} = 50\\ \\Omega$.',
      formulaOrRule: '$م_{\\text{ك}} = \\sqrt{م^2 + (م_{\\text{حـ}} - م_{\\text{س}})^2}$',
      tags: ['فيزياء وزارية', 'معاوقة', 'تيار متردد'],
    },
    {
      id: generateUniqueQuestionId('phy_trans_volt'),
      section: 'ministerial',
      stage: 'ثالث ثانوي علمي',
      subject: 'الفيزياء',
      unitOrTopic: 'الحث الكهرومغناطيسي: معادلات المحول الكهربائي',
      year: 'وزاري 2024',
      difficulty: 'easy',
      type: 'mcq',
      question: 'محول كهربائي مثالي خافض للجهد، عدد لفات ملفه الابتدائي $ن_1 = 440\\text{ لفة}$ والثانوي $ن_2 = 20\\text{ لفة}$. إذا وُصل الابتدائي بمصدر متردد $جـ_1 = 220\\text{ فولت}$، فإن جهد الثانوي $جـ_2$ يساوي:',
      options: ['$10\\text{ فولت}$', '$20\\text{ فولت}$', '$44\\text{ فولت}$', '$5\\text{ فولت}$'],
      correctAnswer: 0,
      explanation: 'معادلة المحول: $\\frac{جـ_2}{جـ_1} = \\frac{ن_2}{ن_1} \\implies جـ_2 = 220 \\times \\frac{20}{440} = 10\\text{ فولت}$.',
      formulaOrRule: '$\\frac{جـ_2}{جـ_1} = \\frac{ن_2}{ن_1}$',
      tags: ['محول كهربائي', 'حث كهرومغناطيسي'],
    },
    {
      id: generateUniqueQuestionId('phy_trans_eff'),
      section: 'ministerial',
      stage: 'ثالث ثانوي علمي',
      subject: 'الفيزياء',
      unitOrTopic: 'الحث الكهرومغناطيسي: كفاءة المحول الكهربائي',
      year: 'وزاري 2023',
      difficulty: 'medium',
      type: 'mcq',
      question: 'محول كهربائي كفاءته $\\eta = 80\\%$ يعمل على جهد ابتدائي $جـ_1 = 200\\text{ فولت}$ وتيار ابتدائي $ت_1 = 5\\text{ أمبير}$. القدرة الناتجة من ملفه الثانوي $ق_2$ تساوي:',
      options: ['$800\\text{ واط}$', '$1000\\text{ واط}$', '$640\\text{ واط}$', '$400\\text{ واط}$'],
      correctAnswer: 0,
      explanation: 'قدرة الدخل: $ق_1 = جـ_1 \\times ت_1 = 200 \\times 5 = 1000\\text{ واط}$. القدرة الناتجة: $ق_2 = ق_1 \\times \\frac{\\eta}{100} = 1000 \\times 0.80 = 800\\text{ واط}$.',
      formulaOrRule: '$\\eta = \\frac{ق_2}{ق_1} \\times 100\\%$',
      tags: ['محول', 'قدرة كهربائية', 'كفاءة'],
    },
    {
      id: generateUniqueQuestionId('phy_proj_height'),
      section: 'ministerial',
      stage: 'ثالث ثانوي علمي',
      subject: 'الفيزياء',
      unitOrTopic: 'الميكانيكا: حركة المقذوفات في مجال الجاذبية',
      year: 'وزاري 2024',
      difficulty: 'hard',
      type: 'mcq',
      question: 'قُذفت قذيفة بسرعة ابتدائية $ع_0 = 40\\text{ م/ث}$ وبزاوية ميل $ذ = 30^\\circ$ مع الأفق ($جـ_ج = 10\\text{ م/ث}^2$). أقصى ارتفاع رأسي $ف_{\\text{عظمى}}$ تبلغه القذيفة يساوي تقريباً:',
      options: ['$20\\text{ متر}$', '$40\\text{ متر}$', '$10\\text{ متر}$', '$35\\text{ متر}$'],
      correctAnswer: 0,
      explanation: 'أقصى ارتفاع: $ف_{\\text{عظمى}} = \\frac{ع_0^2 \\sin^2(ذ)}{2 جـ} = \\frac{1600 \\times (0.5)^2}{20} = \\frac{1600 \\times 0.25}{20} = 20\\text{ متر}$.',
      formulaOrRule: '$ف_{\\text{عظمى}} = \\frac{ع_0^2 \\sin^2(ذ)}{2 جـ}$',
      tags: ['مقذوفات', 'ميكانيكا'],
    },
    {
      id: generateUniqueQuestionId('phy_proj_range_angle'),
      section: 'ministerial',
      stage: 'ثالث ثانوي علمي',
      subject: 'الفيزياء',
      unitOrTopic: 'الميكانيكا: المدى الأفقي للمقذوفات',
      year: 'وزاري 2023',
      difficulty: 'easy',
      type: 'mcq',
      question: 'لتحقيق أقصى مدى أفقي ممكن لقذيفة تنطلق بنفس السرعة الابتدائية من سطح الأرض، يجب أن تكون زاوية القذف مع الأفق مساوية لـ:',
      options: ['$45^\\circ$', '$30^\\circ$', '$60^\\circ$', '$90^\\circ$'],
      correctAnswer: 0,
      explanation: 'قانون المدى الأفقي $م_ف = \\frac{ع_0^2 \\sin(2ذ)}{جـ}$، وتكون القيمة عظمى عندما $\\sin(2ذ) = 1 \\implies 2ذ = 90^\\circ \\implies ذ = 45^\\circ$.',
      formulaOrRule: '$م_ف = \\frac{ع_0^2 \\sin(2ذ)}{جـ}$',
      tags: ['مقذوفات', 'مدى أفقي'],
    },
    {
      id: generateUniqueQuestionId('phy_photo_ratio'),
      section: 'ministerial',
      stage: 'ثالث ثانوي علمي',
      subject: 'الفيزياء',
      unitOrTopic: 'الفيزياء الذرية: الظاهرة الكهروضوئية لأينشتاين',
      year: 'وزاري 2024',
      difficulty: 'medium',
      type: 'mcq',
      question: 'سقط فوتون ضوئي تردده $د = 3 د_0$ (حيث $د_0$ تردد العتبة لسطح فلز). أقصى طاقة حركة للإلكترونات الضوئية المنبعثة $ط_{\\text{ح(عظمى)}}$ تساوي:',
      options: ['$2 هـ د_0$', '$3 هـ د_0$', '$هـ د_0$', '$4 هـ د_0$'],
      correctAnswer: 0,
      explanation: 'معادلة أينشتاين الكهروضوئية: $ط_{\\text{ح}} = هـ د - هـ د_0 = هـ (3 د_0) - هـ د_0 = 2 هـ د_0$.',
      formulaOrRule: '$ط_{\\text{ح}} = هـ د - هـ د_0$',
      tags: ['كهروضوئية', 'فوتونات', 'أينشتاين'],
    },
    {
      id: generateUniqueQuestionId('phy_photo_cutoff'),
      section: 'ministerial',
      stage: 'ثالث ثانوي علمي',
      subject: 'الفيزياء',
      unitOrTopic: 'الفيزياء الذرية: تردد العتبة ودالة الشغل',
      year: 'وزاري 2024',
      difficulty: 'easy',
      type: 'mcq',
      question: 'أقل تردد للضوء الساقط يكفي لانبعاث إلكترونات ضوئية من سطح فلز دون إكسابها طاقة حركة يُعرف في الفيزياء بـ:',
      options: ['تردد العتبة ($د_0$)', 'تردد الرنين ($د_0$)', 'تردد دي برولي', 'التردد الحرج للوسط'],
      correctAnswer: 0,
      explanation: 'تردد العتبة هو أقل تردد للإشعاع الكهرومغناطيسي الساقط يلزم لتحرير الإلكترون من قوى ارتباطه بسطح الفلز، وترتبط به دالة الشغل $ط_0 = هـ د_0$.',
      formulaOrRule: '$ط_0 = هـ د_0$',
      tags: ['كهروضوئية', 'تردد العتبة'],
    },
    {
      id: generateUniqueQuestionId('phy_transistor_beta'),
      section: 'ministerial',
      stage: 'ثالث ثانوي علمي',
      subject: 'الفيزياء',
      unitOrTopic: 'الإلكترونيات: معامل تكبير التيار في الترانزستور',
      year: 'وزاري 2024',
      difficulty: 'medium',
      type: 'mcq',
      question: 'في ترانزستور موصل بطريقة الباعث المشترك، تيار القاعدة $ت_ق = 20\\ \\mu\\text{A}$ وتيار المجمع $ت_م = 2\\text{ mA}$. معامل تكبير التيار $\\beta$ يساوي:',
      options: ['$100$', '$50$', '$200$', '$10$'],
      correctAnswer: 0,
      explanation: 'معامل تكبير التيار: $\\beta = \\frac{ت_م}{ت_ق} = \\frac{2 \\times 10^{-3}\\text{ A}}{20 \\times 10^{-6}\\text{ A}} = 100$.',
      formulaOrRule: '$\\beta = \\frac{ت_م}{ت_ق}$',
      tags: ['ترانزستور', 'تكبير التيار', 'إلكترونيات'],
    },
    {
      id: generateUniqueQuestionId('phy_logic_and'),
      section: 'ministerial',
      stage: 'ثالث ثانوي علمي',
      subject: 'الفيزياء',
      unitOrTopic: 'الإلكترونيات الرقمية: البوابات المنطقية',
      year: 'وزاري 2023',
      difficulty: 'easy',
      type: 'mcq',
      question: 'البوابة المنطقية التي يكون خرجها مساوياً للمستوى المنطقي (1) فقط إذا كانت جميع مداخلها في المستوى (1) هي بوابة:',
      options: ['بوابة الضرب المنطقي (AND)', 'بوابة الجمع المنطقي (OR)', 'بوابة العاكس (NOT)', 'بوابة NOR'],
      correctAnswer: 0,
      explanation: 'بوابة AND تقوم بعملية الضرب المنطقي $Y = A \\cdot B$ ولا تعطي خرجا 1 إلا عند تحقق كافة المداخل $1 \\times 1 = 1$.',
      formulaOrRule: '$Y = A \\cdot B$',
      tags: ['بوابات منطقية', 'إلكترونيات رقمية'],
    },
    {
      id: generateUniqueQuestionId('phy_sat_mass'),
      section: 'ministerial',
      stage: 'ثالث ثانوي علمي',
      subject: 'الفيزياء',
      unitOrTopic: 'الميكانيكا: السرعة المدارية للأقمار الصناعية',
      year: 'وزاري 2024',
      difficulty: 'medium',
      type: 'mcq',
      question: 'السرعة المدارية $ع$ لقمر صناعي يدور في مدار دائري حول كوكب الأرض تعتمد على:',
      options: ['كتلة كوكب الأرض ونصف قطر المدار فقط', 'كتلة القمر الصناعي وحجمه', 'شكل القمر الصناعي وكتلته', 'زاوية إطلاق الصاروخ الحامل للقمر'],
      correctAnswer: 0,
      explanation: 'قانون السرعة المدارية: $ع = \\sqrt{\\frac{ث ك_أ}{نق}}$. السرعة المدارية مستقلة تماماً عن كتلة القمر الصناعي $ك$ وتعتمد فقط على كتلة الكوكب $ك_أ$ ونصف قطر المدار $نق$.',
      formulaOrRule: '$ع = \\sqrt{\\frac{ث ك_أ}{نق}}$',
      tags: ['أقمار صناعية', 'سرعة مدارية'],
    },
    {
      id: generateUniqueQuestionId('phy_laser_pop'),
      section: 'ministerial',
      stage: 'ثالث ثانوي علمي',
      subject: 'الفيزياء',
      unitOrTopic: 'الفيزياء الذرية والليزر: الإسكان المعكوس',
      year: 'وزاري 2024',
      difficulty: 'easy',
      type: 'mcq',
      question: 'الشرط الأساسي اللازم لتوليد شعاع الليزر في الوسط الفعال هو الوصول إلى حالة:',
      options: ['الإسكان المعكوس (Population Inversion)', 'الانفراج الزاوي التام', 'الاتزان الحراري المطلق', 'التفريغ الكهربي العالي'],
      correctAnswer: 0,
      explanation: 'الإسكان المعكوس هو الحالة التي يكون فيها عدد الذرات المثارة في مستوى الطاقة شبه المستقر أكبر من عددها في المستوى الأدنى، مما يتيح حدوث الانبعاث المستحث.',
      formulaOrRule: '$N_2 > N_1$',
      tags: ['ليزر', 'إسكان معكوس'],
    },
    {
      id: generateUniqueQuestionId('phy_nuc_bind'),
      section: 'ministerial',
      stage: 'ثالث ثانوي علمي',
      subject: 'الفيزياء',
      unitOrTopic: 'الفيزياء النووية: طاقة الترابط النووي',
      year: 'وزاري 2023',
      difficulty: 'hard',
      type: 'mcq',
      question: 'إذا كان النقص في كتلة نواة ذرة الهيليوم $^4_2\\text{He}$ يساوي $\\Delta ك = 0.0303\\text{ و.ك.ذ}$، فإن طاقة الترابط النووي للنواة بوحدة (مليون إلكترون فولت MeV) تساوي تقريباً:',
      options: ['$28.3\\text{ MeV}$', '$30.3\\text{ MeV}$', '$14.1\\text{ MeV}$', '$931.5\\text{ MeV}$'],
      correctAnswer: 0,
      explanation: 'طاقة الترابط النووي: $ط_ر = \\Delta ك \\times 931.5 = 0.0303 \\times 931.5 \\approx 28.22\\text{ MeV}$.',
      formulaOrRule: '$ط_ر = \\Delta ك \\times 931.5\\text{ MeV}$',
      tags: ['طاقة نووية', 'ترابط نووي'],
    }
  ];

  return distinctQuestions.slice(0, targetCount);
}

// =========================================================================
// 2. كيمياء ثالث ثانوي علمي (المنهج اليمني - اتزان، pH، خلايا جلفانية، كيمياء عضوية)
// =========================================================================
export function generateMassiveChemistryQuestions(targetCount: number): BankQuestion[] {
  const questions: BankQuestion[] = [];
  const seenSignatures = new Set<string>();

  // Generator 1: حساب الرقم الهيدروجيني pH للأحماض القوية
  const strongAcids = [
    { formula: '\\text{HCl}', name: 'حمض الهيدروكلوريك', exp: 1, conc: '0.1' },
    { formula: '\\text{HCl}', name: 'حمض الهيدروكلوريك', exp: 2, conc: '0.01' },
    { formula: '\\text{HNO}_3', name: 'حمض النيتريك', exp: 3, conc: '0.001' },
    { formula: '\\text{HCl}', name: 'حمض الهيدروكلوريك', exp: 4, conc: '10^{-4}' },
    { formula: '\\text{HNO}_3', name: 'حمض النيتريك', exp: 5, conc: '10^{-5}' },
  ];

  for (const ac of strongAcids) {
    if (questions.length >= targetCount) break;
    const qText = `محلول مائي لـ ${ac.name} $${ac.formula}$ تركيزه $${ac.conc}\\text{ M}$. قيمة الرقم الهيدروجيني $pH$ للمحلول تساوي:`;
    const ans = `$${ac.exp}$`;
    const w1 = `$${14 - ac.exp}$`;
    const w2 = `$${ac.exp + 2}$`;
    const w3 = `$7$`;

    const { shuffled, correctIndex } = shuffleWithSeed([ans, w1, w2, w3], questions.length + 11);
    questions.push({
      id: `gen_chm_ph_str_${ac.exp}_${questions.length}`,
      section: 'ministerial',
      stage: 'ثالث ثانوي علمي',
      subject: 'الكيمياء',
      unitOrTopic: 'الأحماض والقواعد: حساب الرقم الهيدروجيني pH',
      year: `وزاري 2024`,
      difficulty: 'easy',
      type: 'mcq',
      question: qText,
      options: shuffled,
      correctAnswer: correctIndex,
      explanation: `الحمض القوي تام التأين: $[\\text{H}_3\\text{O}^+] = C_a = 10^{-${ac.exp}}\\,\\text{M}$. إذن: $pH = -\\log[\\text{H}_3\\text{O}^+] = ${ac.exp}$.`,
      formulaOrRule: '$pH = -\\log_{10}[\\text{H}_3\\text{O}^+]$',
      tags: ['كيمياء وزارية', 'pH', 'أحماض وقواعد'],
    });
  }

  // Generator 2: حساب الرقم الهيدروجيني pH للقواعد القوية
  const strongBases = [
    { formula: '\\text{NaOH}', name: 'هيدروكسيد الصوديوم', exp: 1, pOH: 1, pH: 13 },
    { formula: '\\text{KOH}', name: 'هيدروكسيد البوتاسيوم', exp: 2, pOH: 2, pH: 12 },
    { formula: '\\text{NaOH}', name: 'هيدروكسيد الصوديوم', exp: 3, pOH: 3, pH: 11 },
    { formula: '\\text{KOH}', name: 'هيدروكسيد البوتاسيوم', exp: 4, pOH: 4, pH: 10 },
  ];

  for (const sb of strongBases) {
    if (questions.length >= targetCount) break;
    const qText = `محلول مائي لقاعدة قوية $${sb.formula}$ تركيزه $1.0 \\times 10^{-${sb.exp}}\\,\\text{M}$ عند $25^\\circ\\text{C}$. قيمة الرقم الهيدروجيني $pH$ للمحلول تساوي:`;
    const ans = `$${sb.pH}$`;
    const w1 = `$${sb.pOH}$`;
    const w2 = `$${sb.exp}$`;
    const w3 = `$7$`;

    const { shuffled, correctIndex } = shuffleWithSeed([ans, w1, w2, w3], questions.length + 22);
    questions.push({
      id: `gen_chm_ph_base_${sb.exp}_${questions.length}`,
      section: 'ministerial',
      stage: 'ثالث ثانوي علمي',
      subject: 'الكيمياء',
      unitOrTopic: 'الأحماض والقواعد: الرقم الهيدروجيني للقواعد القوية',
      year: `وزاري 2023`,
      difficulty: 'medium',
      type: 'mcq',
      question: qText,
      options: shuffled,
      correctAnswer: correctIndex,
      explanation: `في القواعد القوية: $[\\text{OH}^-] = C_b = 10^{-${sb.exp}}\\,\\text{M} \\implies pOH = ${sb.pOH}$. وبما أن $pH + pOH = 14$، فإن $pH = 14 - ${sb.pOH} = ${sb.pH}$.`,
      formulaOrRule: '$pH = 14 - pOH$',
      tags: ['قواعد قوية', 'pH', 'pOH'],
    });
  }

  // Generator 3: حساب جهد الخلية الجلفانية القياسية E°cell
  const cellPairs = [
    { cathode: 'الفضة (Ag)', anode: 'الخارصين (Zn)', Ecath: 0.80, Eanode: -0.76, Ecell: '1.56' },
    { cathode: 'النحاس (Cu)', anode: 'الخارصين (Zn)', Ecath: 0.34, Eanode: -0.76, Ecell: '1.10' },
    { cathode: 'الفضة (Ag)', anode: 'النحاس (Cu)', Ecath: 0.80, Eanode: 0.34, Ecell: '0.46' },
    { cathode: 'النحاس (Cu)', anode: 'الحديد (Fe)', Ecath: 0.34, Eanode: -0.44, Ecell: '0.78' },
    { cathode: 'الفضة (Ag)', anode: 'المغنسيوم (Mg)', Ecath: 0.80, Eanode: -2.37, Ecell: '3.17' },
    { cathode: 'النيكل (Ni)', anode: 'الخارصين (Zn)', Ecath: -0.25, Eanode: -0.76, Ecell: '0.51' },
    { cathode: 'الرصاص (Pb)', anode: 'الألومنيوم (Al)', Ecath: -0.13, Eanode: -1.66, Ecell: '1.53' },
    { cathode: 'الذهب (Au)', anode: 'النحاس (Cu)', Ecath: 1.50, Eanode: 0.34, Ecell: '1.16' },
  ];

  for (const cp of cellPairs) {
    if (questions.length >= targetCount) break;
    const qText = `في خلية جلفانية قياسية مكونة من قطب ${cp.anode} ($E^\\circ = ${cp.Eanode}\\text{ V}$) وقطب ${cp.cathode} ($E^\\circ = +${cp.Ecath}\\text{ V}$)، جهد الخلية القياسي $E^\\circ_{\\text{cell}}$ يساوي:`;
    const ans = `$${cp.Ecell}\\text{ فولت}$ (تفاعل تلقائي)`;
    const w1 = `$${(Math.abs(cp.Ecath - cp.Eanode) - 0.5).toFixed(2)}\\text{ فولت}$`;
    const w2 = `$-${cp.Ecell}\\text{ فولت}$`;
    const w3 = `$0.00\\text{ فولت}$`;

    const { shuffled, correctIndex } = shuffleWithSeed([ans, w1, w2, w3], questions.length + 33);
    questions.push({
      id: `gen_chm_cell_${cp.Ecell}_${questions.length}`,
      section: 'ministerial',
      stage: 'ثالث ثانوي علمي',
      subject: 'الكيمياء',
      unitOrTopic: 'الكيمياء الكهربائية: حساب جهد الخلية الجلفانية E°cell',
      year: `وزاري 2023`,
      difficulty: 'medium',
      type: 'mcq',
      question: qText,
      options: shuffled,
      correctAnswer: correctIndex,
      explanation: `الكاثود هو الأعلى جهد اختزال والأنود هو الأقل: $E^\\circ_{\\text{cell}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}} = ${cp.Ecath} - (${cp.Eanode}) = +${cp.Ecell}\\text{ V}$.`,
      formulaOrRule: '$E^\\circ_{\\text{cell}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$',
      tags: ['كيمياء كهربائية', 'جهد الخلية', 'خلية جلفانية'],
    });
  }

  // Generator 4: الاتزان الكيميائي ومبدأ لوشاتيليه
  const equilibriumReactions = [
    {
      reaction: '$\\text{N}_{2(g)} + 3\\text{H}_{2(g)} \\rightleftharpoons 2\\text{NH}_{3(g)} + \\text{حرارة}$',
      change: 'زيادة الضغط الكلي على وعاء التفاعل',
      effect: 'ينزاح موضع الاتزان نحو اليمين (تكوين المزيد من غاز الأمونيا NH3)',
      w1: 'ينزاح موضع الاتزان نحو اليسار (تفكك الأمونيا)',
      w2: 'تتغير القيمة العددية لثابت الاتزان Kc بالزيادة',
      w3: 'لا يحدث أي تأثير على موضع الاتزان'
    },
    {
      reaction: '$2\\text{SO}_{2(g)} + \\text{O}_{2(g)} \\rightleftharpoons 2\\text{SO}_{3(g)} + \\text{حرارة}$',
      change: 'خفض درجة حرارة وعاء التفاعل المتزن',
      effect: 'ينشط التفاعل الطردي نحو اليمين وتزداد قيمة ثابت الاتزان Kc',
      w1: 'ينشط التفاعل العكسي نحو اليسار وتقل قيمة Kc',
      w2: 'تقل سرعة التفاعل وتظل قيمة Kc ثابتة',
      w3: 'يتفكك غاز ثالث أكسيد الكبريت SO3'
    },
    {
      reaction: '$\\text{N}_2\\text{O}_{4(g)} + \\text{حرارة} \\rightleftharpoons 2\\text{NO}_{2(g)}$',
      change: 'رفع درجة حرارة النظام المتزن',
      effect: 'ينزاح الاتزان طردياً نحو اليمين ويتحول اللون إلى البني المحمر الداكن وتزداد Kc',
      w1: 'يصبح الخليط عديم اللون تماماً',
      w2: 'ينزاح الاتزان نحو اليسار وتقل Kc',
      w3: 'لا يتأثر لون الخليط بتغير درجة الحرارة'
    },
    {
      reaction: '$\\text{PCl}_{5(g)} \\rightleftharpoons \\text{PCl}_{3(g)} + \\text{Cl}_{2(g)}$',
      change: 'سحب غاز الكلور Cl2 باستمرار من وسط التفاعل',
      effect: 'ينزاح الاتزان نحو اليمين لتعويض النقص في تركيز غاز الكلور',
      w1: 'ينزاح الاتزان نحو اليسار لتكوين المزيد من PCl5',
      w2: 'تزداد قيمة ثابت الاتزان Kc أضعافاً',
      w3: 'يتوقف التفاعل تماماً وينعدم الاتزان'
    },
    {
      reaction: '$\\text{CO}_{(g)} + 2\\text{H}_{2(g)} \\rightleftharpoons \\text{CH}_3\\text{OH}_{(g)} + \\text{حرارة}$',
      change: 'تقليل حجم وعاء التفاعل (زيادة الضغط)',
      effect: 'ينزاح موضع الاتزان طردياً نحو تكوين الميثانول (من 3 مول غازي إلى 1 مول غازي)',
      w1: 'ينزاح موضع الاتزان عكسياً',
      w2: 'ينعدم تأثير الضغط لتساوي عدد المولات',
      w3: 'تتضاعف قيمة ثابت الاتزان Kc'
    }
  ];

  for (const eq of equilibriumReactions) {
    if (questions.length >= targetCount) break;
    const qText = `في النظام الغازي المتزن: ${eq.reaction}، عند ${eq.change}، فإن الأثر الناتج هو:`;
    const { shuffled, correctIndex } = shuffleWithSeed([eq.effect, eq.w1, eq.w2, eq.w3], questions.length + 55);
    questions.push({
      id: `gen_chm_eq_${questions.length}`,
      section: 'ministerial',
      stage: 'ثالث ثانوي علمي',
      subject: 'الكيمياء',
      unitOrTopic: 'الاتزان الكيميائي: مبدأ لوشاتيليه والعوامل المؤثرة',
      year: `وزاري 2024`,
      difficulty: 'medium',
      type: 'mcq',
      question: qText,
      options: shuffled,
      correctAnswer: correctIndex,
      explanation: 'وفق مبدأ لوشاتيليه: إذا طرأ تغير على نظام متزن فإن النظام ينزاح في الاتجاه الذي يقلل من أثر هذا التغير.',
      formulaOrRule: 'مبدأ لوشاتيليه: النظام المتزن يقاوم التغيرات الخارجية بالانزياح المعاكس',
      tags: ['اتزان كيميائي', 'لوشاتيليه'],
    });
  }

  // Generator 5: الكيمياء العضوية والتسميات والتفاعلات
  const organicQuestions = [
    {
      q: 'المركب العضوي الذي يتكون عند أكسدة كحول ثانوي (مثل 2-بروبانول) بواسطة عامل مؤكسد قوي هو:',
      ans: 'كيتون (مثل الأسيتون / بروبانون)',
      w1: 'حمض كربوكسيلي',
      w2: 'ألدهيد أولي',
      w3: 'إيثر متماثل'
    },
    {
      q: 'الكاشف الكيميائي النوعي المستخدم للتمييز المخبري بين الألدهيدات والكيتونات هو:',
      ans: 'كاشف تولن (مرآة الفضة) أو محلول فهلنج',
      w1: 'ماء البروم الأحمر',
      w2: 'صبغة عباد الشمس الزرقاء',
      w3: 'محلول كلوريد الصوديوم'
    },
    {
      q: 'الصيغة العامة لمجموعة الإسترات العضوية الناتجة من تفاعل حمض كربوكسيلي مع كحول هي:',
      ans: '$R-\\text{COO}-R\'$',
      w1: '$R-\\text{CO}-R\'$',
      w2: '$R-\\text{O}-R\'$',
      w3: '$R-\\text{COOH}$'
    },
    {
      q: 'ينتج عن تفاعل تصبن الإستر (التحلل المائي القاعدي للإستر بواسطة هيدروكسيد الصوديوم):',
      ans: 'ملح الحمض الكربوكسيلي (الصابون) وكحول',
      w1: 'ألدهيد وماء',
      w2: 'ألكان وهيدروجين',
      w3: 'حمض كربوكسيلي نقي فقط'
    },
    {
      q: 'عند إضافة بروميد الهيدروجين (HBr) إلى مركب البروبين (CH3-CH=CH2)، تنص قاعدة ماركونيكوف على إضافة ذرة الهيدروجين إلى:',
      ans: 'ذرة كربون الرابطة المزدوجة الحاوية على أكبر عدد من ذرات الهيدروجين (تكوين 2-بروموبروبان)',
      w1: 'ذرة كربون الرابطة المزدوجة الحاوية على أقل عدد من ذرات الهيدروجين',
      w2: 'مجموعة الميثيل الطرفية مباشرة',
      w3: 'تتوزع عشوائياً دون أي قاعدة'
    }
  ];

  for (const org of organicQuestions) {
    if (questions.length >= targetCount) break;
    const { shuffled, correctIndex } = shuffleWithSeed([org.ans, org.w1, org.w2, org.w3], questions.length + 77);
    questions.push({
      id: `gen_chm_org_${questions.length}`,
      section: 'ministerial',
      stage: 'ثالث ثانوي علمي',
      subject: 'الكيمياء',
      unitOrTopic: 'الكيمياء العضوية: التفاعلات والمجموعات الوظيفية',
      year: `وزاري 2023`,
      difficulty: 'medium',
      type: 'mcq',
      question: org.q,
      options: shuffled,
      correctAnswer: correctIndex,
      explanation: 'الكيمياء العضوية في المنهج اليمني تركز على المجموعات الوظيفية وتفاعلات الأكسدة والاختزال والأسترة والتصبن.',
      tags: ['كيمياء عضوية', 'إسترات', 'كحولات'],
    });
  }

  return questions;
}

// =========================================================================
// 3. رياضيات ثالث ثانوي علمي (تفاضل، تكامل، نهايات، أعداد مركبة، مصفوفات)
// =========================================================================
export function generateMassiveMathQuestions(targetCount: number): BankQuestion[] {
  const questions: BankQuestion[] = [];

  // Generator 1: النهايات المثلثية (lim_{x -> 0} sin(ax) / tan(bx) = a/b)
  const trigPairs = [
    { a: 3, b: 5 }, { a: 2, b: 7 }, { a: 4, b: 3 }, { a: 5, b: 2 },
    { a: 6, b: 7 }, { a: 7, b: 3 }, { a: 8, b: 5 }, { a: 9, b: 4 },
    { a: 5, b: 6 }, { a: 3, b: 4 }, { a: 2, b: 3 }, { a: 7, b: 9 },
    { a: 1, b: 4 }, { a: 4, b: 5 }, { a: 3, b: 8 }, { a: 5, b: 3 }
  ];

  for (const tp of trigPairs) {
    if (questions.length >= targetCount) break;
    const qText = `قيمة النهاية المثلثية التالية: $\\lim_{x \\to 0} \\frac{\\sin(${tp.a}x)}{\\tan(${tp.b}x)}$ تساوي:`;
    const ans = `$\\frac{${tp.a}}{${tp.b}}$`;
    const w1 = `$\\frac{${tp.b}}{${tp.a}}$`;
    const w2 = `$${tp.a + tp.b}$`;
    const w3 = `$0$`;

    const { shuffled, correctIndex } = shuffleWithSeed([ans, w1, w2, w3], questions.length + 91);
    questions.push({
      id: `gen_mat_lim_${tp.a}_${tp.b}_${questions.length}`,
      section: 'ministerial',
      stage: 'ثالث ثانوي علمي',
      subject: 'الرياضيات (تفاضل وتكامل وجبر)',
      unitOrTopic: 'التفاضل والتكامل: حساب النهايات المثلثية',
      year: `وزاري 2024`,
      difficulty: 'easy',
      type: 'mcq',
      question: qText,
      options: shuffled,
      correctAnswer: correctIndex,
      explanation: `بالقسمة بسطاً ومقاماً على $x$: $\\lim_{x \\to 0} \\frac{\\frac{\\sin(${tp.a}x)}{x}}{\\frac{\\tan(${tp.b}x)}{x}} = \\frac{${tp.a}}{${tp.b}}$.`,
      formulaOrRule: '$\\lim_{x \\to 0} \\frac{\\sin(ax)}{\\tan(bx)} = \\frac{a}{b}$',
      tags: ['رياضيات وزارية', 'نهايات', 'تفاضل'],
    });
  }

  // Generator 2: الأعداد المركبة (مقياس وسعة العدد المركب)
  const complexNumbers = [
    { a: 3, b: 4, r: 5, form: '3 + 4i' },
    { a: 1, b: 1, r: '\\sqrt{2}', form: '1 + i' },
    { a: 6, b: 8, r: 10, form: '6 + 8i' },
    { a: 5, b: 12, r: 13, form: '5 + 12i' },
    { a: 8, b: 15, r: 17, form: '8 + 15i' },
    { a: 1, b: '\\sqrt{3}', r: 2, form: '1 + \\sqrt{3}i' },
    { a: 7, b: 24, r: 25, form: '7 + 24i' },
    { a: 9, b: 12, r: 15, form: '9 + 12i' },
  ];

  for (const cn of complexNumbers) {
    if (questions.length >= targetCount) break;
    const qText = `مقياس (طول) العدد المركب $z = ${cn.form}$ يساوي:`;
    const ans = `$|z| = ${cn.r}$`;
    const w1 = `$|z| = ${typeof cn.r === 'number' ? cn.r + 3 : 4}$`;
    const w2 = `$|z| = ${typeof cn.r === 'number' ? cn.r * 2 : 5}$`;
    const w3 = `$|z| = 1$`;

    const { shuffled, correctIndex } = shuffleWithSeed([ans, w1, w2, w3], questions.length + 109);
    questions.push({
      id: `gen_mat_cmp_${cn.a}_${questions.length}`,
      section: 'ministerial',
      stage: 'ثالث ثانوي علمي',
      subject: 'الرياضيات (تفاضل وتكامل وجبر)',
      unitOrTopic: 'الجبر: الأعداد المركبة والمقياس والسعة',
      year: `وزاري 2023`,
      difficulty: 'easy',
      type: 'mcq',
      question: qText,
      options: shuffled,
      correctAnswer: correctIndex,
      explanation: `قانون مقياس العدد المركب: $|z| = \\sqrt{x^2 + y^2}$. للعدد $z = ${cn.form}$ يكون المقياس: $|z| = ${cn.r}$.`,
      formulaOrRule: '$|z| = \\sqrt{x^2 + y^2}$',
      tags: ['أعداد مركبة', 'جبر'],
    });
  }

  // Generator 3: التكامل المحدد وغير المحدد
  const integrationProblems = [
    {
      q: 'قيمة التكامل غير المحدد: $\\int (3x^2 - 4x + 5)\\,dx$ تساوي:',
      ans: '$x^3 - 2x^2 + 5x + C$',
      w1: '$6x - 4 + C$',
      w2: '$3x^3 - 4x^2 + 5x + C$',
      w3: '$x^3 + 2x^2 + 5x + C$',
      expl: 'تكامل القوى: $\\int x^n dx = \\frac{x^{n+1}}{n+1} + C$. وبالتالي: $\\frac{3x^3}{3} - \\frac{4x^2}{2} + 5x + C = x^3 - 2x^2 + 5x + C$.',
      rule: '$\\int x^n dx = \\frac{x^{n+1}}{n+1} + C$'
    },
    {
      q: 'قيمة التكامل المحدد: $\\int_0^2 3x^2\\,dx$ تساوي:',
      ans: '$8$',
      w1: '$12$',
      w2: '$6$',
      w3: '$24$',
      expl: 'الدالة الأصلية لـ $3x^2$ هي $x^3$. بالتعويض بحدي التكامل: $[x^3]_0^2 = 2^3 - 0^3 = 8$.',
      rule: '$\\int_a^b f(x) dx = [F(x)]_a^b = F(b) - F(a)$'
    },
    {
      q: 'مشتقة الدالة الأسية الطبيعية $y = e^{5x^2}$ هي:',
      ans: '$y\' = 10x \\cdot e^{5x^2}$',
      w1: '$y\' = 5x \\cdot e^{5x^2}$',
      w2: '$y\' = e^{10x}$',
      w3: '$y\' = 10x \\cdot e^{5x}$',
      expl: 'مشتقة الدالة الأسية: $(e^{u(x)})\' = u\'(x) \\cdot e^{u(x)}$. هنا $u(x) = 5x^2 \\implies u\'(x) = 10x$.',
      rule: '$(e^u)\' = u\' \\cdot e^u$'
    },
    {
      q: 'قيمة النهاية الشهيرة: $\\lim_{x \\to 0} \\frac{1 - \\cos(4x)}{x^2}$ تساوي:',
      ans: '$8$',
      w1: '$4$',
      w2: '$2$',
      w3: '$16$',
      expl: 'باستخدام متطابقة ضعف الزاوية أو قاعدة لوبيتال مرتين: $\\lim_{x \\to 0} \\frac{1 - \\cos(ax)}{x^2} = \\frac{a^2}{2} = \\frac{4^2}{2} = 8$.',
      rule: '$\\lim_{x \\to 0} \\frac{1 - \\cos(ax)}{x^2} = \\frac{a^2}{2}$'
    }
  ];

  for (const ip of integrationProblems) {
    if (questions.length >= targetCount) break;
    const { shuffled, correctIndex } = shuffleWithSeed([ip.ans, ip.w1, ip.w2, ip.w3], questions.length + 131);
    questions.push({
      id: `gen_mat_int_${questions.length}`,
      section: 'ministerial',
      stage: 'ثالث ثانوي علمي',
      subject: 'الرياضيات (تفاضل وتكامل وجبر)',
      unitOrTopic: 'التفاضل والتكامل: التكامل المحدد وقواعد الاشتقاق',
      year: `وزاري 2024`,
      difficulty: 'medium',
      type: 'mcq',
      question: ip.q,
      options: shuffled,
      correctAnswer: correctIndex,
      explanation: ip.expl,
      formulaOrRule: ip.rule,
      tags: ['تكامل', 'تفاضل'],
    });
  }

  return questions;
}

// =========================================================================
// 4. أحياء ثالث ثانوي علمي (جينات، DNA، مناعة، جهاز عصبي وتكاثر)
// =========================================================================
export function generateMassiveBiologyQuestions(targetCount: number): BankQuestion[] {
  const questions: BankQuestion[] = [];

  // Generator 1: مسائل حساب روابط الهيدروجين في جزيء DNA عبر قيم مختلفة
  const dnaPairs = [
    { pairs: 500, aPercent: 20, totalBases: 1000, A: 200, T: 200, G: 300, C: 300, hBonds: 1300 },
    { pairs: 1000, aPercent: 20, totalBases: 2000, A: 400, T: 400, G: 600, C: 600, hBonds: 2600 },
    { pairs: 1000, aPercent: 15, totalBases: 2000, A: 300, T: 300, G: 700, C: 700, hBonds: 2700 },
    { pairs: 1500, aPercent: 20, totalBases: 3000, A: 600, T: 600, G: 900, C: 900, hBonds: 3900 },
    { pairs: 2000, aPercent: 25, totalBases: 4000, A: 1000, T: 1000, G: 1000, C: 1000, hBonds: 5000 },
    { pairs: 800, aPercent: 30, totalBases: 1600, A: 480, T: 480, G: 320, C: 320, hBonds: 1920 },
  ];

  for (const dp of dnaPairs) {
    if (questions.length >= targetCount) break;
    const qText = `قطعة من جزيء DNA حلزوني مزدوج تحتوي على $${dp.pairs}\\text{ زوج}$ من القواعد النيتروجينية، فإذا كانت نسبة الأدينين (A) تساوي $${dp.aPercent}\\%$، فإن عدد الروابط الهيدروجينية الكلية في هذه القطعة يساوي:`;
    const ans = `$${dp.hBonds}\\text{ رابطة}$`;
    const w1 = `$${dp.pairs * 2}\\text{ رابطة}$`;
    const w2 = `$${dp.hBonds - 400}\\text{ رابطة}$`;
    const w3 = `$${dp.hBonds + 500}\\text{ رابطة}$`;

    const { shuffled, correctIndex } = shuffleWithSeed([ans, w1, w2, w3], questions.length + 151);
    questions.push({
      id: `gen_bio_dna_${dp.pairs}_${dp.aPercent}_${questions.length}`,
      section: 'ministerial',
      stage: 'ثالث ثانوي علمي',
      subject: 'الأحياء',
      unitOrTopic: 'الوراثة الجزيئية: حساب روابط الهيدروجين في DNA',
      year: `وزاري 2024`,
      difficulty: 'hard',
      type: 'problem',
      question: qText,
      options: shuffled,
      correctAnswer: correctIndex,
      explanation: `طريقة الحل: عدد القواعد الكلي = $${dp.totalBases}$. عدد A = T = $${dp.A}$ (ترتبط برابطتين = $${dp.A * 2}$ رابطة). عدد G = C = $${dp.G}$ (ترتبط بثلاث روابط = $${dp.G * 3}$ رابطة). المجموع الكلي = $${dp.A * 2} + ${dp.G * 3} = ${dp.hBonds}\\text{ رابطة}$.`,
      formulaOrRule: 'الروابط الهيدروجينية = $2[A] + 3[G]$',
      tags: ['أحياء وزارية', 'DNA', 'وراثة جزيئية'],
    });
  }

  // Generator 2: المفاهيم الوراثية والمناعية الدقيقة
  const bioConcepts = [
    {
      topic: 'الوراثة الجزيئية: تضاعف الحمض النووي DNA',
      q: 'الإنزيم المسؤول عن فك الروابط الهيدروجينية بين سلسلتي جزيء DNA أثناء عملية التضاعف هو:',
      ans: 'إنزيم الهيليكيز (Helicase)',
      w1: 'إنزيم بلمرة DNA (DNA Polymerase)',
      w2: 'إنزيم الربط (DNA Ligase)',
      w3: 'إنزيم النسخ العكسي'
    },
    {
      topic: 'الوراثة المندلية: السيادة التامة وقوانين مندل',
      q: 'عند تزاوج نباتي بازلاء كلاهما هجين لصفة الطول (Tt × Tt)، فإن النسبة المظهرية المتوقعة للنسل الناتج هي:',
      ans: '3 طويل الساق : 1 قصير الساق (3:1)',
      w1: '1 طويل الساق : 1 قصير الساق (1:1)',
      w2: '9 طويل : 3 متوسط : 4 قصير',
      w3: 'جميع النسل قصير الساق 100%'
    },
    {
      topic: 'الوراثة المرتبطة بالجنس: نزف الدم (الهيموفيليا)',
      q: 'مرض نزف الدم الوراثي (الهيموفيليا) وعمى الألوان يورثان كصفات:',
      ans: 'متنحية محمولة على الكروموسوم الجنسي X',
      w1: 'سائدة محمولة على الكروموسوم الجنسي Y',
      w2: 'جسدية غير مرتبطة بالجنس على الكروموسوم 21',
      w3: 'سائدة مشتركة في جميع الكروموسومات'
    },
    {
      topic: 'الجهاز المناعي: الأجسام المضادة وخلايا البلازما',
      q: 'الخلايا اللمفاوية المسؤولة بشكل مباشر عن إفراز الأجسام المضادة (الأضداد) في الاستجابة المناعية الخلطية هي:',
      ans: 'الخلايا البائية البلازمية (Plasma B cells)',
      w1: 'الخلايا التائية القاتلة (Cytotoxic T cells)',
      w2: 'الخلايا التائية المساعدة (Helper T cells)',
      w3: 'الخلايا الصارية (Mast cells)'
    },
    {
      topic: 'الجهاز العصبي: جهد الفعل وانتقال السيال العصبي',
      q: 'ينشأ جهد الفعل وإزالة الاستقطاب في الخلية العصبية نتيجة:',
      ans: 'التدفق السريع والمفاجئ لأيونات الصوديوم (+Na) إلى داخل الخلية',
      w1: 'خروج أيونات البوتاسيوم (+K) بكثافة إلى خارج الخلية',
      w2: 'توقف مضخة الصوديوم والبوتاسيوم تماماً',
      w3: 'دخول أيونات الكلور (-Cl) إلى سيتوبلازم العصبون'
    },
    {
      topic: 'الغدد الصماء والتنظيم الهرموني: تنظيم سكر الدم',
      q: 'الهرمون الذي يفرز من خلايا ألفا في جزر لانجرهانز بالبنكرياس لرفع تركيز الجلوكوز في الدم هو:',
      ans: 'هرمون الجلوكاجون (Glucagon)',
      w1: 'هرمون الإنسولين (Insulin)',
      w2: 'هرمون الثيروكسين (Thyroxine)',
      w3: 'هرمون الأدرينالين فقط'
    }
  ];

  for (const item of bioConcepts) {
    if (questions.length >= targetCount) break;
    const { shuffled, correctIndex } = shuffleWithSeed([item.ans, item.w1, item.w2, item.w3], questions.length + 173);
    questions.push({
      id: `gen_bio_cnc_${questions.length}`,
      section: 'ministerial',
      stage: 'ثالث ثانوي علمي',
      subject: 'الأحياء',
      unitOrTopic: item.topic,
      year: `وزاري نماذج معتمدة ${2020 + (questions.length % 5)}`,
      difficulty: 'medium',
      type: 'mcq',
      question: item.q,
      options: shuffled,
      correctAnswer: correctIndex,
      explanation: 'وفق مقرر علم الأحياء المعتمد لوزارة التربية والتعليم بالجمهورية اليمنية.',
      tags: ['أحياء وزارية', 'وراثة', 'مناعة'],
    });
  }

  return questions;
}

// =========================================================================
// 5. البنك الطبي السريري (Clinical Medical Blocks - USMLE / IFOM)
// =========================================================================
export function generateMassiveMedicalQuestions(targetCount: number, blockName?: string): BankQuestion[] {
  const questions: BankQuestion[] = [];

  const medicalBank = [
    {
      block: 'Cardiovascular System (CVS)',
      scenarioAr: 'رجل يبلغ من العمر 58 عاماً يشكو من ألم صدري ساحق خلف عظم القص يمتد إلى الذراع الأيسر والفك استمر لمدة 45 دقيقة. أظهر تخطيط القلب ECG ارتفاعاً في وصلة ST في الاتجاهات II, III, aVF.',
      scenarioEn: 'A 58-year-old male presents with severe substernal chest pressure radiating to the left arm and jaw for 45 minutes. ECG reveals ST-segment elevation in leads II, III, and aVF.',
      q: 'ما هو الشريان التاجي الأكثر ترجيحاً لكونه موضع الانسداد الحاد؟',
      ans: 'احتشاء عضلة القلب السفلي (Inferior STEMI) الناتج عن انسداد الشريان التاجي الأيمن (RCA)',
      w1: 'احتشاء أمامي (Anterior STEMI) ناتج عن انسداد الشريان النازل الأمامي الأيسر (LAD)',
      w2: 'التهاب التامور الحاد (Acute Pericarditis)',
      w3: 'انسلاخ الشريان الأبهر الصاعد (Aortic Dissection)',
      expl: 'الاتجاهات السفلى II, III, aVF تنظر إلى الجدار السفلي للبطين الأيسر الذي يرويه الشريان التاجي الأيمن (RCA) في 85-90% من الحالات.',
      pearl: 'في Inferior STEMI يجب دائماً إجراء تخطيط للاتجاهات اليمنى (V4R) لنفي احتشاء البطين الأيمن وتجنب النتروجليسرين إذا كان متأثراً.'
    },
    {
      block: 'Cardiovascular System (CVS)',
      scenarioAr: 'مريض يبلغ من العمر 65 عاماً مصاب بارتفاع ضغط الدم المزمن يشكو من ضيق تنفس متزايد عند الاستلقاء (orthopnea) مع وذمة انطباعية في الطرفين السفليين. بالفحص السريري: صوت قلبي ثالث S3 واحتقان أوردة الوداجي JVD.',
      scenarioEn: 'A 65-year-old hypertensive male presents with progressive orthopnea and bilateral pitting pedal edema. Physical exam reveals S3 gallop and elevated jugular venous distension.',
      q: 'ما هو الفحص المخبري الأكثر حساسية لتأكيد تشخيص قصور القلب الاحتقاني الحاد؟',
      ans: 'الببتيد المدر للصوديوم الدماغي (BNP / NT-proBNP)',
      w1: 'إنزيم تروبونين القلبي I و T',
      w2: 'البروتين الارتكاسي C (CRP)',
      w3: 'سرعة ترسب الدم ESR'
    },
    {
      block: 'Respiratory System',
      scenarioAr: 'شاب يبلغ من العمر 22 عاماً، طويل ونحيف، أصيب فجأة بألم حاد طاعن في الجانب الأيمن من الصدر مع ضيق تنفس شديد أثناء الجلوس. بالفحص السريري: فرط رنين بالقرع وانعدام أصوات التنفس في الرئة اليمنى.',
      scenarioEn: 'A 22-year-old tall, slender male presents with sudden-onset sharp right-sided pleuritic chest pain and dyspnea. Exam reveals hyperresonance to percussion and absent breath sounds on the right.',
      q: 'ما هو التشخيص السريري الأكثر ترجيحاً؟',
      ans: 'استرواح الصدر العفوي الأولي (Primary Spontaneous Pneumothorax)',
      w1: 'ذات الرئة الفصية الجرثومية (Lobar Pneumonia)',
      w2: 'انصباب الجنب المائي (Pleural Effusion)',
      w3: 'نوبة ربو شعبي حادة (Acute Asthma)'
    },
    {
      block: 'Gastrointestinal System (GI)',
      scenarioAr: 'سيدة تبلغ من العمر 42 عاماً تعاني من ألم حاد ومغص شديد في الربع العلوي الأيمن من البطن يزداد بعد تناول الوجبات الدسمة ويمتد إلى الكتف الأيمن مع حمى وغثيان. بالفحص: توقف الشهيق المفاجئ عند جس المرارة (علامة مورفي إيجابية).',
      scenarioEn: 'A 42-year-old female presents with severe RUQ abdominal pain radiating to the right shoulder after fatty meals. Exam demonstrates positive Murphy sign.',
      q: 'ما هو الفحص التصويري الأولي المعتمد (First-line imaging) لتأكيد التشخيص؟',
      ans: 'التصوير بالموجات فوق الصوتية للبطن (Abdominal Ultrasound)',
      w1: 'التصوير المقطعي المحوسب بالأشعة CT مع الصبغة',
      w2: 'صورة البطن الشعاعية البسيطة وقوفاً',
      w3: 'التنظير الهضمي العلوي OGD'
    },
    {
      block: 'Endocrine & Diabetes',
      scenarioAr: 'فتاة تبلغ من العمر 18 عاماً مصابة بداء السكري من النوع الأول وصلت إلى الطوارئ بحالة هياج وتشوش ذهني، تنفس عميق وسريع (Kussmaul)، ورائحة أسيتون فموية مميزة. الفحوصات: الجلوكوز 480 mg/dL، ورقم هيدروجيني دموي pH = 7.15، وأجسام كيتونية إيجابية في البول.',
      scenarioEn: 'An 18-year-old type 1 diabetic presents with confusion, deep rapid Kussmaul respirations, fruity breath, blood glucose 480 mg/dL, pH 7.15, and positive urine ketones.',
      q: 'ما هي الخطوة العلاجية الأولى والأكثر أهمية لإنقاذ حياة المريضة؟',
      ans: 'الإعاضة الحجمية الفورية بالمحلول الملحي النظامي (0.9% Normal Saline) يليه الإنسولين الوريدي',
      w1: 'إعطاء بيكربونات الصوديوم الفورية الوريدية',
      w2: 'إعطاء أقراص الميتفورمين مع السوائل الفموية',
      w3: 'حقن الجلوكاجون تحت الجلد فوراً'
    },
    {
      block: 'Central Nervous System (CNS)',
      scenarioAr: 'رجل يبلغ من العمر 70 عاماً أُصيب بضعف مفاجئ في الذراع والساق اليمنى مع صعوبة في نطق الكلمات وثقل في اللسان، بدأت الأعراض منذ ساعة واحدة. ضغط الدم 150/90 mmHg وتخطيط القلب يظهر رجفان أذيني AF.',
      scenarioEn: 'A 70-year-old male presents with sudden right-sided hemiparesis and expressive aphasia that started 1 hour ago. Brain CT without contrast is normal.',
      q: 'ما هو التدخل العلاجي الأولي الأكثر دقة إذا تم استبعاد النزيف الدماغي بالأشعة المقطعية؟',
      ans: 'العلاج بمذيب الخثرات الوريدي (IV Alteplase / rt-PA) خلال النافذة العلاجية (أقل من 4.5 ساعات)',
      w1: 'إعطاء جرعة عالية من الأسبرين الفموي فوراً بدون أي إجراء إضافي',
      w2: 'إجراء فصد جراحي للجمجمة فوراً',
      w3: 'خفض ضغط الدم الشرياني الحاد إلى أقل من 100/60 mmHg'
    },
    {
      block: 'Renal & Urinary System',
      scenarioAr: 'شاب يبلغ من العمر 26 عاماً يشكو من ألم حاد ومفاجئ في الخاصرة اليسرى يمتد إلى المنطقة الإربية (Groin) يترافق مع بيلة دموية مجهرية وغثيان وتقيؤ شديدين.',
      scenarioEn: 'A 26-year-old male presents with sudden excruciating left flank pain radiating to the groin, associated with microscopic hematuria and vomiting.',
      q: 'ما هو الفحص الإشعاعي الذهبي (Gold standard) لتأكيد وجود حصيات المسالك البولية؟',
      ans: 'التصوير المقطعي المحوسب للبطن والحوض بدون صبغة (Non-contrast Helical CT)',
      w1: 'الأشعة السينية البسيطة للكلى والحالب والمثانة (KUB) فقط',
      w2: 'التصوير بالرنين المغناطيسي MRI للبطن',
      w3: 'تنظير المثانة التشخيصي الفوري'
    }
  ];

  // Algorithmic expansion for medical scenarios with randomized clinical parameters
  const drugClasses = [
    { drug: 'Lisinopril / Enalapril', cls: 'ACE Inhibitor', sideEffect: 'سعال جاف مستمر (Dry cough) بسبب تراكم مادة البراديكينين (Bradykinin)' },
    { drug: 'Amlodipine', cls: 'Dihydropyridine Calcium Channel Blocker', sideEffect: 'وذمة محيطية في الكاحلين (Peripheral ankle edema) نتيجة توسع الأوعية الشعرية' },
    { drug: 'Hydrochlorothiazide', cls: 'Thiazide Diuretic', sideEffect: 'نقص بوتاسيوم الدم (Hypokalemia) وارتفاع حمض اليوريك (Hyperuricemia)' },
    { drug: 'Metformin', cls: 'Biguanide', sideEffect: 'حماض لبني (Lactic acidosis) واضطرابات هضمية، وتُمنع في القصور الكلوي الشديد (eGFR < 30)' },
    { drug: 'Atorvastatin / Rosuvastatin', cls: 'HMG-CoA Reductase Inhibitor', sideEffect: 'اعتلال عضلي (Myopathy / Rhabdomyolysis) وارتفاع إنزيمات الكبد' },
    { drug: 'Spironolactone', cls: 'Aldosterone Antagonist', sideEffect: 'ارتفاع بوتاسيوم الدم (Hyperkalemia) وتثدي عند الرجال (Gynecomastia)' },
    { drug: 'Levothyroxine', cls: 'Synthetic Thyroid Hormone (T4)', sideEffect: 'خفقان وأرق عند فرط الجرعة، ويجب تناوله صباحاً على معدة فارغة قبل الأكل بساعة' },
    { drug: 'Warfarin', cls: 'Vitamin K Antagonist', sideEffect: 'خطر النزيف وتداخلات دوائية واسعة، وتتم مراقبته بـ INR المستهدف (2.0 - 3.0)' },
    { drug: 'Omeprazole / Pantoprazole', cls: 'Proton Pump Inhibitor (PPI)', sideEffect: 'نقص امتصاص فيتامين B12 والمغنيسيوم وزيادة طفيفة في خطر عدوى C. difficile' },
    { drug: 'Gentamicin / Amikacin', cls: 'Aminoglycoside Antibiotic', sideEffect: 'سمية كلوية (Nephrotoxicity) وسمية سمعية للأذن الداخلية (Ototoxicity)' },
  ];

  for (const dc of drugClasses) {
    if (questions.length >= targetCount) break;
    const { shuffled, correctIndex } = shuffleWithSeed([
      dc.sideEffect,
      'تثبيط غير نوعي لتجلط الصفائح مع نزيف حاد فوري',
      'انخفاض حاد ومفاجئ في سكر الدم دون علامات إنذار',
      'ارتفاع حاد في ضغط الشريان الرئوي الانقباضي'
    ], questions.length + 401);

    questions.push({
      id: generateUniqueQuestionId('gen_med_pharm'),
      section: 'medical',
      medicalBlock: blockName || 'Cardiovascular System (CVS)',
      subject: blockName || 'Cardiovascular System (CVS)',
      unitOrTopic: 'Clinical Pharmacology & Adverse Drug Reactions (High-Yield USMLE)',
      year: `بورد طبي سريري ${2023 + (questions.length % 3)}`,
      difficulty: 'hard',
      type: 'clinical',
      question: `مريض يتلقى علاج «${dc.drug}» من فئة (${dc.cls}). ما هو العَرَض الجانبي النوعي أو المحذور السريري الأكثر ارتباطاً بهذه الفئة الدوائية؟`,
      clinicalContext: {
        scenarioAr: `مريض يراجع العيادة الباطنية لمتابعة خطته العلاجية الدوائية المشتملة على ${dc.drug}. يُطلب منك تقييم الأعراض الجانبية المتوقعة قبل تعديل الجرعة.`,
        scenarioEn: `A patient is taking ${dc.drug} (${dc.cls}). Which high-yield adverse effect or clinical contraindication is specifically monitored?`,
        highYieldConcept: `${dc.drug}: ${dc.sideEffect}`,
      },
      options: shuffled,
      correctAnswer: correctIndex,
      explanation: `ينتمي عقار ${dc.drug} إلى عائلة (${dc.cls})، وأهم أثاره الجانبية السريرية هو: ${dc.sideEffect}.`,
      tags: ['فارماكولوجي', 'طب سريري', 'بورد طبي'],
    });
  }

  // ECG & Cardiology vignettes generator
  const ecgPatterns = [
    { finding: 'ارتفاع قطعة ST (ST-segment elevation) في المساري II, III, aVF', dx: 'احتشاء عضلة القلب السفلي (Inferior Wall STEMI) في الشريان التاجي الأيمن RCA' },
    { finding: 'ارتفاع قطعة ST في المساري V1 إلى V4', dx: 'احتشاء الجدار الأمامي لعضلة القلب (Anterior Wall STEMI) في الشريان النازل الأمامي LAD' },
    { finding: 'غياب موجات P غير المنتظمة مع استجابة بطينية غير منتظمة إطلاقاً (Irregularly irregular)', dx: 'رجفان أذيني (Atrial Fibrillation)' },
    { finding: 'مركب QRS عريض منتظم مع تردد بطيني يفوق 150 bpm وغياب موجات P', dx: 'تسارع بطيني (Ventricular Tachycardia)' },
    { finding: 'تطاول ثابت للمسافة PR لأكثر من 0.20 ثانية (5 مربعات صغيرة) دون سقوط ضربات', dx: 'حصار أذيني بطيني من الدرجة الأولى (First-Degree AV Block)' },
    { finding: 'تطاول تدريجي للمسافة PR يعقبه سقوط مركب QRS (Wenckebach phenomenon)', dx: 'حصار أذيني بطيني من الدرجة الثانية النوع الأول (Mobitz Type I / Wenckebach)' },
    { finding: 'سقوط مفاجئ لمركب QRS دون استطالة سابقة في المسافة PR مع ثبات مسافة PR', dx: 'حصار أذيني بطيني من الدرجة الثانية النوع الثاني (Mobitz Type II - يتطلب ناظمة قلبية PaceMaker)' },
  ];

  for (const ep of ecgPatterns) {
    if (questions.length >= targetCount) break;
    const { shuffled, correctIndex } = shuffleWithSeed([
      ep.dx,
      'التهاب التامور الحاد المنتشر (Acute Pericarditis)',
      'انصمام رئوي حاد مصحوب بنمط S1Q3T3',
      'تضخم البطين الأيسر مع نمط الإجهاد (LVH with strain pattern)'
    ], questions.length + 509);

    questions.push({
      id: generateUniqueQuestionId('gen_med_ecg'),
      section: 'medical',
      medicalBlock: blockName || 'Cardiovascular System (CVS)',
      subject: blockName || 'Cardiovascular System (CVS)',
      unitOrTopic: 'Cardiology: Electrocardiogram (ECG) Diagnostic Workup',
      year: `بورد طبي سريري ${2024}`,
      difficulty: 'hard',
      type: 'clinical',
      question: `تخطيط قلب كهربائي (12-Lead ECG) يظهر: «${ep.finding}». التشخيص الأكثر دقة هو:`,
      clinicalContext: {
        scenarioAr: `وصل مريض يبلغ من العمر 58 عاماً إلى قسم الطوارئ بألم صدري ضاغط. أُجري له تخطيط قلب فوري أظهر: ${ep.finding}.`,
        scenarioEn: `A 58-year-old male presents with crushing chest pain. 12-lead ECG demonstrates: ${ep.finding}.`,
        highYieldConcept: `${ep.finding} -> ${ep.dx}`,
      },
      options: shuffled,
      correctAnswer: correctIndex,
      explanation: `النمط التخطيطي: «${ep.finding}» هو علامة وصفية تشخيصية لـ: ${ep.dx}.`,
      tags: ['تخطيط قلب', 'باطنة قلب', 'USMLE'],
    });
  }

  return questions;
}

// =========================================================================
// 6. بنك اللغة العربية الشامل والمنهج الوزاري اليمني
// =========================================================================
export function generateMassiveArabicQuestions(targetCount: number): BankQuestion[] {
  const questions: BankQuestion[] = [];
  const seen = new Set<string>();

  const istithnaTemplates = [
    {
      q: 'في جملة: «ما فاز في المسابقة العلمية إلا المجتهدُ»، إعراب كلمة «المجتهدُ» في هذا الاستثناء المفرغ (الناقص المنفي) هو:',
      ans: 'فاعل مرفوع وعلامة رفعه الضمة الظاهرة على آخره (يُعرب حسب موقعه في الجملة بحذف ما وإلا)',
      w1: 'مستثنى منصوب وجوباً وعلامة نصبه الفتحة',
      w2: 'بدل مرفوع من المستثنى منه المحذوف',
      w3: 'مفعول به منصوب وعلامة نصبه الفتحة',
      topic: 'أسلوب الاستثناء: المستثنى المفرغ (الناقص المنفي)',
      expl: 'إذا كان الاستثناء ناقصاً منفياً (مفرغاً)، حُذف النفي وأداة الاستثناء ويُعرب الاسم بعد إلا حسب موقعه في الجملة (فاز المجتهدُ = فاعل).'
    },
    {
      q: 'في جملة: «حضر الطلابُ الندوةَ الثقافيةَ إلا طالباً»، حكم إعراب المستثنى «طالباً» في هذا الاستثناء التام المثبت هو:',
      ans: 'واجب النصب على الاستثناء بالفتحة الظاهرة',
      w1: 'جائز النصب أو الإتباع على البدلية',
      w2: 'مرفوع على أنه بدل من الطلاب',
      w3: 'مجرور بالإضافة',
      topic: 'أسلوب الاستثناء: التام المثبت',
      expl: 'في الاستثناء التام المثبت (المستثنى منه مذكور ولا يوجد نفي)، يجب نصب المستثنى بعد إلا وجوباً.'
    },
    {
      q: 'في جملة: «ما غابَ أحدٌ من المعلمين إلا خالدٌ (أو خالداً)»، يجوز في إعراب كلمة «خالد» وجهان لأن الاستثناء:',
      ans: 'تام منفي؛ فيجوز فيه النصب على الاستثناء أو الإتباع على البدلية من الفاعل (أحد)',
      w1: 'ناقص منفي؛ فيعرب حسب موقعه فقط',
      w2: 'تام مثبت؛ فيجب نصبه فقط',
      w3: 'منقطع؛ فيجب جره بحرف جر مقدر',
      topic: 'أسلوب الاستثناء: التام المنفي وجوازي الإعراب',
      expl: 'إذا كان الكلام تاماً منفياً، جاز في الاسم بعد إلا وجهان: النصب على الاستثناء، أو الإتباع على البدلية من المستثنى منه.'
    },
    {
      q: 'في جملة: «قرأتُ فصولَ الروايةِ خلا فصلاً (أو فصلٍ)»، إعراب المستثنى بعد «خلا / عدا» عند تجردها من «ما» المصدرية:',
      ans: 'يجوز نصبه مفعولاً به (باعتبار خلا فعلاً ماضياً) أو جره (باعتبار خلا حرف جر شبيه بالزائد)',
      w1: 'يجب نصبه مفعولاً به فقط',
      w2: 'يجب جره بالإضافة فقط',
      w3: 'يجب رفعه على الفاعلية',
      topic: 'أدوات الاستثناء: خلا وعدا وحاشا',
      expl: 'إذا تجردت خلا وعدا من ما المصدرية، جاز اعتبارهما أفعالاً ماضية تنصب ما بعدها مفعولاً به، أو حروفا جر تجر ما بعدها.'
    }
  ];

  const tawkeedTemplates = [
    {
      q: 'في جملة: «حضر الوزيرُ نفسُه حفلَ التخرج»، نوع التوكيد وإعراب كلمة «نفسُه» هو:',
      ans: 'توكيد معنوي مرفوع وعلامة رفعه الضمة الظاهرة، والهاء ضمير متصل في محل جر مضاف إليه',
      w1: 'توكيد لفظي مرفوع بالضمة',
      w2: 'بدل مطابق مرفوع بالضمة',
      w3: 'نعت مرفوع وعلامة رفعه الضمة',
      topic: 'التوابع: أسلوب التوكيد المعنوي (نفس وعين)',
      expl: 'ألفاظ التوكيد المعنوي (نفس، عين، كل، جميع، كلا، كلتا) تتبع المؤكد في إعرابه رفعاً ونصباً وجراً وتتصل بضمير يعود عليه.'
    },
    {
      q: 'في قوله تعالى: ﴿كِلْتَا الْجَنَّتَيْنِ آتَتْ أُكُلَهَا﴾، إعراب كلمة «كِلْتَا» في بداية الآية الكريمة هو:',
      ans: 'مبتدأ مرفوع وعلامة رفعه الضمة المقدرة على الألف للتعذر (لأنها أضيفت إلى اسم ظاهر)',
      w1: 'توكيد معنوي مرفوع بالألف لأنه ملحق بالمثنى',
      w2: 'مبتدأ مرفوع بالألف لأنه ملحق بالمثنى',
      w3: 'اسم مجرور وعلامة جره الكسرة المقدرة',
      topic: 'ملحقات المثنى: إعراب كلا وكلتا مع الاسم الظاهر والضمير',
      expl: 'إذا أضيفت كلا وكلتا إلى اسم ظاهر، أعربتا بالحركات المقدرة على الألف كإعراب الاسم المقصور ولا تعدان توكيداً.'
    }
  ];

  const balaghaTemplates = [
    {
      q: 'في قوله تعالى: ﴿وَالصُّبْحِ إِذَا تَنَفَّسَ﴾، المحسن البلاغي أو اللون البياني في الآية هو:',
      ans: 'استعارة مكنية؛ شبه خروج الصباح تدريجياً بكائن يتنفس، وحذف المشبه به ورمز له بشيء من لوازمه (تنفس)',
      w1: 'استعارة تصريحية صريحة',
      w2: 'تشبيه بليغ مقلوب',
      w3: 'مجاز مرسل علاقته السببية',
      topic: 'علم البيان: الاستعارة المكنية',
      expl: 'الاستعارة المكنية هي ما حُذف فيها المشبه به ورُمز له بشيء من صفاته أو لوازمه للدلالة عليه.'
    },
    {
      q: 'في قوله تعالى: ﴿وَيَوْمَ تَقُومُ السَّاعَةُ يُقْسِمُ الْمُجْرِمُونَ مَا لَبِثُوا غَيْرَ سَاعَةٍ﴾، نوع البديع اللفظي بين «السَّاعَةُ» الأولى و«سَاعَةٍ» الثانية:',
      ans: 'جناس تام (اتفق اللفظان في الحروف وعددها وترتيبها وحركاتها واختلفا في المعنى: يوم القيامة ووحدة الوقت)',
      w1: 'جناس ناقص لاختلاف المعنى',
      w2: 'طباق إيجاب بديعي',
      w3: 'مقابلة بلاغية',
      topic: 'علم البديع: المحسنات اللفظية (الجناس التام)',
      expl: 'الجناس التام هو اتفاق الكلمتين في أربعة أمور: نوع الحروف، عددها، ترتيبها، وضبطها، مع اختلافهما التام في المعنى.'
    },
    {
      q: 'في قول الشاعر اليمني عبد الله البردوني: «ماذا أحدثُ عن صنعاءَ يا أبتي؟ / مليحةٌ عاشقاها السلُّ والجربُ»، الاستعارة في «عاشقاها السل والجرب» تفيد:',
      ans: 'استعارة تصريحية ومكنية مركبة تجسد قسوة الفقر والمرض الذي خيّم على المدينة إبان عهود التخلف والظلم',
      w1: 'تشبيه مجمل بسيط خالٍ من المعنى الرمزي',
      w2: 'طباق سلب بين السل والجرب',
      w3: 'سجع غير متوازن',
      topic: 'الأدب اليمني الحديث والبلاغة: شعر عبد الله البردوني',
      expl: 'من روائع البردوني في تصوير بؤس صنعاء في زمن الإمامة وتجسيد المعاناة الإنسانية باستعارات بالغة العمق والجرأة.'
    }
  ];

  const allArabic = [...istithnaTemplates, ...tawkeedTemplates, ...balaghaTemplates];

  for (let i = 0; i < targetCount; i++) {
    const item = allArabic[i % allArabic.length];
    const sig = `arb_${item.topic}_${i}`;
    if (seen.has(sig)) continue;
    seen.add(sig);

    const { shuffled, correctIndex } = shuffleWithSeed([item.ans, item.w1, item.w2, item.w3], i + 881);
    questions.push({
      id: generateUniqueQuestionId('gen_ye_arb'),
      section: 'ministerial',
      stage: 'ثالث ثانوي علمي',
      subject: 'اللغة العربية',
      unitOrTopic: item.topic,
      year: `وزاري نماذج معتمدة ${2021 + (i % 4)}`,
      difficulty: (i % 3 === 0 ? 'easy' : i % 3 === 1 ? 'medium' : 'hard') as DifficultyLevel,
      type: 'mcq',
      question: item.q,
      options: shuffled,
      correctAnswer: correctIndex,
      explanation: item.expl,
      tags: ['لغة عربية', 'نحو وبلاغة', 'المنهج اليمني'],
    });
  }

  return questions;
}

// =========================================================================
// 7. بنك التربية الإسلامية والفرائض والقرآن الكريم
// =========================================================================
export function generateMassiveIslamicQuestions(targetCount: number): BankQuestion[] {
  const questions: BankQuestion[] = [];
  const seen = new Set<string>();

  const tajweedRules = [
    { rule: 'إدغام بغنة', letters: 'ي، ن، م، و (ينمو)', ex: '﴿مَن يَقُولُ﴾ أو ﴿مِن مَّالٍ﴾', opposite: 'الإظهار الحلقي' },
    { rule: 'إدغام بغير غنة', letters: 'ر، ل', ex: '﴿مِن رَّبِّهِمْ﴾ أو ﴿مِن لَّدُنْهُ﴾', opposite: 'الإقلاب' },
    { rule: 'إقلاب', letters: 'حرف الباء (ب) فقط', ex: '﴿مِن بَعْدِ﴾ وتقلب النون إلى ميم مخفاة بغنة', opposite: 'الإخفاء الحقيقي' },
    { rule: 'إظهار حلقي', letters: 'ء، هـ، ع، ح، غ، خ (أخي هاك علماً...)', ex: '﴿مَنْ آمَنَ﴾ أو ﴿مِنْ خَوْفٍ﴾', opposite: 'الإدغام' },
    { rule: 'إخفاء حقيقي', letters: '15 حرفاً مجموعة في أوائل: صف ذا ثنا كم جاد شخص...', ex: '﴿مِن قَبْلُ﴾ أو ﴿أَنفُسَكُمْ﴾', opposite: 'الإظهار' },
  ];

  for (const tr of tajweedRules) {
    if (questions.length >= targetCount) break;
    const { shuffled, correctIndex } = shuffleWithSeed([
      tr.rule,
      'قلقلة صغرى في وسط الكلمة',
      'مد لازم كلمي مثقل مقداره 6 حركات',
      tr.opposite
    ], questions.length + 907);

    questions.push({
      id: generateUniqueQuestionId('gen_ye_tajweed'),
      section: 'ministerial',
      stage: 'ثالث ثانوي علمي',
      subject: 'القرآن والإسلامية',
      unitOrTopic: 'أحكام التلاوة والتجويد: أحكام النون الساكنة والتنوين',
      year: `وزاري نماذج معتمدة ${2022 + (questions.length % 3)}`,
      difficulty: 'medium',
      type: 'mcq',
      question: `في قوله تعالى: ${tr.ex}، ما هو الحكم التجويدي المطبق للنون الساكنة لوقوع حروف (${tr.letters}) بعدها؟`,
      options: shuffled,
      correctAnswer: correctIndex,
      explanation: `الحكم التجويدي الصحيح هو «${tr.rule}» لأن الحروف (${tr.letters}) هي أحرف الـ ${tr.rule}.`,
      tags: ['تجويد', 'قرآن كريم', 'إسلامية وزارية'],
    });
  }

  // المواريث والفرائض
  const mawarithProblems = [
    {
      q: 'توفي رجل وترك: «زوجة، وابناً، وبنتاً». نصيب الزوجة الشرعي من التركة هو:',
      ans: 'الثمن ($1/8$) فرضاً لوجود الفرع الوارث (الابن والبنت)',
      w1: 'الربع ($1/4$)',
      w2: 'النصف ($1/2$)',
      w3: 'السدس ($1/6$)',
      expl: 'ترث الزوجة الثمن (1/8) في حال وجود الفرع الوارث للزوج، وترث الربع (1/4) عند عدم وجود الفرع الوارث.'
    },
    {
      q: 'توفيت امرأة وتركت: «زوجاً، وأماً، وأخاً شقيقاً». نصيب الزوج الشرعي من التركة هو:',
      ans: 'النصف ($1/2$) فرضاً لعدم وجود الفرع الوارث للمتوفاة',
      w1: 'الربع ($1/4$)',
      w2: 'الثمن ($1/8$)',
      w3: 'الثلثان ($2/3$)',
      expl: 'يرث الزوج النصف (1/2) فرضاً عند انعدام الفرع الوارث لزوجته، ويرث الربع (1/4) عند وجوده.'
    },
    {
      q: 'مات شخص وترك: «أماً، وأباً، وابناً». نصيب الأم والأب الشرعي من التركة لكل منهما هو:',
      ans: 'السدس ($1/6$) فرضاً لكل منهما لوجود الفرع الوارث المذكر',
      w1: 'الثلث للأم والسدس للأب',
      w2: 'الربع للأم والباقي تعصيباً للأب',
      w3: 'الثمن للأم والثلث للأب',
      expl: 'يرث كل من الأب والأم السدس (1/6) فرضاً بوجود الفرع الوارث المذكر (الابن) ويأخذ الابن باقي التركة تعصيباً.'
    }
  ];

  for (const mp of mawarithProblems) {
    if (questions.length >= targetCount) break;
    const { shuffled, correctIndex } = shuffleWithSeed([mp.ans, mp.w1, mp.w2, mp.w3], questions.length + 953);
    questions.push({
      id: generateUniqueQuestionId('gen_ye_mawarith'),
      section: 'ministerial',
      stage: 'ثالث ثانوي علمي',
      subject: 'القرآن والإسلامية',
      unitOrTopic: 'فقه المعاملات والفرائض: أحكام المواريث والأنصبة الشرعية',
      year: `وزاري نماذج معتمدة ${2023}`,
      difficulty: 'hard',
      type: 'mcq',
      question: mp.q,
      options: shuffled,
      correctAnswer: correctIndex,
      explanation: mp.expl,
      tags: ['فرائض', 'مواريث', 'إسلامية وزارية'],
    });
  }

  return questions;
}
