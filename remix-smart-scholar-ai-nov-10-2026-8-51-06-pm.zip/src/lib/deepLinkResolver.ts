/**
 * Deep Link Resolver:
 * Scans an HTML DOM tree to discover direct, downloadable binary PDF files.
 * Specifically checks for:
 * 1. a[href$=".pdf"], a[href*=".pdf?"], a[href*=".pdf#"]
 * 2. a[download]
 * 3. a[href*="drive.google.com"]
 * 4. a[href*="mediafire.com"], a[href*="archive.org/download/"]
 * 5. a[href*="download"], a[href*="telecharger"], a[href*="تحميل"], a[href*="تنزيل"]
 * 6. iframe[src*=".pdf"], embed[src*=".pdf"], object[data*=".pdf"]
 */
export function resolvePdfLinkFromHtml(html: string, baseUrl: string): string | null {
  if (!html || typeof html !== 'string') return null;

  try {
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');

    const resolveUrl = (raw: string | null | undefined): string | null => {
      if (!raw || raw.startsWith('javascript:') || raw.startsWith('#') || raw.startsWith('mailto:') || raw.startsWith('tel:')) {
        return null;
      }
      try {
        return new URL(raw, baseUrl).href;
      } catch {
        return null;
      }
    };

    // 1. Direct link ending in .pdf
    const directPdf = doc.querySelector<HTMLAnchorElement>('a[href$=".pdf" i], a[href*=".pdf?" i], a[href*=".pdf#" i]');
    if (directPdf) {
      const resolved = resolveUrl(directPdf.getAttribute('href'));
      if (resolved) return resolved;
    }

    // 2. Google Drive file/open/preview download links
    const gdrive = doc.querySelector<HTMLAnchorElement>(
      'a[href*="drive.google.com/file/d/" i], a[href*="drive.google.com/open?id=" i], a[href*="drive.google.com/uc?" i]'
    );
    if (gdrive) {
      const rawHref = gdrive.getAttribute('href') || '';
      const idMatch = rawHref.match(/(?:file\/d\/|open\?id=|uc\?id=)([a-zA-Z0-9_-]+)/i);
      if (idMatch && idMatch[1]) {
        return `https://drive.google.com/uc?export=download&id=${idMatch[1]}`;
      }
      const resolved = resolveUrl(rawHref);
      if (resolved) return resolved;
    }

    // 3. Anchor tags with explicit download attribute
    const downloadAttr = doc.querySelector<HTMLAnchorElement>('a[download]');
    if (downloadAttr) {
      const resolved = resolveUrl(downloadAttr.getAttribute('href'));
      if (resolved) return resolved;
    }

    // 4. Dedicated Storage Hosts (Mediafire, Archive.org, Top4top)
    const storageHost = doc.querySelector<HTMLAnchorElement>(
      'a[href*="mediafire.com/file/" i], a[href*="mediafire.com/download/" i], a[href*="archive.org/download/" i], a[href*="top4top.io/" i], a[href*="4shared.com/" i]'
    );
    if (storageHost) {
      const resolved = resolveUrl(storageHost.getAttribute('href'));
      if (resolved) return resolved;
    }

    // 5. Embedded PDF viewers (iframe, embed, object)
    const embedded = doc.querySelector<HTMLElement>('iframe[src*=".pdf" i], embed[src*=".pdf" i], object[data*=".pdf" i]');
    if (embedded) {
      const rawSrc = embedded.getAttribute('src') || embedded.getAttribute('data');
      const resolved = resolveUrl(rawSrc);
      if (resolved) return resolved;
    }

    // 6. Anchor containing download in href or text
    const downloadKeywords = doc.querySelector<HTMLAnchorElement>(
      'a[href*="download" i], a[href*="telecharger" i], a[href*="تحميل" i], a[href*="تنزيل" i]'
    );
    if (downloadKeywords) {
      const resolved = resolveUrl(downloadKeywords.getAttribute('href'));
      if (resolved) return resolved;
    }

    // 7. Search all <a> tags for Arabic download text keywords
    const allAnchors = Array.from(doc.querySelectorAll('a'));
    for (const a of allAnchors) {
      const text = a.textContent?.trim() || '';
      if (/(?:تحميل|تنزيل|download|رابط الكتاب|الكتاب كامل|تحميل المنهج|ملف pdf|نسخة pdf|رابط مباشر)/i.test(text)) {
        const resolved = resolveUrl(a.getAttribute('href'));
        if (resolved) return resolved;
      }
    }
  } catch (err) {
    console.warn('resolvePdfLinkFromHtml error:', err);
  }

  return null;
}

export { resolvePdfLinkFromHtml as extractPdfDeepLink };
