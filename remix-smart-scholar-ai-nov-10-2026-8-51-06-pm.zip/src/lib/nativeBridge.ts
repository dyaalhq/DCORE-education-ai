/**
 * Native Android WebView & Mobile Bridge
 * Provides rock-solid support for file downloads, uploads, printing, and permissions
 * inside Android WebViews, mobile browsers, and desktop environments.
 */

declare global {
  interface Window {
    AndroidBridge?: {
      downloadFile?: (base64Data: string, filename: string, mimeType: string) => void;
      printDocument?: (htmlContent: string) => void;
      requestPermission?: (permission: string) => boolean;
      shareContent?: (title: string, text: string, url: string) => void;
    };
    AndroidInterface?: {
      downloadFile?: (base64Data: string, filename: string, mimeType: string) => void;
    };
  }
}

/**
 * Detects whether the current page is running inside an Android WebView or mobile app wrapper
 */
export function isAndroidWebView(): boolean {
  if (typeof window === 'undefined' || typeof navigator === 'undefined') return false;
  const ua = navigator.userAgent || '';
  const isAndroid = /Android/i.test(ua);
  const isWebView = /wv|Version\/[0-9.]+/i.test(ua) || !!window.AndroidBridge || !!window.AndroidInterface;
  return isAndroid && isWebView;
}

/**
 * Detects whether the current device is any mobile device
 */
export function isMobileDevice(): boolean {
  if (typeof window === 'undefined' || typeof navigator === 'undefined') return false;
  return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
}

/**
 * Safe Universal File Downloader
 * Supports Desktop browsers, Mobile browsers, and Native Android WebViews
 */
export async function downloadFileSafely(
  blobOrData: Blob | string,
  filename: string,
  mimeType = 'application/octet-stream'
): Promise<boolean> {
  try {
    let blob: Blob;

    if (typeof blobOrData === 'string') {
      // Check if it's already a data URL
      if (blobOrData.startsWith('data:')) {
        const parts = blobOrData.split(',');
        const mimeMatch = parts[0].match(/:(.*?);/);
        const mime = mimeMatch ? mimeMatch[1] : mimeType;
        const bstr = atob(parts[1]);
        const n = bstr.length;
        const u8arr = new Uint8Array(n);
        for (let i = 0; i < n; i++) {
          u8arr[i] = bstr.charCodeAt(i);
        }
        blob = new Blob([u8arr], { type: mime });
      } else {
        blob = new Blob([blobOrData], { type: mimeType });
      }
    } else {
      blob = blobOrData;
    }

    // 1. Android Bridge Check (if app wrapper exposes native download hook)
    if (window.AndroidBridge?.downloadFile || window.AndroidInterface?.downloadFile) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = (reader.result as string).split(',')[1];
        if (window.AndroidBridge?.downloadFile) {
          window.AndroidBridge.downloadFile(base64, filename, blob.type || mimeType);
        } else if (window.AndroidInterface?.downloadFile) {
          window.AndroidInterface.downloadFile(base64, filename, blob.type || mimeType);
        }
      };
      reader.readAsDataURL(blob);
      return true;
    }

    // 2. Mobile Web Share API fallback (if download is blocked in WebView)
    if (isAndroidWebView() && navigator.canShare && navigator.share) {
      try {
        const file = new File([blob], filename, { type: blob.type || mimeType });
        if (navigator.canShare({ files: [file] })) {
          await navigator.share({
            files: [file],
            title: filename,
          });
          return true;
        }
      } catch (shareErr) {
        console.warn('Navigator share file fallback skipped:', shareErr);
      }
    }

    // 3. Standard HTML5 Anchor Download
    const blobUrl = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = blobUrl;
    link.download = filename;
    link.style.display = 'none';
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    document.body.appendChild(link);
    link.click();

    setTimeout(() => {
      document.body.removeChild(link);
      URL.revokeObjectURL(blobUrl);
    }, 1000);

    return true;
  } catch (error) {
    console.error('downloadFileSafely error:', error);
    // Ultimate fallback: open in new window
    try {
      if (typeof blobOrData === 'string' && blobOrData.startsWith('data:')) {
        window.open(blobOrData, '_blank');
        return true;
      }
    } catch (e) {
      console.error('Data URL fallback error:', e);
    }
    return false;
  }
}

/**
 * Safe Print Handler
 * In Android WebViews, window.print() is often unsupported or silent.
 * This method detects environment and safely renders / prompts print or PDF download.
 */
export async function printOrExportSafely(
  element: HTMLElement,
  filename: string,
  options?: {
    orientation?: 'portrait' | 'landscape';
    format?: string;
  }
): Promise<void> {
  const isWebView = isAndroidWebView();

  if (window.AndroidBridge?.printDocument) {
    window.AndroidBridge.printDocument(element.outerHTML);
    return;
  }

  // If in Android WebView or mobile, generate PDF directly using html2pdf.js and trigger download/share
  if (isWebView || isMobileDevice()) {
    try {
      // @ts-ignore
      const html2pdf = (await import('html2pdf.js')).default;
      const opt = {
        margin: [8, 8, 8, 8] as [number, number, number, number],
        filename: filename.endsWith('.pdf') ? filename : `${filename}.pdf`,
        image: { type: 'jpeg' as const, quality: 0.98 },
        html2canvas: { scale: 2, useCORS: true, logging: false },
        jsPDF: {
          unit: 'mm',
          format: options?.format || 'a4',
          orientation: (options?.orientation || 'portrait') as 'portrait' | 'landscape',
        },
      };

      const pdfBlob = await html2pdf().set(opt).from(element).outputPdf('blob');
      await downloadFileSafely(pdfBlob, opt.filename, 'application/pdf');
      return;
    } catch (err) {
      console.warn('html2pdf print fallback failed, trying window.print:', err);
    }
  }

  // Desktop or standard browser: standard window.print
  window.print();
}

/**
 * Programmatic Permission Check (Microphone, Storage)
 */
export async function checkMediaPermission(name: 'microphone' | 'camera'): Promise<'granted' | 'denied' | 'prompt'> {
  if (typeof navigator === 'undefined' || !navigator.permissions) {
    return 'prompt';
  }
  try {
    const result = await navigator.permissions.query({ name: name as any });
    return result.state;
  } catch (e) {
    return 'prompt';
  }
}
