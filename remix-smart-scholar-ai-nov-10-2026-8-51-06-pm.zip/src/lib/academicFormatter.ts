/**
 * Academic Formatter & PDF Export Engine
 * 
 * - Filters AI conversational filler and chatter
 * - Extracts and structures AI summaries into distinct academic sections:
 *   'Main Concepts', 'Key Takeaways', 'Methodology', 'Formulas & Laws', and 'Exam Tips'
 * - High-DPI Academic PDF export via html2pdf.js / jsPDF
 */

import { ChatMessage } from '../types';
import { preprocessEducationalText } from '../components/EducationalContent';
import { jsPDF } from 'jspdf';

export interface AcademicSummarySchema {
  mainConcepts: string;
  keyTakeaways: string;
  methodology: string;
  detailedAnalysis?: string;
  examTips?: string;
}

/**
 * Standard instructional prompt to guide AI models to strictly produce
 * the canonical 3-pillar academic structure: Main Concepts, Key Takeaways, Methodology.
 */
export const ACADEMIC_SUMMARY_SCHEMA_PROMPT = `يجب أن تتبع الإجابة والملخص بدقة الهيكلية الأكاديمية الصارمة التالية بثلاثة أقسام رئيسية محددة وثابتة:

## 💡 المفاهيم الأساسية (Main Concepts)
- سرد وتوضيح المفاهيم، المصطلحات، والتعريفات التأسيسية للموضوع بدقة علمية.

## 📌 الخلاصات والنقاط الجوهرية (Key Takeaways)
- تبيان النتائج، الخلاصات المستفادة، والنقاط الاستراتيجية التي يجب التركيز عليها للاختبارات والمراجعة.

## 📐 المنهجية والتطبيقات الإجرائية (Methodology)
- توضيح خطوات الحل والعمل النموذجي، القوانين الرياضية، المعادلات الكيميائية، والمعايير الإجرائية المنظمة للموضوع.
`;

export interface StructuredSection {
  id: string;
  title: string;
  englishTitle: string;
  icon: string;
  colorTheme: 'teal' | 'navy' | 'emerald' | 'amber' | 'slate';
  content: string;
  keyPoints: string[];
  hasContent?: boolean;
}

export interface StructuredSummary {
  documentTitle: string;
  notebookName: string;
  subject?: string;
  dateStr: string;
  mainConcepts: StructuredSection;
  keyTakeaways: StructuredSection;
  methodology: StructuredSection;
  detailedAnalysis: StructuredSection;
  examTips: StructuredSection;
  rawFilteredMarkdown: string;
}

/**
 * Filter AI responses of filler, chatty pleasantries, and unnecessary conversational greetings.
 * Ensures the student receives 100% pure, dense, structured academic material.
 */
export function filterAIFiller(rawText: string): string {
  if (!rawText) return '';

  let text = rawText.trim();

  // Common conversational opening lines in Arabic & English
  const leadingFillerPatterns = [
    /^(?:أهلاً(?: وسهلاً)?(?: بك)?(?: عزيزي الطالب| يا بطل| يا صديقي| في منصة المعلم)?[!،,.\s-]*)+/i,
    /^(?:مرحباً(?: بك)?(?: في المعلم الذكي| مجدداً)?[!،,.\s-]*)+/i,
    /^(?:وعليكم السلام ورحمة الله(?: وبركاته)?[!،,.\s-]*)+/i,
    /^(?:حياك الله(?: وبياك)?[!،,.\s-]*)+/i,
    /^(?:عزيزي الطالب[،,.\s-]*)+/i,
    /^(?:طاب يومك[،,.\s-]*)+/i,
    /^(?:بالتأكيد[،,!]?\s*(?:يسعدني|يسرني|يشرفني)\s*(?:مساعدتك|الإجابة|شرح هذا الموضوع|تقديم الشرح)[^.\n]*[.\n]+)/i,
    /^(?:بكل سرور[،,!]?[^.\n]*[.\n]+)/i,
    /^(?:إليك الشرح (?:المفصل|الشامل|الكامل)[^.\n]*[.\n]+)/i,
    /^(?:إليك تفاصيل الإجابة[^.\n]*[.\n]+)/i,
    /^(?:فيما يلي (?:الشرح|التلخيص|الإجابة)[^.\n]*[.\n]+)/i,
    /^(?:سؤالك ممتاز[،,.\s-]*)+/i,
    /^(?:يسرني أن أجيبك[^.\n]*[.\n]+)/i,
    /^(?:بناءً على طلبك[،,!]?[^.\n]*[.\n]+)/i,
    /^(?:يسعدني أن أقدم لك[^.\n]*[.\n]+)/i,
    /^(?:سأقوم بشرح[^.\n]*[.\n]+)/i,
    /^(?:دعنا نستعرض[^.\n]*[.\n]+)/i,
    /^(?:Sure!|Hello!|Hi there!|Certainly!|Of course!)[^.\n]*[.\n]+/i,
    /^(?:Here is the (?:detailed|complete) (?:explanation|summary|breakdown)[^.\n]*[.\n]+)/i,
  ];

  let cleaned = text;
  let matched = true;
  while (matched) {
    matched = false;
    for (const pattern of leadingFillerPatterns) {
      if (pattern.test(cleaned)) {
        cleaned = cleaned.replace(pattern, '').trim();
        matched = true;
      }
    }
  }

  // Common conversational closing lines
  const trailingFillerPatterns = [
    /(?:أتمنى(?: لك)? (?:التوفيق|النجاح|دراسة ممتعة|فهم هذا الدرس|أن يكون الشرح واضحاً)[^.\n]*[.!\s]*)+$/i,
    /(?:إذا كان لديك أي سؤال(?: آخر)?(?: لا تتردد في طرحه)?[.!\s]*)+$/i,
    /(?:لا تتردد في طلب أي توضيح إضافي[.!\s]*)+$/i,
    /(?:بالتوفيق والنجاح الدائم[.!\s]*)+$/i,
    /(?:دمت متفوقاً[.!\s]*)+$/i,
    /(?:والله ولي التوفيق[.!\s]*)+$/i,
    /(?:مع خالص تمنياتي لك بالنجاح[.!\s]*)+$/i,
    /(?:يمكنك دائماً سؤالي عن أي درس آخر[.!\s]*)+$/i,
    /(?:I hope this helps!|Let me know if you have any questions!|Happy studying!)[.!\s]*$/i,
  ];

  matched = true;
  while (matched) {
    matched = false;
    for (const pattern of trailingFillerPatterns) {
      if (pattern.test(cleaned)) {
        cleaned = cleaned.replace(pattern, '').trim();
        matched = true;
      }
    }
  }

  return cleaned;
}

/**
 * Extracts bullet points from a markdown text block, with intelligent fallback
 * to key sentences if bullet markers are not explicitly provided.
 */
function extractBulletPoints(text: string): string[] {
  if (!text) return [];
  const lines = text.split('\n');
  const points: string[] = [];
  for (const line of lines) {
    const trimmed = line.trim();
    if (/^[-*•]\s+/.test(trimmed)) {
      points.push(trimmed.replace(/^[-*•]\s+/, '').replace(/\*\*/g, '').trim());
    } else if (/^\d+[\.\)]\s+/.test(trimmed)) {
      points.push(trimmed.replace(/^\d+[\.\)]\s+/, '').replace(/\*\*/g, '').trim());
    }
  }
  if (points.length === 0) {
    // Fallback: extract distinct meaningful sentences
    const sentences = text
      .split(/[.!\n؟]/)
      .map((s) => s.replace(/\*\*/g, '').replace(/^[#> \t-]+/, '').trim())
      .filter((s) => s.length > 15 && !s.startsWith('#'));
    return sentences.slice(0, 5);
  }
  return points.slice(0, 10);
}

/**
 * Pre-processing utility that forces any AI response or raw educational summary
 * to strictly adhere to the canonical 3-pillar structure:
 * 'Main Concepts, Key Takeaways, Methodology'.
 * 
 * 1. Strips conversational chatter, greetings, and pleasantries.
 * 2. Normalizes LaTeX and KaTeX formulas (math & chemical expressions).
 * 3. Categorizes and restructures the content into:
 *    - Main Concepts (المفاهيم الأساسية)
 *    - Key Takeaways (الخلاصات والنقاط الجوهرية)
 *    - Methodology & Procedures (المنهجية والتطبيقات الإجرائية)
 *    - (Optional) Detailed Analysis & Exam Tips if present.
 * 4. Ensures no mandatory pillar is ever empty.
 * 5. Returns canonical markdown with strict, standardized headers, ensuring
 *    flawless consistency for the PDF generator and interactive study views.
 */
export function preprocessAndEnforceAcademicSchema(
  rawText: string,
  options?: { notebookName?: string; subject?: string }
): string {
  const notebookTitle = options?.notebookName || 'المحتوى الدراسي';
  const subjectName = options?.subject || 'المنهج الدراسي';

  if (!rawText || !rawText.trim()) {
    return '';
  }

  // 1. Strip conversational pleasantries and greetings
  let text = filterAIFiller(rawText).trim();

  // 2. Protect and normalize mathematical & chemical notation (KaTeX formulas)
  text = preprocessEducationalText(text);

  // 3. Segment into sections if markdown headers exist
  const hasHeaders = /^#{1,4}\s+/m.test(text);

  const conceptsList: string[] = [];
  const takeawaysList: string[] = [];
  const methodologyList: string[] = [];
  const analysisList: string[] = [];
  const examTipsList: string[] = [];
  const unassignedList: string[] = [];

  if (hasHeaders) {
    const rawSections = text.split(/(?=^#{1,4}\s+)/m);
    for (const sec of rawSections) {
      const trimmed = sec.trim();
      if (!trimmed) continue;

      const headerMatch = trimmed.match(/^#{1,4}\s+(.*)/);
      const headerTitle = (headerMatch ? headerMatch[1] : '').toLowerCase();
      // Remove the top header line from the section body
      const body = trimmed.replace(/^#{1,4}\s+.*(\r?\n)+/, '').trim();
      const content = body || trimmed;

      if (
        headerTitle.includes('مفهوم') ||
        headerTitle.includes('المفاهيم') ||
        headerTitle.includes('تعريف') ||
        headerTitle.includes('التعاريف') ||
        headerTitle.includes('مصطلح') ||
        headerTitle.includes('أسس') ||
        headerTitle.includes('أهداف') ||
        headerTitle.includes('concept') ||
        headerTitle.includes('foundation')
      ) {
        conceptsList.push(content);
      } else if (
        headerTitle.includes('خلاص') ||
        headerTitle.includes('نتائج') ||
        headerTitle.includes('نقاط جوهرية') ||
        headerTitle.includes('مستفاد') ||
        headerTitle.includes('أهم النقاط') ||
        headerTitle.includes('takeaway') ||
        headerTitle.includes('conclusion') ||
        headerTitle.includes('key point')
      ) {
        takeawaysList.push(content);
      } else if (
        headerTitle.includes('منهج') ||
        headerTitle.includes('خطو') ||
        headerTitle.includes('إجراء') ||
        headerTitle.includes('تطبيق') ||
        headerTitle.includes('طريق') ||
        headerTitle.includes('حل') ||
        headerTitle.includes('قانون') ||
        headerTitle.includes('معادل') ||
        headerTitle.includes('method') ||
        headerTitle.includes('procedure') ||
        headerTitle.includes('formula') ||
        headerTitle.includes('step')
      ) {
        methodologyList.push(content);
      } else if (
        headerTitle.includes('تحليل') ||
        headerTitle.includes('تفصيل') ||
        headerTitle.includes('analysis')
      ) {
        analysisList.push(content);
      } else if (
        headerTitle.includes('امتحان') ||
        headerTitle.includes('اختبار') ||
        headerTitle.includes('تنبيه') ||
        headerTitle.includes('أخطاء') ||
        headerTitle.includes('exam') ||
        headerTitle.includes('pitfall') ||
        headerTitle.includes('warning')
      ) {
        examTipsList.push(content);
      } else {
        unassignedList.push(content);
      }
    }
  } else {
    // Unstructured text: evaluate paragraphs and bullet blocks
    const paragraphs = text.split(/\n{2,}/).map((p) => p.trim()).filter(Boolean);
    for (const para of paragraphs) {
      const lower = para.toLowerCase();
      const isMethodOrMath =
        /\$\$|\\ce\{|\b(v|F|m|a|E|c|pH|mol|k|Kc|Ka)\s*=|^\s*\d+[\.\)]/i.test(para) ||
        lower.includes('خطوة') ||
        lower.includes('طريقة') ||
        lower.includes('معادلة') ||
        lower.includes('قانون') ||
        lower.includes('نحسب') ||
        lower.includes('إجراء');

      const isConcept =
        lower.includes('هو ') ||
        lower.includes('هي ') ||
        lower.includes('يعرف ') ||
        lower.includes('تعرف ') ||
        lower.includes('المقصود') ||
        lower.includes('مفهوم') ||
        /^\s*[-*•]?\s*\*\*[^*]+\*\*:\s*/.test(para);

      const isTakeaway =
        lower.includes('نستنتج') ||
        lower.includes('خلاصة') ||
        lower.includes('النتيجة') ||
        lower.includes('أهمية') ||
        lower.includes('يجب مراعاة');

      if (isConcept) {
        conceptsList.push(para);
      } else if (isMethodOrMath) {
        methodologyList.push(para);
      } else if (isTakeaway) {
        takeawaysList.push(para);
      } else {
        unassignedList.push(para);
      }
    }
  }

  // Distribute unassigned content to maintain academic balance
  for (const block of unassignedList) {
    if (conceptsList.length === 0) {
      conceptsList.push(block);
    } else if (takeawaysList.length === 0) {
      takeawaysList.push(block);
    } else if (methodologyList.length === 0) {
      methodologyList.push(block);
    } else {
      const cLen = conceptsList.join('').length;
      const tLen = takeawaysList.join('').length;
      const mLen = methodologyList.join('').length;
      if (cLen <= tLen && cLen <= mLen) {
        conceptsList.push(block);
      } else if (tLen <= mLen) {
        takeawaysList.push(block);
      } else {
        methodologyList.push(block);
      }
    }
  }

  // Extract genuine sentences from the real text if any list is empty
  const extractTextSentences = (startIdx: number, count: number) => {
    return text
      .split(/[.!\n؟]/)
      .map((s) => s.replace(/\*\*/g, '').replace(/^[#> \t-]+/, '').trim())
      .filter((s) => s.length > 20 && !s.startsWith('#'))
      .slice(startIdx, startIdx + count)
      .map((s) => `- ${s}`)
      .join('\n');
  };

  if (conceptsList.length === 0) {
    const s = extractTextSentences(0, 3);
    if (s) conceptsList.push(s);
  }

  if (takeawaysList.length === 0) {
    const s = extractTextSentences(3, 3);
    if (s) takeawaysList.push(s);
  }

  if (methodologyList.length === 0) {
    const stepLines = text.split('\n').filter((l) => /^\s*(?:\d+[\.\)]|[-*•])\s+/.test(l));
    if (stepLines.length > 0) {
      methodologyList.push(stepLines.slice(0, 4).join('\n'));
    }
  }

  // Format section content cleanly
  const formatSection = (items: string[]) => {
    return items
      .join('\n\n')
      .replace(/^#{1,4}\s+.*$/gm, '') // Remove internal nested headers for clean flow
      .replace(/^[•*]\s+/gm, '- ')
      .trim();
  };

  const conceptsBody = formatSection(conceptsList);
  const takeawaysBody = formatSection(takeawaysList);
  const methodologyBody = formatSection(methodologyList);

  // Assemble strictly canonical schema markdown
  let result = [
    `## 💡 المفاهيم الأساسية (Main Concepts)\n\n${conceptsBody}`,
    `## 📌 الخلاصات والنقاط الجوهرية (Key Takeaways)\n\n${takeawaysBody}`,
    `## 📐 المنهجية والتطبيقات الإجرائية (Methodology)\n\n${methodologyBody}`,
  ].join('\n\n');

  if (analysisList.length > 0) {
    result += `\n\n## ⚖️ التحليل الأكاديمي والقوانين (Detailed Analysis)\n\n${formatSection(analysisList)}`;
  }
  if (examTipsList.length > 0) {
    result += `\n\n## ⚠️ تنبيهات المذاكرة والاختبارات (Exam Tips)\n\n${formatSection(examTipsList)}`;
  }

  return result;
}

// Export canonical alias
export const enforceAcademicSummarySchema = preprocessAndEnforceAcademicSchema;

/**
 * Parses an enforced schema markdown into a structured object containing
 * the 3 mandatory pillars (mainConcepts, keyTakeaways, methodology) and optional extras.
 */
export function parseEnforcedSchema(text: string): AcademicSummarySchema {
  const sections = text.split(/(?=^##\s+)/m);
  let mainConcepts = '';
  let keyTakeaways = '';
  let methodology = '';
  let detailedAnalysis = '';
  let examTips = '';

  for (const sec of sections) {
    const trimmed = sec.trim();
    if (!trimmed) continue;
    const lower = trimmed.toLowerCase();
    const body = trimmed.replace(/^##\s+.*(\r?\n)+/, '').trim();

    if (lower.includes('المفاهيم') || lower.includes('main concepts')) {
      mainConcepts = body;
    } else if (lower.includes('الخلاصات') || lower.includes('key takeaways')) {
      keyTakeaways = body;
    } else if (lower.includes('المنهجية') || lower.includes('methodology')) {
      methodology = body;
    } else if (lower.includes('التحليل') || lower.includes('detailed analysis')) {
      detailedAnalysis = body;
    } else if (lower.includes('تنبيهات') || lower.includes('exam tips')) {
      examTips = body;
    }
  }

  return {
    mainConcepts,
    keyTakeaways,
    methodology,
    detailedAnalysis: detailedAnalysis || undefined,
    examTips: examTips || undefined,
  };
}

/**
 * Structure raw AI summary output into the schema with:
 * - Main Concepts (المفاهيم الرئيسية)
 * - Key Takeaways (الخلاصات والنقاط الجوهرية)
 * - Methodology & Procedures (المنهجية والخطوات التطبيقية)
 * - Detailed Analysis & Formulas (القوانين والمعادلات والتحليل)
 * - Exam Tips & Pitfalls (تنبيهات الامتحانات والأخطاء الشائعة)
 * 
 * Uses preprocessAndEnforceAcademicSchema to guarantee that every document strictly
 * contains 'Main Concepts, Key Takeaways, Methodology' before emitting to the PDF generator.
 */
export function extractStructuredSummary(
  rawText: string,
  notebookName: string = 'الدفتر الدراسي',
  subject: string = 'المنهج الدراسي'
): StructuredSummary {
  // 1. Pre-process and force the strict schema first!
  const enforcedMarkdown = preprocessAndEnforceAcademicSchema(rawText, {
    notebookName,
    subject,
  });

  // 2. Parse the guaranteed canonical sections
  const parsed = parseEnforcedSchema(enforcedMarkdown);

  const conceptsContent = parsed.mainConcepts || '';
  const takeawaysContent = parsed.keyTakeaways || '';
  const methodologyContent = parsed.methodology || '';
  const analysisContent = parsed.detailedAnalysis?.trim() || '';
  const examTipsContent = parsed.examTips?.trim() || '';

  const currentDate = new Date().toLocaleDateString('ar-EG', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  return {
    documentTitle: `ملخص دراسي منظم: ${notebookName}`,
    notebookName,
    subject,
    dateStr: currentDate,
    mainConcepts: {
      id: 'concepts',
      title: 'المفاهيم والتعاريف المحورية',
      englishTitle: 'Main Concepts & Theoretical Foundations',
      icon: '💡',
      colorTheme: 'teal',
      content: conceptsContent,
      keyPoints: extractBulletPoints(conceptsContent),
      hasContent: conceptsContent.trim().length > 0,
    },
    keyTakeaways: {
      id: 'takeaways',
      title: 'الخلاصات والنقاط الجوهرية',
      englishTitle: 'Key Takeaways & Core Findings',
      icon: '📌',
      colorTheme: 'navy',
      content: takeawaysContent,
      keyPoints: extractBulletPoints(takeawaysContent),
      hasContent: takeawaysContent.trim().length > 0,
    },
    methodology: {
      id: 'methodology',
      title: 'المنهجية والخطوات التطبيقية',
      englishTitle: 'Methodology & Procedural Steps',
      icon: '📐',
      colorTheme: 'emerald',
      content: methodologyContent,
      keyPoints: extractBulletPoints(methodologyContent),
      hasContent: methodologyContent.trim().length > 0,
    },
    detailedAnalysis: {
      id: 'analysis',
      title: 'القوانين والمعادلات والتحليل المفصل',
      englishTitle: 'Detailed Analysis, Formulas & Laws',
      icon: '⚖️',
      colorTheme: 'teal',
      content: analysisContent,
      keyPoints: extractBulletPoints(analysisContent),
      hasContent: analysisContent.trim().length > 0,
    },
    examTips: {
      id: 'exam_tips',
      title: 'تنبيهات الامتحانات وملاحظات التركيز',
      englishTitle: 'Exam Alerts & Strategic Focus',
      icon: '⚠️',
      colorTheme: 'amber',
      content: examTipsContent,
      keyPoints: extractBulletPoints(examTipsContent),
      hasContent: examTipsContent.trim().length > 0,
    },
    rawFilteredMarkdown: enforcedMarkdown,
  };
}

/**
 * Intelligent Academic Summarizer (calls AI backend to deeply synthesize real lesson text into genuine PDF schema)
 */
export async function generateIntelligentAcademicSummary(
  rawText: string,
  notebookName: string = 'الدفتر الدراسي',
  subject: string = 'المنهج الدراسي'
): Promise<StructuredSummary> {
  const currentDate = new Date().toLocaleDateString('ar-EG', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  try {
    const res = await fetch('/api/summarize-academic', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        text: rawText,
        title: notebookName,
        subject,
      }),
    });

    if (res.ok) {
      const data = await res.json();
      if (data.summary) {
        const s = data.summary;
        const mainConceptsText = s.mainConcepts || '';
        const keyTakeawaysText = s.keyTakeaways || '';
        const methodologyText = s.methodology || '';
        const analysisText = s.detailedAnalysis && s.detailedAnalysis !== 'null' ? s.detailedAnalysis : '';
        const examTipsText = s.examTips && s.examTips !== 'null' ? s.examTips : '';

        return {
          documentTitle: s.documentTitle || `تقرير دراسي: ${notebookName}`,
          notebookName,
          subject,
          dateStr: currentDate,
          mainConcepts: {
            id: 'concepts',
            title: 'المفاهيم والتعاريف المحورية',
            englishTitle: 'Main Concepts & Foundations',
            icon: '💡',
            colorTheme: 'teal',
            content: mainConceptsText,
            keyPoints: extractBulletPoints(mainConceptsText),
            hasContent: mainConceptsText.trim().length > 0,
          },
          keyTakeaways: {
            id: 'takeaways',
            title: 'الخلاصات والنقاط الجوهرية',
            englishTitle: 'Key Takeaways & Core Findings',
            icon: '📌',
            colorTheme: 'navy',
            content: keyTakeawaysText,
            keyPoints: extractBulletPoints(keyTakeawaysText),
            hasContent: keyTakeawaysText.trim().length > 0,
          },
          methodology: {
            id: 'methodology',
            title: 'المنهجية والخطوات التطبيقية',
            englishTitle: 'Methodology & Procedural Steps',
            icon: '📐',
            colorTheme: 'emerald',
            content: methodologyText,
            keyPoints: extractBulletPoints(methodologyText),
            hasContent: methodologyText.trim().length > 0,
          },
          detailedAnalysis: {
            id: 'analysis',
            title: 'القوانين والمعادلات والتحليل المفصل',
            englishTitle: 'Detailed Analysis, Formulas & Laws',
            icon: '⚖️',
            colorTheme: 'teal',
            content: analysisText,
            keyPoints: extractBulletPoints(analysisText),
            hasContent: analysisText.trim().length > 0,
          },
          examTips: {
            id: 'exam_tips',
            title: 'تنبيهات الامتحانات وملاحظات التركيز الوزارية',
            englishTitle: 'Exam Alerts & Strategic Focus',
            icon: '⚠️',
            colorTheme: 'amber',
            content: examTipsText,
            keyPoints: extractBulletPoints(examTipsText),
            hasContent: examTipsText.trim().length > 0,
          },
          rawFilteredMarkdown: [
            mainConceptsText ? `## 💡 المفاهيم الأساسية\n\n${mainConceptsText}` : '',
            keyTakeawaysText ? `## 📌 الخلاصات والنقاط الجوهرية\n\n${keyTakeawaysText}` : '',
            methodologyText ? `## 📐 المنهجية والتطبيقات\n\n${methodologyText}` : '',
            analysisText ? `## ⚖️ القوانين والتحليل المفصل\n\n${analysisText}` : '',
            examTipsText ? `## ⚠️ تنبيهات الامتحانات وملاحظات التركيز\n\n${examTipsText}` : '',
          ].filter(Boolean).join('\n\n'),
        };
      }
    }
  } catch (err) {
    console.warn('Backend academic summarizer call failed, using local extraction:', err);
  }

  // Fallback to local clean extractor
  return extractStructuredSummary(rawText, notebookName, subject);
}

/**
 * Intelligent Conversation Summarizer: synthesizes the entire conversation into a verified academic report
 */
export async function generateIntelligentConversationSummary(
  messages: ChatMessage[],
  sessionTitle: string = 'جلسة مذاكرة وتدريس تفاعلية',
  notebookName: string = 'دفتر المذاكرة الذكي',
  subject: string = 'مراجعة المنهج الأكاديمي'
): Promise<StructuredSummary> {
  const validMessages = messages.filter((m) => m.text && m.text.trim().length > 0);
  if (validMessages.length === 0) {
    return conversationHistoryToStructuredSummary(messages, sessionTitle, notebookName, subject);
  }

  // Compile full conversation into a clean textual digest
  const textBlocks: string[] = [];
  for (const m of validMessages) {
    if (m.role === 'user') {
      textBlocks.push(`سؤال الطالب: ${m.text}`);
    } else {
      textBlocks.push(`شرح المعلم الذكي: ${filterAIFiller(m.text)}`);
    }
  }
  const fullText = textBlocks.join('\n\n');

  return generateIntelligentAcademicSummary(fullText, sessionTitle, subject);
}

/**
 * World-Class Academic PDF Export using html2pdf.js / jsPDF
 * Applies A4 dimensions, high-resolution rendering (scale 2), proper margins,
 * and handles page breaks cleanly.
 */
export async function exportToAcademicPdf(
  elementOrId: HTMLElement | string,
  filename: string = 'ملخص_دراسي_أكاديمي.pdf'
): Promise<void> {
  const targetElement =
    typeof elementOrId === 'string'
      ? document.getElementById(elementOrId)
      : elementOrId;

  if (!targetElement) {
    console.error('Target element for PDF export not found:', elementOrId);
    window.print();
    return;
  }

  try {
    // Dynamic import to support SSR and Vite bundling
    const html2pdfModule = await import('html2pdf.js');
    const html2pdf = (html2pdfModule as any).default || html2pdfModule;

    const opt = {
      margin: [12, 12, 12, 12], // mm: top, left, bottom, right
      filename: filename.endsWith('.pdf') ? filename : `${filename}.pdf`,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: {
        scale: 2,
        useCORS: true,
        letterRendering: true,
        logging: false,
        backgroundColor: '#ffffff',
        scrollY: 0,
        windowWidth: 1024,
      },
      jsPDF: {
        unit: 'mm',
        format: 'a4',
        orientation: 'portrait',
      },
      pagebreak: {
        mode: ['avoid-all', 'css', 'legacy'],
        before: '.page-break-before',
        after: '.page-break-after',
        avoid: [
          '.academic-section',
          'blockquote',
          'table',
          'tr',
          '.katex-display',
          '.avoid-break',
        ],
      },
    };

    await html2pdf().set(opt).from(targetElement).save();
  } catch (err) {
    console.warn('html2pdf export failed, falling back to window.print():', err);
    window.print();
  }
}

/**
 * High-DPI Note PDF Export using jsPDF engine
 * Formats a student note card with embedded images, styled markdown,
 * metadata header, and A4 print dimensions into a downloadable PDF.
 */
export async function exportNoteToPdf(
  elementOrId: HTMLElement | string,
  filename: string = 'ملاحظة_دراسية.pdf'
): Promise<void> {
  const targetElement =
    typeof elementOrId === 'string'
      ? document.getElementById(elementOrId)
      : elementOrId;

  if (!targetElement) {
    console.error('Target element for Note PDF export not found:', elementOrId);
    window.print();
    return;
  }

  try {
    const html2pdfModule = await import('html2pdf.js');
    const html2pdf = (html2pdfModule as any).default || html2pdfModule;

    const opt = {
      margin: [10, 10, 10, 10], // mm: top, left, bottom, right
      filename: filename.endsWith('.pdf') ? filename : `${filename}.pdf`,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: {
        scale: 2,
        useCORS: true,
        letterRendering: true,
        logging: false,
        backgroundColor: '#ffffff',
      },
      jsPDF: {
        unit: 'mm',
        format: 'a4',
        orientation: 'portrait',
      },
      pagebreak: {
        mode: ['avoid-all', 'css', 'legacy'],
        before: '.page-break-before',
        after: '.page-break-after',
        avoid: [
          'blockquote',
          'table',
          'tr',
          '.katex-display',
          'figure',
          'img',
          '.avoid-break',
        ],
      },
    };

    await html2pdf().set(opt).from(targetElement).save();
  } catch (err) {
    console.warn('html2pdf failed for note, attempting fallback with direct jsPDF:', err);
    try {
      const doc = new jsPDF({
        unit: 'mm',
        format: 'a4',
        orientation: 'portrait',
      });
      // Direct html render fallback
      if (typeof (doc as any).html === 'function') {
        await (doc as any).html(targetElement, {
          callback: (pdfDoc: any) => {
            pdfDoc.save(filename.endsWith('.pdf') ? filename : `${filename}.pdf`);
          },
          x: 10,
          y: 10,
          width: 190,
          windowWidth: 794,
        });
      } else {
        window.print();
      }
    } catch {
      window.print();
    }
  }
}

/**
 * High-DPI Conversation Thread PDF Export using html2pdf / jsPDF engine
 * Formats full chat conversation history with user inquiries, AI academic responses,
 * citations, LaTeX equations, metadata header, and A4 print dimensions into a downloadable PDF report.
 */
export async function exportConversationThreadToPdf(
  session: { title: string; messages: Array<{ id: string; role: 'user' | 'ai'; text: string; date?: number; citations?: any[]; providerInfo?: any }> },
  notebookTitle: string = 'الدفتر الدراسي',
  notebookSubject: string = 'المنهج الدراسي',
  filename?: string
): Promise<void> {
  if (!session || !session.messages || session.messages.length === 0) {
    throw new Error('لا توجد رسائل في جلسة المحادثة لتصديرها.');
  }

  const currentDate = new Date().toLocaleDateString('ar-EG', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });

  const exportContainer = document.createElement('div');
  exportContainer.id = `conv-export-${Date.now()}`;
  exportContainer.style.position = 'fixed';
  exportContainer.style.left = '-9999px';
  exportContainer.style.top = '0';
  exportContainer.style.width = '800px';
  exportContainer.style.background = '#ffffff';
  exportContainer.style.color = '#17201e';
  exportContainer.style.fontFamily = 'system-ui, -apple-system, "Segoe UI", Roboto, "Noto Sans Arabic", Tahoma, sans-serif';
  exportContainer.style.direction = 'rtl';
  exportContainer.style.padding = '24px';
  exportContainer.style.zIndex = '-1000';

  // Build HTML representation
  const messagesHtml = session.messages.map((msg, index) => {
    const isUser = msg.role === 'user';
    const cleanText = isUser ? msg.text : filterAIFiller(msg.text);
    const timeStr = msg.date ? new Date(msg.date).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }) : '';
    
    // Format text paragraphs and bolding
    const formattedParagraphs = cleanText
      .split('\n\n')
      .map(p => {
        let text = p.trim();
        if (!text) return '';
        if (text.startsWith('# ')) return `<h1 style="font-size: 16px; font-weight: bold; margin: 10px 0 6px 0; color: #0f766e;">${text.slice(2)}</h1>`;
        if (text.startsWith('## ')) return `<h2 style="font-size: 14px; font-weight: bold; margin: 8px 0 4px 0; color: #115e59;">${text.slice(3)}</h2>`;
        if (text.startsWith('### ')) return `<h3 style="font-size: 13px; font-weight: bold; margin: 6px 0 4px 0; color: #134e4a;">${text.slice(4)}</h3>`;
        if (text.startsWith('- ') || text.startsWith('* ')) {
          const items = text.split('\n').map(item => `<li style="margin-bottom: 3px;">${item.replace(/^[-*]\s*/, '')}</li>`).join('');
          return `<ul style="margin: 6px 0 6px 18px; padding-right: 12px; font-size: 11.5px; line-height: 1.6;">${items}</ul>`;
        }
        return `<p style="margin-bottom: 6px; font-size: 11.5px; line-height: 1.6; color: #1f2937;">${text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')}</p>`;
      })
      .filter(Boolean)
      .join('');

    const citationsHtml = (!isUser && msg.citations && msg.citations.length > 0)
      ? `<div style="margin-top: 8px; padding-top: 6px; border-top: 1px dashed #cbd5e1; font-size: 10px; color: #64748b;">
          <strong style="color: #0f766e;">المراجع والشواهد (${msg.citations.length}):</strong>
          <div style="display: flex; flex-wrap: wrap; gap: 4px; margin-top: 4px;">
            ${msg.citations.map((c: any) => `
              <span style="background: #f1f5f9; padding: 2px 6px; border-radius: 4px; border: 1px solid #e2e8f0;">
                📖 ${c.sourceTitle || 'مرجع'} ${c.pageNumber ? `(ص: ${c.pageNumber})` : ''}
              </span>
            `).join('')}
          </div>
        </div>`
      : '';

    return `
      <div class="avoid-break" style="margin-bottom: 16px; border-radius: 12px; border: 1px solid ${isUser ? '#93c5fd' : '#99f6e4'}; background: ${isUser ? '#f0f9ff' : '#f0fdfa'}; padding: 12px 14px; page-break-inside: avoid;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px; padding-bottom: 4px; border-bottom: 1px solid ${isUser ? '#e0f2fe' : '#ccfbf1'};">
          <div style="display: flex; align-items: center; gap: 6px; font-weight: bold; font-size: 12px; color: ${isUser ? '#0369a1' : '#0f766e'};">
            <span>${isUser ? '👤 سؤال الطالب' : '🤖 شرح وتحليل المعلم الذكي'}</span>
            <span style="font-size: 10px; background: ${isUser ? '#bae6fd' : '#a7f3d0'}; color: ${isUser ? '#0369a1' : '#065f46'}; padding: 1px 5px; border-radius: 10px;">
              #${index + 1}
            </span>
          </div>
          ${timeStr ? `<span style="font-size: 10px; color: #94a3b8;">${timeStr}</span>` : ''}
        </div>
        <div style="padding: 2px 0;">
          ${formattedParagraphs}
        </div>
        ${citationsHtml}
      </div>
    `;
  }).join('');

  exportContainer.innerHTML = `
    <div style="border-bottom: 2px solid #0f766e; padding-bottom: 12px; margin-bottom: 18px;">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
        <div style="font-size: 11px; font-weight: bold; color: #0f766e; background: #ccfbf1; padding: 3px 8px; border-radius: 6px;">
          ✦ المعلم الذكي | تقرير محادثة أكاديمية معتمد
        </div>
        <div style="font-size: 10px; color: #64748b;">
          تاريخ التصدير: ${currentDate}
        </div>
      </div>
      
      <h1 style="font-size: 20px; font-weight: 800; color: #0f766e; margin: 0 0 6px 0;">
        ${session.title || 'سجل جلسة المذاكرة والاستفسار'}
      </h1>

      <div style="display: flex; flex-wrap: wrap; gap: 8px; font-size: 11px; color: #475569; margin-top: 6px;">
        <span style="background: #f8fafc; border: 1px solid #e2e8f0; padding: 2px 8px; border-radius: 4px;">
          📚 <strong>الدفتر:</strong> ${notebookTitle}
        </span>
        <span style="background: #f8fafc; border: 1px solid #e2e8f0; padding: 2px 8px; border-radius: 4px;">
          🎯 <strong>المادة:</strong> ${notebookSubject}
        </span>
        <span style="background: #f8fafc; border: 1px solid #e2e8f0; padding: 2px 8px; border-radius: 4px;">
          💬 <strong>عدد الرسائل:</strong> ${session.messages.length} رسالة
        </span>
      </div>
    </div>

    <div>
      ${messagesHtml}
    </div>

    <div style="margin-top: 24px; padding-top: 10px; border-top: 1px solid #cbd5e1; font-size: 10px; color: #94a3b8; text-align: center;">
      تم استخراج وتنسيق هذا التقرير تلقائياً عبر منصة المعلم الذكي للدراسة بالذكاء الاصطناعي و NotebookLM.
    </div>
  `;

  document.body.appendChild(exportContainer);

  const safeFilename = filename || `محادثة_${(session.title || 'تقرير_دراسي').replace(/[^\w\u0600-\u06FF]/g, '_').slice(0, 30)}_${Date.now()}.pdf`;

  try {
    const html2pdfModule = await import('html2pdf.js');
    const html2pdf = (html2pdfModule as any).default || html2pdfModule;

    const opt = {
      margin: [10, 10, 10, 10],
      filename: safeFilename.endsWith('.pdf') ? safeFilename : `${safeFilename}.pdf`,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: {
        scale: 2,
        useCORS: true,
        letterRendering: true,
        logging: false,
        backgroundColor: '#ffffff',
        windowWidth: 800,
      },
      jsPDF: {
        unit: 'mm',
        format: 'a4',
        orientation: 'portrait',
      },
      pagebreak: {
        mode: ['avoid-all', 'css', 'legacy'],
        avoid: ['.avoid-break', 'blockquote', 'table'],
      },
    };

    await html2pdf().set(opt).from(exportContainer).save();
  } catch (err) {
    console.warn('html2pdf thread export fallback to jsPDF direct:', err);
    try {
      const doc = new jsPDF({
        unit: 'mm',
        format: 'a4',
        orientation: 'portrait',
      });
      if (typeof (doc as any).html === 'function') {
        await (doc as any).html(exportContainer, {
          callback: (pdfDoc: any) => {
            pdfDoc.save(safeFilename.endsWith('.pdf') ? safeFilename : `${safeFilename}.pdf`);
          },
          x: 10,
          y: 10,
          width: 190,
          windowWidth: 800,
        });
      } else {
        window.print();
      }
    } catch {
      window.print();
    }
  } finally {
    if (document.body.contains(exportContainer)) {
      document.body.removeChild(exportContainer);
    }
  }
}

/**
 * Transforms a Mind Map hierarchy into a full academic structured summary
 * ready for document preview, direct printing, or high-DPI A4 PDF export
 * formatted as an organized academic study guide.
 */
export function mindMapToStructuredSummary(
  rootNode: {
    title: string;
    notes?: string;
    badge?: string;
    children?: Array<{
      title: string;
      notes?: string;
      formula?: string;
      badge?: string;
      children?: Array<{
        title: string;
        notes?: string;
        formula?: string;
        badge?: string;
      }>;
    }>;
  },
  notebookName: string = 'الدفتر الدراسي',
  subject: string = 'دليل دراسي أكاديمي - شجرة المفاهيم'
): StructuredSummary {
  const currentDate = new Date().toLocaleDateString('ar-EG', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  const branches = rootNode.children || [];

  // Generate ASCII / Unicode Visual Tree Representation for the study guide
  let treeAscii = `📦 [الموضوع المحوري]: ${rootNode.title}\n`;
  branches.forEach((b, i) => {
    const isLastBranch = i === branches.length - 1;
    const branchPrefix = isLastBranch ? '└── ' : '├── ';
    const childIndent = isLastBranch ? '    ' : '│   ';
    treeAscii += `${branchPrefix}💡 [${b.badge || 'مفهوم رئيسي'}] ${b.title}\n`;
    const leaves = b.children || [];
    leaves.forEach((l, j) => {
      const isLastLeaf = j === leaves.length - 1;
      const leafPrefix = isLastLeaf ? '└── ' : '├── ';
      treeAscii += `${childIndent}${leafPrefix}🔹 [${l.badge || 'عنصر فرعي'}] ${l.title}${l.formula ? ` (صيغة: $${l.formula}$)` : ''}\n`;
    });
  });

  // 1. Main Concepts: Root & Major Branches with Visual Tree Representation
  let conceptsContent = `### 💡 المفاهيم الأساسية وهيكل الشجرة البصرية (Main Concepts)\n\n`;
  conceptsContent += `> **الموضوع العام المحوري**: **${rootNode.title}**\n\n`;
  if (rootNode.notes) {
    conceptsContent += `> *أهداف وملاحظات الموضوع*: ${rootNode.notes}\n\n`;
  }

  conceptsContent += `#### 🌳 المخطط الهيكلي للشجرة البصرية (Visual Concept Tree Hierarchy):\n`;
  conceptsContent += `\`\`\`text\n${treeAscii}\`\`\`\n\n`;

  conceptsContent += `#### تفصيل المفاهيم الأساسية والمحاور المستخلصة:\n`;
  branches.forEach((b, idx) => {
    conceptsContent += `##### ${idx + 1}. ${b.title} ${b.badge ? `\`[${b.badge}]\`` : ''}\n`;
    if (b.notes) {
      conceptsContent += `- **الشرح والتفصيل**: ${b.notes}\n`;
    }
    if (b.formula) {
      conceptsContent += `- **القانون / الصيغة الرياضية**: $$${b.formula}$$\n`;
    }
    const leaves = b.children || [];
    if (leaves.length > 0) {
      conceptsContent += `- **الفروع والمحددات الإجرائية**:\n`;
      leaves.forEach((l) => {
        conceptsContent += `  - **${l.title}** ${l.badge ? `(${l.badge})` : ''}: ${l.notes || 'عنصر فرعي مكمل للمفهوم الأساسي.'}${l.formula ? ` — *معادلة*: $${l.formula}$` : ''}\n`;
      });
    }
    conceptsContent += `\n`;
  });

  // 2. Key Takeaways
  let takeawaysContent = `### 📌 الخلاصات والنقاط الذهبية المستفادة (Key Takeaways)\n\n`;
  branches.forEach((b) => {
    takeawaysContent += `#### 🔹 محور: ${b.title}\n`;
    const leaves = b.children || [];
    if (leaves.length > 0) {
      leaves.forEach((l) => {
        takeawaysContent += `- **${l.title}**: ${l.notes || 'ركيزة جوهرية للاستذكار وحل المسائل.'}\n`;
      });
    } else {
      takeawaysContent += `- ${b.notes || 'ركيزة أساسية للدراسة والاستذكار.'}\n`;
    }
    takeawaysContent += `\n`;
  });

  // 3. Methodology & Applied Procedures (Hierarchy Index Table)
  let methodologyContent = `### 📐 المنهجية ومصفوفة التفرع الهرمي (Methodology & Hierarchy Index)\n\n`;
  methodologyContent += `| المستوى الهرمي | اسم المفهوم / العنصر | التصنيف الأكاديمي | الدور المنهجي والتطبيقي |\n`;
  methodologyContent += `| :--- | :--- | :---: | :--- |\n`;
  methodologyContent += `| **الجذر الأساسي** | ${rootNode.title} | الفكرة العامة | الانطلاق والربط الكلي لمفاهيم الدفتر |\n`;
  branches.forEach((b, i) => {
    methodologyContent += `| **مفهوم رئيسي ${i + 1}** | ${b.title} | ${b.badge || 'مفهوم أساسي'} | تأسيس المفهوم وضبط الفروع والأمثلة |\n`;
    (b.children || []).forEach((l, j) => {
      const summaryNote = (l.notes || 'تطبيق إجرائي').replace(/\|/g, ' ').slice(0, 48);
      methodologyContent += `| ↳ فرع ${i + 1}.${j + 1} | ${l.title} | ${l.badge || 'تفصيل'} | ${summaryNote}... |\n`;
    });
  });

  // 4. Detailed Analysis & Formulas
  let analysisContent = `### ⚖️ القوانين والمعادلات والتحليل الأكاديمي (Formulas & Academic Analysis)\n\n`;
  let hasFormulas = false;
  branches.forEach((b) => {
    if (b.formula) {
      hasFormulas = true;
      analysisContent += `#### قانون: ${b.title}\n$$${b.formula}$$\n`;
      if (b.notes) analysisContent += `> ${b.notes}\n\n`;
    }
    (b.children || []).forEach((l) => {
      if (l.formula) {
        hasFormulas = true;
        analysisContent += `#### معادلة / صيغة فرعية: ${l.title}\n$$${l.formula}$$\n`;
        if (l.notes) analysisContent += `> ${l.notes}\n\n`;
      }
    });
  });

  if (!hasFormulas) {
    branches.forEach((b) => {
      if (b.notes) {
        analysisContent += `- **${b.title}**: ${b.notes}\n`;
      }
    });
  }

  // 5. Exam Tips & Pitfalls
  let examTipsContent = `### ⚠️ تنبيهات دراسية وأخطاء شائعة في الاختبارات (Study Guide & Exam Alerts)\n\n`;
  examTipsContent += `- **الربط الهرمي بين المفاهيم**: عند مراجعة هذا الدفتر، تتبع الشجرة من الفكرة المركزية وصولاً إلى التفريعات لتجنب إغفال أي جزئية في الامتحان.\n`;
  examTipsContent += `- **الدقة في المصطلحات والرموز**: تأكد من حفظ المصطلحات والشارات التصنيفية بدقة، وعدم الخلط بين المفاهيم المتشابهة في المحاور.\n`;
  examTipsContent += `- **التطبيق على القوانين والمعادلات**: تدرب على صياغة المعادلات والتعويض في الوحدات وفق المنهجية المعروضة في الشجرة.\n`;
  examTipsContent += `- **كبسولة الاستذكار السريع**: استعرض المخطط الهيكلي قبل موعد الامتحان لاستحضار الخريطة الذهنية الكلية بثقة وسرعة.\n`;

  const fullMarkdown = `${conceptsContent}\n\n${takeawaysContent}\n\n${methodologyContent}\n\n${analysisContent}\n\n${examTipsContent}`;

  return {
    documentTitle: `دليل دراسي أكاديمي شامل: شجرة المفاهيم الأساسية - ${rootNode.title}`,
    notebookName,
    subject,
    dateStr: currentDate,
    mainConcepts: {
      id: 'concepts',
      title: 'المفاهيم الأساسية وهيكل الشجرة البصرية',
      englishTitle: 'Main Concepts & Visual Tree Structure',
      icon: '💡',
      colorTheme: 'teal',
      content: conceptsContent,
      keyPoints: branches.map((b) => b.title),
    },
    keyTakeaways: {
      id: 'takeaways',
      title: 'الخلاصات والنقاط الجوهرية المستفادة',
      englishTitle: 'Key Takeaways & Core Syntheses',
      icon: '📌',
      colorTheme: 'navy',
      content: takeawaysContent,
      keyPoints: branches.flatMap((b) => (b.children || []).map((c) => c.title)).slice(0, 8),
    },
    methodology: {
      id: 'methodology',
      title: 'المنهجية ومصفوفة التفرع الهرمي',
      englishTitle: 'Methodology & Conceptual Hierarchy Table',
      icon: '📐',
      colorTheme: 'emerald',
      content: methodologyContent,
      keyPoints: branches.map((b) => `${b.title} (${(b.children || []).length} فروع)`),
    },
    detailedAnalysis: {
      id: 'analysis',
      title: 'القوانين والمعادلات والتحليل الأكاديمي',
      englishTitle: 'Formulas, Laws & Detailed Analysis',
      icon: '⚖️',
      colorTheme: 'teal',
      content: analysisContent,
      keyPoints: [],
    },
    examTips: {
      id: 'exam_tips',
      title: 'تنبيهات الامتحانات ودليل المذاكرة',
      englishTitle: 'Study Guide & Exam Alerts',
      icon: '⚠️',
      colorTheme: 'amber',
      content: examTipsContent,
      keyPoints: ['الربط الهرمي بين المفاهيم', 'الدقة في المصطلحات والرموز', 'التطبيق على القوانين', 'المراجعة السريعة'],
    },
    rawFilteredMarkdown: fullMarkdown,
  };
}

/**
 * Specialized PDF generation utility that traverses the ChatView conversation history,
 * extracts core academic concepts, questions, detailed pedagogical answers, formulas,
 * and renders them into the StructuredSummary format ready for 'academic-report-style' PDF layout.
 */
export function conversationHistoryToStructuredSummary(
  messages: ChatMessage[],
  sessionTitle: string = 'جلسة مذاكرة وتدريس تفاعلية',
  notebookName: string = 'دفتر المذاكرة الذكي',
  subject: string = 'مراجعة المنهج الأكاديمي'
): StructuredSummary {
  const currentDate = new Date().toLocaleDateString('ar-EG', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  const validMessages = messages.filter((m) => m.text && m.text.trim().length > 0);

  // Separate questions and answers
  const qnaPairs: Array<{ question: string; answer: string; citationsCount: number }> = [];
  let currentQ = '';

  for (const msg of validMessages) {
    if (msg.role === 'user') {
      currentQ = msg.text.trim();
    } else if (msg.role === 'ai') {
      const sanitized = filterAIFiller(msg.text);
      qnaPairs.push({
        question: currentQ || 'استفسار أكاديمي حول المنهج',
        answer: sanitized,
        citationsCount: msg.citations?.length || 0,
      });
      currentQ = '';
    }
  }

  // 1. Main Concepts: Extracted directly and exclusively from user questions & tutor explanations
  let conceptsContent = '';
  if (qnaPairs.length === 0) {
    conceptsContent = `لا توجد استفسارات أو شروحات مسجلة بعد في هذه الجلسة ليتم تلخيصها.`;
  } else {
    conceptsContent = qnaPairs
      .map((pair, idx) => {
        const qTitle = pair.question.replace(/\n/g, ' ').trim();
        // Extract opening thesis or definitions from the answer
        const firstLines = pair.answer
          .split('\n')
          .map((l) => l.trim())
          .filter((l) => l.length > 15 && !l.startsWith('#'))
          .slice(0, 2)
          .join(' ');
        return `### ${idx + 1}. ${qTitle}\n${firstLines ? `${firstLines}` : ''}`;
      })
      .join('\n\n');
  }

  // 2. Key Takeaways: High-level summaries & takeaways across actual responses
  let takeawaysContent = '';
  const allBulletPoints: string[] = [];

  qnaPairs.forEach((pair, idx) => {
    const bullets = extractBulletPoints(pair.answer);
    if (bullets.length > 0) {
      takeawaysContent += `#### 🔹 مخرجات استفسار (${idx + 1}): ${pair.question.slice(0, 70)}${pair.question.length > 70 ? '...' : ''}\n`;
      bullets.slice(0, 4).forEach((b) => {
        takeawaysContent += `- ${b}\n`;
        allBulletPoints.push(b);
      });
      takeawaysContent += '\n';
    } else {
      const meaningfulLines = pair.answer
        .split('\n\n')
        .map((l) => l.trim())
        .filter((l) => l.length > 20 && !l.startsWith('#'));
      if (meaningfulLines.length > 0) {
        takeawaysContent += `#### 🔹 خلاصة (${idx + 1}): ${pair.question.slice(0, 70)}\n`;
        takeawaysContent += `- ${meaningfulLines[0]}\n\n`;
        allBulletPoints.push(meaningfulLines[0].slice(0, 80));
      }
    }
  });

  // 3. Methodology & Step-by-Step Solutions: Extracted directly from procedural steps in answers
  let methodologyContent = '';
  const proceduralSteps: string[] = [];
  qnaPairs.forEach((pair, idx) => {
    const lines = pair.answer.split('\n');
    const steps = lines.filter((l) => /^\s*(?:\d+[\.\)]|[-*•]\s+(?:خطوة|أولاً|ثانياً|ثالثاً|رابعاً|خامساً))\s+/i.test(l.trim()));
    if (steps.length > 0) {
      proceduralSteps.push(`#### مسار الحل والتطبيق: ${pair.question.slice(0, 60)}...\n` + steps.slice(0, 5).join('\n'));
    }
  });

  if (proceduralSteps.length > 0) {
    methodologyContent = proceduralSteps.join('\n\n');
  } else {
    // If no numbered steps, extract the core procedural sentences
    const directSteps = qnaPairs
      .map((p, i) => {
        const sentences = p.answer.split(/[.!\n]/).filter((s) => s.trim().length > 25);
        if (sentences.length > 0) {
          return `${i + 1}. **${p.question.slice(0, 50)}**: ${sentences[0].trim()}`;
        }
        return '';
      })
      .filter(Boolean);
    methodologyContent = directSteps.join('\n\n');
  }

  // 4. Detailed Analysis & Formulas (حصر القوانين والمعادلات بصيغة LaTeX - استبعاد تام إذا لم ترد في النص)
  let analysisContent = '';
  const formulasFound: string[] = [];
  qnaPairs.forEach((pair) => {
    const rawMatches = pair.answer.match(/\$\$[\s\S]*?\$\$|\$[^$\n]+\$/g);
    if (rawMatches && rawMatches.length > 0) {
      formulasFound.push(...rawMatches.map((m) => m.trim()));
    }
  });

  if (formulasFound.length > 0) {
    const uniqueFormulas = Array.from(new Set(formulasFound)).slice(0, 8);
    analysisContent = uniqueFormulas
      .map((f, i) => {
        if (f.startsWith('$$')) return `$$\n${f.replace(/\$\$/g, '').trim()}\n$$`;
        return `- المعادلة / القاعدة (${i + 1}): ${f}`;
      })
      .join('\n\n');
  }

  // 5. Exam Tips & Pitfalls (حصر تنبيهات الامتحانات الواردة فعلياً في الشرح فقط)
  let examTipsContent = '';
  const examLines: string[] = [];
  qnaPairs.forEach((pair) => {
    const lines = pair.answer.split('\n');
    lines.forEach((l) => {
      const lower = l.toLowerCase();
      if (
        lower.includes('امتحان') ||
        lower.includes('اختبار') ||
        lower.includes('وزاري') ||
        lower.includes('انتبه') ||
        lower.includes('خطأ شائع') ||
        lower.includes('تنبيه') ||
        lower.includes('ملاحظة هامة')
      ) {
        const cleaned = l.replace(/^[#>*•-]+\s*/, '').trim();
        if (cleaned.length > 15 && cleaned.length < 220) {
          examLines.push(`- ${cleaned}`);
        }
      }
    });
  });

  if (examLines.length > 0) {
    examTipsContent = Array.from(new Set(examLines)).slice(0, 6).join('\n');
  }

  const fullMarkdown = [
    conceptsContent ? `## 💡 المفاهيم الأساسية\n\n${conceptsContent}` : '',
    takeawaysContent ? `## 📌 الخلاصات والنقاط الجوهرية\n\n${takeawaysContent}` : '',
    methodologyContent ? `## 📐 المنهجية والتطبيقات\n\n${methodologyContent}` : '',
    analysisContent ? `## ⚖️ القوانين والمعادلات\n\n${analysisContent}` : '',
    examTipsContent ? `## ⚠️ تنبيهات المذاكرة والامتحانات\n\n${examTipsContent}` : '',
  ].filter(Boolean).join('\n\n');

  return {
    documentTitle: `سجل المحادثة والمراجعة الأكاديمية: ${sessionTitle}`,
    notebookName,
    subject,
    dateStr: currentDate,
    mainConcepts: {
      id: 'concepts',
      title: 'المحاور والمفاهيم المشروحة',
      englishTitle: 'Core Concepts & Investigated Topics',
      icon: '💡',
      colorTheme: 'teal',
      content: conceptsContent,
      keyPoints: qnaPairs.map((p) => p.question.slice(0, 50)),
      hasContent: conceptsContent.trim().length > 0,
    },
    keyTakeaways: {
      id: 'takeaways',
      title: 'النتائج والركائز العلمية',
      englishTitle: 'Key Takeaways & Synthesized Conclusions',
      icon: '📌',
      colorTheme: 'navy',
      content: takeawaysContent,
      keyPoints: allBulletPoints.slice(0, 10),
      hasContent: takeawaysContent.trim().length > 0,
    },
    methodology: {
      id: 'methodology',
      title: 'المنهجية والخطوات الإجرائية',
      englishTitle: 'Methodology & Procedural Alignment',
      icon: '📐',
      colorTheme: 'emerald',
      content: methodologyContent,
      keyPoints: extractBulletPoints(methodologyContent),
      hasContent: methodologyContent.trim().length > 0,
    },
    detailedAnalysis: {
      id: 'analysis',
      title: 'القوانين والمعادلات والتحليل المفصل',
      englishTitle: 'Detailed Analysis & Formulas',
      icon: '⚖️',
      colorTheme: 'teal',
      content: analysisContent,
      keyPoints: [],
      hasContent: analysisContent.trim().length > 0,
    },
    examTips: {
      id: 'exam_tips',
      title: 'تنبيهات الامتحانات وملاحظات التركيز',
      englishTitle: 'Exam Readiness & Focused Guidance',
      icon: '⚠️',
      colorTheme: 'amber',
      content: examTipsContent,
      keyPoints: extractBulletPoints(examTipsContent),
      hasContent: examTipsContent.trim().length > 0,
    },
    rawFilteredMarkdown: fullMarkdown,
  };
}

/**
 * Refactors and sanitizes AI output:
 * - Strips conversational pleasantries and filler greetings
 * - Enforces a structured Markdown schema (clear headers, distinct bullet points, callouts)
 * - Guarantees clean, non-conversational academic structure before rendering
 */
export function sanitizeAndStructureAIResponse(
  rawText: string,
  options?: { enforceThreePillars?: boolean; notebookName?: string; subject?: string }
): string {
  if (!rawText) return '';

  if (options?.enforceThreePillars) {
    return preprocessAndEnforceAcademicSchema(rawText, options);
  }

  let text = filterAIFiller(rawText).trim();
  text = preprocessEducationalText(text);

  // If text doesn't contain any headers (#), organize long multi-paragraph responses
  const hasHeaders = /^#{1,4}\s+/m.test(text);
  if (!hasHeaders && text.length > 250) {
    const paragraphs = text.split(/\n{2,}/).map((p) => p.trim()).filter(Boolean);
    if (paragraphs.length >= 2) {
      let structured = `### 💡 المفهوم الأساسي\n\n${paragraphs[0]}\n\n`;
      if (paragraphs.length > 2) {
        structured += `### 📌 الشرح والتحليل المفصل\n\n${paragraphs.slice(1, -1).join('\n\n')}\n\n`;
        structured += `### 📝 النقاط والخلاصة الجوهرية\n\n${paragraphs[paragraphs.length - 1]}`;
      } else {
        structured += `### 📌 الشرح والتفصيل\n\n${paragraphs[1]}`;
      }
      text = structured;
    }
  }

  // Normalize list bullet formatting: ensure standard Markdown list markers with clean bolding
  text = text.replace(/^[•*]\s+/gm, '- ');

  return text;
}
