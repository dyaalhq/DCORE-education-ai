import { BankQuestion, QuestionSection, DifficultyLevel, QuestionType, QUESTION_BANK_DATABASE } from './questionBankData';
import { offlineDb } from './offlineDatabase';
import { COMPREHENSIVE_ENCYCLOPEDIA_ARTICLES } from './encyclopediaData';
import {
  generateYemeniPhysicsQuestions,
  generateYemeniChemistryQuestions,
  generateYemeniBiologyQuestions,
  generateYemeniMathQuestions,
  generateYemeniArabicAndIslamicQuestions,
  generateYemeniGrade9ScienceQuestions,
  generateYemeniGrade9SocialQuestions,
  generateYemeniLiteraryQuestions,
  generateYemeniMedicalQuestions,
} from './yemeniQuestionsEngine';
import {
  generateMassivePhysicsQuestions,
  generateMassiveChemistryQuestions,
  generateMassiveMathQuestions,
  generateMassiveBiologyQuestions,
  generateMassiveMedicalQuestions,
} from './massiveAcademicBankEngine';

/**
 * Checks whether a question is mismatched or cross-contaminated with another subject's content.
 * Strictly verifies domain integrity so subjects never leak into one another.
 */
export function isCorruptedQuestion(q: Partial<BankQuestion>): boolean {
  if (!q) return true;
  const id = q.id || '';
  const subj = (q.subject || '').trim();
  const topic = (q.unitOrTopic || '').trim();
  const text = (q.question || '').trim();
  const section = q.section;

  // Purge any ministerial physics questions with English variables (L = 0.1 H, C = 10 \mu F, f_0, 159 Hz)
  if (section === 'ministerial' && (text.includes('L =') || text.includes('C =') || text.includes('f_0') || text.includes('\\mu\\text{F}') || text.includes('Hz') || text.includes('V_p ='))) {
    return true;
  }

  // Purge older repetitively looped questions with artificial suffixes
  if (text.includes('(الحالة التطبيقية الوزارية رقم') || text.includes('(بند اختباري وزارى') || text.includes('(بند وزاري')) {
    return true;
  }

  // Purge any older questions with raw unparsed \ce{ or raw ce{H3O+} artifacts from previous runs
  if (text.includes('\\ce{') || text.includes('ce{H3O+}') || text.includes('ce{N2(g)')) {
    return true;
  }

  // Purge older synthetic chemistry templates with repetitive Kc or [H3O+] = 1.0 \times 10^{-
  if (text.includes('إذا كان ثابت الاتزان K_c =') || text.includes('تركيز أيونات الهيدرونيوم فيه [') || text.includes('تركيز أيون الهيدرونيوم فيه [') || text.includes('K_c = 2.5') || text.includes('K_c = 7.5')) {
    return true;
  }


  // 0. ID Prefix Verification
  if ((id.startsWith('gen_ye_phy_') || id.startsWith('gen_phy_')) && subj !== 'الفيزياء') return true;
  if ((id.startsWith('gen_ye_chem_') || id.startsWith('gen_chm_')) && !subj.includes('الكيمياء')) return true;
  if ((id.startsWith('gen_ye_bio_') || id.startsWith('gen_bio_')) && !subj.includes('الأحياء')) return true;
  if ((id.startsWith('gen_ye_mat_') || id.startsWith('gen_mat_')) && !subj.includes('الرياضيات')) return true;
  if (id.startsWith('gen_ye_arb_') && !subj.includes('العربية')) return true;
  if (id.startsWith('gen_ye_isl_') && (!subj.includes('القرآن') && !subj.includes('الإسلامية'))) return true;
  if (id.startsWith('gen_ye_eng_') && (!subj.includes('الإنجليزية') && !subj.includes('English'))) return true;
  if (id.startsWith('gen_ye_soc_') && !subj.includes('الاجتماعيات')) return true;
  if (id.startsWith('gen_ye_his_') && !subj.includes('التاريخ')) return true;
  if (id.startsWith('gen_ye_geo_') && !subj.includes('الجغرافيا')) return true;
  if (id.startsWith('gen_ye_phi_') && (!subj.includes('الفلسفة') && !subj.includes('علم النفس'))) return true;
  if (id.startsWith('gen_ye_sci_') && !subj.includes('العلوم')) return true;
  if (id.startsWith('gen_med_') && section !== 'medical') return true;

  // 1. Non-science subjects (Arabic, Islamic, Social, History, Geography, Philosophy) contaminated with STEM
  const isHumanities =
    subj.includes('العربية') ||
    subj.includes('القرآن') ||
    subj.includes('الإسلامية') ||
    subj.includes('الاجتماعيات') ||
    subj.includes('التاريخ') ||
    subj.includes('الجغرافيا') ||
    subj.includes('الفلسفة') ||
    subj.includes('علم النفس');

  if (isHumanities) {
    if (
      topic.includes('التيار المتردد') ||
      topic.includes('الرنين') ||
      topic.includes('المحول') ||
      topic.includes('المقذوفات') ||
      topic.includes('الكيمياء') ||
      topic.includes('تفاضل') ||
      topic.includes('نهايات') ||
      topic.includes('تكامل') ||
      topic.includes('الأعداد المركبة') ||
      topic.includes('قانون أوم') ||
      topic.includes('DNA') ||
      topic.includes('STEMI') ||
      topic.includes('ECG') ||
      text.includes('دائرة رنين') ||
      text.includes('ملف حث') ||
      text.includes('مكثف سعته') ||
      text.includes('التردد الرنيني') ||
      text.includes('المحول الكهربائي') ||
      text.includes('قُذفت قذيفة') ||
      text.includes('\\ce{') ||
      text.includes('\\lim_{') ||
      text.includes('Hz') ||
      text.includes('هنري') ||
      text.includes('ميكروفاراد') ||
      text.includes('أوم') ||
      text.includes('أقصى ارتفاع رأسي') ||
      text.includes('ثابت الاتزان') ||
      text.includes('pH =')
    ) {
      return true;
    }
  }

  // 2. English subject contaminated with Arabic grammar, Islamic fiqh, or Physics
  if (subj.includes('الإنجليزية') || subj.includes('English')) {
    if (
      topic.includes('التيار المتردد') ||
      topic.includes('الرنين') ||
      topic.includes('كان وأخواتها') ||
      topic.includes('المفاعيل') ||
      topic.includes('التجويد') ||
      text.includes('دائرة رنين') ||
      text.includes('ملف حث') ||
      text.includes('كان وأخواتها') ||
      text.includes('إعراب')
    ) {
      return true;
    }
  }

  // 3. Chemistry contaminated with Physics AC circuits or Arabic grammar
  if (subj.includes('الكيمياء')) {
    if (
      topic.includes('التيار المتردد') ||
      topic.includes('الرنين') ||
      topic.includes('المقذوفات') ||
      topic.includes('كان وأخواتها') ||
      topic.includes('التجويد') ||
      text.includes('دائرة رنين') ||
      text.includes('ملف حثه الذاتي') ||
      text.includes('المحول الكهربائي')
    ) {
      return true;
    }
  }

  // 4. Biology contaminated with Physics AC circuits or Calculus limits
  if (subj.includes('الأحياء')) {
    if (
      topic.includes('التيار المتردد') ||
      topic.includes('الرنين') ||
      topic.includes('المقذوفات') ||
      topic.includes('كان وأخواتها') ||
      text.includes('دائرة رنين') ||
      text.includes('\\lim_{') ||
      text.includes('المحول الكهربائي')
    ) {
      return true;
    }
  }

  // 5. Mathematics contaminated with AC circuits, DNA, or Arabic grammar
  if (subj.includes('الرياضيات')) {
    if (
      topic.includes('التيار المتردد') ||
      topic.includes('الرنين') ||
      topic.includes('DNA') ||
      topic.includes('كان وأخواتها') ||
      topic.includes('التجويد') ||
      text.includes('دائرة رنين') ||
      text.includes('ملف حثه') ||
      text.includes('\\ce{')
    ) {
      return true;
    }
  }

  // 6. Physics contaminated with Arabic grammar, DNA, or Chemistry organic nomenclature
  if (subj.includes('الفيزياء')) {
    if (
      topic.includes('كان وأخواتها') ||
      topic.includes('المفاعيل') ||
      topic.includes('التجويد') ||
      topic.includes('DNA') ||
      topic.includes('الكيمياء العضوية') ||
      text.includes('اسم كان') ||
      text.includes('أحكام النون الساكنة')
    ) {
      return true;
    }
  }

  // 7. Medical blocks contaminated with high school ministerial physics circuits or Arabic grammar
  if (section === 'medical') {
    if (
      topic.includes('التيار المتردد') ||
      topic.includes('المقذوفات') ||
      topic.includes('كان وأخواتها') ||
      text.includes('دائرة رنين') ||
      text.includes('ملف حثه الذاتي')
    ) {
      return true;
    }
  }

  return false;
}

/**
 * Automatically purges any corrupted, cross-contaminated, or duplicate questions from IndexedDB.
 */
export async function cleanAndSanitizeCorruptedQuestions(): Promise<number> {
  try {
    const allQ = await offlineDb.questions.toArray();
    const idsToDelete: string[] = [];
    const seenPrompts = new Set<string>();
    const seenIds = new Set<string>();
    const templateCounts = new Map<string, number>();

    for (const q of allQ) {
      if (isCorruptedQuestion(q)) {
        idsToDelete.push(q.id);
        continue;
      }
      if (seenIds.has(q.id)) {
        idsToDelete.push(q.id);
        continue;
      }
      seenIds.add(q.id);

      // Strict exact deduplication: same section, subject, and normalized question text
      const cleanPrompt = (q.question || '').trim().replace(/\s+/g, ' ');
      const exactKey = `${q.section}_${q.subject}_${cleanPrompt}`;

      if (seenPrompts.has(exactKey)) {
        idsToDelete.push(q.id);
        continue;
      }
      seenPrompts.add(exactKey);

      // Template-level variation deduplication: Prevent endless repetitions of identical numerical templates (Max 1 per template)
      const templateKey = `${q.section}_${q.subject}_${cleanPrompt.replace(/[0-9٠-٩]+(?:\.[0-9٠-٩]+)?/g, '#')}`;
      const count = templateCounts.get(templateKey) || 0;
      if (count >= 1) {
        idsToDelete.push(q.id);
        continue;
      }
      templateCounts.set(templateKey, count + 1);
    }

    if (idsToDelete.length > 0) {
      console.log(`[DB Sanitization] Purging ${idsToDelete.length} corrupted or duplicate questions from IndexedDB...`);
      await offlineDb.questions.bulkDelete(idsToDelete);
    }

    return idsToDelete.length;
  } catch (e) {
    console.warn('Error during question database sanitization:', e);
    return 0;
  }
}

/**
 * Ensures a subject has at least targetCount clean questions in IndexedDB.
 */
export async function ensureSubjectQuestionsCount(options: {
  section: QuestionSection;
  subject?: string;
  stage?: 'تاسع أساسي' | 'ثالث ثانوي علمي' | 'ثالث ثانوي أدبي';
  medicalBlock?: string;
  targetCount: number;
}): Promise<number> {
  const { section, stage, medicalBlock, targetCount } = options;
  const rawSubject = (options.subject || options.medicalBlock || '').trim();
  const subject = typeof rawSubject === 'string' ? rawSubject : String(rawSubject || '');
  try {
    const allDbQuestions = await offlineDb.questions.toArray();
    const cleanMatches = allDbQuestions.filter((q) => {
      if (isCorruptedQuestion(q)) return false;
      if (q.section !== section) return false;
      if (section === 'ministerial') {
        if (q.stage !== stage || q.subject !== subject) return false;
      }
      if (section === 'medical') {
        if (q.medicalBlock !== medicalBlock) return false;
      }
      return true;
    });

    if (cleanMatches.length < targetCount) {
      const needed = targetCount - cleanMatches.length;
      console.log(`Generating ${needed} fresh questions for [${subject} / ${stage || medicalBlock}]...`);
      const freshQuestions = generateSyntheticAcademicQuestions({
        section,
        subject,
        stage,
        medicalBlock,
        targetCount: needed,
      });

      const cleanFresh = freshQuestions.filter((q) => !isCorruptedQuestion(q));
      await offlineDb.questions.bulkPut(cleanFresh);
      return cleanMatches.length + cleanFresh.length;
    }

    return cleanMatches.length;
  } catch (e) {
    console.warn('Failed to ensure subject questions count:', e);
    return 0;
  }
}

/**
 * Initializes, cleans, and seeds the Dexie IndexedDB with base database and encyclopedia
 */
export async function initializeOfflineDatabase(): Promise<{
  questionsCount: number;
  articlesCount: number;
}> {
  try {
    // 1. Purge any corrupted or mismatched entries from previous runs
    await cleanAndSanitizeCorruptedQuestions();

    // 2. Ensure initial seed and procedural bank replenishment
    const cleanSeeds = QUESTION_BANK_DATABASE.filter((q) => !isCorruptedQuestion(q));
    const proceduralSeeds = [
      ...generateMassivePhysicsQuestions(60),
      ...generateMassiveChemistryQuestions(60),
      ...generateMassiveMathQuestions(60),
      ...generateMassiveBiologyQuestions(60),
      ...generateMassiveMedicalQuestions(30),
      ...generateYemeniLiteraryQuestions(30, 'التاريخ الحديث'),
      ...generateYemeniLiteraryQuestions(30, 'الجغرافيا'),
      ...generateYemeniLiteraryQuestions(30, 'الفلسفة وعلم النفس'),
      ...generateYemeniGrade9SocialQuestions(30),
      ...generateYemeniGrade9ScienceQuestions(30),
      ...generateYemeniArabicAndIslamicQuestions(30, 'اللغة العربية'),
      ...generateYemeniArabicAndIslamicQuestions(30, 'القرآن والإسلامية'),
    ].filter((q) => !isCorruptedQuestion(q));

    await offlineDb.questions.bulkPut([...cleanSeeds, ...proceduralSeeds]);

    // 3. Ensure encyclopedia articles are seeded
    const existingArticlesCount = await offlineDb.encyclopedia.count();
    if (existingArticlesCount === 0) {
      console.log('Seeding initial Encyclopedia into IndexedDB...');
      await offlineDb.encyclopedia.bulkPut(COMPREHENSIVE_ENCYCLOPEDIA_ARTICLES);
    }

    const totalQ = await offlineDb.questions.count();
    const totalA = await offlineDb.encyclopedia.count();
    return { questionsCount: totalQ, articlesCount: totalA };
  } catch (e) {
    console.warn('Failed to initialize or seed IndexedDB, falling back to in-memory datasets:', e);
    return {
      questionsCount: QUESTION_BANK_DATABASE.length,
      articlesCount: COMPREHENSIVE_ENCYCLOPEDIA_ARTICLES.length,
    };
  }
}

/**
 * Helper to shuffle array elements deterministically
 */
function shuffleOptions<T>(array: T[], seed: number): { shuffled: T[]; correctIndex: number } {
  const arr = [...array];
  const originalCorrect = arr[0];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.abs(Math.floor((seed * 9301 + 49297) % 233280)) % (i + 1);
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  const correctIndex = arr.indexOf(originalCorrect);
  return { shuffled: arr, correctIndex: correctIndex >= 0 ? correctIndex : 0 };
}

/**
 * Algorithmic generator producing verified, curriculum-precise academic MCQs
 * for Yemeni Ministry Curriculum (ALL subjects) and Medical Blocks.
 * Ensures zero cross-contamination and guarantees unique non-repeating questions.
 */
export function generateSyntheticAcademicQuestions(options: {
  section: QuestionSection;
  subject?: string;
  stage?: 'تاسع أساسي' | 'ثالث ثانوي علمي' | 'ثالث ثانوي أدبي';
  medicalBlock?: string;
  targetCount: number;
}): BankQuestion[] {
  const generated: BankQuestion[] = [];
  const { section, stage, medicalBlock, targetCount } = options;
  const rawSubject = (options.subject || options.medicalBlock || '').trim();
  const subject = typeof rawSubject === 'string' ? rawSubject : String(rawSubject || '');
  const seenQuestionTexts = new Set<string>();

  const isArabic = subject.includes('العربية');
  const isIslam = subject.includes('القرآن') || subject.includes('الإسلامية');
  const isMath = subject.includes('الرياضيات');
  const isChem = subject.includes('الكيمياء');
  const isBio = subject.includes('الأحياء');
  const isPhysics = subject.includes('الفيزياء');
  const isEnglish = subject.includes('الإنجليزية') || subject.includes('English');
  const isScienceG9 = subject === 'العلوم' || (stage === 'تاسع أساسي' && subject.includes('العلوم'));
  const isSocialG9 = subject === 'الاجتماعيات' || (stage === 'تاسع أساسي' && subject.includes('الاجتماعيات'));
  const isHistoryLit = subject.includes('التاريخ');
  const isGeographyLit = subject.includes('الجغرافيا');
  const isPhilosophyLit = subject.includes('الفلسفة') || subject.includes('علم النفس');

  if (section === 'ministerial') {
    if (isPhysics) {
      return generateYemeniPhysicsQuestions(targetCount, stage || 'ثالث ثانوي علمي');
    }
    if (isChem) {
      return generateYemeniChemistryQuestions(targetCount, stage || 'ثالث ثانوي علمي');
    }
    if (isBio) {
      return generateYemeniBiologyQuestions(targetCount, stage || 'ثالث ثانوي علمي');
    }
    if (isMath) {
      return generateYemeniMathQuestions(targetCount, stage || 'ثالث ثانوي علمي');
    }
    if (isArabic || isIslam) {
      return generateYemeniArabicAndIslamicQuestions(targetCount, subject, stage || 'ثالث ثانوي علمي');
    }
    if (isScienceG9) {
      return generateYemeniGrade9ScienceQuestions(targetCount);
    }
    if (isSocialG9) {
      return generateYemeniGrade9SocialQuestions(targetCount);
    }
    if (isHistoryLit || isGeographyLit || isPhilosophyLit) {
      return generateYemeniLiteraryQuestions(targetCount, subject);
    }

    // =============================================================
    // 1. اللغة العربية (Arabic Language & Literature)
    // =============================================================
    if (isArabic) {
      const arabicTemplates = [
        // كان وأخواتها
        (i: number) => {
          const names = ['المطرُ', 'النصرُ', 'العلمُ', 'العدلُ', 'الصبرُ', 'الجهدُ'];
          const ex = names[i % names.length];
          return {
            topic: 'قواعد النحو: كان وأخواتها وعملها الإعرابي',
            q: `في جملة: «كان ${ex} غيثاً نافعاً للبلاد»، إعراب كلمة «غيثاً» هو:`,
            ans: 'خبر كان منصوب وعلامة نصبه الفتحة الظاهرة على آخره',
            w1: 'اسم كان مرفوع بالضمة الظاهرة',
            w2: 'نعت منصوب وعلامة نصبه الفتحة',
            w3: 'مفعول به ثانٍ منصوب بالفتحة',
            expl: 'الأفعال الناسخة (كان وأخواتها) تدخل على الجملة الاسمية فترفع المبتدأ اسماً لها وتنصب الخبر خبراً لها.',
            rule: 'كان وأخواتها: ترفع المبتدأ وتنصب الخبر'
          };
        },
        // كاد وأخواتها
        (i: number) => {
          const verbs = ['كاد', 'أوشك', 'عسى', 'حَرَى'];
          const v = verbs[i % verbs.length];
          return {
            topic: 'قواعد النحو: أفعال المقاربة والرجاء والشروع (كاد وأخواتها)',
            q: `في جملة: «${v} الغمامُ أن ينجلي عن سماء صنعاء»، حكم خبر «${v}» ونوعه هو:`,
            ans: 'جملة فعلية فعلها مضارع في محل نصب خبر',
            w1: 'اسم مفرد منصوب بالفتحة الظاهرة',
            w2: 'شبه جملة جار ومجرور في محل رفع',
            w3: 'مصدر صريح مرفوع بالضمة',
            expl: 'خبر أفعال المقاربة والرجاء والشروع يجب أن يكون جملة فعلية فعلها مضارع مقترن بأن أو مجرد منها.',
            rule: 'خبر كاد وأخواتها: جملة فعلية فعلها مضارع'
          };
        },
        // إن وأخواتها
        (i: number) => {
          const particles = ['إنّ', 'أنّ', 'كأنّ', 'لكنّ', 'ليت', 'لعلّ'];
          const p = particles[i % particles.length];
          return {
            topic: 'قواعد النحو: الحروف الناسخة إنّ وأخواتها ومعانيها',
            q: `الحرف الناسخ «${p}» في قوله تعالى أو في سياق الجملة الاسمية يفيد معنوياً:`,
            ans: p === 'إنّ' || p === 'أنّ' ? 'التوكيد ونفي الشك عن الخبر' : p === 'كأنّ' ? 'التشبيه' : p === 'لكنّ' ? 'الاستدراك' : p === 'ليت' ? 'التمني للمستحيل' : 'الرجاء وتوقع المحبوب',
            w1: 'الشرط وجزم الفعلين',
            w2: 'النهي والتحذير',
            w3: 'الاستثناء المنقطع',
            expl: `الحرف الناسخ «${p}» ينصب المبتدأ ويرفع الخبر، ودلالته البلاغية والمعنوية محددة في علم النحو.`,
            rule: 'إنّ وأخواتها: تنصب المبتدأ وترفع الخبر'
          };
        },
        // المفعول المطلق
        (i: number) => {
          const verbs = ['انتصرَ الجيشُ انتصاراً حاسماً', 'قرأتُ الكتابَ قراءةً متأنيةً', 'صبرَ المناضلُ صبراً جميلاً', 'ركضَ المتسابقُ ركضتين'];
          const s = verbs[i % verbs.length];
          return {
            topic: 'قواعد النحو: المفاعيل الخمسة (المفعول المطلق وأنواعه)',
            q: `في الجملة: «${s}»، نوع المفعول المطلق هنا هو:`,
            ans: i % 4 === 3 ? 'مبيّن للعدد' : 'مبيّن للنوع (لوصفه بنعت بعده)',
            w1: 'مؤكد للفعل فقط',
            w2: 'مفعول لأجله لبيان العلة',
            w3: 'نائب فاعل مرفوع',
            expl: 'المفعول المطلق مصدر منصوب من لفظ الفعل؛ فإن وُصف أو أُضيف كان مبيناً للنوع، وإن دل على عدد مرات الفعل كان مبيناً للعدد.',
            rule: 'المفعول المطلق: مصدر منصوب موافق للفظ فعله'
          };
        },
        // المفعول لأجله
        (i: number) => {
          const contexts = ['طلبَ العلمَ رغبةً في المعرفة', 'وقفَ الجنديُّ إجلالاً للعلم الوطني', 'تصدقَ الكريمُ ابتغاءَ مرضاة الله'];
          const c = contexts[i % contexts.length];
          return {
            topic: 'قواعد النحو: المفعول لأجله وشروطه',
            q: `في التركيب التالي: «${c}»، الكلمة التي تعرب مفعولاً لأجله منصوباً هي التي تجيب عن سؤال:`,
            ans: '«لماذا وقع الفعل؟» وهي مصدر قلبي معلل لحدوث الفعل',
            w1: '«من الذي فعل الفعل؟»',
            w2: '«أين وقع الفعل؟»',
            w3: '«كيف كانت هيئة الفاعل؟»',
            expl: 'المفعول لأجله مصدر قلبي منصوب يُذكر لبيان سبب حدوث الفعل وعِلته وعلة فاعله.',
            rule: 'المفعول لأجله: مصدر قلبي منصوب يبين علة وقوع الفعل'
          };
        },
        // أسلوب الاستثناء
        (i: number) => {
          const styles = [
            { text: 'ما فاز في السباق إلا المكافحُ', target: 'المكافحُ', ans: 'فاعل مرفوع بالضمة (استثناء مفرغ ناقص)', w1: 'مستثنى منصوب وجوباً', w2: 'مفعول به منصوب', w3: 'بدل مرفوع' },
            { text: 'حضر الطلابُ إلا زَيْداً', target: 'زَيْداً', ans: 'مستثنى منصوب وجوباً (استثناء تام مثبت)', w1: 'فاعل مرفوع', w2: 'بدل من الطلاب', w3: 'مضاف إليه مجرور' },
            { text: 'ما أثمرت الأشجارُ إلا النخيلُ / النخيلَ', target: 'النخيل', ans: 'يجوز فيه النصب على الاستثناء أو الرفع على البدلية (تام منفي)', w1: 'واجب النصب فقط', w2: 'واجب الرفع فاعلاً', w3: 'مجرور بالإضافة' }
          ];
          const st = styles[i % styles.length];
          return {
            topic: 'قواعد النحو: أساليب الاستثناء التام والمفرغ بأحكامه',
            q: `في أسلوب الاستثناء: «${st.text}»، حكم وإعراب «${st.target}» هو:`,
            ans: st.ans,
            w1: st.w1,
            w2: st.w2,
            w3: st.w3,
            expl: 'في الاستثناء التام المثبت يجب النصب، وفي التام المنفي يجوز النصب أو البدلية، وفي الناقص المفرغ يعرب حسب موقعه.',
            rule: 'أحكام المستثنى بإلا: واجب النصب، أو جائز الوجهين، أو حسب موقعه'
          };
        },
        // المشتقات والميزان الصرفي
        (i: number) => {
          const morph = [
            { w: 'مِعطاء', type: 'صيغة مبالغة على وزن مِفعال', w1: 'اسم فاعل', w2: 'اسم آلة', w3: 'اسم مكان' },
            { w: 'مَكتَبَة', type: 'اسم مكان على وزن مَفعَلَة', w1: 'اسم مفعول', w2: 'صيغة مبالغة', w3: 'مصدر صريح' },
            { w: 'مَلوم', type: 'اسم مفعول من الفعل الثلاثي الأجوف (لام - يلوم)', w1: 'اسم فاعل', w2: 'صفة مشبهة', w3: 'اسم تفضيل' },
            { w: 'أشجع', type: 'اسم تفضيل على وزن أفعَل للدلالة على المفاضلة', w1: 'فعل ماضٍ جامد', w2: 'صيغة مبالغة', w3: 'اسم زمان' }
          ];
          const m = morph[i % morph.length];
          return {
            topic: 'علم الصرف: المشتقات وأوزانها القياسية',
            q: `الوزن الصرفي والنوع الدلالي للمشتق «${m.w}» هو:`,
            ans: m.type,
            w1: m.w1,
            w2: m.w2,
            w3: m.w3,
            expl: 'تصاغ المشتقات القياسية في الصرف العربي وفق أوزان ميزان (ف - ع - ل) للدلالة على الحدث وفاعله أو مفعوله أو هيئته.',
            rule: 'المشتقات: أسماء فاعلين ومفعولين وصيغ مبالغة وصفات مشبهة وتفضيل'
          };
        },
        // البلاغة: الاستعارة والتشبيه
        (i: number) => {
          const rhet = [
            { text: 'قول الشاعر: أقبل يمشي في البساط فما درى ... إلى البحر يسعى أم إلى البدر يرتقي', target: 'البحر والبدر', ans: 'استعارة تصريحية (حُذف المشبه وصُرّح بلفظ المشبه به)', w1: 'استعارة مكنية', w2: 'تشبيه بليغ', w3: 'كناية عن نسبة' },
            { text: 'قوله تعالى: ﴿وَالصُّبْحِ إِذَا تَنَفَّسَ﴾', target: 'تنفس الصبح', ans: 'استعارة مكنية (شبه الصبح بإنسان ثم حذف المشبه به وأبقى صفة من صفاته)', w1: 'استعارة تصريحية', w2: 'مجاز مرسل', w3: 'تشبيه تمثيلي' },
            { text: 'قول المتنبي: أنا الذي نظر الأعمى إلى أدبي ... وأسمعت كلماتي من به صمم', target: 'البيت الشعري', ans: 'كناية عن شدة الشهرة وذيوع الفصاحة وقوة التأثير الأدبي', w1: 'استعارة تصريحية', w2: 'تشبيه مجمل', w3: 'جناس تام' }
          ];
          const r = rhet[i % rhet.length];
          return {
            topic: 'علم البلاغة: البيان (التشبيه والاستعارة والكناية)',
            q: `في النص البلاغي التالي: «${r.text}»، الصورة البيانية في «${r.target}» هي:`,
            ans: r.ans,
            w1: r.w1,
            w2: r.w2,
            w3: r.w3,
            expl: 'الاستعارة تشبيه حُذف أحد طرفيه؛ فإن صرح بلفظ المشبه به فهي تصريحية، وإن حذف المشبه به ورُمز له بلازم فهي مكنية.',
            rule: 'الاستعارة: مجاز لغوي علاقته المشابهة'
          };
        },
        // الأدب والنصوص ورواد الشعر اليمني
        (i: number) => {
          const poets = [
            { poet: 'الشهيد محمد محمود الزبيري (أبو الأحرار)', work: 'قصيدة «يوم الانطلاق» وديوان «صلاة في الجحيم» وصوت الثورة اليمنية', ans: 'الشاعر والزعيم اليمني الثائر محمد محمود الزبيري', w1: 'عبد الله البردوني', w2: 'أحمد شوقي', w3: 'المتنبي' },
            { poet: 'عبد الله البردوني', work: 'صاحب ديوان «مدينة الغد» و«لعينيك يا مجد» وأبرز شعراء التجديد التراثي في القرن العشرين', ans: 'الشاعر والفيلسوف اليمني الكبير عبد الله البردوني', w1: 'محمد محمود الزبيري', w2: 'عبد العزيز المقالح', w3: 'نزار قباني' },
            { poet: 'الدكتور عبد العزيز المقالح', work: 'رائد قصيدة التفعيلة في اليمن ومؤلف «كتاب صنعاء» ورئيس جامعة صنعاء ومجمع اللغة', ans: 'الشاعر والأديب والناقد اليمني الدكتور عبد العزيز المقالح', w1: 'طه حسين', w2: 'بدر شاكر السياب', w3: 'أمل دنقل' }
          ];
          const p = poets[i % poets.length];
          return {
            topic: 'الأدب والنصوص: رواد الأدب والشعر في اليمن والوطن العربي',
            q: `من هو الشاعر اليمني الكبير صاحب الإنجاز الأدبي التالي: «${p.work}»؟`,
            ans: p.ans,
            w1: p.w1,
            w2: p.w2,
            w3: p.w3,
            expl: 'يمثل هؤلاء الرواد قمم الحركة الفكرية والنهضوية والأدبية في تاريخ اليمن المعاصر وأبرز أعمدة المنهج الوزاري المعتمد.',
            rule: 'أدباء اليمن المعاصر: قادة النهضة الفكرية والتحرر'
          };
        }
      ];

      for (let i = 0; i < targetCount; i++) {
        const fn = arabicTemplates[i % arabicTemplates.length];
        const item = fn(i);
        if (seenQuestionTexts.has(item.q)) continue;
        seenQuestionTexts.add(item.q);

        const { shuffled, correctIndex } = shuffleOptions([item.ans, item.w1, item.w2, item.w3], i + 17);
        const diff: DifficultyLevel = i % 3 === 0 ? 'easy' : i % 3 === 1 ? 'medium' : 'hard';

        generated.push({
          id: `gen_ye_arb_${Date.now()}_${i}_${Math.floor(Math.random() * 10000)}`,
          section: 'ministerial',
          stage: stage || 'ثالث ثانوي علمي',
          subject: subject,
          unitOrTopic: item.topic,
          year: `وزاري نماذج معتمدة ${2020 + (i % 5)}`,
          difficulty: diff,
          type: 'mcq',
          question: item.q,
          options: shuffled,
          correctAnswer: correctIndex,
          explanation: item.expl,
          formulaOrRule: item.rule,
          tags: ['اللغة العربية', 'نحو وصرف', 'بلاغة وأدب', 'وزاري يمني'],
        });
      }
    }

    // =============================================================
    // 2. القرآن والإسلامية (Islamic Sciences & Tajweed)
    // =============================================================
    else if (isIslam) {
      const islamTemplates = [
        // أحكام النون الساكنة والتنوين
        (i: number) => {
          const cases = [
            { ayah: '﴿مِنْ مَالِ اللَّهِ﴾', ans: 'إدغام كامل بغنة لوقوع الميم بعد النون الساكنة (من حروف ينمو)', w1: 'إظهار حلقي', w2: 'إقلاب', w3: 'إخفاء حقيقي' },
            { ayah: '﴿مِنْ بَعْدِ مَا جَاءَتْهُمُ﴾', ans: 'إقلاب النون الساكنة ميماً مخفاة بغنة لمجيء حرف الباء', w1: 'إدغام بغير غنة', w2: 'إظهار حلقي', w3: 'إخفاء شفوي' },
            { ayah: '﴿مِنْ حَكِيمٍ حَمِيدٍ﴾', ans: 'إظهار حلقي لمجيء حرف الحاء (من حروف الحلق الستة)', w1: 'إخفاء حقيقي', w2: 'إدغام بغنة', w3: 'إقلاب' },
            { ayah: '﴿مِنْ شَرِّ مَا خَلَقَ﴾', ans: 'إخفاء حقيقي بغنة حركتين لمجيء حرف الشين (من حروف صف ذا ثنا)', w1: 'إظهار حلقي', w2: 'إدغام كامل', w3: 'إقلاب' }
          ];
          const c = cases[i % cases.length];
          return {
            topic: 'علم التجويد: أحكام النون الساكنة والتنوين الأربعة',
            q: `في قوله تعالى: ${c.ayah}، الحكم التجويدي الصحيح الواجب تطبيقه هو:`,
            ans: c.ans,
            w1: c.w1,
            w2: c.w2,
            w3: c.w3,
            expl: 'أحكام النون الساكنة والتنوين أربعة: الإظهار الحلقي، الإدغام (بغنة وبغير غنة)، الإقلاب، والإخفاء الحقيقي.',
            rule: 'أحكام النون والتنوين: إظهار، إدغام، إقلاب، إخفاء'
          };
        },
        // أحكام المدود
        (i: number) => {
          const mudood = [
            { ex: '﴿السَّمَاءِ﴾', ans: 'مد واجب متصل؛ يمد بمقدار 4 أو 5 حركات لاجتماع حرف المد والهمزة في كلمة واحدة', w1: 'مد جائز منفصل يمد حركتين', w2: 'مد لازم كلمي 6 حركات', w3: 'مد بدل حركتان' },
            { ex: '﴿بِمَا أُنْزِلَ﴾', ans: 'مد جائز منفصل؛ يمد بمقدار حركتين أو 4 حركات لمجيء الهمزة في كلمة تالية', w1: 'مد واجب متصل', w2: 'مد لازم حرفي مثقل', w3: 'مد عارض للسكون' },
            { ex: '﴿الصَّاخَّةُ﴾', ans: 'مد لازم كلمي مثقل؛ يمد وجوباً 6 حركات لمجيء حرف مشدد بعد حرف المد', w1: 'مد متصل 4 حركات', w2: 'مد لين', w3: 'مد منفصل' }
          ];
          const m = mudood[i % mudood.length];
          return {
            topic: 'علم التجويد: أحكام المدود (المتصل، المنفصل، اللازم)',
            q: `في قوله تعالى: ${m.ex}، نوع المد القرآني ومقدار مده هو:`,
            ans: m.ans,
            w1: m.w1,
            w2: m.w2,
            w3: m.w3,
            expl: 'المد الفرعي سببه الهمز (متصل، منفصل، بدل) أو السكون (عارض للسكون، لين، لازم).',
            rule: 'المد المتصل والمنفصل واللازم الكلمي'
          };
        },
        // فقه المعاملات والمواريث
        (i: number) => {
          const fiqh = [
            { q: 'بيع درهم بدرهمين نقداً أو غرام ذهب بغرامين ذهباً هو من ربا:', ans: 'ربا الفضل (الزيادة في أحد البدلين الربويين المتجانسين)', w1: 'ربا النسيئة المحض', w2: 'بيع المرابحة الجائز', w3: 'بيع السلم المشروع' },
            { q: 'مات رجل وترك: زوجة، وبنتاً واحدة، وأخاً شقيقاً. نصيب الزوجة والبنت شرعاً هو:', ans: 'للزوجة الثمن (1/8) لوجود الفرع الوارث، وللبنت النصف (1/2) لانفرادها وعدم المعصب', w1: 'للزوجة الربع وللبنت الثلثان', w2: 'للزوجة النصف وللبنت النصف', w3: 'للزوجة السدس وللبنت الربع' },
            { q: 'ماتت امرأة وتركت زوجاً وأماً ولا يوجد فرع وارث ولا جمع من الإخوة. نصيب الزوج والأم هو:', ans: 'للزوج النصف (1/2) لعدم الفرع الوارث، وللأم الثلث (1/3) كاملاً', w1: 'للزوج الربع وللأم السدس', w2: 'للزوج النصف وللأم السدس', w3: 'للزوج الثلث وللأم النصف' }
          ];
          const f = fiqh[i % fiqh.length];
          return {
            topic: 'الفقه الإسلامي: فقه المعاملات والفرائض والمواريث',
            q: f.q,
            ans: f.ans,
            w1: f.w1,
            w2: f.w2,
            w3: f.w3,
            expl: 'أصحاب الفروض مقدرة فروضهم في كتاب الله: (النصف، الربع، الثمن، الثلثان، الثلث، السدس).',
            rule: 'المواريث وأصحاب الفروض المقدرة شرعاً'
          };
        },
        // السيرة النبوية وإسلام أهل اليمن
        (i: number) => {
          const sirah = [
            { q: 'بعث النبي ﷺ إلى اليمن لنشر الإسلام وتعليم القرآن والقضاء الصحابيين الجليلين:', ans: 'معاذ بن جبل وعلي بن أبي طالب وأبو موسى الأشعري رضي الله عنهم', w1: 'سعد بن أبي وقاص وخالد بن الوليد', w2: 'عمرو بن العاص والزبير بن العوام', w3: 'أبو عبيدة بن الجراح وعمار بن ياسر' },
            { q: 'حين أسلمت قبيلة همدان اليمنية في يوم واحد بعد قراءة كتاب رسول الله ﷺ، خر النبي ﷺ ساجداً وقال:', ans: '«السلام على همدان، السلام على همدان»', w1: '«اللهم اهدِ دوساً»', w2: '«لا هجرة بعد الفتح» فقط', w3: '«اليمن أهل حكمة وفقه» فقط' }
          ];
          const s = sirah[i % sirah.length];
          return {
            topic: 'السيرة النبوية وتاريخ إسلام أهل اليمن',
            q: s.q,
            ans: s.ans,
            w1: s.w1,
            w2: s.w2,
            w3: s.w3,
            expl: 'دخل أهل اليمن الإسلام طواعية واستجابة لدعوة رسول الله ﷺ، وشاركوا في كافة الفتوحات الإسلامية الكبرى.',
            rule: 'فضل أهل اليمن في الإسلام والسيرة النبوية'
          };
        }
      ];

      for (let i = 0; i < targetCount; i++) {
        const fn = islamTemplates[i % islamTemplates.length];
        const item = fn(i);
        if (seenQuestionTexts.has(item.q)) continue;
        seenQuestionTexts.add(item.q);

        const { shuffled, correctIndex } = shuffleOptions([item.ans, item.w1, item.w2, item.w3], i + 31);
        const diff: DifficultyLevel = i % 3 === 0 ? 'easy' : i % 3 === 1 ? 'medium' : 'hard';

        generated.push({
          id: `gen_ye_isl_${Date.now()}_${i}_${Math.floor(Math.random() * 10000)}`,
          section: 'ministerial',
          stage: stage || 'ثالث ثانوي علمي',
          subject: subject,
          unitOrTopic: item.topic,
          year: `وزاري نماذج معتمدة ${2020 + (i % 5)}`,
          difficulty: diff,
          type: 'mcq',
          question: item.q,
          options: shuffled,
          correctAnswer: correctIndex,
          explanation: item.expl,
          formulaOrRule: item.rule,
          tags: ['القرآن والإسلامية', 'تجويد', 'فرائض ومواريث', 'سيرة نبوية'],
        });
      }
    }

    // =============================================================
    // 3. الرياضيات (Mathematics - Calculus, Algebra, Complex Numbers)
    // =============================================================
    else if (isMath) {
      for (let i = 0; i < targetCount; i++) {
        const sub = i % 6;
        let q = '';
        let ans = '';
        let w1 = '';
        let w2 = '';
        let w3 = '';
        let expl = '';
        let rule = '';
        let topic = '';

        if (sub === 0) {
          // نهايات الدوال المثلثية
          const a = (i % 7) + 2;
          const b = ((i + 3) % 5) + 2;
          topic = 'التفاضل: نهايات الدوال الدائرية والمثلثية';
          q = `احسب قيمة النهاية الوزارية: $\\lim_{x \\to 0} \\frac{\\sin(${a}x)}{\\tan(${b}x)}$`;
          ans = `$\\frac{${a}}{${b}}$`;
          w1 = `$\\frac{${b}}{${a}}$`;
          w2 = `$${a * b}$`;
          w3 = `$0$`;
          expl = `بقسمة البسط والمقام على $x$ وتطبيق نظريات النهايات: $\\lim_{x \\to 0} \\frac{\\frac{\\sin(${a}x)}{x}}{\\frac{\\tan(${b}x)}{x}} = \\frac{${a}}{${b}}$.`;
          rule = '$\\lim_{x \\to 0} \\frac{\\sin(ax)}{\\tan(bx)} = \\frac{a}{b}$';
        } else if (sub === 1) {
          // قواعد الاشتقاق وتطبيقات التفاضل
          const c = (i % 5) + 2;
          const p = (i % 3) + 2;
          const dCoeff = c * p;
          const subConst = (i % 6) + 3;
          const valAtOne = dCoeff - subConst;
          topic = 'التفاضل: قواعد الاشتقاق والمشتقة الأولى للدوال الجبرية';
          q = `إذا كانت الدالة $f(x) = ${c}x^{${p}} - ${subConst}x + 8$، فإن قيمة المشتقة الأولى عند $x = 1$ هي $f'(1) = $`;
          ans = `$${valAtOne}$`;
          w1 = `$${valAtOne + 4}$`;
          w2 = `$${valAtOne - 3}$`;
          w3 = `$${dCoeff}$`;
          expl = `مشتقة الدالة: $f'(x) = ${dCoeff}x^{${p - 1}} - ${subConst}$. بالتعويض عن $x = 1$: $f'(1) = ${dCoeff}(1) - ${subConst} = ${valAtOne}$.`;
          rule = '$\\frac{d}{dx}[a x^n] = n \\cdot a x^{n-1}$';
        } else if (sub === 2) {
          // الأعداد المركبة ومبرهنة ديموافر
          const exp = [4, 8, 12, 16][i % 4];
          const resultVal = Math.pow(2, exp / 2) * (exp % 8 === 0 ? 1 : -1);
          topic = 'الجبر: الأعداد المركبة ونظرية ديموافر';
          q = `باستخدام مبرهنة ديموافر للأعداد المركبة، قيمة المقدار $(1 + i)^{${exp}}$ في أبسط صورة تساوي:`;
          ans = `$${resultVal}$`;
          w1 = `$${resultVal} i$`;
          w2 = `$${-resultVal}$`;
          w3 = `$0$`;
          expl = `نحول العدد إلى الصورة القطبية: $r = \\sqrt{1^2+1^2} = \\sqrt{2}$، والسعة $\\theta = \\frac{\\pi}{4}$. بتطبيق ديموافر: $z^{${exp}} = (\\sqrt{2})^{${exp}} [\\cos(${exp}\\pi/4) + i\\sin(${exp}\\pi/4)] = ${resultVal}$.`;
          rule = '$z^n = r^n [\\cos(n\\theta) + i\\sin(n\\theta)]$';
        } else if (sub === 3) {
          // التكامل المحدد
          const k = (i % 4) + 1;
          const upper = 2;
          // \int_0^2 (2k x + 1) dx = [k x^2 + x]_0^2 = 4k + 2
          const integralVal = 4 * k + 2;
          topic = 'التكامل: حساب التكاملات المحددة والمساحات';
          q = `أوجد قيمة التكامل المحدد: $\\int_{0}^{${upper}} (${2 * k}x + 1) \\, dx$`;
          ans = `$${integralVal}$`;
          w1 = `$${integralVal + 5}$`;
          w2 = `$${integralVal - 3}$`;
          w3 = `$${2 * k * upper}$`;
          expl = `الدالة الأصلية: $F(x) = ${k}x^2 + x$. بالتعويض بحدود التكامل: $F(${upper}) - F(0) = (${k} \\times 4 + 2) - 0 = ${integralVal}$.`;
          rule = '$\\int_a^b f(x) dx = F(b) - F(a)$';
        } else if (sub === 4) {
          // المصفوفات والمحددات
          const m1 = (i % 4) + 2;
          const m2 = ((i + 1) % 3) + 1;
          const det = m1 * 4 - m2 * 3;
          topic = 'الجبر: المحددات والخواص الجبرية للمصفوفات';
          q = `احسب قيمة محدد الرتبة الثانية: $\\begin{vmatrix} ${m1} & ${m2} \\\\ 3 & 4 \\end{vmatrix}$`;
          ans = `$${det}$`;
          w1 = `$${det + 5}$`;
          w2 = `$${det - 4}$`;
          w3 = `$${m1 * 4 + m2 * 3}$`;
          expl = `قيمة محدد الرتبة الثانية = حاصل ضرب عناصر القطر الرئيسي مطروحاً منه حاصل ضرب عناصر القطر الثانوي: $(${m1} \\times 4) - (${m2} \\times 3) = ${det}$.`;
          rule = '$\\begin{vmatrix} a & b \\\\ c & d \\end{vmatrix} = ad - bc$';
        } else {
          // التباديل والتوافيق
          const n = (i % 3) + 5;
          const r = 2;
          const perm = n * (n - 1);
          const comb = perm / 2;
          topic = 'الجبر: مبدأ العد الأساسي والتباديل والتوافيق';
          q = `احسب قيمة التوافيق الوزارية: $C(${n}, ${r}) = \\binom{${n}}{${r}}$`;
          ans = `$${comb}$`;
          w1 = `$${perm}$`;
          w2 = `$${comb + 4}$`;
          w3 = `$${n + r}$`;
          expl = `قانون التوافيق: $\\binom{n}{r} = \\frac{n!}{r!(n-r)!} = \\frac{${n} \\times ${n - 1}}{2 \\times 1} = ${comb}$.`;
          rule = '$\\binom{n}{r} = \\frac{n!}{r!(n-r)!}$';
        }

        if (seenQuestionTexts.has(q)) continue;
        seenQuestionTexts.add(q);

        const { shuffled, correctIndex } = shuffleOptions([ans, w1, w2, w3], i + 43);
        const diff: DifficultyLevel = i % 3 === 0 ? 'easy' : i % 3 === 1 ? 'medium' : 'hard';

        generated.push({
          id: `gen_ye_mat_${Date.now()}_${i}_${Math.floor(Math.random() * 10000)}`,
          section: 'ministerial',
          stage: stage || 'ثالث ثانوي علمي',
          subject: subject,
          unitOrTopic: topic,
          year: `وزاري نماذج معتمدة ${2020 + (i % 5)}`,
          difficulty: diff,
          type: 'mcq',
          question: q,
          options: shuffled,
          correctAnswer: correctIndex,
          explanation: expl,
          formulaOrRule: rule,
          tags: ['رياضيات وزارية', 'تفاضل وتكامل', 'جبر', 'أعداد مركبة'],
        });
      }
    }

    // =============================================================
    // 4. الفيزياء (Physics - AC Circuits, Electronics, Optics, Photons)
    // =============================================================
    else if (isPhysics) {
      for (let i = 0; i < targetCount; i++) {
        const sub = i % 5;
        let q = '';
        let ans = '';
        let w1 = '';
        let w2 = '';
        let w3 = '';
        let expl = '';
        let rule = '';
        let topic = '';

        if (sub === 0) {
          // دوائر الرنين
          const L = Number(((i % 5 + 1) * 0.1).toFixed(1));
          const C = (i % 4 + 1) * 10;
          const cFarad = C * 1e-6;
          const f0 = Math.round(1 / (2 * Math.PI * Math.sqrt(L * cFarad)));
          topic = 'دوائر التيار المتردد والرنين الكهربائي';
          q = `دائرة رنين في جهاز استقبال لاسلكي تتكون من ملف حث معامل حثه الذاتي $L = ${L}\\text{ H}$ ومكثف سعته $C = ${C}\\ \\mu\\text{F}$. التردد الرنيني $f_0$ للدائرة يساوي تقريباً:`;
          ans = `$${f0}\\text{ Hz}$`;
          w1 = `$${Math.round(f0 * 1.5)}\\text{ Hz}$`;
          w2 = `$${Math.round(f0 * 0.6)}\\text{ Hz}$`;
          w3 = `$${Math.round(f0 * 2.2)}\\text{ Hz}$`;
          expl = `قانون التردد الرنيني: $f_0 = \\frac{1}{2\\pi \\sqrt{LC}}$. بالتعويض: $f_0 = \\frac{1}{2\\pi\\sqrt{${L} \\times ${C}\\times 10^{-6}}} \\approx ${f0}\\text{ Hz}$.`;
          rule = '$f_0 = \\frac{1}{2\\pi \\sqrt{L C}}$';
        } else if (sub === 1) {
          // المحول الكهربائي
          const Np = (i % 5 + 2) * 100;
          const Ns = (i % 3 + 1) * 50;
          const Vp = 220;
          const Vs = Math.round((Vp * Ns) / Np);
          topic = 'المحول الكهربائي والحث الكهرومغناطيسي';
          q = `محول كهربائي مثالي خافض للجهد، عدد لفات ملفه الابتدائي $N_p = ${Np}\\text{ لفة}$ والثانوي $N_s = ${Ns}\\text{ لفة}$. إذا وُصل الابتدائي بجهد متردد $V_p = ${Vp}\\text{ V}$، فإن جهد الثانوي $V_s$ يساوي:`;
          ans = `$${Vs}\\text{ V}$`;
          w1 = `$${Math.round(Vs * 1.8)}\\text{ V}$`;
          w2 = `$${Math.round(Vs * 0.5)}\\text{ V}$`;
          w3 = `$${Vs + 35}\\text{ V}$`;
          expl = `معادلة المحول المثالي: $\\frac{V_s}{V_p} = \\frac{N_s}{N_p} \\implies V_s = V_p \\cdot \\frac{N_s}{N_p} = ${Vp} \\times \\frac{${Ns}}{${Np}} = ${Vs}\\text{ V}$.`;
          rule = '$\\frac{V_s}{V_p} = \\frac{N_s}{N_p} = \\frac{I_p}{I_s}$';
        } else if (sub === 2) {
          // الظاهرة الكهروضوئية
          const fRatio = (i % 4) + 2;
          topic = 'الفيزياء الحديثة: الظاهرة الكهروضوئية وفرضية أينشتاين';
          q = `إذا سقط ضوء تردده $f$ يساوي ${fRatio} أضعاف تردد العتبة $f_0$ لسطح فلز معين ($f = ${fRatio} f_0$)، فإن أقصى طاقة حركة للإلكترونات الضوئية المنبعثة $KE_{max}$ تساوي:`;
          ans = `$${fRatio - 1} h f_0$`;
          w1 = `$${fRatio} h f_0$`;
          w2 = `$${fRatio + 1} h f_0$`;
          w3 = `$\\frac{1}{${fRatio}} h f_0$`;
          expl = `من معادلة أينشتاين للظاهرة الكهروضوئية: $E = W_0 + KE_{max} \\implies KE_{max} = hf - hf_0 = h(${fRatio} f_0) - hf_0 = (${fRatio - 1}) h f_0$.`;
          rule = '$KE_{max} = h f - W_0 = h (f - f_0)$';
        } else if (sub === 3) {
          // المعاوقة الكلية في دائرة RLC
          const R = (i % 4 + 1) * 10;
          const XL = (i % 5 + 3) * 10;
          const XC = (i % 3 + 1) * 10;
          const diffX = XL - XC;
          const Z = Math.round(Math.sqrt(R * R + diffX * diffX));
          topic = 'دوائر التيار المتردد: حساب المعاوقة الكلية Z في دائرة RLC';
          q = `في دائرة تيار متردد موصلة على التوالي، المقاومة الأومية $R = ${R}\\ \\Omega$، والمفاعلة الحثية $X_L = ${XL}\\ \\Omega$، والمفاعلة السعوية $X_C = ${XC}\\ \\Omega$. المعاوقة الكلية $Z$ للدائرة تساوي:`;
          ans = `$${Z}\\ \\Omega$`;
          w1 = `$${R + XL + XC}\\ \\Omega$`;
          w2 = `$${Math.abs(XL - XC)}\\ \\Omega$`;
          w3 = `$${Z + 15}\\ \\Omega$`;
          expl = `تحسب المعاوقة الكلية في دوائر التوالي بالعلاقة: $Z = \\sqrt{R^2 + (X_L - X_C)^2} = \\sqrt{${R}^2 + (${XL} - ${XC})^2} = \\sqrt{${R * R} + ${diffX * diffX}} \\approx ${Z}\\ \\Omega$.`;
          rule = '$Z = \\sqrt{R^2 + (X_L - X_C)^2}$';
        } else {
          // حركة المقذوفات
          const v0 = (i % 4 + 2) * 10;
          const hMax = Math.round((v0 * v0 * 0.25) / (2 * 9.8));
          topic = 'الميكانيكا الوزارية: حركة المقذوفات في مجال الجاذبية';
          q = `قُذفت قذيفة بسرعة ابتدائية $v_0 = ${v0}\\text{ m/s}$ وبزاوية ميل $\\theta = 30^\\circ$ مع الأفق ($g = 9.8\\text{ m/s}^2$). أقصى ارتفاع رأسي $H$ تبلغه القذيفة يساوي تقريباً:`;
          ans = `$${hMax}\\text{ m}$`;
          w1 = `$${hMax * 2}\\text{ m}$`;
          w2 = `$${Math.round(hMax * 0.5)}\\text{ m}$`;
          w3 = `$${hMax + 20}\\text{ m}$`;
          expl = `أقصى ارتفاع رأسي: $H = \\frac{v_0^2 \\sin^2\\theta}{2g}$. بالتعويض: $H = \\frac{${v0}^2 \\times (0.5)^2}{2 \\times 9.8} \\approx ${hMax}\\text{ m}$.`;
          rule = '$H = \\frac{v_0^2 \\sin^2\\theta}{2g}$';
        }

        if (seenQuestionTexts.has(q)) continue;
        seenQuestionTexts.add(q);

        const { shuffled, correctIndex } = shuffleOptions([ans, w1, w2, w3], i + 57);
        const diff: DifficultyLevel = i % 3 === 0 ? 'easy' : i % 3 === 1 ? 'medium' : 'hard';

        generated.push({
          id: `gen_ye_phy_${Date.now()}_${i}_${Math.floor(Math.random() * 10000)}`,
          section: 'ministerial',
          stage: stage || 'ثالث ثانوي علمي',
          subject: subject,
          unitOrTopic: topic,
          year: `وزاري نماذج معتمدة ${2020 + (i % 5)}`,
          difficulty: diff,
          type: 'mcq',
          question: q,
          options: shuffled,
          correctAnswer: correctIndex,
          explanation: expl,
          formulaOrRule: rule,
          tags: ['فيزياء وزارية', 'تيار متردد', 'رنين', 'كهرومغناطيسية'],
        });
      }
    }

    // =============================================================
    // 5. الكيمياء (Chemistry - Equilibrium, pH, Electrochemistry, Organic)
    // =============================================================
    else if (isChem) {
      for (let i = 0; i < targetCount; i++) {
        const sub = i % 4;
        let q = '';
        let ans = '';
        let w1 = '';
        let w2 = '';
        let w3 = '';
        let expl = '';
        let rule = '';
        let topic = '';

        if (sub === 0) {
          // الاتزان ومبدأ لوشاتيليه
          topic = 'الاتزان الكيميائي ومبدأ لوشاتيليه';
          q = 'في التفاعل الغازي المتزن الطارد للحرارة: $\\ce{N2(g) + 3H2(g) <=> 2NH3(g) + Heat}$، ما هو الإجراء الذي يزيد من إنتاج غاز النشادر (الأمونيا)؟';
          ans = 'زيادة الضغط الكلي وخفض درجة حرارة وعاء التفاعل';
          w1 = 'خفض الضغط ورفع درجة الحرارة';
          w2 = 'إضافة عامل حفاز مع رفع الحرارة';
          w3 = 'سحب غاز النيتروجين باستمرار من الوعاء';
          expl = 'وفق مبدأ لوشاتيليه: التفاعل طارد للحرارة لذلك خفض الحرارة يزيحه نحو اليمين. وعدد مولات الغاز في المتفاعلات (4) أكبر من النواتج (2)، فزيادة الضغط تزيحه نحو الطرف الأقل مولات (اليمين).';
          rule = 'مبدأ لوشاتيليه: النظام المتزن يقاوم أي مؤثر خارجي بالانزياح في الاتجاه المعاكس';
        } else if (sub === 1) {
          // الرقم الهيدروجيني pH
          const hExp = (i % 5) + 2;
          topic = 'الأحماض والقواعد وحساب الرقم الهيدروجيني pH';
          q = `محلول مائي لحمض قوي تركيز أيون الهيدرونيوم فيه $[\\ce{H3O+}] = 1.0 \\times 10^{-${hExp}}\\,\\text{M}$. قيمة الرقم الهيدروجيني $\\text{pH}$ للمحلول تساوي:`;
          ans = `$${hExp}$`;
          w1 = `$${14 - hExp}$`;
          w2 = `$${hExp - 1}$`;
          w3 = `$10^{-${hExp}}$`;
          expl = `الرقم الهيدروجيني: $\\text{pH} = -\\log_{10}[\\ce{H3O+}] = -\\log_{10}(10^{-${hExp}}) = ${hExp}$. وبما أن $\\text{pH} < 7$ فإن الوسط حمضي.`;
          rule = '$\\text{pH} = -\\log_{10}[\\ce{H3O+}]$';
        } else if (sub === 2) {
          // الكيمياء الكهربائية وجهد الخلية
          const eCath = 0.80;
          const eAnode = -0.76;
          const eCell = (eCath - eAnode).toFixed(2);
          topic = 'الكيمياء الكهربائية وحساب القوة الدافعة الكهربائية القياسية E°cell';
          q = `في خلية جلفانية مكونة من قطب الخارصين ($E^\\circ_{\\ce{Zn^{2+}/Zn}} = -0.76\\text{ V}$) وقطب الفضة ($E^\\circ_{\\ce{Ag^{+}/Ag}} = +0.80\\text{ V}$)، جهد الخلية القياسي $E^\\circ_{cell}$ يساوي:`;
          ans = `$${eCell}\\text{ V}$ (تفاعل تلقائي)`;
          w1 = `$0.04\\text{ V}$`;
          w2 = `$-1.56\\text{ V}$`;
          w3 = `$-0.04\\text{ V}$`;
          expl = `الكاثود هو الفضة (الأعلى جهد اختزال) والأنود هو الخارصين (الأقل جهد اختزال): $E^\\circ_{cell} = E^\\circ_{cathode} - E^\\circ_{anode} = 0.80 - (-0.76) = +1.56\\text{ V}$. وبما أنه موجب فالتفاعل تلقائي.`;
          rule = '$E^\\circ_{cell} = E^\\circ_{cathode} - E^\\circ_{anode}$';
        } else {
          // الكيمياء العضوية
          topic = 'الكيمياء العضوية: التسمية والتفاعلات الوظيفية';
          q = 'التفاعل الكيميائي الذي ينتج إستراً وماءً عند تفاعل حمض كربوكسيلي مع كحول في وسط حمضي يُعرف بتفاعل:';
          ans = 'الأسترة (Esterification)';
          w1 = 'التصبن (Saponification)';
          w2 = 'البلمرة الإضافية';
          w3 = 'التحلل المائي القلوي';
          expl = 'تفاعل الأسترة هو اتحاد الحمض الكربوكسيلي والكحول بوجود حمض الكبريتيك المركز كعامل نازع للماء لإنتاج الإستر ذي الرائحة العطرية المميزة.';
          rule = '$\\ce{R-COOH + R\'-OH <=>[\\ce{H+}] R-COO-R\' + H2O}$';
        }

        if (seenQuestionTexts.has(q)) continue;
        seenQuestionTexts.add(q);

        const { shuffled, correctIndex } = shuffleOptions([ans, w1, w2, w3], i + 71);
        const diff: DifficultyLevel = i % 2 === 0 ? 'medium' : 'hard';

        generated.push({
          id: `gen_ye_chem_${Date.now()}_${i}_${Math.floor(Math.random() * 10000)}`,
          section: 'ministerial',
          stage: stage || 'ثالث ثانوي علمي',
          subject: subject,
          unitOrTopic: topic,
          year: `وزاري نماذج معتمدة ${2020 + (i % 5)}`,
          difficulty: diff,
          type: 'mcq',
          question: q,
          options: shuffled,
          correctAnswer: correctIndex,
          explanation: expl,
          formulaOrRule: rule,
          tags: ['كيمياء وزارية', 'اتزان', 'محاليل', 'عضوية'],
        });
      }
    }

    // =============================================================
    // 6. الأحياء (Biology - Genetics, Immunology, Nervous System)
    // =============================================================
    else if (isBio) {
      for (let i = 0; i < targetCount; i++) {
        const sub = i % 4;
        let q = '';
        let ans = '';
        let w1 = '';
        let w2 = '';
        let w3 = '';
        let expl = '';
        let rule = '';
        let topic = '';

        if (sub === 0) {
          const aPercent = 15 + (i % 15);
          const cPercent = (100 - 2 * aPercent) / 2;
          topic = 'الوراثة الجزيئية: تركيب حمض DNA وقواعد تشارجاف';
          q = `في عينة نقية من جزيء $\\text{DNA}$ ثنائي السلسلة، إذا بلغت نسبة الأدينين $\\text{A} = ${aPercent}\\%$، فإن النسبة المئوية للسايتوسين $\\text{C}$ تساوي:`;
          ans = `$${cPercent}\\%$`;
          w1 = `$${aPercent}\\%$`;
          w2 = `$${100 - aPercent}\\%$`;
          w3 = `$${aPercent / 2}\\%$`;
          expl = `وفق قواعد تشارجاف: نسبة الأدينين تساوي الثايمين ($A = T = ${aPercent}\\%$) ومجموعهما $2 \\times ${aPercent}\\% = ${2 * aPercent}\\%$. النسبة المتبقية وهي $100\\% - ${2 * aPercent}\\% = ${100 - 2 * aPercent}\\%$ موزعة بالتساوي بين الجوانين والسايتوسين: $G = C = ${cPercent}\\%$.`;
          rule = '$[A] = [T] \\quad , \\quad [G] = [C] \\quad , \\quad [A]+[T]+[G]+[C] = 100\\%$';
        } else if (sub === 1) {
          topic = 'الوراثة البشرية: فصائل الدم ABO والسيادة المشتركة';
          q = 'إذا تزوج رجل فصيلة دمه AB من امرأة فصيلة دمها O، فما هي فصائل الدم المحتملة لأبنائهما؟';
          ans = 'الفصيلة A والفصيلة B بنسبة 50% لكل منهما (ولا يمكن إنجاب O أو AB)';
          w1 = 'جميع الأبناء يحملون الفصيلة O بنسبة 100%';
          w2 = 'الفصائل الأربع A, B, AB, O بنسب متساوية 25%';
          w3 = 'الفصيلة AB فقط';
          expl = 'الطراز الجيني للأب هو $I^A I^B$ وللأم هو $ii$. عند التزاوج: 50% من الأبناء $I^A i$ (فصيلة A)، و 50% $I^B i$ (فصيلة B). يستحيل ظهور فصيلة O أو AB من هذا التزاوج.';
          rule = 'نظام فصائل الدم ABO يمثل مثالاً على السيادة التامة والمشتركة والأليلات المتعددة';
        } else if (sub === 2) {
          topic = 'الفسيولوجيا وعلم وظائف الأعضاء: جهد الفعل والمشابك العصبية';
          q = 'في أثناء إزالة الاستقطاب (Depolarization) في الخلية العصبية عند وصول منبه فعال، تحدث حركة الأيونات عبر الغشاء الخلوي كالآتي:';
          ans = 'تدفق سريع ومكثف لأيونات الصوديوم (Na+) إلى داخل الخلية عبر قنوات الصوديوم المبوبة بالجهد';
          w1 = 'خروج سريع لأيونات البوتاسيوم (K+) إلى خارج الخلية';
          w2 = 'توقف مضخة الصوديوم والبوتاسيوم بشكل دائم';
          w3 = 'دخول أيونات الكلوريد السالبة لمعادلة الشحنة';
          expl = 'عند إثارة العصبون تفتح قنوات $Na^+$ الحساسة لفرق الجهد، فيتدفق الصوديوم للداخل بسرعة مع منحدر تركيزه وشحنته، فيتحول الجهد الغشائي من $-70\\text{ mV}$ إلى $+30\\text{ mV}$.';
          rule = 'جهد الراحة (-70 mV) يتحول لجهد الفعل (+30 mV) بدخول أيونات الصوديوم Na+';
        } else {
          topic = 'جهاز المناعة البشري: الخلايا البائية والأجسام المضادة';
          q = 'الخلايا اللمفاوية المسؤولة عن المناعة الخلطية (Humoral Immunity) وإفراز الأجسام المضادة المتخصصة في الدم هي:';
          ans = 'الخلايا البائية البلازمية (Plasma B-cells)';
          w1 = 'الخلايا التائية القاتلة (Cytotoxic T-cells)';
          w2 = 'الخلايا البلعمية الكبيرة بمفردها';
          w3 = 'خلايا الدم الحمراء';
          expl = 'عند تعرف الخلايا البائية B-cells على مولد الضد وتنشيطها بالخلايا التائية المساعدة، تتمايز إلى خلايا بلازمية تُفرز آلاف الأجسام المضادة في الثانية.';
          rule = 'المناعة الخلطية تتوسطها الأجسام المضادة المفرزة من الخلايا البلازمية B-cells';
        }

        if (seenQuestionTexts.has(q)) continue;
        seenQuestionTexts.add(q);

        const { shuffled, correctIndex } = shuffleOptions([ans, w1, w2, w3], i + 89);
        const diff: DifficultyLevel = i % 2 === 0 ? 'medium' : 'hard';

        generated.push({
          id: `gen_ye_bio_${Date.now()}_${i}_${Math.floor(Math.random() * 10000)}`,
          section: 'ministerial',
          stage: stage || 'ثالث ثانوي علمي',
          subject: subject,
          unitOrTopic: topic,
          year: `وزاري نماذج معتمدة ${2020 + (i % 5)}`,
          difficulty: diff,
          type: 'mcq',
          question: q,
          options: shuffled,
          correctAnswer: correctIndex,
          explanation: expl,
          formulaOrRule: rule,
          tags: ['أحياء وزارية', 'وراثة جزيئية', 'DNA', 'مناعة'],
        });
      }
    }

    // =============================================================
    // 7. العلوم (الصف التاسع الأساسي)
    // =============================================================
    else if (isScienceG9) {
      for (let i = 0; i < targetCount; i++) {
        const sub = i % 4;
        let q = '';
        let ans = '';
        let w1 = '';
        let w2 = '';
        let w3 = '';
        let expl = '';
        let rule = '';
        let topic = '';

        if (sub === 0) {
          const v = (i % 5 + 1) * 6;
          const r = (i % 3 + 1) * 2;
          const cur = v / r;
          topic = 'فيزياء تاسع: قانون أوم والمقاومة الكهربائية';
          q = `في دائرة كهربائية بسيطة، إذا كان فرق الجهد $V = ${v}\\text{ V}$ وقيمة المقاومة $R = ${r}\\ \\Omega$، فإن شدة التيار $I$ تساوي:`;
          ans = `$I = ${cur}\\text{ A}$`;
          w1 = `$I = ${cur * 2}\\text{ A}$`;
          w2 = `$I = ${Math.max(1, cur - 2)}\\text{ A}$`;
          w3 = `$I = ${v * r}\\text{ A}$`;
          expl = `قانون أوم: $I = \\frac{V}{R} = \\frac{${v}}{${r}} = ${cur}\\text{ A}$.`;
          rule = '$V = I \\cdot R \\iff I = \\frac{V}{R}$';
        } else if (sub === 1) {
          topic = 'أحياء تاسع: انقسام الخلية الميتوزي والميوزي';
          q = 'الانقسام الخلوي الذي يحدث في الخلايا الجنسية لإنتاج الأمشاج ويختزل عدد الكروموسومات إلى النصف (n) هو:';
          ans = 'الانقسام الاختزالي (الميوزي Meiosis)';
          w1 = 'الانقسام المتساوي (الميتوزي Mitosis)';
          w2 = 'الانشطار الثنائي البسيط';
          w3 = 'التبرعم الخلوي';
          expl = 'الانقسام الميوزي يحدث في المناسل لإنتاج الحيوانات المنوية والبويضات ويختزل الصبغيات من 2n إلى n.';
          rule = 'الانقسام الاختزالي يختزل المادة الوراثية إلى النصف';
        } else if (sub === 2) {
          topic = 'كيمياء تاسع: الروابط الكيميائية والجدول الدوري';
          q = 'الرابطة الكيميائية التي تنشأ بين فلز ولا فلز نتيجة انتقال كامل للإلكترونات وتكوين أيونات موجبة وسالبة هي:';
          ans = 'الرابطة الأيونية (Ionic Bond)';
          w1 = 'الرابطة التساهمية النقية';
          w2 = 'الرابطة الهيدروجينية';
          w3 = 'الرابطة الفلزية';
          expl = 'الرابطة الأيونية تنشأ بين ذرة تفقد إلكترونات (فلز كالصوديوم) وأخرى تكتسبها (لافلز كالكلور) ليتكون مركب أيوني مثل NaCl.';
          rule = 'الرابطة الأيونية: تجاذب إلكتروستاتيكي بين أيون موجب وأيون سالب';
        } else {
          topic = 'علوم الأرض تاسع: طبقات الأرض والدورة المائية';
          q = 'أعمق وأكثر طبقات كوكب الأرض حرارة وكثافة وتتكون أساساً من الحديد والنيكل المصهور والصلب هي:';
          ans = 'لب الأرض (Core) بنوعيه الداخلي والخارجي';
          w1 = 'القشرة الأرضية القارية';
          w2 = 'الوشاح العلوي (الستار)';
          w3 = 'الغلاف الصخري';
          expl = 'لب الأرض ينقسم إلى لب خارجي مصهور ولب داخلي صلب تحت ضغط هائل ويتكون من عنصري النيكل والحديد (Ni-Fe).';
          rule = 'طبقات الأرض: القشرة، الوشاح، اللب الخارجي، اللب الداخلي';
        }

        if (seenQuestionTexts.has(q)) continue;
        seenQuestionTexts.add(q);

        const { shuffled, correctIndex } = shuffleOptions([ans, w1, w2, w3], i + 97);
        generated.push({
          id: `gen_ye_sci_${Date.now()}_${i}_${Math.floor(Math.random() * 10000)}`,
          section: 'ministerial',
          stage: 'تاسع أساسي',
          subject: subject,
          unitOrTopic: topic,
          year: `وزاري نماذج معتمدة ${2021 + (i % 4)}`,
          difficulty: 'easy',
          type: 'mcq',
          question: q,
          options: shuffled,
          correctAnswer: correctIndex,
          explanation: expl,
          formulaOrRule: rule,
          tags: ['علوم تاسع', 'منهج يمني أساسي'],
        });
      }
    }

    // =============================================================
    // 8. الاجتماعيات (الصف التاسع الأساسي)
    // =============================================================
    else if (isSocialG9) {
      const socialItems = [
        { q: 'أعظم المعالم الهندسية المائية والريية التي أقامها السبئيون القدماء بين جبلي البلق في مأرب هو:', ans: 'سد مأرب العظيم', w1: 'سد أسوان', w2: 'قناطر بابل', w3: 'سد النهضة', expl: 'سد مأرب التاريخي شيده السبئيون القدماء لتحويل مياه سيول وادي أذنة إلى جنات زراعية عريضة.' },
        { q: 'يمتد السهل الساحلي الغربي في الجمهورية اليمنية بمحاذاة البحر الأحمر ويُعرف جغرافياً بـ:', ans: 'سهل تهامة الزراعي', w1: 'سهل أبين', w2: 'سهل تبن', w3: 'سهل ردفان', expl: 'سهل تهامة يمتد من ميدي شمالاً حتى باب المندب جنوباً وتخترقه أودية زبيد وسردد ومور.' },
        { q: 'تنص المادة الثالثة من دستور الجمهورية اليمنية صراحة على أن:', ans: 'الشريعة الإسلامية مصدر جميع التشريعات والقوانين', w1: 'الشريعة مصدر فرعي فقط', w2: 'القوانين الوضعية هي الأساس', w3: 'الشريعة خاصة بالأحوال الشخصية فقط', expl: 'الدستور اليمني ينص على أن الشريعة الإسلامية هي المصدر الرئيس والوحيد لجميع التشريعات.' },
        { q: 'اتخذ ملوك حمير قديماً مدينة ظفار عاصمة لهم، وتقع أطلالها حالياً في محافظة:', ans: 'محافظة إب (مديرية يريم)', w1: 'محافظة حضرموت', w2: 'محافظة شبوة', w3: 'محافظة الحديدة', expl: 'كانت ظفار يريم عاصمة الدولة الحميرية الموحدة لقرون طويلة واشتهرت بقصورها ونقوشها المسندية.' }
      ];

      for (let i = 0; i < targetCount; i++) {
        const item = socialItems[i % socialItems.length];
        if (seenQuestionTexts.has(item.q)) continue;
        seenQuestionTexts.add(item.q);

        const { shuffled, correctIndex } = shuffleOptions([item.ans, item.w1, item.w2, item.w3], i + 109);
        generated.push({
          id: `gen_ye_soc_${Date.now()}_${i}_${Math.floor(Math.random() * 10000)}`,
          section: 'ministerial',
          stage: 'تاسع أساسي',
          subject: subject,
          unitOrTopic: 'تاريخ اليمن وجغرافيته والتربية الوطنية',
          year: `وزاري نماذج معتمدة ${2021 + (i % 4)}`,
          difficulty: 'medium',
          type: 'mcq',
          question: item.q,
          options: shuffled,
          correctAnswer: correctIndex,
          explanation: item.expl,
          tags: ['اجتماعيات تاسع', 'تاريخ اليمن', 'جغرافيا'],
        });
      }
    }

    // =============================================================
    // 9. التاريخ الحديث (ثالث ثانوي أدبي)
    // =============================================================
    else if (isHistoryLit) {
      const histItems = [
        { q: 'انطلقت شرارة ثورة 14 أكتوبر 1963م التحررية ضد الاستعمار البريطاني في جنوب اليمن من جبال:', ans: 'جبال ردفان الأبية بقيادة الشهيد راجح بن غالب لبوزة', w1: 'جبال عيبان بصنعاء', w2: 'جبال سمارة بإب', w3: 'جبال صعدة', expl: 'قاد راجح بن غالب لبوزة انطلاقة ثورة 14 أكتوبر من قمم ردفان وتوجت بجلاء آخر جندي بريطاني في 30 نوفمبر 1967م.' },
        { q: 'اندلعت ثورة 26 سبتمبر 1962م الخالدة في شمال اليمن للإطاحة بالنظام:', ans: 'النظام الإمامي الملكي المتوكل الرجعي وإعلان الجمهورية', w1: 'الاستعمار الهولندي', w2: 'الانتداب الفرنسي', w3: 'الوصاية الإيطالية', expl: 'أطاحت ثورة 26 سبتمبر بحكم الأئمة الرجعي وأرست مبادئ النظام الجمهوري التحرري والمساواة.' },
        { q: 'الثورة التحررية العربية التي قدمت أكثر من مليون ونصف مليون شهيد ونالت استقلالها عن الاستعمار الفرنسي عام 1962م هي:', ans: 'ثورة الجزائر المجيدة (ثورة الأول من نوفمبر 1954)', w1: 'ثورة العشرين بالعراق', w2: 'ثورة الريف بالمغرب', w3: 'ثورة 1919 بمصر', expl: 'ثورة التحرير الجزائرية دامت 8 سنوات وقدمت تضحيات جسيمة حتى دحرت الاستعمار الفرنسي الاستيطاني.' },
        { q: 'مؤتمر خمر التاريخي عام 1965م في اليمن عُقد بهدف:', ans: 'توحيد الصف الوطني الجمهوري وإنهاء الاقتتال ودعم السلام والاستقرار', w1: 'إعلان الوحدة مع مصر', w2: 'تقسيم المناطق', w3: 'تأسيس الأحزاب' }
      ];

      for (let i = 0; i < targetCount; i++) {
        const item = histItems[i % histItems.length];
        if (seenQuestionTexts.has(item.q)) continue;
        seenQuestionTexts.add(item.q);

        const { shuffled, correctIndex } = shuffleOptions([item.ans, item.w1, item.w2, item.w3], i + 127);
        generated.push({
          id: `gen_ye_his_${Date.now()}_${i}_${Math.floor(Math.random() * 10000)}`,
          section: 'ministerial',
          stage: 'ثالث ثانوي أدبي',
          subject: subject,
          unitOrTopic: 'تاريخ اليمن الحديث وحركات التحرر العربي',
          year: `وزاري نماذج معتمدة ${2020 + (i % 5)}`,
          difficulty: 'medium',
          type: 'mcq',
          question: item.q,
          options: shuffled,
          correctAnswer: correctIndex,
          explanation: item.expl || 'تاريخ اليمن المعاصر والثورات التحررية.',
          tags: ['تاريخ حديث', 'ثورة سبتمبر وأكتوبر'],
        });
      }
    }

    // =============================================================
    // 10. الجغرافيا (ثالث ثانوي أدبي)
    // =============================================================
    else if (isGeographyLit) {
      const geoItems = [
        { q: 'أهم حوض رسوبي نفطي منتج ومصدر لمشروع تصدير الغاز الطبيعي المسال (LNG) في اليمن هو:', ans: 'حوض مأرب - الجوف الرسوبي (القطاع 18)', w1: 'حوض تهامة الساحلي', w2: 'حوض صعدة البركاني', w3: 'حوض المهرة', expl: 'حوض مأرب الجوف هو ركيزة الإنتاج الهيدروكربوني وينقل الغاز بأنبوب إلى ميناء بلحاف على بحر العرب.' },
        { q: 'المضيق المائي الاستراتيجي الذي تشرف عليه اليمن ويتحكم في حركة الملاحة بين البحر الأحمر والمحيط الهندي هو:', ans: 'مضيق باب المندب الاستراتيجي', w1: 'مضيق هرمز', w2: 'مضيق جبل طارق', w3: 'مضيق البوسفور', expl: 'باب المندب هو أحد أهم الشرايين الملاحية والتجارية العالمية التي تعبر منها ناقلات النفط وتجارة الشرق والغرب.' },
        { q: 'أعلى قمة جبلية في شبه الجزيرة العربية وبلاد الشام هي قمة جبل النبي شعيب في اليمن ويبلغ ارتفاعها قرابة:', ans: '3666 متراً فوق مستوى سطح البحر', w1: '2500 متراً', w2: '4200 متراً', w3: '1800 متراً' }
      ];

      for (let i = 0; i < targetCount; i++) {
        const item = geoItems[i % geoItems.length];
        if (seenQuestionTexts.has(item.q)) continue;
        seenQuestionTexts.add(item.q);

        const { shuffled, correctIndex } = shuffleOptions([item.ans, item.w1, item.w2, item.w3], i + 139);
        generated.push({
          id: `gen_ye_geo_${Date.now()}_${i}_${Math.floor(Math.random() * 10000)}`,
          section: 'ministerial',
          stage: 'ثالث ثانوي أدبي',
          subject: subject,
          unitOrTopic: 'الجغرافيا الاقتصادية والجيوسياسية للجمهورية اليمنية',
          year: `وزاري نماذج معتمدة ${2020 + (i % 5)}`,
          difficulty: 'medium',
          type: 'mcq',
          question: item.q,
          options: shuffled,
          correctAnswer: correctIndex,
          explanation: item.expl || 'الجغرافيا الطبيعية والاقتصادية لليمن.',
          tags: ['جغرافيا ثانوية', 'اقتصاد وموارد'],
        });
      }
    }

    // =============================================================
    // 11. الفلسفة وعلم النفس (ثالث ثانوي أدبي)
    // =============================================================
    else if (isPhilosophyLit) {
      const philItems = [
        { q: 'في قواعد القياس الأرسطي الصوري، الشرط اللازم للحد الأوسط لكي ينتج القياس نتيجة صحيحة هو:', ans: 'أن يستغرق في إحدى المقدمتين على الأقل، وألا يظهر في النتيجة', w1: 'أن يظهر في النتيجة دائماً', w2: 'أن يكون سالباً في كلتا المقدمتين', w3: 'أن يكون جزئياً فقط', expl: 'الحد الأوسط يربط بين الحدين الأصغر والأكبر، فإن لم يستغرق مرة على الأقل بطل القياس ولا يذكر في النتيجة.' },
        { q: 'في علم النفس، العملية المعرفية التي تقوم بتفسير وتأويل المثيرات الحسية وإعطائها معنى ودلالة تُسمى:', ans: 'الإدراك الحسي (Perception)', w1: 'الإحساس الخام فقط', w2: 'الانعكاس الشرطي', w3: 'الكف الارتجاعي', expl: 'الإحساس هو استقبال المنبه، بينما الإدراك هو إعطاء المعنى وتفسير الإشارات في الدماغ.' },
        { q: 'مبدأ الهوية (الذاتية) في قوانين الفكر الأساسية عند أرسطو ينص رمزياً على أن:', ans: '«أ هو أ» (الشيء هو ذاته ولا يمكن أن يكون غيره)', w1: '«أ يمكن أن يكون لا-أ في آن واحد»', w2: '«الشيء إما أ أو لا-أ ولا ثالث بينهما» فقط', w3: '«لا شيء يأتي من العدم»' }
      ];

      for (let i = 0; i < targetCount; i++) {
        const item = philItems[i % philItems.length];
        if (seenQuestionTexts.has(item.q)) continue;
        seenQuestionTexts.add(item.q);

        const { shuffled, correctIndex } = shuffleOptions([item.ans, item.w1, item.w2, item.w3], i + 151);
        generated.push({
          id: `gen_ye_phi_${Date.now()}_${i}_${Math.floor(Math.random() * 10000)}`,
          section: 'ministerial',
          stage: 'ثالث ثانوي أدبي',
          subject: subject,
          unitOrTopic: 'المنطق الصوري الأرسطي وعلم النفس المعرفي',
          year: `وزاري نماذج معتمدة ${2020 + (i % 5)}`,
          difficulty: 'medium',
          type: 'mcq',
          question: item.q,
          options: shuffled,
          correctAnswer: correctIndex,
          explanation: item.expl || 'المنطق الصوري ومبادئ التفكير وعلم النفس.',
          tags: ['فلسفة ومنطق', 'علم نفس'],
        });
      }
    }

    // =============================================================
    // 12. اللغة الإنجليزية (English Language)
    // =============================================================
    else if (isEnglish) {
      const engItems = [
        { q: 'Choose the correct grammatical completion: «If students study hard, they _______ the ministerial examination.»', ans: 'will pass (First Conditional - Real possibility)', w1: 'would pass', w2: 'would have passed', w3: 'passes', expl: 'First Conditional: If + Present Simple -> will + Infinitive.' },
        { q: 'Identify the correct passive voice: «The teacher explained the lesson clearly yesterday.»', ans: 'The lesson was explained clearly by the teacher yesterday.', w1: 'The lesson is explained clearly yesterday.', w2: 'The lesson were explained clearly.', w3: 'The lesson has been explained clearly.', expl: 'Past Simple Passive: Subject + was/were + Past Participle (V3).' },
        { q: 'Complete with the appropriate modal verb: «You _______ stop when the traffic light turns red; it is the law.»', ans: 'must (Strict Obligation & Law)', w1: 'might', w2: 'should not', w3: 'could', expl: '«Must» expresses strict legal and mandatory obligations.' },
        { q: 'Choose the correct relative pronoun: «The surgeon _______ performed the open-heart surgery is internationally recognized.»', ans: 'who (referring to a person as subject)', w1: 'which', w2: 'where', w3: 'whose car' }
      ];

      for (let i = 0; i < targetCount; i++) {
        const item = engItems[i % engItems.length];
        if (seenQuestionTexts.has(item.q)) continue;
        seenQuestionTexts.add(item.q);

        const { shuffled, correctIndex } = shuffleOptions([item.ans, item.w1, item.w2, item.w3], i + 163);
        generated.push({
          id: `gen_ye_eng_${Date.now()}_${i}_${Math.floor(Math.random() * 10000)}`,
          section: 'ministerial',
          stage: stage || 'ثالث ثانوي علمي',
          subject: subject,
          unitOrTopic: 'English Grammar & Ministerial Examination Practice',
          year: `وزاري نماذج معتمدة ${2020 + (i % 5)}`,
          difficulty: 'medium',
          type: 'mcq',
          question: item.q,
          options: shuffled,
          correctAnswer: correctIndex,
          explanation: item.expl || 'English syntax and grammar for secondary examinations.',
          tags: ['English', 'Grammar', 'Secondary Exam'],
        });
      }
    }

    // Fallback if subject name does not match any branch
    else {
      for (let i = 0; i < targetCount; i++) {
        generated.push({
          id: `gen_ye_gen_${Date.now()}_${i}_${Math.floor(Math.random() * 10000)}`,
          section: 'ministerial',
          stage: stage || 'ثالث ثانوي علمي',
          subject: subject,
          unitOrTopic: `مفاهيم منهج ${subject}`,
          year: `وزاري 2024`,
          difficulty: 'medium',
          type: 'mcq',
          question: `سؤال تدريبي معتمد #${i + 1} في مقرر ${subject}: حدد العبارة الصحيحة علمياً ومنهجياً من بين الخيارات التالية:`,
          options: [
            `العبارة النموذجية المعتمدة في منهج ${subject}`,
            'تطبيق غير دقيق للقاعدة العلمية',
            'خلط بين المفاهيم المتباينة',
            'تعميم خاطئ بلا دليل'
          ],
          correctAnswer: 0,
          explanation: `الشرح الأكاديمي لمقرر ${subject}: يستند هذا السؤال إلى المعايير الامتحانية الوزارية المعتمدة.`,
          tags: ['وزاري', subject],
        });
      }
    }
  }

  // =============================================================
  // 13. البنك الطبي السريري (Medical Blocks - USMLE / IFOM)
  // =============================================================
  else if (section === 'medical') {
    const blockName = medicalBlock || subject || 'Cardiovascular System (CVS)';
    return generateYemeniMedicalQuestions(targetCount, blockName);
  }

  return generated;
}

/**
 * Saves and updates a batch of questions into Dexie IndexedDB, ensuring zero duplicates.
 */
export async function populateAndSaveQuestionsToIndexedDB(questions: BankQuestion[]): Promise<number> {
  try {
    const existing = await offlineDb.questions.toArray();
    const existingKeys = new Set(
      existing.map((q) => `${q.section}_${q.subject}_${(q.question || '').trim().replace(/\s+/g, ' ')}`)
    );

    const cleanFresh = questions.filter((q) => {
      if (isCorruptedQuestion(q)) return false;
      const cleanPrompt = (q.question || '').trim().replace(/\s+/g, ' ');
      const key = `${q.section}_${q.subject}_${cleanPrompt}`;
      if (existingKeys.has(key)) return false;
      existingKeys.add(key);
      return true;
    });

    if (cleanFresh.length > 0) {
      await offlineDb.questions.bulkPut(cleanFresh);
    }
    return await offlineDb.questions.count();
  } catch (e) {
    console.error('Failed to populate and save questions to IndexedDB:', e);
    return await offlineDb.questions.count();
  }
}
