/**
 * Tesseract.js Optical Character Recognition (OCR) Engine
 * Specially tuned strictly for Arabic textbooks, scanned exams, and academic curriculum notes.
 */
import { createWorker } from 'tesseract.js';
import { cleanAndReshapePdfText } from './arabicReshaper';

export interface OCRProgress {
  status: string;
  progress: number; // 0 to 1
  pageNumber?: number;
  totalPages?: number;
}

export type OCRProgressCallback = (progress: OCRProgress) => void;

/**
 * Perform optical character recognition on an Image (File, Blob, or Canvas)
 * Uses Arabic ('ara') strictly with academic dictionary reshaping and diacritics.
 */
export async function recognizeImageText(
  imageSource: Blob | File | HTMLCanvasElement | ImageData | string,
  onProgress?: OCRProgressCallback,
  pageNumber = 1,
  totalPages = 1
): Promise<string> {
  let worker: any = null;
  try {
    onProgress?.({
      status: `تهيئة محرك القراءة البصرية العربي (OCR ara) للصفحة ${pageNumber}...`,
      progress: 0.1,
      pageNumber,
      totalPages,
    });

    // Language set strictly to Arabic ('ara') as required
    worker = await createWorker('ara', 1, {
      logger: (m) => {
        if (m.status === 'recognizing text') {
          onProgress?.({
            status: `جاري استخراج النصوص والمصطلحات الأكاديمية العربية (${Math.round((m.progress || 0) * 100)}%)...`,
            progress: 0.1 + (m.progress || 0) * 0.85,
            pageNumber,
            totalPages,
          });
        }
      },
    });

    const ret = await worker.recognize(imageSource);
    const rawText = (ret.data.text || '')
      .replace(/\r\n/g, '\n')
      .replace(/[ \t]+/g, ' ')
      .trim();

    // Pass through Arabic Reshaper, Presentation Forms normalizer & BiDi fixer
    const extractedText = cleanAndReshapePdfText(rawText);

    onProgress?.({
      status: `اكتمل استخراج النصوص العربية الأكاديمية للصفحة ${pageNumber}`,
      progress: 1.0,
      pageNumber,
      totalPages,
    });

    return extractedText;
  } catch (err: any) {
    console.warn(`OCR failed for page ${pageNumber}:`, err);
    return '';
  } finally {
    if (worker) {
      await worker.terminate().catch(() => {});
    }
  }
}
