// Direct Client-Side Google Gemini API Service with Automatic Key Rotation & Model Failover
// Pre-configured for standalone HTML files, mobile browsers, and offline-first scenarios
// Developed by: فريق D.CORE الذكي

import { DEFAULT_STANDALONE_KEYS, getPreconfiguredGeminiKeys } from './apiConfig';
import { isAppIdentityInquiry, getAppIdentityResponse } from './identityAttribution';

export interface DirectGeminiOptions {
  prompt: string;
  systemInstruction?: string;
  conversationHistory?: Array<{ role: 'user' | 'model' | 'ai' | 'assistant'; text: string }>;
  timeoutMs?: number;
}

export interface DirectGeminiResult {
  text: string;
  modelUsed: string;
  keyUsed: string;
  totalAttempts: number;
}

// Candidate models verified with Google Generative Language API
// Ordered for a fast first response, then quality-preserving failover.
// These IDs are supported by the configured Google Generative Language API.
export const CLIENT_GEMINI_MODELS = [
  'gemini-3.8-flash',
  'gemini-3.5-flash-lite',
  'gemini-3.1-flash-lite',
  'gemini-3.5-flash',
];

export const SYSTEM_CREATOR_IDENTITY = `
هوية المنصة وفريق التطوير والمصمم (Platform & Team Identity):
تم ابتكار وتصميم وتطوير وبرمجة منصة «المعلم الذكي للدراسة والبحث العلمي» (Smart Scholar AI) ونظام الذكاء الاصطناعي الأكاديمي المدمج بها بالكامل بواسطة المبتكر والمصمم والمهندس: «ضياء الحق سبيقاء» (Diaa Al-Haq Sabiqaa) بالتعاون مع «فريق D.CORE الأكاديمي» (D.CORE Academic Team).
إذا سألك المستخدم في أي وقت: من أنت؟ من طورك؟ من صانعك؟ من هو مطورك؟ من برمجك؟ من صمم هذا التطبيق؟ أو أي سؤال يتعلق بهويتك أو بالمصمم أو بفريق العمل، فأجب بفخر واعتزاز ووضوح تام:
بأنك «المعلم الذكي للدراسة والبحث العلمي»، تم تصميمك وابتكارك وهندستك بالكامل بواسطة المهندس والمصمم: «ضياء الحق سبيقاء» وفريق D.CORE الأكاديمي. يُحظر تماماً نسب تصميم هذا التطبيق إلى أي شركة أو جهة أخرى.

المنهجية العلمية والتعليمات الإلزامية الصارمة (Strict Academic Directives):
1. المباشرة المطلقة وحذف الحشو: ادخل فوراً ومباشرة في صلب الموضوع العلمي دون أي مقدمات، أو تحيات افتتاحية، أو مجاملات (مثل "أهلاً بك"، "يسعدني الإجابة"، "بالتأكيد")، ولا تختم بعبارات إنشائية. ابدأ بالجواب التحليلي المركز مباشرة.
2. العمق والشمولية والاستقصاء العلمي: يجب أن تكون الردود عميقة، شاملة، موسعة، ومفصلة لأبعد حد علمي ومنطقي، مع تفكيك المفاهيم، بيان الأصول والعلل، والاستدلالات الدقيقة دون اختصار مخل.
3. التنسيق الرياضي القياسي الصارم (Strict KaTeX & LaTeX Formulas):
   - كتابة جميع القوانين والمعادلات الرياضية، الفيزيائية، والكيميائية بصيغة LaTeX القياسية حصراً.
   - ضع القوانين والمعادلات الرئيسية في أسطر مستقلة داخل كتل عرض منفصلة: $$ ... $$.
   - ضع المتغيرات والرموز داخل السطر بين: $ ... $.
   - إلزامي: عند كتابة رموز أو كلمات عربية داخل LaTeX، يجب دائماً تغليفها بـ \\text{...} مثل:
     $$\\text{ع} = \\frac{\\text{ف}}{\\text{ز}} \\quad \\Longleftrightarrow \\quad v = \\frac{d}{t}$$
     $$\\text{ق} = \\text{ك} \\cdot \\text{جـ} \\quad \\Longleftrightarrow \\quad F = m \\cdot a$$
   - يُمنع منعاً باتاً استخدام الشرطة المائلة / للكسور في القوانين، بل استخدم دائماً \\frac{البسط}{المقام}.
   - يُمنع منعاً باتاً استخدام النجمة * للضرب، بل استخدم دائماً \\cdot أو \\times.
   - يُمنع كتابة الأسس والجذور كرموز مشوهة؛ استخدم دائماً x^2 و \\sqrt{x}.
   - اعرض دائماً جدولاً منظماً لدلالات الرموز ووحدات القياس الدولية (SI).
4. التنظيم الهيكلي: استخدام عناوين Markdown هرمية واضحة، جداول مقارنة منهجية، خطوات حل مرقمة (المعطيات، المطلوب، القانون، التعويض، الناتج النهائي مع الوحدة).
5. سياسة الصفر الجانبي: ابدأ بالمعلومة المطلوبة مباشرة دون أي مقدمات ترحيبية أو خواتيم إنشائية.
6. الإشراف البنيوي: عند طلب خريطة ذهنية أو بيانات قابلة للمعالجة، أخرج JSON صالحاً فقط وفق المخطط المطلوب، وتحقق من وجود id وtitle وchildren وعدم تكرار العقد.
7. لا تحذف التفاصيل؛ قسّم الإجابة إلى أقسام متتابعة واضحة مع الحفاظ على الرصانة العلمية.
`;

/**
 * Executes a direct fetch call to Google Generative Language API with automatic key rotation
 * and multi-model fallback. Seamlessly works in file:/// protocol, iframe, or web app.
 */
export async function callDirectGeminiWithKeyRotation(
  options: DirectGeminiOptions
): Promise<DirectGeminiResult> {
  const { prompt, systemInstruction, conversationHistory, timeoutMs = 9000 } = options;

  if (isAppIdentityInquiry(prompt)) {
    return {
      text: getAppIdentityResponse(),
      modelUsed: 'D.CORE Academic Core',
      keyUsed: 'institutional',
      totalAttempts: 1,
    };
  }

  const keys = getPreconfiguredGeminiKeys();
  if (!keys || keys.length === 0) {
    keys.push(...DEFAULT_STANDALONE_KEYS);
  }

  // Combine developer identity with system instruction
  const finalSystemInstruction = `${SYSTEM_CREATOR_IDENTITY}\n\n${systemInstruction || ''}`.trim();

  // Format conversation history for Gemini API
  const turns: Array<{ role: 'user' | 'model'; parts: Array<{ text: string }> }> = [];

  if (conversationHistory && Array.isArray(conversationHistory)) {
    for (const h of conversationHistory.slice(-30)) {
      if (!h.text || !h.text.trim()) continue;
      const role: 'user' | 'model' = h.role === 'user' ? 'user' : 'model';

      if (turns.length > 0 && turns[turns.length - 1].role === role) {
        turns[turns.length - 1].parts[0].text += `\n\n${h.text.trim()}`;
      } else {
        turns.push({
          role,
          parts: [{ text: h.text.trim() }],
        });
      }
    }
  }

  // Add current prompt
  if (turns.length > 0 && turns[turns.length - 1].role === 'user') {
    turns[turns.length - 1].parts[0].text += `\n\n${prompt.trim()}`;
  } else {
    turns.push({
      role: 'user',
      parts: [{ text: prompt.trim() }],
    });
  }

  const payload: any = {
    contents: turns,
    generationConfig: {
      maxOutputTokens: 8192,
      temperature: 0.35,
      responseMimeType: 'text/plain',
    },
  };

  if (finalSystemInstruction) {
    payload.systemInstruction = {
      parts: [{ text: finalSystemInstruction }],
    };
  }

  let lastError: any = null;
  let attemptCount = 0;

  // Try each key in sequence
  for (let kIdx = 0; kIdx < keys.length; kIdx++) {
    const key = keys[kIdx].trim();
    if (!key || key.length < 15) continue;

    // Try each model in sequence
    for (let mIdx = 0; mIdx < CLIENT_GEMINI_MODELS.length; mIdx++) {
      const model = CLIENT_GEMINI_MODELS[mIdx];
      attemptCount++;

      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), timeoutMs);

      try {
        const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(key)}`;
        const res = await fetch(url, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(payload),
          signal: controller.signal,
        });

        clearTimeout(timer);

        if (res.ok) {
          const json = await res.json();
          const candidateText = json.candidates?.[0]?.content?.parts?.[0]?.text;
          if (candidateText && candidateText.trim().length > 0) {
            return {
              text: candidateText.trim(),
              modelUsed: model,
              keyUsed: `Key ${kIdx + 1} (${key.slice(0, 8)}...)`,
              totalAttempts: attemptCount,
            };
          }
        } else {
          const errData = await res.json().catch(() => ({}));
          const errMsg = errData.error?.message || `HTTP ${res.status}`;
          lastError = new Error(`Model ${model} with key ${kIdx + 1} failed: ${errMsg}`);

          // If 503 high demand or 429 quota, immediately try next model or next key
          if (res.status === 429) {
            // Key quota exhausted, break model loop to switch to next key immediately!
            break;
          }
        }
      } catch (e: any) {
        clearTimeout(timer);
        lastError = e;
      }
    }
  }

  throw lastError || new Error('تعذر الحصول على استجابة من مفاتيح الذكاء الاصطناعي.');
}
