let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext | null {
  try {
    if (!audioCtx) {
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtxClass) {
        audioCtx = new AudioCtxClass();
      }
    }
    if (audioCtx && audioCtx.state === 'suspended') {
      audioCtx.resume();
    }
    return audioCtx;
  } catch (err) {
    console.warn('AudioContext not supported:', err);
    return null;
  }
}

export function playAlarmSound(kind: 'alarm' | 'chime' | 'classic' | 'digital' = 'chime') {
  const ctx = getAudioContext();
  if (!ctx) return;

  const now = ctx.currentTime;
  const master = ctx.createGain();
  master.gain.setValueAtTime(0.0001, now);
  master.gain.exponentialRampToValueAtTime(0.6, now + 0.05);
  master.connect(ctx.destination);

  const playTone = (freq: number, startOffset: number, duration: number, type: OscillatorType = 'sine') => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, now + startOffset);
    gain.gain.setValueAtTime(0.001, now + startOffset);
    gain.gain.exponentialRampToValueAtTime(0.5, now + startOffset + 0.03);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + startOffset + duration);
    osc.connect(gain);
    gain.connect(master);
    osc.start(now + startOffset);
    osc.stop(now + startOffset + duration + 0.05);
  };

  if (kind === 'chime') {
    [523.25, 659.25, 783.99, 1046.5].forEach((f, i) => playTone(f, i * 0.18, 0.8, 'sine'));
  } else if (kind === 'digital') {
    [880, 880, 660, 990, 660].forEach((f, i) => playTone(f, i * 0.14, 0.12, 'square'));
  } else if (kind === 'classic') {
    [880, 1175, 880, 1568].forEach((f, i) => playTone(f, i * 0.22, 0.35, 'sine'));
  } else {
    // alarm
    [660, 990, 1320, 990, 1320].forEach((f, i) => playTone(f, i * 0.18, 0.28, 'sawtooth'));
  }

  setTimeout(() => {
    try {
      master.disconnect();
    } catch {}
  }, 2500);
}
