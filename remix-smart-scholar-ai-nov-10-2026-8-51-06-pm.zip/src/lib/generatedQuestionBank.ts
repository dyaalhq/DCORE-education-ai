import type { BankQuestion, QuestionSection } from './questionBankData';

/**
 * كتالوج محلي مولّد بطريقة حتمية. لا يدّعي أن القوالب بديل عن مراجعة مدرس مختص؛
 * لكنه يضمن تغطية واسعة قابلة للبحث دون اتصال، مع إبقاء القوانين بصيغة LaTeX.
 */
const TARGET_PER_SCOPE = 2000;
const difficulties = ['easy', 'medium', 'hard'] as const;
const types = ['mcq', 'true_false', 'explain', 'problem', 'fill'] as const;

const UNIVERSAL_KNOWLEDGE_DOMAINS = [
  { subject: 'الرياضيات والخوارزميات', topics: ['الجبر والتحليل', 'الهندسة والقياس', 'الاحتمالات والإحصاء', 'المنطق ونظرية الأعداد', 'الخوارزميات والتعقيد'] },
  { subject: 'الفيزياء والكونيات', topics: ['الميكانيكا', 'الكهرباء والمغناطيسية', 'الحرارة والديناميكا الحرارية', 'الموجات والبصريات', 'الفيزياء الحديثة والكونيات'] },
  { subject: 'الكيمياء وعلوم المواد', topics: ['البنية الذرية والروابط', 'الحسابات الكيميائية', 'الاتزان والحركية', 'الكيمياء العضوية', 'المواد والطاقة'] },
  { subject: 'علوم الحاسوب والذكاء الاصطناعي', topics: ['البرمجة وهياكل البيانات', 'قواعد البيانات والشبكات', 'أمن المعلومات', 'التعلم الآلي', 'هندسة البرمجيات'] },
  { subject: 'الطب والعلوم الحيوية', topics: ['علم الخلية والوراثة', 'التشريح والوظائف', 'الأحياء الدقيقة والمناعة', 'المرض والدواء', 'الصحة العامة والأخلاقيات'] },
  { subject: 'التاريخ والحضارات الإنسانية', topics: ['الحضارات القديمة', 'التاريخ الإسلامي', 'التاريخ الحديث', 'الاقتصاد والمجتمع', 'منهجية قراءة المصادر'] },
  { subject: 'الأدب واللغة العربية والبلاغة', topics: ['النحو والصرف', 'البلاغة والعروض', 'الأدب العربي', 'الكتابة والبحث', 'اللسانيات والترجمة'] },
  { subject: 'الفلسفة ونظرية المعرفة', topics: ['المنطق والحجاج', 'الأخلاق', 'فلسفة العلم', 'الفكر السياسي', 'النقد وتمييز المغالطات'] },
  { subject: 'العلوم الشرعية وأصول الفقه', topics: ['القرآن وعلومه', 'الحديث ومصطلحه', 'الفقه وأصوله', 'السيرة والتاريخ الإسلامي', 'المقاصد والأخلاق'] },
  { subject: 'الجغرافيا والبيئة والاقتصاد', topics: ['الجغرافيا الطبيعية', 'المناخ والموارد', 'السكان والمدن', 'الاقتصاد والإدارة', 'الاستدامة والتنمية'] },
  { subject: 'الفنون والإعلام والمهارات المهنية', topics: ['التصميم والفنون', 'الإعلام والتواصل', 'إدارة المشاريع', 'التفكير النقدي', 'المهارات الرقمية'] },
] as const;

const scopeCatalog: Array<{
  section: QuestionSection;
  subject: string;
  topic: string;
  tags: string[];
  formula?: string;
  stage?: BankQuestion['stage'];
  medicalBlock?: string;
}> = [
  ...['العلوم', 'الرياضيات', 'اللغة العربية', 'القرآن والإسلامية', 'الاجتماعيات', 'اللغة الإنجليزية'].map((subject) => ({ section: 'ministerial' as const, subject, topic: 'منهج الصف التاسع الأساسي', tags: ['وزاري', 'تاسع أساسي'], stage: 'تاسع أساسي' as const })),
  ...['الفيزياء', 'الكيمياء', 'الأحياء', 'الرياضيات (تفاضل وتكامل وجبر)', 'اللغة العربية', 'القرآن والإسلامية', 'اللغة الإنجليزية'].map((subject) => ({ section: 'ministerial' as const, subject, topic: 'منهج الصف الثالث الثانوي العلمي', tags: ['وزاري', 'ثالث ثانوي علمي'], stage: 'ثالث ثانوي علمي' as const })),
  ...['التاريخ الحديث', 'الجغرافيا', 'الفلسفة وعلم النفس', 'اللغة العربية', 'القرآن والإسلامية', 'اللغة الإنجليزية'].map((subject) => ({ section: 'ministerial' as const, subject, topic: 'منهج الصف الثالث الثانوي الأدبي', tags: ['وزاري', 'ثالث ثانوي أدبي'], stage: 'ثالث ثانوي أدبي' as const })),
  ...['Foundation & Cell Biology', 'Cardiovascular System (CVS)', 'Respiratory System (RS)', 'Gastrointestinal System (GIT)', 'Central Nervous System (CNS)', 'Endocrine & Metabolism', 'Renal & Urinary System', 'Musculoskeletal System (MSK)', 'Hematology & Oncology', 'Pharmacology & Therapeutics', 'General Pathology & Microbiology', 'Internal Medicine & Surgery'].map((medicalBlock) => ({ section: 'medical' as const, subject: medicalBlock, topic: 'Medical block review', tags: ['طبي', 'سريري', medicalBlock], medicalBlock })),
  ...UNIVERSAL_KNOWLEDGE_DOMAINS.flatMap(({ subject, topics }) => topics.map((topic) => ({ section: 'universal' as const, subject, topic, tags: ['موسوعي', subject, topic] })))
];

const REAL_CONCEPTS: Record<string, { concept: string; question: string; answer: string; distractors?: string[]; formula?: string }[]> = {
  'الجبر والتحليل': [
    { concept: 'المشتقة', question: 'إذا كانت الدالة $$f(x)=x^3-3x^2+2$$، فما قيمة $$f\'(1)$$؟', answer: '$$f\'(x)=3x^2-6x$$، ولذلك $$f\'(1)=-3$$.', distractors: ['$$3$$', '$$0$$', '$$-1$$'] },
    { concept: 'المعادلة التربيعية', question: 'حل المعادلة $$x^2-5x+6=0$$، وفسّر عدد حلولها الحقيقية.', answer: 'نحللها إلى $$(x-2)(x-3)=0$$، إذن الحلّان $$x=2,3$$، والمميّز موجب.', distractors: ['حل واحد هو $$5$$', 'لا حلول حقيقية', 'الحلان $$-2,-3$$'] },
    { concept: 'المتتاليات', question: 'ما الحد العام للمتتالية الحسابية التي حدها الأول $$4$$ وأساسها $$3$$؟', answer: '$$a_n=a_1+(n-1)d=4+3(n-1)=3n+1$$.', distractors: ['$$4n+3$$', '$$3^n+1$$', '$$n+4$$'] },
  ],
  'الميكانيكا': [
    { concept: 'قوانين نيوتن', question: 'جسم كتلته $$2\,kg$$ تؤثر فيه قوة محصلة $$10\,N$$. احسب تسارعه واذكر القانون المستخدم.', answer: 'من قانون نيوتن الثاني $$F=ma$$، يكون $$a=F/m=5\,m/s^2$$.', distractors: ['$$20\,m/s^2$$', '$$0.2\,m/s^2$$', '$$8\,m/s^2$$'] },
    { concept: 'حفظ الطاقة', question: 'كيف تتحول الطاقة عند سقوط جسم في مجال الجاذبية مع إهمال مقاومة الهواء؟', answer: 'تتحول طاقة الوضع الثقالية تدريجياً إلى طاقة حركة، وتبقى الطاقة الميكانيكية الكلية ثابتة: $$E=mgh+\\frac{1}{2}mv^2$$.', distractors: ['تختفي الطاقة', 'تتحول كلها إلى حرارة', 'تزداد طاقة الوضع مع انخفاض الارتفاع'] },
  ],
  'البرمجة وهياكل البيانات': [
    { concept: 'التعقيد الحسابي', question: 'ما التعقيد الزمني للبحث الثنائي في مصفوفة مرتبة؟ ولماذا؟', answer: 'التعقيد $$O(\\log n)$$؛ لأن كل خطوة تقسم مجال البحث إلى نصفين.', distractors: ['$$O(n^2)$$ لأنه يفحص كل زوج', '$$O(1)$$ دائماً', '$$O(n)$$ لأنه يمر على كل عنصر'] },
    { concept: 'هياكل البيانات', question: 'متى تختار المكدس Stack بدلاً من الطابور Queue؟ اذكر تطبيقاً واقعياً.', answer: 'يُستخدم المكدس وفق مبدأ آخر داخل أول خارجاً (LIFO)، مثل سجل التراجع في محرر النصوص أو استدعاءات الدوال.', distractors: ['للمعالجة FIFO فقط', 'لتخزين البيانات عشوائياً دون ترتيب', 'للبحث في قاعدة بيانات'] },
  ],
  'البنية الذرية والروابط': [
    { concept: 'الروابط الكيميائية', question: 'ما الفرق بين الرابطة الأيونية والتساهمية من حيث انتقال الإلكترونات؟', answer: 'في الأيونية تنتقل إلكترونات غالباً بين فلز ولافلز، أما التساهمية فتتشارك الذرات أزواجاً من الإلكترونات.', distractors: ['كلاهما انتقال كامل دائماً', 'التساهمية تحدث بين الأيونات فقط', 'لا علاقة للإلكترونات بالروابط'] },
  ],
};

function makeQuestion(scope: typeof scopeCatalog[number], index: number): BankQuestion {
  const difficulty = difficulties[index % difficulties.length];
  const type = types[index % types.length];
  const serial = String(index + 1).padStart(4, '0');
  const concepts = REAL_CONCEPTS[scope.topic] ?? REAL_CONCEPTS['الجبر والتحليل'];
  const item = concepts[index % concepts.length];
  const formula = scope.formula ?? item.formula;
  const isMcq = type === 'mcq';
  const prompt = type === 'true_false'
    ? `صح أم خطأ: ${item.question.replace(/^.*؟/, '').trim()} راجع التعريف والشرط قبل الحكم.`
    : type === 'explain' ? `اشرح بعمق مفهوم «${item.concept}» في سياق ${scope.subject}، ثم اربطه بتطبيق واقعي وحدود استخدامه.`
    : type === 'problem' ? `${item.question} اكتب المعطيات، القانون، خطوات الحل، ثم اختبر النتيجة والوحدات.`
    : type === 'fill' ? `أكمل بدقة: المفهوم الذي يفسر السؤال الآتي هو «${item.concept}»، وقاعدته الأساسية هي ______. ${item.question}`
    : item.question;
  const answer = type === 'true_false' ? `العبارة تحتاج إلى قراءة شرطها بدقة؛ الإجابة العلمية هي: ${item.answer}` : item.answer;
  const options = isMcq ? [item.answer, ...(item.distractors ?? ['تعميم بلا شرط أو دليل', 'خلط بين السبب والنتيجة', 'قاعدة صحيحة في سياق مختلف'])] : undefined;
  return {
    id: `generated_${scope.section}_${scope.subject.replace(/[^\p{L}\p{N}]+/gu, '_')}_${serial}`,
    section: scope.section, stage: scope.stage, medicalBlock: scope.medicalBlock, subject: scope.subject,
    unitOrTopic: `${scope.topic}: ${item.concept}`,
    difficulty, type, question: prompt, options,
    correctAnswer: isMcq ? 0 : answer,
    explanation: `الإجابة الدقيقة: ${answer}\\n\\nسبب الاختيار: يرتبط المفهوم بـ «${item.concept}» وليس بتفسير عام. راجع الشرط، التعريف، الوحدات، وحدود التعميم قبل اعتماد النتيجة. هذه أسئلة تدريبية محلية مولّدة من مفاهيم حقيقية، وليست بديلاً عن مرجع متخصص.`,
    formulaOrRule: formula, tags: [...scope.tags, difficulty, type, `مفهوم ${item.concept}`]
  };
}

export const GENERATED_QUESTION_BANK: BankQuestion[] = scopeCatalog.flatMap((scope) =>
  Array.from({ length: TARGET_PER_SCOPE }, (_, index) => makeQuestion(scope, index))
);

export const QUESTION_BANK_SCOPE_COUNT = scopeCatalog.length;
export const QUESTION_BANK_TARGET_PER_SCOPE = TARGET_PER_SCOPE;
