import { SourceAnnotation, HighlightColor } from '../types';

/**
 * Normalizes Arabic string to make matching diacritic-free, tatweel-free, and whitespace-resilient.
 */
export function normalizeArabic(str: string): string {
  if (!str) return '';
  return str
    // Remove Arabic Tashkeel (harakat / diacritics)
    .replace(/[\u064B-\u065F\u0670]/g, '')
    // Remove Tatweel / Kashida (ـ)
    .replace(/\u0640/g, '')
    // Normalize Alef variations (إ, أ, آ, ٱ -> ا)
    .replace(/[إأآٱ]/g, 'ا')
    // Normalize Taa Marbuta (ة -> ه)
    .replace(/ة/g, 'ه')
    // Normalize Yaa / Alef Maksura (ى -> ي)
    .replace(/ى/g, 'ي')
    // Normalize quotes and brackets
    .replace(/[«»“”"']/g, '')
    // Normalize unicode bidi control characters
    .replace(/[\u200E\u200F\u200B\u202A-\u202E]/g, '')
    // Normalize multiple spaces / newlines / tabs to single space
    .replace(/[\s\u00A0]+/g, ' ')
    .trim()
    .toLowerCase();
}

/**
 * Builds an exact index mapping from normalized character positions back to rawText positions.
 * This guarantees 100% exact substring recovery even with diacritics, tatweel, and whitespace differences.
 */
export function buildNormalizedIndexMap(rawText: string): { normalized: string; indexMap: number[] } {
  let normalized = '';
  const indexMap: number[] = [];
  let lastWasSpace = false;

  for (let i = 0; i < rawText.length; i++) {
    const ch = rawText[i];

    // Check if tashkeel / harakat or tatweel (skipped completely)
    if (/[\u064B-\u065F\u0670\u0640\u200E\u200F\u200B\u202A-\u202E«»“”"']/.test(ch)) {
      continue;
    }

    // Check if whitespace
    if (/[\s\u00A0]/.test(ch)) {
      if (!lastWasSpace && normalized.length > 0) {
        normalized += ' ';
        indexMap.push(i);
        lastWasSpace = true;
      }
      continue;
    }

    lastWasSpace = false;

    // Normalize characters
    let normChar = ch.toLowerCase();
    if (/[إأآٱ]/.test(normChar)) normChar = 'ا';
    else if (normChar === 'ة') normChar = 'ه';
    else if (normChar === 'ى') normChar = 'ي';

    normalized += normChar;
    indexMap.push(i);
  }

  return { normalized, indexMap };
}

export interface MatchedRange {
  start: number;
  end: number;
  annotation?: SourceAnnotation;
  isCitationTarget?: boolean;
  isSearchMatch?: boolean;
  searchMatchIndex?: number;
}

/**
 * Finds the exact start and end offsets in raw text for an annotation.
 * 1. Checks startIndex and endIndex if already saved and valid
 * 2. Checks exact substring indexOf
 * 3. Checks mathematical character-mapped normalized Arabic alignment
 * 4. Checks loose token-boundary regex matching
 */
export function findAnnotationOffsetsInText(
  rawText: string,
  ann: SourceAnnotation
): { start: number; end: number } | null {
  if (!rawText || !ann.selectedText) return null;

  const target = ann.selectedText.trim();
  if (!target) return null;

  // 1. Direct offset check
  if (
    typeof ann.startIndex === 'number' &&
    typeof ann.endIndex === 'number' &&
    ann.startIndex >= 0 &&
    ann.endIndex <= rawText.length &&
    ann.startIndex < ann.endIndex
  ) {
    const slice = rawText.slice(ann.startIndex, ann.endIndex).trim();
    if (slice === target || normalizeArabic(slice) === normalizeArabic(target)) {
      return { start: ann.startIndex, end: ann.endIndex };
    }
  }

  // 2. Direct exact match
  const exactPos = rawText.indexOf(target);
  if (exactPos !== -1) {
    return { start: exactPos, end: exactPos + target.length };
  }

  // 3. Exact character-index mapped normalized search (100% resilient to Arabic tashkeel, tatweel, and spacing)
  try {
    const { normalized, indexMap } = buildNormalizedIndexMap(rawText);
    const normTarget = normalizeArabic(target);

    if (normTarget && normTarget.length >= 2) {
      const normPos = normalized.indexOf(normTarget);
      if (normPos !== -1 && normPos + normTarget.length - 1 < indexMap.length) {
        const rawStart = indexMap[normPos];
        const rawEnd = indexMap[normPos + normTarget.length - 1] + 1;
        if (rawStart >= 0 && rawEnd <= rawText.length && rawStart < rawEnd) {
          return { start: rawStart, end: rawEnd };
        }
      }
    }
  } catch (err) {
    console.warn('Normalized index mapping error:', err);
  }

  // 4. Normalized whitespace & token match
  const targetTokens = target.split(/\s+/).filter(Boolean);
  if (targetTokens.length > 0) {
    try {
      const escapedTokens = targetTokens.map((t) =>
        t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
      );
      const looseRegex = new RegExp(escapedTokens.join('[\\s\\r\\n\\u00A0]+'), 'i');
      const match = looseRegex.exec(rawText);
      if (match && typeof match.index === 'number') {
        return { start: match.index, end: match.index + match[0].length };
      }
    } catch {
      // Fallback
    }

    // 5. Fallback: match first and last significant tokens
    if (targetTokens.length >= 2) {
      const firstToken = targetTokens[0];
      const lastToken = targetTokens[targetTokens.length - 1];
      const startIdx = rawText.indexOf(firstToken);
      if (startIdx !== -1) {
        const searchSub = rawText.slice(startIdx);
        const endRel = searchSub.indexOf(lastToken);
        if (endRel !== -1 && endRel < target.length * 2.5) {
          const endIdx = startIdx + endRel + lastToken.length;
          return { start: startIdx, end: endIdx };
        }
      }
    }
  }

  return null;
}

/**
 * Splits long continuous text into readable page-sized chunks if no pages exist.
 */
export function ensureDocumentPages(
  content: string,
  existingPages?: Array<{ pageNumber: number; text: string }>
): Array<{ pageNumber: number; text: string }> {
  if (existingPages && existingPages.length > 0) {
    return existingPages.map((p, idx) => ({
      pageNumber: p.pageNumber || idx + 1,
      text: p.text || '',
    }));
  }

  if (!content || !content.trim()) {
    return [{ pageNumber: 1, text: '' }];
  }

  // Check if content has [الصفحة X] markers
  const pageRegex = /\[الصفحة\s+(\d+)\]([\s\S]*?)(?=(\[الصفحة\s+\d+\]|$))/g;
  const extracted: Array<{ pageNumber: number; text: string }> = [];
  let match;
  while ((match = pageRegex.exec(content)) !== null) {
    const pNum = parseInt(match[1], 10);
    const pText = match[2].trim();
    if (pText) {
      extracted.push({ pageNumber: pNum, text: pText });
    }
  }

  if (extracted.length > 0) {
    return extracted;
  }

  // For long articles/texts without page markers, break into comfortable 2000-character pages
  if (content.length > 3200) {
    const pages: Array<{ pageNumber: number; text: string }> = [];
    const paragraphs = content.split(/\n\s*\n/);
    let currentPageText = '';
    let pageNum = 1;

    for (const para of paragraphs) {
      if ((currentPageText.length + para.length > 2200) && currentPageText.trim().length > 400) {
        pages.push({ pageNumber: pageNum++, text: currentPageText.trim() });
        currentPageText = para + '\n\n';
      } else {
        currentPageText += para + '\n\n';
      }
    }

    if (currentPageText.trim()) {
      pages.push({ pageNumber: pageNum, text: currentPageText.trim() });
    }

    if (pages.length > 1) {
      return pages;
    }
  }

  return [{ pageNumber: 1, text: content }];
}
