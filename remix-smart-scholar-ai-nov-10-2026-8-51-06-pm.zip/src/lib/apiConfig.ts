// Centralized API configuration & universal fetch interceptor for standalone and hosted environments

export const DEFAULT_CLOUD_BACKEND = 'https://ais-pre-ceqcff5xopfxfafx5hxq4n-665382393160.europe-west1.run.app';

// Pre-configured official Google Gemini API keys provided by D.CORE
// Automatically active in standalone single-file HTML mode without requiring any manual setup
export const DEFAULT_STANDALONE_KEYS: string[] = [];

export function getPreconfiguredGeminiKeys(): string[] {
  const keys: string[] = [];
  try {
    const custom = localStorage.getItem('standalone_gemini_key');
    if (custom && custom.trim().length > 15) {
      keys.push(custom.trim());
    }
  } catch (e) {
    // ignore in restricted browser contexts
  }

  // Append default developer keys ensuring no duplicates
  for (const k of DEFAULT_STANDALONE_KEYS) {
    if (!keys.includes(k)) {
      keys.push(k);
    }
  }

  return keys;
}

export function isStandaloneApp(): boolean {
  if (typeof window === 'undefined') return false;
  try {
    if ((window as any).__IS_STANDALONE_SINGLE_FILE__ === true) return true;
    if (window.location.protocol === 'file:') return true;
    if (!window.location.host) return true;
    if (window.location.pathname.endsWith('.html') && window.location.pathname.includes('standalone')) return true;
  } catch (e) {
    // ignore
  }
  return false;
}

export function getApiBaseUrl(): string {
  if (typeof window === 'undefined') return '';

  // 1. User custom server URL if configured
  try {
    const custom = localStorage.getItem('standalone_backend_url');
    if (custom && custom.trim()) {
      return custom.trim().replace(/\/+$/, '');
    }
  } catch (e) {
    // ignore localstorage errors in restricted contexts
  }

  // 2. If running on web over HTTP/HTTPS from a hosted app or live server
  if (typeof window.location !== 'undefined') {
    const proto = window.location.protocol;
    // If running on actual web origin (not file://)
    if (proto === 'http:' || proto === 'https:') {
      return window.location.origin;
    }
  }

  // 3. If running from local disk (file://) or downloaded standalone HTML file
  return DEFAULT_CLOUD_BACKEND;
}

export function getApiUrl(endpoint: string): string {
  const cleanEndpoint = endpoint.startsWith('/') ? endpoint : `/${endpoint}`;
  const baseUrl = getApiBaseUrl();
  if (!baseUrl) return cleanEndpoint;
  return `${baseUrl}${cleanEndpoint}`;
}

export async function apiFetch(input: RequestInfo | URL, init?: RequestInit): Promise<Response> {
  let target = input;
  if (typeof input === 'string' && input.startsWith('/api/')) {
    target = getApiUrl(input);
  } else if (input instanceof URL && input.pathname.startsWith('/api/')) {
    target = getApiUrl(input.pathname + input.search);
  }
  return fetch(target, init);
}

// Global fetch interceptor to guarantee all relative /api/ requests resolve correctly even in file:/// or standalone mode
let isFetchPatched = false;

export function initUniversalApiFetch() {
  if (typeof window === 'undefined' || isFetchPatched) return;
  
  try {
    const originalFetch = window.fetch ? window.fetch.bind(window) : fetch;
    const patchedFetch = async function (input: RequestInfo | URL, init?: RequestInit): Promise<Response> {
      try {
        if (typeof input === 'string' && input.startsWith('/api/')) {
          const fullUrl = getApiUrl(input);
          return await originalFetch(fullUrl, init);
        } else if (input instanceof URL && input.pathname.startsWith('/api/')) {
          const fullUrl = getApiUrl(input.pathname + input.search);
          return await originalFetch(fullUrl, init);
        }
      } catch (e) {
        console.warn('API fetch rewrite warning, using original fetch:', e);
      }
      return originalFetch(input, init);
    };

    // Safely attempt defineProperty without crashing if window.fetch is a read-only getter
    try {
      Object.defineProperty(window, 'fetch', {
        value: patchedFetch,
        writable: true,
        configurable: true,
      });
      isFetchPatched = true;
    } catch {
      // If window.fetch has only a getter or is sealed by the browser/iframe sandbox,
      // silently ignore the assignment so the app doesn't crash.
    }
  } catch {
    // Silent fail-safe
  }
}

// Auto-initialize safely
try {
  initUniversalApiFetch();
} catch {
  // Silent fail-safe
}
