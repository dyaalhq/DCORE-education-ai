/**
 * TextToSpeechService - Production-Grade Web Speech API Service
 * 
 * Features:
 * 1. Global singleton instance & React hook callable anywhere in the app.
 * 2. Robust Arabic and multilingual speech synthesis with automated voice discovery.
 * 3. Text cleaning: converts Markdown & LaTeX math (equations, fractions, square roots) to natural spoken Arabic.
 * 4. Micro-chunking (sentence-by-sentence) with boundary preservation to eliminate the Chrome 15-second speech freeze bug.
 * 5. Full lifecycle error handling: auto-recovery on utterance failure, interruption handling, fallback voices.
 * 6. Play, Pause, Resume, Stop, Speed Rate adjustment, Voice selection, Skip next/prev chunk.
 * 7. Mobile audio unlock (Safari / Chrome iOS & Android).
 */

import { useState, useEffect } from 'react';

export interface TTSVoiceOption {
  name: string;
  lang: string;
  uri: string;
  isArabic: boolean;
  isDefault: boolean;
}

export interface TTSSpeechOptions {
  title?: string;
  speed?: number;
  pitch?: number;
  voiceUri?: string;
  onStart?: () => void;
  onEnd?: () => void;
  onError?: (err: any) => void;
}

export interface TTSState {
  isPlaying: boolean;
  isPaused: boolean;
  speed: number;
  pitch: number;
  currentTitle: string;
  totalChunks: number;
  currentChunkIndex: number;
  currentChunkText: string;
  progressPercent: number;
  hasVoiceSupport: boolean;
  availableVoices: TTSVoiceOption[];
  selectedVoiceUri: string | null;
  errorMessage: string | null;
}

export type TTSListener = (state: TTSState) => void;

export class TextToSpeechService {
  private synth: SpeechSynthesis | null = null;
  private currentUtterance: SpeechSynthesisUtterance | null = null;
  private chunks: string[] = [];
  private currentChunkIndex = 0;
  private speed = 1.0;
  private pitch = 1.0;
  private currentTitle = '';
  private isPlaying = false;
  private isPaused = false;
  private listeners: Set<TTSListener> = new Set();
  private keepAliveInterval: any = null;
  private activeOnEnd?: () => void;
  private activeOnError?: (err: any) => void;
  private cachedVoices: SpeechSynthesisVoice[] = [];
  private selectedVoiceUri: string | null = null;
  private lastError: string | null = null;
  private retryAttempts = 0;

  constructor() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      this.synth = window.speechSynthesis;
      this.refreshVoices();

      if (typeof this.synth.addEventListener === 'function') {
        this.synth.addEventListener('voiceschanged', () => this.refreshVoices());
      } else {
        this.synth.onvoiceschanged = () => this.refreshVoices();
      }
    }
  }

  public refreshVoices(): TTSVoiceOption[] {
    if (!this.synth) return [];
    try {
      this.cachedVoices = this.synth.getVoices() || [];
    } catch {
      this.cachedVoices = [];
    }
    const options = this.getVoiceOptions();
    this.notify();
    return options;
  }

  public getVoiceOptions(): TTSVoiceOption[] {
    return this.cachedVoices.map((v) => ({
      name: v.name,
      lang: v.lang,
      uri: v.voiceURI,
      isArabic: v.lang.toLowerCase().startsWith('ar'),
      isDefault: v.default,
    }));
  }

  public subscribe(listener: TTSListener): () => void {
    this.listeners.add(listener);
    listener(this.getState());
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify(): void {
    const state = this.getState();
    this.listeners.forEach((fn) => {
      try {
        fn(state);
      } catch (err) {
        console.warn('TTS listener notification error:', err);
      }
    });
  }

  public getState(): TTSState {
    const total = this.chunks.length;
    const current = this.currentChunkIndex;
    const progressPercent = total > 0 ? Math.round(((current + 1) / total) * 100) : 0;

    return {
      isPlaying: this.isPlaying,
      isPaused: this.isPaused,
      speed: this.speed,
      pitch: this.pitch,
      currentTitle: this.currentTitle,
      totalChunks: total,
      currentChunkIndex: current,
      currentChunkText: this.chunks[current] || '',
      progressPercent: Math.min(100, Math.max(0, progressPercent)),
      hasVoiceSupport: !!this.synth,
      availableVoices: this.getVoiceOptions(),
      selectedVoiceUri: this.selectedVoiceUri,
      errorMessage: this.lastError,
    };
  }

  public isSpeaking(): boolean {
    return this.isPlaying;
  }

  /**
   * Pre-cleans Markdown, KaTeX, and equations into natural spoken Arabic
   */
  public cleanTextForSpeech(rawText: string): string {
    if (!rawText) return '';

    return rawText
      // Code blocks and inline code
      .replace(/```[\s\S]*?```/g, ' كود برمجي ')
      .replace(/`([^`]+)`/g, '$1')
      // LaTeX math fractions: \frac{a}{b} -> a مقسوماً على b
      .replace(/\\frac\{([^}]+)\}\{([^}]+)\}/g, '$1 مقسوماً على $2')
      .replace(/\\sqrt\{([^}]+)\}/g, ' الجذر التربيعي لـ $1 ')
      .replace(/\\text\{([^}]+)\}/g, '$1')
      // Math operators & symbols
      .replace(/\\cdot/g, ' في ')
      .replace(/\\times/g, ' ضرب ')
      .replace(/\\approx/g, ' يساوي تقريباً ')
      .replace(/\\le/g, ' أصغر من أو يساوي ')
      .replace(/\\ge/g, ' أكبر من أو يساوي ')
      .replace(/\\ne/g, ' لا يساوي ')
      .replace(/\\pm/g, ' زائد أو ناقص ')
      .replace(/\\infty/g, ' ما لا نهاية ')
      .replace(/\\Delta/g, ' دلتا ')
      .replace(/\\lambda/g, ' لامدا ')
      .replace(/\\pi/g, ' باي ')
      .replace(/\\sum/g, ' مجموع ')
      .replace(/\\int/g, ' تكامل ')
      // Math blocks
      .replace(/\$\$([\s\S]*?)\$\$/g, ' معادلة: $1 ')
      .replace(/\$([^$]+)\$/g, ' $1 ')
      // Markdown formatting
      .replace(/^#{1,6}\s+/gm, '')
      .replace(/[*_~]{1,3}([^*_~]+)[*_~]{1,3}/g, '$1')
      .replace(/!\[.*?\]\(.*?\)/g, '')
      .replace(/\[([^\]]+)\]\((.*?)\)/g, '$1')
      .replace(/\[\d+(?:,\s*\d+)*\]/g, '') // Remove citation tags like [1], [2]
      .replace(/^[-*+•]\s+/gm, '')
      .replace(/^\d+\.\s+/gm, '')
      .replace(/^[>|]\s*/gm, '')
      .replace(/\|/g, ' ')
      .replace(/[—_–\\{}]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  /**
   * Splits text into short, manageable chunks to avoid Chrome's 15s freeze bug
   */
  private splitIntoSpokenChunks(cleanText: string): string[] {
    if (!cleanText) return [];

    const rawSentences = cleanText.split(/([.!?،؛\n]+)/);
    const chunks: string[] = [];
    let currentBuffer = '';

    for (let i = 0; i < rawSentences.length; i++) {
      const part = rawSentences[i].trim();
      if (!part) continue;

      if (currentBuffer.length + part.length < 120) {
        currentBuffer += (currentBuffer ? ' ' : '') + part;
      } else {
        if (currentBuffer) chunks.push(currentBuffer);
        currentBuffer = part;
      }
    }

    if (currentBuffer) {
      chunks.push(currentBuffer);
    }

    return chunks.length > 0 ? chunks : [cleanText];
  }

  /**
   * Find highest quality Arabic voice, or active selected voice
   */
  private resolveVoice(): SpeechSynthesisVoice | null {
    if (!this.synth) return null;
    if (this.cachedVoices.length === 0) {
      this.refreshVoices();
    }
    const voices = this.cachedVoices;
    if (voices.length === 0) return null;

    // 1. Explicit user selection
    if (this.selectedVoiceUri) {
      const match = voices.find((v) => v.voiceURI === this.selectedVoiceUri);
      if (match) return match;
    }

    // 2. Premium / Natural Arabic voices
    const premiumArabic = voices.find(
      (v) =>
        v.lang.toLowerCase().startsWith('ar') &&
        (v.name.includes('Natural') ||
          v.name.includes('Google') ||
          v.name.includes('Enhanced') ||
          v.name.includes('Maged') ||
          v.name.includes('Tarik') ||
          v.name.includes('Laila') ||
          v.name.includes('Salma') ||
          v.name.includes('Zayd'))
    );
    if (premiumArabic) return premiumArabic;

    // 3. Any standard Arabic voice (ar-SA, ar-EG, ar)
    const anyArabic =
      voices.find((v) => v.lang.toLowerCase().startsWith('ar-sa')) ||
      voices.find((v) => v.lang.toLowerCase().startsWith('ar-eg')) ||
      voices.find((v) => v.lang.toLowerCase().startsWith('ar'));
    if (anyArabic) return anyArabic;

    // 4. Fallback to default
    return voices.find((v) => v.default) || voices[0] || null;
  }

  /**
   * Unlock audio engine for mobile iOS/Safari/Android
   */
  public unlockAudio(): void {
    if (!this.synth) return;
    try {
      if (this.synth.paused) {
        this.synth.resume();
      }
    } catch {}
  }

  /**
   * Primary Speak method
   */
  public speak(
    text: string,
    optionsOrTitle?: string | TTSSpeechOptions,
    maybeSpeed?: number
  ): void {
    if (!this.synth) {
      console.warn('[TextToSpeechService] Web Speech API not supported in this browser.');
      this.lastError = 'محرك الصوت غير مدعوم في هذا المتصفح';
      this.notify();
      return;
    }

    let title = 'قراءة صوتية';
    let speed = this.speed;
    let pitch = this.pitch;
    let voiceUri = this.selectedVoiceUri;
    let onStart: (() => void) | undefined;
    let onEnd: (() => void) | undefined;
    let onError: ((err: any) => void) | undefined;

    if (typeof optionsOrTitle === 'string') {
      title = optionsOrTitle;
      if (maybeSpeed !== undefined) speed = maybeSpeed;
    } else if (optionsOrTitle && typeof optionsOrTitle === 'object') {
      if (optionsOrTitle.title) title = optionsOrTitle.title;
      if (optionsOrTitle.speed !== undefined) speed = optionsOrTitle.speed;
      if (optionsOrTitle.pitch !== undefined) pitch = optionsOrTitle.pitch;
      if (optionsOrTitle.voiceUri) voiceUri = optionsOrTitle.voiceUri;
      onStart = optionsOrTitle.onStart;
      onEnd = optionsOrTitle.onEnd;
      onError = optionsOrTitle.onError;
    }

    this.stop();
    this.unlockAudio();

    const cleaned = this.cleanTextForSpeech(text);
    if (!cleaned) {
      onEnd?.();
      return;
    }

    this.speed = Math.max(0.5, Math.min(2.5, speed));
    this.pitch = Math.max(0.5, Math.min(1.8, pitch));
    if (voiceUri) this.selectedVoiceUri = voiceUri;

    this.chunks = this.splitIntoSpokenChunks(cleaned);
    this.currentChunkIndex = 0;
    this.currentTitle = title;
    this.isPlaying = true;
    this.isPaused = false;
    this.lastError = null;
    this.retryAttempts = 0;
    this.activeOnEnd = onEnd;
    this.activeOnError = onError;

    onStart?.();
    this.startKeepAlive();
    this.notify();

    // Settle pending cancellations before speaking
    setTimeout(() => {
      if (this.isPlaying) {
        this.speakCurrentChunk();
      }
    }, 50);
  }

  private speakCurrentChunk(): void {
    if (!this.synth || !this.isPlaying || this.currentChunkIndex >= this.chunks.length) {
      this.handleFinish();
      return;
    }

    try {
      if (this.synth.paused) {
        this.synth.resume();
      }

      const chunkText = this.chunks[this.currentChunkIndex];
      const utterance = new SpeechSynthesisUtterance(chunkText);
      utterance.rate = this.speed;
      utterance.pitch = this.pitch;
      utterance.lang = 'ar-SA';

      const voice = this.resolveVoice();
      if (voice) {
        utterance.voice = voice;
        utterance.lang = voice.lang || 'ar-SA';
      }

      utterance.onstart = () => {
        this.lastError = null;
        this.retryAttempts = 0;
        this.notify();
      };

      utterance.onend = () => {
        if (!this.isPlaying) return;
        this.currentChunkIndex++;
        if (this.currentChunkIndex < this.chunks.length) {
          this.notify();
          this.speakCurrentChunk();
        } else {
          this.handleFinish();
        }
      };

      utterance.onerror = (e) => {
        // Intentional cancel or stop
        if (e.error === 'interrupted' || e.error === 'canceled') {
          return;
        }

        console.warn(`[TextToSpeechService] Chunk error: ${e.error}`);
        this.lastError = `خطأ أثناء نطق المقطع (${e.error})`;

        // Resilient error recovery: try next chunk instead of breaking the entire reading
        if (this.isPlaying && this.currentChunkIndex < this.chunks.length - 1) {
          this.currentChunkIndex++;
          setTimeout(() => {
            if (this.isPlaying) this.speakCurrentChunk();
          }, 100);
        } else {
          this.activeOnError?.(e);
          this.handleFinish();
        }
      };

      this.currentUtterance = utterance;
      this.synth.speak(utterance);
      this.notify();
    } catch (err: any) {
      console.warn('[TextToSpeechService] Exception in speakCurrentChunk:', err);
      this.lastError = err?.message || 'خطأ غير متوقع في محرك النطق';
      this.activeOnError?.(err);
      this.handleFinish();
    }
  }

  private handleFinish(): void {
    const endCallback = this.activeOnEnd;
    this.stop();
    endCallback?.();
  }

  public pause(): void {
    if (!this.synth || !this.isPlaying) return;
    try {
      this.synth.pause();
    } catch {}
    this.isPaused = true;
    this.notify();
  }

  public resume(): void {
    if (!this.synth) return;
    try {
      if (this.isPaused) {
        this.synth.resume();
        this.isPaused = false;
        this.notify();
      } else if (!this.isPlaying && this.chunks.length > 0) {
        this.isPlaying = true;
        this.speakCurrentChunk();
      }
    } catch {}
  }

  public stop(): void {
    if (this.synth) {
      try {
        this.synth.cancel();
      } catch {}
    }
    this.stopKeepAlive();
    this.isPlaying = false;
    this.isPaused = false;
    this.currentUtterance = null;
    this.activeOnEnd = undefined;
    this.activeOnError = undefined;
    this.notify();
  }

  public setSpeed(newSpeed: number): void {
    this.speed = Math.max(0.5, Math.min(2.5, newSpeed));
    this.notify();

    if (this.synth && this.isPlaying && !this.isPaused) {
      try {
        this.synth.cancel();
      } catch {}
      setTimeout(() => {
        if (this.isPlaying) {
          this.speakCurrentChunk();
        }
      }, 50);
    }
  }

  public setPitch(newPitch: number): void {
    this.pitch = Math.max(0.5, Math.min(1.8, newPitch));
    this.notify();
  }

  public setVoice(voiceUri: string | null): void {
    this.selectedVoiceUri = voiceUri;
    this.notify();

    if (this.synth && this.isPlaying && !this.isPaused) {
      try {
        this.synth.cancel();
      } catch {}
      setTimeout(() => {
        if (this.isPlaying) {
          this.speakCurrentChunk();
        }
      }, 50);
    }
  }

  public nextChunk(): void {
    if (this.currentChunkIndex < this.chunks.length - 1) {
      this.currentChunkIndex++;
      if (this.synth) {
        try { this.synth.cancel(); } catch {}
      }
      setTimeout(() => {
        if (this.isPlaying) this.speakCurrentChunk();
        else this.notify();
      }, 50);
    }
  }

  public prevChunk(): void {
    if (this.currentChunkIndex > 0) {
      this.currentChunkIndex--;
      if (this.synth) {
        try { this.synth.cancel(); } catch {}
      }
      setTimeout(() => {
        if (this.isPlaying) this.speakCurrentChunk();
        else this.notify();
      }, 50);
    }
  }

  // Periodic heartbeat to prevent Chrome/WebKit 15-second speech synthesis pause
  private startKeepAlive(): void {
    this.stopKeepAlive();
    this.keepAliveInterval = setInterval(() => {
      if (this.synth && this.isPlaying && !this.isPaused) {
        try {
          this.synth.pause();
          this.synth.resume();
        } catch {}
      }
    }, 8000);
  }

  private stopKeepAlive(): void {
    if (this.keepAliveInterval) {
      clearInterval(this.keepAliveInterval);
      this.keepAliveInterval = null;
    }
  }
}

// Global Singleton Instance
export const textToSpeechService = new TextToSpeechService();

/**
 * Universal standalone helper to speak text from anywhere in the app
 */
export function speakText(
  text: string,
  options?: TTSSpeechOptions
): void {
  textToSpeechService.speak(text, options);
}

/**
 * Universal standalone helper to pause speech
 */
export function pauseSpeaking(): void {
  textToSpeechService.pause();
}

/**
 * Universal standalone helper to resume speech
 */
export function resumeSpeaking(): void {
  textToSpeechService.resume();
}

/**
 * Universal standalone helper to stop all ongoing speech
 */
export function stopSpeaking(): void {
  textToSpeechService.stop();
}

/**
 * React Hook for TextToSpeechService
 */
export function useTextToSpeech() {
  const [state, setState] = useState<TTSState>(() => textToSpeechService.getState());

  useEffect(() => {
    const unsubscribe = textToSpeechService.subscribe(setState);
    return () => unsubscribe();
  }, []);

  return {
    ...state,
    speak: (text: string, options?: TTSSpeechOptions) => textToSpeechService.speak(text, options),
    pause: () => textToSpeechService.pause(),
    resume: () => textToSpeechService.resume(),
    stop: () => textToSpeechService.stop(),
    setSpeed: (speed: number) => textToSpeechService.setSpeed(speed),
    setPitch: (pitch: number) => textToSpeechService.setPitch(pitch),
    setVoice: (voiceUri: string | null) => textToSpeechService.setVoice(voiceUri),
    nextChunk: () => textToSpeechService.nextChunk(),
    prevChunk: () => textToSpeechService.prevChunk(),
  };
}
