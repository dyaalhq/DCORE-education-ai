/**
 * Knowledge Resolver Service
 * خدمة حل وتوثيق المعارف والمصطلحات الأكاديمية بالذكاء الاصطناعي (Gemini)
 * مع ضمان الفلترة العلمية الصارمة، منع التكرار، ودعم KaTeX القياسي.
 */

import { EncyclopediaArticle, offlineDb } from './offlineDatabase';
import { COMPREHENSIVE_ENCYCLOPEDIA_ARTICLES } from './encyclopediaData';
import { ScienceCategory } from './storage';

export interface ResolveOptions {
  categoryHint?: string;
  forceFreshGeneration?: boolean;
  onStatusUpdate?: (status: string) => void;
}

export class KnowledgeResolverService {
  /**
   * Resolves any scientific query or academic concept:
   * 1. Checks in-memory cache and IndexedDB to avoid unnecessary network calls & token waste.
   * 2. If already exists, returns the verified high-yield article.
   * 3. If new, invokes the backend Knowledge Resolver powered by Gemini 3.8 Flash.
   * 4. Persists the new scholarly article into IndexedDB for 100% offline access.
   */
  public async resolve(query: string, options: ResolveOptions = {}): Promise<EncyclopediaArticle> {
    const cleanQuery = query.trim();
    if (!cleanQuery) {
      throw new Error('يرجى كتابة مصطلح أو مفهوم علمي صالح للبحث والتوثيق');
    }

    const { categoryHint, forceFreshGeneration, onStatusUpdate } = options;

    // Step 1: Check existing local articles (Unless forced fresh)
    if (!forceFreshGeneration) {
      onStatusUpdate?.('فحص قاعدة المعارف الأكاديمية المحلية...');
      
      // Match from comprehensive static database
      const exactStatic = COMPREHENSIVE_ENCYCLOPEDIA_ARTICLES.find(
        (a) =>
          a.title.toLowerCase().includes(cleanQuery.toLowerCase()) ||
          a.slug === cleanQuery.toLowerCase() ||
          a.tags.some((t) => t.toLowerCase() === cleanQuery.toLowerCase())
      );
      if (exactStatic) {
        onStatusUpdate?.('تم استرجاع المرجع المعتمد فوراً من الموسوعة المحلية ✓');
        return exactStatic;
      }

      // Match from IndexedDB
      try {
        const stored = await offlineDb.encyclopedia.toArray();
        const found = stored.find(
          (a) =>
            a.title.toLowerCase().includes(cleanQuery.toLowerCase()) ||
            a.tags.some((t) => t.toLowerCase() === cleanQuery.toLowerCase())
        );
        if (found) {
          onStatusUpdate?.('تم استرجاع المرجع المعتمد من قاعدة بيانات الجهاز ✓');
          return found;
        }
      } catch (dbErr) {
        console.warn('Could not read encyclopedia table from IndexedDB:', dbErr);
      }
    }

    // Step 2: Call Backend Knowledge Resolver (Gemini API)
    onStatusUpdate?.('استدعاء محرك المعرفة الموسوعي (Gemini Knowledge Resolver)...');
    const response = await fetch('/api/knowledge-resolver', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        query: cleanQuery,
        categoryHint,
      }),
    });

    if (!response.ok) {
      const errData = await response.json().catch(() => ({}));
      throw new Error(errData.error || 'فشل الاتصال بمحرك حل المعرفة العلمي');
    }

    const data = await response.json();
    if (!data.success || !data.article) {
      throw new Error(data.error || 'تعذر استخراج مرجع علمي دقيق لهذا المصطلح');
    }

    const article: EncyclopediaArticle = data.article;

    // Step 3: Persist to IndexedDB for seamless offline usage
    try {
      await offlineDb.encyclopedia.put(article);
    } catch (saveErr) {
      console.warn('Could not persist resolved article to IndexedDB:', saveErr);
    }

    onStatusUpdate?.('تم توثيق وحفظ المرجع الموسوعي بنجاح ✓');
    return article;
  }

  /**
   * Search across all stored encyclopedia articles (local memory + IndexedDB)
   */
  public async searchAll(
    query: string,
    category?: string
  ): Promise<EncyclopediaArticle[]> {
    const q = query.trim().toLowerCase();
    const staticArticles = COMPREHENSIVE_ENCYCLOPEDIA_ARTICLES;

    let dbArticles: EncyclopediaArticle[] = [];
    try {
      dbArticles = await offlineDb.encyclopedia.toArray();
    } catch {}

    const all = [...staticArticles];
    const seenIds = new Set(all.map((a) => a.id));

    for (const a of dbArticles) {
      if (!seenIds.has(a.id)) {
        all.push(a);
        seenIds.add(a.id);
      }
    }

    return all.filter((art) => {
      if (category && category !== 'الكل' && art.category !== category) {
        return false;
      }
      if (!q) return true;

      const titleMatch = art.title.toLowerCase().includes(q);
      const summaryMatch = art.summary.toLowerCase().includes(q);
      const tagsMatch = art.tags?.some((t) => t.toLowerCase().includes(q));
      const contentMatch = art.markdownContent?.toLowerCase().includes(q);
      const formulaMatch = art.formulaLatex?.toLowerCase().includes(q);

      return titleMatch || summaryMatch || tagsMatch || contentMatch || formulaMatch;
    });
  }
}

export const knowledgeResolver = new KnowledgeResolverService();
