/**
 * D.CORE Academic Arabic Text Reshaper & PDF Extractor Normalizer
 * Preserves pure, authentic Arabic text from digital and scanned PDFs.
 * 
 * Accurately handles:
 * 1. Unicode Arabic Presentation Forms-A & B (e.g. ﹰ ﹱ ﺎ ﺏ ﺕ ﺔ ﺛ ﺝ ... -> standard Arabic).
 * 2. Removal of zero-width non-joiners, control glyphs, and tatweel (kashida).
 * 3. Reconnection of spaced-out letters (e.g. "ا ل ك ت ا ب" -> "الكتاب").
 * 4. Safe preservation of regular Arabic words, Tanween Fath (e.g. أولاً, مثلاً, دائماً), and proper RTL order.
 */

// Mapping table for Unicode Arabic Presentation Forms-A & Forms-B to Standard Arabic Characters
const PRESENTATION_FORMS_MAP: Record<string, string> = {
  // Lam-Alef forms
  '\uFEF5': 'لآ', '\uFEF6': 'لآ',
  '\uFEF7': 'لأ', '\uFEF8': 'لأ',
  '\uFEF9': 'لإ', '\uFEFA': 'لإ',
  '\uFEFB': 'لا', '\uFEFC': 'لا',

  // Alef with madd / hamza
  '\uFE80': 'ء',
  '\uFE81': 'آ', '\uFE82': 'آ',
  '\uFE83': 'أ', '\uFE84': 'أ',
  '\uFE85': 'ؤ', '\uFE86': 'ؤ',
  '\uFE87': 'إ', '\uFE88': 'إ',
  '\uFE89': 'ئ', '\uFE8A': 'ئ', '\uFE8B': 'ئ', '\uFE8C': 'ئ',
  '\uFE8D': 'ا', '\uFE8E': 'ا',

  // Baa, Taa, Thaa
  '\uFE8F': 'ب', '\uFE90': 'ب', '\uFE91': 'ب', '\uFE92': 'ب',
  '\uFE93': 'ة', '\uFE94': 'ة',
  '\uFE95': 'ت', '\uFE96': 'ت', '\uFE97': 'ت', '\uFE98': 'ت',
  '\uFE99': 'ث', '\uFE9A': 'ث', '\uFE9B': 'ث', '\uFE9C': 'ث',

  // Jeem, Haa, Khaa
  '\uFE9D': 'ج', '\uFE9E': 'ج', '\uFE9F': 'ج', '\uFEA0': 'ج',
  '\uFEA1': 'ح', '\uFEA2': 'ح', '\uFEA3': 'ح', '\uFEA4': 'ح',
  '\uFEA5': 'خ', '\uFEA6': 'خ', '\uFEA7': 'خ', '\uFEA8': 'خ',

  // Dal, Thal, Raa, Zay
  '\uFEA9': 'د', '\uFEAA': 'د',
  '\uFEAB': 'ذ', '\uFEAC': 'ذ',
  '\uFEAD': 'ر', '\uFEAE': 'ر',
  '\uFEAF': 'ز', '\uFEB0': 'ز',

  // Seen, Sheen, Saad, Daad
  '\uFEB1': 'س', '\uFEB2': 'س', '\uFEB3': 'س', '\uFEB4': 'س',
  '\uFEB5': 'ش', '\uFEB6': 'ش', '\uFEB7': 'ش', '\uFEB8': 'ش',
  '\uFEB9': 'ص', '\uFEBA': 'ص', '\uFEBB': 'ص', '\uFEBC': 'ص',
  '\uFEBD': 'ض', '\uFEBE': 'ض', '\uFEBF': 'ض', '\uFEC0': 'ض',

  // Taa, Zaa, Ayn, Ghayn
  '\uFEC1': 'ط', '\uFEC2': 'ط', '\uFEC3': 'ط', '\uFEC4': 'ط',
  '\uFEC5': 'ظ', '\uFEC6': 'ظ', '\uFEC7': 'ظ', '\uFEC8': 'ظ',
  '\uFEC9': 'ع', '\uFECA': 'ع', '\uFECB': 'ع', '\uFECC': 'ع',
  '\uFECD': 'غ', '\uFECE': 'غ', '\uFECF': 'غ', '\uFED0': 'غ',

  // Faa, Qaaf, Kaaf
  '\uFED1': 'ف', '\uFED2': 'ف', '\uFED3': 'ف', '\uFED4': 'ف',
  '\uFED5': 'ق', '\uFED6': 'ق', '\uFED7': 'ق', '\uFED8': 'ق',
  '\uFED9': 'ك', '\uFEDA': 'ك', '\uFEDB': 'ك', '\uFEDC': 'ك',

  // Laam, Meem, Noon, Haa
  '\uFEDD': 'ل', '\uFEDE': 'ل', '\uFEDF': 'ل', '\uFEE0': 'ل',
  '\uFEE1': 'م', '\uFEE2': 'م', '\uFEE3': 'م', '\uFEE4': 'م',
  '\uFEE5': 'ن', '\uFEE6': 'ن', '\uFEE7': 'ن', '\uFEE8': 'ن',
  '\uFEE9': 'ه', '\uFEEA': 'ه', '\uFEEB': 'ه', '\uFEEC': 'ه',

  // Waaw, Alef Maksura, Yaa
  '\uFEED': 'و', '\uFEEE': 'و',
  '\uFEEF': 'ى', '\uFEF0': 'ى',
  '\uFEF1': 'ي', '\uFEF2': 'ي', '\uFEF3': 'ي', '\uFEF4': 'ي',

  // Tanween & Tashkeel presentation forms
  '\uFE70': ' ً', '\uFE71': ' ً',
  '\uFE72': ' ٌ',
  '\uFE74': ' ٍ',
  '\uFE76': ' َ', '\uFE77': ' َ',
  '\uFE78': ' ُ', '\uFE79': ' ُ',
  '\uFE7A': ' ِ', '\uFE7B': ' ِ',
  '\uFE7C': ' ّ', '\uFE7D': ' ّ',
  '\uFE7E': ' ْ',
};

/**
 * 1. Normalize Unicode Presentation Forms-A and Forms-B to Standard Arabic characters
 */
export function normalizePresentationForms(text: string): string {
  if (!text) return '';
  let result = '';
  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    if (PRESENTATION_FORMS_MAP[char]) {
      result += PRESENTATION_FORMS_MAP[char];
    } else {
      result += char;
    }
  }
  return result;
}

/**
 * 2. Reconnect letters that were extracted with single spaces between each character
 * (e.g. "ا ل ع ص ر  ا ل ح د ي ث" -> "العصر الحديث")
 */
export function reconnectDisjointedSpacedLetters(text: string): string {
  if (!text) return '';
  return text.replace(
    /(?:[\u0600-\u06FF]\s){3,}[\u0600-\u06FF]/g,
    (match) => {
      // Split on double space first (which marks word boundaries)
      const words = match.split(/\s{2,}/);
      return words
        .map((w) => w.replace(/\s+/g, ''))
        .join(' ');
    }
  );
}

/**
 * Safely clean and normalize extracted PDF and OCR text:
 * - Normalizes presentation forms
 * - Removes tatweel and hidden control characters
 * - Reconnects single spaced letters
 * - Cleans multiple whitespace while preserving paragraph structure
 */
export function cleanAndReshapePdfText(rawText: string): string {
  if (!rawText) return '';

  // Normalize Unicode compatibility forms before any structural parsing.
  let processed = normalizePresentationForms(rawText).normalize('NFKC');

  // Remove extraction artifacts while preserving Arabic, Latin, numbers, formulas, and layout.
  processed = processed
    .replace(/[\uFFFD\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '')
    .replace(/[\u200B\u200C\u200D\u2060\uFEFF]/g, '')
    .replace(/[\u00AD]/g, '')
    .replace(/([\u0600-\u06FF])[-‐‑‒–—]\s*\n\s*(?=[\u0600-\u06FF])/g, '$1')
    .replace(/([^\n])\n(?=[\u0600-\u06FF])/g, '$1 ');

  // Step 2: Remove zero-width non-joiners or weird PDF glyph spacers (U+200C, U+200B, etc.) inside words
  processed = processed
    .replace(/([\u0600-\u06FF])[\u200B\u200C\u200D\uFEFF]([\u0600-\u06FF])/g, '$1$2')
    .replace(/[\u0640]/g, ''); // Remove tatweel (kashida)

  // Step 3: Reconnect disjointed single letters (e.g. "ا ل ع ص ر")
  processed = reconnectDisjointedSpacedLetters(processed);

  // Step 4: Fix clearly reversed words (ONLY words that start with Ta' Marbutah 'ة' which is linguistically impossible in Arabic)
  processed = processed.replace(/\bة[\u0600-\u06FF]{2,}\b/g, (w) => {
    return Array.from(w).reverse().join('');
  });

  // Step 5: Clean multiple spaces while preserving paragraphs and lines
  const cleaned = processed
    .replace(/[ \t]+/g, ' ')
    .replace(/\n\s*\n\s*\n+/g, '\n\n')
    .trim();

  return cleaned;
}
