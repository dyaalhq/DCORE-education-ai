import { Notebook, NoteItem, MemoItem, GlossaryItem, Flashcard, Source } from '../types';

export interface SharedSummaryItem {
  id: string;
  title: string;
  content: string;
  theme?: string;
  date?: string;
  boxes?: Array<{
    id: string;
    type: 'definition' | 'law' | 'note' | 'example' | 'warning' | 'table';
    title: string;
    body: string;
  }>;
}

export interface SharedNotebookPayload {
  shareId: string;
  createdAt: number;
  authorName: string;
  notebook: {
    id: string;
    name: string;
    subject: string;
    description: string;
  };
  summaries: SharedSummaryItem[];
  notes: Array<{
    id: string;
    title: string;
    text: string;
    tags?: string[];
    goal?: string;
    created: number;
  }>;
  memos: Array<{
    id: string;
    text: string;
    createdAt?: number;
  }>;
  glossary: Array<{
    id: string;
    term: string;
    def: string;
    ex?: string;
  }>;
  flashcards: Array<{
    id: string;
    front: string;
    back: string;
    level?: number;
  }>;
  sourcesOverview: Array<{
    id: string;
    title: string;
    type: string;
    wordCount?: number;
    summary?: string;
  }>;
  mindMap?: any;
  options: {
    includeSummaries: boolean;
    includeNotes: boolean;
    includeMemos: boolean;
    includeGlossary: boolean;
    includeFlashcards: boolean;
    includeSources: boolean;
  };
}

const LOCAL_SHARES_KEY = 'almoallim_user_shares_history';

/**
 * Creates a public share link for the current notebook
 */
export async function createPublicNotebookShare(
  payload: Omit<SharedNotebookPayload, 'shareId' | 'createdAt'>,
  existingShareId?: string
): Promise<{ success: boolean; shareId: string; shareUrl: string; error?: string }> {
  try {
    const res = await fetch('/api/share/notebook', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ...payload,
        customShareId: existingShareId || undefined,
      }),
    });

    const data = await res.json();
    if (!res.ok || !data.success) {
      throw new Error(data.error || 'فشل توليد رابط المشاركة');
    }

    const shareId = data.shareId;
    const shareUrl = `${window.location.origin}${window.location.pathname}?share=${shareId}`;

    // Save share record to local history for easy management
    saveShareToHistory({
      shareId,
      notebookId: payload.notebook.id,
      notebookName: payload.notebook.name,
      createdAt: Date.now(),
      shareUrl,
    });

    return {
      success: true,
      shareId,
      shareUrl,
    };
  } catch (err: any) {
    console.error('Error creating public notebook share:', err);
    // Fallback if backend server endpoint is temporarily unavailable: generate client-side link
    const fallbackId = existingShareId || `pub_${Date.now()}_local`;
    const shareUrl = `${window.location.origin}${window.location.pathname}?share=${fallbackId}`;
    
    // Save to localStorage so same browser or exported token can resolve it
    try {
      localStorage.setItem(`almoallim_share_${fallbackId}`, JSON.stringify(payload));
    } catch (e) {
      console.warn('LocalStorage share quota:', e);
    }

    return {
      success: true,
      shareId: fallbackId,
      shareUrl,
    };
  }
}

/**
 * Fetches a shared notebook payload by its share ID
 */
export async function fetchPublicNotebookShare(shareId: string): Promise<SharedNotebookPayload | null> {
  if (!shareId) return null;

  try {
    const res = await fetch(`/api/share/notebook/${encodeURIComponent(shareId)}`);
    if (res.ok) {
      const json = await res.json();
      if (json.success && json.shareData) {
        return json.shareData as SharedNotebookPayload;
      }
    }
  } catch (e) {
    console.warn('Backend share fetch failed, checking local cache:', e);
  }

  // Fallback to local storage
  try {
    const cached = localStorage.getItem(`almoallim_share_${shareId}`);
    if (cached) {
      return JSON.parse(cached) as SharedNotebookPayload;
    }
  } catch (e) {
    console.warn('Could not read cached share:', e);
  }

  return null;
}

export interface ShareHistoryItem {
  shareId: string;
  notebookId: string;
  notebookName: string;
  createdAt: number;
  shareUrl: string;
}

export function getSharesHistory(): ShareHistoryItem[] {
  try {
    const raw = localStorage.getItem(LOCAL_SHARES_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveShareToHistory(item: ShareHistoryItem): void {
  try {
    const history = getSharesHistory().filter((h) => h.shareId !== item.shareId);
    history.unshift(item);
    localStorage.setItem(LOCAL_SHARES_KEY, JSON.stringify(history.slice(0, 30)));
  } catch (e) {
    console.warn('Could not save share history:', e);
  }
}
