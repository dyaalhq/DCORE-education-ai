/**
 * Fast In-Memory & IndexedDB Vector Database (RAG Vector Store)
 * Optimized for textbook retrieval, semantic search, and token-limit prevention.
 */
import { SourceChunk, Citation } from '../types';
import { normalizeArabicWord, tokenize, vectorize, cosineSim, isComprehensiveQuery } from './retrieval';

export interface VectorRecord {
  id: string;
  sourceId: string;
  sourceTitle: string;
  notebookId: string;
  pageNumber?: number | null;
  section?: string;
  text: string;
  vector: Map<string, number>;
  tokens: string[];
  tokenEstimate: number;
  katex?: string[];
  hasKatex?: boolean;
}

export interface VectorSearchResult {
  chunk: SourceChunk;
  score: number;
  similarity: number;
  confidence: number; // 0 to 100%
  pageNumber?: number | null;
  katex?: string[];
  hasKatex?: boolean;
}

/**
 * Detect and extract LaTeX / KaTeX equations from text
 * Identifies inline ($...$), display ($$...$$), environments (\begin{...}...\end{...}),
 * and math commands (\frac, \sqrt, \sum, etc.) as well as explicit <katex> tags.
 */
export function extractKatexEquations(text: string): string[] {
  if (!text) return [];
  const equations: string[] = [];
  const seen = new Set<string>();

  const addEq = (eq: string) => {
    const trimmed = eq.trim();
    if (trimmed && !seen.has(trimmed)) {
      seen.add(trimmed);
      equations.push(trimmed);
    }
  };

  // 1. Explicit <katex>...</katex> or [katex]...[/katex] tags
  const tagRegex = /<(?:katex|latex)[^>]*>([\s\S]*?)<\/(?:katex|latex)>|\[katex\]([\s\S]*?)\[\/katex\]/gi;
  let match: RegExpExecArray | null;
  while ((match = tagRegex.exec(text)) !== null) {
    addEq(match[1] || match[2]);
  }

  // 2. Display math: $$...$$ or \[...\]
  const displayRegex = /\$\$([\s\S]*?)\$\$|\\\[([\s\S]*?)\\\]/g;
  while ((match = displayRegex.exec(text)) !== null) {
    addEq(match[1] || match[2]);
  }

  // 3. LaTeX math environments: \begin{...}...\end{...}
  const envRegex = /\\begin\{(equation|align|gather|matrix|bmatrix|pmatrix|vmatrix|cases|array)\*?\}[\s\S]*?\\end\{\1\*?\}/g;
  while ((match = envRegex.exec(text)) !== null) {
    addEq(match[0]);
  }

  // 4. Inline math: $...$ or \(...\)
  const inlineRegex = /(?:^|[^\\])\$([^\$\n\r]+?)\$|\\\(([\s\S]*?)\\\)/g;
  while ((match = inlineRegex.exec(text)) !== null) {
    const candidate = (match[1] || match[2] || '').trim();
    if (
      candidate.length >= 2 &&
      !/^\d+(?:\.\d+)?$/.test(candidate) &&
      (/[\+\-\=\\\^_\{\}\(\)\[\]\/\*]|frac|sqrt|alpha|beta|theta|pi|int|sum/i.test(candidate))
    ) {
      addEq(candidate);
    }
  }

  // 5. Standalone LaTeX command sequences like \frac{a}{b}, \sqrt{x}, \sum_{i=1}^n
  const cmdRegex = /\\(?:frac\{[^\}]*\}\{[^\}]*\}|sqrt(?:\[[^\]]*\])?\{[^\}]*\}|sum(?:_[^\^]*\^[^\s]*)?|int(?:_[^\^]*\^[^\s]*)?|[a-zA-Z]+(?:\^\{[^\}]*\}|_{[^\}]*})+)/g;
  while ((match = cmdRegex.exec(text)) !== null) {
    addEq(match[0]);
  }

  return equations;
}

const DB_NAME = 'DCoreSchooler_VectorDB';
const DB_VERSION = 1;
const STORE_NAME = 'vectors';

export interface IndexProgress {
  processed: number;
  total: number;
  percent: number;
  currentChunkTitle?: string;
  status: string;
}

export type IndexProgressCallback = (progress: IndexProgress) => void;


class VectorDatabase {
  private inMemoryIndex = new Map<string, VectorRecord>();
  private idfMap = new Map<string, number>();
  private totalDocs = 0;
  private dbPromise: Promise<IDBDatabase | null> | null = null;
  private activeProgress: IndexProgress | null = null;
  private progressListeners = new Set<IndexProgressCallback>();

  public getActiveProgress(): IndexProgress | null {
    return this.activeProgress;
  }

  public subscribeProgress(callback: IndexProgressCallback): () => void {
    this.progressListeners.add(callback);
    try {
      if (this.activeProgress) {
        callback(this.activeProgress);
      }
    } catch (e) {
      console.warn('Error in progress listener initialization:', e);
    }
    return () => {
      this.progressListeners.delete(callback);
    };
  }

  private notifyProgress(progress: IndexProgress | null) {
    this.activeProgress = progress;
    this.progressListeners.forEach((cb) => {
      try {
        cb(progress as IndexProgress);
      } catch (err) {
        console.error('Progress listener error:', err);
      }
    });
  }

  constructor() {
    this.initIndexedDB();
  }

  private initIndexedDB(): Promise<IDBDatabase | null> {
    if (this.dbPromise) return this.dbPromise;
    if (typeof window === 'undefined' || !window.indexedDB) {
      this.dbPromise = Promise.resolve(null);
      return this.dbPromise;
    }

    this.dbPromise = new Promise((resolve) => {
      try {
        const req = window.indexedDB.open(DB_NAME, DB_VERSION);
        req.onupgradeneeded = () => {
          const db = req.result;
          if (!db.objectStoreNames.contains(STORE_NAME)) {
            const store = db.createObjectStore(STORE_NAME, { keyPath: 'id' });
            store.createIndex('sourceId', 'sourceId', { unique: false });
            store.createIndex('notebookId', 'notebookId', { unique: false });
          }
        };
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => resolve(null);
      } catch (e) {
        resolve(null);
      }
    });

    return this.dbPromise;
  }

  /**
   * Non-blocking Asynchronous Batched Vector Indexing with Web Worker and Progress Feedback:
   * Offloads vectorization and equation extraction to a background Web Worker when available,
   * with smooth progress reporting to guarantee zero main-thread freezes.
   */
  public async indexChunksAsync(
    chunks: SourceChunk[],
    onProgress?: IndexProgressCallback,
    batchSize = 12
  ): Promise<void> {
    if (!chunks || chunks.length === 0) return;

    // Direct asynchronous batched indexing with microtask yielding
    const total = chunks.length;
    let processed = 0;

    for (let i = 0; i < total; i += batchSize) {
      const batch = chunks.slice(i, i + batchSize);

      for (const chunk of batch) {
        if (!chunk) continue;
        const chunkText = typeof chunk.text === 'string' ? chunk.text : (chunk as any)?.content || '';
        const tokens = tokenize(chunkText);
        const vector = vectorize(chunkText);
        const tokenEstimate = Math.ceil(chunkText.length / 4);

        // Extract LaTeX / KaTeX equations and preserve in metadata
        const katexEquations = extractKatexEquations(chunkText);
        const hasKatex = katexEquations.length > 0;
        if (hasKatex) {
          chunk.metadata = {
            ...chunk.metadata,
            katex: katexEquations,
            hasKatex: true,
            hasMath: true,
          };
        }

        const record: VectorRecord = {
          id: chunk.id,
          sourceId: chunk.sourceId,
          sourceTitle: chunk.sourceTitle || 'مصدر مرجعي',
          notebookId: chunk.notebookId || '',
          pageNumber: chunk.pageNumber,
          section: chunk.section,
          text: chunkText,
          vector,
          tokens,
          tokenEstimate,
          katex: katexEquations,
          hasKatex,
        };

        this.inMemoryIndex.set(chunk.id, record);
        processed++;
      }

      const percent = Math.min(100, Math.round((processed / total) * 100));
      const progressPayload: IndexProgress = {
        processed,
        total,
        percent,
        currentChunkTitle: batch[batch.length - 1]?.sourceTitle || 'كتاب دراسي',
        status: `جاري فهرسة وتضمين المقاطع: ${processed} من ${total} (${percent}%)`,
      };
      this.notifyProgress(progressPayload);
      onProgress?.(progressPayload);

      // Yield to the event loop so the browser UI thread never freezes
      await new Promise((resolve) => setTimeout(resolve, 0));
    }

    this.recalculateIDF();
    setTimeout(() => {
      this.notifyProgress(null);
    }, 1200);
  }

  /**
   * Index chunks into the vector store (delegates to async non-blocking method)
   */
  public async indexChunks(
    chunks: SourceChunk[],
    onProgress?: IndexProgressCallback
  ): Promise<void> {
    return this.indexChunksAsync(chunks, onProgress);
  }

  /**
   * Recalculate IDF for hybrid BM25 + dense cosine retrieval
   */
  private recalculateIDF(): void {
    this.totalDocs = this.inMemoryIndex.size;
    const docFreq = new Map<string, number>();

    for (const record of this.inMemoryIndex.values()) {
      const uniqueTokens = new Set(record.tokens);
      for (const t of uniqueTokens) {
        docFreq.set(t, (docFreq.get(t) || 0) + 1);
      }
    }

    this.idfMap.clear();
    for (const [token, df] of docFreq.entries()) {
      this.idfMap.set(token, Math.log((this.totalDocs + 1) / (df + 1)) + 1.0);
    }
  }

  /**
   * Search vector store for the most relevant pages/chunks to answer the student's question
   */
  public search(
    query: string,
    options: {
      notebookId?: string;
      sourceIds?: string[];
      topK?: number;
      minScore?: number;
    } = {}
  ): VectorSearchResult[] {
    const isBroad = isComprehensiveQuery(query);
    const defaultTopK = isBroad ? 18 : 6;
    const { notebookId, sourceIds, topK = defaultTopK, minScore = isBroad ? 0.08 : 0.15 } = options;
    if (!query.trim() || this.inMemoryIndex.size === 0) return [];

    const queryTokens = tokenize(query);
    const queryVector = vectorize(query);

    const candidates: Array<{ record: VectorRecord; score: number; similarity: number }> = [];

    for (const record of this.inMemoryIndex.values()) {
      // Filter by notebook or selected sources
      if (notebookId && record.notebookId && record.notebookId !== notebookId) {
        continue;
      }
      if (sourceIds !== undefined) {
        if (sourceIds.length === 0 || !sourceIds.includes(record.sourceId)) {
          continue;
        }
      }

      // 1. Vector Cosine Similarity (Subword & semantic representation)
      const cosSim = cosineSim(queryVector, record.vector);

      // 2. Lexical / IDF BM25 Score
      let lexicalScore = 0;
      const recordTokenSet = new Set(record.tokens);
      for (const qt of queryTokens) {
        if (recordTokenSet.has(qt)) {
          const idf = this.idfMap.get(qt) || 1.0;
          lexicalScore += idf;
        }
      }

      // Normalization
      const maxPossibleLexical = queryTokens.reduce((sum, qt) => sum + (this.idfMap.get(qt) || 1.0), 0) || 1;
      const normalizedLexical = lexicalScore / maxPossibleLexical;

      // 3. Page / Section heading priority
      let sectionBoost = 1.0;
      if (record.section) {
        const normSection = normalizeArabicWord(record.section);
        for (const qt of queryTokens) {
          if (normSection.includes(qt)) {
            sectionBoost += 0.3;
          }
        }
      }

      // Hybrid combination
      const combinedScore = (cosSim * 0.55 + normalizedLexical * 0.45) * sectionBoost;

      if (combinedScore >= minScore || cosSim > 0.3) {
        candidates.push({
          record,
          score: combinedScore,
          similarity: cosSim,
        });
      }
    }

    // Sort by score descending
    candidates.sort((a, b) => b.score - a.score);

    return candidates.slice(0, topK).map((c) => {
      const confidence = Math.min(100, Math.round(c.score * 100));
      return {
        chunk: {
          id: c.record.id,
          sourceId: c.record.sourceId,
          sourceTitle: c.record.sourceTitle,
          notebookId: c.record.notebookId,
          text: c.record.text,
          pageNumber: c.record.pageNumber,
          section: c.record.section,
          metadata: {
            katex: c.record.katex,
            hasKatex: c.record.hasKatex,
            hasMath: c.record.hasKatex,
          },
        },
        score: c.score,
        similarity: c.similarity,
        confidence,
        pageNumber: c.record.pageNumber,
        katex: c.record.katex,
        hasKatex: c.record.hasKatex,
      };
    });
  }

  /**
   * Format retrieved chunks into concise RAG context for Gemini to explain without token overflow
   */
  public formatRAGContext(
    results: VectorSearchResult[],
    query: string
  ): {
    contextText: string;
    citations: Citation[];
    pagesReferenced: number[];
  } {
    if (results.length === 0) {
      return { contextText: '', citations: [], pagesReferenced: [] };
    }

    const citations: Citation[] = [];
    const pagesReferenced = new Set<number>();
    let contextText = '';

    for (let i = 0; i < results.length; i++) {
      const { chunk, confidence, katex } = results[i];
      const pageInfo = chunk.pageNumber ? `(الصفحة: ${chunk.pageNumber})` : '';
      if (chunk.pageNumber) {
        pagesReferenced.add(chunk.pageNumber);
      }

      const quote = chunk.text.length > 200 ? chunk.text.slice(0, 195) + '...' : chunk.text;

      citations.push({
        sourceId: chunk.sourceId,
        sourceTitle: chunk.sourceTitle,
        pageNumber: chunk.pageNumber,
        section: chunk.section,
        quote,
        confidenceScore: confidence,
        confidenceLevel: confidence > 70 ? 'high' : confidence > 45 ? 'medium' : 'moderate',
        chunkId: chunk.id,
        katexEquations: katex || chunk.metadata?.katex,
      });

      const mathMetaInfo = katex && katex.length > 0
        ? `\n[معادلات وصيغ رياضية موثقة (KaTeX / LaTeX): ${katex.map((eq) => `$$${eq}$$`).join(' ')}]`
        : '';

      contextText += `\n[مقطع ${i + 1} - المصدر: ${chunk.sourceTitle} ${pageInfo}]${mathMetaInfo}\n${chunk.text}\n`;
    }

    return {
      contextText: contextText.trim(),
      citations,
      pagesReferenced: Array.from(pagesReferenced).sort((a, b) => a - b),
    };
  }

  public clear(): void {
    this.inMemoryIndex.clear();
    this.idfMap.clear();
    this.totalDocs = 0;
  }
}

export const vectorStore = new VectorDatabase();
