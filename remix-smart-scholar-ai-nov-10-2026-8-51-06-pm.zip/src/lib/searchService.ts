/**
 * Client-Side Intelligent Web Search & Knowledge Extraction Service
 * Integrates with /api/search and /api/search/export
 * Extracts pure clean text, indexes into interconnected semantic blocks,
 * and exports structured JSON containing titles, links, and content summaries.
 */

export interface WebSearchResultDataBlock {
  id: string;
  type: 'concept' | 'definition' | 'theorem' | 'procedure' | 'fact';
  heading: string;
  body: string;
  confidence: number;
}

export interface ClientSearchResultItem {
  id: string;
  title: string;
  uri: string;
  cleanContent?: string;
  summary: string;
  executiveSummary?: string;
  keyTopics?: string[];
  dataBlocks?: WebSearchResultDataBlock[];
  indexingStatus?: string;
  isEducationalBook?: boolean;
}

export interface ClientSearchPayload {
  exportedAt: string;
  engine: string;
  query: string;
  totalResults: number;
  indexingStatus: string;
  overviewAnswer?: string;
  results: {
    id: string;
    title: string;
    uri: string;
    summary: string;
    executiveSummary?: string;
    keyTopics?: string[];
    interconnectedBlocksCount: number;
    blocks?: WebSearchResultDataBlock[];
    cleanContentPreview?: string;
  }[];
}

/**
 * Execute smart search through the application backend
 */
export async function executeSmartSearch(
  query: string,
  mode: 'curriculum' | 'general' = 'curriculum'
): Promise<{
  results: ClientSearchResultItem[];
  overviewAnswer?: string;
  query: string;
}> {
  if (!query || !query.trim()) {
    return { results: [], query: '' };
  }

  const res = await fetch('/api/search', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query: query.trim(), mode }),
  });

  if (!res.ok) {
    throw new Error(`Search request failed with status: ${res.status}`);
  }

  const data = await res.json();
  const rawSources = data.sources || [];

  const results: ClientSearchResultItem[] = rawSources.map((s: any, idx: number) => ({
    id: s.id || `res_${Date.now()}_${idx}`,
    title: s.title || 'مصدر تعليمي بدون عنوان',
    uri: s.uri || '',
    cleanContent: s.cleanContent || s.snippet || '',
    summary: s.summary || s.snippet || '',
    executiveSummary: s.executiveSummary,
    keyTopics: s.keyTopics || [],
    dataBlocks: s.dataBlocks || [],
    indexingStatus: s.indexingStatus || 'جاهز للاستجواب الدقيق',
    isEducationalBook: s.isEducationalBook || false,
  }));

  return {
    results,
    overviewAnswer: data.text || data.overviewAnswer || '',
    query,
  };
}

/**
 * Formats client search results into an organized JSON payload
 * containing titles, links, summaries, and interconnected data blocks.
 */
export function formatSearchResultsAsJsonPayload(
  query: string,
  items: ClientSearchResultItem[],
  overviewAnswer?: string
): ClientSearchPayload {
  return {
    exportedAt: new Date().toISOString(),
    engine: 'محرك الفهرسة والبحث المعرفي الذكي (NotebookLM Engine)',
    query,
    totalResults: items.length,
    indexingStatus: 'فهرسة دقيقة لكتل البيانات المترابطة',
    overviewAnswer: overviewAnswer || undefined,
    results: items.map((item) => ({
      id: item.id,
      title: item.title,
      uri: item.uri,
      summary: item.summary,
      executiveSummary: item.executiveSummary,
      keyTopics: item.keyTopics,
      interconnectedBlocksCount: item.dataBlocks?.length || 0,
      blocks: item.dataBlocks,
      cleanContentPreview: item.cleanContent ? item.cleanContent.slice(0, 300) + '...' : undefined,
    })),
  };
}

/**
 * Exports search results as a formatted, indented JSON string
 */
export function exportSearchResultsJsonString(
  query: string,
  items: ClientSearchResultItem[],
  overviewAnswer?: string
): string {
  const payload = formatSearchResultsAsJsonPayload(query, items, overviewAnswer);
  return JSON.stringify(payload, null, 2);
}

/**
 * Downloads search results as a structured JSON file in the browser
 */
export function downloadSearchResultsAsJsonFile(
  query: string,
  items: ClientSearchResultItem[],
  overviewAnswer?: string,
  customFileName?: string
): void {
  const jsonString = exportSearchResultsJsonString(query, items, overviewAnswer);
  const blob = new Blob([jsonString], { type: 'application/json;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  const safeName = customFileName || `نتائج_البحث_${query.replace(/[^\w\u0600-\u06FF]/g, '_').slice(0, 30)}_${Date.now()}.json`;
  a.href = url;
  a.download = safeName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
