/**
 * StudySpeechEngine - Backward-compatible Bridge to TextToSpeechService
 */

import {
  textToSpeechService,
  speakText as globalSpeakText,
  stopSpeaking as globalStopSpeaking,
  pauseSpeaking as globalPauseSpeaking,
  resumeSpeaking as globalResumeSpeaking,
  TTSSpeechOptions,
  TTSState,
  TTSListener,
} from './TextToSpeechService';

export type SpeechOptions = TTSSpeechOptions;
export type SpeechState = TTSState;
export type SpeechListener = TTSListener;

export const studySpeechEngine = textToSpeechService;

export const speakText = globalSpeakText;
export const stopSpeaking = globalStopSpeaking;
export const pauseSpeaking = globalPauseSpeaking;
export const resumeSpeaking = globalResumeSpeaking;

export { textToSpeechService, TextToSpeechService, useTextToSpeech } from './TextToSpeechService';
