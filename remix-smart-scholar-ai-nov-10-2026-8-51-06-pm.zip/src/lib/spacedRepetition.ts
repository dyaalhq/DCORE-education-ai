// Advanced Spaced Repetition System (SuperMemo SM-2 & Leitner Hybrid Algorithm)
// Scientifically optimizes memory consolidation and retention intervals.

import { Flashcard } from '../types';

export type ReviewRating = 'again' | 'hard' | 'good' | 'easy';

export interface SpacedRepetitionResult {
  level: number;
  reps: number;
  intervalDays: number;
  easeFactor: number;
  nextReview: number;
  mistake: boolean;
  ratingLabel: string;
}

/**
 * Calculates the next review date and interval using the SuperMemo SM-2 algorithm.
 * 
 * Grades:
 * - 'again' (Grade 1): Complete blackout / incorrect. Resets repetitions, sets next review to 10-30 minutes.
 * - 'hard'  (Grade 3): Correct with significant hesitation / difficulty. Slight decrease in EF.
 * - 'good'  (Grade 4): Correct with ideal effort. Standard SM-2 interval progression.
 * - 'easy'  (Grade 5): Perfect recall / effortless. Increases EF, awards longer interval bonus.
 */
export function calculateSM2Schedule(
  card: Flashcard,
  rating: ReviewRating | boolean
): SpacedRepetitionResult {
  // Normalize boolean ratings for backward compatibility
  const normalizedRating: ReviewRating = typeof rating === 'boolean'
    ? (rating ? 'good' : 'again')
    : rating;

  const currentEase = typeof card.easeFactor === 'number' && card.easeFactor >= 1.3 ? card.easeFactor : 2.5;
  const currentReps = typeof card.reps === 'number' ? card.reps : (card.level || 0);

  let newReps = currentReps;
  let newEase = currentEase;
  let intervalDays = 1;
  let nextReviewDelayMs = 24 * 60 * 60 * 1000; // 1 day
  let mistake = false;
  let ratingLabel = 'جيد';

  // Quality grade (0-5 scale in SM-2)
  let quality = 4;
  switch (normalizedRating) {
    case 'again':
      quality = 1;
      mistake = true;
      ratingLabel = 'أحتاج مراجعة (إعادة)';
      break;
    case 'hard':
      quality = 3;
      mistake = false;
      ratingLabel = 'صعب';
      break;
    case 'good':
      quality = 4;
      mistake = false;
      ratingLabel = 'متقن (جيد)';
      break;
    case 'easy':
      quality = 5;
      mistake = false;
      ratingLabel = 'سهل ومتقن جداً';
      break;
  }

  if (quality < 3) {
    // Incorrect / Blackout: Reset repetitions
    newReps = 0;
    intervalDays = 0.04; // ~1 hour
    nextReviewDelayMs = 60 * 60 * 1000; // 1 hour for immediate consolidation
    // Ease factor remains unchanged or slightly penalised
    newEase = Math.max(1.3, currentEase - 0.2);
  } else {
    // Correct recall: advance SM-2 repetitions
    if (newReps === 0) {
      intervalDays = 1; // 1 day
      nextReviewDelayMs = 24 * 60 * 60 * 1000;
    } else if (newReps === 1) {
      intervalDays = quality === 5 ? 6 : (quality === 3 ? 3 : 5); // 3-6 days
      nextReviewDelayMs = intervalDays * 24 * 60 * 60 * 1000;
    } else {
      // Interval(n) = Interval(n-1) * EF
      const prevInterval = card.intervalDays || Math.max(1, Math.round((card.nextReview - (card.lastReviewed || Date.now() - 86400000)) / 86400000)) || 5;
      const bonus = quality === 5 ? 1.3 : (quality === 3 ? 0.85 : 1.0);
      intervalDays = Math.max(2, Math.round(prevInterval * currentEase * bonus));
      nextReviewDelayMs = intervalDays * 24 * 60 * 60 * 1000;
    }

    newReps += 1;

    // SM-2 EF update formula: EF' = EF + (0.1 - (5 - quality) * (0.08 + (5 - quality) * 0.02))
    newEase = currentEase + (0.1 - (5 - quality) * (0.08 + (5 - quality) * 0.02));
    if (newEase < 1.3) newEase = 1.3;
    if (newEase > 3.0) newEase = 3.0;
  }

  // Calculate Leitner visual mastery level (0-5)
  const newLevel = Math.min(5, Math.max(0, Math.floor(newReps)));

  return {
    level: newLevel,
    reps: newReps,
    intervalDays: Math.round(intervalDays * 10) / 10,
    easeFactor: Math.round(newEase * 100) / 100,
    nextReview: Date.now() + nextReviewDelayMs,
    mistake,
    ratingLabel,
  };
}

/**
 * Returns formatted human-readable time remaining until next review.
 */
export function formatNextReviewTime(timestamp: number): string {
  const diff = timestamp - Date.now();
  if (diff <= 0) return 'مستحقة الآن';

  const mins = Math.floor(diff / (60 * 1000));
  if (mins < 60) return `خلال ${mins} دقيقة`;

  const hours = Math.floor(mins / 60);
  if (hours < 24) return `خلال ${hours} ساعة`;

  const days = Math.floor(hours / 24);
  if (days === 1) return 'غداً';
  if (days === 2) return 'خلال يومين';
  if (days <= 10) return `خلال ${days} أيام`;
  return `خلال ${days} يوماً`;
}
