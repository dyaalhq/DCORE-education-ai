import { Citation, Source } from '../types';

export interface ResolvedSourceTarget {
  source: Source;
  pageNumber: number;
  highlightText: string;
  zoomScale: number;
  confidenceScore?: number;
  matchedKeywords?: string[];
  section?: string;
  targetAnnotationId?: string;
  chunkId?: string;
}

export interface InTextCitationReference {
  rawMatch: string;
  index: number;
  citationIndex?: number;
  pageNumber?: number;
  sourceTitle?: string;
  resolvedCitation?: Citation;
  resolvedSource?: Source;
}

/**
 * Normalizes text for robust fuzzy substring and citation matching
 */
export function normalizeForSearch(str: string): string {
  if (!str) return '';
  return str
    .toLowerCase()
    .replace(/[\u064B-\u065F\u0670]/g, '') // remove Arabic diacritics
    .replace(/[أإآ]/g, 'ا')
    .replace(/[ة]/g, 'ه')
    .replace(/[ى]/g, 'ي')
    .replace(/[^\w\s\u0600-\u06FF]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Automatically parses in-text AI citations and references from message text:
 * Supports formats like:
 * - [1], [2], [3]
 * - [مصدر 1], [مرجع 1], [مرجع رقم 2]
 * - [ص 14], [صفحة 25], (صفحة 10)
 * - [مصدر: اسم الكتاب، ص 12]
 */
export function parseInTextReferences(
  text: string,
  sources: Source[],
  citations: Citation[] = []
): InTextCitationReference[] {
  if (!text) return [];

  const references: InTextCitationReference[] = [];
  const seenMatches = new Set<string>();

  // 1. Pattern: [مصدر X] or [مرجع X] or [مصدر رقم X] or [مرجع رقم X]
  const explicitRefRegex = /\[(?:مصدر|مرجع)(?:\s+رقم)?\s*(\d+)\]/gi;
  let match;
  while ((match = explicitRefRegex.exec(text)) !== null) {
    const rawMatch = match[0];
    const refNum = parseInt(match[1], 10);
    const citIndex = refNum - 1;

    const resolvedCitation = citations[citIndex];
    let resolvedSource = resolvedCitation 
      ? sources.find((s) => s.id === resolvedCitation.sourceId || s.title === resolvedCitation.sourceTitle)
      : sources[citIndex];

    references.push({
      rawMatch,
      index: match.index,
      citationIndex: citIndex,
      pageNumber: resolvedCitation?.pageNumber || undefined,
      sourceTitle: resolvedCitation?.sourceTitle || resolvedSource?.title,
      resolvedCitation,
      resolvedSource,
    });
    seenMatches.add(`${rawMatch}_${match.index}`);
  }

  // 2. Pattern: [1], [2], etc. (Standard academic citation numbers)
  const numericRefRegex = /\[(\d+)\]/g;
  while ((match = numericRefRegex.exec(text)) !== null) {
    const rawMatch = match[0];
    const key = `${rawMatch}_${match.index}`;
    if (seenMatches.has(key)) continue;

    const refNum = parseInt(match[1], 10);
    const citIndex = refNum - 1;

    if (citIndex >= 0 && citIndex < citations.length) {
      const resolvedCitation = citations[citIndex];
      const resolvedSource = sources.find(
        (s) => s.id === resolvedCitation.sourceId || s.title === resolvedCitation.sourceTitle
      );

      references.push({
        rawMatch,
        index: match.index,
        citationIndex: citIndex,
        pageNumber: resolvedCitation.pageNumber || undefined,
        sourceTitle: resolvedCitation.sourceTitle,
        resolvedCitation,
        resolvedSource,
      });
      seenMatches.add(key);
    }
  }

  // 3. Pattern: [ص 15], [صفحة 24], (صفحة 42)
  const pageRefRegex = /[\[\(](?:ص|صفحة)\s*(\d+)[\]\)]/gi;
  while ((match = pageRefRegex.exec(text)) !== null) {
    const rawMatch = match[0];
    const key = `${rawMatch}_${match.index}`;
    if (seenMatches.has(key)) continue;

    const pageNum = parseInt(match[1], 10);
    // Associate with the closest preceding citation or first source
    const lastCitation = citations[0];
    const targetSource = lastCitation 
      ? sources.find((s) => s.id === lastCitation.sourceId) 
      : sources[0];

    references.push({
      rawMatch,
      index: match.index,
      pageNumber: pageNum,
      resolvedCitation: lastCitation,
      resolvedSource: targetSource,
    });
    seenMatches.add(key);
  }

  return references;
}

/**
 * Resolves a citation or reference into full document navigation parameters:
 * Finds the exact target source, determines the exact relevant page number,
 * extracts the cleanest search quote to highlight, and specifies optimal zoom.
 */
export function resolveSourceTarget(
  citation: Citation,
  sources: Source[]
): ResolvedSourceTarget | null {
  if (!citation) return null;

  // 1. Locate the source document
  let targetSource = sources.find((s) => s.id === citation.sourceId);

  if (!targetSource && citation.sourceTitle) {
    const normTitle = normalizeForSearch(citation.sourceTitle);
    targetSource = sources.find((s) => {
      const normS = normalizeForSearch(s.title);
      return normS === normTitle || normS.includes(normTitle) || normTitle.includes(normS);
    });
  }

  // Fallback to first available source if only one exists in notebook
  if (!targetSource && sources.length === 1) {
    targetSource = sources[0];
  }

  if (!targetSource) {
    return null;
  }

  // 2. Clean up the quote for text searching and highlighting
  let rawQuote = citation.quote || '';
  // Remove leading/trailing ellipsis or quote symbols
  let cleanQuote = rawQuote
    .replace(/^["'«“\s\.\…]+/, '')
    .replace(/["'»”\s\.\…]+$/, '')
    .trim();

  // If quote is too long, pick the first 1-2 distinct sentences for reliable matching
  if (cleanQuote.length > 140) {
    const sentences = cleanQuote.split(/[.!\n؟]/).map((s) => s.trim()).filter((s) => s.length > 15);
    if (sentences.length > 0) {
      cleanQuote = sentences[0];
    } else {
      cleanQuote = cleanQuote.slice(0, 100).trim();
    }
  }

  // 3. Determine the exact relevant page number
  let targetPage = citation.pageNumber && citation.pageNumber > 0 ? citation.pageNumber : 1;

  // If pageNumber is not provided or defaulted to 1, search the source pages for the quote
  if ((!citation.pageNumber || citation.pageNumber <= 1) && targetSource.pages && targetSource.pages.length > 0) {
    const normQuote = normalizeForSearch(cleanQuote);
    for (const page of targetSource.pages) {
      const normPageText = normalizeForSearch(page.text);
      if (normPageText.includes(normQuote) || (normQuote.length > 20 && normPageText.includes(normQuote.slice(0, 20)))) {
        targetPage = page.pageNumber;
        break;
      }
    }
  }

  // Also check if content has explicit [الصفحة X] tags preceding the quote
  if ((!citation.pageNumber || citation.pageNumber <= 1) && targetSource.content) {
    const normQuote = normalizeForSearch(cleanQuote);
    const content = targetSource.content;
    const pageMarkers = Array.from(content.matchAll(/\[الصفحة\s+(\d+)\]/g));
    
    if (pageMarkers.length > 0 && normQuote.length > 10) {
      const quoteIndex = normalizeForSearch(content).indexOf(normQuote.slice(0, 25));
      if (quoteIndex !== -1) {
        let detectedPage = 1;
        for (const pm of pageMarkers) {
          if (pm.index !== undefined && pm.index <= quoteIndex) {
            detectedPage = parseInt(pm[1], 10);
          } else {
            break;
          }
        }
        targetPage = detectedPage;
      }
    }
  }

  // 4. Default reading zoom for highlighted passage (130% is ideal for focus)
  const zoomScale = 1.3;

  // 5. Check if an existing annotation corresponds to this citation or chunk
  let targetAnnotationId: string | undefined;
  if (targetSource.annotations && targetSource.annotations.length > 0) {
    const matchedAnn = targetSource.annotations.find(
      (a) =>
        (citation.chunkId && a.chunkId === citation.chunkId) ||
        (cleanQuote && a.selectedText.includes(cleanQuote)) ||
        (cleanQuote && cleanQuote.includes(a.selectedText))
    );
    if (matchedAnn) {
      targetAnnotationId = matchedAnn.id;
      if (matchedAnn.pageNumber) {
        targetPage = matchedAnn.pageNumber;
      }
    }
  }

  return {
    source: targetSource,
    pageNumber: targetPage,
    highlightText: cleanQuote || citation.quote || '',
    zoomScale,
    confidenceScore: citation.confidenceScore,
    matchedKeywords: citation.matchedKeywords,
    section: citation.section,
    targetAnnotationId,
    chunkId: citation.chunkId,
  };
}
