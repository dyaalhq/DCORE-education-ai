import { InitialIndexingReport } from '../types';
import { extractKeywords, splitIntoSentences } from './documentParser';

/**
 * Generates structured Initial Indexing Output for indexed web resources & documents:
 * - العنوان الرئيسي: (عنوان المصدر)
 * - الملخص التنفيذي: (فقرة موجزة عن جوهر المحتوى)
 * - خريطة المفاهيم (Key Topics): (نقاط نقطية لأهم المواضيع التي تم العثور عليها)
 * - حالة الفهرسة: (جاهز للاستجواب الدقيق)
 */
export function generateInitialIndexingReport(
  title: string,
  content: string,
  headings?: string[],
  pageCount?: number
): InitialIndexingReport {
  const cleanTitle = title.replace(/\.pdf$/i, '').trim() || 'مصدر ويب مفهرس';
  const sentences = splitIntoSentences(content.slice(0, 10000));
  
  // 1. Executive Summary Extraction:
  // Pick meaningful non-trivial sentences that describe what the document covers
  let summarySentences = sentences
    .map((s) => s.trim())
    .filter((s) => s.length >= 35 && s.length <= 300)
    .filter((s) => !/^(فهرس|مقدمة|المحتويات|حقوق الطبع|طبعة|دار النشر|رقم الإيداع)/i.test(s));

  let executiveSummary = '';
  if (summarySentences.length > 0) {
    executiveSummary = summarySentences.slice(0, 3).join(' ');
  } else {
    executiveSummary = `يتناول هذا المرجع «${cleanTitle}» مجموعة من المفاهيم والمعارف الأكاديمية والمنهجية الموثقة، حيث تم استيعاب وفهرسة نصوصه بدقة عالية لتمكين البحث الدلالي والاسترجاع المعرفي المباشر.`;
  }

  if (executiveSummary.length > 350) {
    executiveSummary = executiveSummary.slice(0, 347).trim() + '...';
  }

  // 2. Key Topics Mapping:
  const keyTopics: string[] = [];

  // Use headings if available
  if (headings && headings.length > 0) {
    headings.forEach((h) => {
      const cleanH = h.replace(/^#+\s*/, '').trim();
      if (cleanH.length >= 3 && cleanH.length <= 60 && !keyTopics.includes(cleanH)) {
        keyTopics.push(cleanH);
      }
    });
  }

  // If headings are few, extract from keywords and section markers
  if (keyTopics.length < 4) {
    const rawKeywords = extractKeywords(content.slice(0, 8000), 12);
    rawKeywords.forEach((kw) => {
      if (kw.length >= 3 && !keyTopics.includes(kw) && keyTopics.length < 8) {
        keyTopics.push(`مفهوم: ${kw}`);
      }
    });
  }

  // Fallback topics if still sparse
  if (keyTopics.length === 0) {
    keyTopics.push(
      `المفاهيم والتعريفات التأسيسية في ${cleanTitle}`,
      `القوانين والقواعد المنهجية والتطبيقات العلمية`,
      `الأمثلة والنماذج التوضيحية واستنتاجات المحتوى`
    );
  }

  return {
    title: cleanTitle,
    executiveSummary,
    keyTopics: keyTopics.slice(0, 7),
    indexingStatus: 'جاهز للاستجواب الدقيق',
  };
}
