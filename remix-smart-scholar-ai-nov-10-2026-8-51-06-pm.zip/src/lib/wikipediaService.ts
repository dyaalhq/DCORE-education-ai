/**
 * Wikipedia API Service for Smart Scholar AI
 * Provides deep multilingual encyclopedia search and direct extraction of structured articles
 * with auto-chunking for the RAG vector store and study notebooks.
 */

export interface WikipediaSearchResult {
  pageid: number;
  title: string;
  snippet: string;
  wordcount: number;
  timestamp: string;
  size: number;
}

export interface WikipediaArticleDetails {
  pageid: number;
  title: string;
  extract: string;
  canonicalurl: string;
  thumbnail?: string;
  description?: string;
  lang: string;
  wordCount: number;
  headings: string[];
}

export async function searchWikipedia(
  query: string,
  lang: 'ar' | 'en' = 'ar',
  limit: number = 8
): Promise<WikipediaSearchResult[]> {
  if (!query || !query.trim()) return [];

  const endpoint = `https://${lang}.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(
    query.trim()
  )}&utf8=&format=json&origin=*&srlimit=${limit}`;

  try {
    const res = await fetch(endpoint, {
      headers: {
        Accept: 'application/json',
      },
    });

    if (!res.ok) {
      throw new Error(`Wikipedia API error: ${res.statusText}`);
    }

    const data = await res.json();
    const searchResults = data?.query?.search || [];

    return searchResults.map((item: any) => ({
      pageid: item.pageid,
      title: item.title,
      // Strip HTML tags from snippet
      snippet: (item.snippet || '')
        .replace(/<span class="searchmatch">/g, '')
        .replace(/<\/span>/g, '')
        .replace(/&quot;/g, '"')
        .replace(/&#039;/g, "'")
        .replace(/&amp;/g, '&'),
      wordcount: item.wordcount,
      timestamp: item.timestamp,
      size: item.size,
    }));
  } catch (err) {
    console.warn('[WikipediaService] Search failed:', err);
    throw err;
  }
}

export async function fetchWikipediaArticle(
  title: string,
  lang: 'ar' | 'en' = 'ar'
): Promise<WikipediaArticleDetails> {
  const endpoint = `https://${lang}.wikipedia.org/w/api.php?action=query&prop=extracts|pageimages|info&inprop=url&explaintext=1&exintro=0&titles=${encodeURIComponent(
    title
  )}&pithumbsize=600&format=json&origin=*`;

  try {
    const res = await fetch(endpoint, {
      headers: {
        Accept: 'application/json',
      },
    });

    if (!res.ok) {
      throw new Error(`Wikipedia API error: ${res.statusText}`);
    }

    const data = await res.json();
    const pages = data?.query?.pages || {};
    const pageId = Object.keys(pages)[0];
    const page = pages[pageId];

    if (!page || page.missing !== undefined) {
      throw new Error('لم يتم العثور على المقال المطلوب في ويكيبيديا');
    }

    const rawExtract: string = page.extract || '';
    
    // Extract section headings from the text (lines starting with == Section ==)
    const headings: string[] = [];
    const lines = rawExtract.split('\n');
    lines.forEach((l) => {
      const match = l.match(/^={2,4}\s*([^=]+?)\s*={2,4}$/);
      if (match) {
        headings.push(match[1].trim());
      }
    });

    // Clean section headers to standard markdown headers
    const cleanedContent = rawExtract
      .replace(/^==\s*([^=]+?)\s*==$/gm, '## $1')
      .replace(/^===\s*([^=]+?)\s*===$/gm, '### $1')
      .replace(/^====\s*([^=]+?)\s*====$/gm, '#### $1');

    const wordCount = cleanedContent.trim().split(/\s+/).filter(Boolean).length;

    return {
      pageid: page.pageid,
      title: page.title,
      extract: cleanedContent,
      canonicalurl: page.canonicalurl || `https://${lang}.wikipedia.org/wiki/${encodeURIComponent(page.title)}`,
      thumbnail: page.thumbnail?.source,
      lang,
      wordCount,
      headings,
    };
  } catch (err) {
    console.warn('[WikipediaService] Fetch article failed:', err);
    throw err;
  }
}
