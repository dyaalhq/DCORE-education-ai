/**
 * Specialized PDF & Optical Character Recognition (OCR) Parser
 * Integrates pdfjs-dist and Tesseract.js with automatic Arabic language configuration ('ara')
 * Supports digital textbooks and scanned documents with page-by-page extraction.
 */
import { createWorker } from 'tesseract.js';
import { cleanAndReshapePdfText } from './arabicReshaper';

export interface ParsedPDFPage {
  pageNumber: number;
  text: string;
  isOcr?: boolean;
}

export interface PDFParseResult {
  pages: ParsedPDFPage[];
  fullText: string;
  totalPages: number;
  ocrApplied: boolean;
  isScanned: boolean;
}

export type ParseProgressCallback = (progress: {
  status: string;
  progress: number; // 0 to 1
  pageNumber?: number;
  totalPages?: number;
}) => void;

/**
 * Obtain or initialize PDF.js library reliably in the browser
 */
async function getPdfJsLibrary(): Promise<any> {
  if (typeof window !== 'undefined' && (window as any).pdfjsLib) {
    const lib = (window as any).pdfjsLib;
    if (!lib.GlobalWorkerOptions?.workerSrc) {
      lib.GlobalWorkerOptions.workerSrc =
        'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
    }
    return lib;
  }

  try {
    const pdfjs = await import('pdfjs-dist');
    if (!pdfjs.GlobalWorkerOptions?.workerSrc && !pdfjs.GlobalWorkerOptions?.workerPort) {
      try {
        pdfjs.GlobalWorkerOptions.workerPort = new Worker(
          new URL('pdfjs-dist/build/pdf.worker.min.mjs', import.meta.url),
          { type: 'module' }
        );
      } catch {
        pdfjs.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${
          pdfjs.version || '3.11.174'
        }/pdf.worker.min.js`;
      }
    }
    return pdfjs;
  } catch (err) {
    if (typeof window !== 'undefined' && (window as any).pdfjsLib) {
      return (window as any).pdfjsLib;
    }
    throw new Error('تعذر تحميل محرك معالجة ملفات PDF.');
  }
}

/**
 * Render a single PDF page to an HTML Canvas for Tesseract OCR processing
 */
async function renderPageToCanvas(page: any, scale = 2.0): Promise<HTMLCanvasElement> {
  const viewport = page.getViewport({ scale });
  const canvas = document.createElement('canvas');
  const context = canvas.getContext('2d');
  canvas.height = viewport.height;
  canvas.width = viewport.width;

  if (!context) {
    throw new Error('فشل إنشاء سياق رسم الكانفاس للتعرف البصري');
  }

  await page.render({
    canvasContext: context,
    viewport,
  }).promise;

  return canvas;
}

/**
 * Perform Arabic OCR on an image source using Tesseract.js with automatic 'ara' setting
 */
export async function performArabicOCR(
  imageSource: HTMLCanvasElement | Blob | string,
  onProgress?: ParseProgressCallback,
  pageNumber = 1,
  totalPages = 1
): Promise<string> {
  let worker: any = null;
  try {
    onProgress?.({
      status: `تهيئة قارئ Tesseract.js العربي (OCR ara) للصفحة ${pageNumber}...`,
      progress: 0.1,
      pageNumber,
      totalPages,
    });

    // Automatically configure language to Arabic ('ara')
    worker = await createWorker('ara', 1, {
      logger: (m) => {
        if (m.status === 'recognizing text') {
          onProgress?.({
            status: `جاري استخراج النصوص العربية بالمسح الضوئي للصفحة ${pageNumber} (${Math.round((m.progress || 0) * 100)}%)...`,
            progress: 0.1 + (m.progress || 0) * 0.85,
            pageNumber,
            totalPages,
          });
        }
      },
    });

    const result = await worker.recognize(imageSource);
    const rawText = (result.data.text || '')
      .replace(/\r\n/g, '\n')
      .replace(/[ \t]+/g, ' ')
      .trim();

    return cleanAndReshapePdfText(rawText);
  } catch (err) {
    console.warn(`OCR extraction failed on page ${pageNumber}:`, err);
    return '';
  } finally {
    if (worker) {
      await worker.terminate().catch(() => {});
    }
  }
}

/**
 * Complete PDF Parser supporting digital & scanned documents:
 * 1. Reads binary ArrayBuffer / Blob directly in client.
 * 2. Iterates across all pages (1..pdf.numPages).
 * 3. Extracts text and applies arabicReshaper.
 * 4. Automatically triggers Tesseract.js with 'ara' on scanned/image-only pages.
 */
export async function parsePDFWithOCR(
  input: ArrayBuffer | Uint8Array | Blob | File,
  onProgress?: ParseProgressCallback
): Promise<PDFParseResult> {
  let arrayBuffer: ArrayBuffer;
  if (input instanceof ArrayBuffer) {
    arrayBuffer = input;
  } else if (input instanceof Uint8Array) {
    const copy = new Uint8Array(input.byteLength);
    copy.set(input);
    arrayBuffer = copy.buffer as ArrayBuffer;
  } else {
    arrayBuffer = await input.arrayBuffer();
  }

  const pdfjs = await getPdfJsLibrary();
  const loadingTask = pdfjs.getDocument({
    data: arrayBuffer,
    useSystemFonts: true,
  });

  const pdfDoc = await loadingTask.promise;
  const totalPages = pdfDoc.numPages;
  const pages: ParsedPDFPage[] = [];
  let fullText = '';
  let ocrApplied = false;
  let scannedPagesCount = 0;

  for (let i = 1; i <= totalPages; i++) {
    onProgress?.({
      status: `قراءة وتفكيك الصفحة ${i} من ${totalPages}...`,
      progress: (i - 1) / totalPages,
      pageNumber: i,
      totalPages,
    });

    const page = await pdfDoc.getPage(i);
    const content = await page.getTextContent();
    let pageText = content.items
      .map((item: any) => item.str || '')
      .join(' ')
      .replace(/\s+/g, ' ')
      .trim();

    // If text layer is empty or too short (scanned page), trigger Tesseract.js OCR
    if (!pageText || pageText.length < 25) {
      scannedPagesCount++;
      // Render canvas and run Arabic OCR if document is scanned or early pages
      if (totalPages <= 30 || i <= 10) {
        try {
          const canvas = await renderPageToCanvas(page, 1.8);
          const ocrText = await performArabicOCR(canvas, onProgress, i, totalPages);
          if (ocrText && ocrText.length > 15) {
            pageText = ocrText;
            ocrApplied = true;
          }
        } catch (ocrErr) {
          console.warn(`Scanned OCR attempt failed on page ${i}:`, ocrErr);
        }
      }
    }

    if (pageText) {
      const reshapedText = cleanAndReshapePdfText(pageText);
      pages.push({ pageNumber: i, text: reshapedText, isOcr: ocrApplied });
      fullText += `\n[الصفحة ${i}]\n` + reshapedText + '\n';
    } else {
      const emptyMarker = `[الصفحة ${i} - رسم توضيحي أو محتوى ممسوح ضوئياً]`;
      pages.push({ pageNumber: i, text: emptyMarker, isOcr: false });
      fullText += `\n[الصفحة ${i}]\n` + emptyMarker + '\n';
    }

    if (typeof page.cleanup === 'function') {
      page.cleanup();
    }
  }

  try {
    if (typeof pdfDoc.destroy === 'function') {
      await pdfDoc.destroy();
    }
  } catch (e) {}

  return {
    pages,
    fullText: fullText.trim(),
    totalPages,
    ocrApplied,
    isScanned: scannedPagesCount > totalPages * 0.5,
  };
}
