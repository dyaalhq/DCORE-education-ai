/**
 * Background Synchronization & Offline-First Resilience Service
 * - Handles online/offline transition listeners
 * - Flushes pending sync actions to cloud upon reconnection
 * - Periodically and seamlessly replenishes the offline IndexedDB question pool
 */
import { AppState } from './storage';
import { syncWorkspaceToCloud } from './cloudAuth';
import { offlineDb } from './offlineDatabase';
import {
  generateSyntheticAcademicQuestions,
  populateAndSaveQuestionsToIndexedDB
} from './massiveQuestionGenerator';

export interface SyncStatus {
  isOnline: boolean;
  isSyncing: boolean;
  lastSyncedAt?: number;
  pendingChangesCount: number;
  error?: string;
}

const PENDING_SYNC_KEY = 'dcore_pending_offline_sync';

export class BackgroundSyncService {
  private static instance: BackgroundSyncService;
  private isSyncing = false;
  private lastSyncedAt?: number;
  private pendingChanges = false;
  private getStateFn?: () => AppState;
  private onSyncCallback?: (syncedAt: number) => void;
  private listeners: Array<(status: SyncStatus) => void> = [];
  private replenishmentTimer?: NodeJS.Timeout;

  private constructor() {
    if (typeof window !== 'undefined') {
      window.addEventListener('online', () => this.handleNetworkChange(true));
      window.addEventListener('offline', () => this.handleNetworkChange(false));
      
      // Check if there was pending sync left from previous session
      try {
        const pending = localStorage.getItem(PENDING_SYNC_KEY);
        if (pending === 'true') {
          this.pendingChanges = true;
        }
      } catch {}
    }
  }

  public static getInstance(): BackgroundSyncService {
    if (!BackgroundSyncService.instance) {
      BackgroundSyncService.instance = new BackgroundSyncService();
    }
    return BackgroundSyncService.instance;
  }

  public initialize(getState: () => AppState, onSyncSuccess?: (syncedAt: number) => void) {
    this.getStateFn = getState;
    this.onSyncCallback = onSyncSuccess;

    // Start background question replenishment loop after initial load
    if (typeof window !== 'undefined') {
      setTimeout(() => {
        this.replenishQuestionPoolIfNeeded();
      }, 5000);

      // Recurring check every 15 minutes
      this.replenishmentTimer = setInterval(() => {
        this.replenishQuestionPoolIfNeeded();
      }, 15 * 60 * 1000);
    }
  }

  public subscribe(callback: (status: SyncStatus) => void): () => void {
    this.listeners.push(callback);
    callback(this.getStatus());
    return () => {
      this.listeners = this.listeners.filter((cb) => cb !== callback);
    };
  }

  public getStatus(): SyncStatus {
    const isOnline = typeof navigator !== 'undefined' ? navigator.onLine : true;
    return {
      isOnline,
      isSyncing: this.isSyncing,
      lastSyncedAt: this.lastSyncedAt,
      pendingChangesCount: this.pendingChanges ? 1 : 0,
    };
  }

  private notify() {
    const status = this.getStatus();
    this.listeners.forEach((cb) => cb(status));
  }

  public markPendingChange() {
    this.pendingChanges = true;
    try {
      localStorage.setItem(PENDING_SYNC_KEY, 'true');
    } catch {}
    this.notify();

    // If online, debounce sync
    if (typeof navigator !== 'undefined' && navigator.onLine) {
      this.triggerCloudSyncDebounced();
    }
  }

  private syncTimeout?: NodeJS.Timeout;
  private triggerCloudSyncDebounced() {
    if (this.syncTimeout) clearTimeout(this.syncTimeout);
    this.syncTimeout = setTimeout(() => {
      this.syncNow();
    }, 2000);
  }

  public async syncNow(): Promise<boolean> {
    if (this.isSyncing || !this.getStateFn) return false;
    const isOnline = typeof navigator !== 'undefined' ? navigator.onLine : true;
    if (!isOnline) {
      this.markPendingChange();
      return false;
    }

    const state = this.getStateFn();
    if (!state.userProfile?.uid) {
      return false;
    }

    this.isSyncing = true;
    this.notify();

    try {
      const result = await syncWorkspaceToCloud(state.userProfile.uid, state);
      if (result.success && result.syncedAt) {
        this.lastSyncedAt = result.syncedAt;
        this.pendingChanges = false;
        try {
          localStorage.removeItem(PENDING_SYNC_KEY);
        } catch {}
        if (this.onSyncCallback) {
          this.onSyncCallback(result.syncedAt);
        }
        return true;
      }
      return false;
    } catch (e) {
      console.warn('[BackgroundSync] Cloud sync failed, will retry on reconnection:', e);
      return false;
    } finally {
      this.isSyncing = false;
      this.notify();
    }
  }

  private async handleNetworkChange(isOnline: boolean) {
    this.notify();
    if (isOnline) {
      console.log('[BackgroundSync] Connection restored. Flushing pending changes and updating question pool...');
      if (this.pendingChanges) {
        await this.syncNow();
      }
      this.replenishQuestionPoolIfNeeded();
    }
  }

  /**
   * Silently verifies that local IndexedDB holds a vast pool of academic & medical questions.
   * If local storage has capacity or pool is below target, synthesizes and stores new batches.
   */
  public async replenishQuestionPoolIfNeeded(): Promise<number> {
    try {
      const count = await offlineDb.questions.count();
      // Target at least 2,500 questions cached locally for 100% offline coverage
      if (count < 2500) {
        console.log(`[BackgroundSync] Current offline pool: ${count} questions. Replenishing with high-yield batches...`);
        
        const coreSubjects = [
          { section: 'ministerial' as const, subject: 'الرياضيات', stage: 'ثالث ثانوي علمي' as const },
          { section: 'ministerial' as const, subject: 'الفيزياء', stage: 'ثالث ثانوي علمي' as const },
          { section: 'ministerial' as const, subject: 'الكيمياء', stage: 'ثالث ثانوي علمي' as const },
          { section: 'ministerial' as const, subject: 'الأحياء', stage: 'ثالث ثانوي علمي' as const },
          { section: 'ministerial' as const, subject: 'القرآن الكريم وعلومه', stage: 'ثالث ثانوي علمي' as const },
          { section: 'medical' as const, subject: 'Cardiovascular System (CVS)', medicalBlock: 'Cardiovascular System (CVS)' },
          { section: 'medical' as const, subject: 'Clinical Pathology & Histology', medicalBlock: 'Clinical Pathology' },
          { section: 'medical' as const, subject: 'Pharmacology & Therapeutics', medicalBlock: 'Pharmacology' },
        ];

        let totalAdded = 0;
        for (const item of coreSubjects) {
          const batch = generateSyntheticAcademicQuestions({
            section: item.section,
            subject: item.subject,
            stage: item.stage,
            medicalBlock: item.medicalBlock,
            targetCount: 150
          });
          await populateAndSaveQuestionsToIndexedDB(batch);
          totalAdded += batch.length;
        }

        const newTotal = await offlineDb.questions.count();
        console.log(`[BackgroundSync] Successfully cached ${totalAdded} fresh verified questions. Total offline pool: ${newTotal}`);
        return newTotal;
      }
      return count;
    } catch (e) {
      console.warn('[BackgroundSync] Question replenishment error:', e);
      return 0;
    }
  }

  public destroy() {
    if (this.replenishmentTimer) clearInterval(this.replenishmentTimer);
    if (this.syncTimeout) clearTimeout(this.syncTimeout);
    this.listeners = [];
  }
}

export const backgroundSync = BackgroundSyncService.getInstance();
