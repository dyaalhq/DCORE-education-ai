export interface Notebook {
  id: string;
  name: string;
  subject: string;
  description: string;
  createdAt: number;
  updatedAt: number;
  sourceIds: string[];
  noteIds: string[];
  chatSessionIds: string[];
  progress: number;
}

export type HighlightColor = 'yellow' | 'green' | 'blue' | 'purple' | 'rose';

export interface AnnotationRect {
  x: number; // 0..1 normalized to page width
  y: number; // 0..1 normalized to page height
  width: number; // 0..1 normalized to page width
  height: number; // 0..1 normalized to page height
  pageNumber?: number;
}

export interface SourceAnnotation {
  id: string;
  sourceId: string;
  sourceTitle?: string;
  pageNumber: number;
  selectedText: string;
  note?: string;
  color: HighlightColor;
  startIndex?: number;
  endIndex?: number;
  prefix?: string;
  suffix?: string;
  createdAt: number;
  updatedAt?: number;
  // Precise PDF.js coordinates & chunk linking
  rects?: AnnotationRect[];
  boundingRect?: AnnotationRect;
  chunkId?: string; // ID of corresponding SourceChunk in DB
  paragraphIndex?: number; // Paragraph index in the page
  paragraphText?: string; // Context paragraph snippet
  linkedCitationId?: string; // Cross-link to Chat citation
}

export type SourceStatus = 'Uploading' | 'Processing' | 'Ready' | 'Failed' | 'Unsupported';

export interface InitialIndexingReport {
  title: string;
  executiveSummary: string;
  keyTopics: string[];
  indexingStatus: 'جاهز للاستجواب الدقيق';
}

export interface Source {
  id: string;
  notebookId: string;
  title: string;
  uri?: string;
  type: string;
  size: number;
  status: SourceStatus;
  errorMessage?: string;
  content: string;
  rawHtml?: string;
  headings?: string[];
  wordCount?: number;
  lineCount?: number;
  pageCount?: number;
  pages?: Array<{ pageNumber: number; text: string }>;
  annotations?: SourceAnnotation[];
  summary?: string;
  indexingReport?: InitialIndexingReport;
  createdAt: number;
  updatedAt: number;
  localFileId?: string;
  favorite?: boolean;
}

export interface ChunkMetadata {
  paragraphIndex?: number;
  sectionTitle?: string;
  headingHierarchy?: string[];
  charOffset?: number;
  charLength?: number;
  tokenEstimate?: number;
  keywords?: string[];
  topics?: string[];
  sourceType?: string;
  hasMath?: boolean;
  hasTable?: boolean;
  katex?: string[]; // Array of identified LaTeX/KaTeX equations
  hasKatex?: boolean;
  pageNumber?: number | null;
  slidingWindowApplied?: boolean;
  connectedPages?: number[];
}

export interface SourceChunk {
  id: string;
  sourceId: string;
  sourceTitle: string;
  notebookId: string;
  text: string;
  pageNumber?: number | null;
  section?: string;
  offset?: number;
  metadata?: ChunkMetadata;
}

export interface Citation {
  sourceId: string;
  sourceTitle: string;
  uri?: string;
  pageNumber?: number | null;
  section?: string;
  quote?: string;
  confidenceScore?: number; // 0 to 100% confidence match
  confidenceLevel?: 'high' | 'medium' | 'moderate';
  matchedKeywords?: string[];
  chunkId?: string;
  annotationId?: string;
  headingHierarchy?: string[];
  katexEquations?: string[];
}

export interface GroundingSource {
  title: string;
  uri: string;
  domain?: string;
  snippet?: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'ai';
  text: string;
  date: number;
  notebookId: string;
  sessionId: string;
  citations?: Citation[];
  groundingSources?: GroundingSource[];
  groundingQueries?: string[];
  isGroundingVerified?: boolean;
  providerInfo?: {
    activeProvider: 'gemini' | 'fallback';
    modelUsed: string;
    fallbackUsed: boolean;
    fallbackReason?: string;
  };
  feedback?: 'like' | 'dislike' | null;
  suggestedNextPrompt?: string;
  suggestedNextUnit?: string;
}

export interface ChatSession {
  id: string;
  notebookId: string;
  title: string;
  created: number;
  updated: number;
  messages: ChatMessage[];
  sourceIds: string[];
}

export interface NoteItem {
  id: string;
  notebookId: string;
  subject: string;
  level: string;
  title: string;
  goal: string;
  tags: string[];
  text: string;
  favorite: boolean;
  mastery: number;
  created: number;
  updated: number;
  files?: Array<{ id: string; name: string; type: string; size: number }>;
}

export interface QuizQuestion {
  id: string;
  question: string;
  type: 'mcq' | 'tf' | 'short';
  options?: string[];
  answer: string | number;
  explanation?: string;
  userAnswer?: string | number;
}

export interface QuizResult {
  id: string;
  notebookId: string;
  noteId?: string;
  title: string;
  score: number;
  count: number;
  date: number;
  kind: 'ai' | 'local';
  questions: QuizQuestion[];
}

export interface Flashcard {
  id: string;
  notebookId: string;
  noteId?: string;
  front: string;
  back: string;
  level: number;
  nextReview: number;
  interval?: number;
  mistake: boolean;
  topic?: string;
  easeFactor?: number; // SM-2 ease factor (default 2.5)
  reps?: number; // Consecutive successful repetitions
  intervalDays?: number; // Next interval in days
  lastReviewed?: number;
  masteryHistory?: Array<{ date: number; level: number }>;
}

export interface StudyPlan {
  id: string;
  notebookId: string;
  goal: string;
  start: string;
  days: number;
  mins: number;
  items: Array<{ day: number; date: string; task: string; focus?: string; done: boolean }>;
}

export interface TodoItem {
  id: string;
  notebookId: string;
  text: string;
  due?: string;
  dueDate?: string;
  dueTime?: string;
  priority?: 'high' | 'medium' | 'low';
  done: boolean;
  created?: number;
  createdAt?: number;
}

export interface MemoItem {
  id: string;
  notebookId: string;
  text: string;
  date?: number;
  createdAt?: number;
}

export interface GlossaryItem {
  id: string;
  notebookId: string;
  term: string;
  def: string;
  ex?: string;
  date?: number;
  createdAt?: number;
}

export interface FocusSession {
  id: string;
  notebookId: string;
  date?: number;
  timestamp?: number;
  minutes?: number;
  durationMins: number;
  kind?: string;
  sound?: string;
}

export type MindMapLayout = 'rtl' | 'ltr' | 'radial' | 'tree' | 'bottom_up' | 'ttb' | 'btt';

export interface MindMapNode {
  id: string;
  title: string;
  text?: string;
  level: number;
  depth?: number;
  children?: MindMapNode[];
  color?: string;
  notes?: string;
  formula?: string;
  badge?: string;
  details?: string;
  relatedNodeIds?: string[];
  relationLabel?: string;
}

export interface MindMapNodeData {
  id: string;
  text: string;
  notes?: string;
  depth: number;
  color?: string;
  icon?: string;
  collapsed?: boolean;
  children: MindMapNodeData[];
}

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  photoURL?: string;
  signedInAt: number;
  lastSyncAt?: number;
  isGoogleUser: boolean;
}

export interface CustomSummaryDoc {
  id: string;
  notebookId: string;
  title: string;
  subject: string;
  author: string;
  date: string;
  theme: 'teal' | 'navy' | 'classic' | 'emerald' | 'crimson';
  printMode: 'colored' | 'print_friendly';
  paperSize: 'a4';
  orientation: 'portrait' | 'landscape';
  fontSize: 'sm' | 'md' | 'lg';
  showCoverPage: boolean;
  showPageNumbers: boolean;
  showTableOfContents: boolean;
  content: string;
  boxes: Array<{
    id: string;
    type: 'definition' | 'law' | 'note' | 'example' | 'warning' | 'table';
    title: string;
    body: string;
  }>;
  createdAt: number;
  updatedAt: number;
}

export type AIMode = 'notebook' | 'hybrid' | 'general';

export interface FallbackAISettings {
  enabled: boolean;
  activeProvider?: 'auto' | 'gemini' | 'fallback';
  providerName: string;
  apiKey: string;
  baseUrl: string;
  model: string;
  geminiApiKey?: string;
  geminiModel?: string;
}

export interface MindMapTree {
  id: string;
  notebookId: string;
  title: string;
  root: MindMapNode;
  updatedAt: number;
}

