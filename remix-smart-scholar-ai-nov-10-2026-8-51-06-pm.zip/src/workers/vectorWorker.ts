/**
 * Dedicated Background Web Worker for PDF and Document Vector Tokenization & Embedding
 * Runs on a separate OS thread to ensure the browser UI NEVER freezes during large book indexing (100-500+ pages).
 */

// Helper to tokenize Arabic and English text inside worker
function normalizeArabicWord(word: string): string {
  if (!word) return '';
  return word
    .toLowerCase()
    .replace(/[ًٌٍَُِّْـ]/g, '') // Remove tashkeel diacritics & tatweel
    .replace(/[إأآء]/g, 'ا') // Normalize alef forms
    .replace(/ة/g, 'ه') // Normalize taa marbuta
    .replace(/ى/g, 'ي') // Normalize alef maqsura
    .trim();
}

function tokenize(text: string): string[] {
  if (!text) return [];
  const words = text.match(/[\u0600-\u06FFa-zA-Z0-9_]+/g) || [];
  return words
    .map(normalizeArabicWord)
    .filter((w) => w.length >= 2);
}

function vectorize(text: string): Record<string, number> {
  const tokens = tokenize(text);
  const tf: Record<string, number> = {};
  for (const token of tokens) {
    tf[token] = (tf[token] || 0) + 1;
  }
  return tf;
}

function extractKatexEquations(text: string): string[] {
  if (!text) return [];
  const equations: string[] = [];
  const seen = new Set<string>();

  const addEq = (eq: string) => {
    const trimmed = eq.trim();
    if (trimmed && !seen.has(trimmed)) {
      seen.add(trimmed);
      equations.push(trimmed);
    }
  };

  // 1. Explicit <katex> tags
  const tagRegex = /<(?:katex|latex)[^>]*>([\s\S]*?)<\/(?:katex|latex)>|\[katex\]([\s\S]*?)\[\/katex\]/gi;
  let match: RegExpExecArray | null;
  while ((match = tagRegex.exec(text)) !== null) {
    addEq(match[1] || match[2]);
  }

  // 2. Display math: $$...$$ or \[...\]
  const displayRegex = /\$\$([\s\S]*?)\$\$|\\\[([\s\S]*?)\\\]/g;
  while ((match = displayRegex.exec(text)) !== null) {
    addEq(match[1] || match[2]);
  }

  // 3. LaTeX environments
  const envRegex = /\\begin\{(equation|align|gather|matrix|bmatrix|pmatrix|vmatrix|cases|array)\*?\}[\s\S]*?\\end\{\1\*?\}/g;
  while ((match = envRegex.exec(text)) !== null) {
    addEq(match[0]);
  }

  // 4. Inline math: $...$
  const inlineRegex = /(?:^|[^\\])\$([^\$\n\r]+?)\$|\\\(([\s\S]*?)\\\)/g;
  while ((match = inlineRegex.exec(text)) !== null) {
    const candidate = (match[1] || match[2] || '').trim();
    if (
      candidate.length >= 2 &&
      !/^\d+(?:\.\d+)?$/.test(candidate) &&
      (/[\+\-\=\\\^_\{\}\(\)\[\]\/\*]|frac|sqrt|alpha|beta|theta|pi|int|sum/i.test(candidate))
    ) {
      addEq(candidate);
    }
  }

  // 5. Standalone LaTeX math commands
  const cmdRegex = /\\(?:frac\{[^\}]*\}\{[^\}]*\}|sqrt(?:\[[^\]]*\])?\{[^\}]*\}|sum(?:_[^\^]*\^[^\s]*)?|int(?:_[^\^]*\^[^\s]*)?|[a-zA-Z]+(?:\^\{[^\}]*\}|_{[^\}]*})+)/g;
  while ((match = cmdRegex.exec(text)) !== null) {
    addEq(match[0]);
  }

  return equations;
}

export interface WorkerChunkInput {
  id: string;
  sourceId: string;
  sourceTitle: string;
  notebookId: string;
  pageNumber?: number | null;
  section?: string;
  text: string;
  metadata?: any;
}

export interface WorkerProcessedRecord {
  id: string;
  sourceId: string;
  sourceTitle: string;
  notebookId: string;
  pageNumber?: number | null;
  section?: string;
  text: string;
  vector: Record<string, number>;
  tokens: string[];
  tokenEstimate: number;
  katex?: string[];
  hasKatex?: boolean;
}

self.onmessage = (e: MessageEvent) => {
  const { type, chunks, batchSize = 10 } = e.data || {};

  if (type === 'INDEX_CHUNKS') {
    if (!chunks || !Array.isArray(chunks) || chunks.length === 0) {
      self.postMessage({ type: 'COMPLETE', records: [] });
      return;
    }

    const total = chunks.length;
    const processedRecords: WorkerProcessedRecord[] = [];

    for (let i = 0; i < total; i++) {
      const chunk: WorkerChunkInput = chunks[i];
      const tokens = tokenize(chunk.text);
      const vector = vectorize(chunk.text);
      const tokenEstimate = Math.ceil(chunk.text.length / 4);
      const katex = extractKatexEquations(chunk.text);
      const hasKatex = katex.length > 0;

      const record: WorkerProcessedRecord = {
        id: chunk.id,
        sourceId: chunk.sourceId,
        sourceTitle: chunk.sourceTitle || 'كتاب دراسي',
        notebookId: chunk.notebookId || '',
        pageNumber: chunk.pageNumber,
        section: chunk.section,
        text: chunk.text,
        vector,
        tokens,
        tokenEstimate,
        katex,
        hasKatex,
      };

      processedRecords.push(record);

      // Report progress periodically or at the end
      if ((i + 1) % batchSize === 0 || i === total - 1) {
        const processed = i + 1;
        const percent = Math.min(100, Math.round((processed / total) * 100));
        self.postMessage({
          type: 'PROGRESS',
          progress: {
            processed,
            total,
            percent,
            currentChunkTitle: chunk.sourceTitle || 'كتاب دراسي',
            status: `معالجة الخلفية (Web Worker): تمت فهرسة ${processed} من ${total} مقطع (${percent}%)`,
          },
        });
      }
    }

    self.postMessage({
      type: 'COMPLETE',
      records: processedRecords,
    });
  }
};
