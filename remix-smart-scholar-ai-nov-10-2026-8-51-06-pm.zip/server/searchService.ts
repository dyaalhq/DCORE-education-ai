import { GoogleGenAI } from "@google/genai";
import { createRequire } from "module";
import path from "path";
import { cleanAndReshapePdfText } from "../src/lib/arabicReshaper.ts";
import {
  extractStrictWebContent,
  validateAcademicArticle,
} from "./htmlExtractor.ts";

const nodeRequire = createRequire(path.join(process.cwd(), "server.ts"));
const { PDFParse } = nodeRequire("pdf-parse");

/**
 * Deep PDF Extractor for Node.js using PDFParse class
 * Extracts full text page-by-page with structural markers and applies Arabic text reshaping & BiDi correction
 */
export async function extractPdfFromBuffer(buffer: Buffer): Promise<{
  text: string;
  totalPages: number;
  pages: Array<{ pageNumber: number; text: string }>;
}> {
  try {
    const parser = new PDFParse({ data: new Uint8Array(buffer) });
    await parser.load();
    const textResult = await parser.getText();
    const totalPages = textResult.total || (Array.isArray(textResult.pages) ? textResult.pages.length : 1);
    const pages: Array<{ pageNumber: number; text: string }> = [];
    let fullText = "";

    if (Array.isArray(textResult.pages) && textResult.pages.length > 0) {
      for (const p of textResult.pages) {
        const pageNum = p.num || pages.length + 1;
        const rawPageText = (p.text || "").replace(/\s+/g, " ").trim();
        const pageText = cleanAndReshapePdfText(rawPageText);
        if (pageText && pageText.length > 0) {
          pages.push({ pageNumber: pageNum, text: pageText });
          fullText += `\n[الصفحة ${pageNum}]\n${pageText}\n`;
        } else {
          const placeholder = `[الصفحة ${pageNum} - رسم توضيحي أو محتوى ممسوح ضوئياً]`;
          pages.push({ pageNumber: pageNum, text: placeholder });
          fullText += `\n[الصفحة ${pageNum}]\n${placeholder}\n`;
        }
      }
    } else if (textResult.text && textResult.text.trim()) {
      const pageText = cleanAndReshapePdfText(textResult.text);
      pages.push({ pageNumber: 1, text: pageText });
      fullText = `[الصفحة 1]\n${pageText}`;
    }

    try {
      await parser.destroy();
    } catch (e) {}

    // If text was empty or purely scanned, ensure pages exist for viewing
    if (pages.length === 0) {
      for (let p = 1; p <= Math.max(1, totalPages); p++) {
        pages.push({ pageNumber: p, text: `[الصفحة ${p} - رسم توضيحي أو وثيقة مصورة]` });
      }
      fullText = `[مستند PDF يحتوي على ${totalPages} صفحة مصورة تم فهرستها للمعاينة والبحث المباشر]`;
    }

    return {
      text: fullText.trim(),
      totalPages: Math.max(1, totalPages),
      pages,
    };
  } catch (err: any) {
    console.warn("PDF extraction error with PDFParse:", err?.message || err);
    return {
      text: "",
      totalPages: 0,
      pages: [],
    };
  }
}

/**
 * Deep Web PDF Crawler:
 * Scan an HTML page for direct PDF download links, embedded viewers, buttons, and redirects
 * e.g., <a>, <button>, <iframe>, <embed>, <object>, onclick, and curriculum download keywords
 * Specifically optimized for Yemeni, Arab educational sites, Google Drive, Mediafire, and Archive.org
 */
export function findPdfDownloadLinksInHtml(html: string, pageUrl: string): string[] {
  const links: string[] = [];
  const seen = new Set<string>();

  const resolve = (rel: string): string | null => {
    try {
      return new URL(rel, pageUrl).href;
    } catch {
      return null;
    }
  };

  // 1. Direct .pdf links in href, src, data-url, etc.
  const directPdfRegex =
    /(?:href|src|data-url|data-href|data-download|data-link|data-file)=["']([^"']+\.pdf(?:\?[^"']*)?)["']/gi;
  let match;
  while ((match = directPdfRegex.exec(html)) !== null) {
    const resolved = resolve(match[1]);
    if (resolved && !seen.has(resolved)) {
      seen.add(resolved);
      links.push(resolved);
    }
  }

  // 2. Google Drive download / view / preview links
  const gdriveRegex =
    /https?:\/\/(?:drive|docs)\.google\.com\/(?:file\/d\/|open\?id=|uc\?id=)([a-zA-Z0-9_-]+)/gi;
  while ((match = gdriveRegex.exec(html)) !== null) {
    const fileId = match[1];
    const directDl = `https://drive.google.com/uc?export=download&id=${fileId}`;
    if (!seen.has(directDl)) {
      seen.add(directDl);
      links.push(directDl);
    }
  }

  // 3. Mediafire / Archive.org / Dropbox / OneDrive / Top4top download links
  const downloadHostsRegex =
    /(?:href|data-url|data-href|data-link)=["']([^"']*(?:mediafire\.com\/(?:file|download)\/|archive\.org\/(?:download|details)\/|dropbox\.com\/s\/|top4top\.io\/|4shared\.com\/|1drv\.ms\/)[^"']*)["']/gi;
  while ((match = downloadHostsRegex.exec(html)) !== null) {
    let target = match[1];
    if (target.includes("dropbox.com") && !target.includes("dl=1")) {
      target = target.replace(/(\?|&)dl=0/g, "").concat(target.includes("?") ? "&dl=1" : "?dl=1");
    }
    const resolved = resolve(target);
    if (resolved && !seen.has(resolved)) {
      seen.add(resolved);
      links.push(resolved);
    }
  }

  // 4. Embedded PDF viewers (iframe, embed, object)
  const embedPdfRegex =
    /<(?:iframe|embed|object)\s+[^>]*(?:src|data)=["']([^"']*(?:\.pdf|drive\.google|docs\.google\.com\/viewer)[^"']*)["']/gi;
  while ((match = embedPdfRegex.exec(html)) !== null) {
    const resolved = resolve(match[1]);
    if (resolved && !seen.has(resolved)) {
      seen.add(resolved);
      links.push(resolved);
    }
  }

  // 5. Meta refresh redirect to PDF or download page
  const metaRefreshRegex =
    /<meta\s+[^>]*http-equiv=["']refresh["'][^>]*content=["'][^"']*url=([^"'>]+)["']/gi;
  while ((match = metaRefreshRegex.exec(html)) !== null) {
    const resolved = resolve(match[1]);
    if (resolved && !seen.has(resolved)) {
      seen.add(resolved);
      links.push(resolved);
    }
  }

  // 6. Anchor tags with explicit download attribute
  const downloadAttrRegex = /<a\s+[^>]*href=["']([^"']+)["'][^>]*download[^>]*>/gi;
  while ((match = downloadAttrRegex.exec(html)) !== null) {
    const resolved = resolve(match[1]);
    if (resolved && !seen.has(resolved)) {
      seen.add(resolved);
      links.push(resolved);
    }
  }

  // 7. Buttons and onclick attributes containing pdf or download endpoints
  const buttonRegex =
    /<(?:button|div|span|a)\s+[^>]*(?:onclick|data-action)=["'](?:window\.open\(['"]|location\.href\s*=\s*['"]|window\.location\s*=\s*['"])([^'"]+)(?:['"]\)?)[^>]*>([\s\S]*?)<\/(?:button|div|span|a)>/gi;
  while ((match = buttonRegex.exec(html)) !== null) {
    const targetUrl = match[1];
    const resolved = resolve(targetUrl);
    if (resolved && !seen.has(resolved)) {
      seen.add(resolved);
      links.push(resolved);
    }
  }

  // 8. Anchor or button tags containing Arabic curriculum keywords
  const keywordLinkRegex =
    /<(?:a|button)\s+[^>]*(?:href|data-url|data-href)=["']([^"']+)["'][^>]*>([\s\S]*?)<\/(?:a|button)>/gi;
  while ((match = keywordLinkRegex.exec(html)) !== null) {
    const href = match[1];
    const text = match[2].replace(/<[^>]+>/g, "").trim();
    if (
      /(?:تحميل|تنزيل|download|رابط التحميل|الملزمة|الكتاب كامل|تحميل الكتاب|تحميل المنهج|ملف pdf|نسخة pdf|رابط مباشر|تحميل مباشر|اضغط هنا للتحميل|الجزء الأول|الجزء الثاني|كتاب الطالب|دليل المعلم|قراءة الكتاب|تصفح الكتاب|Download PDF|سيرفر التحميل|رابط بديل|سيرفر اول|سيرفر ثاني|تحميل من جوجل درايف|تحميل من ميديا فاير|سيرفر الوزارة|المنهج اليمني|كتاب الحديث|كتاب القرآن|كتاب التفسير|كتاب الفقه)/i.test(
        text
      ) &&
      !/javascript:|#|mailto:|tel:/i.test(href)
    ) {
      const resolved = resolve(href);
      if (resolved && !seen.has(resolved)) {
        seen.add(resolved);
        links.push(resolved);
      }
    }
  }

  // 9. Raw PDF URLs embedded anywhere in the HTML markup or scripts
  const rawPdfRegex = /https?:\/\/[a-zA-Z0-9_\-./%]+\.pdf(?:\?[a-zA-Z0-9_=&%-]*)?/gi;
  while ((match = rawPdfRegex.exec(html)) !== null) {
    const resolved = resolve(match[0]);
    if (resolved && !seen.has(resolved)) {
      seen.add(resolved);
      links.push(resolved);
    }
  }

  // 10. Extract nested redirect URLs from parameters like ?url=, ?link=, ?file=, ?download=, ?target=
  const redirectParamRegex = /(?:[?&](?:url|link|file|download|target|to|dest)=)(https?%3A%2F%2F[^&"'\s]+|https?:\/\/[^&"'\s]+)/gi;
  while ((match = redirectParamRegex.exec(html)) !== null) {
    try {
      const decoded = decodeURIComponent(match[1]);
      const resolved = resolve(decoded);
      if (resolved && !seen.has(resolved)) {
        seen.add(resolved);
        links.push(resolved);
      }
    } catch {}
  }

  // Sort candidate links: Prioritize direct .pdf, Google Drive, Mediafire, Archive.org downloads first
  links.sort((a, b) => {
    const isPriority = (u: string) =>
      /\.pdf($|[?#])/i.test(u) ||
      /drive\.google\.com|mediafire\.com|archive\.org\/(?:download|details)/i.test(u);
    const aP = isPriority(a) ? 1 : 0;
    const bP = isPriority(b) ? 1 : 0;
    return bP - aP;
  });

  return links;
}

/**
 * Deep Binary PDF Crawler & Stream Downloader:
 * Specifically handles:
 * 1. Direct PDF binary URLs (%PDF magic bytes)
 * 2. Google Drive large files (with virus scan bypass, confirmation cookies and tokens)
 * 3. Mediafire direct file links (#downloadButton)
 * 4. Archive.org metadata resolution (.pdf file selection)
 * 5. Recursive crawling through Yemeni educational portals & blog download pages
 */
export async function downloadBinaryPdfWithCrawling(
  targetUrl: string,
  maxDepth = 2,
  visited = new Set<string>()
): Promise<{ buffer: Buffer; resolvedUrl: string; title?: string } | null> {
  const cleanUrl = targetUrl.trim();
  if (!cleanUrl || visited.has(cleanUrl)) return null;
  visited.add(cleanUrl);

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 12000);

  try {
    // 1. Google Drive direct handling & Large-file virus scan bypass (>25MB)
    const gdriveIdMatch = cleanUrl.match(
      /https?:\/\/(?:drive|docs)\.google\.com\/(?:file\/d\/|open\?id=|uc\?id=)([a-zA-Z0-9_-]+)/i
    );
    if (gdriveIdMatch) {
      const fileId = gdriveIdMatch[1];
      const directGdriveUrl = `https://drive.google.com/uc?export=download&id=${fileId}`;
      try {
        const gdRes = await fetch(directGdriveUrl, {
          headers: {
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            Accept: "application/pdf,application/octet-stream,*/*",
          },
          redirect: "follow",
        });
        if (gdRes.ok) {
          const gdBuf = Buffer.from(await gdRes.arrayBuffer());
          if (gdBuf.length >= 5 && gdBuf.slice(0, 5).toString("ascii").startsWith("%PDF")) {
            return { buffer: gdBuf, resolvedUrl: directGdriveUrl, title: "كتاب دراسي (Google Drive)" };
          }

          // Check for Google Drive Virus Scan confirmation page (for textbooks > 25MB)
          const gdHtml = gdBuf.toString("utf-8");
          const confirmToken =
            gdHtml.match(/confirm=([0-9a-zA-Z_-]+)/i)?.[1] ||
            gdHtml.match(/name="confirm"\s+value="([0-9a-zA-Z_-]+)"/i)?.[1];
          const confirmUrlMatch =
            gdHtml.match(/href="([^"]*(?:confirm=[a-zA-Z0-9_-]+|download\/confirm)[^"]*)"/i)?.[1] ||
            gdHtml.match(/action="([^"]*uc\?export=download[^"]*)"/i)?.[1];

          let finalConfirmUrl = "";
          if (confirmUrlMatch) {
            finalConfirmUrl = confirmUrlMatch.startsWith("http")
              ? confirmUrlMatch
              : `https://drive.google.com${confirmUrlMatch.startsWith("/") ? "" : "/"}${confirmUrlMatch}`.replace(
                  /&amp;/g,
                  "&"
                );
          } else if (confirmToken) {
            finalConfirmUrl = `https://drive.google.com/uc?export=download&confirm=${confirmToken}&id=${fileId}`;
          }

          if (finalConfirmUrl) {
            const rawCookies =
              (gdRes.headers as any).getSetCookie?.() || [gdRes.headers.get("set-cookie")].filter(Boolean);
            const cookieHeader = rawCookies.map((c: string) => c.split(";")[0]).join("; ");
            const confRes = await fetch(finalConfirmUrl, {
              headers: {
                "User-Agent":
                  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                Accept: "application/pdf,application/octet-stream,*/*",
                ...(cookieHeader ? { Cookie: cookieHeader } : {}),
              },
              redirect: "follow",
            });
            if (confRes.ok) {
              const confBuf = Buffer.from(await confRes.arrayBuffer());
              if (confBuf.length >= 5 && confBuf.slice(0, 5).toString("ascii").startsWith("%PDF")) {
                return { buffer: confBuf, resolvedUrl: finalConfirmUrl, title: "كتاب دراسي (Google Drive)" };
              }
            }
          }
        }
      } catch (gdErr) {
        console.warn("Google Drive direct download error:", gdErr);
      }
    }

    // 2. Mediafire handling: scrape direct download button from landing page
    if (/https?:\/\/(?:www\.)?mediafire\.com\//i.test(cleanUrl)) {
      try {
        const mfRes = await fetch(cleanUrl, {
          headers: {
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
          },
        });
        if (mfRes.ok) {
          const mfHtml = await mfRes.text();
          const dlBtnMatch =
            mfHtml.match(/href="((?:https?:)?\/\/download\d*\.mediafire\.com\/[^"]+)"/i)?.[1] ||
            mfHtml.match(/id="downloadButton"[^>]*href="([^"]+)"/i)?.[1] ||
            mfHtml.match(/aria-label="Download file"[^>]*href="([^"]+)"/i)?.[1];
          if (dlBtnMatch) {
            const mfDlUrl = dlBtnMatch.startsWith("//") ? `https:${dlBtnMatch}` : dlBtnMatch;
            const mfDlRes = await fetch(mfDlUrl, {
              headers: {
                "User-Agent":
                  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                Accept: "application/pdf,application/octet-stream,*/*",
              },
            });
            if (mfDlRes.ok) {
              const mfBuf = Buffer.from(await mfDlRes.arrayBuffer());
              if (mfBuf.length >= 5 && mfBuf.slice(0, 5).toString("ascii").startsWith("%PDF")) {
                return { buffer: mfBuf, resolvedUrl: mfDlUrl, title: "كتاب دراسي (Mediafire)" };
              }
            }
          }
        }
      } catch (mfErr) {
        console.warn("Mediafire download error:", mfErr);
      }
    }

    // 3. Archive.org details URL handling: query files metadata
    const archiveMatch = cleanUrl.match(/https?:\/\/archive\.org\/details\/([a-zA-Z0-9_\-\.]+)/i);
    if (archiveMatch) {
      const identifier = archiveMatch[1];
      try {
        const metaRes = await fetch(`https://archive.org/metadata/${identifier}/files`, {
          headers: { "User-Agent": "NotebookLM_Edu/1.0" },
        });
        if (metaRes.ok) {
          const metaData = await metaRes.json();
          const files: any[] = metaData.result || [];
          const pdfFile = files.find(
            (f: any) => f.name?.toLowerCase().endsWith(".pdf") && !f.name?.includes("_text.pdf")
          );
          if (pdfFile && pdfFile.name) {
            const archPdfUrl = `https://archive.org/download/${identifier}/${encodeURIComponent(pdfFile.name)}`;
            const archRes = await fetch(archPdfUrl, { redirect: "follow" });
            if (archRes.ok) {
              const archBuf = Buffer.from(await archRes.arrayBuffer());
              if (archBuf.length >= 5 && archBuf.slice(0, 5).toString("ascii").startsWith("%PDF")) {
                return { buffer: archBuf, resolvedUrl: archPdfUrl, title: identifier };
              }
            }
          }
        }
      } catch {}
    }

    // 4. Dropbox direct download transform
    let reqUrl = cleanUrl;
    if (/https?:\/\/(?:www\.)?dropbox\.com\//i.test(reqUrl) && !reqUrl.includes("dl=1")) {
      reqUrl = reqUrl.replace(/(\?|&)dl=0/g, "").concat(reqUrl.includes("?") ? "&dl=1" : "?dl=1");
    }

    // 5. General HTTP Fetch
    let res = await fetch(reqUrl, {
      signal: controller.signal,
      redirect: "follow",
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        Accept:
          "application/pdf,application/octet-stream,text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
      },
    });

    // Fallback proxy if direct fetch was blocked
    if (!res || !res.ok) {
      try {
        const pRes = await fetch(`https://corsproxy.io/?${encodeURIComponent(reqUrl)}`, {
          headers: {
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            Accept: "application/pdf,application/octet-stream,*/*",
          },
        });
        if (pRes.ok) res = pRes;
      } catch {}
    }

    if (!res || !res.ok) return null;

    const contentType = (res.headers.get("content-type") || "").toLowerCase();
    const arrayBuffer = await res.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);

    // Direct binary PDF (%PDF magic bytes)
    if (buffer.length >= 5 && buffer.slice(0, 5).toString("ascii").startsWith("%PDF")) {
      return { buffer, resolvedUrl: res.url || reqUrl };
    }

    // Content-Type indicates PDF and has sufficient size
    if (contentType.includes("application/pdf") && buffer.length > 500) {
      return { buffer, resolvedUrl: res.url || reqUrl };
    }

    // If it's an HTML page and depth permits, crawl it for embedded PDF download links
    if (maxDepth > 0 && (contentType.includes("text/html") || buffer.length < 1500000)) {
      const rawHtml = buffer.toString("utf-8");
      const candidateLinks = findPdfDownloadLinksInHtml(rawHtml, res.url || reqUrl);

      for (const candUrl of candidateLinks.slice(0, 10)) {
        if (!visited.has(candUrl)) {
          const subResult = await downloadBinaryPdfWithCrawling(candUrl, maxDepth - 1, visited);
          if (
            subResult &&
            subResult.buffer.length >= 5 &&
            subResult.buffer.slice(0, 5).toString("ascii").startsWith("%PDF")
          ) {
            return subResult;
          }
        }
      }
    }
  } catch (err: any) {
    console.warn(`Binary PDF crawl error for ${cleanUrl}:`, err?.message || err);
  } finally {
    clearTimeout(timer);
  }

  return null;
}

export interface SemanticDataBlock {
  id: string;
  blockIndex: number;
  title: string;
  content: string;
  keyConcepts: string[];
  charCount: number;
  prevBlockId: string | null;
  nextBlockId: string | null;
  citationRef: string;
  logicalSequence: number;
  sourceTitle: string;
  summarySnippet?: string;
}

export interface InitialIndexingReport {
  mainTitle: string;
  executiveSummary: string;
  keyTopics: string[];
  indexingStatus: "جاهز للاستجواب الدقيق";
  totalDataBlocks: number;
  indexedAt: string;
  sourceUrl?: string;
  contentType?: string;
}

export interface WebSearchResultItem {
  id: string;
  title: string;
  snippet: string;
  uri: string;
  domain: string;
  category: "curriculum" | "book" | "notes" | "solutions" | "wikipedia" | "academic" | "web" | "journal";
  author?: string;
  date?: string;
  grade?: string;
  subject?: string;
  country?: string;
  hasCachedContent?: boolean;
  relevanceScore?: number;
  summary?: string;
  executiveSummary?: string;
  keyTopics?: string[];
  dataBlocks?: SemanticDataBlock[];
  cleanContent?: string;
  indexingReport?: InitialIndexingReport;
  indexingStatus?: "جاهز للاستجواب الدقيق";
}

export interface WebSearchResponse {
  success: boolean;
  query: string;
  answer: string;
  text: string;
  sources: WebSearchResultItem[];
  totalCount: number;
  modelUsed?: string;
  provider: "gemini-grounding" | "multi-source-academic" | "curriculum-engine";
}

export interface StructuredContentReport {
  success: boolean;
  title: string;
  url: string;
  domain: string;
  summary: string;
  executiveSummary: string;
  keyTopics: string[];
  totalBlocks: number;
  dataBlocks: SemanticDataBlock[];
  indexingReport: InitialIndexingReport;
  extractedAt: string;
  contentType: string;
  status: "جاهز للاستجواب الدقيق";
  cleanText?: string;
  error?: string;
}

export interface ExportedSearchItem {
  id: string;
  title: string;
  url: string;
  domain: string;
  category: string;
  summary: string;
  executiveSummary: string;
  keyTopics: string[];
  indexingStatus: "جاهز للاستجواب الدقيق";
  relevanceScore?: number;
  dataBlocksCount: number;
  dataBlocks: SemanticDataBlock[];
  indexingReport?: InitialIndexingReport;
  cleanContentPreview?: string;
  author?: string;
  date?: string;
}

export interface ExportedSearchPayload {
  exportedAt: string;
  engine: string;
  query: string;
  totalResults: number;
  indexingStatus: "جاهز للاستجواب الدقيق";
  overviewAnswer?: string;
  results: ExportedSearchItem[];
}

// Common Arabic and English stopwords to exclude from key concept extraction
const ARABIC_STOPWORDS = new Set([
  "في", "من", "على", "إلى", "عن", "مع", "هذا", "هذه", "تم", "كان", "كانت", "يكون",
  "أن", "إن", "التي", "الذي", "الذين", "اللاتي", "كل", "ذلك", "تلك", "قد", "لا", "ما",
  "لم", "لن", "ثم", "أو", "أم", "بل", "لكن", "حيث", "بين", "خلال", "نحو", "غير", "كما",
  "وهو", "وهي", "هو", "هي", "هم", "نحن", "أنا", "أنتم", "هنا", "هناك", "عند", "بعد", "قبل",
  "the", "is", "at", "which", "on", "and", "a", "an", "in", "to", "for", "of", "with", "as"
]);

/**
 * Extract salient keywords and key concepts from text
 */
export function extractSalientKeywords(text: string, maxCount = 6): string[] {
  if (!text) return [];
  const words = text
    .toLowerCase()
    .replace(/[ًٌٍَُِّْـ]/g, "")
    .replace(/[أإآ]/g, "ا")
    .replace(/ى/g, "ي")
    .replace(/ة/g, "ه")
    .replace(/[^\p{L}\p{N}\s]/gu, " ")
    .split(/\s+/)
    .filter((w) => w.length > 2 && !ARABIC_STOPWORDS.has(w));

  const counts = new Map<string, number>();
  for (const w of words) {
    counts.set(w, (counts.get(w) || 0) + 1);
  }

  return Array.from(counts.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, maxCount)
    .map(([w]) => w);
}

/**
 * Segments clean web/document text into interconnected Semantic Data Blocks (كتل بيانات مترابطة سياقياً ومنطقياً)
 * Each block represents an independent concept or topic for precise semantic indexing,
 * cross-referencing, citations, and NotebookLM-style knowledge retrieval.
 */
export function segmentIntoSemanticDataBlocks(
  text: string,
  sourceTitle: string,
  targetBlockSize = 750
): SemanticDataBlock[] {
  if (!text || typeof text !== "string") return [];
  const clean = text.replace(/\r/g, "").trim();
  if (!clean) return [];

  // Split by double newlines, headings, or sentence boundaries if text is continuous
  let rawSegments = clean.split(/\n\s*\n/);
  if (rawSegments.length <= 1 || (rawSegments.length < 4 && clean.length > 2000)) {
    rawSegments = clean.split(/(?<=[.!?؟؛;\n])\s+/);
  }

  const blocks: SemanticDataBlock[] = [];
  let currentAccumulator: string[] = [];
  let currentLen = 0;
  let blockIndex = 1;
  const safeTitlePrefix = sourceTitle.replace(/[^\w\u0600-\u06FF]/g, "_").slice(0, 15) || "block";

  const flushBlock = (inferredTitle?: string) => {
    if (currentAccumulator.length === 0) return;
    const blockContent = currentAccumulator.join("\n\n").trim();
    if (blockContent.length < 50 && blocks.length > 0) {
      blocks[blocks.length - 1].content += "\n\n" + blockContent;
      blocks[blocks.length - 1].charCount = blocks[blocks.length - 1].content.length;
      currentAccumulator = [];
      currentLen = 0;
      return;
    }

    const keyConcepts = extractSalientKeywords(blockContent, 5);
    const firstLine = blockContent.split("\n")[0]?.replace(/^#+\s*/, "").trim() || "";
    const blockTitle =
      inferredTitle ||
      (firstLine.length >= 5 && firstLine.length <= 60
        ? firstLine
        : keyConcepts.length > 0
        ? `محور: ${keyConcepts.slice(0, 2).join(" و ")}`
        : `كتلة بيانات رقم ${blockIndex}`);

    const id = `${safeTitlePrefix}_block_${blockIndex}`;
    const prevBlockId = blockIndex > 1 ? `${safeTitlePrefix}_block_${blockIndex - 1}` : null;
    const citationRef = `[المصدر: ${sourceTitle} - الفقرة ${blockIndex}]`;
    const summarySnippet = blockContent.slice(0, 140).trim() + (blockContent.length > 140 ? "..." : "");

    // Link forward reference on previous block
    if (blocks.length > 0) {
      blocks[blocks.length - 1].nextBlockId = id;
    }

    blocks.push({
      id,
      blockIndex,
      title: blockTitle,
      content: blockContent,
      keyConcepts,
      charCount: blockContent.length,
      prevBlockId,
      nextBlockId: null,
      citationRef,
      logicalSequence: blockIndex,
      sourceTitle,
      summarySnippet,
    });

    blockIndex++;
    currentAccumulator = [];
    currentLen = 0;
  };

  for (const seg of rawSegments) {
    const trimmed = seg.trim();
    if (!trimmed) continue;

    // If an individual segment is very long, break it by sentences
    if (trimmed.length > targetBlockSize * 1.5) {
      const subSentences = trimmed.split(/(?<=[.!?؟؛;\n])\s+/);
      for (const sent of subSentences) {
        const sTrim = sent.trim();
        if (!sTrim) continue;
        currentAccumulator.push(sTrim);
        currentLen += sTrim.length;
        if (currentLen >= targetBlockSize) {
          flushBlock();
        }
      }
      continue;
    }

    const isHeading =
      /^#{1,4}\s+/.test(trimmed) ||
      /^(الوحدة|الفصل|المبحث|الدرس|الباب|القانون|المحور|النظرية|أولاً:|ثانياً:|ثالثاً:|رابعاً:|خامساً:)/i.test(trimmed);

    if (isHeading && currentLen >= 250) {
      flushBlock();
    }

    currentAccumulator.push(trimmed);
    currentLen += trimmed.length;

    if (currentLen >= targetBlockSize) {
      flushBlock();
    }
  }

  flushBlock();

  if (blocks.length === 0 && clean.length > 0) {
    const keyConcepts = extractSalientKeywords(clean, 5);
    blocks.push({
      id: `${safeTitlePrefix}_block_1`,
      blockIndex: 1,
      title: sourceTitle,
      content: clean,
      keyConcepts,
      charCount: clean.length,
      prevBlockId: null,
      nextBlockId: null,
      citationRef: `[المصدر: ${sourceTitle} - الفقرة 1]`,
      logicalSequence: 1,
      sourceTitle,
      summarySnippet: clean.slice(0, 140) + (clean.length > 140 ? "..." : ""),
    });
  }

  return blocks;
}

/**
 * Creates a structured Initial Indexing Report (تقرير الفهرسة الأولي)
 * conforming to the NotebookLM output protocol:
 * - العنوان الرئيسي: (عنوان المصدر)
 * - الملخص التنفيذي: (فقرة موجزة عن جوهر المحتوى)
 * - خريطة المفاهيم (Key Topics): (نقاط لأهم المواضيع)
 * - حالة الفهرسة: جاهز للاستجواب الدقيق
 */
export function createInitialIndexingReport(
  title: string,
  text: string,
  url?: string,
  contentType = "text/html"
): InitialIndexingReport {
  const { executiveSummary, keyTopics } = synthesizeSummaryAndTopics(text, title);
  const dataBlocks = segmentIntoSemanticDataBlocks(text, title);

  return {
    mainTitle: title,
    executiveSummary,
    keyTopics,
    indexingStatus: "جاهز للاستجواب الدقيق",
    totalDataBlocks: dataBlocks.length,
    indexedAt: new Date().toISOString(),
    sourceUrl: url,
    contentType,
  };
}

/**
 * Synthesizes high-level summary, executive summary, and key topics
 * from clean educational or web content.
 */
export function synthesizeSummaryAndTopics(
  text: string,
  title: string
): {
  summary: string;
  executiveSummary: string;
  keyTopics: string[];
} {
  const clean = text.replace(/\r/g, "").trim();
  if (!clean) {
    return {
      summary: `محتوى معرفي مستخلص لـ «${title}».`,
      executiveSummary: `محتوى معرفي مستخلص لـ «${title}».`,
      keyTopics: [`مفاهيم ${title}`],
    };
  }

  const rawSentences = clean
    .split(/(?<=[.!?؟؛;\n])\s+/)
    .map((s) => s.trim())
    .filter((s) => s.length >= 25 && s.length <= 280)
    .filter((s) => !/^(فهرس|مقدمة|المحتويات|حقوق الطبع|طبعة|دار النشر|رقم الإيداع)/i.test(s));

  let summary = "";
  if (rawSentences.length > 0) {
    summary = rawSentences.slice(0, 3).join(" ");
  } else {
    summary = clean.slice(0, 260) + (clean.length > 260 ? "..." : "");
  }

  let executiveSummary = "";
  if (rawSentences.length > 3) {
    executiveSummary = rawSentences.slice(0, 2).join(" ");
  } else {
    executiveSummary = summary;
  }

  if (summary.length > 350) summary = summary.slice(0, 347).trim() + "...";
  if (executiveSummary.length > 280) executiveSummary = executiveSummary.slice(0, 277).trim() + "...";

  const keyTopics: string[] = [];
  const lines = clean.split("\n");
  for (const line of lines) {
    const trimmed = line.trim();
    const headingMatch = trimmed.match(/^#{1,4}\s+(.+)$/);
    if (headingMatch && headingMatch[1].length <= 50) {
      const topic = headingMatch[1].trim();
      if (!keyTopics.includes(topic)) keyTopics.push(topic);
    } else if (
      /^(الوحدة|الفصل|المبحث|الدرس|الباب|القانون|المحور)\s+[^\n:.]+[:.]?/i.test(trimmed) &&
      trimmed.length <= 50
    ) {
      if (!keyTopics.includes(trimmed)) keyTopics.push(trimmed);
    }
    if (keyTopics.length >= 6) break;
  }

  if (keyTopics.length < 3) {
    const keywords = extractSalientKeywords(clean, 6);
    for (const kw of keywords) {
      const kwTopic = `مفهوم: ${kw}`;
      if (!keyTopics.includes(kwTopic) && keyTopics.length < 6) {
        keyTopics.push(kwTopic);
      }
    }
  }

  if (keyTopics.length === 0) {
    keyTopics.push(`ا��مفاهيم التأسيسية في ${title}`, `القواعد والتطبيقات العملية`);
  }

  return {
    summary,
    executiveSummary,
    keyTopics,
  };
}

// Real binary cache for processed documents
export const educationalContentCache = new Map<
  string,
  {
    title: string;
    content: string;
    contentType: string;
    wordCount: number;
    lineCount: number;
  }
>();

function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

function cleanHtmlSnippet(html: string): string {
  return html
    .replace(/<[^>]+>/g, "")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/\s+/g, " ")
    .trim();
}

/**
 * Detect if the search query is targeting educational curricula, school books,
 * study notes, summaries, grades, or exam materials.
 */
export function isEducationalOrCurriculumQuery(query: string): boolean {
  const eduKeywords =
    /(كتاب|كتب|منهج|مناهج|صف|الصفوف|ثانوي|ثانوية|متوسط|متوسطة|ابتدائي|ابتدائية|إعدادي|إعدادية|ملزمة|ملازم|ملخص|ملخصات|حلول|حل|شرح|دروس|درس|توجيهي|مقرر|مقررات|مادة|تاسع|عاشر|حادي عشر|بكالوريا|دليل المعلم|كراسة|سعودي|مصري|أردني|عراقي|سوري|يمني|إماراتي|كويتي|عماني|قطري|بحريني|مغربي|جزائري|تونسي|سوداني|مدرستي|عين|واجباتي|نظام مسارات)/i;
  return eduKeywords.test(query);
}

/**
 * Extract core subject keywords from a query (e.g. "كتاب الرياضيات الصف الثالث الثانوي المنهج السعودي" -> "رياضيات")
 */
function extractCoreSubject(query: string): string {
  const subjects = [
    "حديث",
    "تفسير",
    "توحيد",
    "فقه",
    "قرآن كريم",
    "قرآن",
    "تربية إسلامية",
    "سيرة نبوية",
    "عقيدة",
    "دراسات إسلامية",
    "رياضيات",
    "فيزياء",
    "كيمياء",
    "أحياء",
    "علوم",
    "لغة عربية",
    "أدب ونصوص",
    "أدب",
    "نصوص",
    "مطالعة",
    "نحو",
    "بلاغة",
    "قواعد",
    "لغة إنجليزية",
    "تاريخ",
    "جغرافيا",
    "دراسات اجتماعية",
    "تربية وطنية",
    "وطنية",
    "فلسفة",
    "منطق",
    "علم نفس",
    "علم اجتماع",
    "حاسب آلي",
    "برمجة",
    "تقنية رقمية",
    "إحصاء",
    "تفاضل وتكامل",
    "جبر",
    "هندسة",
    "جيولوجيا",
  ];

  for (const s of subjects) {
    if (query.includes(s)) {
      return s;
    }
  }

  // Fallback: remove stop words
  return query
    .replace(/(كتاب|كتب|منهج|مناهج|الصف|صف|الثانوي|المتوسط|الابتدائي|الإعدادي|ملزمة|ملخص|حلول|المنهج|اليمني|السعودي|المصري|الأردني|العراقي)/gi, "")
    .trim() || query;
}

/**
 * Normalize Arabic text for robust semantic matching and bidi/letter variance tolerance
 */
export function normalizeArabicText(text: string): string {
  if (!text) return "";
  return text
    .replace(/[\u064B-\u065F\u0670]/g, "") // remove tashkeel/harakat
    .replace(/[إأآٱ]/g, "ا")
    .replace(/ى/g, "ي")
    .replace(/ة/g, "ه")
    .replace(/[\r\n\t]+/g, " ")
    .replace(/[^\w\s\u0600-\u06FF]/g, " ")
    .toLowerCase()
    .trim();
}

/**
 * Common Arabic stop words to ignore during query token overlap calculation
 */
const ARABIC_STOP_WORDS = new Set([
  "في", "من", "على", "إلى", "الى", "عن", "مع", "هذا", "هذه", "هؤلاء", "تلك", "ذلك",
  "التي", "الذي", "الذين", "اللاتي", "اللواتي", "ان", "إن", "أن", "كان", "كانت",
  "يكون", "ما", "لم", "لن", "لا", "هل", "كل", "تم", "قد", "عبر", "حول", "بين",
  "هو", "هي", "هم", "هن", "نحن", "أنا", "انا", "انت", "أنت", "كما", "غير", "حيث",
  "عند", "عندما", "ثم", "أو", "او", "بل", "لكن", "حتى", "جدا", "فقط", "ذات", "نحو"
]);

/**
 * Standard school subjects and academic taxonomies for semantic alignment
 */
const ACADEMIC_SUBJECTS: Record<string, string[]> = {
  mathematics: ["رياضيات", "جبر", "هندسه", "تفاضل", "تكامل", "حساب", "احصاء", "مصفوفات", "دوال", "معادلات", "مثلثات", "متجهات"],
  chemistry: ["كيمياء", "عناصر", "تفاعلات", "مركبات", "عضوي", "روابط", "محاليل", "جدول دوري", "احماض", "قواعد", "اكسده"],
  physics: ["فيزياء", "حركه", "طاقه", "كهرباء", "مغناطيس", "كولوم", "نيوتن", "ضوء", "موجات", "نوويه", "جهد", "تيار", "سرعه", "تسارع", "قوانين"],
  biology: ["احياء", "علوم", "وراثه", "خليه", "بيئه", "تشريح", "نبات", "حيوان", "جينات", "تنفس", "هضم", "اعصاب", "احياء دقيقه"],
  arabic: ["عربيه", "نحو", "صرف", "بلاغه", "اعراب", "نصوص", "ادب", "قواعد", "شعر", "فاعل", "مفعول", "مبتدا", "خبر", "معاجم"],
  history_geography: ["تاريخ", "جغرافيا", "حضاره", "ثوره", "خرائط", "معاهده", "دول", "حروب", "دراسات اجتماعيه", "مناخ"],
  islamic: ["اسلاميه", "قران", "حديث", "فقه", "توحيد", "تفسير", "عقيده"],
  computer: ["حاسب", "برمجه", "تقنيه", "معلومات", "شبكات", "رقميه", "ذكاء اصطناعي", "خوارزميات", "بيانات"],
};

/**
 * Strict Semantic Relevance Evaluator:
 * Calculates match percentage between user's search query and retrieved result.
 * Strictly disqualifies entertainment/pop-culture and superficial wiki portals (Score = 0).
 * Requires minimum 70% relevance for curriculum/PDF mode.
 */
export function evaluateSemanticRelevance(
  userQuery: string,
  item: {
    title: string;
    snippet?: string;
    uri: string;
    domain?: string;
    category?: string;
  },
  mode: "curriculum" | "general" = "curriculum"
): { isRelevant: boolean; score: number; reason?: string } {
  const normQuery = normalizeArabicText(userQuery);
  const normTitle = normalizeArabicText(item.title || "");
  const normSnippet = normalizeArabicText(item.snippet || "");
  const normContent = `${normTitle} ${normSnippet}`;

  // 1. Strict Disqualification: Entertainment, pop-culture, TV series, songs, movies, drama, trivia
  const entertainmentRegex = /(مسلسل|مسلسلات|فيلم|افلام|اغنيه|اغاني|ممثل|ممثله|سينما|دراما|كوميديا|حلقات|حلقه|البوم|موسيقي|موسيقى|فنان|مشاهير|كليب|تلفزيون|شاهد نت|نتفليكس|مسرحيه|ترفيه)/i;
  if (entertainmentRegex.test(normTitle) || entertainmentRegex.test(normSnippet)) {
    if (!entertainmentRegex.test(normQuery)) {
      return { isRelevant: false, score: 0, reason: "محتوى ترفيهي أو غير دراسي (مسلسلات/أفلام)" };
    }
  }

  // 2. Strict Disqualification: Cooking recipes, Wikipedia navigation/shelf, donate, login, and non-academic lists
  const wikiMetaRegex =
    /(رفوف ويكي كتب|رفوف|بوابه|تصنيف|قالب|خاص|قائمه حلقات|صفحه رئيسيه|مسرحيات|رف:|صفحه_رئيسيه|كتاب الطبخ|طبخ|وصفات|تبرع|تسجيل الدخول|انقل للشريط الجانبي|بوابه المجتمع)/i;
  if (wikiMetaRegex.test(normTitle) || (wikiMetaRegex.test(normSnippet) && !wikiMetaRegex.test(normQuery))) {
    return { isRelevant: false, score: 0, reason: "صفحة فهرسة أو موضوع ترفيهي/غير دراسي أو قوائم تصفح" };
  }

  // 3. Educational open repositories (Wikibooks, Wikipedia): Accept if containing relevant subject matter
  let isOpenWikiSource =
    item.uri.includes("wikipedia.org") || item.uri.includes("wikibooks.org") || item.domain?.includes("wikipedia.org");

  // 3. Extract meaningful query tokens (ignoring stop words and 1-letter characters)
  const queryTokens = normQuery
    .split(/\s+/)
    .map(t => t.trim())
    .filter(t => t.length >= 2 && !ARABIC_STOP_WORDS.has(t));

  if (queryTokens.length === 0) {
    return { isRelevant: true, score: 75 };
  }

  // 4. Token match calculation
  let titleMatches = 0;
  let snippetMatches = 0;

  for (const token of queryTokens) {
    if (normTitle.includes(token)) {
      titleMatches++;
    } else if (normSnippet.includes(token)) {
      snippetMatches++;
    }
  }

  const tokenCoverage = (titleMatches * 1.0 + snippetMatches * 0.5) / queryTokens.length;

  // 5. Academic & Curriculum Intent Bonus
  const academicRegex = /(كتاب|كتب|ملزمه|ملازم|مذكره|مذكرات|منهج|مناهج|مقرر|مقررات|دليل المعلم|دليل|شرح|حلول|تمارين|اسئله|وزاري|اختبار|امتحان|الصف|صف|ثانوي|اعدادي|متوسط|ابتدائي|توجيهي|طالب|مدرسي|دراسي)/i;
  let academicBonus = 0;
  if (academicRegex.test(normTitle)) {
    academicBonus += 0.25;
  } else if (academicRegex.test(normSnippet)) {
    academicBonus += 0.15;
  }

  // 6. Direct PDF / Book Format Bonus
  let formatBonus = 0;
  const isDirectPdf = /\.pdf($|[?#])/i.test(item.uri) || /archive\.org\/download|drive\.google/i.test(item.uri);
  if (isDirectPdf || item.category === "book" || item.category === "curriculum") {
    formatBonus += 0.20;
  } else if (item.category === "notes" || item.category === "solutions") {
    formatBonus += 0.15;
  }

  // 7. Academic Subject Consistency Check
  let subjectBonus = 0;
  let subjectPenalty = 0;

  for (const [, keywords] of Object.entries(ACADEMIC_SUBJECTS)) {
    if (keywords.some(kw => normQuery.includes(kw))) {
      const subjectMatchedInDoc = keywords.some(kw => normContent.includes(kw));
      if (subjectMatchedInDoc) {
        subjectBonus = 0.15;
      } else {
        // Query clearly targeted a specific subject but document has no matching domain terms
        subjectPenalty = 0.20;
      }
      break;
    }
  }

  // 8. Calculate Composite Semantic Relevance Score
  let rawScore = (tokenCoverage * 0.45) + academicBonus + formatBonus + subjectBonus - subjectPenalty;

  // Exact phrase match boost
  if (normTitle.includes(normQuery) || (normQuery.length > 8 && normSnippet.includes(normQuery))) {
    rawScore = Math.max(rawScore, 0.85);
  }

  const finalScore = Math.min(1.0, Math.max(0.0, rawScore));
  const scorePercent = Math.round(finalScore * 100);

  // Requirement: Minimum 70% semantic match threshold for curriculum mode!
  const minThreshold = mode === "curriculum" ? 70 : 60;
  const isRelevant = scorePercent >= minThreshold;

  return {
    isRelevant,
    score: scorePercent,
    reason: isRelevant ? "تطابق دلالي أكاديمي محقق" : `نسبة التطابق (${scorePercent}%) أقل من الحد الأدنى الإلزامي (${minThreshold}%)`,
  };
}

/**
 * Search Internet Archive specifically for textbooks, books, and study guides
 */
export async function searchArchiveOrg(query: string, mode: "curriculum" | "general" = "curriculum"): Promise<WebSearchResultItem[]> {
  const results: WebSearchResultItem[] = [];
  const seenIds = new Set<string>();

  const coreSubject = extractCoreSubject(query);
  const norm = normalizeArabicText(query);
  const gradeMatch = norm.match(/(اول|ثاني|ثالث|رابع|خامس|سادس|سابع|ثامن|تاسع|عاشر|حادي عشر|ثاني عشر|توجيهي|ثانوي|متوسط|اعدادي|ابتدائي)/i)?.[0] || "";

  // Queries to try: 1) Subject + Grade/Stage (e.g. "كيمياء اول ثانوي"), 2) Subject + ثانوي, 3) full clean search
  const queryCandidates: string[] = [];
  if (coreSubject && gradeMatch && coreSubject !== gradeMatch) {
    queryCandidates.push(`${coreSubject} ${gradeMatch}`);
  }
  if (coreSubject) {
    queryCandidates.push(`${coreSubject} ثانوي`);
    queryCandidates.push(coreSubject);
  }
  const cleanSearch = query.replace(/[^\w\s\u0600-\u06FF]/g, " ").trim();
  if (cleanSearch && !queryCandidates.includes(cleanSearch)) {
    queryCandidates.push(cleanSearch);
  }

  await Promise.all(
    queryCandidates.slice(0, 3).map(async (qCandidate) => {
      try {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 3500);
        const url = `https://archive.org/advancedsearch.php?q=${encodeURIComponent(
          qCandidate
        )}+AND+mediatype:(texts)&fl[]=identifier,title,description,creator,year&rows=5&output=json`;
        const res = await fetch(url, {
          signal: controller.signal,
          headers: { "User-Agent": "NotebookLM_Edu/1.0" },
        });
        clearTimeout(timer);
        if (res.ok) {
          const data = await res.json();
          const docs = data.response?.docs || [];
          for (const doc of docs) {
            if (doc.identifier && doc.title && !seenIds.has(doc.identifier)) {
              seenIds.add(doc.identifier);
              const downloadPdfUri = `https://archive.org/download/${doc.identifier}/${encodeURIComponent(doc.identifier)}.pdf`;
              const snippet = doc.description
                ? cleanHtmlSnippet(doc.description).slice(0, 240) + "..."
                : "كتاب ومستند دراسي موثق من مستودعات الأرشيف الرقمي المفتوحة.";
              results.push({
                id: `archive_${doc.identifier}`,
                title: `📄 [كتاب رقمي] ${doc.title}`,
                snippet,
                uri: downloadPdfUri,
                domain: "archive.org",
                category: "book",
                author: doc.creator || "مكتبة الأرشيف الرقمي",
                date: doc.year ? doc.year.toString() : undefined,
              });
            }
          }
        }
      } catch (err) {
        // Silently catch network timeouts
      }
    })
  );

  return results;
}

/**
 * Search Wikibooks for open textbooks and courses (only in general mode, strictly excluding meta/shelf junk)
 */
async function searchWikibooks(query: string): Promise<WebSearchResultItem[]> {
  const results: WebSearchResultItem[] = [];
  try {
    const subject = extractCoreSubject(query);
    const url = `https://ar.wikibooks.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(
      subject
    )}&utf8=&format=json&origin=*`;
    const res = await fetch(url, { headers: { "User-Agent": "NotebookLM_Edu/1.0" } });
    if (res.ok) {
      const data = await res.json();
      const items = data.query?.search || [];
      for (const item of items.slice(0, 5)) {
        // Exclude generic portals, shelves, cooking books, donate, and meta pages
        if (
          /(رفوف|رف:|بوابة:|تصنيف:|قالب:|خاص:|ويكيبيديا:|مسلسل|فيلم|الصفحة الرئيسية|صفحة رئيسية|كتاب الطبخ|طبخ|أطعمة|وصفات|تبرع|تسجيل الدخول|مستخدم:|نقاش)/i.test(
            item.title
          )
        ) {
          continue;
        }
        const uri = `https://ar.wikibooks.org/wiki/${encodeURIComponent(item.title.replace(/ /g, "_"))}`;
        results.push({
          id: `wikibooks_${item.pageid || Date.now() + Math.random()}`,
          title: `[مقرر ويكي الكتب] ${item.title}`,
          snippet: cleanHtmlSnippet(item.snippet || "كتاب دراسي مفتوح ومنهاج معرفي متكامل."),
          uri,
          domain: "ar.wikibooks.org",
          category: "curriculum",
          hasCachedContent: true,
        });
      }
    }
  } catch (err) {
    console.warn("Wikibooks search error:", err);
  }
  return results;
}

/**
 * Subject-focused Wikipedia search (only in general mode, strictly filtering out entertainment and portals)
 */
async function searchWikipediaSubject(query: string): Promise<WebSearchResultItem[]> {
  const subject = extractCoreSubject(query);
  const results: WebSearchResultItem[] = [];

  try {
    const arUrl = `https://ar.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(
      subject
    )}&utf8=&format=json&origin=*`;
    const arRes = await fetch(arUrl, { headers: { "User-Agent": "NotebookLM_Edu/1.0" } });
    if (arRes.ok) {
      const arData = await arRes.json();
      const items = arData.query?.search || [];
      for (const item of items.slice(0, 3)) {
        // Filter out entertainment, disambiguation, cooking, donate, and portal pages
        if (
          /(مسلسل|فيلم|أغنية|ممثل|ممثلة|بوابة:|تصنيف:|قالب:|توضيح|دراما|كتاب الطبخ|طبخ|��صفات|تبرع|تسجيل الدخول|قائمة)/i.test(
            item.title
          )
        ) {
          continue;
        }
        results.push({
          id: `wiki_ar_${item.pageid || Date.now() + Math.random()}`,
          title: `[موسوعة] ${item.title}`,
          snippet: cleanHtmlSnippet(item.snippet || "مقالة موسوعية تأسيسية للموضوع."),
          uri: `https://ar.wikipedia.org/wiki/${encodeURIComponent(item.title.replace(/ /g, "_"))}`,
          domain: "ar.wikipedia.org",
          category: "wikipedia",
        });
      }
    }
  } catch (err) {
    console.warn("Wikipedia subject search error:", err);
  }
  return results;
}

/**
 * Intelligent Educational & Curriculum Search with Gemini
 * Uses gemini-3.1-flash-lite which is extremely fast and avoids 429 quota locks.
 */
async function searchCurriculumAndStudyMaterials(query: string): Promise<{
  curriculumOverview: string;
  sources: WebSearchResultItem[];
  subject?: string;
  grade?: string;
  country?: string;
} | null> {
  const ai = getGeminiClient();
  if (!ai) return null;

  const candidateModels = ["gemini-3.8-flash", "gemini-3.5-flash-lite", "gemini-3.1-flash-lite"];
  const prompt = `أنت مفهرس ومساعد ذكي متقدم متخصص في الكتب والمناهج المدرسية والملازم والملخصات الدراسية العربية والعالمية (مثل NotebookLM التعليمي).
المستخدم يبحث بدقة عن: "${query}".

المطلوب:
تحليل المنهج والصف والمادة والدولة المذكورة في بحث المستخدم، واستخراج معلومات حقيقية ودقيقة ومنهجية بالصيغة التالية (أجب بصيغة JSON فقط دون أي نصوص خارجية):
{
  "curriculumOverview": "توصيف دقيق وشامل ومكثف للمنهج والصف المحدد، الفصول الدراسية، الوحدات والدروس المقررة، أهداف التعلم، وأهم القوانين والمفاهيم الأساسية المقررة لهذا المنهج بالتحديد ليستفيد منه الطالب فوراً",
  "subject": "اسم المادة الدراسية بدقة",
  "grade": "الصف الدراسي المحدد بدقة",
  "country": "الدولة أو نوع المنهج",
  "sources": [
    {
      "title": "اسم الكتاب المدرسي الرسمي المعتمد (مثال: كتاب الرياضيات - الصف الثالث الثانوي - المنهج المعتمد)",
      "uri": "https://ien.sa/ (أو رابط المنصة الرسمية لوزارة التعليم في الدولة مثل بنك المعرفة أو درسك)",
      "snippet": "توصيف محتوى الكتاب المدرسي والوحدات والفصول المقررة للطلاب لهذا الفصل",
      "category": "curriculum",
      "studyContent": "ملخص كامل ومفصل لكتاب الطالب والوحدات المقررة مع القوانين والتعاريف لتضمينها في دفتر الطالب"
    },
    {
      "title": "ملزمة ومذكرة الشرح والملخص الشامل للمنهج",
      "uri": "https://www.wajibati.net/ (أو رابط ملزمة مذكرات الشرح والملخصات المعتمدة)",
      "snippet": "ملخص مكثف للدروس، القواعد الرئيسية، شرح المفاهيم خطوة بخطوة، والخرائط الذهنية",
      "category": "notes",
      "studyContent": "نص المذكرة والملخص الدراسي الكامل متضمناً شرح القواعد والملخصات المنهجية الجاهزة للقراءة والاستذكار"
    },
    {
      "title": "دليل حلول التمارين والأسئلة والامتحانات الوزارية السابقة",
      "uri": "https://hululkit.com/ (أو رابط بنك الحلول والأسئلة الوزارية)",
      "snippet": "حلول المسائل والأنشطة، ونماذج امتحانات وزارية محلولة لتدريب الطالب على الاختبارات",
      "category": "solutions",
      "studyContent": "دليل الحلول والتمارين ونماذج الأسئلة والحلول النموذجية المقررة لهذا الصف والمنهج"
    }
  ]
}`;

  for (const model of candidateModels) {
    try {
      const response = await ai.models.generateContent({
        model,
        contents: prompt,
      });

      const raw = (response.text || "").trim();
      const cleaned = raw.replace(/^```json\s*/i, "").replace(/\s*```$/i, "").trim();
      const parsed = JSON.parse(cleaned);

      if (parsed.curriculumOverview) {
        return {
          curriculumOverview: parsed.curriculumOverview,
          sources: [], // No synthetic stubs; all books must come from real web PDFs and digitised archives
          subject: parsed.subject,
          grade: parsed.grade,
          country: parsed.country,
        };
      }
    } catch (err: any) {
      console.warn(`Curriculum search error with ${model}:`, err?.message || err);
    }
  }

  return null;
}

/**
 * Generate Local Educational Synthesis when cloud AI is unreachable
 */
function generateLocalCurriculumSynthesis(query: string, subject: string): string {
  return `## 📚 التوليف الدراسي الشامل: «${query}»

تم تحليل وتحديد المنهج والصف الدراسي المطلوب بدقة، وفهرسة المصادر والكتب والملازم الدراسية المرتبطة به.

### 💡 محاور المنهج المقررة:
- **المحتوى الأساسي لمادة ${subject}**: يركز المنهج على إكساب الطالب المفاهيم التأسيسية، القوانين المنهجية، والتطبيقات النموذجية وفق أحدث الطبعات المعتمدة.
- **الوحدات والفصول**: تم تنظيم المنهج وفق خطة التوزيع الدراسي لضمان شمولية المهارات وتدرجها المعرفي.
- **الاختبارات والتقييم**: تشتمل المصادر المرفقة أدناه على كتب الطالب المعتمدة، الملازم الشارحة، ونماذج بنوك الأسئلة الوزارية وحلولها.

> 💡 **نصيحة NotebookLM**: اضغط على زر **«+ إضافة إلى الدفتر»** بجوار الكتاب المدرسي أو الملزمة لإضافتها فورياً لذاكرة دفترك وبدء تلخيصها وطرح الأسئلة عليها.`;
}

/**
 * Fetch papers from ArXiv API (only for general/scientific queries, skipped for school curricula)
 */
async function searchArxiv(query: string): Promise<WebSearchResultItem[]> {
  const results: WebSearchResultItem[] = [];
  try {
    const cleanQuery = query.replace(/[^\w\s\u0600-\u06FF]/g, " ").trim();
    const url = `https://export.arxiv.org/api/query?search_query=all:${encodeURIComponent(
      cleanQuery
    )}&start=0&max_results=3`;
    const res = await fetch(url, { headers: { "User-Agent": "NotebookLM_Edu/1.0" } });
    if (res.ok) {
      const xml = await res.text();
      const entries = xml.split("<entry>").slice(1);
      for (const entry of entries) {
        const titleMatch = entry.match(/<title>([\s\S]*?)<\/title>/);
        const summaryMatch = entry.match(/<summary>([\s\S]*?)<\/summary>/);
        const idMatch = entry.match(/<id>([\s\S]*?)<\/id>/);
        const authorMatch = entry.match(/<author>[\s\S]*?<name>([\s\S]*?)<\/name>/);
        const publishedMatch = entry.match(/<published>([\s\S]*?)<\/published>/);

        if (titleMatch && idMatch) {
          const rawTitle = titleMatch[1].trim().replace(/\n+/g, " ");
          const rawSummary = summaryMatch ? summaryMatch[1].trim().replace(/\n+/g, " ") : "";
          results.push({
            id: `arxiv_${Math.random().toString(36).substring(2, 9)}`,
            title: `[ورقة بحثية] ${rawTitle}`,
            snippet: rawSummary ? rawSummary.slice(0, 240) + "..." : "بحث علمي موثق من مستودع أبحاث arXiv.",
            uri: idMatch[1].trim(),
            domain: "arxiv.org",
            category: "academic",
            author: authorMatch ? authorMatch[1].trim() : "باحثون أكاديميون",
            date: publishedMatch ? publishedMatch[1].slice(0, 10) : undefined,
          });
        }
      }
    }
  } catch (err) {
    console.warn("ArXiv search error:", err);
  }
  return results;
}

/**
 * Fetch articles from CrossRef API (only for general/scientific queries)
 */
async function searchCrossRef(query: string): Promise<WebSearchResultItem[]> {
  const results: WebSearchResultItem[] = [];
  try {
    const url = `https://api.crossref.org/works?query=${encodeURIComponent(
      query
    )}&rows=3&select=title,URL,publisher,abstract,DOI,author,created`;
    const res = await fetch(url, {
      headers: { "User-Agent": "NotebookLM_Edu/1.0 (mailto:academic-support@ai.studio)" },
    });
    if (res.ok) {
      const data = await res.json();
      const items = data.message?.items || [];
      for (const item of items) {
        if (item.title && item.title.length > 0 && item.URL) {
          const title = item.title[0];
          const snippet = item.abstract
            ? cleanHtmlSnippet(item.abstract).slice(0, 220) + "..."
            : `ورقة أكاديمية منشورة عبر دار النشر ${item.publisher || "المعتمدة"} (DOI: ${item.DOI || ""}).`;
          const author = item.author?.[0]?.family
            ? `${item.author[0].given || ""} ${item.author[0].family}`.trim()
            : undefined;

          results.push({
            id: `crossref_${Math.random().toString(36).substring(2, 9)}`,
            title: `[دراسة محكمة] ${title}`,
            snippet,
            uri: item.URL,
            domain: "doi.org",
            category: "journal",
            author,
            date: item.created?.["date-parts"]?.[0]?.[0]?.toString(),
          });
        }
      }
    }
  } catch (err) {
    console.warn("CrossRef search error:", err);
  }
  return results;
}

/**
 * Universal Google Web Search using Gemini Google Search Grounding
 * Searches the web and strictly restricts queries behind the scenes with `filetype:pdf`
 * and mandatory curriculum keywords to guarantee direct, downloadable PDF textbooks and academic materials.
 */
async function searchGoogleWebUniversal(
  query: string,
  mode: "curriculum" | "general" = "curriculum"
): Promise<{ answer: string; sources: WebSearchResultItem[] } | null> {
  const ai = getGeminiClient();
  if (!ai) return null;

  // Strict Query Engineering: Enforce `(كتاب OR ملزمة OR مذكرة OR منهج OR دليل المعلم)` and `filetype:pdf`
  const cleanQ = query.trim();
  const hasFileType = /filetype:\w+/i.test(cleanQ);
  const hasCurriculumKw = /(كتاب|ملزمة|مذكرة|منهج|دليل المعلم)/i.test(cleanQ);

  let engineeredQuery = cleanQ;
  if (mode === "curriculum") {
    if (!hasCurriculumKw) {
      engineeredQuery = `${engineeredQuery} (كتاب OR ملزمة OR مذكرة OR منهج OR دليل المعلم)`;
    }
    if (!hasFileType) {
      engineeredQuery = `${engineeredQuery} filetype:pdf`;
    }
  }

  const prompt = mode === "curriculum"
    ? `أنت محرك بحث أكاديمي ومدرسي صارم فائق الدقة متخصص حصرياً في العثور على الكتب والمناهج المدرسية وملفات الـ PDF المباشرة (Direct PDF & School Curriculum Search Engine).
قواعد الأمان والبحث الآمن الإلزامية (Strict SafeSearch: ACTIVE):
1. الالتزام الصارم بالبحث الآمن (SafeSearch: Active) واستبعاد أي محتوى غير لائق أو ترفيهي أو غير دراسي.
2. استبعاد موسوعة ويكيبيديا المفتوحة (Wikipedia) وويكي كتب تماماً من نتائج المناهج (Strict Whitelist).
3. قيد النتائج حصراً بروابط ملفات الـ PDF المباشرة والمستندات التعليمية والكتب والملازم والمقررات القابلة للتنزيل الفوري.
4. ركز على روابط المناهج الدراسية، الكتب المدرسية الرسمية المعتمدة (مثل المنهج اليمني، السعودي، المصري، الأردني)، المستودعات الأكاديمية (مثل Archive.org، المكتبات الرقمية، مواقع وزارات التعليم، واجباتي، عين).
المستخدم يبحث عن: "${cleanQ}".
استعلام البحث الإلزامي المقيد خلف الكواليس: "${engineeredQuery}".`
    : `أنت محرك بحث أكاديمي ومعرفي شامل للتعليم والبحوث الرقمية.
قواعد الأمان: الالتزام الصارم بالبحث الآمن (Strict SafeSearch: Active) واستبعاد أي محتوى غير لائق.
المستخدم يبحث عن: "${cleanQ}".
استخرج أفضل المراجع والكتب والمقالات الأكاديمية الموثقة حول هذا الموضوع بدقة.`;

  const candidateModels = ["gemini-3.8-flash", "gemini-3.5-flash-lite", "gemini-3.1-flash-lite"];
  for (const model of candidateModels) {
    try {
      const response = await ai.models.generateContent({
        model,
        contents: prompt,
        config: {
          tools: [{ googleSearch: {} }],
        },
      });

      const text = response.text || "";
      const grounding = response.candidates?.[0]?.groundingMetadata;
      const sources: WebSearchResultItem[] = [];

      if (grounding?.groundingChunks && Array.isArray(grounding.groundingChunks)) {
        for (const chunk of grounding.groundingChunks) {
          if (chunk.web?.uri) {
            let domain = "web";
            try {
              domain = new URL(chunk.web.uri).hostname.replace(/^www\./, "");
            } catch (e) {}

            // Exclude open Wikipedia and Wikibooks from curriculum search
            if (
              mode === "curriculum" &&
              (domain.includes("wikipedia.org") || domain.includes("wikibooks.org") || domain.includes("wikimedia.org"))
            ) {
              continue;
            }

            // Support educational Telegram channels (t.me / telegram.me) for study notes, summaries, and books
            const isTelegram = domain.includes("t.me") || domain.includes("telegram.me");
            if (isTelegram) {
              const tgTitle = chunk.web.title || "مكتبة تلجرام التعليمية (ملازم وكتب PDF)";
              sources.push({
                id: `tg_${Math.random().toString(36).substring(2, 9)}`,
                title: `📱 [مكتبة تلجرام دراسية] ${tgTitle}`,
                snippet: `ملزمة ومستند دراسي موثق مسترجع من قنوات تلجرام التعليمية المفتوحة: ${tgTitle}`,
                uri: chunk.web.uri,
                domain: "t.me",
                category: "notes",
              });
              continue;
            }

            // Exclude non-educational social media or video entertainment domains
            if (
              /(facebook|twitter|instagram|tiktok|youtube|pinterest|reddit|imdb|netflix|dailymotion|shahid)/i.test(
                domain
              )
            ) {
              continue;
            }

            // Exclude news newspapers, journalism, or non-educational news portals (e.g. صحيفة عين, أخبار)
            if (
              mode === "curriculum" &&
              !/\.pdf($|[?#])/i.test(chunk.web.uri) &&
              /(news|akhbar|newspaper|sahifa|press|media|al-ain|ain\.news|alain|sabq|alyaum|okaz|alriyadh)/i.test(
                domain
              )
            ) {
              continue;
            }

            const isPdf =
              /\.pdf($|[?#])/i.test(chunk.web.uri) ||
              /drive\.google|archive\.org\/download|mediafire/i.test(chunk.web.uri);
            const title = chunk.web.title || (isPdf ? `[كتاب PDF مباشر] ${domain}` : `مرجع دراسي: ${domain}`);
            sources.push({
              id: `gsearch_${Math.random().toString(36).substring(2, 9)}`,
              title: isPdf ? `📄 [كتاب/مستند PDF] ${title}` : title,
              snippet: isPdf
                ? `رابط مباشر لملف PDF دراسي جاهز للقراءة والتفكيك والفهرسة في الدفتر.`
                : `مصدر دراسي معتمد من نتائج بحث المناهج والكتب.`,
              uri: chunk.web.uri,
              domain,
              category: isPdf ? "book" : "curriculum",
            });
          }
        }
      }

      if (text || sources.length > 0) {
        return { answer: text, sources };
      }
    } catch (err: any) {
      console.warn(`Universal Google Search Grounding with ${model} warning:`, err?.message || err);
    }
  }
  return null;
}

/**
 * Main Web & Curriculum Search Dispatcher with Strict Semantic Filtering and Mode Support
 */
export async function executeWebSearch(
  query: string,
  mode: "curriculum" | "general" = "curriculum"
): Promise<WebSearchResponse> {
  const trimmed = query.trim();

  // If direct URL
  if (/^https?:\/\//i.test(trimmed)) {
    try {
      const urlObj = new URL(trimmed);
      const domain = urlObj.hostname.replace(/^www\./, "");
      return {
        success: true,
        query: trimmed,
        answer: `تم العثور على الرابط المباشر: **${trimmed}**. يمكنك الآن إضافته بضغطة زر إلى دفترك لتفكيكه وتحليله.`,
        text: `تم العثور على الرابط المباشر: **${trimmed}**. يمكنك الآن إضافته بضغطة زر إلى دفترك لتفكيكه وتحليله.`,
        sources: [
          {
            id: `direct_url_${Date.now()}`,
            title: `مصدر مباشر: ${domain}`,
            snippet: `رابط ويب مباشر تم إدخاله بواسطة المستخدم: ${trimmed}`,
            uri: trimmed,
            domain,
            category: "web",
            relevanceScore: 100,
          },
        ],
        totalCount: 1,
        provider: "multi-source-academic",
      };
    } catch (e) {}
  }

  const isEdu = isEducationalOrCurriculumQuery(trimmed);
  const coreSubject = extractCoreSubject(trimmed);

  // In 'curriculum' mode: strictly exclude superficial Wikipedia & Wikibooks!
  // In 'general' mode: include academic web & encyclopedias with strict filtering.
  const [googleResult, eduResult, archiveBooks, wikibooks, wikiSubject] = await Promise.all([
    searchGoogleWebUniversal(trimmed, mode),
    isEdu ? searchCurriculumAndStudyMaterials(trimmed) : Promise.resolve(null),
    searchArchiveOrg(trimmed, mode),
    mode === "general" ? searchWikibooks(trimmed) : Promise.resolve([]),
    mode === "general" ? searchWikipediaSubject(trimmed) : Promise.resolve([]),
  ]);

  const allSources: WebSearchResultItem[] = [];
  const seenUris = new Set<string>();

  // Prioritize Google Web Grounding sources (including direct PDFs found worldwide)
  if (googleResult?.sources) {
    for (const s of googleResult.sources) {
      if (!seenUris.has(s.uri)) {
        seenUris.add(s.uri);
        allSources.push(s);
      }
    }
  }

  // Add high-priority educational sources
  if (eduResult?.sources) {
    for (const s of eduResult.sources) {
      if (!seenUris.has(s.uri)) {
        seenUris.add(s.uri);
        allSources.push(s);
      }
    }
  }

  // Add archive.org digital books
  for (const s of archiveBooks) {
    if (!seenUris.has(s.uri)) {
      seenUris.add(s.uri);
      allSources.push(s);
    }
  }

  // Add wikibooks courses (only in general mode)
  for (const s of wikibooks) {
    if (!seenUris.has(s.uri)) {
      seenUris.add(s.uri);
      allSources.push(s);
    }
  }

  // Add foundational wikipedia subject article (only in general mode)
  for (const s of wikiSubject) {
    if (!seenUris.has(s.uri)) {
      seenUris.add(s.uri);
      allSources.push(s);
    }
  }

  // Apply Strict Semantic Relevance Filtering (>= 70% in curriculum mode, >= 60% in general mode)
  const filteredSources: WebSearchResultItem[] = [];
  for (const s of allSources) {
    const evalRes = evaluateSemanticRelevance(trimmed, s, mode);
    if (evalRes.isRelevant) {
      s.relevanceScore = evalRes.score;
      filteredSources.push(s);
    }
  }

  // Sort by highest relevance score descending
  filteredSources.sort((a, b) => (b.relevanceScore || 0) - (a.relevanceScore || 0));

  // Enrich each search result with clean summaries, key topics, semantic data blocks, and indexing status
  for (const s of filteredSources) {
    if (!s.summary) {
      const { summary, executiveSummary, keyTopics } = synthesizeSummaryAndTopics(
        s.snippet || s.title,
        s.title
      );
      s.summary = summary;
      s.executiveSummary = executiveSummary;
      s.keyTopics = keyTopics;
    }
    if (!s.dataBlocks || s.dataBlocks.length === 0) {
      s.dataBlocks = segmentIntoSemanticDataBlocks(
        s.snippet || s.title,
        s.title,
        350
      );
    }
    if (!s.indexingReport) {
      s.indexingReport = createInitialIndexingReport(
        s.title,
        s.snippet || s.title,
        s.uri
      );
    }
    s.indexingStatus = "جاهز للاستجواب الدقيق";
  }

  let finalAnswer = googleResult?.answer || "";
  if (!finalAnswer && eduResult?.curriculumOverview) {
    finalAnswer = `## 📚 التوصيف المعرفي الشامل للمنهج والكتاب:\n\n${eduResult.curriculumOverview}\n\n` +
      (eduResult.subject ? `- **المادة الدراسية**: ${eduResult.subject}\n` : "") +
      (eduResult.grade ? `- **الصف والمرحلة**: ${eduResult.grade}\n` : "") +
      (eduResult.country ? `- **المنهج والاعتماد**: ${eduResult.country}\n\n` : "\n") +
      `> 💡 **جاهز للإضافة**: يمكنك إضافة أي من الكتب المدرسية أو الملازم والحلول أدناه لدفترك مباشرة بضغطة زر لبدء مذاكرتها وطرح الأسئلة عليها.`;
  } else if (!finalAnswer) {
    finalAnswer = generateLocalCurriculumSynthesis(trimmed, coreSubject);
  }

  return {
    success: true,
    query: trimmed,
    answer: finalAnswer,
    text: finalAnswer,
    sources: filteredSources,
    totalCount: filteredSources.length,
    provider: googleResult ? "gemini-grounding" : isEdu ? "curriculum-engine" : "multi-source-academic",
    modelUsed: "gemini-3.8-flash",
  };
}

/**
 * Fetch and Extract Content from any URL:
 * 1. Strictly prioritizes real binary PDF streams (%PDF magic bytes) using deep crawling,
 *    Google Drive large-file virus bypass, Mediafire scraping, and Archive.org metadata resolution.
 * 2. Processes all book pages page-by-page via PDF parser with Arabic reshaping.
 * 3. STRICT ANTI-MOCK BAN: Rejects HTML pages for books/curricula and prompts user for direct file upload.
 */
export async function fetchCleanContentFromUrl(url: string): Promise<{
  success: boolean;
  title: string;
  content: string;
  text: string;
  url: string;
  contentType: string;
  wordCount: number;
  lineCount: number;
  size: number;
  rawHtml?: string;
  dataBase64?: string;
  type: string;
  pageCount?: number;
  pages?: Array<{ pageNumber: number; text: string }>;
}> {
  const cleanUrl = url.trim();

  // 1. Direct Rejection for non-PDF messaging/social channels
  if (/https?:\/\/(?:t\.me|telegram\.me|telegram\.org|facebook\.com|twitter\.com)\//i.test(cleanUrl)) {
    throw new Error("الصفحة لا تحتوي على ملف كتاب PDF مباشر، يرجى رفع الملف من جهازك");
  }

  let isBookOrCurriculum =
    /(كتاب|كتب|منهج|مناهج|ملزمة|ملازم|مقرر|hadith|حديث|قرآن|فقه|تفسير|توحيد|صف|ثانوي|متوسط|ابتدائي|إعدادي|pdf|تحميل|تنزيل|طالب|معلم)/i.test(
      cleanUrl
    );

  // 4. Primary Crawling: Attempt direct binary PDF retrieval (including deep link crawling & bypasses)
  const pdfDownloadResult = await downloadBinaryPdfWithCrawling(cleanUrl);
  if (
    pdfDownloadResult &&
    pdfDownloadResult.buffer &&
    pdfDownloadResult.buffer.length >= 5 &&
    pdfDownloadResult.buffer.slice(0, 5).toString("ascii").startsWith("%PDF")
  ) {
    const { text: pdfText, totalPages, pages } = await extractPdfFromBuffer(pdfDownloadResult.buffer);
    const wordCount = pdfText.split(/\s+/).filter(Boolean).length;
    const lineCount = pdfText.split("\n").length;
    const fallbackTitle = decodeURIComponent(
      (pdfDownloadResult.resolvedUrl || cleanUrl).split("/").pop()?.replace(/[?#].*$/, "") || "كتاب دراسي PDF"
    );

    // Multi-page check: Real textbooks/curricula have multiple pages.
    // Ensure we extracted pages and content safely
    if (totalPages <= 0 && (!pdfText || pdfText.trim().length === 0)) {
      throw new Error(
        "تعذر استخراج صفحات هذا الملف كـ PDF. يُرجى استخدام خيار [رفع ملفات] لاختيار الكتاب من هاتفك أو جهازك مباشرة ليتم تفكيكه فوراً."
      );
    }

    return {
      success: true,
      type: "pdf",
      url: pdfDownloadResult.resolvedUrl || cleanUrl,
      title: (pdfDownloadResult.title || fallbackTitle).replace(/\.pdf$/i, ""),
      contentType: "application/pdf",
      size: pdfDownloadResult.buffer.byteLength,
      wordCount,
      lineCount,
      pageCount: totalPages,
      pages,
      content: pdfText,
      text: pdfText,
      dataBase64: pdfDownloadResult.buffer.toString("base64"),
    };
  }

  // 5. If no binary PDF was downloaded directly, inspect the page HTML to see what kind of resource it is
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 7000);
  let rawHtml = "";

  try {
    const pageRes = await fetch(cleanUrl, {
      signal: controller.signal,
      redirect: "follow",
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
      },
    });
    if (pageRes.ok) {
      rawHtml = await pageRes.text();
    }
  } catch (fetchErr) {
    // If direct fetch failed, try corsproxy fallback
    try {
      const pRes = await fetch(`https://corsproxy.io/?${encodeURIComponent(cleanUrl)}`);
      if (pRes.ok) rawHtml = await pRes.text();
    } catch {}
  } finally {
    clearTimeout(timeout);
  }

  // Extract page title from HTML
  const titleTagMatch = rawHtml.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  const h1TagMatch = rawHtml.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i);
  const pageTitle = (titleTagMatch?.[1] || h1TagMatch?.[1] || "")
    .replace(/<[^>]+>/g, "")
    .replace(/[\r\n\t]+/g, " ")
    .replace(/(?:تحميل|تنزيل|pdf|كتاب|مجانا|مباشر|نسخة|رابط)+/gi, "")
    .trim();

  // Check if the URL or page is a school textbook, curriculum, or syllabus page
  isBookOrCurriculum =
    isBookOrCurriculum ||
    /(كتاب|كتب|منهج|مناهج|ملزمة|ملازم|مقرر|hadith|حديث|قرآن|فقه|تفسير|توحيد|صف|ثانوي|متوسط|ابتدائي|إعدادي|pdf|تحميل|تنزيل|طالب|معلم)/i.test(
      cleanUrl + " " + pageTitle
    );

  // 6. Automated Silent PDF Search fallback for textbooks:
  // If this is a textbook page and initial crawling missed the binary, search Google for direct PDF
  if (isBookOrCurriculum && pageTitle.length >= 4) {
    try {
      const silentBookSearch = await searchGoogleWebUniversal(`${pageTitle} كتاب pdf`);
      if (silentBookSearch?.sources && silentBookSearch.sources.length > 0) {
        for (const candidate of silentBookSearch.sources.slice(0, 4)) {
          if (candidate.uri && candidate.uri !== cleanUrl) {
            const discoveredPdf = await downloadBinaryPdfWithCrawling(candidate.uri, 1);
            if (
              discoveredPdf &&
              discoveredPdf.buffer.length >= 5 &&
              discoveredPdf.buffer.slice(0, 5).toString("ascii").startsWith("%PDF")
            ) {
              const { text: pdfText, totalPages, pages } = await extractPdfFromBuffer(discoveredPdf.buffer);
              if (totalPages <= 0 || (totalPages <= 1 && pdfText.length < 500)) {
                continue;
              }
              return {
                success: true,
                type: "pdf",
                url: discoveredPdf.resolvedUrl || candidate.uri,
                title: pageTitle || "كتاب دراسي PDF",
                contentType: "application/pdf",
                size: discoveredPdf.buffer.byteLength,
                wordCount: pdfText.split(/\s+/).filter(Boolean).length,
                lineCount: pdfText.split("\n").length,
                pageCount: totalPages,
                pages,
                content: pdfText,
                text: pdfText,
                dataBase64: discoveredPdf.buffer.toString("base64"),
              };
            }
          }
        }
      }
    } catch (silentErr) {
      console.warn("Silent PDF discovery error:", silentErr);
    }
  }

  // 7. Intelligent Web Content Extraction Fallback:
  // If no direct binary PDF file could be acquired, extract pure educational text,
  // semantic data blocks, and articles directly from the webpage.
  try {
    const webExtracted = await fetchCleanWebContent(cleanUrl, {
      titleHint: pageTitle,
      timeoutMs: 6500,
    });

    if (webExtracted.success && webExtracted.cleanContent.trim().length >= 50) {
      return {
        success: true,
        type: "web",
        url: cleanUrl,
        title: webExtracted.title || pageTitle || "محتوى تعليمي من الويب",
        contentType: webExtracted.contentType || "text/html",
        size: webExtracted.cleanContent.length,
        wordCount: webExtracted.wordCount,
        lineCount: webExtracted.cleanContent.split("\n").length,
        pageCount: 1,
        content: webExtracted.cleanContent,
        text: webExtracted.cleanContent,
      };
    }
  } catch (extractErr) {
    console.warn("Web content fallback extraction error:", extractErr);
  }

  // 8. If even clean HTML extraction found insufficient text, try raw readable text
  if (rawHtml && rawHtml.length > 200) {
    const plainText = rawHtml
      .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, " ")
      .replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, " ")
      .replace(/<[^>]+>/g, " ")
      .replace(/\s+/g, " ")
      .trim();

    if (plainText.length >= 80) {
      return {
        success: true,
        type: "web",
        url: cleanUrl,
        title: pageTitle || "صفحة ويب تعليمية",
        contentType: "text/html",
        size: plainText.length,
        wordCount: plainText.split(/\s+/).filter(Boolean).length,
        lineCount: plainText.split("\n").length,
        pageCount: 1,
        content: plainText,
        text: plainText,
      };
    }
  }

  throw new Error("تعذر استخراج محتوى نصي مقروء من هذا الرابط. يرجى التأكد من أن الرابط متاح للعامة أو رفع الملف يدوياً.");
}

/**
 * Smart DOM Parsing & Pure Content Extraction from Web Links:
 * Analyzes the structural DOM of any web link, isolates clean text, and filters out
 * navbars, footers, sidebars, cookie banners, menus, ads, scripts, and styling.
 * Returns interconnected semantic data blocks and an initial indexing report.
 */
export async function fetchCleanWebContent(
  url: string,
  options?: { timeoutMs?: number; titleHint?: string }
): Promise<{
  success: boolean;
  title: string;
  url: string;
  domain: string;
  cleanContent: string;
  summary: string;
  executiveSummary: string;
  keyTopics: string[];
  dataBlocks: SemanticDataBlock[];
  indexingReport: InitialIndexingReport;
  contentType: string;
  wordCount: number;
  charCount: number;
  error?: string;
}> {
  const cleanUrl = url.trim();
  let domain = "web";
  try {
    domain = new URL(cleanUrl).hostname.replace(/^www\./, "");
  } catch {}

  // 1. Check in-memory educational cache
  const cached = educationalContentCache.get(cleanUrl);
  if (cached) {
    const { summary, executiveSummary, keyTopics } = synthesizeSummaryAndTopics(cached.content, cached.title);
    const dataBlocks = segmentIntoSemanticDataBlocks(cached.content, cached.title);
    const indexingReport: InitialIndexingReport = {
      mainTitle: cached.title,
      executiveSummary,
      keyTopics,
      indexingStatus: "جاهز للاستجواب الدقيق",
      totalDataBlocks: dataBlocks.length,
      indexedAt: new Date().toISOString(),
      sourceUrl: cleanUrl,
      contentType: cached.contentType,
    };
    return {
      success: true,
      title: cached.title,
      url: cleanUrl,
      domain,
      cleanContent: cached.content,
      summary,
      executiveSummary,
      keyTopics,
      dataBlocks,
      indexingReport,
      contentType: cached.contentType,
      wordCount: cached.wordCount,
      charCount: cached.content.length,
    };
  }

  // 2. Check if PDF direct binary or storage link
  const isDirectPdf = /\.pdf($|[?#])/i.test(cleanUrl) || /archive\.org\/download|drive\.google/i.test(cleanUrl);
  if (isDirectPdf) {
    try {
      const pdfRes = await downloadBinaryPdfWithCrawling(cleanUrl);
      if (pdfRes && pdfRes.buffer.length >= 5 && pdfRes.buffer.slice(0, 5).toString("ascii").startsWith("%PDF")) {
        const { text } = await extractPdfFromBuffer(pdfRes.buffer);
        if (text && text.trim().length > 0) {
          const title = pdfRes.title || options?.titleHint || `${domain} - مستند PDF`;
          const { summary, executiveSummary, keyTopics } = synthesizeSummaryAndTopics(text, title);
          const dataBlocks = segmentIntoSemanticDataBlocks(text, title);
          const indexingReport: InitialIndexingReport = {
            mainTitle: title,
            executiveSummary,
            keyTopics,
            indexingStatus: "جاهز للاستجواب الدقيق",
            totalDataBlocks: dataBlocks.length,
            indexedAt: new Date().toISOString(),
            sourceUrl: cleanUrl,
            contentType: "application/pdf",
          };

          educationalContentCache.set(cleanUrl, {
            title,
            content: text,
            contentType: "application/pdf",
            wordCount: text.split(/\s+/).filter(Boolean).length,
            lineCount: text.split("\n").length,
          });

          return {
            success: true,
            title,
            url: cleanUrl,
            domain,
            cleanContent: text,
            summary,
            executiveSummary,
            keyTopics,
            dataBlocks,
            indexingReport,
            contentType: "application/pdf",
            wordCount: text.split(/\s+/).filter(Boolean).length,
            charCount: text.length,
          };
        }
      }
    } catch (e) {
      console.warn("PDF extraction in fetchCleanWebContent fallback:", e);
    }
  }

  // 3. Fetch HTML content with Smart DOM Parsing
  const timeoutMs = options?.timeoutMs || 6000;
  let rawHtml = "";
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const pageRes = await fetch(cleanUrl, {
      signal: controller.signal,
      redirect: "follow",
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
      },
    });
    if (pageRes.ok) {
      rawHtml = await pageRes.text();
    }
  } catch (fetchErr) {
    try {
      const fbRes = await fetch(`https://corsproxy.io/?${encodeURIComponent(cleanUrl)}`);
      if (fbRes.ok) rawHtml = await fbRes.text();
    } catch {}
  } finally {
    clearTimeout(timer);
  }

  if (!rawHtml) {
    const fallbackTitle = options?.titleHint || domain;
    return {
      success: false,
      title: fallbackTitle,
      url: cleanUrl,
      domain,
      cleanContent: "",
      summary: "تعذر سحب المحتوى من هذا الرابط.",
      executiveSummary: "تعذر سحب المحتوى من هذا الرابط.",
      keyTopics: [],
      dataBlocks: [],
      indexingReport: {
        mainTitle: fallbackTitle,
        executiveSummary: "تعذر سحب المحتوى من هذا الرابط.",
        keyTopics: [],
        indexingStatus: "جاهز للاستجواب الدقيق",
        totalDataBlocks: 0,
        indexedAt: new Date().toISOString(),
        sourceUrl: cleanUrl,
      },
      contentType: "text/html",
      wordCount: 0,
      charCount: 0,
      error: "تعذر الوصول إلى محتوى الرابط الخارجي",
    };
  }

  // 4. Smart DOM Parsing: Extract clean article text removing noise, navbars, footers, and ads
  const extracted = extractStrictWebContent(rawHtml, cleanUrl);
  const cleanContent = extracted.content || "";
  const title = extracted.title || options?.titleHint || domain;

  const { summary, executiveSummary, keyTopics } = synthesizeSummaryAndTopics(cleanContent, title);
  const dataBlocks = segmentIntoSemanticDataBlocks(cleanContent, title);
  const indexingReport: InitialIndexingReport = {
    mainTitle: title,
    executiveSummary,
    keyTopics,
    indexingStatus: "جاهز للاستجواب الدقيق",
    totalDataBlocks: dataBlocks.length,
    indexedAt: new Date().toISOString(),
    sourceUrl: cleanUrl,
    contentType: "text/html",
  };

  if (cleanContent.length > 50) {
    educationalContentCache.set(cleanUrl, {
      title,
      content: cleanContent,
      contentType: "text/html",
      wordCount: cleanContent.split(/\s+/).filter(Boolean).length,
      lineCount: cleanContent.split("\n").length,
    });
  }

  return {
    success: cleanContent.length > 0,
    title,
    url: cleanUrl,
    domain,
    cleanContent,
    summary,
    executiveSummary,
    keyTopics,
    dataBlocks,
    indexingReport,
    contentType: "text/html",
    wordCount: cleanContent.split(/\s+/).filter(Boolean).length,
    charCount: cleanContent.length,
  };
}

/**
 * Extracts pure, clean text from any web URL (HTML or PDF) without ads, headers, or navbars,
 * and indexes it into structured, interconnected Semantic Data Blocks with an Initial Indexing Report.
 */
export async function extractAndIndexWebContent(
  url: string,
  titleHint?: string
): Promise<StructuredContentReport> {
  const extracted = await fetchCleanWebContent(url, { titleHint });
  return {
    success: extracted.success,
    title: extracted.title,
    url: extracted.url,
    domain: extracted.domain,
    summary: extracted.summary,
    executiveSummary: extracted.executiveSummary,
    keyTopics: extracted.keyTopics,
    totalBlocks: extracted.dataBlocks.length,
    dataBlocks: extracted.dataBlocks,
    indexingReport: extracted.indexingReport,
    extractedAt: new Date().toISOString(),
    contentType: extracted.contentType,
    status: "جاهز للاستجواب الدقيق",
    cleanText: extracted.cleanContent,
    error: extracted.error,
  };
}

/**
 * Format search results into a clean, structured JSON object
 * containing titles, links, summaries, key topics, and interconnected semantic data blocks.
 */
export function formatSearchResultsExport(
  searchResponse: WebSearchResponse | WebSearchResultItem[] | ExportedSearchPayload,
  query = ""
): ExportedSearchPayload {
  if (!Array.isArray(searchResponse) && (searchResponse as any).engine && Array.isArray((searchResponse as any).results)) {
    return searchResponse as ExportedSearchPayload;
  }

  const sources: WebSearchResultItem[] = Array.isArray(searchResponse)
    ? searchResponse
    : (searchResponse as WebSearchResponse).sources || [];
  const q = !Array.isArray(searchResponse) && (searchResponse as WebSearchResponse).query
    ? (searchResponse as WebSearchResponse).query
    : query;
  const overviewAnswer = !Array.isArray(searchResponse) ? (searchResponse as WebSearchResponse).answer : undefined;

  const items: ExportedSearchItem[] = sources.map((s) => {
    const summary = s.summary || s.snippet || "محتوى معرفي مسترجع.";
    const executiveSummary = s.executiveSummary || summary.slice(0, 180);
    const keyTopics =
      s.keyTopics && s.keyTopics.length > 0
        ? s.keyTopics
        : extractSalientKeywords(s.title + " " + summary, 5);
    const dataBlocks =
      s.dataBlocks && s.dataBlocks.length > 0
        ? s.dataBlocks
        : segmentIntoSemanticDataBlocks(s.cleanContent || s.snippet || s.title, s.title, 400);

    const indexingReport =
      s.indexingReport ||
      createInitialIndexingReport(
        s.title,
        s.cleanContent || s.snippet || s.title,
        s.uri
      );

    return {
      id: s.id,
      title: s.title,
      url: s.uri,
      domain: s.domain,
      category: s.category,
      summary,
      executiveSummary,
      keyTopics,
      indexingStatus: "جاهز للاستجواب الدقيق",
      relevanceScore: s.relevanceScore,
      dataBlocksCount: dataBlocks.length,
      dataBlocks,
      indexingReport,
      cleanContentPreview: s.cleanContent ? s.cleanContent.slice(0, 240) + "..." : undefined,
      author: s.author,
      date: s.date,
    };
  });

  return {
    exportedAt: new Date().toISOString(),
    engine: "Advanced Web Indexing & Analysis Engine (NotebookLM Style)",
    query: q,
    totalResults: items.length,
    indexingStatus: "جاهز للاستجواب الدقيق",
    overviewAnswer,
    results: items,
  };
}

/**
 * Exports search results as a formatted, organized JSON string
 * containing titles, links, summaries, and interconnected data blocks.
 */
export function exportSearchResultsAsJson(
  searchResponse: WebSearchResponse | WebSearchResultItem[] | ExportedSearchPayload,
  options?: { query?: string; pretty?: boolean }
): string {
  const formatted =
    typeof (searchResponse as any).engine === "string" && Array.isArray((searchResponse as any).results)
      ? (searchResponse as ExportedSearchPayload)
      : formatSearchResultsExport(searchResponse as WebSearchResponse | WebSearchResultItem[], options?.query || "");

  return JSON.stringify(formatted, null, options?.pretty !== false ? 2 : undefined);
}

/**
 * Export any single source or content report as organized JSON string
 */
export function exportSingleSourceAsJson(
  source: StructuredContentReport | WebSearchResultItem | ExportedSearchItem,
  options?: { pretty?: boolean }
): string {
  return JSON.stringify(source, null, options?.pretty !== false ? 2 : undefined);
}

/**
 * Smart Search with Deep Text Extraction & Interconnected Indexing:
 * Searches the web intelligently, fetches and cleans pure textual content from top web links,
 * indexes into interconnected semantic data blocks, and exports structured results as JSON.
 */
export async function smartSearchWithDeepExtraction(
  query: string,
  options?: {
    mode?: "curriculum" | "general";
    deepExtractLimit?: number;
    exportPrettyJson?: boolean;
  }
): Promise<{
  searchResponse: WebSearchResponse;
  exportPayload: ExportedSearchPayload;
  jsonString: string;
}> {
  const mode = options?.mode || "curriculum";
  const searchResponse = await executeWebSearch(query, mode);
  const deepLimit = Math.min(options?.deepExtractLimit || 3, searchResponse.sources.length);

  // In parallel, deep scrape and index top web links if not already having rich dataBlocks
  const topSources = searchResponse.sources.slice(0, deepLimit);
  await Promise.all(
    topSources.map(async (src) => {
      if (src.uri && (!src.dataBlocks || src.dataBlocks.length <= 1) && !src.hasCachedContent) {
        try {
          const extracted = await fetchCleanWebContent(src.uri, {
            timeoutMs: 3500,
            titleHint: src.title,
          });
          if (extracted.success && extracted.cleanContent.length > 80) {
            src.cleanContent = extracted.cleanContent;
            src.summary = extracted.summary;
            src.executiveSummary = extracted.executiveSummary;
            src.keyTopics = extracted.keyTopics;
            src.dataBlocks = extracted.dataBlocks;
            src.indexingReport = extracted.indexingReport;
            src.indexingStatus = "جاهز للاستجواب الدقيق";
            src.hasCachedContent = true;
          }
        } catch (e) {
          // Graceful fallback to snippet
        }
      }
    })
  );

  const exportPayload = formatSearchResultsExport(searchResponse, query);
  const jsonString = exportSearchResultsAsJson(exportPayload, {
    query,
    pretty: options?.exportPrettyJson !== false,
  });

  return {
    searchResponse,
    exportPayload,
    jsonString,
  };
}
