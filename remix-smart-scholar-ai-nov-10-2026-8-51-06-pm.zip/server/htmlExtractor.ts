import { JSDOM } from "jsdom";
import { Readability } from "@mozilla/readability";
import { cleanAndReshapePdfText } from "../src/lib/arabicReshaper.ts";

/**
 * List of non-educational and boilerplate DOM selectors to purge before any content extraction
 */
export const NON_EDUCATIONAL_SELECTORS = [
  "nav",
  "header",
  "footer",
  "aside",
  "form",
  "script",
  "style",
  "noscript",
  "iframe",
  "svg",
  ".sidebar",
  "#sidebar",
  "#mw-navigation",
  ".vector-menu",
  ".vector-header",
  ".vector-sidebar",
  "#mw-panel",
  "#mw-head",
  ".mw-jump-link",
  ".mw-editsection",
  "#siteSub",
  "#contentSub",
  "#toc",
  ".toc",
  ".infobox",
  ".navbox",
  ".vertical-navbox",
  ".mw-footer",
  "#footer",
  ".catlinks",
  ".noprint",
  ".mw-empty-elt",
  ".reflist",
  ".reference",
  ".mw-hidden-catlinks",
  ".mw-indicators",
  ".cdx-menu",
  ".vector-page-toolbar",
  ".vector-dropdown",
  ".mw-portlet",
  ".vector-column-start",
  ".vector-column-end",
  "[role='navigation']",
  "[role='banner']",
  "[role='contentinfo']",
  "[aria-label*='navigation']",
  "[aria-label*='menu']",
  ".menu",
  ".navbar",
  ".cookie-banner",
  ".banner",
  ".ad",
  ".ads",
  ".advertisement",
  ".social-share",
  ".comments",
  "#comments",
  ".login",
  ".signup",
  ".login-modal",
  ".donations",
  ".donate-box",
  ".site-notice",
  "#siteNotice",
  ".portal",
  ".mw-wiki-logo",
];

/**
 * Known navigation, menu, and non-academic junk keywords
 */
export const JUNK_PHRASES = [
  "تبرع",
  "انقل للشريط الجانبي",
  "تسجيل الدخول",
  "إنشاء حساب",
  "الصفحة الرئيسية",
  "كتاب الطبخ",
  "بوابة المجتمع",
  "أحدث التغييرات",
  "سياسة الخصوصية",
  "اتصل بنا",
  "جميع الحقوق محفوظة",
  "شروط الاستخدام",
  "ماذا يصل هنا",
  "تعديل وصلات",
];

/**
 * Academic subject anchor keywords indicating genuine subject matter
 */
export const ACADEMIC_KEYWORDS = [
  "فيزياء", "كيمياء", "رياضيات", "أحياء", "علوم", "نحو", "صرف", "بلاغة", "أدب",
  "لغة عربية", "تاريخ", "جغرافيا", "فلسفة", "منطق", "حاسب", "برمجة", "إحصاء",
  "تفاضل", "تكامل", "جبر", "هندسة", "معادلة", "قانون", "نظرية", "طاقة", "حركة",
  "عنصر", "تفاعل", "مركب", "خلية", "جينات", "ذرة", "موجات", "نيوتن", "كولوم",
  "شرح", "درس", "فصل", "مبحث", "مقرر", "منهج", "تعريف", "مفهوم", "مسألة",
  "تمرين", "استنتاج", "خصائص", "بنية", "وظائف", "تراكيب", "دراسات", "بحث"
];

/**
 * Clean and extract strict educational text from an HTML string
 * Automatically removes headers, footers, sidebars, navigation, menus, and boilerplate.
 * Isolates #mw-content-text / .mw-parser-output on Wikimedia sites.
 * Uses @mozilla/readability on general sites to isolate the academic article.
 */
export function extractStrictWebContent(rawHtml: string, pageUrl: string): {
  success: boolean;
  title: string;
  content: string;
  isMediaWiki: boolean;
  usedReadability: boolean;
} {
  if (!rawHtml || typeof rawHtml !== "string" || rawHtml.trim().length === 0) {
    return { success: false, title: "", content: "", isMediaWiki: false, usedReadability: false };
  }

  const dom = new JSDOM(rawHtml, { url: pageUrl });
  const doc = dom.window.document;

  // 1. Remove all non-educational and navigational selectors
  for (const selector of NON_EDUCATIONAL_SELECTORS) {
    try {
      const elements = doc.querySelectorAll(selector);
      elements.forEach((el) => el.remove());
    } catch (e) {
      // Ignore invalid selector issues if any
    }
  }

  // 2. Check for Wikipedia / Wikibooks / MediaWiki core container
  const mwContainer =
    doc.querySelector("#mw-content-text .mw-parser-output") ||
    doc.querySelector(".mw-parser-output") ||
    doc.querySelector("#mw-content-text");

  if (mwContainer) {
    // Additional selective cleaning inside mediawiki container
    const internalNoise = mwContainer.querySelectorAll(
      ".mw-editsection, .navbox, .vertical-navbox, .hatnote, .reference, .reflist, .mw-empty-elt, .gallery, .portal, .catlinks, .metadata"
    );
    internalNoise.forEach((el) => el.remove());

    // Extract text from paragraphs and headers inside container
    const textNodes: string[] = [];
    const contentElements = mwContainer.querySelectorAll("h1, h2, h3, h4, p, ul, ol, table, blockquote");

    contentElements.forEach((el) => {
      const text = el.textContent?.trim() || "";
      if (text.length > 0) {
        textNodes.push(text);
      }
    });

    const fullArticleText = textNodes.length > 0 ? textNodes.join("\n\n") : (mwContainer.textContent || "");
    const cleanedText = cleanAndReshapePdfText(fullArticleText.replace(/\s+/g, " ").trim());

    const pageTitle =
      doc.querySelector("#firstHeading")?.textContent?.trim() ||
      doc.querySelector("h1")?.textContent?.trim() ||
      doc.title?.replace(/ - ويكيبيديا.*| - ويكي كتب.*/i, "").trim() ||
      "مقال أكاديمي";

    return {
      success: cleanedText.length > 50,
      title: pageTitle,
      content: cleanedText,
      isMediaWiki: true,
      usedReadability: false,
    };
  }

  // 3. For General Websites: Use @mozilla/readability to isolate the article content
  try {
    const reader = new Readability(doc, {
      charThreshold: 60,
    });
    const article = reader.parse();

    if (article && article.textContent && article.textContent.trim().length >= 80) {
      const cleanArticleText = cleanAndReshapePdfText(article.textContent.replace(/\s+/g, " ").trim());
      const articleTitle = article.title?.trim() || doc.title?.trim() || "مقال تعليمي";

      return {
        success: true,
        title: articleTitle,
        content: cleanArticleText,
        isMediaWiki: false,
        usedReadability: true,
      };
    }
  } catch (readabilityErr) {
    console.warn("Readability extraction failed, falling back to main container:", readabilityErr);
  }

  // 4. Fallback: Search for primary content container (main, article, [role="main"])
  const mainContainer =
    doc.querySelector("main") ||
    doc.querySelector("article") ||
    doc.querySelector('[role="main"]') ||
    doc.querySelector(".article-content") ||
    doc.querySelector(".entry-content") ||
    doc.querySelector(".post-content") ||
    doc.querySelector("#content");

  if (mainContainer) {
    const rawMainText = mainContainer.textContent || "";
    const cleanMainText = cleanAndReshapePdfText(rawMainText.replace(/\s+/g, " ").trim());
    const fallbackTitle = doc.querySelector("h1")?.textContent?.trim() || doc.title?.trim() || "محتوى تعليمي";

    return {
      success: cleanMainText.length > 50,
      title: fallbackTitle,
      content: cleanMainText,
      isMediaWiki: false,
      usedReadability: false,
    };
  }

  // Never return raw body if it failed to isolate a content container
  return {
    success: false,
    title: doc.title?.trim() || "",
    content: "",
    isMediaWiki: false,
    usedReadability: false,
  };
}

/**
 * Strict Academic Content Validator:
 * Rejects any document containing navigation junk phrases (e.g. "تبرع", "تسجيل الدخول", "انقل للشريط الجانبي")
 * or lacking coherent academic subject matter.
 */
export function validateAcademicArticle(
  text: string,
  title: string
): {
  isValid: boolean;
  reason?: string;
} {
  const normText = text.replace(/[\u064B-\u065F\u0670]/g, "").toLowerCase();
  const normTitle = title.replace(/[\u064B-\u065F\u0670]/g, "").toLowerCase();
  const combined = `${normTitle} ${normText}`;

  // 1. Strict Exclusion of Non-Academic Junk Keywords
  const forbiddenPhrases = [
    "تبرع",
    "انقل للشريط الجانبي",
    "تسجيل الدخول",
    "إنشاء حساب",
    "كتاب الطبخ",
    "بوابة المجتمع",
    "سياسة الخصوصية",
    "ماذا يصل هنا",
    "مسلسلات",
    "قائمة حلقات",
  ];

  for (const phrase of forbiddenPhrases) {
    if (combined.includes(phrase)) {
      return {
        isValid: false,
        reason: `تم رفض المستند لاحتوائه على عناصر تنقل وقوائم غير دراسية («${phrase}») بدلاً من المادة العلمية الأكاديمية.`,
      };
    }
  }

  // 2. Minimum Length & Paragraph Coherence Check
  const wordCount = text.split(/\s+/).filter(Boolean).length;
  if (wordCount < 25) {
    return {
      isValid: false,
      reason: `المحتوى المستخرج مقتضب جداً (${wordCount} كلمة) ولا يشكل مادة علمية متكاملة.`,
    };
  }

  // 3. Subject-matter or educational coherence
  let academicHit = false;
  for (const kw of ACADEMIC_KEYWORDS) {
    if (combined.includes(kw)) {
      academicHit = true;
      break;
    }
  }

  if (!academicHit && wordCount < 120) {
    return {
      isValid: false,
      reason: "لا يتضمن المستند مفاهيم أو مصطلحات دراسية تخص المواد التعليمية الأساسية.",
    };
  }

  return { isValid: true };
}
