import fs from "fs";
import path from "path";

export interface StudentProfile {
  uid: string;
  email: string;
  displayName: string;
  photoURL?: string;
  provider: "google" | "local";
  createdAt: number;
  lastLoginAt: number;
  lastSyncAt?: number;
}

export interface CloudStudentData {
  profile: StudentProfile;
  appState: any;
  updatedAt: number;
}

const DATA_DIR = path.join(process.cwd(), ".user_data");
const STUDENTS_DIR = path.join(DATA_DIR, "students");

// Ensure directories exist
function ensureDirs() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  if (!fs.existsSync(STUDENTS_DIR)) {
    fs.mkdirSync(STUDENTS_DIR, { recursive: true });
  }
}

function getStudentFilePath(uid: string): string {
  ensureDirs();
  const safeUid = uid.replace(/[^a-zA-Z0-9_-]/g, "_");
  return path.join(STUDENTS_DIR, `${safeUid}.json`);
}

/**
 * Register or update a student record from Google Sign-In
 */
export function saveOrUpdateStudent(profile: StudentProfile): StudentProfile {
  const filePath = getStudentFilePath(profile.uid);
  let existingData: CloudStudentData | null = null;

  if (fs.existsSync(filePath)) {
    try {
      existingData = JSON.parse(fs.readFileSync(filePath, "utf8"));
    } catch (e) {}
  }

  const updatedProfile: StudentProfile = {
    ...profile,
    createdAt: existingData?.profile?.createdAt || profile.createdAt || Date.now(),
    lastLoginAt: Date.now(),
  };

  const cloudData: CloudStudentData = {
    profile: updatedProfile,
    appState: existingData?.appState || null,
    updatedAt: Date.now(),
  };

  fs.writeFileSync(filePath, JSON.stringify(cloudData, null, 2), "utf8");
  return updatedProfile;
}

/**
 * Save complete synchronized workspace (chats, files, notes, notebooks) for a student
 */
export function syncStudentWorkspace(uid: string, appState: any): { success: boolean; syncedAt: number } {
  const filePath = getStudentFilePath(uid);
  let existingData: CloudStudentData | null = null;

  if (fs.existsSync(filePath)) {
    try {
      existingData = JSON.parse(fs.readFileSync(filePath, "utf8"));
    } catch (e) {}
  }

  const profile: StudentProfile = existingData?.profile || {
    uid,
    email: appState?.userProfile?.email || "student@google.com",
    displayName: appState?.userProfile?.displayName || "طالب باحث",
    photoURL: appState?.userProfile?.photoURL,
    provider: "google",
    createdAt: Date.now(),
    lastLoginAt: Date.now(),
  };

  profile.lastSyncAt = Date.now();

  const cloudData: CloudStudentData = {
    profile,
    appState,
    updatedAt: Date.now(),
  };

  fs.writeFileSync(filePath, JSON.stringify(cloudData, null, 2), "utf8");
  return { success: true, syncedAt: cloudData.updatedAt };
}

/**
 * Retrieve synchronized workspace for student
 */
export function getStudentWorkspace(uid: string): CloudStudentData | null {
  const filePath = getStudentFilePath(uid);
  if (!fs.existsSync(filePath)) {
    return null;
  }
  try {
    return JSON.parse(fs.readFileSync(filePath, "utf8"));
  } catch (e) {
    return null;
  }
}
