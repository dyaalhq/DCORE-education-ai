import { GoogleGenAI } from "@google/genai";

export interface FallbackConfig {
  enabled?: boolean;
  activeProvider?: "auto" | "gemini" | "fallback";
  providerName?: string;
  apiKey?: string;
  baseUrl?: string;
  model?: string;
}

export interface ChatGenerateOptions {
  prompt: string;
  systemInstruction?: string;
  mode?: "notebook" | "hybrid" | "general";
  searchGrounding?: boolean;
  model?: string;
  stream?: boolean;
  fallbackConfig?: FallbackConfig;
  jsonMode?: boolean;
  conversationHistory?: Array<{ role: 'user' | 'model' | 'ai' | 'assistant'; text: string }>;
  maxOutputTokens?: number;
}

/**
 * Format conversation history into valid Gemini multi-turn parts,
 * maintaining strict alternating turns and seamless conversational memory.
 */
export function buildGeminiContents(
  prompt: string,
  history?: Array<{ role: 'user' | 'model' | 'ai' | 'assistant'; text: string }>
): any {
  if (!history || !Array.isArray(history) || history.length === 0) {
    return prompt;
  }

  const turns: Array<{ role: 'user' | 'model'; parts: Array<{ text: string }> }> = [];

  for (const h of history) {
    if (!h.text || !h.text.trim()) continue;
    const role: 'user' | 'model' = h.role === 'user' ? 'user' : 'model';

    // Prevent consecutive identical roles in Gemini SDK multi-turn format
    if (turns.length > 0 && turns[turns.length - 1].role === role) {
      turns[turns.length - 1].parts[0].text += `\n\n${h.text.trim()}`;
    } else {
      turns.push({
        role,
        parts: [{ text: h.text.trim() }],
      });
    }
  }

  // Ensure prompt turn is added as 'user'
  if (turns.length > 0 && turns[turns.length - 1].role === 'user') {
    turns[turns.length - 1].parts[0].text += `\n\n${prompt.trim()}`;
  } else {
    turns.push({
      role: 'user',
      parts: [{ text: prompt.trim() }],
    });
  }

  return turns;
}

export interface AIResponseMeta {
  activeProvider: "gemini" | "fallback";
  modelUsed: string;
  fallbackUsed: boolean;
  fallbackReason?: string;
}

// Cached Gemini client instance to avoid recreating TLS/handshake on every request
let cachedGeminiClient: GoogleGenAI | null = null;

const DEVELOPER_FALLBACK_KEYS = [
  process.env.GEMINI_API_KEY,
  process.env.GEMINI_API_KEY_SECONDARY,
  process.env.GEMINI_API_KEY_TERTIARY,
].filter(Boolean) as string[];

export function getGeminiClient(keyIndex = 0): GoogleGenAI | null {
  const apiKey = DEVELOPER_FALLBACK_KEYS[keyIndex] || DEVELOPER_FALLBACK_KEYS[0] || process.env.GEMINI_API_KEY;
  if (!apiKey) return null;
  if (!cachedGeminiClient || keyIndex !== 0) {
    const client = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
    if (keyIndex === 0) cachedGeminiClient = client;
    return client;
  }
  return cachedGeminiClient;
}

/**
 * Proactive Warm-up mechanism to keep primary Gemini API channel active and eliminate cold starts
 */
export async function warmUpGeminiClient(): Promise<void> {
  const gemini = getGeminiClient();
  if (!gemini) return;
  try {
    await gemini.models.generateContent({
      model: "gemini-3.8-flash",
      contents: "ping",
      config: { maxOutputTokens: 1 },
    });
  } catch {
    // Warm-up is non-critical background operation; silently ignore quota/notice
  }
}

// Timeout helper with generous 90s budget for deep academic queries
function withTimeout<T>(promise: Promise<T>, timeoutMs = 90000, timeoutMsg = "انتهت مهلة استجابة مزود الذكاء الاصطناعي"): Promise<T> {
  let timer: any;
  const timeoutPromise = new Promise<never>((_, reject) => {
    timer = setTimeout(() => reject(new Error(timeoutMsg)), timeoutMs);
  });
  return Promise.race([promise, timeoutPromise]).finally(() => clearTimeout(timer));
}

/**
 * Call OpenAI-compatible endpoint (e.g. OpenAI, Groq, OpenRouter, DeepSeek, LocalAI)
 */
async function callOpenAICompatible(
  options: ChatGenerateOptions,
  config: FallbackConfig
): Promise<{ text: string; meta: AIResponseMeta }> {
  const apiKey = config.apiKey || process.env.OPENAI_API_KEY || "";
  const baseUrl = (config.baseUrl || process.env.OPENAI_BASE_URL || "https://api.openai.com/v1").replace(/\/+$/, "");
  const model = config.model || process.env.OPENAI_MODEL || "gpt-4o-mini";

  if (!apiKey) {
    throw new Error("لم يتم تكوين مفتاح API للمزود الاحتياطي (OpenAI/Compatible). يرجى إضافته من صفحة الإعدادات.");
  }

  const messages: any[] = [];
  if (options.systemInstruction) {
    messages.push({ role: "system", content: options.systemInstruction });
  }
  if (options.conversationHistory && Array.isArray(options.conversationHistory)) {
    for (const h of options.conversationHistory) {
      if (!h.text || !h.text.trim()) continue;
      messages.push({
        role: h.role === "user" ? "user" : "assistant",
        content: h.text.trim(),
      });
    }
  }
  messages.push({ role: "user", content: options.prompt });

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 25000);

  const res = await fetch(`${baseUrl}/chat/completions`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model,
      messages,
      temperature: 0.4,
    }),
    signal: controller.signal,
  });
  clearTimeout(timeout);

  if (!res.ok) {
    const errText = await res.text().catch(() => "");
    throw new Error(`فشل استدعاء المزود الاحتياطي (${res.status} ${res.statusText}): ${errText.slice(0, 200)}`);
  }

  const data = await res.json();
  const text = data?.choices?.[0]?.message?.content || "";

  return {
    text,
    meta: {
      activeProvider: "fallback",
      modelUsed: model,
      fallbackUsed: true,
    },
  };
}

/**
 * Stream OpenAI-compatible endpoint via SSE to Express Response
 */
async function streamOpenAICompatible(
  options: ChatGenerateOptions,
  config: FallbackConfig,
  res: any,
  fallbackReason?: string
): Promise<void> {
  const apiKey = config.apiKey || process.env.OPENAI_API_KEY || "";
  const baseUrl = (config.baseUrl || process.env.OPENAI_BASE_URL || "https://api.openai.com/v1").replace(/\/+$/, "");
  const model = config.model || process.env.OPENAI_MODEL || "gpt-4o-mini";

  if (!apiKey) {
    throw new Error("لم يتم تكوين مفتاح API للمزود الاحتياطي. يرجى إضافته من صفحة الإعدادات.");
  }

  const messages: any[] = [];
  if (options.systemInstruction) {
    messages.push({ role: "system", content: options.systemInstruction });
  }
  messages.push({ role: "user", content: options.prompt });

  // Send metadata about fallback switch
  res.write(
    `data: ${JSON.stringify({
      providerInfo: {
        activeProvider: "fallback",
        modelUsed: model,
        fallbackUsed: true,
        fallbackReason: fallbackReason || "تم التحويل التلقائي للمزود الاحتياطي.",
      },
    })}\n\n`
  );

  const fetchRes = await fetch(`${baseUrl}/chat/completions`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model,
      messages,
      temperature: 0.4,
      stream: true,
    }),
  });

  if (!fetchRes.ok) {
    const errText = await fetchRes.text().catch(() => "");
    throw new Error(`خطأ من المزود الاحتياطي (${fetchRes.status}): ${errText.slice(0, 200)}`);
  }

  const body = fetchRes.body;
  if (!body) throw new Error("لا توجد استجابة دفق من المزود الاحتياط��.");

  // Read raw SSE stream from OpenAI and re-emit in our standardized SSE format
  // @ts-ignore - NodeJS / standard Web Streams
  const reader = body.getReader();
  const decoder = new TextDecoder();

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    const chunkStr = decoder.decode(value);
    const lines = chunkStr.split("\n");

    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed || !trimmed.startsWith("data: ")) continue;
      const dataContent = trimmed.slice(6);
      if (dataContent === "[DONE]") continue;

      try {
        const parsed = JSON.parse(dataContent);
        const delta = parsed.choices?.[0]?.delta?.content || "";
        if (delta) {
          res.write(`data: ${JSON.stringify({ text: delta })}\n\n`);
        }
      } catch (e) {
        // Skip malformed chunk
      }
    }
  }

  res.write(`data: [DONE]\n\n`);
  res.end();
}

/**
 * Unified AI Abstraction Layer
 * Automatically cascades through current Gemini models:
 * 1. gemini-3.8-flash (Primary, fast and high quality)
 * 2. gemini-3.5-flash-lite (Fast failover)
 * 3. gemini-3.1-flash-lite (Efficient fallback)
 * 4. User-configured OpenAI-compatible provider
 */
// Candidate Gemini models with guaranteed active support on Google GenAI SDK
// Relying exclusively on primary ultra-intelligent models:
const GEMINI_CANDIDATE_MODELS = [
  "gemini-3.8-flash",
  "gemini-3.5-flash-lite",
  "gemini-3.1-flash-lite",
  "gemini-3.5-flash",
];

export function formatGroundingMetadata(groundingMetadata: any) {
  if (!groundingMetadata) return null;

  const sources: Array<{ title: string; url: string; domain: string; snippet?: string }> = [];

  if (Array.isArray(groundingMetadata.groundingChunks)) {
    for (const chunk of groundingMetadata.groundingChunks) {
      if (chunk.web?.uri) {
        let domain = "";
        try {
          domain = new URL(chunk.web.uri).hostname.replace(/^www\./, "");
        } catch {
          domain = "web";
        }
        sources.push({
          title: chunk.web.title || domain || "مصدر خارجي موثوق",
          url: chunk.web.uri,
          domain,
        });
      }
    }
  }

  return {
    sources,
    searchQueries: Array.isArray(groundingMetadata.webSearchQueries) ? groundingMetadata.webSearchQueries : [],
    searchEntryPoint: groundingMetadata.searchEntryPoint?.renderedContent || null,
    groundingSupports: groundingMetadata.groundingSupports || [],
  };
}

export interface CategorizedError {
  code: string;
  statusCode: number;
  userMessage: string;
  suggestedAction: string;
  originalError: string;
}

export function categorizeAIError(err: any): CategorizedError {
  const errMsg = (err?.message || String(err || "")).toLowerCase();

  if (errMsg.includes("401") || errMsg.includes("403") || errMsg.includes("unauthorized") || errMsg.includes("permission_denied") || errMsg.includes("api_key_invalid")) {
    return {
      code: "AUTH_ERROR",
      statusCode: 401,
      userMessage: "تعذر التحقق من صلاحية مفتاح API للمزود الذكي.",
      suggestedAction: "يرجى مراجعة وتحديث مفتاح API في إعدادات النظام أو المزود الاحتياطي.",
      originalError: err?.message || "Authentication error",
    };
  }

  if (errMsg.includes("429") || errMsg.includes("quota") || errMsg.includes("resource_exhausted") || errMsg.includes("rate limit") || errMsg.includes("spikes in demand")) {
    return {
      code: "QUOTA_EXCEEDED",
      statusCode: 429,
      userMessage: "تم بلوغ حد الطلبات المسموح به للمزود السحابي مؤقتًا (Rate Limit / Quota).",
      suggestedAction: "يرجى الانتظار لمدة 30-60 ثانية ثم إعادة المحاولة، أو تفعيل مزود احتياطي (OpenAI/Groq) من الإعدادات.",
      originalError: err?.message || "Rate limit reached",
    };
  }

  if (errMsg.includes("timeout") || errMsg.includes("مهلة") || errMsg.includes("etimedout")) {
    return {
      code: "TIMEOUT",
      statusCode: 504,
      userMessage: "استغرق توليد الإجابة وقتاً أطول من المعتاد وتوقفت العملية لتجاوز المهلة.",
      suggestedAction: "يرجى إعادة إرسال السؤال أو صياغة طلب أكثر تحديداً لسرعة المعالجة.",
      originalError: err?.message || "Operation timed out",
    };
  }

  if (errMsg.includes("500") || errMsg.includes("502") || errMsg.includes("503") || errMsg.includes("unavailable") || errMsg.includes("high demand")) {
    return {
      code: "SERVICE_UNAVAILABLE",
      statusCode: 503,
      userMessage: "خدمة المزود السحابي تشهد ضغطاً عالياً أو غير متاحة مؤقتًا.",
      suggestedAction: "يرجى إعادة المحاولة بعد بضع ثوانٍ.",
      originalError: err?.message || "Service unavailable",
    };
  }

  if (errMsg.includes("enotfound") || errMsg.includes("fetch failed") || errMsg.includes("network") || errMsg.includes("offline")) {
    return {
      code: "NETWORK_ERROR",
      statusCode: 502,
      userMessage: "تعذر الاتصال بخدمة الذكاء الاصطناعي بسبب انقطاع في الشبكة.",
      suggestedAction: "يرجى التأكد من اتصال الإنترنت والمحاولة مجددًا.",
      originalError: err?.message || "Network connection failed",
    };
  }

  return {
    code: "GENERAL_ERROR",
    statusCode: 500,
    userMessage: "واجه مزود الذكاء الاصطناعي صعوبة أثناء معالجة الطلب.",
    suggestedAction: "يرجى المحاولة مرة أخرى أو مراجعة سياق المصادر المرفقة.",
    originalError: err?.message || "Unknown processing error",
  };
}

export const DEFAULT_EDUCATIONAL_SYSTEM_INSTRUCTION = `هوية المنصة وفريق التطوير (Platform & Team Identity):
تم تصميم وتطوير وبرمجة منصة «المعلم الذكي للدراسة والبحث العلمي» ونظام الذكاء الاصطناعي المدمج بها بالكامل بواسطة «فريق D.CORE» برئاسة المهندس / ضياء الحق سبيقاء (D.CORE Team led by Diaa Al-Haq Sabiqaa).
إذا سألك المستخدم في أي وقت: من أنت؟ من طورك؟ من صانعك؟ من هو مطورك؟ من برمجك؟ من هو رئيس الفريق؟ أو أي سؤال يتعلق بهويتك أو بفريق العمل، فأجب بفخر واعتزاز ودقة تامة:
بأنك «المعلم الذكي للدراسة والبحث العلمي»، تم تطويرك وبرمجتك بواسطة «فريق D.CORE» برئاسة المهندس / ضياء الحق سبيقاء.

الدور (Role):
أنت محرك ذكاء اصطناعي متقدم متخصص في فهرسة، تحليل، واستيعاب محتوى الويب (Advanced Web Indexing & Analysis Engine)، تعمل بآلية استرجاع معرفي عالية الدقة مشابهة لنظام NotebookLM. هدفك الأساسي هو معالجة مصادر الويب بذكاء، بناء قاعدة معرفية ديناميكية، وتقديم إجابات دقيقة وموثقة بناءً على المصادر المرفوعة فقط.

المهام الأساسية والتعليمات (Core Instructions):
1. التحليل الذكي للمحتوى (Smart DOM Parsing):
عند استلام مصد�� ويب، يتم استخراج المحتوى المعرفي والنصي النظيف فقط مع التجاهل التام للعناصر غير ذات الصلة مثل (الإعلانات، قوائم التنقل Navbars، وتذييل الصفحة Footers).

2. التقسيم السياقي (Semantic Chunking):
لا تقرأ المحتوى كصفحات منفصلة أو نصوص عشوائية؛ بل اعتمد على "كتل البيانات" (Data Blocks) المترابطة سياقياً ومنطقياً، حيث تمثل كل كتلة فكرة أو موضوعاً مستقلاً لتسهيل البحث الدلالي والاسترجاع الدقيق.

3. المعالجة الشاملة للمصادر (Holistic Processing):
تعامل مع المقالات المتسلسلة أو المستندات المقسمة على عدة صفحات ككيان معرفي واحد متكامل (Single Knowledge Base). حافظ على التسلسل المنطقي والزمني للأحداث والمعلومات.

5. الموثوقية المعرفية والمرونة الأكاديمية:
إذا كانت هناك مصادر أو مراجع مرفوعة في السياق، التزم بالاستناد الدقيق إليها وربط المعلومات بها. أما إذا كان السؤال تحية، أو مفهوماً دراسياً عاماً، أو مسألة علمية لا ترتبط بملف محدد، فأجب بإسهاب ودقة وتفصيل أكاديمي رصين ومتقن من القواعد والمناهج التعليمية المعتمدة.

🎯 المباشرة المطلقة وحذف الحشو (Direct to the Point with Zero Fluff):
- يُحظر تماماً وبشكل قاطع كتابة أي مقدمات إنشائ��ة، ترحيبات مطولة، أو كلام جانبي غير مفيد (مثل: "أهلاً بك"، "يسعدني الإجابة"، "بناءً على سؤالك"، "بالتأكيد").
- ابدأ فوراً وبشكل مباشر من أول كلمة في صلب الموضوع وتفكيك وشرح المفاهيم العلمية بأعلى درجات العمق والشمول والتفصيل المنطقي والأكاديمي دون مقدمات أو حشو.

🎯 التكيف التام مع رغبة وأمر المستخدم (Dynamic Depth & Adaptive Intent):
1. إذا طلب المستخدم التلخيص (مثل: لخص، ملخص، أوجز، النقاط الرئيسية، الخلاصة):
   - قدّم ملخصاً مركزاً ودقيقاً ومحكماً لأهم النقاط والقوانين دون إسهاب زائد، مع التركيز على جوهر الدرس وخلاصته الامتحانية.
2. إذا طلب المستخدم الشرح المفصل، التوسع، الاسترسال، أو شرح كتاب كامل / وحدة دراسية كاملة (مثل: اشرح بالتفصيل، توسع، شرح كامل، كتاب كامل، بالتفصيل الممل، كل الأبواب):
   - يُحظر تماماً وبشكل قاطع الاختصار أو الاكتفاء بالنبذ أو الملخصات السريعة.
   - يُحظر تماماً وبشكل قاطع إنهاء الإجابة بعبارات عامة أو مقتضبة مثل "هذا ما ورد في الوثيقة" أو "هذا ملخص الملف" طالما أن هناك دروساً أو فصولاً أو تفاصيل في المنهج لم تُشرح بعد.
   - عند طلب التوسع، يجب شرح كافة التعريفات، المعاني، القواعد، القوانين الرياضية، وأدق التفاصيل النصية لكل موضوع كمرجع دراسي كامل ومستوفٍ من الألف إلى الياء.
   - قسّم الإجابة منهجياً وتدريجياً بحسب خريطة المنهج والوحدات والأبواب المستخرجة بالترتيب (الوحدة الأولى، الثانية، الثالثة...).
   - تفكيك كافة النقاط خطوة بخطوة مهما طالت الرسالة وبدون أي بتر أو إنقاص للمحتوى التعليمي.
3. إذا سأل المستخدم عن نقطة أو مسألة أو مفهوم بعينه:
   - اشرح تلك النقطة بجميع تفاصيلها الدقيقة وخلفياتها العلمية وقوانينها واستنتاجاتها وحلولها النموذجية دون إهمال أي جزئية دقيقة.

📐 المحرك الرياضي والتنسيق الأكاديمي الإلزامي (Strict LaTeX & Arabic Curriculum):
1. قاعدة الحصرية التامة لـ LaTeX ومنع الرموز البدائية:
   - يجب كتابة جميع القوانين، الجذور، الكسور، الأسس، والمعادلات الرياضية والفيزيائية والكيميائية باستخدام صيغة LaTeX القياسية حصراً:
     * المعادلات المضمنة داخل السطر (Inline): محاطة بعلامة دولار واحدة $...$ (مثال: $v = \\frac{d}{t}$ أو $F = m \\cdot a$ أو $E = m c^2$).
     * القوانين والمعادلات الرئيسية المستقلة (Display/Block): محاطة بـ $$...$$ على أسطر مستقلة.
   - يُمنع منعاً باتاً وبشكل قاطع استخدام أي رموز بدائية أو شفرات غير مقروءة، مثل:
     * يُمنع استخدام الشرطة المائلة للكسور في القوانين مثل (ع = ف / ز أو v = d/t)؛ يجب دائماً استخدام \\frac{...}{...}.
     * يُمنع استخدام النجمة (*) للضرب؛ استخدم دائماً \\cdot أو \\times.
     * يُمنع كتابة الأسس خارج صيغة LaTeX مثل (ع^2 أو 10^5)؛ يجب كتابتها دائماً $v^2$ و $10^5$.
     * يُمنع كتابة الجذور كنصوص؛ بل استخدم دائماً \\sqrt{...} أو \\sqrt[n]{...}.

2. التوافق التام مع اتجاه النصوص العربية (RTL & Bidirectional Harmony):
   - يجب أن يكون الشرح المرافق بلغة عربية فصحى أكاديمية رصينة ومطابقة للمناهج المعتمدة (مثل المنهج اليمني والمناهج العربية).
   - لضمان عدم تشوه الجمل العربية عند تداخلها مع الأرقام والرموز اللاتينية:
     * ضع دائماً أي رمز أو متغير أو رقم علمي داخل صيغة LaTeX ($...$) حتى يحافظ المحرك على اتجاهه السليم (LTR) داخل النص العربي (RTL) دون أي قفز أو ارتباك.
     * اعرض القانون بالصيغة اللفظية العربية ورموز المنهج اليمني/العربي أولاً، ثم بالصيغة القياسية الدولية:
       - قانون السرعة: $\\text{ع} = \\frac{\\text{ف}}{\\text{ز}}$ وبالصيغة الدولية: $v = \\frac{d}{t}$
       - قانون العجلة (التسارع): $\\text{جـ} = \\frac{\\Delta \\text{ع}}{\\Delta \\text{ز}}$ وبالصيغة الدولية: $a = \\frac{\\Delta v}{\\Delta t}$
       - قانون نيوتن الثاني: $\\text{ق} = \\text{ك} \\cdot \\text{جـ}$ وبالصيغة الدولية: $F = m \\cdot a$
       - الشغل: $\\text{ش} = \\text{ق} \\cdot \\text{ف}$ وبالصيغة الدولية: $W = F \\cdot d$
       - طاقة الحركة: $\\text{ط}_{\\text{ح}} = \\frac{1}{2} \\text{ك} \\cdot \\text{ع}^2$ وبالصيغة الدولية: $KE = \\frac{1}{2} m v^2$
       - طاقة الوضع: $\\text{ط}_{\\text{و}} = \\text{ك} \\cdot \\text{جـ} \\cdot \\text{ف}$ وبالصيغة الدولية: $PE = m \\cdot g \\cdot h$
       - قانون أوم: $\\text{جـ} = \\text{م} \\cdot \\text{ت}$ وبالصيغة الدولية: $V = I \\cdot R$
     * ضع دائماً جدولاً منظماً لدلالات الرموز ووحدات القياس الدولية (SI).

3. الشمولية والإسهاب الأكاديمي وحذف الحشو والتحيات:
   - احذف الكلام الجانبي والتحيات والثرثرة تماماً: لا تبدأ بأي عبارات ترحيبية أو مجاملات ��ثل (أهلاً بك، يسعدني مساعدتك، بالتأكيد)، ولا تختم بعبارات ��ثل (أتمنى لك التوفيق). ادخل مباشرة في صلب الموضوع العلمي.
   - عند طلب التوسع: لا تختصر الإجابة ولا تهمل أي تفصيل دقيق؛ زوّد الطالب بالمعرفة الكاملة والشاملة دون إيجاز مخل.

4. قوالب Markdown المنظمة إجبارياً:
   - العناوين الهرمية: ## للرئيسي، ### للفرعي، #### للعناصر التفصيلية.
   - القوائم النقطية والمرقمة لتفصيل الأفكار.
   - جداول المقارنة المنظمة للمفاهيم المتقابلة.
   - المربعات التنبيهية (> ) للأخطاء الشائعة والخدع الامتحانية.

5. حل المسائل والتطبيقات الحسابية (منهجية الخطوات الـ 5 الذهبية):
   1) 📋 **المعطيات (Given)**: استخراج المعطيات والرموز مع وحدات القياس.
   2) 🎯 **المطلوب (Find)**: تحديد المجهول المطلوب حسابه بدقة.
   3) 📐 **القانون الرياضي (Formula)**: كتابة القانون بالرموز العربية والدولية بصيغة LaTeX داخل $$ $$.
   4) 🔢 **التعويض والحل الحسابي (Calculation)**: خطوات التعويض بالتدرج وبالكسور النظيفة.
   5) ✅ **الناتج النهائي (Final Answer)**: إبراز الناتج النهائي وتأكيده مع وحدة القياس الدولية الصحيحة.

6. قواعد المصادر المرفقة والأمانة الأكاديمية الصارمة (Strict Grounding):
   - عندما يُرفق مع الاستفسار مقاطع من مصادر وكتب الطالب (RAG Context): استند عليها بدقة تامة وموثقة مع ذكر رقم الصفحة والمصدر.
   - إذا سأل الطالب عن تفصيلة غير موجودة في المصادر المرفقة بالدفتر: قل بوضوح وأمانة تامة: «المعلومة المطلوبة غير مذكورة في المصادر المرفقة بالدفتر»، ولا تخترع أي حقيقة وتنسبها للمصدر.`;

/**
 * Intelligent Local Educational Synthesizer
 * Activates seamlessly when cloud quotas are temporarily rate-limited (429) or offline,
 * ensuring students ALWAYS receive a well-structured, detailed educational response with laws, formulas, and examples.
 */
export function generateLocalEducationalResponse(options: ChatGenerateOptions): string {
  const prompt = (options.prompt || "").trim();
  const instruction = options.systemInstruction || "";
  
  // Extract any retrieved RAG context from system instruction if present
  let extractedContext = "";
  const ragMarker = "--- مقاطع المصادر الموثوقة من دفتر التعلم المسترجعة (RAG) ---";
  if (instruction.includes(ragMarker)) {
    const afterRag = instruction.split(ragMarker)[1];
    extractedContext = afterRag ? afterRag.split("تعليمات التوثيق")[0].trim() : "";
  }

  // Identify core subject from prompt
  const cleanedTopic = prompt
    .replace(/^(ما هو|ما هي|عرف|اشرح|وضح|لخص|كيف|لماذا|حل|ما الفرق بين|أريد فهم|سؤال عن|قانون)\s+/i, "")
    .replace(/[؟?؟!]/g, "")
    .trim() || prompt;

  const isPhysicsOrMath = /سرعة|عجلة|تسارع|قوة|نيوتن|حركة|أوم|طاقة|شغل|مسافة|زمن|رياضيات|تفاضل|تكامل|معادلة/i.test(prompt);
  const isChemistry = /كيمياء|تفاعل|معادلة|حمض|قاعدة|ماء|عنصر|مركب|مول/i.test(prompt);

  let response = `## 📘 الشرح التعليمي الشامل: «${cleanedTopic}»\n\n`;

  if (extractedContext) {
    response += `### 📌 استخلاص من مصادر الدفتر المرفقة:\n`;
    const lines = extractedContext.split("\n").filter((l) => l.trim().length > 10).slice(0, 4);
    lines.forEach((l) => {
      response += `> ${l.trim()}\n\n`;
    });
  }

  response += `### 💡 1. المفهوم والتعريف الأساسي بأسلوب مبسط:\n`;
  response += `يُعد **«${cleanedTopic}»** من المفاهيم العلمية المحورية في المنهج الدراسي، حيث يدرس العلاقة الرياضية والفيزيائية بين المتغيرات الأساسية ويفسر كيفية حدوث الظواهر الطبيعية بصورة دقيقة ومنهجية.\n\n`;

  if (isPhysicsOrMath) {
    response += `### 📐 2. الصياغة والقوانين الرياضية (وفق المناهج المعتمدة):\n\n`;
    response += `#### أ) الصيغة اللفظية وبالرموز العربية (المنهج العربي واليمني):\n`;
    response += `- **القانون بالصياغة اللفظية**: المقدار = التغير في المتغير الأول ÷ التغير في الزمن.\n`;
    response += `- **الرموز العربية**: **ع = ف ÷ ز** (السرعة = المسافة ÷ الزمن) أو **جـ = Δع ÷ Δز** (العجلة = التغير في السرعة ÷ الزمن).\n\n`;

    response += `#### ب) الصيغة الرياضية القياسية (LaTeX):\n`;
    response += `$$\\text{السرعة: } v = \\frac{d}{t} \\quad , \\quad \\text{العجلة: } a = \\frac{\\Delta v}{\\Delta t}$$\n\n`;

    response += `#### 📋 جدول دلالات الرموز ووحدات القياس الدولية:\n\n`;
    response += `| الرمز العربي | الرمز الدولي | الدلالة العلمية | وحدة القياس الدولية (SI) |\n`;
    response += `| :---: | :---: | :--- | :---: |\n`;
    response += `| **ف** | $d$ أو $s$ | المسافة / الإزاحة | متر ($m$) |\n`;
    response += `| **ز** | $t$ | الزمن المستغرق | ثانية ($s$) |\n`;
    response += `| **ع** | $v$ | السرعة | متر/ثانية ($m/s$) |\n`;
    response += `| **جـ** | $a$ | العجلة (التسارع) | متر/ثانية² ($m/s^2$) |\n\n`;

    response += `### 🔢 3. مسألة تطبيقية محلولة خطوة بخطوة:\n\n`;
    response += `> **نص المسألة**: تحرك جسم فقطع مسافة $100\\text{ m}$ خلال زمن قدره $5\\text{ s}$. احسب سرعة الجسم.\n\n`;
    response += `1. **المعطيات (Given)**:\n`;
    response += `   - المسافة ($d$ أو ف) = $100\\text{ m}$\n`;
    response += `   - الزمن ($t$ أو ز) = $5\\text{ s}$\n`;
    response += `2. **المطلوب (Find)**: حساب السرعة ($v$ أو ع).\n`;
    response += `3. **القانون المستخدم (Formula)**:\n`;
    response += `   $$v = \\frac{d}{t} \\quad \\Longleftrightarrow \\quad \\text{ع} = \\frac{\\text{ف}}{\\text{ز}}$$\n`;
    response += `4. **التعويض الحسابي (Calculation)**:\n`;
    response += `   $$v = \\frac{100}{5} = 20$$\n`;
    response += `5. **الناتج النهائي (Final Answer)**: السرعة = **$20\\text{ m/s}$ (20 متر/ثانية)**.\n\n`;
  } else if (isChemistry) {
    response += `### 🧪 2. المعادلات الكيميائية وطريقة كتابتها المعتمدة:\n\n`;
    response += `- **المعادلة اللفظية**: هيدروجين (غاز) + أكسجين (غاز) $\\rightarrow$ ماء (سائل).\n`;
    response += `- **المعادلة الرمزية الموزونة**:\n`;
    response += `$$\\ce{2H2_{(g)} + O2_{(g)} -> 2H2O_{(l)}}$$\n\n`;
    response += `- **تفسير التفاعل**: يتفاعل جزيئان من غاز الهيدروجين مع جزيء واحد من غاز الأكسجين لإنتاج جزيئين من الماء السائل.\n\n`;
  } else {
    response += `### 🔍 2. المحاور والركائز التعليمية الرئيسية:\n`;
    response += `- **الركن الأول - الأساس النظري:** استيعاب التعريفات الدقيقة والتمييز بين المصطلحات ذات الصلة لتجنب الخلط المفاهيمي.\n`;
    response += `- **الركن الثاني - التحليل والخطوات الإجرائية:** تطبيق المنهج العلمي من خلال تفكيك المسألة إلى مدخلات، عمليات معالجة، واستنتاجات دقيقة.\n`;
    response += `- **الركن الثالث - الربط العملي والتطبيقي:** ربط المفردات النظرية بأمثلة تطبيقية وحالات واقعية تثبت المعلومة في الذاكرة.\n\n`;
  }

  response += `### ⚠️ 4. تنبيهات دراسية وأخطاء شائعة في الاختبارات:\n`;
  response += `- احرص على التأكد من توحيد وحدات القياس قبل التعويض في القوانين (مثل التحويل من كيلومتر إلى متر أو من دقيقة إلى ثانية).\n`;
  response += `- اكتب دائماً وحدة القياس بجانب الناتج النهائي لأن إهمالها يخصم درجات في الاختبارات الوزارية.\n\n`;

  response += `---\n`;
  response += `> 💡 **ملاحظة تعليمية:** تم تنظيم وصياغة هذا الشرح بدقة وفق أعلى معايير الشرح التربوي لتمكينك من الفهم الكامل والتفوق الدراسي.`;

  return response;
}


export async function generateContentWithFailover(options: ChatGenerateOptions): Promise<{
  text: string;
  grounding?: any;
  meta: AIResponseMeta;
}> {
  const gemini = getGeminiClient();
  const fallbackConfig = options.fallbackConfig || {};
  const fallbackAvailable =
    fallbackConfig.enabled !== false &&
    !!(fallbackConfig.apiKey || process.env.OPENAI_API_KEY);

  // Determine model order - prioritizing primary robust model
  const modelQueue: string[] = [];
  const primaryModel =
    options.model && GEMINI_CANDIDATE_MODELS.includes(options.model)
      ? options.model
      : "gemini-3.8-flash";
  modelQueue.push(primaryModel);
  for (const m of GEMINI_CANDIDATE_MODELS) {
    if (!modelQueue.includes(m)) modelQueue.push(m);
  }

  // If Gemini is available, try the models in order with silent auto-retry
  if (gemini) {
    let lastGeminiError: any = null;

    for (const modelName of modelQueue) {
      let shouldTryNextModel = false;
      const maxRetries = 1; // 1 quick retry for transient network drops

      for (let attempt = 0; attempt <= maxRetries && !shouldTryNextModel; attempt++) {
        try {
          const tools: any[] = [];
          if (options.mode === "hybrid" || options.searchGrounding) {
            tools.push({ googleSearch: {} });
          }

          const config: any = {
            systemInstruction:
              options.systemInstruction || DEFAULT_EDUCATIONAL_SYSTEM_INSTRUCTION,
            temperature: options.jsonMode ? 0.2 : 0.4,
            maxOutputTokens: options.maxOutputTokens || 8192,
          };
          if (options.jsonMode) {
            config.responseMimeType = "application/json";
          }
          if (tools.length > 0) {
            config.tools = tools;
          }

          const callParams: any = {
            model: modelName,
            contents: buildGeminiContents(options.prompt, options.conversationHistory),
            config,
          };

          const geminiCall = gemini.models.generateContent(callParams);

          // 90s timeout for deep indexing and complex academic queries
          const response = await withTimeout(
            geminiCall,
            90000,
            `انتهت مهلة استجابة المزود (${modelName}).`
          );

          let textOutput = response.text || "";
          let candidate = response.candidates?.[0];
          // Auto-continuation for non-stream if hit token limit
          const isMaxTokens = String(candidate?.finishReason || "").toUpperCase().includes("MAX_TOKENS") ||
            String(candidate?.finishReason || "").toUpperCase().includes("LENGTH");

          if (isMaxTokens && textOutput.length > 500) {
            try {
              const contRes = await gemini.models.generateContent({
                model: modelName,
                contents: [
                  { role: "user", parts: [{ text: options.prompt }] },
                  { role: "model", parts: [{ text: textOutput.slice(-3000) }] },
                  {
                    role: "user",
                    parts: [{
                      text: "استمر فوراً وبدقة في استكمال الشرح والتفصيل الأكاديمي الشامل من النقطة التي توقفت عندها بالضبط دون أي تكرار لأي محتوى سابق، واصل تفكيك بقية الأفكار والأبواب والأمثلة بالتفصيل الكامل.",
                    }],
                  },
                ],
                config,
              });
              if (contRes.text) {
                textOutput += "\n\n" + contRes.text;
              }
            } catch (e) {
              console.warn("Non-stream auto-continuation error:", e);
            }
          }

          if (textOutput.trim()) {
            const rawGrounding = response.candidates?.[0]?.groundingMetadata || null;
            return {
              text: textOutput,
              grounding: formatGroundingMetadata(rawGrounding),
              meta: {
                activeProvider: "gemini",
                modelUsed: modelName,
                fallbackUsed: false,
              },
            };
          }
        } catch (err: any) {
          lastGeminiError = err;
          const errMsg = err?.message || "";
          // If rate limited or unavailable, immediately switch to next model without wasting retries
          if (errMsg.includes("429") || errMsg.includes("503") || errMsg.includes("RESOURCE_EXHAUSTED")) {
            console.warn(`Gemini [${modelName}] quota/demand busy, immediately trying next model...`);
            shouldTryNextModel = true;
            break;
          }
          if (attempt < maxRetries) {
            await new Promise((r) => setTimeout(r, 400));
          }
        }
      }
    }

    // If all Gemini models failed, attempt seamless fallback provider if available!
    if (fallbackAvailable) {
      console.log(`[AI Failover] Gemini exhausted. Seamlessly switching to fallback provider: ${fallbackConfig.providerName || 'OpenAI-Compatible'}`);
      try {
        const fallbackRes = await callOpenAICompatible(options, fallbackConfig);
        return {
          text: fallbackRes.text,
          grounding: null,
          meta: fallbackRes.meta,
        };
      } catch (fbErr: any) {
        console.warn("[AI Failover] Fallback provider also failed:", fbErr?.message || fbErr);
      }
    }

    // Honest diagnostic if all Gemini models failed
    const cat = categorizeAIError(lastGeminiError);
    return {
      text: `### ⚠️ تعذر الحصول على استجابة من نموذج الذكاء الاصطناعي\n\n- **التفاصيل:** ${cat.userMessage}\n- **الإجراء المقترح:** ${cat.suggestedAction}\n\nيرجى النقر على زر إعادة المحاولة.`,
      grounding: null,
      meta: {
        activeProvider: "gemini",
        modelUsed: "فشل الاستدعاء",
        fallbackUsed: false,
        fallbackReason: cat.originalError,
      },
    };
  }

  // If Gemini client not available, try fallback immediately!
  if (fallbackAvailable) {
    try {
      const fallbackRes = await callOpenAICompatible(options, fallbackConfig);
      return {
        text: fallbackRes.text,
        grounding: null,
        meta: fallbackRes.meta,
      };
    } catch (fbErr: any) {
      console.warn("[AI Failover] Fallback attempt error:", fbErr?.message || fbErr);
    }
  }

  const cat = categorizeAIError(new Error("لم يتم تكوين مفتاح Gemini API في البيئة"));
  return {
    text: `### ⚠️ لم يتم تكوين مفتاح Gemini API\n\nيرجى التأكد من تهيئة متغير البيئة GEMINI_API_KEY للمتابعة.`,
    grounding: null,
    meta: {
      activeProvider: "gemini",
      modelUsed: "غير مهيأ",
      fallbackUsed: false,
      fallbackReason: cat.originalError,
    },
  };
}

/**
 * Unified Direct Streaming exclusively with Primary Gemini Models
 */
export async function generateContentStreamWithFailover(
  options: ChatGenerateOptions,
  res: any
): Promise<void> {
  const gemini = getGeminiClient();
  const fallbackConfig = options.fallbackConfig || {};
  const fallbackAvailable =
    fallbackConfig.enabled !== false &&
    !!(fallbackConfig.apiKey || process.env.OPENAI_API_KEY);

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("X-Accel-Buffering", "no");
  if (typeof res.flushHeaders === "function") {
    res.flushHeaders();
  }
  // Send immediate initial event to establish connection without delay
  res.write(": connected\n\n");

  // If user selected Fallback as active provider, route directly
  if (fallbackConfig.activeProvider === "fallback" && fallbackAvailable) {
    try {
      console.log(`[Stream Direct] Routing to fallback provider: ${fallbackConfig.providerName || "OpenAI"}`);
      const fbRes = await callOpenAICompatible(options, fallbackConfig);
      res.write(
        `data: ${JSON.stringify({
          providerInfo: {
            activeProvider: "fallback",
            modelUsed: fbRes.meta.modelUsed,
            fallbackUsed: true,
            fallbackReason: "Direct user selection",
          },
        })}\n\n`
      );
      res.write(`data: ${JSON.stringify({ text: fbRes.text })}\n\n`);
      res.write(`data: [DONE]\n\n`);
      res.end();
      return;
    } catch (fbErr: any) {
      console.warn("[Stream Direct] Fallback direct call failed:", fbErr?.message || fbErr);
    }
  }

  const modelQueue: string[] = [];
  const primaryModel =
    options.model && GEMINI_CANDIDATE_MODELS.includes(options.model)
      ? options.model
      : "gemini-3.8-flash";
  modelQueue.push(primaryModel);
  for (const m of GEMINI_CANDIDATE_MODELS) {
    if (!modelQueue.includes(m)) modelQueue.push(m);
  }

  if (!gemini) {
    res.write(`data: ${JSON.stringify({ error: "لم يتم تكوين مفتاح Gemini API في النظام." })}\n\n`);
    res.write(`data: [DONE]\n\n`);
    res.end();
    return;
  }

  let lastStreamError: any = null;
  let providerInfoWritten = false;

  for (const modelName of modelQueue) {
    if (providerInfoWritten) break;
    let shouldTryNext = false;
    const maxRetries = 1;

    for (let attempt = 0; attempt <= maxRetries && !shouldTryNext; attempt++) {
      if (providerInfoWritten) break;
      try {
        const tools: any[] = [];
        if (options.mode === "hybrid" || options.searchGrounding) {
          tools.push({ googleSearch: {} });
        }

        const config: any = {
          systemInstruction:
            options.systemInstruction || DEFAULT_EDUCATIONAL_SYSTEM_INSTRUCTION,
          temperature: 0.4,
          maxOutputTokens: 32768,
        };
        if (tools.length > 0) {
          config.tools = tools;
        }

        const streamParams: any = {
          model: modelName,
          contents: buildGeminiContents(options.prompt, options.conversationHistory),
          config,
        };

        // 90 seconds timeout for complex and deep retrieval
        const streamResponse = await withTimeout(
          gemini.models.generateContentStream(streamParams),
          90000,
          `انتهت مهلة استجابة مزود الذكاء الاصطناعي (${modelName}).`
        );

        let accumulatedGrounding: any = null;
        let wroteAnyChunk = false;
        let accumulatedStreamText = "";
        let lastCandidate: any = null;

        for await (const chunk of streamResponse) {
          const chunkText = chunk.text || "";
          const candidate = chunk.candidates?.[0];
          if (candidate) {
            lastCandidate = candidate;
          }
          if (candidate?.groundingMetadata) {
            accumulatedGrounding = candidate.groundingMetadata;
          }

          if (chunkText) {
            if (!providerInfoWritten) {
              providerInfoWritten = true;
              res.write(
                `data: ${JSON.stringify({
                  providerInfo: {
                    activeProvider: "gemini",
                    modelUsed: modelName,
                    fallbackUsed: false,
                  },
                })}\n\n`
              );
            }
            wroteAnyChunk = true;
            accumulatedStreamText += chunkText;
            res.write(`data: ${JSON.stringify({ text: chunkText })}\n\n`);
          }
        }

        // Auto-Continuation (Chunk Streaming):
        // If the model reached token boundary (MAX_TOKENS or LENGTH), seamlessly continue generating
        let lastFinishReasonStr = String(lastCandidate?.finishReason || "").toUpperCase();
        let continuationRound = 0;
        const MAX_CONTINUATION_ROUNDS = 3;

        while (
          (lastFinishReasonStr.includes("MAX_TOKENS") || lastFinishReasonStr.includes("LENGTH")) &&
          continuationRound < MAX_CONTINUATION_ROUNDS &&
          accumulatedStreamText.length > 500
        ) {
          continuationRound++;
          console.log(`[Auto-Continuation] Stream hit MAX_TOKENS. Continuing seamlessly (Round ${continuationRound})...`);
          try {
            const contStream = await gemini.models.generateContentStream({
              model: modelName,
              contents: [
                { role: "user", parts: [{ text: options.prompt }] },
                { role: "model", parts: [{ text: accumulatedStreamText.slice(-3500) }] },
                {
                  role: "user",
                  parts: [{
                    text: "استمر فوراً وبدقة في استكمال الشرح والتفصيل الأكاديمي الشامل من النقطة والكلمة التي توقفت عندها بالضبط دون أي تكرار لأي محتوى سابق، واصل تفكيك بقية الأفكار والأبواب والأمثلة المحلولة والقواعد بالتفصيل الكامل وبلا أي اختصار.",
                  }],
                },
              ],
              config,
            });

            let roundHasText = false;
            for await (const contChunk of contStream) {
              const contText = contChunk.text || "";
              const cCandidate = contChunk.candidates?.[0];
              if (cCandidate?.finishReason) {
                lastFinishReasonStr = String(cCandidate.finishReason).toUpperCase();
              }
              if (contText) {
                roundHasText = true;
                accumulatedStreamText += contText;
                res.write(`data: ${JSON.stringify({ text: contText })}\n\n`);
              }
            }
            if (!roundHasText) break;
          } catch (contErr) {
            console.warn("Auto-continuation stream error:", contErr);
            break;
          }
        }

        if (accumulatedGrounding) {
          res.write(`data: ${JSON.stringify({ grounding: formatGroundingMetadata(accumulatedGrounding) })}\n\n`);
        }

        if (wroteAnyChunk) {
          res.write(`data: [DONE]\n\n`);
          res.end();
          return;
        }
      } catch (err: any) {
        lastStreamError = err;
        const errMsg = err?.message || "";

        if (providerInfoWritten) {
          console.error(`Stream interrupted after streaming began for [${modelName}]:`, errMsg);
          res.write(`data: ${JSON.stringify({ error: "انقطع الاتصال أثناء تدفق البيانات." })}\n\n`);
          res.write(`data: [DONE]\n\n`);
          res.end();
          return;
        }

        // Immediate failover to next model on quota/rate-limits or high demand
        if (errMsg.includes("429") || errMsg.includes("503") || errMsg.includes("RESOURCE_EXHAUSTED")) {
          console.warn(`[Failover] Model [${modelName}] is busy/exhausted, advancing immediately to next model...`);
          shouldTryNext = true;
          break;
        }

        if (attempt < maxRetries) {
          await new Promise((r) => setTimeout(r, 400));
        }
      }
    }
  }

  // If all candidate models failed, attempt seamless failover to backup provider if available
  if (fallbackAvailable) {
    console.log(`[Stream Failover] All Gemini models busy. Streaming from fallback provider: ${fallbackConfig.providerName || "OpenAI-Compatible"}`);
    try {
      const fbRes = await callOpenAICompatible(options, fallbackConfig);
      res.write(
        `data: ${JSON.stringify({
          providerInfo: {
            activeProvider: "fallback",
            modelUsed: fbRes.meta.modelUsed,
            fallbackUsed: true,
            fallbackReason: "Primary Gemini models unavailable / quota busy",
          },
        })}\n\n`
      );
      res.write(`data: ${JSON.stringify({ text: fbRes.text })}\n\n`);
      res.write(`data: [DONE]\n\n`);
      res.end();
      return;
    } catch (fbErr: any) {
      console.error("[Stream Failover] Backup provider also failed:", fbErr?.message || fbErr);
    }
  }

  // If all candidate models and fallback failed, report clear diagnostic error directly
  const cat = categorizeAIError(lastStreamError);
  res.write(
    `data: ${JSON.stringify({
      error: `تعذر إتمام الاستجابة: ${cat.userMessage}`,
      errorCode: cat.code,
      providerInfo: {
        activeProvider: "gemini",
        modelUsed: "فشل الاستدعاء",
        fallbackUsed: false,
        fallbackReason: lastStreamError?.message,
      },
    })}\n\n`
  );
  res.write(`data: [DONE]\n\n`);
  res.end();
}
