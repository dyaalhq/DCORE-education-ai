import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { defineConfig } from 'vite';
import pwaPkg from 'vite-plugin-pwa/dist/index.cjs';
import viteCompression from 'vite-plugin-compression';

const VitePWA = pwaPkg.VitePWA || (pwaPkg as any).default?.VitePWA || pwaPkg;

import { visualizer } from 'rollup-plugin-visualizer';
import { execSync } from 'child_process';
import fs from 'fs';

/**
 * Automated Asset & Image Optimizer Plugin
 * Compresses oversized icons/images and generates modern WebP equivalents during build
 */
function imageOptimizerPlugin() {
  return {
    name: 'automated-image-optimizer',
    buildStart() {
      try {
        const root = process.cwd();
        const targets = [
          { file: 'public/logo.jpg', resize: '512x512', quality: 82 },
          { file: 'public/apple-touch-icon.png', resize: '180x180', quality: 85 },
          { file: 'public/icon-192.png', resize: '192x192', quality: 85 },
          { file: 'public/icon-512.png', resize: '512x512', quality: 85 },
          { file: 'public/favicon.ico', resize: '48x48', quality: 85 },
          { file: 'src/assets/images/smart_teacher_logo_1791551437596.jpg', resize: '512x512', quality: 82 },
        ];
        for (const t of targets) {
          const fullPath = path.join(root, t.file);
          if (fs.existsSync(fullPath)) {
            const st = fs.statSync(fullPath);
            if (st.size > 80 * 1024) {
              execSync(`convert "${fullPath}" -resize ${t.resize} -quality ${t.quality} "${fullPath}"`, { stdio: 'ignore' });
              const webpPath = fullPath.replace(/\.(png|jpg|jpeg)$/i, '.webp');
              if (!fullPath.endsWith('.ico') && !fs.existsSync(webpPath)) {
                execSync(`convert "${fullPath}" -quality ${t.quality} "${webpPath}"`, { stdio: 'ignore' });
              }
            }
          }
        }
      } catch (err) {
        // Graceful fallback if convert is not available
      }
    },
  };
}

export default defineConfig(() => {
  return {
    plugins: [
      react(),
      tailwindcss(),
      imageOptimizerPlugin(),
      // Brotli compression for maximum asset compaction
      viteCompression({
        algorithm: 'brotliCompress',
        ext: '.br',
        threshold: 1024,
        deleteOriginFile: false,
      }),
      // Gzip fallback compression
      viteCompression({
        algorithm: 'gzip',
        ext: '.gz',
        threshold: 1024,
        deleteOriginFile: false,
      }),
      visualizer({
        filename: 'dist/stats.html',
        title: 'Smart Scholar AI - Interactive Bundle Visualizer',
        open: false,
        gzipSize: true,
        brotliSize: true,
      }),
      VitePWA({
        registerType: 'autoUpdate',
        includeAssets: ['favicon.ico', 'apple-touch-icon.png', 'icon.svg'],
        manifest: {
          id: '/',
          name: 'المعلم الذكي - منصة دراسة ذكية بالذكاء الاصطناعي',
          short_name: 'المعلم الذكي',
          description: 'منصة تعليمية ذكية متقدمة بأسلوب NotebookLM لإدارة المصادر، المحادثة المعرفية مع المستندات، تلخيص الكتب والـ PDF، أدوات المذاكرة، والاختبارات التفاعلية.',
          theme_color: '#0f766e',
          background_color: '#f8fbfa',
          display: 'standalone',
          start_url: '/',
          scope: '/',
          icons: [
            {
              src: '/pwa-192x192.png',
              sizes: '192x192',
              type: 'image/png',
              purpose: 'any',
            },
            {
              src: '/pwa-512x512.png',
              sizes: '512x512',
              type: 'image/png',
              purpose: 'any',
            },
            {
              src: '/pwa-maskable-512x512.png',
              sizes: '512x512',
              type: 'image/png',
              purpose: 'maskable',
            },
          ],
        },
        workbox: {
          globPatterns: ['**/*.{js,css,html,ico,png,svg,woff,woff2}'],
          globIgnores: ['**/standalone.html', '**/al-muallem-al-dhaki-complete.html'],
          maximumFileSizeToCacheInBytes: 15 * 1024 * 1024,
        },
        devOptions: {
          enabled: true,
          type: 'module',
        },
      }),
    ],
    resolve: {
      alias: {
        '@': path.resolve(import.meta.dirname ?? process.cwd(), '.'),
      },
    },
    build: {
      target: 'es2020',
      minify: 'terser',
      terserOptions: {
        compress: {
          drop_console: true,
          drop_debugger: true,
          pure_funcs: ['console.log', 'console.info', 'console.debug'],
          passes: 2,
        },
        mangle: {
          safari10: true,
        },
        format: {
          comments: false,
        },
      },
      chunkSizeWarningLimit: 1200,
      rollupOptions: {
        output: {
          manualChunks(id) {
            // Split pdf.js and PDF tooling into their own chunk
            if (id.includes('node_modules/pdfjs-dist') || id.includes('html2pdf.js') || id.includes('jspdf') || id.includes('pdf-parse')) {
              return 'vendor-pdf';
            }
            if (id.includes('node_modules/three') || id.includes('@react-three')) {
              return 'vendor-three';
            }
            if (id.includes('node_modules/katex') || id.includes('react-katex') || id.includes('rehype-katex') || id.includes('remark-math')) {
              return 'vendor-katex';
            }
            if (id.includes('node_modules/recharts') || id.includes('node_modules/d3')) {
              return 'vendor-charts';
            }
            if (id.includes('node_modules/lucide-react')) {
              return 'vendor-icons';
            }
            if (id.includes('node_modules/react/') || id.includes('node_modules/react-dom/')) {
              return 'vendor-react';
            }
          },
        },
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modifyâfile watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
